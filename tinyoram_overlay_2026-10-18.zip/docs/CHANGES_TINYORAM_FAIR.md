# Tiny ORAM: changes for a fair comparison with DOMA (2026-10-18)

*The next round, with the card scripts and the new checks, is `CHANGES_TINYORAM_CARD.md`; its acceptance figures supersede the counts below.*

Base: **your current `fpga_zcu208_deploy.zip`** (2026-10-18: Z = 10, compact buckets, 300 MHz closure,
command prefetch, arrival-mode early release). Its Tiny ORAM files were exactly the Phase 2 merge: the
audit (`tinyoram_audit.zip`, 2026-10-13) had not been merged. So this delivery carries the audit too
(`docs/CHANGES_TINYORAM_AUDIT.md`), and Tiny ORAM's own files are replaced whole. Of the shared files,
only `vitis/host_doma.cpp` and `vitis/scan.sh` change, by additions on the Tiny ORAM path and the opt-in
`DOMA_LAT_HIST`. Patch against your package: `docs/tinyoram_fair_shared_files.diff`.

| Note item | File | Change |
|---|---|---|
| 2. Front end | `tinyoram/rtl/tinyoram_kernel.v` | **Prefetch:** a fetcher prefetches command k+1's header during `K_WAIT`, and for a PUT its data too (2 beats at 64 B, 128 at 4 KB), into a block-sized buffer. Every run start clears it; requests are held until taken. **Posted response writes:** GET data and headers don't wait for B. `wb_pend` counts them, and the run waits for all of them once, before the summary. **Header queue:** one entry, so the acknowledged latency can be filled in later. About 52 cycles per command saved at 64 B in simulation. |
| 7. Latency end point | `tinyoram/rtl/tinyoram_kernel.v`, `sim/tb_tinyoram_kernel.v` | Primary (header bytes 8–11, summary min/max) = data done, Tiny ORAM idle and every write-back beat handed off; the command is released then. Bytes 20–23 = write-back acknowledged; 16–19 = data ready. The adapter still holds the next reads until the writes are acknowledged. |
| 4. Merged bursts (B6) | `tinyoram/rtl/tinyoram_axi_adapter.v`; `fetch_tinyoram.sh … merge`; `build_tinyoram.sh MERGE=1` (tag `_merge`) | The adapter is rewritten with `MERGE` (0 = 1:1, the default and the published behaviour; 1 = contiguous commands merged, never across 4 KB or the split). The read-behind-unacknowledged-write hold is kept. At 64 B, read bursts are 12 beats (one bucket). |
| 3. Host memory, matched budgets | `tinyoram/rtl/tinyoram_kernel.v`, `tinyoram/rtl/tinyoram_axi_adapter.v`, `vitis/kernel_tinyoram.xml`, `vitis/package_tinyoram.tcl`, `vitis/tinyoram_hw.cfg`, `vitis/tinyoram_host.cfg` | New memory port `top` (`m_axi_gmem3`; HBM[8] with `tinyoram_host.cfg`, HBM[9] with `tinyoram_hw.cfg`) and scalar `top_bytes` (0x3C, 0x48). Tree offsets below `top_bytes` go to `top`, which is the tree top, since Tiny ORAM lays out subtrees breadth-first. `top_bytes` at or above the tree size puts the whole tree on-package; a value below is rounded down to 4 KB (error 0x80). Read and write data stay in command order across the two ports. The zero-fill covers both regions, and the traffic record counts both ports. |
| 5. Position map, both trust assumptions | `tinyoram/patches/07_flat_posmap_option.diff`; `fetch_tinyoram.sh … flatpm`; `build_tinyoram.sh FLATPM=1` (tag `_flatpm`) | (a) As published: recursion and PLB, the default. (b) `TINYORAM_RECURSION 1`: all N entries in an on-chip position map, with no PosMap ORAMs (1 MB at 131,072 blocks). It is on chip rather than in HBM; that is a stated limitation, slightly in Tiny ORAM's favour. |
| 6. Timing protection, latency spread | `vitis/host_doma.cpp`, docs | The host prints min, p50, p90, p99, p99.9, max, mean and a 16-bin histogram of the primary latency for Tiny ORAM (`DOMA_LAT_HIST=1` does the same for DOMA). The docs state that DOMA's figures include its timing padding and Tiny ORAM's do not. |
| Host (Tiny ORAM path only) | `vitis/host_doma.cpp` | 6-argument launch (`top` buffer and `top_bytes`); `DOMA_TINY_TOP=<bytes>\|all\|doma:<pct>`. `doma:<pct>` is the matched budget: the bytes `doma_kernel` keeps on-package at that HBM share for the same records, from the same sizes the host gives DOMA's buffers (8,076,960 / 10,076,960 / 18,076,960 B at 0 / 20 / 100% for 1M records, 32-byte blocks, packed; equal to the allocations under the XRT mock). `DOMA_TINY_FLATPM=1` takes the flat position map's 1 MB off it. A `placement:` line with on-package and host bytes per record; the latency line with the new primary figure; Tiny ORAM's traffic line labelled as both tree ports. DOMA's output is unchanged (checked under the XRT mock in 8 configurations, timings masked). |
| Sweeps (item 7) | `vitis/scan.sh` | `DOMA_KERNEL=tinyoram_kernel`: the same CSV columns from the same host and command stream. `NS` is the bitstream's record count. The second axis is `TOPS` (default `0 doma:0 doma:20 doma:100`), written to `hbm_pct`. Each run's full output goes to `<csv>.log`. With `doma_kernel` the script behaves as before: no line removed, CSV unchanged under the mock. |
| Review fixes | `tinyoram/rtl/tinyoram_kernel.v` | From an independent review of the rewrite (README §14): a write error after release is charged to that command's header and the summary; the acknowledged latency keeps counting after release; errors found while a header waits go to their own register (`errs_q`), so none is lost; an init launch lets leftover adapter traffic finish before the reset, `K_BOOT` has a timeout, and the run's end waits (bounded) for Tiny ORAM and the adapter to be idle; a zero-fill write error halts the ORAM (0x8). **New since:** a command charged an error after its release is no longer counted as completed (`nlate`), so the summary's count equals the headers without an error. And an error now wins over "all acknowledged" (header queue, `K_WAIT`, `K_HQ`): the adapter shows both in the same cycle when the failing response is the last one, which had released the header clean and charged the next command (found at 128 B, merged, with the split). |
| Tests | `sim/tb_tinyoram_kernel.v`, `sim/run_tinyoram.sh` | The top port gets its own memory model, with stale contents. `+top=<bytes>`, `+top_all`. Every burst must stay inside its own buffer and never cross 4 KB. A merged build runs per size. The block image now models Tiny ORAM's undefined contents after a GET of a never-written block. Fault injection: `+berr=K` (SLVERR on the K-th tree write response); after a release, `+berr_rel` (the first response while the header waits), `+berr_last` (the last one outstanding) and `+berr_early` (before a GET's header is queued: the response port is stalled, as a slave may, until a tree response arrives). The error must be on that command's header, and the completed count must equal the headers without an error. `+resp_rdy_gap` slows the response port only. The late-write tests preload first. A one-command run before run 1, and a monitor on command reads. **81 checks.** |
| Mutation checks | `sim/run_tinyoram_mutants.sh` (new) | 16 checks at 64 B, 14 mutants of the kernel and the adapter; every one must be caught. Two were missed by the first version of the tests (a1, m9); the tests were strengthened until both were caught, and that found the race above (README §14, "Tests and mutation checks"). |
| Docs | `docs/README_TINYORAM.md` §13–14, `docs/TINYORAM_CARD_RUNBOOK.md` (Phase 5 through `scan.sh`, matched budgets), `docs/CHANGES_TINYORAM_AUDIT.md`, `docs/tinyoram_mutants_2026-10-13.txt`, `docs/tinyoram_l15_merge_flatpm_sim_2026-10-18.txt`, `docs/tinyoram_regression_2026-10-18.txt`, `docs/tinyoram_mutants_2026-10-18.txt`, `docs/doma_regression_rebase_2026-10-18.txt`, `docs/tinyoram_fair_shared_files.diff`, `MANIFEST.sha256` | The comparison setup, the bitstream matrix and the runs; the audit's change list and mutation log, which were not in your package; the Tiny ORAM and DOMA logs; the shared-file patch; checksums regenerated. |

## Acceptance (this tree: your package with this zip unzipped over it)

* **DOMA** (`docs/doma_regression_rebase_2026-10-18.txt`): `ORAM_BEATS=1 bash run_verilator.sh` and
  `bash run_verilator.sh` both end with `ALL CHECKS PASSED`, with the timing hashes you gave: 32 B
  `fc899eb5aae696a2` / `c9fbaacc72ad716a`, 4 KB `05a12e803b18dc9f` / `e99b1b2a7b33c7bb`. The script
  printed 37 checks per size (0 failed) from 53 simulation runs; I could not reproduce "44" as a
  count, so I report what it printed. No file DOMA's regression uses differs from your package.
* **Tiny ORAM:** `bash run_tinyoram.sh` gives 81/81, and `bash run_tinyoram_mutants.sh` catches 16/16
  (`docs/tinyoram_regression_2026-10-18.txt`, `docs/tinyoram_mutants_2026-10-18.txt`). Both ran on your
  package with this zip unzipped over it, Tiny ORAM fetched from 18ece07 and patched by
  `fetch_tinyoram.sh`.
* **Host and `scan.sh`** (no XRT here, so under a functional mock of XRT):
  * DOMA's output is identical to your host's in 8 configurations, with timings masked. They cover
    HBM shares 0/20/100%, packing, `DOMA_POOL`, `DOMA_PAGES_HBM` and block sizes.
  * The DOMA `scan.sh` CSV is identical, with timing columns masked.
  * The Tiny ORAM paths (`doma:<pct>`, `all`, bytes, the flat-map adjustment, the errors) and a Tiny
    ORAM sweep produce the expected lines.
* **L = 15** (1M records packed), merged, no preload: 200 commands take 268,212 cycles with recursion
  and 81,387 with the flat position map. The 1:1 adapter took 403,362 cycles on the same commands.

## Not done in this delivery

* **Item 8 (clock, utilization) and the card runs:** these need Vivado and the U55C. The hierarchical
  utilization report of `vitis/synth_ooc_tinyoram.tcl` lists the core (`u_tiny`) and the adapter
  (`u_adapt`) separately, and the runbook's Phase 5 lists what to report per configuration. Bytes per
  command come from the host's `traffic:` line, and per-record placement from its `placement:` line.

## Files (relative to the package root; unzip over your package, nothing is deleted)

New: `docs/CHANGES_TINYORAM_AUDIT.md`, `docs/CHANGES_TINYORAM_FAIR.md`, `docs/doma_regression_rebase_2026-10-18.txt`, `docs/tinyoram_fair_shared_files.diff`, `docs/tinyoram_l15_merge_flatpm_sim_2026-10-18.txt`, `docs/tinyoram_mutants_2026-10-13.txt`, `docs/tinyoram_mutants_2026-10-18.txt`, `docs/tinyoram_regression_2026-10-18.txt`, `sim/run_tinyoram_mutants.sh`, `tinyoram/patches/07_flat_posmap_option.diff`.

Changed, Tiny ORAM only: `docs/README_TINYORAM.md`, `docs/TINYORAM_CARD_RUNBOOK.md`, `docs/tinyoram_l15_sim_2026-10-13.txt`, `docs/tinyoram_regression_2026-10-13.txt`, `sim/run_tinyoram.sh`, `sim/tb_tinyoram_kernel.v`, `tinyoram/fetch_tinyoram.sh`, `tinyoram/rtl/tinyoram_axi_adapter.v`, `tinyoram/rtl/tinyoram_kernel.v`, `vitis/build_tinyoram.sh`, `vitis/kernel_tinyoram.xml`, `vitis/package_tinyoram.tcl`, `vitis/synth_ooc_tinyoram.tcl`, `vitis/tinyoram_host.cfg`, `vitis/tinyoram_hw.cfg`. The 10-13 logs are the audit's reruns, which your package did not have.

Changed, shared: `vitis/host_doma.cpp` and `vitis/scan.sh`, additions only on the Tiny ORAM path, plus the opt-in `DOMA_LAT_HIST` (patch: `docs/tinyoram_fair_shared_files.diff`). `MANIFEST.sha256` is regenerated. Everything of DOMA's, `axi_mem_model.v`, `check_timing.sh` and `worst_paths.tcl` are unchanged.
