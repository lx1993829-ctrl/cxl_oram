# Tiny ORAM: before the U55C builds (2026-10-18, second note)

Base: your `fpga_zcu208_deploy.zip` of 2026-10-18 14:48, with `tinyoram_fair_rebased_2026-10-18.zip` (this
overlay replaces it). **The newest DOMA package (with `patches/fpga_vivado_order.patch`) was not attached**, so
this overlay could not be checked on it. `install_tinyoram.sh` is written for exactly that case: it verifies
whichever base it is given, patches the shared files if they changed since 14:48 (and stops if a patch does not
apply), regenerates the manifest, and with `--check` reruns DOMA's regression at both sizes on the result. The
newest package's changes (`rtl/doma_kernel.v`, `sim/run_verilator.sh`, `docs/README_FPGA.md`) are files this overlay
does not touch.

| Note item | File | Change |
|---|---|---|
| 1. Manifest, install | `tinyoram/card/install_tinyoram.sh` (new) | Base manifest verified; overlay; shared files replaced only if unchanged since the overlay's base, else patched; manifest regenerated over the combined tree and verified; one copy per bitstream; `--check` runs DOMA's regression at both sizes and both Tiny ORAM regressions. Tested here on your 14:48 package, on a base with newer shared files (patched, both sides' changes kept, CRLF kept), and on a conflicting base (stops). The overlay's own `MANIFEST.sha256` is the one for your 14:48 package plus the overlay; on the newest package, use the script, which regenerates it. |
| 2. Vivado's implicit-net error | `sim/run_tinyoram.sh`, `sim/run_tinyoram_mutants.sh` | `iverilog -Wimplicit` per size over the kernel, the adapter and the fetched core, for the 1:1, merged and flat-position-map variants. The kernel and the adapter have none. The core's eight are all in its REW-ORAM branch, which is not built and never declared later; they are listed exactly, and anything else fails. Mutant l1 (a use before its declaration) is caught. Nothing needed fixing. |
| 3. Hold under slow acknowledgements | `sim/tb_tinyoram_kernel.v`, `sim/run_tinyoram.sh`, `sim/axi_mem_model.v` | `slowack` and `m_slowack` at every size: acknowledgements 2,000 cycles late (6,000 at 4 KB), longer than a path write-back. The models hold all of it (`WF_DEPTH`, and a new `AW_DEPTH` parameter, default 16, as before). The longest hold must reach 1,000 / 3,000 cycles. A bus monitor, on in every test, fails any read overlapping an unacknowledged write. Mutant a1 (no hold) at 4 KB on both adapters is caught. |
| 4. Addresses above 4 GB | `sim/tb_tinyoram_kernel.v`; README §15 | The adapter and kernel are 64-bit throughout. The testbench's tree and top buffers now straddle a 4 GB boundary; mutant a4 (32-bit base + offset) is caught. Documented limits: `top_bytes` is 32-bit (top ≤ 4 GB − 4 KB); the record fields are 256 GB / 17 GB per launch. Largest planned tree: 902 MB. |
| Traffic by port | `tinyoram/rtl/tinyoram_kernel.v`, `vitis/host_doma.cpp` | Record bytes 1–7: the top port's share. The host prints `traffic split:` pages (off-package) / top (on-package) per command. |
| 5. Bring-up | `tinyoram/card/bringup_64.sh` (new) | `ooc` / `emu` / `hw` / `card`, each with its pass criterion and a report to send back (`bringup_report.txt`). The board build is the headline configuration at small size (merged, tree in host memory). The card runs cover the split, the whole tree on-package and back-to-back runs. The post-placement check is automatic. |
| 6. Build queue | `tinyoram/card/queue.sh`, `queue.txt` (new) | The 7 builds, one at a time, each in its own copy. Out-of-context timing at its geometry first: a failure skips the board build and names the reachable clock. Post-place WNS < −0.5 ns stops the build. Then the timing verdict. Commands: `status`, `pause`, `stop`, `reset`, `log`. |
| 7. Sweeps and table | `tinyoram/card/sweep_tiny.sh`, `sweep_doma.sh`, `merge_results.py` (new); `vitis/scan.sh`, `vitis/host_doma.cpp` | Matching settings: Tiny ORAM `TOPS="0 doma:0 doma:20 doma:50 doma:100"`, with matched budgets for DOMA's 32-byte blocks packed 4 per block (4 KB unpacked); DOMA `DOMA_PACK=1 NS="100000 1000000 10000000" HBMS="0 20 50 100"`. One table per configuration. DOMA's host gets opt-in `DOMA_PLACEMENT=1` and a check that the matched-budget sizes equal its buffers; `scan.sh` gets opt-in `SCAN_LOG=1`. DOMA's default output and CSV are unchanged (mock, 11 configurations). |
| 8. Differences to state | README §15, `merge_results.py` | GET/PUT-uniform padded DOMA vs unprotected Tiny ORAM (PUT data prefetch only); the on-chip position map in (b); DOMA's ~8 MB on-package at 0%. `comparison.md` opens with them. |
| Docs | README §15 and status line, runbook (scripts first; OOC first-line text), this file, the logs | |

## Acceptance

Run here on your 14:48 package with this overlay on it (the newest package was not attached):
* **DOMA:** `ORAM_BEATS=1 bash run_verilator.sh` and `bash run_verilator.sh` both `ALL CHECKS PASSED`, 37 checks
  each, with the same timing hashes: 32 B `fc899eb5aae696a2` / `c9fbaacc72ad716a`, 4 KB `05a12e803b18dc9f` /
  `e99b1b2a7b33c7bb` (`docs/doma_regression_rebase_2026-10-18.txt`). This includes the memory model's new
  `AW_DEPTH` parameter, which defaults to the old 16.
* **Tiny ORAM:** `run_tinyoram.sh` 93/93 (the 81 before, plus 4 lint and 8 slow-acknowledgement checks);
  `run_tinyoram_mutants.sh` 20/20 (adding l1, a4 and a1 at 4 KB on both adapters). See
  `docs/tinyoram_regression_2026-10-18.txt` and `docs/tinyoram_mutants_2026-10-18.txt`.
* **Scripts:** all dry-run here against stand-ins for XRT, Vivado and v++ (README §15). On the card they are
  untested, and the bring-up is what tests them.
* **On the newest package:** `install_tinyoram.sh <newest zip> <this zip> ~/tiny --check` does the same and must
  end with `INSTALL OK, ALL REGRESSIONS PASSED`.

## Files

Unzip over your 14:48 package (nothing is deleted), or better, use `tinyoram/card/install_tinyoram.sh`, which
works on any later base too.

New in this round: `tinyoram/card/` (`install_tinyoram.sh`, `bringup_64.sh`, `queue.sh`, `queue.txt`,
`sweep_tiny.sh`, `sweep_doma.sh`, `merge_results.py`), `docs/CHANGES_TINYORAM_CARD.md`.

Changed in this round: `tinyoram/rtl/tinyoram_kernel.v` (traffic by port), `sim/tb_tinyoram_kernel.v`,
`sim/run_tinyoram.sh`, `sim/run_tinyoram_mutants.sh`, `vitis/host_doma.cpp`, `vitis/scan.sh`,
`sim/axi_mem_model.v` (shared: `AW_DEPTH`, default 16), `docs/README_TINYORAM.md` (§15),
`docs/TINYORAM_CARD_RUNBOOK.md`, `docs/CHANGES_TINYORAM_FAIR.md` (pointer), the logs,
`docs/tinyoram_fair_shared_files.diff` (now all three shared files), `MANIFEST.sha256`.

Carried from the previous rounds (also not in your package): everything in `CHANGES_TINYORAM_FAIR.md` and
`CHANGES_TINYORAM_AUDIT.md`.

Shared files, all by additions with defaults that leave DOMA unchanged: `vitis/host_doma.cpp`, `vitis/scan.sh`,
`sim/axi_mem_model.v` (patch: `docs/tinyoram_fair_shared_files.diff`). `check_timing.sh`, `worst_paths.tcl` and
everything of DOMA's are untouched.
