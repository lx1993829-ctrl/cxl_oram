# Tiny ORAM: fixes from the Phase 2 audit (2026-10-13)

Base: the Phase 2 merge. Unzip over the package root. No file is deleted. No shared file changes:
`host_doma.cpp`, `axi_mem_model.v`, `check_timing.sh` and `worst_paths.tcl` are as merged, and so
is everything of DOMA's.

| Audit item | File | Change |
|---|---|---|
| 1. Re-boot on every init launch | `tinyoram/rtl/tinyoram_kernel.v` | Every launch with `size = 0` enters `K_RST`. Tiny ORAM and the adapter are held in reset, `pages` is latched again, and the geometry is reported without memory access. The next launch with commands zero-fills the tree again and releases the core, which clears its PosMap, PLB and stash. `0x20` is now raised only by a launch with commands that names a buffer other than the one from the last init. The zero-fill's response counter counts only during the fill and never drops below zero. |
| 1. Test | `sim/tb_tinyoram_kernel.v`, `sim/run_tinyoram.sh` | `+reboot` (every size) does a second init with the tree buffer moved, and `+reboot +reboot_same` (64 B) one at the same address. Each must touch no memory at init. A probe follows: one record into each of blocks 0–7, then whole-block reads, which must show zeros around the record. Then the runs and verify must pass against a fresh model. A command launch naming another buffer must report `0x20` and keep the latched buffer. An address monitor fails any tree burst outside the latched buffer. |
| 2. `$random` → xorshift32 | `sim/tb_tinyoram_kernel.v` | `rnd()` drives commands and stale tree contents; `prnd()` drives packed offsets, lengths and junk. Both use `tb_stash.v`'s xorshift32. |
| 3. Check order | `tinyoram/rtl/tinyoram_kernel.v`, `sim/tb_tinyoram_kernel.v` | The order is now `doma_kernel.v`'s, as in step 5.2: opcode, PUT range, halted, key, and then the GET range, which is Tiny ORAM only. Bad range plus bad key therefore gives 0x40 for a PUT and 0x4 for a GET, and the verify launch tests both. **To confirm against the current zip.** |
| 4. Runbook | `docs/TINYORAM_CARD_RUNBOOK.md` | One unzipped copy per bitstream (`~/fpga_tiny64`, `~/fpga_tiny64_l15`). Back-to-back runs on one bitstream are now stated as safe. New section on the tree in host memory (`CFG=tinyoram_host.cfg`, once host memory is enabled). The Phase 4 traffic estimate is redone with the new generator: 11–18 KB each way per command. |
| 4. Host-memory xclbin name | `vitis/build_tinyoram.sh` | With `CFG=tinyoram_host.cfg` the tag gets `_host`, so it no longer overwrites the HBM xclbin. |
| Docs | `docs/README_TINYORAM.md` (§13), `docs/tinyoram_regression_2026-10-13.txt`, `docs/tinyoram_mutants_2026-10-13.txt`, `docs/tinyoram_l15_sim_2026-10-13.txt` | Description, regression log (33/33), mutation results, and the Phase 4 simulation rerun with xorshift32. |

`HOST_WORDS` in the testbench defaults to 8 MB (was 4 MB), so `+reboot` has room for two trees at 4 KB.

## Acceptance

* **Tiny ORAM:** `bash run_tinyoram.sh` gives **33/33**. That is the 28 Phase 2 checks, all rerun with xorshift32, plus `reboot` at four sizes and `rebootsame` at 64 B.
* **Mutation checks (64 B):** all are caught.

  | Mutant | Test | Result |
  |---|---|---|
  | Wrong last-beat formula | `+ranges` | Hangs at the limit |
  | Mask not restored after a partial PUT | `+ranges` | 3 failures |
  | No core reset at init | `+reboot` | Tiny ORAM's own check stops on garbage |
  | No core reset at init | `+reboot_same` | Probe fails |
  | `pages` not re-latched | `+reboot` | Summary wrong |
  | Phase 2 check order | `+packed=8` | GET with bad range and bad key returns 0x40, not 0x4 |
* **DOMA:** not rerun on the current package; the zip was not attached. Nothing of DOMA's or of the shared files changes here. Expected: 28/28 per size, with hashes 1d0cbb36268422ce/886ed1a80f3e4fae (32 B) and 11f8bfc8e4d73473/61fc9e15ed9aea5b (4 KB).
