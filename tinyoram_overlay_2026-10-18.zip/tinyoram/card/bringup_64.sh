#!/bin/bash
# bringup_64.sh -- card bring-up of tinyoram_kernel at 64 B, L = 6 (runbook Phases 3.2-3.5), with pass criteria.
#
#   bash bringup_64.sh ooc     3.2  out-of-context place and route at 300 MHz, 1:1 and merged adapter (1-2 hours)
#   bash bringup_64.sh emu     3.3  hardware emulation, merged adapter, tree in HBM: 4 short runs (about 1 hour)
#   bash bringup_64.sh hw      3.4  board build: merged adapter, tree in host memory (HOST[0]), as the headline (hours)
#   bash bringup_64.sh card    3.5  6 runs on the card with that bitstream (minutes)
#   bash bringup_64.sh report       print the report so far
# Run the steps in this order, each only after the one before passed. Run it in the bring-up copy that
# install_tinyoram.sh made (DEST/bringup/fpga_zcu208); it never touches another copy.
# Every step appends its verdict to bringup_report.txt next to this package copy (DEST/bringup/). Send me that file
# after each step; on a FAIL, also the log the report names.
# No large build (queue.sh) should start before "card" has passed.
set -u
CARD=$(cd "$(dirname "$0")" && pwd)
PKG=$(cd "$CARD/../.." && pwd)
V=$PKG/vitis
REP=$(dirname "$PKG")/bringup_report.txt
VITIS_SETTINGS=${VITIS_SETTINGS:-/tools/Xilinx/Vitis/2024.1/settings64.sh}
XRT_SETUP=${XRT_SETUP:-/opt/xilinx/xrt/setup.sh}
FREQ=${FREQ:-300}
say() { echo "$*"; echo "$*" >> "$REP"; }
tools() { command -v vivado > /dev/null || { source "$VITIS_SETTINGS" > /dev/null 2>&1; source "$XRT_SETUP" > /dev/null 2>&1; }
          command -v vivado > /dev/null || { echo "vivado not found: source $VITIS_SETTINGS (or set VITIS_SETTINGS)"; exit 2; }; }
cd "$V" || exit 2

# check_run <label> <log> <cmds> <GET/PUT text or ""> <expected top bytes or ""> <top traffic: zero|some|all|"">
# The lines every correct run prints, and the traffic: at least one 2,688-byte path each way per command.
check_run() {
    local lb=$1 lg=$2 nc=$3 gp=$4 top=$5 tt=$6 ok=1 why=""
    grep -q "^ALL RESPONSES CORRECT" $lg || { ok=0; why="$why no ALL RESPONSES CORRECT;"; }
    grep -qE "completed $nc, errors 0x0, summary ok" $lg || { ok=0; why="$why not 'completed $nc, errors 0x0, summary ok';"; }
    [ -n "$gp" ] && { grep -qF "$gp" $lg || { ok=0; why="$why not '$gp';"; }; }
    [ -n "$top" ] && { grep -qE "^placement: tree [0-9]+ B = $top B on-package" $lg || { ok=0; why="$why top buffer not $top B;"; }; }
    local rd; rd=$(grep -oE "= [0-9]+ B read, [0-9]+ B written per command" $lg | head -1 | awk '{print $2}')
    { [ -n "$rd" ] && [ "$rd" -ge 2688 ] && [ "$rd" -le 10752 ]; } || { ok=0; why="$why traffic ${rd:-missing} B read per command (expected 2,688 or a little more);"; }
    local sp; sp=$(grep -E "^traffic split:" $lg | head -1)
    local prd trd; prd=$(echo "$sp" | awk '{print $5}'); trd=$(echo "$sp" | awk '{print $15}')
    case "$tt" in
      zero) [ "${trd:-x}" = 0 ] || { ok=0; why="$why top-port traffic ${trd:-missing}, expected 0;"; } ;;
      some) { [ "${trd:-0}" -gt 0 ] && [ "${prd:-0}" -gt 0 ]; } 2>/dev/null || { ok=0; why="$why traffic not split over both ports (pages ${prd:-?}, top ${trd:-?});"; } ;;
      all)  [ "${prd:-x}" = 0 ] || { ok=0; why="$why pages-port traffic ${prd:-missing}, expected 0;"; } ;;
    esac
    local lat; lat=$(grep -oE "to last write-back beat [0-9]+\.\.[0-9]+" $lg | head -1 | awk '{print $5}')
    if [ $ok = 1 ]; then say "  PASS  $lb (latency ${lat:-?} cycles, $rd B read per command; $(grep -m1 '^query:' $lg | grep -oE '[0-9.]+ KQPS'))"
    else say "  FAIL  $lb:$why ($lg)"; FAILED=1; fi
}

step=${1:-}
case "$step" in
ooc)
    tools; say "== 3.2 out-of-context timing at $FREQ MHz, 64 B, L = 6 ($(date '+%F %T'))"; FAILED=0
    for m in "" merge; do
        bash ../tinyoram/fetch_tinyoram.sh 64 6 $m > bringup_fetch.log 2>&1 || { say "  FAIL  fetch_tinyoram.sh ($V/bringup_fetch.log)"; exit 1; }
        lg=bringup_ooc_${m:-1to1}.log
        vivado -mode batch -nojournal -nolog -source synth_ooc_tinyoram.tcl -tclargs route $FREQ > $lg 2>&1
        line=$(grep -E "^WNS: " $lg | tail -1); wns=$(echo "$line" | awk '{print $2}'); whs=$(echo "$line" | awk '{print $5}')
        util=$(grep -m1 -E "^\| *tinyoram_kernel" ooc_tinyoram_64B_L6${m:+_merge}_${FREQ}mhz/util_routed.rpt 2>/dev/null | tr -s ' ' | cut -c1-120)
        if [ -n "$wns" ] && awk -v w="$wns" -v h="$whs" 'BEGIN{exit !(w >= 0 && h >= 0)}'; then
            say "  PASS  ${m:-1:1} adapter: WNS $wns ns, WHS $whs ns at $FREQ MHz"
        else
            f=$(awk -v w="${wns:-0}" -v m="$FREQ" 'BEGIN{f = 1000 / (1000 / m - w); printf "%d", int(f / 5) * 5}')
            say "  FAIL  ${m:-1:1} adapter: WNS ${wns:-missing} ns, WHS ${whs:-missing} ns at $FREQ MHz (about $f MHz reachable; $V/$lg, worst paths in ooc_tinyoram_64B_L6${m:+_merge}_${FREQ}mhz/worst_groups.txt)"; FAILED=1
        fi
        [ -n "$util" ] && say "        utilization (whole kernel, out of context): $util"
    done
    say "  pass criterion: WNS >= 0 and WHS >= 0 for both. $([ $FAILED = 0 ] && echo 'PASSED: go on with  bash bringup_64.sh emu' || echo 'FAILED: send me the report and the named logs')"
    exit $FAILED ;;
emu)
    tools; say "== 3.3 hardware emulation, merged adapter, tree in HBM ($(date '+%F %T'))"; FAILED=0
    SIZE=64 TARGET=hw_emu MERGE=1 FREQ=$FREQ bash build_tinyoram.sh > bringup_emu_build.log 2>&1
    T=tinyoram_64; [ "$FREQ" = 300 ] || T=${T}_${FREQ}mhz; T=${T}_merge
    [ -f ${T}_hw_emu.xclbin ] && [ -x host_doma ] || { say "  FAIL  the emulation build ($V/bringup_emu_build.log)"; exit 1; }
    E="XCL_EMULATION_MODE=hw_emu DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=64 DOMA_PAGES_HBM=1"
    env $E DOMA_N=32 ./host_doma ${T}_hw_emu.xclbin 20 > bringup_emu_1.log 2>&1;                         check_run "e1 32 records, 20 commands" bringup_emu_1.log 20 "" 0 zero
    env $E DOMA_N=64 DOMA_PACK=1 ./host_doma ${T}_hw_emu.xclbin 20 > bringup_emu_2.log 2>&1;              check_run "e2 64 records packed 8 per block" bringup_emu_2.log 20 "" 0 zero
    env $E DOMA_N=32 DOMA_TINY_TOP=16384 ./host_doma ${T}_hw_emu.xclbin 20 > bringup_emu_3.log 2>&1;      check_run "e3 tree top 16 KB on-package" bringup_emu_3.log 20 "" 16384 some
    env $E DOMA_N=32 DOMA_TINY_TOP=all ./host_doma ${T}_hw_emu.xclbin 20 > bringup_emu_4.log 2>&1;        check_run "e4 whole tree on-package" bringup_emu_4.log 20 "" 49536 all
    say "  pass criterion: all four PASS. $([ $FAILED = 0 ] && echo 'PASSED: go on with  bash bringup_64.sh hw' || echo 'FAILED: send me the report and the named logs; the emulation log is under .run/*/hw_emu/device0/binary_0/behav_waveform/xsim/simulate.log')"
    exit $FAILED ;;
hw)
    tools; say "== 3.4 board build: merged adapter, tree in host memory, $FREQ MHz ($(date '+%F %T'))"; FAILED=0
    T=tinyoram_64; [ "$FREQ" = 300 ] || T=${T}_${FREQ}mhz; T=${T}_host_merge
    R=_x_$T/link/vivado/vpl/prj/prj.runs/impl_1; rm -f $R/post_place_timing.rpt
    setsid env SIZE=64 TARGET=hw MERGE=1 CFG=tinyoram_host.cfg FREQ=$FREQ bash build_tinyoram.sh > bringup_hw_build.log 2>&1 &
    pid=$!; pp=""; echo "  building (pid $pid; log $V/bringup_hw_build.log); the post-placement check runs by itself"
    while kill -0 $pid 2>/dev/null; do
        sleep 60
        if [ -z "$pp" ] && [ -f $R/post_place_timing.rpt ]; then
            pp=$(awk '/WNS\(ns\)/{getline; getline; print $1; exit}' $R/post_place_timing.rpt); [ -n "$pp" ] || continue
            cg=$(grep -A12 "Congestion" $R/post_place_congestion.rpt 2>/dev/null | grep -oE "Level [0-9]+" | awk '{print $2}' | sort -n | tail -1)
            say "  post-placement: WNS $pp ns, worst congestion level ${cg:-?}"
            if awk -v w="$pp" 'BEGIN{exit !(w < -0.5)}'; then
                kill -- -$pid 2>/dev/null; sleep 5; kill -9 -- -$pid 2>/dev/null
                say "  FAIL  post-placement WNS $pp ns < -0.5: stopped. Send me the report; then a lower FREQ (bash bringup_64.sh ooc with FREQ=...)"; exit 1
            fi
            [ -n "$cg" ] && [ "$cg" -ge 5 ] && say "  NOTE  congestion level $cg: send me $V/$R/post_place_congestion.rpt with the report"
        fi
    done
    wait $pid
    if [ ! -f ${T}_hw.xclbin ]; then say "  FAIL  the build ($V/bringup_hw_build.log)"; exit 1; fi
    grep -E "^final routed timing|^kernel clock in|^PASS: timing|^NOT AT|^FAIL" bringup_hw_build.log | sed 's/^/        /' >> "$REP"
    util=$(grep -E "tinyoram_kernel_1|u_tiny |u_adapt " $R/post_place_util_hier.rpt 2>/dev/null | head -3 | tr -s ' ' | cut -c1-130)
    [ -n "$util" ] && { say "        utilization after placement (kernel, core u_tiny, adapter u_adapt):"; echo "$util" | sed 's/^/          /' | tee -a "$REP"; }
    if grep -q "^PASS: timing closed" bringup_hw_build.log; then say "  PASS  timing closed at $FREQ MHz: ${T}_hw.xclbin. Go on with  bash bringup_64.sh card"
    elif grep -q "^NOT AT " bringup_hw_build.log; then say "  PASS (lower clock)  $(grep -m1 '^NOT AT' bringup_hw_build.log | cut -c1-90). Usable; go on with  bash bringup_64.sh card"
    else say "  FAIL  timing (see the lines above; $V/bringup_hw_build.log): do not use the xclbin"; exit 1; fi ;;
card)
    tools; say "== 3.5 runs on the card, tree in host memory ($(date '+%F %T'))"; FAILED=0
    T=tinyoram_64; [ "$FREQ" = 300 ] || T=${T}_${FREQ}mhz; T=${T}_host_merge; X=${T}_hw.xclbin
    [ -f $X ] || { say "  FAIL  no $X: run  bash bringup_64.sh hw  first"; exit 1; }
    E="DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=64"
    env $E DOMA_N=256 ./host_doma $X 5000 > bringup_card_1.log 2>&1;                    check_run "c1 256 records, 5,000 commands" bringup_card_1.log 5000 "query: 5000 commands (2546 GET, 2454 PUT)" 0 zero
    env $E DOMA_N=256 ./host_doma $X 100000 > bringup_card_2.log 2>&1;                  check_run "c2 256 records, 100,000 commands" bringup_card_2.log 100000 "query: 100000 commands (49992 GET, 50008 PUT)" 0 zero
    env $E DOMA_N=2048 DOMA_PACK=1 ./host_doma $X 5000 > bringup_card_3.log 2>&1;       check_run "c3 2,048 records packed 8 per block" bringup_card_3.log 5000 "query: 5000 commands (2546 GET, 2454 PUT)" 0 zero
    env $E DOMA_N=256 DOMA_TINY_TOP=16384 ./host_doma $X 5000 > bringup_card_4.log 2>&1; check_run "c4 tree top 16 KB in HBM, the rest in host memory" bringup_card_4.log 5000 "query: 5000 commands (2546 GET, 2454 PUT)" 16384 some
    env $E DOMA_N=256 DOMA_TINY_TOP=all ./host_doma $X 5000 > bringup_card_5.log 2>&1;  check_run "c5 whole tree in HBM" bringup_card_5.log 5000 "query: 5000 commands (2546 GET, 2454 PUT)" 49536 all
    env $E DOMA_N=256 ./host_doma $X 5000 > bringup_card_6.log 2>&1;                    check_run "c6 c1 again, back to back (a fresh ORAM)" bringup_card_6.log 5000 "query: 5000 commands (2546 GET, 2454 PUT)" 0 zero
    for i in 1 4 5; do grep -E "^latency spread|^traffic" bringup_card_$i.log | sed "s/^/        c$i: /" >> "$REP"; done
    grep -E "^kernel clock in" bringup_hw_build.log 2>/dev/null | tail -1 | sed 's/^/        /' >> "$REP"
    say "  pass criterion: all six PASS. $([ $FAILED = 0 ] && echo 'BRING-UP PASSED: the build queue (queue.sh start) may start' || echo 'FAILED: send me the report and the named logs')"
    exit $FAILED ;;
report) cat "$REP" ;;
*) sed -n '2,13p' "$0"; exit 1 ;;
esac
