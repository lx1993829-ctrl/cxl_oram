#!/bin/bash
# install_tinyoram.sh -- put the Tiny ORAM overlay on a DOMA package, check it, and make one copy per bitstream.
#
#   bash install_tinyoram.sh <fpga_zcu208_deploy.zip> <tinyoram_overlay.zip> [DEST]        (DEST default ~/tiny)
#   bash install_tinyoram.sh <base.zip> <overlay.zip> [DEST] --check     # also run all three regressions
#
# Leaves your own ~/fpga_zcu208 alone. Makes:
#   DEST/combined/fpga_zcu208     the base package with the overlay on it, manifest regenerated
#   DEST/bringup/fpga_zcu208      a copy for bringup_64.sh
#   DEST/q<id>_<name>/fpga_zcu208 a copy per build queue entry (tinyoram/card/queue.txt); fetch_tinyoram.sh
#                                 rewrites tinyoram/build/src in place, so no two builds may share a copy
# Steps, each of which stops the script on failure:
#   1. the base package's MANIFEST.sha256 must verify;
#   2. the overlay's Tiny ORAM files are copied in; the three shared files (vitis/host_doma.cpp, vitis/scan.sh,
#      sim/axi_mem_model.v) are replaced whole only if the base still has the version the overlay was made
#      from; otherwise the overlay's patch (docs/tinyoram_fair_shared_files.diff) is applied to the base's
#      version, and the script stops if it does not apply;
#   3. MANIFEST.sha256 is regenerated over the combined tree and verified;
#   4. with --check: DOMA's regression at 32 B and 4 KB (sim/run_verilator.sh), then run_tinyoram.sh and
#      run_tinyoram_mutants.sh; every one must end with its pass line (about 3 hours on two cores).
# Pass: the last line is "INSTALL OK" (with --check: "INSTALL OK, ALL REGRESSIONS PASSED").
set -u
BASE=${1:?usage: install_tinyoram.sh <base.zip> <overlay.zip> [DEST] [--check]}
OVL=${2:?usage: install_tinyoram.sh <base.zip> <overlay.zip> [DEST] [--check]}
DEST=${3:-$HOME/tiny}; [ "$DEST" = --check ] && DEST=$HOME/tiny
CHECK=0; for a in "$@"; do [ "$a" = --check ] && CHECK=1; done
BASE=$(readlink -f "$BASE"); OVL=$(readlink -f "$OVL")
die() { echo "INSTALL FAILED: $*"; exit 1; }
[ -f "$BASE" ] || die "no base package $BASE"; [ -f "$OVL" ] || die "no overlay $OVL"
# the shared files' versions in the base package this overlay was made from (fpga_zcu208_deploy.zip, 2026-10-18 14:48)
declare -A FROM=(
  [vitis/host_doma.cpp]=ede85e1d764be6ae3e034cb67c52b3fc3d15932eb709e1d7ba25c33524acf56a
  [vitis/scan.sh]=0eeebef9eaebb016c28ebe809a9a15fb4656492c470218dc3483755ba63f0652
  [sim/axi_mem_model.v]=bcf21dd3307f92736fe465cefbc343ce154fb9ad426621f0b870b7ee62a6ed14 )

C=$DEST/combined
[ -e "$C" ] && die "$C exists: remove it (or choose another DEST) first"
mkdir -p "$C" || die "cannot create $C"
echo "== 1. base package: $BASE"
unzip -q "$BASE" -d "$C" || die "unzip of the base package failed"
[ -f "$C/fpga_zcu208/MANIFEST.sha256" ] || die "the base package has no fpga_zcu208/MANIFEST.sha256"
( cd "$C/fpga_zcu208" && sha256sum -c --quiet MANIFEST.sha256 ) || die "the base package's manifest does not verify"
echo "   manifest verified ($(wc -l < "$C/fpga_zcu208/MANIFEST.sha256") files)"

echo "== 2. overlay: $OVL"
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
unzip -q "$OVL" -d "$T" || die "unzip of the overlay failed"
R=$T; [ -d "$T/fpga_zcu208" ] && R=$T/fpga_zcu208
( cd "$R" && find . -type f ! -name MANIFEST.sha256 | sed 's#^\./##' ) | while read -r f; do
    [ -n "${FROM[$f]:-}" ] && continue
    mkdir -p "$C/fpga_zcu208/$(dirname "$f")" && cp -p "$R/$f" "$C/fpga_zcu208/$f" || exit 1
done || die "copying the overlay failed"
for f in "${!FROM[@]}"; do
    have=$(sha256sum "$C/fpga_zcu208/$f" 2>/dev/null | cut -d' ' -f1)
    if [ "$have" = "${FROM[$f]}" ]; then cp -p "$R/$f" "$C/fpga_zcu208/$f"; echo "   $f: the base has the version the overlay was made from: replaced"
    else
        echo "   $f: the base's version is newer than the overlay's base: applying the overlay's patch to it"
        ( cd "$C/fpga_zcu208" && awk -v f="a/$f" '/^diff /{p=0} /^--- /{p=($2==f)} p' docs/tinyoram_fair_shared_files.diff > "$T/one.diff" \
            && [ -s "$T/one.diff" ] && patch -p1 --forward --no-backup-if-mismatch -s < "$T/one.diff" ) \
            || die "the patch for $f does not apply to this base: send me this base package"
    fi
done
chmod +x "$C"/fpga_zcu208/sim/*.sh "$C"/fpga_zcu208/vitis/*.sh "$C"/fpga_zcu208/tinyoram/*.sh "$C"/fpga_zcu208/tinyoram/card/*.sh 2>/dev/null

echo "== 3. manifest"
( cd "$C/fpga_zcu208" && find . -type f ! -name MANIFEST.sha256 | sort | xargs sha256sum > MANIFEST.sha256 && sha256sum -c --quiet MANIFEST.sha256 ) \
    || die "the regenerated manifest does not verify"
echo "   regenerated and verified ($(wc -l < "$C/fpga_zcu208/MANIFEST.sha256") files)"

echo "== copies, one per bitstream"
mk() { [ -e "$DEST/$1" ] && { echo "   $DEST/$1 exists: kept"; return; }; mkdir -p "$DEST/$1" && cp -a "$C/fpga_zcu208" "$DEST/$1/" && echo "   $DEST/$1/fpga_zcu208"; }
mk bringup
[ -f "$C/fpga_zcu208/tinyoram/card/queue.txt" ] || die "the overlay has no tinyoram/card/queue.txt"
while read -r id name rest; do case "$id" in ''|\#*) continue ;; esac; mk "q${id}_$name"; done < "$C/fpga_zcu208/tinyoram/card/queue.txt"

if [ $CHECK = 1 ]; then
    echo "== 4. regressions on the combined tree (logs in $DEST/check_*.log)"
    S=$C/fpga_zcu208/sim; ok=1
    ( cd "$S" && ORAM_BEATS=1 bash run_verilator.sh ) > "$DEST/check_doma32.log" 2>&1; tail -1 "$DEST/check_doma32.log" | grep -q "ALL CHECKS PASSED" && echo "   DOMA 32 B: ALL CHECKS PASSED" || { echo "   DOMA 32 B: FAILED"; ok=0; }
    grep -oE "trace-hash=[0-9a-f]{16}" "$DEST/check_doma32.log" | sort -u | sed 's/^/     /'
    ( cd "$S" && rm -rf build && bash run_verilator.sh ) > "$DEST/check_doma4k.log" 2>&1; tail -1 "$DEST/check_doma4k.log" | grep -q "ALL CHECKS PASSED" && echo "   DOMA 4 KB: ALL CHECKS PASSED" || { echo "   DOMA 4 KB: FAILED"; ok=0; }
    grep -oE "trace-hash=[0-9a-f]{16}" "$DEST/check_doma4k.log" | sort -u | sed 's/^/     /'
    ( cd "$S" && bash ../tinyoram/fetch_tinyoram.sh 4k > /dev/null && bash run_tinyoram.sh ) > "$DEST/check_tinyoram.log" 2>&1
    tail -1 "$DEST/check_tinyoram.log" | grep -q "ALL CHECKS PASSED" && echo "   Tiny ORAM: $(grep -c '  PASS' "$DEST/check_tinyoram.log") checks, ALL CHECKS PASSED" || { echo "   Tiny ORAM: FAILED"; ok=0; }
    ( cd "$S" && bash run_tinyoram_mutants.sh ) > "$DEST/check_mutants.log" 2>&1
    grep -q "MUTANT CHECKS CAUGHT" "$DEST/check_mutants.log" && echo "   $(grep 'MUTANT CHECKS CAUGHT' "$DEST/check_mutants.log")" || { echo "   mutation checks: FAILED"; ok=0; }
    [ $ok = 1 ] && { echo "INSTALL OK, ALL REGRESSIONS PASSED"; exit 0; } || die "a regression failed (logs in $DEST/check_*.log)"
fi
echo "INSTALL OK"
