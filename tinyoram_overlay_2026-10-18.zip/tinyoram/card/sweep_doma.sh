#!/bin/bash
# sweep_doma.sh -- DOMA's card sweeps with the same settings as sweep_tiny.sh, through the same scan.sh and host.
#
#   bash sweep_doma.sh <DOMA 32 B xclbin> [<DOMA 4 KB xclbin>]
#   CMDS=20000 (default); NS32, NS4K override the record counts (they must match sweep_tiny.sh's builds)
#
# 32 B bitstream: DOMA_PACK=1 (4 records per 32-byte block), NS="100000 1000000 10000000", HBMS="0 20 50 100".
#   At 10M records that is 2.5M blocks: the bitstream's NMAX must be at least that (4M in your current build).
# 4 KB bitstream (optional): unpacked, NS="16384 65536", the same HBMS: the 4 KB comparison.
# It runs the host program of this package copy (the combined tree: DOMA's current host plus the Tiny ORAM additions),
# built here if missing, with DOMA_PLACEMENT=1 and DOMA_LAT_HIST=1, which add DOMA's placement and latency spread to
# the logs without changing anything else. The xclbins stay where they are; they must be built from the same DOMA
# package version as this copy's base (the host's LAMBDA, Z and buffer layout must match the bitstream).
# Output: DEST/results/doma_32B.csv, doma_4k.csv and .log; DEST/results/clocks.txt gets each kernel clock.
# Pass: every row has a KQPS value, errors 0x0, bad 0.
set -u
X32=$(readlink -f "${1:?usage: sweep_doma.sh <doma 32 B xclbin> [<doma 4 KB xclbin>]}"); X4K=${2:+$(readlink -f "$2")}
CARD=$(cd "$(dirname "$0")" && pwd)
PKG=$(cd "$CARD/../.." && pwd)
DEST=${DEST:-$(dirname "$(dirname "$PKG")")}
RES=$DEST/results; mkdir -p "$RES"; CMDS=${CMDS:-20000}
XRT_SETUP=${XRT_SETUP:-/opt/xilinx/xrt/setup.sh}
command -v xclbinutil > /dev/null || source "$XRT_SETUP" > /dev/null 2>&1
cd "$PKG/vitis" || exit 2
if [ ! -x host_doma ] || [ host_doma.cpp -nt host_doma ]; then
    g++ -std=c++17 -O2 host_doma.cpp -I$XILINX_XRT/include -L$XILINX_XRT/lib -lxrt_coreutil -pthread -o host_doma || exit 2
fi
clk() { xclbinutil --info -i "$1" 2>/dev/null | awk '/Name:.*DATA_CLK/{f=1} f && /Frequency:/{print $2; exit}'; }
fail=0
one() {   # one <xclbin> <tag> <block> <pack 0|1> <NS>
    local env=(SCAN_LOG=1 DOMA_PLACEMENT=1 DOMA_LAT_HIST=1 DOMA_BLOCK=$3 NS="$5" HBMS="0 20 50 100" OUT=$RES/doma_$2.csv)
    [ "$4" = 1 ] && env+=(DOMA_PACK=1)
    echo "== DOMA $2: $(basename "$1"), N=$5, $CMDS commands"
    env "${env[@]}" bash scan.sh "$1" $CMDS
    echo "doma $2 $(basename "$1") $(clk "$1")" >> "$RES/clocks.txt"
    awk -F, 'NR > 1 && ($4 == "" || $9 != "0x0" || $10 != "0") {bad = 1} END {exit bad}' "$RES/doma_$2.csv" \
        && echo "   PASS: every row measured, errors 0x0, all responses correct" || { echo "   FAIL: see $RES/doma_$2.log"; fail=1; }
    grep -q "^WARNING: doma_onpkg_bytes" "$RES/doma_$2.log" && { echo "   FAIL: the matched-budget sizes differ from this host's DOMA buffers (see the log)"; fail=1; }
}
one "$X32" 32B 32 1 "${NS32:-100000 1000000 10000000}"
[ -n "$X4K" ] && one "$X4K" 4k 4096 0 "${NS4K:-16384 65536}"
exit $fail
