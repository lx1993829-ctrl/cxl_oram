#!/bin/bash
# scan.sh -- DOMA throughput and latency over N and the HBM share, one CSV row per run.
#   bash scan.sh doma_hw.xclbin [commands]          (run in the directory with host_doma)
#   NS="65536 262144 1048576" HBMS="0 20 50" bash scan.sh doma_hw.xclbin 20000
# N is in records (DOMA_N); each must be at most the build's NMAX. Every response is verified by host_doma.
# Tiny ORAM (DOMA_KERNEL=tinyoram_kernel): the same columns, from the same host and command stream.
#   DOMA_KERNEL=tinyoram_kernel DOMA_PACK=1 NS=1000000 bash scan.sh tinyoram_64_n1000000_p8_host_merge_hw.xclbin 20000
#   NS must be the bitstream's own record count (Tiny ORAM's tree depth is fixed per build). In place of the
#   HBM share it sweeps the tree-top setting TOPS (DOMA_TINY_TOP), written to the hbm_pct column:
#     0         the whole tree in pages (host memory with tinyoram_host.cfg): the comparison with DOMA at 0% HBM
#     doma:<p>  the bytes doma_kernel keeps on-package at <p>% HBM for the same records (DOMA_MATCH_BLOCK, default
#               32-byte blocks): the matched budgets. With DOMA_TINY_FLATPM=1 (a FLATPM=1 build) the on-chip
#               position map is taken off the top.
#     <bytes>, all   a top of that many bytes, or the whole tree on-package
#   Default TOPS="0 doma:0 doma:20 doma:100". Each run's full output (latency spread, placement) goes to <OUT>.log.
KER=${DOMA_KERNEL:-doma_kernel}
if [ "$KER" = tinyoram_kernel ]; then
    [ -n "${NS:-}" ] || { echo "Tiny ORAM: set NS to the bitstream's record count (DOMA_N), e.g. NS=1000000"; exit 1; }
    export DOMA_KERNEL
fi
X=${1:?usage: scan.sh <xclbin> [commands]}; C=${2:-20000}
NS=${NS:-"16384 65536 262144 1048576 4194304"}
HBMS=${HBMS:-"0 10 20 30 50 100"}
OUT=${OUT:-scan_$(basename $X .xclbin)_$(date +%m%d%H%M).csv}
[ "$KER" = tinyoram_kernel ] && { HBMS=${TOPS:-"0 doma:0 doma:20 doma:100"}; LOG=${OUT%.csv}.log; : > $LOG; }
# SCAN_LOG=1 keeps doma_kernel's full output too (<OUT>.log), e.g. with DOMA_PLACEMENT=1 DOMA_LAT_HIST=1
[ "$KER" != tinyoram_kernel ] && [ -n "${SCAN_LOG:-}" ] && { LOG=${OUT%.csv}.log; : > $LOG; }
# the block size: host_doma sizes its buffers by DOMA_BLOCK (default 4096); a probe run reports the kernel's own
if [ -z "${DOMA_BLOCK:-}" ]; then
    b=$(DOMA_N=1024 ./host_doma $X 10 2>&1 | grep -oE "set DOMA_BLOCK=[0-9]+" | head -1 | cut -d= -f2)
    if [ -n "$b" ]; then export DOMA_BLOCK=$b; echo "the kernel's block is $b bytes: DOMA_BLOCK=$b"; fi
fi
echo "n,hbm_pct,commands,kqps,device_cycles,lat_min_cyc,lat_max_cyc,completed,errors,bad,pool,init_s,note" > $OUT
for n in $NS; do for h in $HBMS; do
    if [ "$KER" = tinyoram_kernel ]; then
        log=$(DOMA_N=$n DOMA_TINY_TOP=$h ./host_doma $X $C 2>&1)
        { echo "==== N=$n DOMA_TINY_TOP=$h"; echo "$log"; } >> $LOG
    else
    log=$(DOMA_N=$n DOMA_HBM_PCT=$h ./host_doma $X $C 2>&1)
    [ -n "${SCAN_LOG:-}" ] && { echo "==== N=$n DOMA_HBM_PCT=$h"; echo "$log"; } >> $LOG
    fi
    kq=$(echo "$log" | awk '/^query:/{print $(NF-1)}')
    dev=$(echo "$log" | awk '/^device:/{gsub(/\.\./," "); gsub(/,/,""); print $2","$7","$8","$11","$13}')
    bad=$(echo "$log" | grep -cE "bad header|wrong data")
    pool=$(echo "$log" | awk '/^stash pool:/{print $3}')
    init=$(echo "$log" | awk '/^init:/{print $2}')
    note=""; [ -z "$kq" ] && note=$(echo "$log" | grep -m1 -iE "error|must|fail|exceed|could not" | tr ',' ';' | cut -c1-120)
    echo "$n,$h,$C,${kq:-},${dev:-,,,,},$bad,${pool:-},${init:-},$note" >> $OUT
    if [ "$KER" = tinyoram_kernel ]; then
        printf "N=%-8s top=%-9s %s KQPS  %s\n" "$n" "$h" "${kq:-FAILED}" "${note:-$(echo "$log" | grep -m1 '^placement:' | cut -c1-110)}"
    else
    printf "N=%-8s HBM=%3s%%  %s KQPS  %s\n" "$n" "$h" "${kq:-FAILED}" "${note:-$(echo "$log" | grep -m1 '^device:' | cut -c1-90)}"
    fi
done; done
echo "written $OUT"
[ -n "${LOG:-}" ] && echo "written $LOG (each run's full output: latency spread, histogram, placement, traffic)"
