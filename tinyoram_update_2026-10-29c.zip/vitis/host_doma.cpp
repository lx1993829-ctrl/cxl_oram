// host_doma.cpp -- XRT host program for doma_kernel, built to match BOLT's benchmark host
// (BOLT-benchmark/BOLT/*/host.cpp) so the two are measured the same way:
//   * same workload generator: std::mt19937 seed 1, 50% PUT, keys uniform over the dataset,
//     VALUE_SIZE random bytes per PUT (DOMA stores them at the start of a 4 KB block)
//   * keys are dense: key index i is DOMA slot i (BOLT looks keys up through its hash map)
//   * commands are converted and copied to the card BEFORE timing starts, as BOLT does
//   * query time = one kernel launch processing all CMD_SIZE commands, plus wait()
//   * init time = boot run (key load, bucket layout, lease) + preloading every slot,
//     the analogue of BOLT's data preparation and loading
// Usage: ./host_doma <xclbin> [CMD_SIZE] [--kernel NAME]
//   NAME (or DOMA_KERNEL=NAME): doma_kernel (default) or tinyoram_kernel, the Tiny ORAM baseline.
//   Everything else -- generator, seeds, preload counted as initialization, the timed region of one
//   launch plus wait(), the DOMA_* variables -- is the same for both kernels. For tinyoram_kernel:
//     DOMA_N      records; must match the bitstream's tree (Tiny ORAM's depth is fixed per build:
//                 N = 4 * 2^L blocks, L >= 6 the smallest with 4 * 2^L >= blocks, as build_tinyoram.sh picks it);
//                 default: the bitstream's N
//     DOMA_BLOCK  Tiny ORAM's block size in bytes (64, 128, 256 or 4096), used to size the command, response
//                 and tree buffers before the first launch (default 4096, which also covers the smaller builds)
//     DOMA_PACK   as for DOMA: BLOCK / 8 records per block (offset and length in the command header,
//                 written through Tiny ORAM's byte write mask); DOMA_N records then need N/(BLOCK/8) blocks
//     DOMA_TINY_TOP  bytes of the tree's top kept on-package (the `top` buffer, HBM): Tiny ORAM's tree-top
//                 cache, to match DOMA's on-package budget. 0 (default) = the whole tree in `pages`;
//                 "all" or >= the tree size = the whole tree on-package; otherwise rounded down to 4 KB.
//                 "doma:<pct>" = the bytes doma_kernel keeps on-package for the same DOMA_N records at
//                 DOMA_HBM_PCT=<pct>: its position map, bucket records, stash and HBM buckets, sized as this
//                 host sizes them for doma_kernel, with DOMA_MATCH_BLOCK-byte blocks (default 32) packed as
//                 DOMA_PACK says. With DOMA_TINY_FLATPM=1 (a build_tinyoram.sh FLATPM=1 bitstream) the 8 bytes
//                 per block of Tiny ORAM's on-chip position map are trusted on-package bytes too, and are
//                 taken off the matched top
//   Tiny ORAM launches with 6 arguments (cmd, resp, pages, size, top, top_bytes) and needs no metadata
//   buffers. Its latency figures: primary (summary min/max) = last write-back beat handed off, as DOMA's
//   arrival mode; also data ready and write-back acknowledged, and the spread of the primary figure.
//   DOMA_LAT_HIST=1 prints the same spread for doma_kernel.
//   Large CMD_SIZE (tinyoram_kernel only): the command and response buffers hold 32 bytes plus one block-sized slot per
//   command and each sits in one 512 MB HBM bank, so from 512-byte blocks up 1M commands do not fit one launch. Then the
//   query runs as back-to-back launches on the same ORAM, each of at most DOMA_BATCH commands (default: as many as fit
//   DOMA_BUF_MAX bytes per buffer, default 480 MiB). The command stream is generated once, as for one launch; each batch
//   is copied to the card before its launch, and the timed region is each launch + wait(), summed (copies between
//   launches not timed). Every response is verified; the latency figures and counters cover all commands. A run that
//   fits one launch is unchanged.
#include <xrt/xrt_bo.h>
#include <xrt/xrt_device.h>
#include <xrt/xrt_kernel.h>
#include <algorithm>
#include <cmath>
#include <vector>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <initializer_list>
#include <random>
#include <string>
#include <vector>

// must match the hardware build (rtl/oram_params.vh, single-client default)
// run-time size (DOMA_N=<records>): n blocks in NB = ceil(n / LAMBDA) buckets, passed to the kernel as nblk
// (the build's maximum is rtl/oram_params.vh ORAM_N; build.sh NMAX=...). Default: 256 blocks, as before.
static const uint32_t LAMBDA     = 8;                // rtl/oram_params.vh ORAM_C
static const uint32_t ZPOS       = 10;               // rtl/oram_params.vh ORAM_Z

// Stash pool size: Claim 1 of the stash analysis (docs/stash_chain_design.md). The stash exceeds xR + xO with
// probability at most gamma = 2^-64 per access, for every access sequence (Chernoff bounds over negatively
// associated per-bucket terms; the best split of gamma between the two terms).
static double ln_mgf_A(double t, double Bk, double n) {     // ln E[e^{tA}], P(A >= i) = (1 - 1/B)^i, A capped at n
    const double p = 1.0 / Bk, lr = std::log1p(-p) + t;
    if (std::fabs(lr) < 1e-15) return std::log(p * n + 1.0);
    if (lr > 0) { const double lrn = n * lr; if (lrn > 700) return INFINITY;
                  return std::log(p * std::expm1(lrn) / std::expm1(lr) + std::exp(lrn)); }
    const double rn = std::exp(n * lr);
    return std::log(p * (1 - rn) / (-std::expm1(lr)) + rn);
}
static double stash_xR(double Bk, double n, double lg) {   // lg = ln(1 / gamma_R)
    double best = INFINITY;
    for (int i = 1; i < 400; i++) { const double u = i * 0.005, v = ln_mgf_A(std::expm1(u) / Bk, Bk, n);
        if (!std::isfinite(v)) break; best = std::min(best, (Bk * v + lg) / u); }
    return best;
}
static double stash_xO(double Bk, double lam, int Z, double lg) {
    double best = INFINITY; std::vector<double> lt(160);
    for (int i = 1; i < 400; i++) { const double u = i * 0.01; double mx = -INFINITY, sum = 0;
        for (int k = 0; k < 160; k++) { lt[k] = -lam + k * std::log(lam) - std::lgamma(k + 1.0) + u * std::max(0, k - Z); mx = std::max(mx, lt[k]); }
        for (int k = 0; k < 160; k++) sum += std::exp(lt[k] - mx);
        best = std::min(best, (Bk * (mx + std::log(sum)) + lg) / u); }
    return best;
}
static double stash_bound(double n, double lam, int Z) {
    const double Bk = std::ceil(n / lam), G = 64 * std::log(2.0);
    double best = INFINITY;
    for (double f : {0.1, 0.3, 0.5, 0.7, 0.9})
        best = std::min(best, stash_xR(Bk, n, G - std::log(f)) + stash_xO(Bk, lam, int(Z), G - std::log(1 - f)));
    return best;
}
static uint32_t       NBLK       = 256;              // blocks (slots)
static uint32_t       NB         = 64;               // buckets
static const size_t   MAX_BLOCK  = 4096;             // largest block (4 KB); buffers are sized for it
static size_t         BLOCK      = 4096;             // bytes per slot: the kernel reports its own after boot
static const size_t   BUCKET_STRIDE = 32768;         // bucket spacing in DOMA's memory map
static const int      VALUE_SIZE = 8;                // BOLT's default value size (bytes)
static uint32_t       PACK       = 1;                // records per block: 1, or BLOCK / VALUE_SIZE with DOMA_PACK=1
static uint32_t       NKEYS      = 256;              // keys (records); slots x records per block by default
static const uint8_t  T_GET = 0x01, T_PUT = 0x02, T_ACK = 0x10, T_SUM = 0x5A;

static size_t roundup4k(size_t x) { return (x + 4095) & ~size_t(4095); }

struct Cmd { uint8_t type; uint32_t key; uint8_t value[VALUE_SIZE]; };

// BOLT's generate_uniform_commands(), with the key index used directly as the key
static std::vector<Cmd> generate_uniform_commands(int size) {
    std::vector<Cmd> cmds;
    uint32_t seed = 1;
    std::mt19937 gen(seed);
    std::uniform_real_distribution<double> op_dis(0.0, 1.0);
    std::uniform_int_distribution<int> key_dis(0, NKEYS - 1);
    std::uniform_int_distribution<int> value_dis(0, 255);
    for (int i = 0; i < size; i++) {
        Cmd c{};
        double rw = op_dis(gen);
        c.key = key_dis(gen);
        if (rw < 0.5) { c.type = T_PUT; for (int j = 0; j < VALUE_SIZE; j++) c.value[j] = (uint8_t)value_dis(gen); }
        else c.type = T_GET;
        cmds.push_back(c);
    }
    return cmds;
}

struct Buffers {
    xrt::bo cmd, resp, pages, meta, brec, stash;   // meta: position map; brec: bucket records; stash (all in HBM)
    xrt::bo pages_hbm;                             // DOMA: buckets kept in HBM (DOMA_HBM_PCT, fixed boundary)
    xrt::bo top;                                   // tinyoram_kernel: the tree top (HBM)
    size_t hc = 0, hr = 0;
};

// lay commands out as doma_kernel expects: 32-byte headers, then PUT data on 4 KB boundaries
static void stage(Buffers& b, const std::vector<Cmd>& cmds) {
    size_t n = cmds.size();
    b.hc = roundup4k(n * 32);
    b.hr = roundup4k((n + 2) * 32);                   // after records [n] (summary) and [n+1] (traffic)
    auto p = b.cmd.map<uint8_t*>();
    std::memset(p, 0, b.hc + n * BLOCK);
    for (size_t i = 0; i < n; i++) {
        // key k is record k % PACK of block k / PACK; a packed PUT writes only its record
        // (offset and length in header bytes 8-15); unpacked commands use length 0 (whole block)
        uint32_t slot = cmds[i].key / PACK, off = (cmds[i].key % PACK) * VALUE_SIZE;
        uint32_t len  = (PACK > 1) ? uint32_t(VALUE_SIZE) : 0u;
        p[i * 32] = cmds[i].type;
        std::memcpy(p + i * 32 + 4, &slot, 4);
        std::memcpy(p + i * 32 + 8, &off, 4);
        std::memcpy(p + i * 32 + 12, &len, 4);
        if (cmds[i].type == T_PUT) std::memcpy(p + b.hc + i * BLOCK + off, cmds[i].value, VALUE_SIZE);
    }
    b.cmd.sync(XCL_BO_SYNC_BO_TO_DEVICE, b.hc + n * BLOCK, 0);
}

struct Summary { uint64_t total, rd_beats, wr_beats; uint32_t beats, lat_min, lat_max, errors, done; bool ok, traffic;
                 uint32_t geo_n; size_t geo_tree;      // tinyoram_kernel only: traffic-record bytes 24-27 blocks, 28-31 tree (64-byte bursts)
                 uint32_t rt_l = 0, rt_lmax = 0, rt_lmin = 0;   // tinyoram_kernel with a run-time depth: summary bytes 1-3 (0 otherwise)
                 uint64_t top_rd64, top_wr64; };       // tinyoram_kernel only: bytes 1-7, the top port's share (64-byte units)

static Summary read_summary(Buffers& b, size_t n) {
    // at least through the summary record itself (b.hr is 0 before the first stage())
    b.resp.sync(XCL_BO_SYNC_BO_FROM_DEVICE, std::max(b.hr + n * BLOCK, (n + 2) * size_t(32)), 0);
    auto r = b.resp.map<uint8_t*>() + n * 32;
    Summary s{};
    s.ok = (r[0] == T_SUM);
    s.rt_l = r[1]; s.rt_lmax = r[2]; s.rt_lmin = r[3];   // 0 except from a run-time-depth tinyoram_kernel
    std::memcpy(&s.beats, r + 4, 4);   // block size in beats (0 from bitstreams before this field)
    std::memcpy(&s.total, r + 8, 8);   std::memcpy(&s.lat_min, r + 16, 4); std::memcpy(&s.lat_max, r + 20, 4);
    std::memcpy(&s.errors, r + 24, 4); std::memcpy(&s.done, r + 28, 4);
    // record [n+1]: traffic on the bucket port during the launch (0x5B; absent from older bitstreams)
    s.traffic = (r[32] == 0x5B);
    if (s.traffic) { std::memcpy(&s.rd_beats, r + 40, 8); std::memcpy(&s.wr_beats, r + 48, 8);
                     uint32_t gt; std::memcpy(&s.geo_n, r + 56, 4); std::memcpy(&gt, r + 60, 4); s.geo_tree = size_t(gt) * 64;
                     uint64_t tb = 0; std::memcpy(&tb, r + 32, 8); s.top_rd64 = (tb >> 8) & 0xFFFFFFFull; s.top_wr64 = (tb >> 36) & 0xFFFFFFFull; }
    return s;
}

// Tiny ORAM's tree span in bytes for a block of `block` bytes and depth L (ORAML), Z = 4, PMMAC on:
// the formulas of its include/BucketLocal.vh (buckets of 64-byte bursts, subtree layout per DDR3 row)
static size_t tinyoram_tree_bytes(size_t block, unsigned L) {
    const unsigned Z = 4, U = 32, E = 64, H = 128;
    unsigned hdr = E + 8 * ((Z + 7) / 8) + U * Z + L * Z + H * Z;                // header bits
    size_t bkt = (hdr + 511) / 512 + Z * ((block * 8 + 511) / 512);             // bucket, in 64-byte bursts
    size_t words = bkt * 8, x = 8192 / words + 1;
    unsigned lst = 0; while ((size_t(2) << lst) <= x) lst++;                      // log2 floor
    if (lst == 0) lst = 1;
    unsigned nst = (L + 1 + lst - 1) / lst;
    size_t tot = ((size_t(1) << (nst * lst)) - 1) / ((size_t(1) << lst) - 1);
    return 64 * ((size_t(1) << (L + 1)) + tot) * bkt;
}
static unsigned tinyoram_depth(size_t blocks) { unsigned L = 6; while ((size_t(4) << L) < blocks) L++; return L; }

// doma_kernel's on-package (HBM) bytes for `nrec` records of VALUE_SIZE bytes in `block`-byte blocks (`pack`
// per block) at an HBM share of `pct`: the same sizes main() gives its meta, brec, stash and pages_hbm buffers
static size_t doma_onpkg_bytes(size_t nrec, size_t block, uint32_t pack, unsigned pct) {
    const uint32_t nblk = uint32_t((nrec + pack - 1) / pack), nb = (nblk + LAMBDA - 1) / LAMBDA;
    const double bnd = stash_bound(double(nblk), double(LAMBDA), int(ZPOS));
    uint32_t pool = uint32_t(std::min<double>(nblk, std::ceil(bnd) + std::ceil(0.01 * nblk) + 64));
    if (std::getenv("DOMA_POOL")) pool = uint32_t(std::min<unsigned long>(nblk, std::stoul(std::getenv("DOMA_POOL"))));
    const uint32_t hbmk = uint32_t((uint64_t(nb) * pct) / 100);
    const size_t meta  = std::max<size_t>(4096, ((size_t(nblk) + 4) / 5) * 32);
    const size_t brec  = std::max<size_t>(4096, size_t(nb) * 64);
    const size_t stash = roundup4k(size_t(nb) * 64) + roundup4k(size_t(pool) * 16) + size_t(pool) * block;
    return meta + brec + stash + size_t(hbmk) * ZPOS * block;
}

int main(int argc, char** argv) {
    if (argc < 2) { std::printf("usage: %s <xclbin> [CMD_SIZE] [--kernel doma_kernel|tinyoram_kernel]\n", argv[0]); return 1; }
    int CMD_SIZE = 5000;                                                   // BOLT: 5000
    std::string kname = std::getenv("DOMA_KERNEL") ? std::getenv("DOMA_KERNEL") : "doma_kernel";
    for (int a = 2; a < argc; a++) {
        std::string o = argv[a];
        if (o == "--kernel" && a + 1 < argc) kname = argv[++a];
        else if (a == 2 && !o.empty() && o[0] != '-') CMD_SIZE = std::stoi(o);
        else { std::printf("unknown argument %s\n", o.c_str()); return 1; }
    }
    const bool TINY = (kname == "tinyoram_kernel");
    if (!TINY && kname != "doma_kernel") { std::printf("unknown kernel %s (doma_kernel or tinyoram_kernel)\n", kname.c_str()); return 1; }
    auto device = xrt::device(0);
    auto uuid   = device.load_xclbin(argv[1]);
    auto krnl   = xrt::kernel(device, uuid, kname);

    // size: DOMA_BLOCK (bytes, default 4 KB) sizes the buffers before boot; checked against the kernel after
    const size_t BLOCKA = std::getenv("DOMA_BLOCK") ? std::stoul(std::getenv("DOMA_BLOCK")) : MAX_BLOCK;
    if (BLOCKA < 32 || BLOCKA > MAX_BLOCK || (BLOCKA & (BLOCKA - 1))) { std::printf("DOMA_BLOCK must be a power of two, 32..4096\n"); return 1; }
    const uint32_t pack_a = std::getenv("DOMA_PACK") ? uint32_t(BLOCKA / VALUE_SIZE) : 1u;
    if (std::getenv("DOMA_N")) {
        NKEYS = uint32_t(std::stoul(std::getenv("DOMA_N")));
        NBLK  = (NKEYS + pack_a - 1) / pack_a;
    }
    NB = (NBLK + LAMBDA - 1) / LAMBDA;
    const size_t stride = size_t(ZPOS) * BLOCKA;                              // compact layout: exactly Z blocks per bucket
    // stash pool: Claim 1's bound at 2^-64 per access, plus a margin for the window effect (PROVISIONAL: 1% of n
    // + 64, until its formal derivation); never more than n. DOMA_POOL=<entries> overrides it.
    const double pool_bnd = stash_bound(double(NBLK), double(LAMBDA), int(ZPOS));
    uint32_t POOL = uint32_t(std::min<double>(NBLK, std::ceil(pool_bnd) + std::ceil(0.01 * NBLK) + 64));
    if (std::getenv("DOMA_POOL")) POOL = uint32_t(std::min<unsigned long>(NBLK, std::stoul(std::getenv("DOMA_POOL"))));
    // Tiny ORAM: its tree for the requested size (the bitstream reports the real one at init; checked below)
    const unsigned tiny_L = tinyoram_depth(NBLK);
    // DOMA_HBM_PCT: the percentage of buckets kept in HBM (fixed boundary: buckets 0 .. HBMK-1), the rest in pages
    const unsigned hbm_pct = std::getenv("DOMA_HBM_PCT") ? unsigned(std::stoul(std::getenv("DOMA_HBM_PCT"))) : 0u;
    if (hbm_pct > 100) { std::printf("DOMA_HBM_PCT must be 0..100\n"); return 1; }
    if (TINY && hbm_pct) { std::printf("DOMA_HBM_PCT is for doma_kernel only\n"); return 1; }
    const uint32_t HBMK = uint32_t((uint64_t(NB) * hbm_pct) / 100);
    const size_t pages_bytes = TINY ? roundup4k(tinyoram_tree_bytes(BLOCKA, tiny_L))
                                    : size_t(NB - HBMK) * stride + 4096;      // + up to 4 KB: the kernel rebases by a 4 KB multiple
    if (TINY) std::printf("size: %u blocks, Tiny ORAM tree for L=%u (N=%u), %zu-byte blocks: %zu bytes\n",
                          NBLK, tiny_L, 4u << tiny_L, BLOCKA, pages_bytes);
    if (!TINY) std::printf("stash pool: %u entries (Claim 1 bound %.0f at 2^-64 per access, + window margin)%s\n", POOL, pool_bnd,
                           std::getenv("DOMA_POOL") ? " [DOMA_POOL]" : "");
    if (TINY) {} else std::printf("size: %u blocks (nblk), %u buckets (%u in HBM = %u%%, %u in pages), buffers sized for %zu-byte blocks\n",
                     NBLK, NB, HBMK, hbm_pct, NB - HBMK, BLOCKA);
    // commands per launch: all of them, unless (tinyoram_kernel) the buffers would not fit one HBM bank, or the card
    // refuses buffers that large: each card buffer is backed by pinned host memory, and a run refused at a size retries
    // with half the buffer (half the commands per launch), down to 16 MiB
    size_t batch = CMD_SIZE, max_cmds = 0;
    size_t bufmax = std::getenv("DOMA_BUF_MAX") ? std::stoull(std::getenv("DOMA_BUF_MAX")) : (size_t(480) << 20);
    Buffers b;
    for (;;) {
        batch = CMD_SIZE;
        size_t cap = SIZE_MAX;
        if (TINY) {
            cap = std::max<size_t>(1, (bufmax > 8192 ? bufmax - 8192 : 0) / (32 + BLOCKA));
            if (std::getenv("DOMA_BATCH")) batch = std::min<size_t>(batch, std::max<size_t>(1, std::stoull(std::getenv("DOMA_BATCH"))));
            if (batch > cap) batch = cap;
        }
        max_cmds = std::max<size_t>(batch, std::min<size_t>({size_t(NBLK), size_t(5000), cap}));   // the preload's batches too
        try {
            b.cmd   = xrt::bo(device, roundup4k(max_cmds * 32) + max_cmds * BLOCKA, krnl.group_id(0));
            b.resp  = xrt::bo(device, roundup4k((max_cmds + 2) * 32) + max_cmds * BLOCKA, krnl.group_id(1));
            break;
        } catch (const std::exception& e) {
            const size_t want = roundup4k((max_cmds + 2) * 32) + max_cmds * BLOCKA;
            if (!TINY || bufmax <= (size_t(16) << 20)) {
                std::printf("cannot allocate the command/response buffers (%zu B each): %s\n", want, e.what()); return 1; }
            std::printf("the card refused command/response buffers of %zu B each (%s): retrying with half\n", want, e.what());
            b.cmd = xrt::bo(); b.resp = xrt::bo();
            bufmax = std::min(bufmax, want) / 2;
        }
    }
    try {
        b.pages = std::getenv("DOMA_PAGES_HBM") ? xrt::bo(device, pages_bytes, krnl.group_id(2)) : xrt::bo(device, pages_bytes, xrt::bo::flags::host_only, krnl.group_id(2));
    } catch (const std::exception& e) {
        std::printf("cannot allocate the tree buffer (pages, %zu B in %s): %s\n", pages_bytes,
                    std::getenv("DOMA_PAGES_HBM") ? "HBM" : "host memory, HOST[0]", e.what());
        return 1;
    }
    // Tiny ORAM's tree top on-package: DOMA_TINY_TOP bytes (the kernel reports what it used)
    size_t tiny_top = 0;
    if (TINY && std::getenv("DOMA_TINY_TOP")) {
        std::string tv = std::getenv("DOMA_TINY_TOP");
        if (tv.compare(0, 5, "doma:") == 0) {
            const unsigned mp = unsigned(std::stoul(tv.substr(5)));
            const size_t mb = std::getenv("DOMA_MATCH_BLOCK") ? std::stoul(std::getenv("DOMA_MATCH_BLOCK")) : 32;
            if (!std::getenv("DOMA_N") || mp > 100 || mb < 32 || mb > MAX_BLOCK || (mb & (mb - 1))) {
                std::printf("DOMA_TINY_TOP=doma:<pct> needs DOMA_N, pct 0..100 and DOMA_MATCH_BLOCK a power of two 32..4096\n"); return 1; }
            const uint32_t mpack = std::getenv("DOMA_PACK") ? uint32_t(mb / VALUE_SIZE) : 1u;
            tiny_top = doma_onpkg_bytes(NKEYS, mb, mpack, mp);
            std::printf("matched budget: doma_kernel keeps %zu B on-package for %u records in %zu-byte blocks (%u per block) at %u%% HBM\n",
                        tiny_top, NKEYS, mb, mpack, mp);
            if (std::getenv("DOMA_TINY_FLATPM")) {   // the flat position map: 8 bytes per block, on chip
                const size_t pm = size_t(8) << (tiny_L + 2);
                tiny_top = (tiny_top > pm) ? tiny_top - pm : 0;
                std::printf("matched budget: less Tiny ORAM's on-chip position map (%zu B for N=%u blocks): %zu B for the tree top\n",
                            pm, 4u << tiny_L, tiny_top);
            }
        } else tiny_top = (tv == "all") ? size_t(UINT32_MAX) : size_t(std::stoull(tv));
        if (tiny_top > UINT32_MAX) tiny_top = UINT32_MAX;
    }
    size_t tiny_tree = 0, tiny_top_eff = 0;
    if (TINY) {
        const size_t tb = std::max<size_t>(4096, roundup4k(std::min(tiny_top, pages_bytes)));
        try { b.top = xrt::bo(device, tb, krnl.group_id(4)); }
        catch (const std::exception& e) { std::printf("cannot allocate the tree-top buffer (top, %zu B in HBM): %s\n", tb, e.what()); return 1; }
    }
    if (!TINY) {
    // DOMA's trusted metadata (position map, 4 bytes per slot) in on-package HBM; DOMA writes all of it at boot
    b.meta  = xrt::bo(device, std::max<size_t>(4096, ((size_t(NBLK) + 4) / 5) * 32), krnl.group_id(4));   // 48-bit entries, 5 per 32-byte beat
    // bucket records: 256 bytes per bucket (metadata + each position's IV/tag), written by DOMA at boot
    b.brec  = xrt::bo(device, std::max<size_t>(4096, size_t(NB) * 64), krnl.group_id(5));    // 64-byte records (per-bucket GCM)
    // the stash: 512-byte lists per bucket, then a pool with one block per slot
    // the stash: 32-byte heads per bucket, 16-byte links per pool entry, then the pool's blocks
    // heads: 64 bytes per bucket. A head holds Z + 2 entries; at Z = 10 it takes two 32-byte beats when the build's
    // pool index needs more than 20 bits (NMAX above 2^20), and the kernel then lays out its regions after NB * 64.
    b.stash = xrt::bo(device, roundup4k(size_t(NB) * 64) + roundup4k(size_t(POOL) * 16) + size_t(POOL) * BLOCKA, krnl.group_id(6));
    // buckets kept in HBM: buckets 0 .. HBMK-1 (DOMA formats them at boot, like pages)
    b.pages_hbm = xrt::bo(device, std::max<size_t>(4096, size_t(HBMK) * stride), krnl.group_id(8));
    // DOMA_TINY_TOP=doma:<pct> sizes Tiny ORAM's tree top with doma_onpkg_bytes(); it must equal these buffers
    const size_t onpkg = b.meta.size() + b.brec.size() + b.stash.size() + size_t(HBMK) * stride;
    const size_t nrec = size_t(NBLK) * pack_a;                        // records the buffers are sized for
    if (doma_onpkg_bytes(nrec, BLOCKA, pack_a, hbm_pct) != onpkg)
        std::printf("WARNING: doma_onpkg_bytes() gives %zu B but doma_kernel's buffers take %zu B: update it, or Tiny ORAM's matched budgets are off\n",
                    doma_onpkg_bytes(nrec, BLOCKA, pack_a, hbm_pct), onpkg);
    if (std::getenv("DOMA_PLACEMENT"))   // the same line as Tiny ORAM's, for the comparison table
        std::printf("placement: on-package %zu B (position map, bucket records, stash, %u HBM buckets) + %zu B in pages; per record %.1f B on-package, %.1f B in pages\n",
                    onpkg, HBMK, size_t(NB - HBMK) * stride, double(onpkg) / (std::getenv("DOMA_N") ? NKEYS : nrec),
                    double(size_t(NB - HBMK) * stride) / (std::getenv("DOMA_N") ? NKEYS : nrec));
    }
    // DOMA: 11 arguments; Tiny ORAM: cmd, resp, pages, size, top, top_bytes
    auto launch = [&](uint32_t n) {
        return TINY ? krnl(b.cmd, b.resp, b.pages, n, b.top, uint32_t(tiny_top))
                    : krnl(b.cmd, b.resp, b.pages, n, b.meta, b.brec, b.stash, NBLK, b.pages_hbm, HBMK, POOL);
    };

    // ---- init: boot run, then preload every key (BOLT's init includes loading its dataset)
    auto init_start = std::chrono::system_clock::now();
    auto r0 = launch(0u);                                                  // DOMA: key load, layout, lease; Tiny ORAM: latch
    r0.wait();
    {   // the kernel reports its block size; the data layout must match the bitstream
        Summary s0 = read_summary(b, 0);
        if (s0.ok && s0.beats > 0 && s0.beats * 32 <= MAX_BLOCK) BLOCK = size_t(s0.beats) * 32;
        std::printf("block: %zu bytes per slot%s\n", BLOCK, (s0.beats == 0) ? " (bitstream does not report it; assuming 4 KB)" : "");
        if (VALUE_SIZE > BLOCK) { std::printf("VALUE_SIZE %d exceeds the block\n", VALUE_SIZE); return 1; }
        if (BLOCK != BLOCKA && (std::getenv("DOMA_BLOCK") || std::getenv("DOMA_N"))) {
            std::printf("the kernel's block is %zu bytes but DOMA_BLOCK sized the buffers for %zu: set DOMA_BLOCK=%zu\n", BLOCK, BLOCKA, BLOCK);
            return 1; }
    }
    if (TINY) {   // a run-time-depth bitstream (L_max in summary byte 2): select the depth DOMA_N needs, by a second init
        Summary g0 = read_summary(b, 0);
        if (g0.ok && g0.rt_lmax != 0 && std::getenv("DOMA_N")) {
            const unsigned want = std::max<unsigned>(tiny_L, g0.rt_lmin);
            if (want > g0.rt_lmax) {
                std::printf("DOMA_N=%u records (%u blocks of %u) need L=%u; this run-time-depth bitstream goes up to L_max=%u\n",
                            NKEYS, NBLK, pack_a, tiny_L, g0.rt_lmax);
                return 1; }
            if (want != g0.rt_l) { auto rs = launch(0x80000000u | want); rs.wait(); }
            Summary g1 = read_summary(b, 0);
            std::printf("Tiny ORAM bitstream: run-time depth, L = %u..%u; running at L=%u%s\n", g1.rt_lmin, g1.rt_lmax, g1.rt_l,
                        (g1.errors & 0x100) ? " (the depth was refused: status 0x100)" : "");
            if (g1.errors & 0x100) return 1;
        }
    }
    if (TINY) {   // the bitstream's geometry; Tiny ORAM has touched no memory yet (it zero-fills at the next launch)
        Summary g = read_summary(b, 0);
        if (!g.ok || !g.traffic || g.geo_n == 0) { std::printf("tinyoram_kernel did not report its geometry\n"); return 1; }
        unsigned bl = 1; while ((4u << bl) < g.geo_n) bl++;
        std::printf("Tiny ORAM bitstream: N=%u blocks (L=%u), tree %zu bytes\n", g.geo_n, bl, g.geo_tree);
        if (std::getenv("DOMA_N") && g.geo_n != (4u << tiny_L)) {
            std::printf("DOMA_N=%u records (%u blocks of %u) need a Tiny ORAM build with L=%u (N=%u blocks); this bitstream has N=%u (L=%u)\n",
                        NKEYS, NBLK, pack_a, tiny_L, 4u << tiny_L, g.geo_n, bl);
            return 1; }
        if (!std::getenv("DOMA_N")) NBLK = g.geo_n;
        tiny_tree = g.geo_tree;
        tiny_top_eff = (tiny_top >= g.geo_tree) ? g.geo_tree : (tiny_top & ~size_t(4095));
        if (g.errors & 0x80) std::printf("DOMA_TINY_TOP rounded down to %zu bytes (a multiple of 4 KB)\n", tiny_top_eff);
        if (tiny_top_eff > b.top.size()) { std::printf("the top buffer is smaller than the tree top\n"); return 1; }
        if (g.geo_tree > b.pages.size()) {
            std::printf("this bitstream's tree (%zu bytes) is larger than the pages buffer (%zu bytes): run with DOMA_BLOCK=%zu and DOMA_N for its N=%u blocks\n",
                        g.geo_tree, b.pages.size(), BLOCK, g.geo_n);
            return 1; }
    }
    if (std::getenv("DOMA_PACK")) PACK = uint32_t(BLOCK / VALUE_SIZE);    // records share a block
    if (!std::getenv("DOMA_N")) NKEYS = NBLK * PACK;
    std::printf("records: %u keys of %d bytes, %u per block\n", NKEYS, VALUE_SIZE, PACK);
    if (TINY) std::printf("placement: tree %zu B = %zu B on-package (top buffer) + %zu B in pages; per record %.1f B on-package, %.1f B in pages\n",
                          tiny_tree, tiny_top_eff, tiny_tree - tiny_top_eff, double(tiny_top_eff) / NKEYS, double(tiny_tree - tiny_top_eff) / NKEYS);
    std::vector<uint8_t> ref(size_t(NKEYS) * VALUE_SIZE);
    std::vector<Cmd> preload;
    std::mt19937 vgen(16);                                                // BOLT seeds its dataset with 16
    std::uniform_int_distribution<int> vdis(0, 255);
    for (uint32_t k = 0; k < NKEYS; k++) {
        Cmd c{}; c.type = T_PUT; c.key = k;
        for (int j = 0; j < VALUE_SIZE; j++) c.value[j] = (uint8_t)vdis(vgen);
        std::memcpy(&ref[size_t(k) * VALUE_SIZE], c.value, VALUE_SIZE);
        preload.push_back(c);
    }
    uint32_t pre_err = 0;
    for (size_t at = 0; at < preload.size(); at += max_cmds) {             // in batches that fit the buffers
        std::vector<Cmd> part(preload.begin() + at, preload.begin() + std::min(preload.size(), at + max_cmds));
        stage(b, part);
        auto r1 = launch((uint32_t)part.size());
        r1.wait();
        pre_err |= read_summary(b, part.size()).errors;
    }
    auto init_end = std::chrono::system_clock::now();
    std::printf("init: %.6f s (boot + preload of %u keys), preload errors=0x%x\n",
                std::chrono::duration<double>(init_end - init_start).count(), NKEYS, pre_err);

    // ---- query run, timed exactly like BOLT: launch + wait, commands already on the card
    // (tinyoram_kernel with more commands than fit the buffers: back-to-back launches of `batch` commands, each staged
    // before its launch and timed launch + wait; the times are summed)
    auto cmds = generate_uniform_commands(CMD_SIZE);
    double t = 0;
    Summary s{}; s.ok = true; s.traffic = true; s.lat_min = UINT32_MAX;
    int bad = 0, gets = 0, puts = 0, nlaunch = 0;
    std::vector<uint32_t> lv;                                             // primary latency of every command (TINY / DOMA_LAT_HIST)
    uint32_t dmin = UINT32_MAX, dmax = 0, amin = UINT32_MAX, amax = 0;
    const bool want_lat = TINY || std::getenv("DOMA_LAT_HIST");
    for (size_t at = 0; at < cmds.size(); at += batch) {
        const size_t n = std::min(batch, cmds.size() - at);
        std::vector<Cmd> part(cmds.begin() + at, cmds.begin() + at + n);
        stage(b, part);
        auto start = std::chrono::system_clock::now();
        auto run = launch((uint32_t)n);
        run.wait();
        auto end = std::chrono::system_clock::now();
        t += std::chrono::duration<double>(end - start).count();
        nlaunch++;
        Summary p = read_summary(b, n);
        s.ok = s.ok && p.ok; s.total += p.total; s.done += p.done; s.errors |= p.errors; s.beats = p.beats;
        s.lat_min = std::min(s.lat_min, p.lat_min); s.lat_max = std::max(s.lat_max, p.lat_max);
        s.traffic = s.traffic && p.traffic; s.rd_beats += p.rd_beats; s.wr_beats += p.wr_beats;
        s.top_rd64 += p.top_rd64; s.top_wr64 += p.top_wr64; s.geo_n = p.geo_n; s.geo_tree = p.geo_tree;
        // ---- verify every response against the reference
        auto resp = b.resp.map<uint8_t*>();
        for (size_t k = 0; k < n; k++) {
            const size_t i = at + k;
            const uint8_t* h = resp + k * 32;
            uint32_t slot; std::memcpy(&slot, h + 4, 4);                  // the kernel echoes the block
            uint32_t key = cmds[i].key, off = (key % PACK) * VALUE_SIZE;
            if (h[0] != T_ACK || slot != key / PACK) { if (bad++ < 5) std::printf("cmd %zu: bad header 0x%02x block %u\n", i, h[0], slot); continue; }
            if (cmds[i].type == T_PUT) { std::memcpy(&ref[size_t(key) * VALUE_SIZE], cmds[i].value, VALUE_SIZE); puts++; }
            else {
                gets++;
                if (std::memcmp(resp + b.hr + k * BLOCK + off, &ref[size_t(key) * VALUE_SIZE], VALUE_SIZE) != 0)
                    if (bad++ < 5) std::printf("cmd %zu: GET key %u returned wrong data\n", i, key);
            }
            if (want_lat) {   // the spread of the primary latency (response header bytes 8-11), and Tiny ORAM's others
                uint32_t l, d, a; std::memcpy(&l, h + 8, 4); std::memcpy(&d, h + 16, 4); std::memcpy(&a, h + 20, 4);
                lv.push_back(l);
                dmin = std::min(dmin, d); dmax = std::max(dmax, d); amin = std::min(amin, a); amax = std::max(amax, a);
            }
        }
    }
    if (s.lat_min == UINT32_MAX) s.lat_min = 0;
    if (nlaunch > 1)
        std::printf("batches: %d launches of up to %zu commands on the same ORAM (command and response buffers of %zu B, one HBM bank each); "
                    "timed: each launch + wait, summed\n", nlaunch, batch, b.cmd.size());
    std::printf("query: %d commands (%d GET, %d PUT) in %.6f s = %.1f KQPS\n", CMD_SIZE, gets, puts, t, CMD_SIZE / t / 1e3);
    std::printf("device: %llu cycles total, per-command latency %u..%u cycles, completed %u, errors 0x%x, summary %s\n",
                (unsigned long long)s.total, s.lat_min, s.lat_max, s.done, s.errors, s.ok ? "ok" : "MISSING");
    if (want_lat) {
        if (TINY && dmax)   // Tiny ORAM's secondary latencies (header bytes 16-19 and 20-23)
            std::printf("latency: to data ready %u..%u, to last write-back beat %u..%u, to write-back acknowledged %u..%u cycles\n",
                        dmin, dmax, s.lat_min, s.lat_max, amin, amax);
        if (!lv.empty()) {
            std::sort(lv.begin(), lv.end());
            auto pct = [&](double q) { return lv[std::min(lv.size() - 1, size_t(q * (lv.size() - 1) + 0.5))]; };
            double mean = 0; for (uint32_t x : lv) mean += x; mean /= lv.size();
            std::printf("latency spread: min %u, p50 %u, p90 %u, p99 %u, p99.9 %u, max %u, mean %.1f cycles (%zu commands)\n",
                        lv.front(), pct(0.5), pct(0.9), pct(0.99), pct(0.999), lv.back(), mean, lv.size());
            // histogram: 16 equal bins from min to max
            uint32_t lo = lv.front(), hi = lv.back(), w = std::max<uint32_t>(1, (hi - lo + 16) / 16);
            std::vector<size_t> bins(16, 0);
            for (uint32_t x : lv) bins[std::min<size_t>(15, (x - lo) / w)]++;
            std::printf("latency histogram (%u-cycle bins from %u):", w, lo);
            for (size_t k = 0; k < bins.size(); k++) std::printf(" %zu", bins[k]);
            std::printf("\n");
        }
    }
    if (s.traffic && s.done)
        std::printf("traffic: %s %llu B read, %llu B written = %.0f B read, %.0f B written per command\n",
                    TINY ? "tree (pages + top, both ports)" : "bucket port (pages, off-package)", (unsigned long long)(s.rd_beats * 32), (unsigned long long)(s.wr_beats * 32),
                    32.0 * s.rd_beats / s.done, 32.0 * s.wr_beats / s.done);
    if (TINY && s.traffic && s.done) {   // the same traffic split by port: off-package (pages) and on-package (top)
        const double trd = 64.0 * s.top_rd64, twr = 64.0 * s.top_wr64, ard = 32.0 * s.rd_beats, awr = 32.0 * s.wr_beats;
        std::printf("traffic split: pages (off-package) %.0f B read, %.0f B written per command; top (on-package) %.0f B read, %.0f B written per command\n",
                    (ard - trd) / s.done, (awr - twr) / s.done, trd / s.done, twr / s.done);
    }
    std::printf("%s\n", (bad == 0 && s.ok && s.errors == 0) ? "ALL RESPONSES CORRECT" : "ERRORS FOUND");
    return (bad == 0 && s.ok && s.errors == 0) ? 0 : 1;
}
