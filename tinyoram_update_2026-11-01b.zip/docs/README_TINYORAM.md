# Tiny ORAM as a U55C kernel — Step 1 notes and Step 2 configuration

Status 2026-10-18: Phase 1 (port onto step 5.2, §10) and Phase 2 (packed records, §11) done; the card
bring-up at 64 B (Phase 3) and the 1M-record build (Phase 4) are written up as commands with expected
output in `docs/TINYORAM_CARD_RUNBOOK.md` (§12). Audit fixes in §13. The changes for a fair comparison
with DOMA are in §14: front end, merged bursts, tree-top split, flat position map, latency spread.
Rebased onto DOMA's current package (Z = 10, compact buckets, 300 MHz closure, prefetch, arrival-mode
early release): DOMA's regressions pass on it at 32 B and 4 KB with the expected timing hashes, and
`scan.sh` runs both kernels. §15 adds the implicit-net lint, slow-acknowledgement tests with a stale-read
monitor, 4 GB-crossing buffers, per-port traffic, and the card scripts (install, bring-up, build queue,
sweeps, merged table) in `tinyoram/card/`. §17 fixes the PosMap depth at 4 KB; §18 adds a run-time tree depth
(one build for every N up to L_max, checked cycle by cycle against native builds). Regression and mutation counts: see
`docs/tinyoram_regression_2026-10-18.txt` and `docs/tinyoram_mutants_2026-10-18.txt`. Packaging, host program and build scripts are untested on Vitis: no Vivado/Vitis/XRT where
they were written (the host was checked against a functional mock of XRT).

Source studied: `github.com/ascend-secure-processor/oram`, branch `oram_fpga_public`,
commit `18ece07` (2017-07-12). Simulator: Verilator 5.020. The harness and patches used
below are in `tinyoram/study/` (`run_study.sh setup` fetches the source and applies
`sim_patches.diff`; no Tiny ORAM source is copied into this package).

## 1. Summary

* **One RTL tree, not an FPGA/ASIC split.** `oram_fpga_public` is `master` plus two
  README commits. The RTL is the MIT "chip" snapshot (2014–15). FPGA and ASIC builds
  share it through `` `ifdef FPGA ``. The board files, Xilinx IP and test scripts the README
  refers to (`../boards`, `../tests`) are not in the repository.
* **4 KB blocks work.** N = 256, 4 KB blocks, encryption and PMMAC integrity on: random
  GET/PUT traffic matched a reference model with BEDWidth 128 and with 256.
* **Read-after-write ordering is required.** Tiny ORAM assumes a MIG-style in-order DRAM.
  When writes become visible late, the harness fails ("block already present in stash").
  The AXI adapter must hold reads until earlier writes are acknowledged.
* **Random initial values are fine; never-written tree memory must read as zeros.**
  (Corrected 2026-10-10: the "hang with random initial values" reported here first was a bug
  in my testbench's memory model, which returned random data for never-written memory under
  `--x-initial unique`. With that fixed, Tiny ORAM passes with `+verilator+rand+reset+2`.)
* **Only one secure configuration works.** That is the Path ORAM backend with AES and
  PMMAC. RAW Path ORAM (`EnableREW=1`) does not work in this snapshot.
* **License:** the MIT-written files carry no license and the repository has no LICENSE
  file (§6).

## 2. Interfaces

### Frontend (user side of `TinyORAMCore`)

| Signal | Meaning |
|---|---|
| `Cmd[1:0]` + `PAddr[31:0]`, `CmdValid/CmdReady` | Commands: `0` Update (write), `2` Read. `1` Append and `3` ReadRmv are internal (PosMap). An Update to a never-written block works, because the frontend turns it into an Append. `PAddr` is the block index and must be < N. |
| `WMask[ORAMB/8-1:0]` | Byte write mask, 4096 bits at 4 KB. Tie it to all ones. |
| `DataIn[FEDWidth]`, valid/ready | Write data. After an accepted Update, ORAMB/FEDWidth beats (512 at 4 KB). |
| `DataOut[FEDWidth]`, valid/ready | Read data, same beat count. |

* **One command at a time.** `CmdReady` stays low until the frontend is free again.
* **No write acknowledgement.** `CmdReady` going high again does not mean the access has
  finished. A trace of one 4 KB access with BEDWidth = 256 (`-DTRACE`), in cycles from the
  command:

  | Phase | GET | PUT |
  |---|---|---|
  | Path read: commands | 39–2040 | |
  | Path read: data | 80–4083 | |
  | Data returned to the user | 4883–5394 | |
  | `CmdReady` high again | | 546 |
  | Path writeback | 4769–8744 | ~8800 (ends) |

  So the user sees a GET finish about 3.4k cycles before the writeback ends, and a PUT
  finish about 8k cycles before it ends.
* **Out-of-range `PAddr` is not handled.** It only sets a sticky error flag (simulation
  calls `$finish`). The wrapper must reject keys ≥ N itself (status 0x4).

### DRAM side ("MIG-like")

* **Command channel:** `DRAMAddress[DDRAWidth]`, `DRAMCommand[2:0]` (0 = write, 1 = read),
  valid/ready.
  * The address counts 64-bit words and is always a multiple of 8. Each command is one
    64-byte burst.
  * A bucket is a run of consecutive bursts. Buckets are laid out in subtrees of height 2
    (at 4 KB), which keeps each subtree within one DDR3 row.
  * The adapter can merge consecutive commands into AXI bursts, but must split them at
    4 KB boundaries. A 4 KB-block bucket is 16,512 B, so it is not 4 KB-aligned.
* **Write data:** `BEDWidth` beats with valid/ready, 512/BEDWidth beats per write command,
  in command order.
* **Read data:** `BEDWidth` beats with **no ready**, in command order.
  * The AES engine must take a beat every cycle. Overflow only sets an error flag
    (`ERROR_OF1`, "Lose ciphertexts").
  * So the adapter buffers the AXI R channel. It pushes at most one beat per cycle into
    the core, and throttles `rready` on its own FIFO.
* **Ordering:** the core issues a whole path of reads, then a whole path of writes. The
  next access's reads start with the root bucket that was just written. The adapter
  therefore needs a single ID with in-order reads, and must hold reads until every
  earlier write has its B response. The `WR_LAG=20000` run shows what happens without
  this.
* **Initial memory contents:** there is no DRAM initialiser ("we got rid of DRAMInit").
  * A bucket whose stored IV is 0 is treated as empty.
  * The tree region must be zero before first use. Garbage happened to pass in simulation,
    but it can turn into fake blocks.
  * Proposal: the kernel zero-fills the tree at the first (size = 0) launch, counted as
    initialization. This matches DOMA formatting its buckets at boot.

## 3. Parameters

| Parameter | Default | Notes |
|---|---|---|
| `ORAMB` (block size, bits) | 512 (64 B) | The FCCM'15 paper claims 64 B–4 KB. 32768 tested here. |
| `ORAMZ` | 4 | Effectively fixed: the frontend assumes Z = 4. N = 4·2^L, so the tree is 50 % full. |
| `ORAML` | 23 (19 in sim) | Number of levels = L + 1. N = 256 gives L = 6: 127 buckets, 508 slots. |
| `ORAMC` (stash) | 10 | Extra entries on top of one path: 10 + 4·7 = 38 entries (152 KB at 4 KB). The backend does background eviction (dummy accesses) when the stash fills. |
| `FEDWidth` | 64 | Only 64 works. 128 and 256 hang at 4 KB. |
| `BEDWidth` | 128 | Must divide 512. 128 and 256 both pass. |
| `Overclock` | 1 | Extra stash pipelining "needed for 200 MHz". |
| PosMap | Unified frontend, PLB 8 KB, `PRFPosMap=1` | Recursion = ⌈(L+2−10)/3⌉+1, which is 1 at N = 256. The whole PosMap (256 counters) is on chip, so there are no PosMap ORAMs and the PLB does nothing. Recursion appears at larger N. The 3 is log2 of the 8 leaves in a 64 B PosMap block; for larger blocks `fetch_tinyoram.sh` writes the same rule with log2(ORAMB/64) (§17). |
| `EnableAES` | 1 | AES-128 counter mode. Each bucket gets a 64-bit IV from a global counter, stored in clear. Pipelined tiny_aes (21-cycle latency), with BEDWidth/128 lanes running at line rate. |
| `EnableIV` (PMMAC) | 1 | Keyed SHA-3 (Keccak, 224-bit digest truncated to 128) over (counter, address, data). It is checked in the frontend; the counter in the PosMap gives freshness. Leaves are AES-PRF(counter). The MACs grow the bucket header from 1 to 2 bursts. |
| `EnableREW` | 0 | RAW Path ORAM. **Not usable**, see below. |
| Keys | hard-coded | AES key all ones, PRF and MAC keys fixed. This is the same situation as DOMA's stand-in keys. |

Which security switches actually work in this snapshot:

* **AES on, PMMAC on: works.** This contradicts the README, which says integrity needs
  the RAW backend.
* **AES on, PMMAC off: works** with `PRFPosMap=0`. With `PRFPosMap=1` and no PMMAC, the
  leaves would be the raw counters.
* **RAW backend: does not work.**
  * With PMMAC it stops with "Not supported yet" (it needs a 1-burst header).
  * Without PMMAC it stops with "Path buffer overflow". The source itself says
    "this won't work right now".

Geometry and traffic at N = 256 and 4 KB, with PMMAC:

* **Bucket:** 258 bursts = 16,512 B.
* **Path:** 7 buckets = 115,584 B.
* **Per access:** 231,168 B moved (56× the block), plus occasional background evictions.
* **Tree:** 2.0 MB in use. The address span is 3.35 MB because of the subtree padding.
  DOMA's pages buffer is 2 MB, so the host must size the pages buffer per kernel.

## 4. Dependencies and porting to UltraScale+ / Vivado 2024.1

* **Xilinx IP is not needed** for the proposed configuration.
  * The only IP instances are `ClkCross512x{128,144,512}` (async FIFOs, RAW backend with
    `FPGA` defined) and `aes_clock` (MMCM, only when `SlowAESClock=0`). Neither is used.
  * There are no Xilinx primitives. RAMs are behavioural (`gatelib/RAM.v`).
  * `FPGA_MEMORY` must be defined. Otherwise the RAMs map to IBM 32SOI SRAM wrappers.
* **Two build flows:**
  * **`FPGA` defined:** parameters are passed down the hierarchy. The backend and AES
    resets are tied to 0, and their FSMs depend on `initial` blocks. `Const.vh` also needs
    `SYNTHESIS` (Vivado synth) or `MODELSIM` (simulation) defined, or its macros
    disappear.
  * **Without `FPGA` (the "ASIC" flow):** resets are real, but `Frontend`,
    `PathORAMBackendCore` and `AESPathORAM` take their parameters from `PathORAM.vh`
    instead of from the parent. One instance per build, configured by editing that file.
  * Both flows gave identical results at 4 KB. **I'd use the ASIC flow plus
    `FPGA_MEMORY`**, because its resets are real.
* **Old-Verilog issues:**
  * Zero-width replications in gatelib parameter defaults (`{Width{1'b0}}` with Width = 0):
    errors in Verilator 5 and Icarus 12. Vivado's behaviour still needs checking with
    `synth_ooc.tcl`.
  * `PrioritySelect.v` has an unnamed instance, which is a syntax error. It is unused, so
    I excluded it.
  * `ClockSource.v` starts the clock on `posedge` of a constant, so it never starts in
    Verilator.
  * 233 `(* mark_debug = "TRUE" *)` attributes. They should be stripped so they don't pin
    nets.
  * Many simulation-only checks are not gated by reset.
* **Random initial values:** Tiny ORAM's logic passes (corrected 2026-10-10, see §1). Only
  its simulation-only self-checks fire on the first clock edge, before reset takes effect,
  so the random-init run compiles Tiny ORAM without `SIMULATION`.
* **Timing:** the original target was 200 MHz on a Virtex-7 (XC7VX485T). Likely long
  paths at 300 MHz:
  * Keccak `round2in1` (two rounds per cycle);
  * the tiny_aes table rounds;
  * the stash scan logic.

  I can't estimate slack without Vivado. That is the first `worst_paths.tcl` job.

## 5. Its own tests

* **The shipped test** is `frontend/test/testUORAM.v`, driving `TinyORAMASICWrap` and
  `TrafficGenASIC`. The README says the per-module testbenches are out of date.
  * It needs files that are not in the repository (`tests/software/testORAM.v`,
    `network_define.v`). `+define+SIMULATION_VIVADO` avoids them.
  * Its dummy generator hard-fails on any configuration other than the default one
    (64 B blocks, Z = 4, PMMAC on).
* **Icarus 12:** does not elaborate (indefinite-width concatenations). Not pursued.
* **Verilator 5.020:** needed four simulation-only patches:
  * zero-width defaults;
  * a nonblocking assignment in a loop in an AddrGen checker;
  * the clock start;
  * an `ORAML` override, since L = 19 is too slow.

  With those it gives **"TrafficGen: ALL TESTS PASSED"**: default configuration, L = 10,
  6,144 accesses.
* **My harness** (`tinyoram/study/tb_core.sv`) drives `TinyORAMCore` directly.
  * Preload of all N blocks, then 200 random commands (50 % PUT), every GET checked.
  * DRAM model: in-order, 40-cycle read latency, 10 % random gaps on every DRAM channel,
    never-written memory reads as zeros.

| Configuration | Result | Cycles/cmd | Read + written per cmd |
|---|---|---|---|
| 64 B, L = 10 (N = 4096), FED 64, BED 128, AES + PMMAC | PASS | 1,328 | 7.3 + 7.2 KB |
| 64 B, L = 10, BED 256 | PASS | 824 | 7.4 + 7.4 KB |
| **4 KB, L = 6 (N = 256), FED 64, BED 128, AES + PMMAC** | PASS | 18,364 | 112.5 + 112.3 KB |
| **4 KB, L = 6, FED 64, BED 256, AES + PMMAC** | PASS | 9,636 | 112.9 + 112.4 KB |
| 4 KB, BED 256, AES only (`PRFPosMap=0`) | PASS | 8,962 | 112.9 + 112.4 KB |
| 4 KB, same with `FPGA` defined | PASS, identical | 9,636 | |
| 4 KB, FED 128 or 256 | hang | | |
| 4 KB, writes visible 20k cycles late | FAIL (duplicate block in stash) | | |
| 4 KB, random initial values | PASS (the first "hang" was a testbench bug) | 9,613 | |
| 64 B, RAW backend, no PMMAC | FAIL (path buffer overflow) | | |

The cycles-per-command figures come from an idealised DRAM. HBM, and later host memory,
will be slower. At 300 MHz, 9,636 cycles is 32 µs, about 31 k commands/s, as an upper
bound.

## 6. License

* **Third-party cores** carry permissive notices: UC Berkeley GateLib (BSD-3),
  tiny_aes and the Keccak core by Homer Hsing (Apache-2.0), and the OpenCores AES by
  R. Usselmann (BSD-style).
* **The MIT-written files** (frontend, backend, stash, addr, integrity, `TinyORAMCore`,
  `include/`) have no license header, and there is no LICENSE file.
* By default that means all rights reserved, so redistributing modified copies is not
  clearly allowed. Until that's settled, I'd ship Tiny ORAM changes only as patches plus a
  fetch script, as `tinyoram/study/` does now.
* The authors to ask are C. Fletcher, L. Ren and A. Kwon (commit authors).

## 7. Step 2 configuration (agreed 2026-10-09)

**Baseline A, same N and block size as DOMA:**

* **Protocol:** Path ORAM backend, Z = 4, L = 6, N = 256, 4 KB blocks, C = 10.
* **Security:** AES-128 counter mode on, PMMAC integrity on, `PRFPosMap=1`. The PLB is
  configured but idle.
* **Widths:** FEDWidth 64, BEDWidth 256, so a 256-bit AXI beat is one core beat.
* **Clock:** the same 300 MHz kernel clock, with the AES on that clock
  (`SlowAESClock=1`). If timing fails, report the achieved frequency rather than lowering
  the target.
* **Tree:** in `m_axi_gmem2`, HBM[8] first, then HOST[0]. The pages buffer is at least
  3.35 MB and zero-filled by the kernel at the first launch.
* **Build:** ASIC flow plus `FPGA_MEMORY`, `mark_debug` stripped, minimal fixes for
  Vivado and for random initial values, each one recorded in the README.

Baseline A is the most comparable to DOMA. It is also not Tiny ORAM's favourable regime:
its 2-burst headers and 56× path traffic dominate. A second configuration (B) would cover
BOLT-like sizes:

* 64 B blocks (Tiny ORAM's native and minimum size); 8–256 B records fit in one block;
* N sized like BOLT's key space, which brings in PosMap recursion and the PLB as Tiny
  ORAM was designed;
* later, also 256 B.

**Latency definition.** DOMA's `client_done` fires after its writeback is acknowledged.
For a fair comparison I propose:

* a command is done when its data is back (GET) **and** the backend is idle **and** the
  adapter has no outstanding writes;
* the next command is issued only after that.

This needs one internal tap (the backend controller's idle state). I would also record
"data ready" time as a second figure.

**Decided:**

* 2026-10-09: keep Tiny ORAM's own cryptography; do not swap in DOMA's AES-GCM. That
  means tiny_aes (pipelined AES-128 in counter mode) for bucket encryption, the OpenCores
  AES as the counter-to-leaf PRF, and keyed SHA-3 for PMMAC. The comparison is against
  Tiny ORAM as published. The README for the results will state the primitive
  difference: AES-CTR plus SHA-3 MAC versus DOMA's AES-GCM.
* 2026-10-09: integrity (PMMAC) stays on.
* 2026-10-09: latency definition.
  * A command's latency ends when its path writeback has been fully sent: the last write
    data beat has been accepted on `m_axi_gmem2`. The kernel does not wait for the write
    responses (B) before stopping the latency counter.
  * For correctness, the adapter still holds later reads until earlier writes are
    acknowledged (§2). Any wait for B responses therefore shows up in the next command's
    latency and in the total query time, not in this command's latency.
  * A GET's data-ready time is recorded as a second figure.
* 2026-10-09: add reset-time clears to Tiny ORAM's uninitialised RAMs and registers, so the
  random-initial-value test passes. **Superseded 2026-10-10:** no clears are needed; the hang
  was a testbench bug (§1), and Tiny ORAM passes the random-init test unchanged.
* 2026-10-09: no license request to the authors. Tiny ORAM will be cited (Fletcher et al.,
  FCCM 2015). Since the MIT files carry no license, the package keeps shipping Tiny ORAM as
  the upstream commit plus our patches and a fetch script, not as copied sources.
* 2026-10-10: record sizes. Both are kept: BOLT-like records of 8–256 B, and 4 KB (DOMA's
  size). All use N = 256 with AES and PMMAC on.
  * Tiny ORAM's block size `ORAMB` is fixed at build time, so each block size is its own
    xclbin.
  * In simulation (harness, BEDWidth 256, 400 random commands after preload), 64 B and up
    pass. 8, 16 and 32 B blocks hang before the first PUT completes, which matches the
    paper's 64 B minimum.
  * So 8–64 B records are stored in 64 B blocks, padded. This costs nothing in memory
    traffic, because Tiny ORAM pads every block to a whole 64 B burst anyway. 128 B,
    256 B and 4 KB are native blocks.
  * That makes four builds:

    | Records | `ORAMB` | Bucket | Path (read, = written) | Sim cycles/cmd |
    |---|---|---|---|---|
    | 8, 16, 32, 64 B | 512 (64 B) | 6 bursts = 384 B | 2,688 B | 351 |
    | 128 B | 1024 | 10 bursts = 640 B | 4,480 B | 499 |
    | 256 B | 2048 | 18 bursts = 1,152 B | 8,064 B | 777 |
    | 4 KB | 32768 | 258 bursts = 16,512 B | 115,584 B | 9,636 |

    The cycle counts come from the idealised DRAM model (40-cycle reads, 10 % gaps), so
    they are upper bounds on speed.
  * The kernel takes the first `ORAMB` bits of each 4 KB PUT slot in the command buffer
    and writes the record (`ORAMB` bits) at the start of the GET slot, so the host layout
    stays the same as DOMA's. **Superseded 2026-10-13 (§11):** slots are block-sized, as DOMA's.

## 8. Step 3 (adapter and kernel) and Step 4 (simulation) — 2026-10-10

### What was built

| File | What it is |
|---|---|
| `tinyoram/rtl/tinyoram_kernel.v` | The Vitis kernel. Same arguments, control registers, buffer layout, response and summary records as `doma_kernel.v`, with Tiny ORAM in DOMA's place. |
| `tinyoram/rtl/tinyoram_axi_adapter.v` | Tiny ORAM's DDR3-controller-style memory port to `m_axi_gmem2`. |
| `tinyoram/fetch_tinyoram.sh` | Downloads Tiny ORAM at commit 18ece07 and applies `tinyoram/patches/`. It writes a flat source directory, `tinyoram/build/src/`, with the configuration header for one block size. |
| `tinyoram/config/tinyoram_config_{64,128,256,4k}.vh` | One configuration header per block size (each size is its own xclbin). |
| `sim/tb_tinyoram_kernel.v`, `sim/run_tinyoram.sh` | Kernel regression (the testbench plays XRT), run with Verilator. |
| `sim/run_xsim_tinyoram.sh` | The same test in Vivado's simulator (untested here). |
| `vitis/synth_ooc_tinyoram.tcl` | Out-of-context synthesis and place & route on the U55C part at 300 MHz. Run this first. |
| `vitis/package_tinyoram.tcl`, `kernel_tinyoram.xml`, `tinyoram_hw.cfg`, `tinyoram_host.cfg`, `build_tinyoram.sh` | Packaging and v++ link, mirroring the DOMA files. |
| `vitis/host_doma.cpp` | Shared with DOMA. Selects the kernel with `--kernel tinyoram_kernel` or `DOMA_KERNEL`; see §10. |

### Changes to Tiny ORAM (patches against 18ece07)

| Patch | Change | Why |
|---|---|---|
| 01 | `Const.vh`/`PathORAM.vh` include `tinyoram_config.vh`. `ORAMB`, `ORAML` and `BEDWidth` defaults can be overridden; `FPGA_MEMORY` is defined. | Per-build configuration. |
| 02 | New `Idle` output, passed up from the backend controller and the integrity verifier. | Status only, for the agreed latency definition. No behaviour change. |
| 03 | gatelib parameter defaults `{Width{…}}` → `{(Width>0?Width:1){…}}`. | Zero-width replication is illegal in current tools. The values are unchanged. |
| 04 | Three simulation-only self-checks: one no longer runs during reset, one fixes a Verilator loop construct. | Inside `ifdef SIMULATION`; no effect on hardware. |
| 05 | `PosMapPLB.v`: `OldLeafOut <= PosMapOut[LeafOutWidth-1:0]` (was `[ORAML-1:0]`). | **Bug fix.** See below. |
| 06 | Remove all 233 `(* mark_debug = ... *)` attributes (14 files). | They pin nets, which costs resources and timing; DOMA has none. Plan step B4: 20/20 with identical cycle counts. |

The patch 05 bug, in more detail:

* In PRF mode the PosMap holds a 64-bit access counter per block, and the leaf is
  AES(address ‖ counter).
* The old counter was cut to `ORAML` bits while the new one kept all 64. So after 2^`ORAML`
  accesses to one block, the old and new leaves disagree, and Tiny ORAM stops on its own
  check ("block being accessed didn't have correct leaf").
* At the authors' `ORAML` = 23 that needs 8 M accesses to one block. At ours (6) it needs 64.
  A uniform 5,000-command run would rarely reach that, but repeated runs without reloading
  the xclbin would.
* Reproduced on the unpatched source: it fails on the 64th access to one key. With the fix,
  300 consecutive accesses to one key pass.

No reset-time clears were needed (§1). Crypto and keys are as published.

### Adapter (1:1, as agreed)

* **Translation:** one Tiny ORAM command (64 B) becomes one 2-beat AXI burst, with a single
  ID. A 64-byte-aligned 2-beat burst can't cross a 4 KB boundary.
* **Ordering:** a read is not issued while any write lacks its B response. A write is not
  issued while any read still has data to return. This is the ordering of the DDR3
  controller Tiny ORAM was built for.
* **Read buffer:** 512 beats; an AR is issued only when there is room for all its data.
  This is needed because Tiny ORAM can't apply backpressure on read data.
* **Write buffer:** 512 beats, and a beat leaves only after its AW. This is needed because
  Tiny ORAM's AES has about two buckets of keystream buffering and no stall. Without the
  buffer, a long W stall loses keystream (Tiny ORAM's own "Lose Masks!" check). A memory
  controller's write FIFO plays the same role in the original setup.
* **Address check:** an address outside the tree raises the kernel's error flag (0x8).

### Kernel specifics

* **First launch:** latches the pages address and zero-fills the tree. An all-zero bucket is
  Tiny ORAM's "never written" bucket, and Tiny ORAM has no DRAM initialiser of its own. Only
  then is Tiny ORAM released from reset; nothing touches memory before the first `ap_start`.
* **Tree size:** the zero-fill covers 49,536 B / 123,520 B / 185,472 B / 3,517,056 B for
  64 B / 128 B / 256 B / 4 KB blocks at L = 6. The host sizes the pages buffer from
  `DOMA_N` and `DOMA_BLOCK` (§10).
* **Key range:** keys ≥ N are rejected (0x4).
* **Changed 2026-10-13 (§10):** the zero-fill moved from the init launch to the first launch
  with size > 0, so the host can check the geometry first.
* **Latency end:** superseded on 2026-10-12 by plan step B1 (§9): the primary figure now ends
  at write-back acknowledged, and "data ready" and "last write beat" are secondary figures.

### Simulation results (Verilator 5.020, `sim/run_tinyoram.sh`, log in `docs/tinyoram_regression_2026-10-12.txt`)

All 20 checks pass: four block sizes × five tests (e2e, late start + 256 PUTs, 30 % gaps, late
writes, random initial values).

Per-command latency at the testbench's 100-cycle tree latency:

| Block size | Latency (cycles) |
|---|---|
| 64 B | 571 |
| 128 B | 834 |
| 256 B | 1,318 |
| 4 KB | 16,936 |

The testbench's memory model accepts at most 16 outstanding reads. With 64-byte bursts that
caps reads at 16 × 2 beats per 100 cycles. So simulated 4 KB latency is mostly that limit,
not Tiny ORAM; HBM's real outstanding-read limit will set the board number.

Memory model: `+host_wlat=200` lands each burst 200 cycles after its own last beat. The
current `sim/axi_mem_model.v` does this itself (bursts land pipelined), so the `wlat_pipe`
option this test used on the old base is no longer needed and `axi_mem_model.v` is unchanged.

### Next on the U55C machine

Superseded by §10 (host usage) and the Phase 3 instructions.

## 9. Modification plan, 2026-10-12

Status of the plan's steps:

| Step | Status |
|---|---|
| A (port onto the current package) | **Waiting for the current `fpga_zcu208_deploy.zip`** (step 4, 26/26). Everything below was done on Tiny ORAM's own files, ready to port. |
| B1 latency | Done, using the recommended definition. |
| B2 byte counters | Done (Tiny ORAM side). |
| B3 packing | `WMask` verified; packing itself not yet started. |
| B4 `mark_debug` | Done (patch 06). |
| B5 clock | Done. |
| B6 burst merging | Decided 2026-10-12: decide after the first 4 KB card results (see below). |
| C | Needs the card. |
| D | Recursion and PLB tested; tree-size table below. |

### B1: latency ends at write-back acknowledged

The response header now carries three figures, all counted from issuing the command to Tiny
ORAM:

| Header bytes | Figure | Ends when |
|---|---|---|
| 8–11 (primary, and the summary min/max) | write-back acknowledged | data done, Tiny ORAM `Idle`, and every write's B response received (adapter idle). This is the same end point as DOMA's `client_done`. |
| 16–19 | data ready | GET record received, or PUT record sent. |
| 20–23 | last write beat | Tiny ORAM `Idle` and every write beat on the bus. |

The testbench checks data ready ≤ last write beat ≤ acknowledged for every command. DOMA's
header bytes 16–31 are zero today; the host can read these two fields for Tiny ORAM only.

### B2: record [size+1]

Format, as in the plan:
* byte 0: `0x5B`;
* bytes 8–15: read beats on gmem2 during the launch;
* bytes 16–23: write beats on gmem2;
* bytes 24–31: zero (DOMA). Since 2026-10-13 Tiny ORAM puts its geometry there (§10).

The init launch counts the zero-fill (64 B tree: 1,548 write beats = 49,536 B). The testbench
compares both counts with its own beat counters on gmem2: exact in all 20 runs. Per command
(run 1, 64 B blocks): 84 read + 84 write beats = 2,688 B each way, exactly one path.

**Layout edge case: settled.** DOMA moved GET data to HR = roundup((size+2)·32, 4 KB) in step
5.2; Tiny ORAM does the same (§10).

### B3 (check): `WMask` works

Test (`tinyoram/study/tb_core.sv -DMASK_TEST`): three quarters of the PUTs to existing blocks
get a partial byte mask, either a random byte range (any offset and length) or an aligned
8-byte slot, against a byte-level reference.

| Configuration | Partial PUTs | Commands | Result |
|---|---|---|---|
| 64 B | 126 | 300 | PASS |
| 4 KB | 48 | 120 | PASS |
| N = 16K, 64 B | 1,124 | 3,000 | PASS |
| N = 64K, 64 B | 1,116 | 3,000 | PASS |

Packing through `WMask` is therefore feasible. The kernel changes it needs (header bytes 8–15,
status 0x40, block-sized slots, block size in summary bytes 4–7) wait for step A, so they
match the current DOMA layout.

### B5: clock

* `FREQ=<MHz> bash build_tinyoram.sh`: `--kernel_frequency` and `check_timing.sh`'s `WANT_MHZ` follow it.
  The packaged `FREQ_HZ` stays 300 MHz whatever `FREQ` is, as in DOMA's `package_kernel.tcl` (§19).
* For `FREQ` ≠ 300 the xclbin is named `tinyoram_<size>_<FREQ>mhz_<target>.xclbin`.
* `synth_ooc_tinyoram.tcl -tclargs route <MHz>` checks another clock out of context.

### D: recursion and the PLB at large N (harness, 64 B blocks, AES and PMMAC on, random partial writes)

| N (blocks) | L | Recursion levels | Preload | 3,000 random commands | Traffic per command |
|---|---|---|---|---|---|
| 16,384 | 12 | 3 | 16,384 PUTs | PASS, 1,398 cycles/cmd | 13.2 KB read + 13.2 KB written: ~2.6 paths (one path = 4,992 B), the extra from PosMap blocks missing the PLB |
| 65,536 | 14 | 3 | 65,536 PUTs | PASS, 1,669 cycles/cmd | 16.5 KB each way: ~2.9 paths (one path = 5,760 B) |

So at large N, PosMap recursion multiplies Tiny ORAM's traffic. The byte counters (B2) will
show this on the card.

Tree size per N, packed 8-byte records (8 per 64 B block). Choose L as the smallest value
with 4·2^L ≥ blocks. The tree span includes the subtree-padding buckets.

| Records | Blocks | L | Blocks held | Recursion | Tree span | One path, each way |
|---|---|---|---|---|---|---|
| 2,048 | 256 | 6 | 256 | 1 | 48 KB | 2,688 B |
| 16,384 | 2,048 | 9 | 2,048 | 2 | 0.4 MB | 3,840 B |
| 131,072 | 16,384 | 12 | 16,384 | 3 | 3.0 MB | 4,992 B |
| 1,048,576 | 131,072 | 15 | 131,072 | 4 | 30 MB | 6,144 B |
| 10,000,000 | 1,250,000 | 19 | 2,097,152 | 5 | 390 MB | 7,680 B |

10M records fit an HBM bank (512 MB), with about 120 MB to spare. The kernel already derives
its key-range check and zero-fill size from the geometry; once packing is in, the host's
`--n` must name records and the matching build.

### B6: burst merging, decided after the card results (2026-10-12)

The 1:1 adapter stays the default and the faithful baseline. After the first 4 KB run with the
tree in HBM[8], compute Tiny ORAM's effective tree bandwidth:

    (read beats + write beats from record [size+1]) x 32 B / query time

Compare it with what the same HBM bank delivers to DOMA's 4 KB bursts. If Tiny ORAM is clearly
limited by per-transaction cost (2-beat bursts) rather than by its own path traffic, add the
merged variant and report both. The merged variant combines consecutive commands into longer
bursts, split at 4 KB boundaries, adapter only, nothing inside Tiny ORAM. Otherwise report 1:1
only.

**Stated limitation (2026-10-13 status note: "not now").** The adapter is 1:1: every Tiny ORAM
memory command is its own 64-byte, 2-beat AXI burst, as with the DDR3 controller Tiny ORAM was
built for. DOMA moves whole blocks in long bursts. The board numbers for Tiny ORAM therefore
include HBM's per-transaction cost of 64-byte bursts; merging consecutive commands into longer
bursts (adapter only) could lower it, and is not done.

## 10. Phase 1: port onto the step 5.2 package (2026-10-13)

### Layout

* Tiny ORAM's kernel and adapter moved from `rtl/` to **`tinyoram/rtl/`**. DOMA's
  `package_kernel.tcl`, `synth_ooc.tcl` and `worst_paths.tcl` read every `rtl/*.v`, and Tiny
  ORAM's files need its headers, so leaving them in `rtl/` would break DOMA's builds. DOMA's
  `rtl/` is now byte-identical to the step 5.2 package.
* Response data at HR = roundup((size+2)·32, 4 KB), after the summary record [size] and the
  traffic record [size+1], as DOMA.

### Init launch and geometry

* **The init launch (size = 0) only latches the pages address and reports the geometry.** It
  touches no memory. The zero-fill of the tree moved to the first launch with size > 0 (in the
  host flow, the first preload batch, so it still counts as initialization), followed by Tiny
  ORAM's release from reset.
* **Record [size+1] bytes 24–31** (zero for DOMA): bytes 24–27 the build's N (blocks), bytes
  28–31 the tree size in 64-byte bursts (a 32-bit byte count would overflow above 4 GB).
* The testbench checks both fields, and that the init launch issued no AR or AW on the tree port.

### Host (`vitis/host_doma.cpp`, shared)

Additive; without the new option or variable the DOMA path is unchanged (checked: identical
output to the step 5.2 host against a functional mock of XRT, with and without `DOMA_N`,
`DOMA_BLOCK`, `DOMA_PACK`, `DOMA_PAGES_HBM`).

| Item | Behaviour |
|---|---|
| Kernel selection | `./host_doma <xclbin> [CMD_SIZE] [--kernel tinyoram_kernel]`, or `DOMA_KERNEL=tinyoram_kernel`. Default `doma_kernel`. |
| Arguments | DOMA: 8 (cmd, resp, pages, size, meta, brec, stash, nblk). Tiny ORAM: 4 (cmd, resp, pages, size). meta/brec/stash are allocated only for DOMA. |
| `DOMA_N` | Records, for both kernels. For Tiny ORAM the host derives L (smallest with 4·2^L ≥ N) and refuses a bitstream with a different N, naming the L it needs. Unset: the bitstream's N. |
| `DOMA_BLOCK` | Sizes Tiny ORAM's tree buffer before the first launch (default 4096, which covers every block size at the same L). If the bitstream's tree is larger than the buffer, the host stops and prints the `DOMA_N`/`DOMA_BLOCK` to use. |
| `DOMA_PACK` | Refused for Tiny ORAM until Phase 2 (allowed since then, §11). |
| Output | Tiny ORAM prints its geometry after init, and per run the three latencies: data ready, last write-back beat, write-back acknowledged (min..max). The traffic line prints for both kernels. |

The host's tree-size formula is a port of Tiny ORAM's `BucketLocal.vh`; it matches the RTL's
own value at 64 B, 128 B, 256 B and 4 KB for L = 6, 14, 18 and 22 (16 points).

### Build scripts

* `fetch_tinyoram.sh <size> [L]`: optional tree depth (6..26), written into the build's
  configuration header. The default stays L = 6.
* `build_tinyoram.sh`: `N=<records>` picks L (one bitstream per N; xclbin
  `tinyoram_<size>_n<N>_<target>.xclbin`), passes the same post-placement hook as `build.sh`
  (`post_place.tcl`, hardware builds only), and prints the host command with the matching
  `DOMA_KERNEL`, `DOMA_BLOCK`, `DOMA_N` and (for `tinyoram_hw.cfg`) `DOMA_PAGES_HBM=1`.
* `check_timing.sh` / `worst_paths.tcl` (shared): `XCLBIN` and `XDIR` overrides (defaults
  `doma_hw.xclbin`, `_x`), kernel-name-neutral path names; `WANT_MHZ` was already there.

### Tree sizes (bytes, from the RTL)

| Block | L = 6 | L = 14 | L = 18 | L = 22 |
|---|---|---|---|---|
| 64 B | 49,536 | 18,923,904 | 207,667,584 | 4,032,872,832 |
| 128 B | 123,520 | 23,634,560 | 505,979,520 | 5,539,144,320 |
| 256 B | 185,472 | 38,966,400 | 642,946,176 | 10,910,602,368 |
| 4 KB | 3,517,056 | 901,769,856 | 14,428,400,256 | 230,854,486,656 |

An HBM pseudo-channel holds 512 MB, so with the tree in HBM[8] the unpacked 64 B build tops
out at L = 18 (1M blocks). With 8 records per block (Phase 2), 1M records need L = 15 and 10M
records L = 19, both within one bank.

## 11. Phase 2: packed records (2026-10-13)

`tinyoram/rtl/tinyoram_kernel.v`, following `doma_kernel.v`'s packed-record layout:

| Item | Behaviour |
|---|---|
| Header | bytes 8–11 record offset in the block, 12–15 record length; length 0 = whole block (all unpacked commands). |
| Range check | `length != 0` and (`offset >= block` or `length > block - offset`): status **0x40**, no Tiny ORAM access. Checked for GETs and PUTs (DOMA checks PUTs only, since its GETs return the whole block). |
| PUT | Tiny ORAM's own byte write mask (`WMask`, one bit per byte) selects the record. The kernel builds it 128 bytes per cycle before issuing the command: 1 cycle at 64 and 128 B, 2 at 256 B, 32 at 4 KB (before the latency counter starts, like DOMA's issue). The PUT data fed to Tiny ORAM is zero outside the record. |
| GET | Only the record's bytes are written into the response slot (byte strobes on `gmem1`, a burst covering just the record's beats); the rest of the slot is untouched. |
| Slots | Block-sized: command data at `HC + i·BLOCK`, GET data at `HR + i·BLOCK`, as DOMA. |
| Summary | bytes 4–7: block size in 32-byte beats, as DOMA. The host reads it and lays out its buffers to match. |

**Why the PUT data is zeroed outside the record.** Tiny ORAM turns the first write to a block into an
`Append` of the whole block, and the mask is applied only to `Update`s (`IntegrityVerifier.v`: the read
block and the new data are merged under the mask). Without zeroing, a record written into a
never-written block would carry the host's slot contents around it. With it, the bytes around a first
record are zeros, which is what a never-written block reads as. In the host's flow every block is
written by the preload first, so this only matters for byte-exactness in the tests.

**Unchanged:** whole-block commands (length 0) take the same path as before plus one cycle for the
check, so unpacked latencies are as in Phase 1. A GET of a block that was never written returns
whatever Tiny ORAM returns (stale data from its buffers); the host never does this, since it preloads
every key.

**Tests** (`sim/run_tinyoram.sh`, at 64 B and 4 KB, mirroring DOMA's packed kernel tests):

* `+packed=8 +preload`: the preload writes every block whole, then 8-byte records with junk around
  them in each PUT slot. Every GET is checked byte for byte against an image of the block; bytes of the
  response slot outside the record must keep their poison. Run 2's bad command is a PUT whose range
  runs past the block (0x40). A last launch GETs 64 whole blocks (length 0), which checks every byte of
  the image, and ends with a GET whose range runs past the block (0x40).
* `+packed=16 +host_wlat=200 +host_gap=30`: the same with writes landing 200 cycles late and 30% gaps
  in read data, without preload, so records are also written into never-written blocks.
* `+ranges +preload +host_gap=30` (all four block sizes): records at random byte offsets and lengths,
  crossing beat boundaries anywhere and up to the whole block, with one command in eight a whole-block
  command. The verify launch ends with four bad ranges: past the end, an offset beyond the block, a
  wrapping length (0xFFFFFFF8) and a length beyond the block. Each must come back 0x40 with its data
  slot untouched. This test was added after an independent review of the RTL found that the packed tests
  alone would miss two mutations: a wrong last-beat formula, and a mask not restored to all ones after a
  partial PUT. The test catches both (checked with the two mutants).

**Implementation notes.** The byte enables of a beat come from the record's first and last beat and two
32-bit edge masks, all registered when the command is checked, so the per-beat logic is two
comparisons and an AND. The 4,096-bit mask is reset to all ones when the header arrives, not at the end
of the command checks. The kernel refuses (in simulation) a block size that is not a power of two, or
a build without PMMAC: Tiny ORAM applies `WMask` in its integrity verifier, so without PMMAC a packed
PUT would overwrite the rest of the block with zeros.

**Host:** `DOMA_PACK=1` now works for Tiny ORAM, with the same meaning as for DOMA (block/8 records per
block). `DOMA_N` stays records: the host divides by the records per block to get the blocks and L.
Command and response buffers are block-sized. `build_tinyoram.sh PACK=1` picks L the same way.

## 12. Phases 3 and 4: on the card

`docs/TINYORAM_CARD_RUNBOOK.md`: the commands, in order, with the output to expect at each step and
what to report.

## 13. Audit fixes before the card (2026-10-13)

**Re-boot on every init launch** (`tinyoram/rtl/tinyoram_kernel.v`, as `doma_kernel.v` now does).
XRT does not reprogram the card between host processes that use the same xclbin. Before this fix, the
kernel latched the tree buffer for its lifetime, so a second host run would either get error `0x20` (its
buffer at a new address) or silently inherit the previous run's ORAM. Now:
* Every launch with `size = 0` holds Tiny ORAM and the adapter in reset (state `K_RST`, 16 cycles; the
  reset continues until the tree is filled), latches `pages` again, and reports the geometry without
  touching memory.
* The next launch with commands zero-fills the tree again and releases Tiny ORAM. Its reset
  re-initialises the on-chip state (PosMap, PLB, stash).
* `0x20` is only for a launch with commands that names a different buffer than the last init launch.
  The latched buffer is kept.
* While filling, the zero-fill counts only its own write responses and never goes below zero, so a
  stray response left over from an aborted run cannot stall it.

Tests (`+reboot`, every block size; `+reboot +reboot_same` at 64 B):
1. A first session: init, preload, runs, and the packed verify launch.
2. A second init with the tree buffer moved to another address (or, with `+reboot_same`, at the same
   address). The init must touch no memory.
3. A probe. One record goes into each of blocks 0–7, which the first session had filled, and then each
   whole block is read back. A fresh ORAM returns the record with zeros around it; a kept ORAM
   returns the old block.
4. Commands and a verify launch, checked against a fresh reference model.
5. A launch with commands naming yet another buffer. It must report `0x20`, keep using the latched
   buffer, and stay correct.

Throughout, every tree burst must fall inside the buffer latched by the last init launch. Mutants:
* not resetting Tiny ORAM at init: caught by the probe;
* not re-latching `pages`: caught by the address monitor and the summary.

**Check order.** `K_CHK` now follows `doma_kernel.v`'s order: opcode (0x2), then the range of a PUT
(0x40), then a halted ORAM (0x8), then the key (0x4). Only after those does it check the range of a GET
(0x40), which is Tiny ORAM only, since `doma_kernel`'s GETs return the whole block. So a command with
both a bad range and a bad key gets the status DOMA gives it: 0x40 for a PUT, 0x4 for a GET. The verify
launch tests both cases, and the Phase 2 order (range first for GETs too) fails it.

**Testbench random numbers.** `$random(seed)` is replaced by two xorshift32 generators, as in
`tb_stash.v`: one for commands and the stale tree contents, and one for packed mode's offsets, lengths and
junk. In Verilator, `$random(seed)` produced degenerate sequences that touched few distinct keys. All
checks and the mutation checks were rerun with the new generators. The Phase 4 simulation
(`docs/tinyoram_l15_sim_2026-10-13.txt`) was also rerun, because its traffic figure depends on how many
distinct blocks the commands touch.

## 14. Changes for a fair comparison with DOMA (2026-10-18)

Requested in the comparability note of 2026-10-18. Everything here is in Tiny ORAM's own files and
the host's Tiny ORAM path. Tiny ORAM's RTL changes only through the optional patch 07, whose default
leaves it as published.

### Kernel front end, as doma_kernel's (`tinyoram/rtl/tinyoram_kernel.v`)

* **Prefetch.** A fetcher reads command k+1's header while command k is in `K_WAIT`; for a PUT it
  also reads the data into a block-sized buffer (2 beats at 64 B, 128 at 4 KB). Every run start
  clears it. A request stays pending until the fetcher takes it, so a rejected command can't drop it.
* **Posted response writes.** GET data and headers are written without waiting for their B responses.
  `wb_pend` counts them, and the run waits for all of them once, before the summary.
* **Early release (the latency end point).** A command ends when its data is done and Tiny ORAM is
  idle with every write-back beat handed off on the bus. That is the primary latency (header bytes
  8–11, summary min/max), the same end point as DOMA's arrival mode. The next command is issued then;
  the adapter still holds its reads until every write is acknowledged, exactly as before. The
  command's header waits in a one-entry queue until then, so header bytes 20–23 can carry the latency
  to write-back acknowledged. Bytes 16–19 are still data ready.
* **Saving:** in simulation (64 B, 100-cycle memory), the same 120 commands take 33,439 device cycles
  instead of 39,749, about 52 cycles per command.

### Merged bursts (B6), adapter option `TINYORAM_MERGE` (`fetch_tinyoram.sh ... merge`, `build_tinyoram.sh MERGE=1`)

* **What merges:** consecutive commands of the same direction to contiguous addresses become one
  AXI burst. A burst never crosses 4 KB or the tree-top split. It closes on a command that does not
  continue it, after 4 idle cycles, or at a limit.
* **Result:** at 64 B a read burst is 12 beats, one 384-byte bucket; buckets on a path are not
  contiguous, because the path leaves its subtree. At 4 KB a 16.5 KB bucket becomes 4 KB bursts.
* **Ordering:** the read-behind-unacknowledged-write hold is kept, on both ports.
* **Effect in simulation:** at 64 B with 1M-record geometry (L = 15, packed), 200 commands take
  268,212 cycles merged against 403,362 with the 1:1 adapter, with the same traffic.
* **The 1:1 adapter remains the default** (`TINYORAM_MERGE 0`). It is Tiny ORAM as built for its
  DDR3 controller, and is reported too.

### Tree-top split (matched on-package budgets)

* **Interface:** the kernel has a fourth memory port, `top` (`m_axi_gmem3`, HBM), and a scalar
  `top_bytes`. Tree byte offsets below `top_bytes` live in `top`; the rest live in `pages` (host
  memory in the headline configuration).
* **Why a byte prefix is the tree top:** Tiny ORAM lays the tree out subtree by subtree, in
  breadth-first order (`AddrGenBktHead.v`: bucket index = index in subtree + subtree index ·
  2^L_st). At 64 B, a subtree has L_st = 7 levels and occupies 49,152 B.

  | Geometry | Subtree | Top prefixes (bytes) | Whole tree |
  |---|---|---|---|
  | 64 B, L = 15 (1M records packed) | 7 levels | levels 0–6: 49,152; 0–13: 6,340,608 | 31,506,816 B |
  | 4 KB, L = 12 (16,384 blocks) | 2 levels | 0–1: 66,048; 0–5: 1,387,008; 0–9: 22,522,368 | 225,438,336 B |
  | 4 KB, L = 14 (65,536 blocks) | 2 levels | 0–9: 22,522,368; 0–11: 90,155,520 | 901,769,856 B |

  Any byte count works. A count between two subtree levels covers part of the next level's
  subtrees. The split is a fixed address map, so it reveals nothing about the access pattern.
* **Host:** `DOMA_TINY_TOP=<bytes>` (`all` = the whole tree on-package). The host prints the
  placement and the per-record bytes on-package and in `pages`. The kernel rounds a count below the
  tree down to 4 KB and flags it (summary error 0x80 at init).
* **Matched budgets:** `DOMA_TINY_TOP=doma:<p>` makes the top the bytes `doma_kernel` keeps on-package
  at `<p>`% HBM for the same records. That is its position map, bucket records, stash and HBM buckets,
  sized as the host sizes DOMA's buffers. The blocks are `DOMA_MATCH_BLOCK` bytes (default 32), packed
  as `DOMA_PACK` says. Against the buffers the host actually allocates for `doma_kernel` (checked under
  the XRT mock), the figures agree to the byte. For 1M 8-byte records:

  | DOMA point | DOMA on-package | Tiny ORAM top (4 KB multiple) | Share of the tree |
  |---|---|---|---|
  | 0% HBM | 8,076,960 B | 8,073,216 B | 25.6% |
  | 20% | 10,076,960 B | 10,076,160 B | 32.0% |
  | 100% | 18,076,960 B | 18,075,648 B | 57.4% |

  So even at DOMA's 100% point, Tiny ORAM keeps a little over half of its tree on-package, because its
  tree (31.5 MB at Z = 4 with headers and MACs) is larger than DOMA's whole footprint. With
  `DOMA_TINY_FLATPM=1` (for a `FLATPM=1` bitstream), the 1 MB on-chip position map comes off the top.
* **Zero-fill:** at the first command launch it covers both regions.
* **Ordering across ports:** read data from the two ports reaches Tiny ORAM in command order, through
  a per-burst order FIFO and one read buffer per port. Write data follows the same rule.
* **Traffic record:** counts both ports.
* **Link configs:** `tinyoram_hw.cfg` maps `top` to HBM[9]; `tinyoram_host.cfg` maps `pages` to
  HOST[0] and `top` to HBM[8] (HBM[8:15] from 2026-10-21, §22).

### Sweeps: `scan.sh` with `DOMA_KERNEL=tinyoram_kernel`

The same script, host, command stream and CSV columns as DOMA's sweeps. For Tiny ORAM, `NS` must be
the bitstream's own record count, and the second axis is the tree-top setting `TOPS` (default
`0 doma:0 doma:20 doma:100`) in place of `HBMS`. It goes in the `hbm_pct` column. `0` is the
whole tree in host memory, the headline comparison with DOMA at 0% HBM; `doma:<p>` are the matched
budgets. Each run's full output (latency spread, histogram, placement, traffic) goes to a `.log` next
to the CSV. With `doma_kernel`, `scan.sh` behaves exactly as before (its CSV checked unchanged under the
XRT mock).

### Position map under both trust assumptions (patch 07, `fetch_tinyoram.sh ... flatpm`, `build_tinyoram.sh FLATPM=1`)

* **(a) As published.** PosMap recursion with the PLB: at L = 15, 4 levels (3 PosMap ORAMs in
  untrusted memory).
* **(b) Same trust as DOMA.** `TINYORAM_RECURSION 1` is a one-line override of the recursion depth in
  Tiny ORAM's `UORAM.vh`. Tiny ORAM then keeps all N position-map entries on chip (64-bit PRF
  counters: 1 MB at 131,072 blocks, block RAM or URAM) and has no PosMap ORAMs.
  * **Budget:** that 1 MB is trusted on-package storage and counts against the matched budget.
  * **Bias:** it is on chip rather than in HBM, which favours Tiny ORAM slightly over an HBM position
    map: no HBM round trip per access. Moving it to HBM would need a new PosMap memory with a latency
    protocol inside Tiny ORAM's frontend. That is not done; this is a stated limitation.
  * **Simulation (64 B, L = 15, packed, merged, no preload):** 200 commands take 81,387 cycles flat
    against 268,212 recursive, and move 103 beats each way per command against 356.

### Latency spread and timing protection

* **No timing protection.** Tiny ORAM as published pads nothing. Its latency varies with background
  evictions, PLB hits and, with recursion, the number of PosMap ORAM accesses. DOMA pads every access
  to calibrated budgets (arrival-relative scheduling, about a quarter of each access). **So DOMA's
  figures include its timing padding and Tiny ORAM's do not.**
* **What the host reports for Tiny ORAM:** min, p50, p90, p99, p99.9, max and mean of the primary
  latency, and a 16-bin histogram, from every command's header. `DOMA_LAT_HIST=1` prints the same for
  doma_kernel; without it, DOMA's output is unchanged.

### Independent review of this rewrite, and what changed after it

A separate read of the new adapter and command engine found no defects in the adapter. It found four in
the kernel's new paths, all fixed and now tested:
1. **A write error after release was not charged to its command.** A SLVERR/DECERR arriving after a
   command was released now marks that command's queued header 0x8 and the summary. The new `+berr=K`
   test injects SLVERR on the K-th tree write response. The run must report 0x8 in the summary and on
   the header of the command that write belongs to (the released command whose header waits for its
   acknowledgements, otherwise the command in progress), without hanging; a re-boot must follow and the
   fresh run after it must be correct.
   The summary's completed count (bytes 28–31) leaves such a command out, so it always equals the
   number of headers without an error; the fault runs check that. (Its latency stays in the summary's
   min/max, which cover every released command.)

   A later test found the same-cycle race behind this: the adapter decrements its count of
   outstanding writes and sets its error flag on the same edge. So when the failing response was the
   last one outstanding, "all acknowledged" and the error showed together, and the header queue took
   the first. That released the header clean and charged the error to the next command. It showed at
   128 B, merged, with the split. Now an error wins over "all acknowledged" in three places:
   * in the header queue;
   * in `K_WAIT`, where a halted ORAM is an error even if the write-back has been handed off;
   * in `K_HQ`, where a released command is charged if the ORAM halted before its header was queued.
     Only that command's writes can be in flight then: the next command has not started, and Tiny
     ORAM is idle, so its integrity checks are done.
2. **The acknowledged latency undercounted.** After release the counter now keeps running through the
   GET write-back and the header queue, and the acknowledgement time is captured whenever it happens.
3. **An error flag could be lost** when two parts of the engine set it in the same cycle. Errors found
   while a header waits now go to their own register, OR-ed into the summary.
4. **Re-boot after an aborted run.** The init launch now lets any traffic left in the adapter finish
   (bounded by the command timeout) before resetting it. `K_BOOT` has a timeout. The run's end waits,
   bounded, for Tiny ORAM and the adapter to be idle, so the traffic record includes an access Tiny ORAM
   finishes after a fault. A zero-fill write error now halts the ORAM (0x8).

Two test gaps it pointed out are also closed:
* **A one-command run before run 1:** a prefetch left over from it must not leak into the next run.
* **A monitor on command reads:** only headers and data slots of the current launch's commands may be
  read, which catches prefetching past the last command.

Known and accepted:
* **Early release needs its 2-cycle filter.** Tiny ORAM reports idle for one cycle while a write
  command still sits in a register before its DRAM port, so releasing after one idle cycle would end
  the latency count 1–2 cycles early. Data stays correct either way, because the adapter's
  read-after-write hold still applies.
* **Write channel ordering.** Every master here asserts WVALID only after AWREADY, as `doma_kernel`
  does. The Xilinx interconnect and HBM accept that; a slave that waits for WVALID before AWREADY
  would not.
* **Buffer alignment.** XRT buffers are 4 KB aligned, which the 4 KB burst rule assumes.

### Tests and mutation checks

`sim/run_tinyoram.sh`: 81 checks over the four block sizes (log: `docs/tinyoram_regression_2026-10-18.txt`).
Per size, with the 1:1 adapter: e2e, late, gaps, wlat, xinit, reboot, split, fault, faultlast,
faultearly, ranges; packed8 and packed16 at 64 B and 4 KB; rebootsame at 64 B. With the merged adapter
(its own build): m_e2e, m_gaps, m_wlat, m_split, m_fault, m_faultlast, m_faultearly, m_topall.

Fault injection (the testbench drives SLVERR on a tree write response; every fault run must report
0x8 in the summary and on the header of the command the write belongs to, the summary's completed
count must equal the headers without an error, and a re-boot and a correct fresh run must follow):

| Option | Where the error lands |
|---|---|
| `+berr=K` | the K-th write response of the run (in practice, while a command runs) |
| `+berr_rel` | the first response while a released command's header waits for its acknowledgements |
| `+berr_last` | the last response outstanding then (the error and "all acknowledged" show in the same cycle) |
| `+berr_early` | after a GET's release, before its header is queued: the testbench stalls the response port, as a slave may, until one of the GET's tree write responses arrives |

The fault-after-release checks need a response still outstanding at the release: writes land 200
cycles late, 2,000 at 4 KB, where Tiny ORAM reports idle long after its last write beat.

`sim/run_tinyoram_mutants.sh` (new): 16 mutation checks at 64 B, each a deliberate bug in the kernel or
the adapter, and each must be caught (log: `docs/tinyoram_mutants_2026-10-18.txt`).

| Mutant | Test | Caught by |
|---|---|---|
| m1 wrong last-beat formula | `+ranges` | hang at the cycle limit |
| m2 mask not restored after a partial PUT | `+ranges` | verify mismatch |
| m3 no core reset at init | `+reboot`, `+reboot +reboot_same` | hang in `K_RST` |
| m4 `pages` not re-latched | `+reboot` | summary wrong |
| m5 Phase 2 check order | `+packed=8` | GET with a bad range and a bad key gets 0x40 |
| m6 prefetch not cleared at run start | default | run 1's first command runs a stale prefetched header (wrong key) |
| m8 prefetch past the last command | default | command-read monitor |
| m9 error after release not charged to its header | `+berr_rel +host_wlat=200` | header without 0x8 |
| m10 such a command still counted as completed | `+berr_rel +host_wlat=200` | summary count ≠ headers without error |
| m11 "all acknowledged" tested before the error in the header queue | `+berr_last +host_wlat=200` | header without 0x8 |
| m13 no charge in `K_HQ` for an error before the header is queued | `+berr_early +host_wlat=200` | header without 0x8 |
| a1 reads not held behind unacknowledged writes | `+host_wlat=200 +preload` (and `+packed=8`) | Tiny ORAM's stash check: a block read back twice |
| a2 off-by-one in the tree-top split | `+top=16384` | address monitor |
| a3 merged burst crossing 4 KB | `+top_all +ranges` | address monitor |

Two of these were missed by the first version of the tests, so the tests were strengthened:
* **a1** passed `+host_wlat=200` without a preload. Probably because the tree then holds few real
  blocks, so a read that overtakes a write rarely brings back a stale copy of a block that has moved.
  With the preload, every block is in the tree and the stale copy hits Tiny ORAM's own stash check.
  The late-write tests (`wlat`, `m_wlat`) now preload first.
* **m9** passed `+berr=40`: the error arrived before any command was released, and took the ordinary
  path. `+berr_rel` puts the error on the first write response that arrives while a released command's
  header waits for its acknowledgements, and requires 0x8 on that header. It also found that such a
  command was still counted as completed, fixed above (m10 is that fix's mutant). Running it at every
  size then found the same-cycle race above. `+berr_last` and `+berr_early` were added for it, and
  they run at every size in both builds (`faultlast`, `faultearly`, `m_faultlast`, `m_faultearly`).

Two mutants are left out because they are not bugs in what is checked:
* **m7, releasing after one idle cycle instead of two:** see "Known and accepted" above.
* **m12, `K_WAIT` testing release before `halted`:** `K_HQ` then charges the command, so its header and
  the completed count are still right; only the summary's latency min/max would include it.

### A Tiny ORAM behaviour the tests now model

A GET of a never-written block returns Tiny ORAM's `FakePattern` (0x00af1234, `UORAM.vh`). From then
on the block behaves as written, with undefined contents. This was observed in simulation: a later
partial PUT kept non-zero bytes around its record. The testbench's block image marks such bytes as unknown. The host
never does this: its preload writes every record first.

## 15. Before the builds: checks and card scripts (2026-10-18, second note)

### Vivado's "already declared" error (item 2)

Vivado treats a name used in a port connection before its declaration as an implicit wire, then rejects
the later declaration. Verilator accepts it. `run_tinyoram.sh` now starts each size with
`iverilog -Wimplicit` over the kernel, the adapter and the fetched core, for the 1:1, merged and
flat-position-map variants (their generate branches differ):
* **The kernel and the adapter:** no implicit nets.
* **The core:** eight implicit nets (`AESREWORAM.v` 535–538, `PathORAMBackend.v` 369–380 since patch 08, 359–370 before). All are in the
  REW-ORAM branch (`EnableREW = 1`), which this build does not elaborate, and none is declared later. They
  are listed exactly in the script; anything else fails.
* **One iverilog-only workaround:** iverilog cannot size `DataIn + j` in `AES_DW.v` (a genvar), which Vivado
  does. The lint therefore sizes it in a lint-only copy; the core is built as published.
* **Mutant l1** (a name used before its declaration in the kernel) is caught.

### The read-behind-write hold under slow acknowledgements (item 3)

* **The test** (`slowack`, `m_slowack`, every size, both adapters): after the preload, tree writes are
  acknowledged 2,000 cycles after their data (6,000 at 4 KB), longer than a whole path write-back. The
  models hold all of it, through `axi_mem_model`'s `WF_DEPTH` and a new `AW_DEPTH` parameter (default 16,
  as before). The longest hold must reach 1,000 / 3,000 cycles: the next path's reads did wait for the
  acknowledgements. At 4 KB both adapters hold reads for up to 5,051 cycles.
* **A bus monitor, on in every test:** it fails any tree read that overlaps a write not yet
  acknowledged, which is the read that would return stale data.
* **Mutant a1** (no hold), at 4 KB on both adapters: the 1:1 build fails with Tiny ORAM's own stash check
  (a block not found), and both are caught by the monitor at the root bucket. The merged build's stale
  reads did not change any result: the top buckets of a Path ORAM tree hold mostly dummy blocks. That is
  why the monitor, not the data, is the criterion.

### Addresses above 4 GB (item 4)

* **Offsets:** the adapter's tree offsets are Tiny ORAM's DRAM address times 8 in 64 bits, and every
  base + offset is a 64-bit sum. Tiny ORAM sizes its DRAM address to its tree. The kernel's tree size,
  zero-fill offsets and split point are 64-bit too.
* **Tested:** the testbench's tree and tree-top buffers now start 16 KB below a 4 GB boundary, so every
  tree crosses one. A 32-bit base + offset sum (mutant a4) is caught: Tiny ORAM's stash check stops on
  the wrapped addresses before the address monitor has to.
* **Limits that remain** (documented, not fixed):
  * `top_bytes` is a 32-bit argument, so the on-package top is at most 4 GB − 4 KB, and `all` means the
    whole tree only for a tree under 4 GB. The top buffer was one HBM bank (HBM[8], 512 MB); since 2026-10-21 it spans
    HBM[8:15], 4 GiB (§22).
  * The traffic record gives the tree size in 32 bits of 64-byte bursts (256 GB), and the top port's
    traffic in 28 bits of 64-byte units per direction and launch (17 GB).
* **Planned trees:**

  | Build | Blocks | L | Tree |
  |---|---|---|---|
  | 64 B, 1M records packed | 125,000 | 15 | 31.5 MB |
  | 64 B, 100K packed | 12,500 | 12 | 3.2 MB |
  | 64 B, 10M packed | 1,250,000 | 19 | 409 MB |
  | 4 KB, N = 16K | 16,384 | 12 | 225 MB |
  | 4 KB, N = 64K | 65,536 | 14 | 902 MB |

### Counts

`run_tinyoram.sh` now has 93 checks: the 81 of §14, plus the lint at each size (4) and `slowack` and
`m_slowack` at each size (8). `run_tinyoram_mutants.sh` has 21, adding l1, a4, a1 at 4 KB on both adapters,
and (§16) l2. Logs: `docs/tinyoram_regression_2026-10-18.txt`, `docs/tinyoram_mutants_2026-10-18.txt`.

### Traffic by port

The traffic record's free bytes 1–7 now carry the top port's share (64-byte units). The host prints
`traffic split: pages (off-package) … ; top (on-package) …` per command, so at a matched budget Tiny ORAM's
host-memory traffic is measured, as DOMA's is.

### Card scripts (`tinyoram/card/`, items 1 and 5–7)

| Script | What it does | Pass |
|---|---|---|
| `install_tinyoram.sh <base.zip> <overlay.zip> [DEST] [--check]` | Verifies the base's manifest. Overlays Tiny ORAM's files. Replaces a shared file whole only if the base has the version the overlay was made from, otherwise applies `docs/tinyoram_fair_shared_files.diff` and stops if it does not apply. Regenerates and verifies the manifest. Makes one copy per bitstream. `--check` runs DOMA's regression at both sizes and both Tiny ORAM regressions. | `INSTALL OK` (with `--check`: `…, ALL REGRESSIONS PASSED`) |
| `bringup_64.sh ooc / link / emu / hw / card` | Runbook 3.2–3.5 at 64 B, L = 6. The out-of-context check covers both adapters. `link` (§19) is a v++ link at a clock other than 300 MHz, stopped before synthesis. Emulation uses merged bursts with the tree in HBM. The board build is the headline configuration at small size: merged, tree in host memory. Card runs exercise the split, the whole tree on-package and a back-to-back run. The post-placement check is automatic. Every step appends to `bringup_report.txt`, which is what to send back. | each step's last line |
| `queue.sh start / status / pause / stop / reset` | The 7 builds of `queue.txt`, one at a time, each in its own copy. Out-of-context timing at that geometry comes first; a failure skips the board build and gives the reachable clock. The board build is stopped if post-place WNS < −0.5 ns. Then `check_timing.sh`'s verdict. | `DONE` per entry |
| `sweep_tiny.sh` / `sweep_doma.sh` | `scan.sh` with matching settings. Tiny ORAM: `TOPS="0 doma:0 doma:20 doma:50 doma:100"`, matched budgets for DOMA's 32-byte blocks packed 4 per block (4 KB unpacked for the 4 KB builds). DOMA: `DOMA_PACK=1 NS="100000 1000000 10000000" HBMS="0 20 50 100"`. Logs keep latency spread, placement and traffic for both. `test_card_scripts.sh` dry-runs `sweep_tiny.sh` and `accept_rt.sh` against the XRT mock (§20). | `PASS` per bitstream |
| `merge_results.py` | One table per configuration from both designs' results: KQPS, primary latency (p50, p99, max; max also in µs at the clock), off- and on-package bytes per command, on-package and host bytes per record, clock. | writes `comparison.md` and `comparison.csv` |

All five were dry-run here against stand-ins for XRT, Vivado and v++ (no tools here). That covered the
install on your package and on a base with newer shared files, and a conflicting base that must stop
the install. It also covered the bring-up's card checks passing and failing, the queue's DONE,
FAILED_OOC and FAILED_PLACE paths (the build is stopped), and the sweep → merge chain.

DOMA's host gets two opt-in lines for the table, neither changing its default output (checked in 11
configurations):
* **`DOMA_PLACEMENT=1`:** DOMA's on-package and host bytes per record.
* **A cross-check:** a warning appears if the matched-budget sizes ever differ from the buffers the DOMA
  path allocates. It never fired.

`scan.sh` gets `SCAN_LOG=1`, which keeps DOMA's full output.

### To state with the results (item 8)

* **Timing protection:** DOMA pads every access to fixed budgets and handles GETs and PUTs identically,
  so they look alike on the bus; it pays a small cost for this. Tiny ORAM has no timing protection, and
  it prefetches only PUT data.
* **Variant (b):** Tiny ORAM's position map is on chip, which saves it an HBM round trip per access
  compared with DOMA.
* **DOMA's 0% point:** DOMA still keeps about 8 MB on-package (per 1M records). The `0` run gives Tiny
  ORAM nothing on-package; `doma:0` gives it the same 8 MB.

`merge_results.py` prints these at the top of `comparison.md`.

## 16. A dead upstream file stopped Vivado (bring-up, 2026-10-18 evening)

**What happened.** The bring-up's `ooc` step failed in Vivado with `[Synth 8-36] 'LastBuckerAddr' is not
declared [DRAMInitializer.v:96]`, then `module 'tinyoram_kernel' not found`.
* **Why Vivado:** `DRAMInitializer.v` is unused upstream (nothing instantiates it at 18ece07), and
  `LastBuckerAddr` is defined nowhere. Vivado analyses every file it is given: the out-of-context script
  reads `files.f`, and `package_tinyoram.tcl` globs every `.v` in `build/src`. So the dead file broke the
  out-of-context run, and it would have broken every board build.
* **Why not the simulators:** Verilator and the iverilog lint elaborate only from `tinyoram_kernel`, so
  they never looked at it.

**Fixes:**
* **`fetch_tinyoram.sh` leaves out dead files.** These are files whose modules no other file names, in
  any configuration (`DRAMInitializer`, `aes_192`, `aes_256`, `ClockSource`, `FIFOLinear`, `LFSR`,
  `ROISeedGenerator`, `SynthesizedRandDRAM`), plus the `DRAM2RAM`/`SynthesizedDRAM` pair, which only
  each other and `SynthesizedRandDRAM` name. That makes 72 sources into 62.
  * **How "dead" was decided:** Verilator's elaborated module list, over all four block sizes, the 1:1,
    merged and flat-position-map variants, with and without `SIMULATION`. None of the ten has a module
    in any of them.
  * **What stays:** files named by an inactive generate branch (the REW-ORAM files, `Bin2Gray`/`Gray2Bin`,
    `padder1`), so every tool still finds the modules those branches name.
  * **`aes_192`/`aes_256`** also instantiate their rounds with the wrong number of ports, a second trap of
    the same kind.
* **`vitis/elab_tinyoram.tcl`:** a one-minute Vivado elaboration (`synth_design -rtl` of
  `tinyoram_kernel`) of exactly the files the builds read. It runs:
  * in `build_tinyoram.sh` after the fetch, before packaging, for every board and emulation build
    (`ELAB=0` skips it);
  * in `bringup_64.sh ooc` before each out-of-context run;
  * in `queue.sh` before each entry's out-of-context run.

  A source error now fails in a minute, not hours.
* **`sim/lint_tinyoram.sh`** (used by `run_tinyoram.sh`): besides the elaboration from the top, it
  elaborates every module of every source file as its own top, as Vivado analyses every file. It fails
  on undeclared or unbound names, unknown modules, port mismatches, syntax errors, and unlisted implicit
  nets.
  * **What it reports:** with the dead files left out, 74 modules, all clean. Three (`DM_Cache`,
    `Keccak_WF`, `REWStatCtr`) show only `CountAlarm`'s zero-width replication with their default
    parameters as their own top; in the design their parameters are set.
  * **New mutants:** l2 puts `DRAMInitializer.v` back and is caught; so is `aes_192.v` put back.

**`AES_DW.v:146`** (`{{(AESWidth-AESEntropy){1'b0}}, DataIn + j}`, which iverilog will not size).
* **By the standard:** a genvar is a 32-bit integer, so the operand is sized. `DataIn` is
  `AESEntropy` = 64 bits, the sum is 64 bits, and the concatenation is exactly `AESWidth` = 128 bits.
  Verilator computes it this way, and the regression's AES results depend on it.
* **Not confirmed in Vivado here:** there is no Vivado in this environment. The module is in the
  design (`PRNG` instantiates `AES_DW`), so the elaboration step elaborates this line: if Vivado rejected
  it, `elab_tinyoram.tcl` would fail there, within a minute.

## 17. The 4 KB queue geometries and the PosMap depth (2026-10-18, night)

**What happened.** `lint_tinyoram.sh` failed for queue entries q6 (`4k_n16K_merge`, L = 12) and q7
(`4k_n64K_merge`, L = 14): `CountAlarm.v:97: error: Concatenation repeat may not be zero`. The regression
had linted every block size only at its default depth, L = 6, so it never saw these geometries.

**The instance:** `tinyoram_kernel.u_tiny.front_end.uoram.PPP.PosMapInitCounter` (`PosMapPLB.v:93`,
`CountAlarm #(.Threshold(FinalPosMapEntry))`). Its threshold is 0, not 1: `CWidth = log2(0) = 0`, hence `{0{...}}`.
It counts through the on-chip final PosMap at initialisation, and `FinalPosMapEntry` is the size of that PosMap.

**Why it is 0.** Tiny ORAM's depth rule (`UORAM.vh`) is "recursive until < 1024 entries in PosMap", written
as `divceil(L + 2 − 10, 4 − PRFPosMap) + 1`. That is 3 bits per level, because a 64 B PosMap block holds 8
leaves (`LeafInBlock = ORAMB / 64`; 64-bit PRF leaves). A 4 KB block holds 512 leaves, which is 9 bits per
level. So the 3-bit form adds levels that have nothing left to hold:

| Geometry | Tiny ORAM's form | Final PosMap | Same rule, 9 bits per level | Final PosMap |
|---|---|---|---|---|
| 4 KB, L = 12 (16,384 blocks) | depth 3 | 16,384 / 512² = **0** | depth 2 | 32 entries |
| 4 KB, L = 14 (65,536 blocks) | depth 3 | **0** | depth 2 | 128 entries |
| 64 B, any L | ⌈(L − 8)/3⌉ + 1 | 1..1024 | identical | identical |

* **At 4 KB with L ≥ 12, the published formula gives a design with an empty final PosMap.** A
  zero-entry PosMap with a zero-width counter is not a real configuration. Neither Verilator nor iverilog
  will build it (IEEE 1800-2017 §11.4.12.1 allows a zero replication only inside a larger concatenation),
  so no simulator ever ran it. Whatever Vivado does with it would not be meaningful either.
* **Why not widen `CountAlarm` instead:** `CWidth ≥ 1` would compile, but it would hide the empty PosMap
  rather than fix it. It would also change a core file every geometry uses.

**Fix: `fetch_tinyoram.sh` applies the same rule at the block's real width.**
* **The rule:** `divceil(L + 2 − 10, log2(ORAMB/64)) + 1`.
* **Where it is written:** through patch 07's existing `TINYORAM_RECURSION` define, and only when the
  result differs from Tiny ORAM's form. That leaves 64 B untouched at every L, and so all of q1–q5 and the
  headline.
* **The guard:** the fetch stops if a depth would leave a final PosMap outside 1..1024 entries.
* **What the fetch writes:**
  * 4 KB, L = 12 and 14: depth 2.
  * 4 KB, L = 18: depth 3 (published form: 5).
  * 128 B and 256 B with L ≥ 12: one level less than the published form. There the published form still
    builds, but has a final PosMap far below its own 1,024-entry target, for example 64 entries at 128 B
    with L = 12. Neither size is in the queue.
* **What it costs:** nothing new. The core is unchanged, and this is the case its own comment describes.
  The on-chip final PosMap is 32 / 128 entries.
* **It makes the 4 KB comparison more faithful:** the PosMap ORAM is one level, not two, so a PLB miss
  costs up to one PosMap path fewer than the published formula would charge.

**Checks:**
* **`run_tinyoram.sh`:** a new first stage fetches every `queue.txt` geometry into its own copy, as
  `queue.sh` does, and lints it. That is 7 checks, about two minutes; `SIZES=""` runs only this stage, and
  `QUEUE_LINT=0` skips it.
* **A q6 simulation:** 4 KB, L = 12, depth 2, built with a 256 MB tree buffer. With `+keys=32`, a new
  opt-in testbench option, 32 keys 512 apart sit one per PosMap block, against a PLB of two blocks, so
  PosMap blocks keep being evicted and read back. Packed records, the first 1 MB of the tree on the top port, and 30% read
  gaps are on. Every GET checked. `GEOM_SIM=0` skips it.
* **By hand here:**
  * q7 at L = 14, merged, with a 1 GB tree buffer, 32 keys, the first 1 MB on the top port, and gaps.
  * q6 with the 1:1 adapter, 64 keys, with late writes.

  Both `ALL CHECKS PASSED` (`docs/tinyoram_4k_geometry_sim_2026-10-18.txt`). The testbench's top buffer is
  4 MB, so a split must fit in it, as well as being a multiple of 4 KB (else 0x80).
* **Mutant l3:** q6's geometry with the published depth. The lint catches it at `CountAlarm.v:97`.

## 18. Run-time tree depth (patch 08, 2026-10-19)

**What it is.** Today's builds fix the tree depth L at build time. With `TINYORAM_RTDEPTH`, a build is made for
L_max, and the host picks any L from 6 to L_max at its init launch. The core then runs as the native build of
depth L.
* **What the build serves:** one 64 B build at L_max = 19 (10M records packed) serves the 100K, 1M and 10M points.
* **Fairness requirement:** a run-time-depth build must not walk L_max-long paths for a small N. It must behave
  exactly like the native build of the same L.
* **Acceptance (card):** N = 1M on the L_max = 19 build against the native L = 15 build (queue entry q1). Both
  must give the same throughput and latency within run-to-run noise, at the same clock.
* **Block size stays a build parameter** on both sides, as for DOMA.

### What changes with L, and where the run-time value comes from

`rtdepth/TinyRTGeo.v` holds a table of every depth-dependent quantity for L = 0..31. The table is computed at
elaboration by a constant function that applies the same formulas as Tiny ORAM's headers, so in hardware it is
a 32-entry lookup and a register. The kernel holds the active depth and passes the table row to the core as one
bus (`RTGeo`, `include/RTGeo.vh`). Each module that used a compile-time constant takes it from the bus instead:

| Quantity (native constant) | Used in | Run-time version |
|---|---|---|
| path length `ORAML + 1` | `AddrGen` (`Ready`, `CmdValid`) | the bus's L |
| `PathSize_DRBursts`, `PathSize_BEDChunks`, `PathPSize_BEDChunks` | `BackendCoreController` (two `REWStatCtr`), `DRAMToStash` (`REWStatCtr`), `AESPathORAM` (path counter) | counters with a run-time threshold (`CountAlarmRT`, `REWStatCtr` with `RTChunks = 1`), same terminal test as `CountCompare` |
| `BlocksOnPath` | `Stash` (write-back counters), `StashScanTable` (per-access reset) | from the bus |
| `StashCapacity` | `StashCore` (free-list reset, per-access list rebuild) | from the bus; the free list ends with SNULL at the active capacity, the rebuild stops there |
| levels on a path | `StashScanTable` (deepest bucket a block may go to) | levels below the active leaves count as full, so no block is placed there |
| subtree layout `numTallST`, `(L+1) % L_st`, `numST · L_st` | `AddrGenBktHead` | from the bus: the native build's addresses, bucket for bucket |
| `NumValidBlock` (N) | `UORAMController` (range check, PosMap block addresses) | from the bus |
| `FinalPosMapStart`, `FinalPosMapEntry` | `PosMapPLB` (on-chip PosMap select, address, init count) | from the bus; the on-chip PosMap RAM is sized for 1,024 entries, the largest any depth needs |
| leaf width `ORAML` | `IntegrityVerifier` (PRF leaf), `BackendCoreController` (dummy leaf), `PosMapPLB` (the PLB's leaf tag) | masked to L bits |
| dummy-leaf PRNG width `1 << log2(ORAML)` | `BackendCoreController` | one PRNG per width the build can need (8, 16, 32 bits), same key, the active one selected |
| tree size, N, the records | kernel: zero-fill, key check, tree-top split, record [size+1], adapter range check | from the bus |

Some things stay at L_max size: memories and counter widths, `SNULL`, and the stash's `StashAlmostFull`
expression. `StashAlmostFull` reduces to "occupancy ≥ C − 1" at any L, so it triggers exactly as in the native
build.

**Unchanged without the define.** Without `TINYORAM_RTDEPTH`, patch 08 changes nothing. `sim/check_rtdepth_native.sh`
preprocesses each of the 17 core files it touches with patches 01–07 and with 01–08, then compares them with
comments and white space removed. They are identical in all 8 configurations (4 block sizes, 1:1 and merged). The
regression runs this check.

**The dummy-leaf PRNG.** The native build of depth L draws its dummy-access leaves from a PRNG `1 << log2(L)`
bits wide: 8 bits for L ≤ 8, 16 for 9..16, 32 for 17..32. It splits each AES output into chunks of that width.
* **Why it matters:** a single PRNG of L_max's width would draw a different (equally uniform) stream, so the
  run-time build would diverge from the native one at the first dummy access.
* **The fix:** the run-time build instantiates each width it can need, all with the same key, and uses the
  active depth's. Dummy accesses are then identical too, value for value and cycle for cycle.
* **The cost:** up to two extra small AES cores.

### Interface

* **Selecting the depth.** An init launch with `size = 0x8000_0000 | L` selects depth L; `size = 0` selects
  L_max. The depth is applied while the core is held in reset, then the tree-top split is computed against
  the new tree size. A depth outside 6..L_max keeps L_max and sets status 0x100.
* **What the summary reports.** Bytes 1–3 of the summary give the active L, L_max and the smallest L (6); a
  native build leaves them 0. Record [size+1] reports N and the tree of the active depth.
* **Host (`vitis/host_doma.cpp`, shared file, additive).** When the init's summary shows a run-time-depth
  bitstream and `DOMA_N` needs another L, the host sends the depth-selecting init and prints
  `Tiny ORAM bitstream: run-time depth, L = 6..19; running at L=15`.
  * Everything after that is unchanged: the pages buffer, the checks and the runs follow the active depth.
  * A `DOMA_N` above L_max stops with a message.
  * DOMA's output is unchanged.
* **Build.** `RTDEPTH=1 bash build_tinyoram.sh` (tag `_rt`), or `fetch_tinyoram.sh <size> <L_max> [merge] rtdepth`.
  A flat position map cannot be combined with it, because its size depends on N.
* **Queue entries.**
  * q8 `64_n10M_merge_rt`: 64 B, L_max = 19, host memory, merged; for q4/q1/q5's N.
  * q9 `4k_n64K_merge_rt`: 4 KB, L_max = 14; for q6/q7's N.

  Their PM column says `rt`. `sweep_tiny.sh` sweeps every N of `RT_NS` up to the entry's N on them.
  `merge_results.py` adds a table of each run-time-depth row against the native row of the same N, adapter and
  setting.

### Checks

* **Geometry (`sim/tb_rtgeo_probe.v`).** For every block size and L = 6..22 (68 geometries), the table row of
  depth L equals all 15 compile-time constants of the native build compiled with ORAML = L. That includes the
  4 KB recursion depth that `fetch_tinyoram.sh` writes. All 68 match.
* **Equivalence (`sim/run_tinyoram_rteq.sh`).** The native build of depth L and the run-time build started at L
  run the same testbench commands and seeds, with tree buffers of the same size (the testbench's random stream
  depends on it). The check fails on any of the following:
  * either build fails;
  * any per-launch line differs (latency min/max, the three latency figures, traffic, status);
  * any tree burst differs in port, cycle, offset or length (`+axitrace`);
  * the hash of every block byte written to the tree differs. This hash covers each beat outside the bucket
    headers, with its strobes and tree offset.

  **Header contents.** The bucket headers are not compared, because their size is the same but their layout is
  not. A run-time-depth build packs its Z leaf labels as L_max-bit fields, so the MAC fields start
  Z (L_max − L) bits later. Same 2 bursts, same AES and MAC work, different ciphertext. A per-beat comparison
  (L = 9 on L_max = 12, 16,356 write beats) found 501 differing beats, all in the first three beats of a bucket
  header, and none in a block.

  The tests are e2e, preload, gaps, late writes, packed records, byte ranges, the tree-top split, slow
  acknowledgements and repeated keys. 67 pairs, all identical (results in `docs/tinyoram_rteq_2026-10-19.txt`):
  * 64 B merged, L_max = 12, at L = 6, 7, 9 and 12. These cover one subtree, a short bottom subtree, PosMap
    recursion depths 1–3, and dummy-leaf PRNG widths of 8 and 16 bits.
  * 64 B 1:1, L = 9 on L_max = 12.
  * **64 B merged, L = 15 and 12 on L_max = 19, the planned card build.** L = 15 uses a 16-bit dummy-leaf PRNG
    where L_max uses 32 bits.
  * 4 KB merged, L = 6 and 8 on L_max = 9 (two-level subtrees).

  The preloads are mostly dummy accesses: at L = 9, 1,057 of 1,133 path reads. So the dummy-access path and
  its PRNG are exercised.
* **Mutants of patch 08** (one edit each in a copy of the L_max = 12 build). Each of these must break the
  equivalence:
  * PosMap block addresses from the build's N;
  * no level mask in the scan table;
  * one 32-bit dummy-leaf PRNG;
  * the build's subtree layout;
  * the build's path length in the AES path counter;
  * a write-back that never ends;
  * the build's final-PosMap start.

  **Three edits that must not show** (bursts, cycles, block bytes and latencies all stay equal):
  * **The stash's list rebuild over the build's capacity.** The stash capacity only matters at an overflow,
    which the background eviction prevents, and the rebuild is hidden under the path write-back.
  * **PRF leaves at the build's width.**
  * **Dummy leaves at the PRNG's width.** For both leaf edits, every path and placement decision ignores leaf
    bits above L because of the level mask.

  Patch 08 keeps all three (the active depth's capacity, the leaf masks) so that the stored values are those of
  the native build.
* **The run-time build alone:**
  * a re-boot from L = 9 to L = 6 (both sessions correct);
  * depths 13 and 5 on L_max = 12, each refused with status 0x100, followed by a correct ORAM of depth L_max.
* **Host:** against an XRT mock with a run-time-depth kernel. For `DOMA_N` = 1M it selects L = 15, for 10M
  L = 19, and with 10M on L_max = 15 it stops with a message. A native bitstream never receives a depth-selecting
  launch (the mock fails if it does). DOMA's output is unchanged in three configurations.
* **Not covered:** the PLB's leaf tag is masked to L bits as in the native build. That only shows after 2^L
  writes of one PosMap block, too long to simulate, so no mutant covers it. Like the other leaf masks, it keeps
  the native value.

### Effort and timing closure

* **The patch:** a 1,259-line diff, 508 lines added.
  * 17 core files are touched, each change under `ifdef`.
  * New: `TinyRTGeo.v`, `CountAlarmRT.v`, `RTGeo.vh`.
  * In the wrapper, about 70 lines: the active depth, the geometry, and the depth-selecting init.
* **The logic added:** a 262-bit register loaded from a 32-entry constant table. Constant comparisons become
  comparisons with registers. One variable shift is added in the bucket address (`AddrGenBktHead`: by
  `(L+1) % L_st`, at most 6 positions at 64 B), and a level mask in the scan table. Up to two more PRNGs.
* **The structural cost** is that of the native L_max build: a stash for Z(L_max + 1) + C blocks, L_max-wide
  leaves, and a scan table for L_max + 1 levels. The native q5 (L = 19) has the same. So **q5's timing is the
  reference**:
  * If q5 meets 300 MHz, the run-time build most likely does too. The only path that could get longer is the
    variable shift in the bucket address.
  * The geometry register changes only while the core is in reset. If its fan-out ever showed up on a critical
    path, a false path from `u_geo/Geo_reg` would be correct (and is not set today).
* **Builds saved.**
  * Of the planned 64 B entries, q8 replaces q4 and q5; q1 stays, as the acceptance reference.
  * q9 replaces q6 and q7.
  * Any further N between 6 and L_max costs no build.

### On the card

1. Build q8 (`bash queue.sh start 8`), after q1, at 300 MHz like q1.
2. Run `bash accept_rt.sh 1 8` (`tinyoram/card/accept_rt.sh`). It runs N = 1M on both bitstreams, alternating,
   5 times each, at `DOMA_TINY_TOP` 0 and doma:20. Pass:
   * traffic per command identical (exact);
   * p50 and p99 within 2%;
   * KQPS within the larger of 2% and twice the native build's own spread;
   * every run correct;
   * the same clock.

   Last line `ACCEPT PASS`; report in `results/accept_rt.txt`.
3. If it passes, use q8 for the 100K and 10M points (`bash sweep_tiny.sh 8`) and skip q4 and q5. If it fails,
   keep the native builds and send the report.

## 19. The kernel clock's metadata at link (2026-10-19, afternoon)

**What failed.** q1 and q8 at `FREQ = 230` stopped at the v++ link:
`[VPL-1] ulp_memory_subsystem_0: AXI Interface /S03_AXI has associated clock metadata 230000000 ... does not match
the clock metadata of any clocks attached to the aclk inputs`.

* `package_tinyoram.tcl` wrote `FREQ_HZ = FREQ` on the kernel IP's `ap_clk`. The `m_axi_gmem*` interfaces are
  associated with `ap_clk`, so they carried 230 MHz too.
* The platform's kernel clock domain keeps its default metadata, 300 MHz, whatever `--kernel_frequency` asks for.
  `--kernel_frequency` changes the clock itself, not the metadata the block design checks the interfaces against.
  So every `FREQ` other than 300 failed. The 300 MHz builds were never affected.
* DOMA's `package_kernel.tcl` always declares 300 MHz, and its builds set the real clock with
  `--kernel_frequency`.

**The fix** (the same as your edit on the server):
* `package_tinyoram.tcl` always declares `FREQ_HZ = 300000000`. A fourth argument (the old MHz argument) is
  accepted and ignored, so an old call cannot bring the bug back.
* `build_tinyoram.sh` no longer passes `FREQ` to the packaging. `v++ -l --kernel_frequency $FREQ` is unchanged,
  and so is `check_timing.sh`'s `WANT_MHZ`. The kernel runs at `FREQ`, and the xclbin's kernel clock, which
  `check_timing.sh` reads and the host reports, shows `FREQ`.
* Nothing else depends on the declared value. The RTL has no clock parameter, and the timing constraints come
  from the platform's clock at `--kernel_frequency`.

**Why the checks before missed it.** The elaboration and the out-of-context runs read only the kernel's sources,
with their own clock constraint. They never see the platform's block design, which is where the interfaces'
clock metadata is compared. The emulation and the 300 MHz board builds are linked at 300 MHz, where the declared
value happens to be right.

**The new check: `vitis/link_check_tinyoram.sh`**, run by `bringup_64.sh link` after `ooc`.
* It packages the fetched sources and checks that the `.xo` declares 300 MHz.
* It then runs the real `v++ -l -t hw` with `--kernel_frequency FREQ` (default 230) and the link configuration,
  stopped with `--to_step` at `vpl.generate_target` (or `vpl.update_bd` if this Vitis does not list the former).
  That point is after the block design is assembled and validated, which is where VPL-1 is raised, and before
  synthesis: 10–20 minutes, not hours.
* It catches any mismatch between the kernel and the platform that a link reaches before synthesis: clock
  metadata, connectivity (`nk`, `sp`, `slr`) and memory banks.
* `bringup_64.sh link` runs it for both link configurations (`tinyoram_host.cfg`, `tinyoram_hw.cfg`) at
  `LINK_FREQ`. The default is 230, or `FREQ` when that is not 300. Pass: both end `LINK CHECK PASS` (no `ERROR`,
  no `[VPL-1]`); critical warnings from the block design are listed in the report.
* Tested here only against stand-ins for Vivado and v++: a pass, a VPL-1 failure taken from the platform flow's
  `vivado.log`, and an `.xo` that still declares 230 MHz (refused before the link). On the server it is
  untested until you run it.

## 20. The run-time sweep's loop variable (2026-10-19, evening)

**What failed.** `sweep_tiny.sh` on a run-time-depth entry (q8, q9) called `scan.sh 10000000` and every run failed
with `No such file '10000000'`. Line 27 sets `x` to the entry's xclbin path. The loop on line 33, which picks the N
of `RT_NS` up to the entry's N, used `x` as its variable too, so after the loop `x` held the last N. Native entries
never enter that loop and were unaffected. `accept_rt.sh` runs `host_doma` directly and passed.

**The fix** (your server edit): the loop variable is `v`.

**Why the dry run missed it.** The scripts were dry-run (§15, §18) against the XRT mock, with stand-in layouts
made by hand and not kept in the package. The run-time-depth path was dry-run through the host and `accept_rt.sh`,
but `sweep_tiny.sh`'s new `RT_NS` loop was never run on a run-time entry with a stand-in that checks which xclbin
it is given.

**The new test: `tinyoram/card/test_card_scripts.sh`**, about a minute, g++ only. It is now a stage of
`sim/run_tinyoram.sh` (so of `install_tinyoram.sh --check` too; `CARD_TEST=0` skips it).
* **The mock:** `tinyoram/card/mock_xrt/` is the functional XRT mock the host was checked against, now in the
  package. It answers a launch as a key-value store in the kernels' response layout, native or with a run-time
  depth (L_max). A native bitstream sent a depth-selecting init exits with an error.
* **The stand-in:** a `DEST` laid out as `queue.sh` leaves it, for q1, q6, q8 and q9 from `queue.txt`. Each entry
  has a status file and a copy's `vitis/` with the xclbin, `scan.sh`, and a `host_doma` that answers as that
  bitstream and records each call's xclbin and `DOMA_N`.
* **`sweep_tiny.sh 1 6 8 9`** must pass its own check on every entry, and also:
  * call `host_doma` with the entry's own xclbin on every run;
  * run exactly the expected N, each with every `TOPS` setting (q1 1M, q6 16K, q8 100K/1M/10M, q9 16K/64K);
  * on q8 and q9, run each N at the depth it needs (L = 12, 15, 19; L = 12, 14).

  `RT_NS=1000000` on q8 must run 1M only.
* **`accept_rt.sh 1 8`** must end `ACCEPT PASS`, with traffic, depth and p50/p99 identical on both bitstreams.
  The mock's KQPS is host wall-clock time, so the test uses `NOISE_PCT=50`.
* **Self-check:** the test puts the bug back into a copy of `sweep_tiny.sh` and must catch it. It does: "15
  host_doma calls without the entry's xclbin (xclbin=10000000)".

## 21. More block sizes: 512 B, 1 KB, 2 KB (2026-10-19, night)

`fetch_tinyoram.sh` now takes `64 | 128 | 256 | 512 | 1k | 2k | 4k` (block bytes). The new sizes are
`tinyoram/config/tinyoram_config_{512,1k,2k}.vh`. They are the 64 B file with only `TINYORAM_ORAMB` changed: Z = 4,
C = 10, AES-128 and PMMAC on, FEDWidth 64, BEDWidth 256. Each also builds with run-time depth up to L_max = 18
(`fetch_tinyoram.sh <size> 18 merge rtdepth`). The core and patch 08 are unchanged; both take the block size from `ORAMB`.
The wrapper's simulation-time configuration check now says ORAMB ≥ 512 (see below); synthesis is unaffected.

### Why there is no 8, 16 or 32 B block

* **The backend never starts below 64 B (found in simulation, 32 B).** A native 32 B build accepted its first PUT
  and then never read the tree: the testbench's watchdog stopped the launch, and every later command timed out.
  * The backend's eviction buffer waits for `BlkSize_BEDChunks` chunks of block data before it appends a block to the
    stash (`PathORAMBackendCore.v`: `EvictBuf_Chunks >= BlkSize_BEDChunks`). That is a whole 512-bit burst: 2 chunks
    of 256 bits.
  * The frontend stores only ORAMB bits: 1 chunk at 32 B. So the first append never happens.
  * Tiny ORAM as published therefore needs ORAMB ≥ 512 bits. Making smaller blocks work would mean padding the
    frontend's data in the core, a change to the original structure, for a block that would save nothing (next
    point).
  * The wrapper's check (simulation only) now stops such a build at elaboration with this reason.

* **Each block takes a whole DRAM burst.** Tiny ORAM pads each block slot of a bucket to whole 512-bit DRAM bursts
  (`BucketLocal.vh`: `BlkSize_DRBursts = divceil(ORAMB, DDRDWidth)`, `DDRDWidth` = 512). An 8, 16 or 32 B block takes
  the same 64 B as a 64 B block: the same tree, the same traffic per access at the same L.
* **A PosMap block holds ORAMB / 64 entries.** With integrity on, the position map is the PRF form (`PRFPosMap = 1`),
  with 64-bit entries (`LeafWidth = AESEntropy`). That gives 1 entry per PosMap block at 8 B, 2 at 16 B and 4 at 32 B.
  * At 8 B the recursion cannot shrink the position map. Only a flat on-chip position map works, which needs
    N ≤ 1,024 blocks (L ≤ 8).
  * At 16 B and L = 18, the position-map rule ("recursive until < 1,024 entries", §17) gives 11 levels. The PosMap
    blocks then fill the tree to about 100%, against Tiny ORAM's 50% design point. 11 levels is also more than patch
    08's table covers (9).
* **The wrapper moves records in whole 32 B AXI beats,** so 8 and 16 B blocks would also need wrapper changes. Its
  check now requires ORAMB ≥ 512 bits, for the backend's reason above.

So 8-byte records go packed into 64 B blocks (the host's `DOMA_PACK=1`; q1 puts 8 per 64 B block). The fetch
refuses `8`, `16` and `32` with that message. The host packs 8-byte records only (`VALUE_SIZE` = 8). 16-byte records would
need a `VALUE_SIZE` setting in the shared host, which is not part of this change.

### What the new sizes cost

How full the tree gets (data plus PosMap blocks, out of 8 · 2^L slots), the PosMap depth, and the tree size
(`host_doma.cpp`'s `tinyoram_tree_bytes`):

| block | PosMap depth at L = 18 | tree filled at L = 18 | tree at L = 14 / 16 / 18 |
|---|---|---|---|
| 64 B (existing) | 5 | 57% | 20 MB / 54 MB / 0.19 GB |
| 512 B | 3 | 51% | 85 MB / 0.41 GB / 1.20 GB |
| 1 KB | 3 | 50% | 0.15 GB / 0.79 GB / 2.34 GB |
| 2 KB | 3 | 50% | 0.29 GB / 1.31 GB / 6.38 GB |

* **1 KB and 2 KB at L = 18 need large host-memory trees: 2.3 and 6.4 GB.** `tinyoram_host.cfg` puts the tree in
  `HOST[0]`. Check that the card's host-memory region is at least that big before running N near 1M blocks. Smaller
  N on the same bitstream use smaller trees: the host allocates the tree for the active depth.
* **The whole tree on-package is not possible there.** `top_bytes` is 32-bit (top ≤ 4 GB − 4 KB), and the tree top
  spans HBM[8:15], 4 GiB (§22; one bank, HBM[8], before 2026-10-21). The matched budgets (`doma:<p>`) fit.
* **The 2 KB subtrees are short.** At 2 KB a bucket is 130 bursts, so a subtree of the address layout (8 KB DRAM
  rows) has 3 levels. The layout's padding (`NumBuckets = 2^(L+1) + numTotalST`) is then 36% of the tree at L = 18
  (12% at 1 KB, with 4-level subtrees). That is Tiny ORAM's own layout (`BucketLocal.vh`), as at 4 KB.

### Queue, sweep, table

* **Queue:** new entries `q13 1k_n1M_merge_rt` and `q14 2k_n1M_merge_rt`, after your q10–q12 (128 B, 256 B, 4 KB). Each is 1,048,576 records unpacked, so
  L_max = 18, merged, `tinyoram_host.cfg`, FREQ 230. `install_tinyoram.sh` makes their copies.
* **Sweep:** `sweep_tiny.sh` sweeps `RT_NS` = 16K, 64K, 256K and 1M records on them (L = 12, 14, 16, 18). The
  matched budgets use doma_kernel with the same block size, unpacked (`DOMA_MATCH_BLOCK` = 1024 / 2048), as for 4 KB.
  DOMA has no 1 KB or 2 KB build of its own here, so their tables have Tiny ORAM rows only.
* **Size names:** every script that turns a size name into bytes now knows `1k` and `2k`: `build_tinyoram.sh`,
  `queue.sh`, `sweep_tiny.sh`, `accept_rt.sh`, `run_tinyoram.sh`, `test_card_scripts.sh`. `merge_results.py` writes
  one table per block size above 64 B.

### Checks

* **Here** (`sim/run_tinyoram_sizes.sh`, log `docs/tinyoram_sizes_2026-10-20.txt`):
  * the every-module lint of the six geometries (512 B, 1 KB, 2 KB, each native L = 6 and run-time L_max = 18,
    merged);
  * the fetch refusing 8, 16 and 32 B;
  * TinyRTGeo against each new size's native constants at L = 6..22 (51 geometries);
  * per size, the native L = 6 build against the L_max = 18 build started at 6 on the regression's tests:
    * both correct, with identical per-launch lines, tree bursts (same cycles) and block bytes;
    * for 1 KB and 2 KB also at L = 10 against a native L = 10 build, which has PosMap depth 2 and a preload of
      all 4,096 blocks;
  * a re-boot from one depth to another on each L_max = 18 build.
  * the same suite on the three run-time-depth bitstreams you built on 10-20 (q10 128 B, q11 256 B, q12 4 KB, all
    L_max = 18): `SZS="128 256 4k"`, 43 checks, all passed. 4 KB is also checked at L = 10 against a native L = 10
    build (PosMap depth 2, full preload).
* **Elsewhere:**
  * patch 08's native-identity check now covers 14 configurations (7 sizes × 2 adapters);
  * the build-queue lint in `run_tinyoram.sh` covers q10–q14;
  * the card-scripts dry run sweeps q10–q14 at two N.
* **The testbench**, two opt-in defines (without them it is unchanged):
  * `-DTB_NMAX=<blocks>` caps the reference arrays. At 2 KB and L_max = 18 they would otherwise take 2.4 GB. A run
    at more blocks fails.
  * `-DTB_CMD_WORDS=<words>` enlarges the command and response buffers (default 8 MB). 4,096 PUTs of 2 KB need
    16 MB. The 2 KB L = 10 preload first ran past the 8 MB buffer and failed with garbage keys. Any launch whose data
    does not fit now fails with that reason instead.
* **On your server** (`tinyoram/card/check_sizes_vivado.sh`, in the bring-up copy):
  * `elab`: the Vivado elaboration of the same six geometries;
  * `link`: the short v++ link (§19) of 1 KB and 2 KB, run-time L_max = 18, merged, at 230 MHz with
    `tinyoram_host.cfg`.

  Last line `SIZES VIVADO CHECKS PASSED`. The report is `DEST/bringup/sizes_report.txt`. Dry-run here only
  against stand-ins for Vivado and v++.

## 22. Slowdown comparison, the q8 drop at 1M, a multi-bank tree top (2026-10-21)

### Columns for the slowdown comparison (`sweep_tiny.sh`, `csv_extend.py`, `extend_results.sh`)

Every Tiny ORAM CSV keeps scan.sh's 13 columns, unchanged and in the same order. Seven columns are appended to every
row:

| column | what |
|---|---|
| `clock_mhz` | the kernel clock read from that row's bitstream: `xclbinutil --info`, `DATA_CLK` (as `check_timing.sh` and `sweep_doma.sh` read it), not queue.txt's FREQ; `clocks.txt` gets the same value |
| `block_bytes` | the bitstream's block size |
| `value_bytes` | bytes one command reads or writes: 8 for packed records (`DOMA_PACK=1`), else the whole block |
| `hbm_budget_bytes` | the on-package tree top of that run, after rounding to 4 KB (the host's `placement:` line); 0 = the whole tree in host memory. `hbm_pct` still has the setting (`0`, `doma:20`, ...) |
| `dev_cycles_per_query` | the query launch's device cycles (kernel start to done) / commands = `device_cycles` / `commands` |
| `lat_mean_cyc` | mean per-command latency in cycles (`latency spread:`) |
| `tree_L` | the depth the run used (a run-time-depth bitstream: the depth selected for N) |

* **Old CSVs:** `bash extend_results.sh` adds the same columns to the CSVs already in `results/`, from their own logs.
  It needs no card run, and keeps each original as `<csv>.orig`.
* **Unpacked values:** an unpacked PUT writes the whole block, but only its first 8 bytes are the random value; the
  rest is zero. Tiny ORAM encrypts and moves whole blocks either way, and DOMA's host and a baseline run through the
  same host do the same.
* **Tested here:** the card-scripts dry run checks every column on q1/q6/q8/q9. Its stand-in `xclbinutil` reports
  queue.txt's FREQ + 1, so a clock not taken from the bitstream would show.

### The workload is the same

`sweep_tiny.sh`, `sweep_doma.sh` and `scan.sh` all run `host_doma`. Its query workload is one code path for both
kernels:

* **Commands:** `generate_uniform_commands`, BOLT's generator. `std::mt19937` with seed 1, 50% PUT
  (`uniform_real < 0.5`), keys uniform over the N records, 8 random value bytes per PUT. At the same N, the command
  stream is identical command by command.
* **Count:** 20,000 commands. `CMDS` defaults to 20,000 in both sweeps and is passed to `scan.sh` and on to `host_doma`.
* **Preload:** before timing, every record is written once (values from `mt19937` seed 16), and counted as init.
* **Timing:** commands are converted and copied to the card (`sync` to device) before the clock starts. The timed
  region is one kernel launch with all commands, plus `wait()`. Verification follows, outside the timing.
* **The same code in every host version.** The generator, the preload loop and the timed region are byte-identical
  in your base package's host and in every overlay's (10-18c, 10-19, 10-19c, 10-20b; checked by hash). So each
  bitstream copy's own `host_doma` runs the same workload as the combined copy's.
* **Differences between the two designs are outside the workload:**
  * the on-package knob: `DOMA_HBM_PCT` for DOMA, `DOMA_TINY_TOP` for Tiny ORAM;
  * Tiny ORAM's depth-selecting init launch, which is part of init.

### The 500K → 1M drop on q8: one more PosMap recursion level

q8 is 64 B blocks with 8 records each, L_max = 19. Measured at `doma:20`: 136.8 / 109.5 / 83.4 / 60.6 / 57.3 KQPS at
100K / 500K / 1M / 5M / 10M. The depth, the recursion and an exact model of Tiny ORAM's PosMap lookup at each N:

| N | L | PosMap levels in tree (R − 1) | on-chip final entries | path (one read) | P(fetch level 1 / 2 / 3 / 4) | real paths / access | real path bytes read / access | KQPS ratio, model / measured |
|---|---|---|---|---|---|---|---|---|
| 100K | 12 | 2 | 256 | 4,992 B | 0.96 / 0.67 | 2.63 | 13.1 KB | |
| 500K | 14 | 2 | 1,024 | 5,760 B | 0.99 / 0.93 | 2.92 | 16.8 KB | 0.78 / 0.80 |
| 1M | 15 | **3** | 256 | 6,144 B | 1.00 / 0.98 / 0.82 | **3.79** | **23.3 KB** | 0.72 / 0.76 |
| 5M | 18 | 4 | 256 | 7,296 B | 1.00 / 1.00 / 0.97 / 0.79 | 4.76 | 34.7 KB | 0.67 / 0.73 |
| 10M | 19 | 4 | 512 | 7,680 B | 1.00 / 1.00 / 0.99 / 0.89 | 4.88 | 37.4 KB | 0.93 / 0.95 |

* **A recursion level is added at 1M.** At L = 14 the last PosMap level has 1,024 blocks, which fit in the on-chip
  final PosMap (the limit is "< 1,024 entries"; §17). At L = 15 it would have 2,048, so the recursion gets a third
  level in the tree and the on-chip final PosMap drops to 256 entries.
  * Real path accesses per query go from 2.92 to 3.79 (+30%). The path itself is only 6.7% longer. Together that is
    1.38× the bytes, against 1.07× for one tree level alone.
  * 5M → 10M adds a level without a recursion step, and drops only 5%.
* **The PLB does not change behaviour there.** It is ineffective at every N. It is a direct-mapped 8 KB cache: 128
  lines of 64 B PosMap blocks, index = block address mod 128. Under uniform keys, a level-1 PosMap block is in it for
  under 1% of accesses at 500K and at 1M. What changes is that 82% of accesses at 1M miss all the way up to the new
  level.
* **The model:** `traffic_levels.py` implements it: `UORAMController.v`'s lookup order, `DM_Cache.v`'s indexing,
  keys uniform as the host draws them, 100K warm-up and 100K measured accesses.
  * It predicts the measured KQPS ratios from bytes alone, slightly overestimating each drop. A share of each
    command's time is fixed (command fetch, crypto pipeline fill), and the doma:20 top share differs per N.
  * It counts no background evictions. Those show as the difference against the card's counters.
* **Your counters:** run `python3 tinyoram/card/traffic_levels.py ~/tiny/results/tiny_q8_64_n10M_merge_rt.log`. Per
  run it prints:
  * L, R, the on-chip final PosMap entries and the path size;
  * the kernel's read and write bytes per command, and bytes per tree level;
  * paths per command measured, against the model;
  * the difference: background-eviction paths per command.

### A multi-bank tree top (`tinyoram_host.cfg`: `top` on `HBM[8:15]`)

Until 2026-10-21 the tree-top port `top` was one buffer on `HBM[8]`, one 512 MB pseudo-channel. `tinyoram_host.cfg`
now maps it to `HBM[8:15]`: 8 channels, 4 GiB, one address space to the kernel. Banks 8–15 are otherwise unused by
this kernel (commands HBM[6], responses HBM[7], the tree in HOST[0]). `tinyoram_hw.cfg` (the bring-up config, tree in
`HBM[8]`) is unchanged. The separate `tinyoram_host_big.cfg` (HBM[16:23]) of the morning is withdrawn.

* **The budgets this is for (`doma:20`, your figures):** 1 KB and 2 KB at 1M records need 523 and 1,015 MiB, and 4 KB
  at 500K and 1M records 1,008 MiB and about 2 GiB. All are above 512 MB and well inside 4 GiB.
  * This package's own budget function (`doma_onpkg_bytes`, what `doma:<p>` requests) gives somewhat less: 1 KB
    0.45 GiB, 2 KB 0.88 GiB, 4 KB 1.73 GiB at 1M and 20%.
  * 4 KB at `doma:100` exceeds 4 GiB.
* **Every address path to the top is 64-bit, so nothing assumed one bank:**
  * The kernel widens `top_bytes` to 64 bits before rounding it to 4 KB. The split point `top_q`, the top's base
    `top_base`, and the zero-fill's offset and address (`zf_off`, `zf_awaddr`) are 64-bit.
  * The adapter's top-port address is `base_t + offset`, both 64-bit. The split compares the 64-bit tree offset with
    `top_bytes`. Bursts are never merged across the split or past 4 KB.
  * The zero-fill's 4 KB bursts are 4 KB-aligned, as is the split, so none straddles it.
  * The traffic record's top share is 28 bits of 64-byte units: 17 GB per launch.
  * The one 32-bit field is the `top_bytes` argument: a top of up to 4 GiB − 4 KB, all of HBM[8:15].
  * No burst crosses 4 KB, so none crosses a channel boundary.
  * The host allocates the top as one buffer of the run's size, as DOMA's host allocates its 4 GiB bucket buffer on
    HBM[16:23] (`doma_big.cfg`).
* **Checked here (simulation), tops above 512 MB:** `SIZES_SET=top4g bash sim/run_tinyoram_sizes.sh`, run-time
  depth L_max = 18 against the native build of each depth:
  * 4 KB at L = 14 (an 860 MiB tree) with a 640 MiB top;
  * 2 KB at L = 15 (an 817 MiB tree) with a 640 MiB top.

  The run-time builds at L_max = 18 simulate about 12× slower than the native ones (2,400 cycles/s at 4 KB), and
  zero-filling the tree takes most of the time: about 3 hours per size. That is why 2 KB runs at L = 15 rather than
  at L = 16 with q14's full 1,015 MiB. Every address bit above 512 MiB is exercised either way.

  The top model is exactly the top's size and the tree model the tree's, so an access past either is a model error.
  The traces must also place every top-port burst inside [0, top), every host-port burst in [top, tree), and must
  include ORAM path reads past 512 MiB. Results: 16/16 pass (8 per size, with the lint and table checks).
  * 4 KB: the run-time build issues the same 238,489 bursts in the same cycles, with the same block bytes, as the
    native build. 181,860 bursts go to the top, all inside 640 MiB, 209 of them path reads past 512 MiB. 56,629 go to
    host memory, all above the top.
  * 2 KB: 219,131 identical bursts; 173,680 to the top, 114 path reads past 512 MiB; 45,451 to host memory.
  * No memory-model errors on either port (`docs/tinyoram_sizes_2026-10-20.txt`).
* **Earlier, smaller tops** (4 KB, L = 10, a 64 MB model: tops of 15%, half and all of the tree) passed 10/10 with the
  same equivalence (`SIZES_SET=bigtop`).
* **Rebuilds:** q12, q13 and q14 must be relinked with the new `tinyoram_host.cfg` (full v++ link). Before that, run
  `bash check_sizes_vivado.sh link` in the bring-up copy: the short link (§19) of exactly those three configurations
  at 230 MHz, which checks the HBM[8:15] connectivity against the platform.
* **The other bitstreams stay as built, with the top on HBM[8].** At 1M records q10 (128 B) and q11 (256 B) need at
  most 201 / 378 MiB even at `doma:100`. q1 and q8 need at most 171 MiB. q15 (512 B) needs 243 / 426 / 731 MiB at
  `doma:20` / `50` / `100`, so on q15 only `doma:100` at 1M does not fit; the host then fails to allocate the top
  buffer.

### Value-size sweeps (no tree top)

After q15 (512 B) is DONE, in `~/tiny/combined/fpga_zcu208/tinyoram/card`:

```bash
TOPS=0 RT_NS="100000 1000000" bash sweep_tiny.sh 10 11 13 14 15
TOPS=0 RT_NS="16384 65536 262144 524288" bash sweep_tiny.sh 12
```

* **Two calls,** because `RT_NS` applies to every entry in a call (each entry runs the N of `RT_NS` up to its own N).
* **Host memory:** the trees at these points are 0.04–2.3 GiB at 128 B–1 KB. The large ones are 2 KB at 1M (6.4 GiB)
  and 4 KB at 256K / 512K (3.4 / 5.4 GiB). Check that the card's host-memory region holds them.
* **Your q15 line:** this package's `queue.txt` has no q15. Use your server's `queue.txt` with your q15 line, or add
  `15 512_n1M_merge_rt 512 1048576 0 tinyoram_host.cfg 1 rt 230 ...` if that is what you built (the sweep reads the
  N column).

### A 256-bit-burst Tiny ORAM at 1M 8-byte records (estimate, not built)

* **Assumed:** `DDRDWidth` 256 bits (`DDRBstLen` 4), 32 B blocks with 4 records each: 250,000 blocks, so L = 16. The
  header is 4 bursts (128 B), so a bucket is 256 B and a path 4,352 B.
* **PosMap:** a 32 B PosMap block holds 4 entries, so R = 5: 4 PosMap levels in the tree, 1,024 on chip. The tree is
  66% full, against 57% today.
* **The same PLB:** 8 KB is 256 lines of 32 B.

| | today: 512-bit bursts, 64 B blocks | 256-bit bursts, 32 B blocks |
|---|---|---|
| L, PosMap levels in tree | 15, 3 | 16, 4 |
| path (one read) | 6,144 B | 4,352 B |
| real paths / access | 3.79 | 4.90 |
| bytes / access, read + write | 46.6 KB | **42.7 KB** |
| of which the data path | 12.3 KB | 8.7 KB |
| of which PosMap paths | 34.3 KB | 34.0 KB |

* **About 8% fewer bytes.** The data path shrinks by 29%, but the extra recursion level takes almost all of it back:
  the PosMap paths cost the same.
* **Background evictions are not included.** At 66% occupancy they would be more frequent than at 57%, which narrows
  the gap further.
* **64 B blocks with 256-bit bursts** give exactly today's numbers: same buckets, same recursion.

## 23. A million commands per run (2026-10-29)

`host_doma <xclbin> 1000000` (or `CMDS=1000000` for `scan.sh`, `sweep_tiny.sh` and `accept_rt.sh`) runs 1M query
commands on Tiny ORAM at any block size.

* **The kernel already took any count in one launch.** Header and slot addresses are 64-bit (`cbase + idx·32`,
  `hc_off + (idx << log2 block)`). The command, completion and latency counters are 32-bit, so up to 4G commands.
* **The limit was the host's two card buffers.** Commands and responses each take 32 bytes plus one block-sized slot
  per command, and each buffer sits in one 512 MB HBM bank (`HBM[6]`, `HBM[7]`). 1M commands fit one launch up to
  256 B blocks (288 MiB per buffer). They need 0.5–4 GiB at 512 B to 4 KB.
* **Now the host splits the query when it does not fit.** It runs back-to-back launches on the same ORAM, each of at
  most `DOMA_BATCH` commands. The default is as many as fit `DOMA_BUF_MAX` bytes per buffer, default 480 MiB:
  925,199 commands per launch at 512 B, 476,617 at 1 KB, 241,975 at 2 KB, 121,925 at 4 KB. So 1M commands are 2, 3, 5
  and 9 launches.
  * The command stream is generated once, exactly as for one launch: the same 1M commands in the same order.
  * Each batch is copied to the card before its launch. The timed region is each launch + `wait()`, summed, so the
    copies between launches are not timed. KQPS is all commands over that sum.
  * Every response is verified against the reference. The device cycles, traffic and latency figures (spread,
    histogram) cover all commands. A `batches:` line says how the run was split.
  * The device-cycle total includes one kernel start per launch, a few hundred cycles each.
* **When the card refuses the buffers, the host retries with half.** XRT backs every card buffer with pinned host
  memory. On your card, 1M commands at 512 B failed with `failed to allocate userptr bo: Operation not permitted`
  even with 268 MB buffers, while 20,000 commands passed.
  * The host now halves the buffer (and the commands per launch) and retries, printing one `the card refused ...`
    line per refusal, down to 16 MiB. Below that it stops with a plain message instead of an abort.
  * The `batches:` line gives the size that was accepted. Use it as `DOMA_BUF_MAX` to skip the retries next time.
  * Checked against the XRT mock with refusals above 100 MB (512 B: 63 MB buffers, 9 launches) and above 30 MB
    (4 KB: 16 MB, 263 launches), all responses correct.
* **Unchanged:** a run that fits one launch gives byte-identical output to before, for both kernels (checked against
  the XRT mock at 20,000 commands). `doma_kernel` never splits. `scan.sh` parses the same lines.
* **Checked against the XRT mock:**
  * 1M commands at 64 B in one launch, and forced into 4 launches (`DOMA_BATCH=300000`): the same 499,259 GETs and
    500,741 PUTs, all responses correct, the same traffic per command.
  * 1M at 4 KB: 9 launches, all correct.
* **Host memory:** the reference copy of the commands is 16 MB. The response check and latency list add about 4 MB per
  million commands.

### One launch for 1M commands (2026-10-30): commands and responses over 4 GiB each

* **`tinyoram_host.cfg`** now maps `cmd_input` to `HBM[16:23]` and `resp_output` to `HBM[24:31]`, 8 pseudo-channels
  (4 GiB) each; they were `HBM[6]` and `HBM[7]`. The tree top stays on `HBM[8:15]`. 1M commands then need at most
  3.84 GiB per buffer (4 KB blocks), so they fit one launch at every block size.
* **The kernel is unchanged.** Its header and slot addresses are 64-bit.
* **The host first tries one launch for all commands.** A bitstream linked with the earlier config (one 512 MB bank per
  port) refuses those buffers. The host then falls back to halving and batches, as in §23. Both kinds of bitstream
  work with the same host.
  * Mock: 1 KB, 1M commands in one launch with 1.06 GB buffers. With a 512 MiB limit: one refusal, then 3 launches,
    all correct.
  * Runs that fit one launch are byte-identical to before, for both kernels.
* **Rebuilds:** q15, q13, q14 and q12 (512 B–4 KB) need a relink with the new config for one launch. The 64–256 B
  bitstreams already run 1M commands in one launch. Check first with `bash check_sizes_vivado.sh link` (512 B to
  4 KB, 230 MHz).
* **Two things to watch on the card:**
  * HBM[16:31] is the other HBM stack from HBM[6:7]. The command fetch is prefetched, so a latency change should not
    show, but compare one KQPS figure against a batched run.
  * Each card buffer is also backed by pinned host memory: about 7.7 GB at 4 KB with 1M commands, on top of the
    tree. If the card refuses that, the host falls back to batches by itself.


## 24. A plaintext tree top for Tiny ORAM? (2026-11-01, analysis only)

DOMA v14c keeps its on-package buckets in plaintext. The question: would Tiny ORAM gain from the same choice for its
tree top (the `top_bytes` split)? Answer: no change. Every number below is from simulation. No RTL and no bitstream
changed. Measurement script: `sim/run_tinyoram_aesgain.sh`; address-map model and card estimate: `sim/aesgain_model/`; log:
`docs/tinyoram_aesgain_2026-11-01.txt`.

### Where encryption sits relative to the split

* **The split is below the AES.** The data path runs memory ports → adapter (`h_off < top_bytes` picks gmem3 or
  gmem2) → `AESPathORAM` → backend core. The AES sees one in-order stream of 256-bit beats with no addresses, so
  today every bucket is encrypted, wherever it lands.
* **Header and IV.** The first 64 bits of each bucket header are the IV. It is a global counter, written in the
  clear, incremented for every bucket written. The rest of the header (valid bits, addresses, leaves, the per-block
  MACs) and the four blocks are XORed with the keystream. `DRAMToStash` treats a bucket whose IV is 0 as never written
  (that is how the zero-filled tree reads as empty).
* **Keystream.** At each header beat the IV enters a one-entry FIFO. `AES_W` (two tiny_aes cores, 256 bits per cycle)
  then makes AES(K, IV ‖ chunk index) for every beat of the bucket, while the data waits in a 26-entry FIFO. A path
  streams at line rate. The cost is the pipeline depth, paid once per path read and once per write-back.
* **A bypass for top buckets would need:**
  * a per-bucket flag, taken from the bucket's destination address with the adapter's own comparison, carried into
    `AESPathORAM` in stream order. A bucket that straddles the split counts as off-package (its keystream is per
    bucket);
  * for flagged buckets, no keystream requests and a zero mask, in the same in-order FIFO as encrypted buckets;
  * the IV field still written with the counter, so a written top bucket never reads as empty;
  * write beats still taken only during a write-back. The stash presents one beat past the end of each write-back,
    which the AES never takes (its IV FIFO is still busy then). Tiny ORAM's own `EnableAES = 0` branch takes it and
    fails the backend's write-back check in this snapshot. A zero-latency pass-through must not take it either.
* **PMMAC: keep it as is.**
  * The MAC is per block, not per bucket. It is computed in the front end, stored next to the block in a bucket
    header, and follows the block. Blocks move between the top and the rest through the on-chip stash at every
    eviction, so every block must carry a valid MAC whenever it may be written off-package. The MAC write cannot be
    skipped.
  * Skipping only the check for blocks read from the top would need each block's origin tracked through the stash.
    It would also make the response time depend on the level where the requested block was found, which is not
    public. That is a new timing leak.
  * It costs nothing on the memory path. The check runs in the front end, not in the bucket stream.

### Security of a bypass

* **Nothing new is revealed.** The split is a fixed address map. A bucket's offset is a function of the path's leaf,
  and the leaf of every path access is already visible on the bus, as is the port each burst uses (the split exists
  today). A bypass changes the contents of on-package buckets only. The cycles it saves depend only on the leaf
  (below).
* **Blocks leaving the package are always encrypted.** Data reaches off-package memory only in a path write-back,
  and the bypass decision is per destination bucket. A block read in plaintext from the top sits in the on-chip
  stash. When it is evicted to a lower bucket, it is encrypted with that bucket's fresh IV. IVs stay unique, because
  the counter still advances for every bucket written.

### Expected gain (simulation)

* **Method.** Two builds per block size, of the same geometry (L = 10, merged adapter):
  * as shipped;
  * `AES_BYPASS_ALL`: every bucket in plaintext with zero added latency. A private copy of `AESPathORAM.v`: payload
    passes straight through, the IV is still written, write beats are gated to write-backs.
  
  Both builds run the same command stream: 4,096 preload PUTs (64–512 B), then 300 commands with 50% PUTs and
  uniform keys. Both make the same accesses, with identical tree traffic in every run, and pass every GET check.
  Memory latency in the model: 40 cycles on the top port, 100 cycles on the host port.
* **The keystream never stalls the memory.** Read beats refused by the AES: 0 at every size. A counter probe in the
  shipped build shows the cost is the pipeline tail. From the last beat into the AES to the last beat out, it takes
  23–24 cycles per path read and 24 per write-back.
* **Whole tree on package (`+top_all`), random commands, cycles per command:**

| block | as shipped | all plaintext | saved | per path |
|---|---|---|---|---|
| 64 B | 851.7 | 809.4 | 42.2 (4.96%) | 24.1 |
| 128 B | 1,192.2 | 1,151.5 | 40.8 (3.42%) | 23.9 |
| 256 B | 1,919.8 | 1,878.4 | 41.4 (2.16%) | 23.7 |
| 512 B | 3,414.9 | 3,373.3 | 41.6 (1.22%) | 23.5 |
| 1 KB | 2,939.9 | 2,928.0 | 11.9 (0.41%) | 16 |
| 2 KB | 5,510.2 | 5,494.5 | 15.7 (0.28%) | 21 |
| 4 KB | 10,852.4 | 10,844.7 | 7.7 (0.07%) | 10 |

  * The saving is a constant ~24 cycles per path access, so its share falls as the path grows.
  * 1–4 KB ran without the preload: mostly appends, 0.74 paths per command. Per path they show the same small
    saving.
* **A partial top saves only on paths that lie entirely on package.** Tiny ORAM issues each path read and each
  write-back from the root down, so a path's top buckets come first and its off-package buckets last. The
  keystream tail of the last off-package bucket ends the read and the write-back whether or not the top buckets
  were encrypted.
  * Checked on every path in the bus traces at a 15% top for 64–512 B: no top bucket after a host bucket.
  * At 1–4 KB, the two ports' read handshakes can interleave on the bus. The data still reaches the AES in command
    order.
  * The share of paths entirely in the top follows from Tiny ORAM's address map (`AddrGenBktHead.v`, modelled; the
    model matches the traced shares: 9.4/9.9%, 11.9/11.6%, 0/0%, 3.5/3.6% at 64/128/256/512 B).
* **On the card's geometry** (1M records, L = 18, the host's matched budgets): saving ≈ 24 cycles × (share of path
  accesses entirely on package) / cycles per path. Cycles per path are taken from the L = 10 runs (2.33 × path beats
  + 180, fitted at 64–512 B). These are upper bounds: zero-latency plaintext, a 40-cycle HBM, and per-path rather
  than per-command time.

| block | path | whole tree | doma:20: paths on package | doma:20 gain | doma:100: paths on package | doma:100 gain |
|---|---|---|---|---|---|---|
| 64 B | 7.1 KB | 3.4% | 23.9% | 0.8% | 55.2% | 1.9% |
| 128 B | 11.9 KB | 2.3% | 0% | 0 | 12.1% | 0.3% |
| 256 B | 21.4 KB | 1.4% | 16.7% | 0.2% | 58.8% | 0.8% |
| 512 B | 40.4 KB | 0.75% | 9.0% | 0.07% | 53.5% | 0.4% |
| 1 KB | 78 KB | 0.40% | 8.6% | 0.03% | 54.4% | 0.2% |
| 2 KB | 154 KB | 0.21% | 0% | 0 | 11.4% | 0.02% |
| 4 KB | 306 KB | 0.10% | 0% | 0 | 2.2% | 0.002% |

  * **Check at 64 B, L = 14** (65,536-block preload, then the same 300 commands):
    * 2.95 path accesses per command;
    * 589 cycles per path, against 600 from the fit;
    * 23.9 cycles saved per path;
    * 4.07% per command with the whole tree on package, against 4.0% predicted.

    The testbench checks responses only for launches of up to 4,096 commands, so this run has no GET checks. Its
    two builds made identical tree traffic.
* **Against DOMA at 4 KB.** DOMA saves 764 cycles per on-package access. Tiny ORAM would save about 24 cycles per
  path access, 0.1% with the whole tree on package and nothing at doma:20.

### Recommendation

Do not change Tiny ORAM. At the matched budget (doma:20), the gain is under 1% at every size, and zero at 128 B,
2 KB and 4 KB. With the whole tree on package, it is under 2% from 256 B up. At 64 B and 128 B it is 3.4% and 2.3%
as upper bounds. Paper text:

> Tiny ORAM encrypts each bucket with AES in counter mode, and its keystream pipeline runs at the full memory rate
> while a bucket streams in or out, so encryption adds only the depth of that pipeline, about 24 cycles per path
> access. Tiny ORAM reads and writes each path from the root down, so a plaintext tree top would remove this cost
> only for paths that lie entirely on package. In simulation of the U55C kernel, the saving is under 1% per access
> at the matched on-package budget for every value size from 64 B to 4 KB, and at most 3.4% with the whole tree on
> package (64 B values), falling to 0.1% at 4 KB. We therefore keep encryption on every Tiny ORAM bucket.

### Reproduce

`bash sim/run_tinyoram_aesgain.sh` (7 sizes, about 1 hour on 2 cores; `SZS`, `L`, `CMDS`, `PRELOAD`, `TOP_PCT`
choose the runs). It writes `build_tinyoram/aesgain/summary.txt`, `table.txt` and `order.txt`.

## 25. Plaintext tree top (TOP_PLAINTEXT, patch 09, 2026-11-01)

A build option that treats on-package memory the way DOMA v14c does. Buckets in the on-package tree top are stored
in plaintext. Every other bucket is stored exactly as in the default build. Section 24 measured the gain; this
section is the implementation.

* **Build:** `build_tinyoram.sh TOPPLAIN=1` (fetch option `topplain`; tag suffix `_tp`). In the queue, PM `rt+tp`.
  Run commands and the queue entries are in `docs/TINYORAM_CARD_RUNBOOK.md` (Plaintext tree top).
* **Option off: the build is unchanged.** Patch 09 is applied to every fetch, but without `TINYORAM_TOP_PLAINTEXT`:
  * every core file it touches preprocesses to the same source as with patches 01–08 (7 sizes × 1:1/merged ×
    native/run-time depth);
  * `tinyoram_kernel.v` preprocesses to the 2026-10-30 kernel (the same 28 configurations).

### What it does

* **Which buckets.** A bucket is in the top when every 64-byte burst of it has a tree byte offset below the kernel's
  `top_bytes`. This is the same comparison the adapter uses to send a burst to the top port, so the top is exactly the
  set of buckets stored on package. A bucket that straddles the split counts as off-package.
* **Where the flag comes from.** The memory command stream, inside `AESPathORAM`:
  * one flag per bucket, from the bucket's first read command. A bucket's bursts are contiguous, so its first burst
    says where it ends. The bucket's data can come back before its last command is issued (2 KB and 4 KB buckets;
    mutant m4 takes the flag at the last command and is caught);
  * the write-back reuses the read's flags, because Tiny ORAM writes back the path it has just read, bucket by
    bucket, in the same order. A simulation check compares every write-back flag with the flag of that bucket's write
    commands.
* **Data path.**
  * A top bucket requests no keystream and is not XORed.
  * When nothing older is waiting in the AES data FIFO, its beats pass straight through in the same cycle. Otherwise
    they queue in order behind the older beats and leave without a mask.
  * Beat order and rate are unchanged, and reads are never refused.
  * Tiny ORAM reads and writes each path from the root down, so top buckets come first and always pass straight
    through: they add no cycles.
* **IV.**
  * The IV field of a top bucket still gets the global counter, and the counter still advances for every bucket
    written. So every off-top bucket gets the same IV, and the same ciphertext, as in the default build in the same
    run.
  * A written top bucket never reads as empty, since `DRAMToStash` treats IV 0 as a never-written bucket.
* **Write-back gate (a guard).** §24's zero-latency bypass took one extra write beat after a write-back, which broke
  the backend's write-back check. So the option counts each write-back's beats and takes none past the end until the
  next path read.
  * In this design the stash never offers such a beat. A probe counted 0 offered beats at 64 B, with the whole tree,
    the doma:20 top and no top.
  * Without the gate, every run passes too. So the gate never acts, and it has no mutant.
  * It is kept as a guard: a 16-bit counter that takes no cycles.
* **PMMAC: unchanged.** The per-block MAC and its check run in the front end, on every block, wherever it was read
  from.
* **Boot.** Unchanged. The kernel zero-fills the whole tree; a zero bucket reads as empty in the top (plaintext) and
  below it, as by default.
* **Report.** The kernel sets summary byte 1 bit 7. `host_doma` masks it out of the depth field and prints
  `Tiny ORAM bitstream: the tree top (DOMA_TINY_TOP) is stored in plaintext (TOP_PLAINTEXT)`. Older bitstreams leave
  the bit 0, and their output is unchanged.
* **Security.** As §24 found, nothing new is revealed:
  * the split is a fixed address map, and the cycles saved depend only on the path's leaf;
  * off-package data is written only in path write-backs, encrypted per destination bucket with a fresh IV.
* **An upstream property, unchanged.** `AES_W` feeds its two AES-128 cores the same input. Upstream marks this as a
  TODO: the padding should be unique per core. So each 256-bit keystream beat is two copies of one AES block, and the
  two 128-bit halves of an off-package beat are XORed with the same pad. This holds for every build so far, and the
  plaintext top does not change it. It is noted here because the memory inspection reproduces the keystream exactly.

### Regression (`sim/run_tinyoram_topplain.sh`, log `docs/tinyoram_topplain_2026-11-01.txt`)

All on Verilator 5.020: **53 of 53 checks pass** (in four runs, all seven sizes; the log has each).

* **Full run:** `bash sim/run_tinyoram_topplain.sh`, about 5 hours on 2 cores. `SZS`, `STAGES` choose a part. It needs
  `cryptography` for Python.
* **1. Default unchanged:** the 84 preprocessed comparisons above (3 core files × 28 configurations). The kernel
  check was made once against the 2026-10-30 kernel and is recorded in the log.
* **2. Lint** (`lint_tinyoram.sh`, every module, implicit nets) of the TOP_PLAINTEXT sources. Each size is checked at
  L = 10 and at the queue's L_max (run-time depth; 64 B: 19).
* **3. Default against TOP_PLAINTEXT, native L = 10, merged, at every size.** The same commands as §24: a preload of
  all 4,096 blocks at 64–512 B, then 300 commands.
  * **No top:** every response correct. The two builds are identical: every per-launch line, every bus burst in the
    same cycle, and the tree's final bytes.
  * **The top at doma:20's share of the size's 1M-record tree.** 64 B: 32%, the q8 1M point (8-byte records against
    DOMA's 32 B blocks); 128 B–4 KB: 16.4/21.8/19.7/19.3/13.7/12.9%. The whole tree on package too. In both:
    * every response is correct;
    * **memory inspection** (`sim/topplain/inspect_tree.py`) of both buffers at the end:
      * every written top bucket is plaintext, byte-identical to the default build's bucket after AES-CTR
        decryption;
      * every off-top bucket slot is byte-identical to the default build's, is ciphertext (no beat stored as it
        decrypts), and decrypts to a sane bucket;
      * every valid block's leaf puts its bucket on that leaf's path, and every data block holds exactly the last
        PUT of its key (4,095 of 4,096 at 64–512 B; the rest is in the stash).
  * **Cycles:** with the whole tree on package, both builds give exactly §24's run1 device cycles at every size (as
    shipped, and zero-latency plaintext).

| block | doma:20 top | default cycles/cmd | TOP_PLAINTEXT | saved | whole tree: default | TOP_PLAINTEXT | saved |
|---|---|---|---|---|---|---|---|
| 64 B | 32.0% | 867.2 | 855.8 | 1.32% | 851.7 | 809.4 | 4.96% |
| 128 B | 16.4% | 1,188.4 | 1,183.6 | 0.41% | 1,192.2 | 1,151.5 | 3.42% |
| 256 B | 21.8% | 1,914.7 | 1,914.7 | 0 | 1,919.8 | 1,878.4 | 2.16% |
| 512 B | 19.7% | 3,409.2 | 3,406.1 | 0.09% | 3,414.9 | 3,373.3 | 1.22% |
| 1 KB | 19.3% | 2,936.2 | 2,935.1 | 0.04% | 2,939.9 | 2,928.0 | 0.41% |
| 2 KB | 13.7% | 5,492.8 | 5,492.8 | 0 | 5,510.2 | 5,494.5 | 0.28% |
| 4 KB | 12.9% | 10,829.4 | 10,829.4 | 0 | 10,852.4 | 10,844.7 | 0.07% |

  * L = 10 here, so paths are short and the shares are larger than at the card's L = 18 (§24's table).
  * 1–4 KB run without a preload (§24).
  * At doma:20 only the paths that lie wholly in the top gain, as §24 predicted. There are none at 256 B, 2 KB and
    4 KB at this depth.
* **4. The queue's configuration.** The run-time-depth TOP_PLAINTEXT build (L_max 18; 64 B: 19), run at L = 10 with
  the doma:20 split, against the native L = 10 TOP_PLAINTEXT build: both correct, the same bursts in the same cycles,
  and the same block bytes, at every size. 64 B runs with the full preload (50,285 bursts); the others run 20–40
  commands after the zero-fill.
* **5. Mutants**, each caught:
  * m1: the IV counter not advanced for top buckets. Off-top IVs shift.
  * m2: top buckets encrypted after all.
  * m4 (2 KB): the flag taken at a bucket's last read command, as first written. It is too late for 2 KB buckets.
    This was a real bug: the first version failed stage 3 at 2 KB, and the flag now comes from the bucket's first
    command.
* **Also, with patch 09 in:** `run_tinyoram.sh SIZES=64` passes 42/42. That includes the lint of every queue
  geometry and the card-script dry run, which now also covers:
  * entries 31–37: tags, status and sweeps;
  * the host's plaintext-top report;
  * `queue.sh start -j 2` with stand-in builds: each entry built once, never more than two at a time.

### Queue and runs

* **Queue ids 31–37** (`tinyoram/card/queue_topplain.txt`): q8, q10, q11, q15, q13, q14 and q12 with `+tp`, at 220 MHz.
  Each has the same size, N, packing, adapter and run-time depth as its original. They have new names and tags
  (`..._rt_tp`), so the existing copies and bitstreams are untouched.
* **`queue.sh start -j 2`** runs two workers. Each claims the next pending entry, so two builds run at a time.
* **Host:** no change is needed to run them. One launch serves 1M commands, as before. The only addition is the
  one-line report.
* **Commands:** install, build and runs are in the runbook (Plaintext tree top).
* **Matched budgets.** `doma:<pct>` uses the DOMA geometry of the 14:48 package (Z = 10, 8 blocks per bucket on
  average, a stash pool of the bound + 1% + 64). DOMA v14c builds with Z = 8, 6 per bucket and a pool of the bound
  + 1. Its on-package bytes at the same records and HBM share are 8–16% larger (64 B–4 KB at 1M records). Moving
  `doma_onpkg_bytes()` to v14c's sizing is a one-function host change. It is not made here, because it would also
  move the matched points of the runs already made.
