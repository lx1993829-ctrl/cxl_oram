#!/bin/bash
# fetch_tinyoram.sh -- get Tiny ORAM (Fletcher et al., FCCM 2015) and prepare it for the U55C kernel.
#
#   bash fetch_tinyoram.sh [size] [L] [merge] [flatpm]
#                                        size = 64 | 128 | 256 | 512 | 1k | 2k | 4k   (bytes; default 4k).
#                                               8-, 16- and 32-byte records go packed into 64 B blocks (the
#                                               host's DOMA_PACK=1): not Tiny ORAM block sizes (README §21)
#                                        L    = tree depth ORAML (default: the size's config, 6);
#                                               N = 4 * 2^L blocks, e.g. L=18 for 1M records
#                                        merge: the adapter merges contiguous commands into one
#                                               burst (TINYORAM_MERGE 1); default the 1:1 adapter
#                                        flatpm: no PosMap recursion, all N PosMap entries on chip
#                                               (TINYORAM_RECURSION 1, patch 07); default as published
#                                        rtdepth: run-time tree depth (TINYORAM_RTDEPTH, patch 08): built for
#                                               L_max = L, the host selects any depth 6..L_max at its init
#                                               launch, and the core then behaves as the native build of that
#                                               depth (README §18)
#                                        topplain: plaintext tree top (TINYORAM_TOP_PLAINTEXT, patch 09): buckets whose
#                                               tree offset is below the kernel's top_bytes (the on-package top) are
#                                               stored in plaintext, every other bucket exactly as by default (README §25)
#
# 1. downloads github.com/ascend-secure-processor/oram at commit 18ece07 (branch oram_fpga_public;
#    its RTL is identical to master) into tinyoram/upstream/  -- or uses TINYORAM_TARBALL=<file>
#    if the machine cannot reach GitHub (download the same commit's .tar.gz elsewhere)
# 2. applies our patches (tinyoram/patches/0*.diff) to a copy in tinyoram/build/patched/
#      01 build configuration header   02 Idle status output   03 zero-width parameter defaults
#      04 simulation-only check fixes (inside `ifdef SIMULATION; no effect on synthesis)
#      05 PosMapPLB fix (a leaf truncated to ORAML bits: wrong path after 2^ORAML accesses to a block)
#      06 no mark_debug attributes (debug-core markers only; cycle-identical)
#      07 TINYORAM_RECURSION option (default unchanged: Tiny ORAM's own recursion depth)
#      08 TINYORAM_RTDEPTH option (run-time tree depth; without the define the preprocessed core is unchanged)
#      09 TINYORAM_TOP_PLAINTEXT option (plaintext tree top; without the define the preprocessed core is unchanged)
# 3. writes tinyoram/build/src/: every core source and header in one flat directory (the names
#    are unique), plus tinyoram_config.vh for the chosen size and files.f (the source list)
# Tiny ORAM's sources are not redistributed with this package: the MIT-written files carry no
# license. Cite: C. W. Fletcher et al., "A Low-Latency, Low-Area Hardware Oblivious RAM
# Controller", FCCM 2015.
set -euo pipefail
here=$(cd "$(dirname "$0")" && pwd)
SIZE=${1:-4k}
LV=${2:-}
MG=""; FP=""; RT=""; TP=""
for o in "${@:3}"; do
    case "$o" in merge) MG=merge ;; flatpm) FP=flatpm ;; rtdepth) RT=rtdepth ;; topplain) TP=topplain ;;
        *) echo "unknown option '$o' (merge, flatpm, rtdepth, topplain)"; exit 2 ;; esac
done
[ -n "$FP" ] && [ -n "$RT" ] && { echo "flatpm and rtdepth do not combine (a flat PosMap is sized for one N)"; exit 2; }
COMMIT=18ece0764c4feb5b34f568b2bf9e18081a781a06
cfg=$here/config/tinyoram_config_$SIZE.vh
case "$SIZE" in 8|16|32) echo "$SIZE-byte blocks: not a Tiny ORAM block size. Its backend moves whole 64-byte DRAM bursts per block (a"
    echo "smaller block never starts an eviction), and its PosMap blocks hold ORAMB/64 entries; pack the records into 64 B"
    echo "blocks instead (DOMA_PACK=1; README §21)"; exit 2 ;; esac
[ -f "$cfg" ] || { echo "unknown size '$SIZE' (want 64, 128, 256, 512, 1k, 2k or 4k)"; exit 2; }

up=$here/upstream
if [ ! -f "$up/TinyORAMCore.v" ]; then
    rm -rf "$up"; mkdir -p "$up"
    tb=${TINYORAM_TARBALL:-$here/oram-$COMMIT.tar.gz}
    if [ -f "$tb" ]; then
        tar -xzf "$tb" -C "$up" --strip-components=1
    elif command -v git >/dev/null && git clone -q -b oram_fpga_public https://github.com/ascend-secure-processor/oram.git "$up.git" 2>/dev/null; then
        (cd "$up.git" && git checkout -q $COMMIT && git archive $COMMIT) | tar -x -C "$up"; rm -rf "$up.git"
    else
        echo "downloading Tiny ORAM $COMMIT ..."
        wget -q -O "$tb" "https://github.com/ascend-secure-processor/oram/archive/$COMMIT.tar.gz" \
            || curl -sSL -o "$tb" "https://github.com/ascend-secure-processor/oram/archive/$COMMIT.tar.gz"
        tar -xzf "$tb" -C "$up" --strip-components=1
    fi
    [ -f "$up/TinyORAMCore.v" ] || { echo "download/unpack failed (set TINYORAM_TARBALL to a downloaded .tar.gz)"; exit 1; }
fi

b=$here/build
rm -rf "$b/patched" "$b/src"; mkdir -p "$b"
cp -rL "$up" "$b/patched"
for p in "$here"/patches/0*.diff; do
    (cd "$b/patched" && patch -s -p1 < "$p") || { echo "patch $(basename "$p") failed"; exit 1; }
done

# the synthesizable core: no testbenches, no ASIC wrappers/SRAMs, no unused inverse AES,
# no board files; PrioritySelect.v is unused and has a syntax error (unnamed instance).
# Vivado reads every file it is given (synth_design; package_tinyoram.tcl globs build/src/*.v), not only
# the modules the design uses, so a dead file can stop a build: DRAMInitializer.v names an undeclared
# LastBuckerAddr ([Synth 8-36]), and aes_192.v/aes_256.v instantiate their rounds with the wrong number of
# ports. Left out as well: every other file whose modules are named by no other file, in any configuration
# (checked with Verilator's elaborated module list over all four block sizes, 1:1/merged/flat position map,
# with and without SIMULATION; README §16). Files named by an inactive generate branch (the REW-ORAM files,
# Bin2Gray/Gray2Bin, padder1) stay, so every tool still finds the modules those branches name.
DEAD="DRAMInitializer.v aes_192.v aes_256.v ClockSource.v FIFOLinear.v LFSR.v ROISeedGenerator.v SynthesizedRandDRAM.v DRAM2RAM.v SynthesizedDRAM.v"
mkdir -p "$b/src"
(cd "$b/patched" && find . -name '*.v' -not -path '*/test/*' -not -path '*/old/*' -not -path './sram_wrap/*' \
    -not -path '*/bench/*' -not -name 'aes_inv*' -not -name 'test_*' -not -name 'tiny_aes_vc707.v' \
    -not -name 'PrioritySelect.v' -not -name '*ASIC*' | sort) | while read -r f; do
    case " $DEAD " in *" $(basename "$f") "*) ;; *) echo "$f" ;; esac; done > "$b/core.lst"
dups=$(xargs -n1 basename < "$b/core.lst" | sort | uniq -d)
[ -z "$dups" ] || { echo "duplicate file names: $dups"; exit 1; }
while read -r f; do cp "$b/patched/$f" "$b/src/"; done < "$b/core.lst"
cp "$b/patched/include/"*.vh "$b/patched/include/DRAM.constants" "$b/src/"
cp "$cfg" "$b/src/tinyoram_config.vh"
if [ -n "$LV" ]; then
    [[ "$LV" =~ ^[0-9]+$ ]] && [ "$LV" -ge 6 ] && [ "$LV" -le 26 ] || { echo "L must be 6..26"; exit 2; }
    sed -i -E "s/^(\`define TINYORAM_ORAML +)[0-9]+.*/\1$LV        \/\/ set by fetch_tinyoram.sh: N = $((4 << LV)) blocks/" "$b/src/tinyoram_config.vh"
fi
(cd "$b/src" && ls *.v) > "$b/src/files.f"
if [ "$MG" = merge ]; then
    sed -i 's#^`endif#`define TINYORAM_MERGE     1        // set by fetch_tinyoram.sh: merged bursts in the adapter\n`endif#' "$b/src/tinyoram_config.vh"
fi
if [ "$RT" = rtdepth ]; then
    sed -i 's#^`endif#`define TINYORAM_RTDEPTH   1        // set by fetch_tinyoram.sh: run-time tree depth, L_max = ORAML (patch 08)\n`endif#' "$b/src/tinyoram_config.vh"
fi
if [ "$TP" = topplain ]; then
    sed -i 's#^`endif#`define TINYORAM_TOP_PLAINTEXT 1    // set by fetch_tinyoram.sh: the on-package tree top in plaintext (patch 09)\n`endif#' "$b/src/tinyoram_config.vh"
fi
if [ "$FP" = flatpm ]; then
    sed -i 's#^`endif#`define TINYORAM_RECURSION 1        // set by fetch_tinyoram.sh: flat on-chip PosMap, no recursion\n`endif#' "$b/src/tinyoram_config.vh"
else
    # PosMap recursion depth. Tiny ORAM's rule (UORAM.vh) is "recursive until < 1024 entries in PosMap", written as
    # divceil(L + 2 - 10, 4 - PRFPosMap) + 1: 3 bits per level, which is log2 of the 8 leaves a 64-byte PosMap block
    # holds. A block of ORAMB bits holds ORAMB/64 leaves (LeafWidth = AESEntropy = 64), so the same rule in general is
    # divceil(L + 2 - 10, log2(ORAMB/64)) + 1. At 64 B the two are equal for every L, and nothing is written. Larger
    # blocks get one level too many from the 3-bit form; at 4 KB with L >= 12 the last level then has no entries at
    # all (FinalPosMapEntry = 0: CountAlarm #(.Threshold(0)) in PosMapPLB, a zero replication that iverilog and
    # Verilator reject). There the general form is written, through patch 07's define (README §17).
    ob=$(grep -oE '^`define TINYORAM_ORAMB +[0-9]+' "$b/src/tinyoram_config.vh" | awk '{print $3}')
    ol=$(grep -oE '^`define TINYORAM_ORAML +[0-9]+' "$b/src/tinyoram_config.vh" | awk '{print $3}')
    lg=0; while [ $((1 << lg)) -lt $((ob / 64)) ]; do lg=$((lg + 1)); done
    x=$((ol + 2 - 10)); r_up=1; r_gen=1
    [ $x -gt 0 ] && r_up=$(( (x + 2) / 3 + 1 )) && r_gen=$(( (x + lg - 1) / lg + 1 ))
    if [ $r_gen != $r_up ]; then
        sed -i 's#^`endif#`define TINYORAM_RECURSION '$r_gen'        // set by fetch_tinyoram.sh: Tiny ORAM'"'"'s depth rule for '$((ob / 8))'-byte blocks ('$lg' bits per level; its 3-bit form gives '$r_up', README §17)\n`endif#' "$b/src/tinyoram_config.vh"
    fi
    # the on-chip final PosMap (PLBLocal.vh: FinalPosMapEntry) must have 1..1024 entries
    fin=$(( (4 << ol) >> (lg * (r_gen - 1)) ))
    [ $fin -ge 1 ] && [ $fin -le 1024 ] || { echo "PosMap depth $r_gen leaves $fin final entries (want 1..1024)"; exit 1; }
fi
echo "Tiny ORAM ready: $(wc -l < "$b/src/files.f") sources in $b/src, configuration $SIZE ($(grep -oE '(ORAM[BL]|MERGE|RECURSION|RTDEPTH|TOP_PLAINTEXT) +[0-9]+' "$b/src/tinyoram_config.vh" | tr '\n' ' '))"
