#!/bin/bash
# lint_tinyoram.sh -- iverilog checks of the Tiny ORAM sources for errors that Verilator lets through and Vivado does not.
#   bash lint_tinyoram.sh <src dir> <tinyoram_config.vh> <log prefix> [-D... defines]
#   (src dir: a fetched ../tinyoram/build/src; the kernel and adapter come from ../tinyoram/rtl, or KR= / AD=)
# 1. Reachable: elaborate from tinyoram_kernel with -Wimplicit. Vivado treats a name used in a port connection before
#    its declaration as an implicit wire and then rejects the declaration ("already declared"); every implicit net
#    fails except the eight listed below.
# 2. Every module of every .v file in the src dir (the files Vivado reads: package_tinyoram.tcl globs them all), the
#    kernel and the adapter, each elaborated as its own top, as Vivado analyses every file it is given. Fails on an
#    undeclared or unbound name, an unknown module, a port mismatch, a syntax error, or an implicit net not listed.
#    Errors that come only from a module's default parameters when it is its own top (CountAlarm's zero-width
#    replication) are listed, not failed: in the design the parameters are set (step 1 covers that).
# The eight implicit nets of Tiny ORAM's core are all in its REW-ORAM branch (EnableREW = 1), which no build here
# elaborates, and none is declared later. A lint-only copy of AES_DW.v sizes one genvar sum (DataIn + j: a genvar is
# a 32-bit integer, so the sum is 64 bits; iverilog will not size it, Vivado and Verilator do).
# Exit 0 = clean. Logs: <log prefix>.reach.log, <log prefix>.modules.log
set -u
SRCD=${1:?usage: lint_tinyoram.sh <src dir> <config.vh> <log prefix> [defines]}; CFG=${2:?}; LOG=${3:?}; shift 3
KR=${KR:-../tinyoram/rtl/tinyoram_kernel.v}; AD=${AD:-../tinyoram/rtl/tinyoram_axi_adapter.v}
CORE_IMPLICIT="AESREWORAM.v:535:RW_R_Ctr AESREWORAM.v:536:RW_W_Ctr AESREWORAM.v:537:RO_R_Ctr AESREWORAM.v:538:RO_W_Ctr
PathORAMBackend.v:375:ROStartAESValid PathORAMBackend.v:376:ROStartAESReady PathORAMBackend.v:385:PBF_DRAMReadData
PathORAMBackend.v:386:PBF_DRAMReadDataValid"
L=$(mktemp -d); trap 'rm -rf "$L"' EXIT
mkdir -p $L/src $L/cfg && cp "$SRCD"/* $L/src/ && cp "$CFG" $L/cfg/tinyoram_config.vh
sed -i "s/DataIn + j}/DataIn + AESEntropy'(j)}/" $L/src/AES_DW.v
FILES="$(ls $L/src/*.v) $KR $AD"
bad=0
implicit() {   # implicit <log>: implicit nets not in the list
    grep "implicit definition" "$1" | while read -r line; do
        f=$(echo "$line" | sed -E 's#^.*/##; s#^([^:]+):([0-9]+):.*'"'"'(.*)'"'"'.*#\1:\2:\3#')
        case " $(echo $CORE_IMPLICIT) " in *" $f "*) ;; *) echo "$line";; esac
    done; }
# 1. reachable from the top, with this configuration
iverilog -g2012 -Wimplicit "$@" -I$L/cfg -I$L/src -o /dev/null -s tinyoram_kernel $FILES > $LOG.reach.log 2>&1
rc=$?; x=$(implicit $LOG.reach.log)
[ $rc = 0 ] || { echo "   reachable: iverilog errors ($LOG.reach.log):"; grep -i "error" $LOG.reach.log | head -5 | sed 's/^/     /'; bad=1; }
[ -z "$x" ] || { echo "   reachable: implicit nets:"; echo "$x" | head -5 | sed 's/^/     /'; bad=1; }
# 2. every module as its own top (LINT_MODULES=0 skips this part)
[ "${LINT_MODULES:-1}" = 0 ] && exit $bad
: > $LOG.modules.log; nmod=0; nnote=0
for m in $(grep -hoE "^\s*module\s+[A-Za-z_][A-Za-z0-9_]*" $FILES | awk '{print $2}' | sort -u); do
    nmod=$((nmod+1))
    iverilog -g2012 -Wimplicit "$@" -I$L/cfg -I$L/src -o /dev/null -s $m $FILES > $L/m.log 2>&1
    { echo "== $m"; cat $L/m.log; } >> $LOG.modules.log
    hard=$(grep -iE "Unable to bind|Unknown module type|not declared|already declared|Wrong number of ports|is not a port|syntax error|I give up" $L/m.log | head -3)
    x=$(implicit $L/m.log)
    if [ -n "$hard" ] || [ -n "$x" ]; then echo "   module $m:"; { echo "$hard"; echo "$x"; } | grep -v '^$' | sed "s#$L/src/##; s/^/     /"; bad=1
    elif grep -qi "error" $L/m.log; then nnote=$((nnote+1)); fi
done
echo "   $nmod modules each elaborated as its own top; $nnote with errors only from their default parameters (listed in $LOG.modules.log)"
exit $bad
