#!/bin/bash
# ys_depth.sh -- a logic-depth proxy without Vivado (docs/overlap_rtl_spec.md section 11). The controller, top and kernel
# (where the overlap logic lives) are mapped to UltraScale+ cells by Yosys (synth_xilinx -family xcup, no LUT RAM), with
# the datapath blocks (GCM, stash, scratch, AXI masters, HBM tables) as black boxes; ys_depth.py then lists the deepest
# logic in front of each register (LUT = 1, MUXF7/8/9 = 0.3, carry chain 1 + 0.15 per CARRY4). Not a timing analysis:
# compare the overlap builds with v14d1, whose paths closed at 300 MHz on the card.
#   bash ys_depth.sh            # v14d1, step 1, step 2 (two at a time); about 3 min each; reports in build/ys/*.depth
#   bash ys_depth.sh step2      # step 2 only (the read unit axi_rd2 is synthesized; axi_master stays a black box)
set -u
cd "$(dirname "$0")"
RTL=$(cd "${RTL_DIR:-../rtl}" && pwd); O=build/ys; mkdir -p $O
command -v yosys > /dev/null || { echo "yosys not found: source the OSS CAD Suite environment first"; exit 1; }
yosys -V
LIB=""
for f in aes_func aes128_key_expansion_fpga aes128_round_fpga aes128_pipe2_fpga ghash_single_cycle_fpga ghash_lane3 ghash_lane6 \
         aes_gcm_pipelined aes_gcm_2lane axi_master pos_map_hbm bucket_rec_hbm rng_bucket scratch_buf stash_hbm lease_token_table plain_oram_top; do
    LIB="$LIB $RTL/$f.v"; done
one() {
    local t=$1; shift
    local D="-DORAM_BLOCK_BEATS=128 -DORAM_C=7 -DORAM_N=2097152 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -DSYNTHESIS $*"
    cat > $O/$t.ys <<YS
read_verilog -lib -sv $D -I $RTL $LIB
read_verilog -sv $D -I $RTL $RTL/axi_rd2.v $RTL/wb_pf.v $RTL/flat_oram_gcm.v $RTL/secure_oram_top.v $RTL/doma_kernel.v
hierarchy -top doma_kernel
synth_xilinx -family xcup -top doma_kernel -flatten -noiopad -nolutram -nosrl
stat -tech xilinx
delete t:RAMB* t:\$mem*
write_json $O/$t.json
YS
    yosys -q -l $O/$t.log $O/$t.ys > $O/$t.out 2>&1 || { echo "$t: yosys FAILED, last lines of $O/$t.out:"; tail -15 $O/$t.out; return; }
    python3 ys_depth.py $O/$t.json 30 > $O/$t.depth && rm -f $O/$t.json
    echo "== $t: $(head -1 $O/$t.depth)"
}
if [ "${1:-all}" = step2 ]; then T="step2"; one step2 -DORAM_OVERLAP2 -DORAM_OVERLAP4   # bash ys_depth.sh step2: step 2 only
else T="v14d1 step1 step2"; one v14d1 & one step1 -DORAM_OVERLAP2 & wait; one step2 -DORAM_OVERLAP2 -DORAM_OVERLAP4; fi
for t in $T; do
    echo "== $t, deepest register groups (depth, endpoint):"
    sed -n '3,$p' $O/$t.depth | grep -E "^ *[0-9]+\.[0-9]+ " | head -12
done
