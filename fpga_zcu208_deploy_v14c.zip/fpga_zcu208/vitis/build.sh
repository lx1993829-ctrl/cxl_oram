#!/bin/bash
# build.sh -- doma_kernel.xo -> doma.xclbin -> host program  (UNTESTED here)
# Needs Vitis 2024.1 (the version BOLT used), XRT, and the U55C platform installed.
#   TARGET=hw      bash build.sh   # board bitstream (hours)
#   TARGET=hw_emu  bash build.sh   # hardware emulation, no card needed
#   BEATS=8 TARGET=hw bash build.sh   # 256-byte blocks (1, 2, 4, 8 beats = 32-256 B; default 4 KB)
set -euo pipefail
cd "$(dirname "$0")"
PLATFORM=${PLATFORM:-xilinx_u55c_gen3x16_xdma_3_202210_1}     # BOLT's xclbins use this platform
TARGET=${TARGET:-hw}
CFG=${CFG:-doma.cfg}                  # CFG=doma_emu.cfg if hw_emu cannot use host memory
BEATS=${BEATS:-}                      # block size in 32-byte beats: 1, 2, 4, 8 (32-256 B); empty = 4 KB
if [ -n "$BEATS" ]; then
    printf '// written by build.sh\n`ifndef ORAM_BLOCK_BEATS\n`define ORAM_BLOCK_BEATS %s\n`endif\n' "$BEATS" > ../rtl/oram_build_cfg.vh
    # NMAX: the build's maximum number of blocks (the host chooses n <= NMAX at run time); default 256
    [ -n "${NMAX:-}" ] && printf '`ifndef ORAM_N\n`define ORAM_N %s\n`endif\n' "$NMAX" >> ../rtl/oram_build_cfg.vh
else
    printf '// written by build.sh: default block size (4 KB)\n' > ../rtl/oram_build_cfg.vh
    [ -n "${NMAX:-}" ] && printf '`ifndef ORAM_N\n`define ORAM_N %s\n`endif\n' "$NMAX" >> ../rtl/oram_build_cfg.vh
fi
# SCHED=arrival: arrival-relative scheduling. Everything secret-dependent stays padded (the lookup, the requested
# block's path, evictions); a bucket's own read latency is not (see docs/README_FPGA.md for the condition).
if [ "${SCHED:-strict}" = "arrival" ]; then
    printf '`define ORAM_SCHED_ARRIVAL\n' >> ../rtl/oram_build_cfg.vh
fi
# TRACE=1: the phase-trace variant (docs/README_FPGA.md, "Phase trace"). Every response header carries the bucket-port
# timestamps, and with bit 31 of size set each command also writes a 32-byte record of 16 phase timestamps. Without it
# the RTL is exactly the untraced design; build it in its own folder so both bitstreams stay available.
if [ "${TRACE:-0}" = "1" ]; then
    printf '`define ORAM_PHASE_TRACE\n' >> ../rtl/oram_build_cfg.vh
fi
# DEBUG=1 (v14b, needs TRACE=1 and SCHED=arrival): the on-package debug variant (docs/v14b_card_calibration.md). An
# on-package timing overrun is recorded and counted, never halts; each 128-byte trace record (v14c) carries the core's access
# record; the summary is followed by the debug records. For calibrating AR_WB_H / AR_REL_H on the card only: never
# measure with it, never deploy it. Build it in its own folder.
if [ "${DEBUG:-0}" = "1" ]; then
    [ "${TRACE:-0}" = "1" ] && [ "${SCHED:-strict}" = "arrival" ] || { echo "DEBUG=1 needs TRACE=1 and SCHED=arrival"; exit 1; }
    printf '`define ORAM_ONPKG_DEBUG\n' >> ../rtl/oram_build_cfg.vh
fi
# INTERIM=1 (v14b, 4 KB blocks, LAMBDA=7, SCHED=arrival): the interim on-package budgets (rtl/oram_params.vh: AR_WB_H
# 1455, AR_REL_H 2538, covering stash reads of up to 500 cycles) in place of v14's (855, 1938), until the card
# calibration (docs/v14b_card_calibration.md) sets the defaults. Off-package budgets are unchanged.
if [ "${INTERIM:-0}" = "1" ]; then
    { [ "${LAMBDA:-6}" = "7" ] && [ "${SCHED:-strict}" = "arrival" ] && { [ -z "${BEATS:-}" ] || [ "${BEATS}" = 128 ]; }; } \
        || { echo "INTERIM=1 is for 4 KB blocks, LAMBDA=7, SCHED=arrival"; exit 1; }
    printf '`define ORAM_ONPKG_INTERIM\n' >> ../rtl/oram_build_cfg.vh
fi
# PLAIN=1: the non-oblivious baseline (rtl/plain_oram_top.v instead of DOMA's core; docs/README_FPGA.md, "Baseline").
# Run it with DOMA_HBM_PCT=75 DOMA_POOL=64 so the HBM page buffer holds exactly one slot per record.
if [ "${PLAIN:-0}" = "1" ]; then
    [ "${TRACE:-0}" = "1" ] && { echo "PLAIN=1 and TRACE=1 together are not supported"; exit 1; }
    printf '`define ORAM_PLAIN\n' >> ../rtl/oram_build_cfg.vh
fi
# LAMBDA: slots per bucket (default 6, in rtl/oram_params.vh); the host programs need DOMA_LAMBDA=<the same> to run it
[ -n "${LAMBDA:-}" ] && printf '`ifndef ORAM_C\n`define ORAM_C %s\n`endif\n' "$LAMBDA" >> ../rtl/oram_build_cfg.vh
echo "lambda: ${LAMBDA:-6}, block size: ${BEATS:-128} beats ($(( ${BEATS:-128} * 32 )) bytes), scheduling: ${SCHED:-strict}, phase trace: $([ "${TRACE:-0}" = 1 ] && echo on || echo off), on-package debug: $([ "${DEBUG:-0}" = 1 ] && echo "ON (calibration only)" || echo off), on-package budgets: $([ "${INTERIM:-0}" = 1 ] && echo "INTERIM (500-cycle stash reads)" || echo default), core: $([ "${PLAIN:-0}" = 1 ] && echo "PLAIN baseline" || echo DOMA)"
vivado -mode batch -nojournal -nolog -source package_kernel.tcl -tclargs ../rtl doma_kernel.xo
# hardware builds: after placement, write the placed checkpoint and congestion/utilization/timing reports
# (post_place.tcl), so even a stopped build leaves evidence in _x/link/vivado/vpl/prj/prj.runs/impl_1/
HOOK=""
if [ "$TARGET" = "hw" ]; then HOOK="--vivado.prop run.impl_1.STEPS.PLACE_DESIGN.TCL.POST=$(pwd)/post_place.tcl"; fi
v++ -l -t $TARGET --platform $PLATFORM --kernel_frequency 300 --config $CFG $HOOK \
    --save-temps -o doma_$TARGET.xclbin doma_kernel.xo
g++ -std=c++17 -O2 host_doma.cpp -I$XILINX_XRT/include -L$XILINX_XRT/lib -lxrt_coreutil -pthread -o host_doma
if [ "$TARGET" = hw ]; then ./check_timing.sh || echo "*** TIMING NOT CLOSED: do not use doma_hw.xclbin for measurements ***"; fi
if [ "$TARGET" = hw_emu ]; then emconfigutil --platform $PLATFORM; echo "run: XCL_EMULATION_MODE=hw_emu ./host_doma doma_hw_emu.xclbin"; fi
