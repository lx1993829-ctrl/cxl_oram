// doma_debug.h -- v14b: the controller's halt record and the debug build's on-package records, decoded for the host
// programs (host_doma.cpp, host_phases.cpp). Header-only; included once per program.
//
// Halt record (every build): a halted launch's summary carries it in place of the latency fields (lat_min = bits 31:0,
// lat_max = bits 63:32): [63:40] bucket, [39:35] state, [34] HBM bucket, [33:32] on-package deadline (01 write-back
// start, t_arr + AR_WB_H; 10 hand-off, t_arr + AR_REL_H; 11 scratch bank conflict; 00 another cause), [31:20] cycles
// missed by (saturating at 4095), [19:17] memory-unit errors (position map, bucket records, stash), [16] the missed
// time is a lower bound (the late event had not happened when the summary was written; a later launch's summary has
// the final value), [15:0] access cycle.
//
// Summary byte 2: [0] debug records, [1] debug trace records (64 bytes in v14b), [2] interim on-package budgets
// (build.sh INTERIM=1), [3] (v14c) the trace records are 128 bytes: beat 2 is the access's stash open.
// Debug build (build.sh DEBUG=1 TRACE=1; summary byte 2 bit 0): records [n+2] counters (0x5C), [n+3] the first
// on-package overrun (0x5D), [n+4] the first deadline (2) miss (0x5E); the response data then starts at
// roundup4k((n + 5) * 32). With bit 1 (and size bit 31 set), each trace record is 64 bytes: the 16 phase timestamps,
// then the core's per-access record (16-bit access cycles, 0xFFFF = did not happen):
//   0 t_arr  1 flags  2 write-back issued  3 release gate reached (write handed off)  4 last W  5 first W
//   6 bucket record in  7 stash open issued  8 stash ready (decisions start)  9 S_SCAN entered  10 last copy landed
//   11 cycles W held by the memory  12 cycles writing with no W offered  13 bucket read AR  14 first R  15 access end
//   flags: [0] on package, [1] plaintext path, [2] deadline (1) missed, [3] deadline (2) missed, [4] bank conflict,
//          [5] arrival seen, [6] PUT, [11:8] eviction copies
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

static int SUMREC = 2;              // records after the n headers: 2 (summary, traffic), 5 in a debug bitstream
static bool TRACE64 = false;        // debug trace records (64 or 128 bytes: beat 1 holds the access's timestamps)
static size_t TRACE_B = 32;         // trace record size: 32, 64 (v14b debug) or 128 bytes (v14c debug: beat 2, the stash open)

static const char* DOMA_STATE[32] = {"S_IDLE", "S_POS_LOOKUP", "S_RD_GATE", "S_DDR_READ", "S_CR_IV", "S_CR_IVW", "S_CR_START",
    "S_CR_FEED", "S_CR_RECV", "S_CR_TAG", "S_SCAN", "S_OP", "S_CP", "S_COMPACT", "S_COMPACT2", "S_PM_UPD", "S_EVICT",
    "S_EVICT_CHK", "S_EVICT_DONE", "S_EVICT_WAIT", "S_EA_START", "S_WB_GATE", "S_DDR_WRITE", "S_DONE_GATE",
    "S_RES_STREAM", "S_FMT_START", "S_FMT_WRITE", "S_FMT_WAIT", "S_HALT", "S_LAYOUT", "S_UNUSED30", "S_UNUSED31"};

// the summary's byte 2: debug flags (0 in a normal bitstream)
static void dbg_from_summary(const uint8_t* sum) {
    SUMREC  = (sum[2] & 1) ? 5 : 2;
    TRACE64 = (sum[2] & 10) != 0;
    TRACE_B = (sum[2] & 8) ? 128 : (sum[2] & 2) ? 64 : 32;
    if (sum[2] & 1)
        std::printf("DEBUG BITSTREAM (build.sh DEBUG=1): on-package overruns are recorded and do not halt; never use it for measurements\n");
    if (sum[2] & 4)
        std::printf("on-package budgets: INTERIM (build.sh INTERIM=1: AR_WB_H 1455, AR_REL_H 2538 at 4 KB; stash reads up to 500 cycles)\n");
}

static void print_halt_record(const char* where, uint32_t lo, uint32_t hi) {
    const uint64_t h = (uint64_t(hi) << 32) | lo;
    const unsigned st = (h >> 35) & 31, code = (h >> 32) & 3, by = (h >> 20) & 0xFFF, ue = (h >> 17) & 7;
    static const char* DL[4] = {"", "deadline (1): the write-back had not started at t_arr + AR_WB_H",
                                "deadline (2): the write was not handed off at the release time t_arr + AR_REL_H",
                                "a scratch bank conflict on the on-package path"};
    std::printf("halt record (%s): state %u (%s), access cycle %u, bucket %llu (%s), memory-unit errors:%s%s%s%s\n", where,
                st, DOMA_STATE[st], unsigned(h & 0xFFFF), (unsigned long long)(h >> 40), ((h >> 34) & 1) ? "HBM" : "host",
                (ue & 4) ? " position map" : "", (ue & 2) ? " bucket records" : "", (ue & 1) ? " stash" : "", ue ? "" : " none");
    if (code)
        std::printf("halt record (%s): on-package timing overrun, %s; missed by %s%u cycles%s%s\n", where, DL[code],
                    ((h >> 16) & 1) ? "at least " : "", by, (by == 4095) ? " (saturated)" : "",
                    ((h >> 16) & 1) ? " (still running when this summary was written; a later launch's summary has the final value)" : "");
}

static inline uint16_t rd16(const uint8_t* p) { uint16_t v; std::memcpy(&v, p, 2); return v; }
static inline uint32_t rd32(const uint8_t* p) { uint32_t v; std::memcpy(&v, p, 4); return v; }

// records [n+2] .. [n+4]; r points at record [n+2]
static void print_debug_records(const char* where, const uint8_t* r) {
    if (r[0] != 0x5C) { std::printf("debug (%s): no counters record\n", where); return; }
    std::printf("debug (%s): since boot %u on-package accesses; deadline (1) missed %u (worst by %u), deadline (2) missed %u "
                "(worst by %u), scratch bank conflicts %u; worst after the arrival: write-back start %u, release gate %u, stash "
                "ready %u (budgets AR_WB_H %u, AR_REL_H %u)\n", where,
                rd32(r + 8), rd32(r + 12), rd16(r + 6), rd32(r + 16), rd16(r + 24), rd32(r + 20), rd16(r + 26), rd16(r + 28),
                rd16(r + 30), rd16(r + 2), rd16(r + 4));
    for (int k = 1; k <= 2; k++) {
        const uint8_t* s = r + 32 * k;
        if (s[0] != (k == 1 ? 0x5D : 0x5E)) continue;
        static const char* EV[4] = {"?", "deadline (1), write-back not started at t_arr + AR_WB_H",
                                    "deadline (2), not handed off at t_arr + AR_REL_H", "scratch bank conflict"};
        const uint8_t f = s[3];
        auto o = [](uint8_t x) { return int(int8_t(x)); };
        std::printf("debug (%s): %s: %s; access %u since boot, state %u (%s), access cycle %u, %u cycles after the arrival, "
                    "missed by %u%s\n", where, k == 1 ? "first on-package overrun" : "first deadline (2) miss", EV[s[1] & 3],
                    rd32(s + 4), s[2] & 31, DOMA_STATE[s[2] & 31], rd16(s + 8), rd16(s + 10), rd16(s + 12),
                    rd16(s + 12) ? "" : " (0: the access had not ended)");
        std::printf("debug (%s):   %u copy beats landed, copies done %u of %u queued (pending mask 0x%02x), %u bucket beats "
                    "written, %u positions sendable; flags:%s%s%s%s%s%s%s%s\n", where, rd16(s + 14), s[16] >> 4, s[16] & 15, s[17],
                    rd16(s + 18), s[31] & 15, (f & 1) ? " on-package" : "", (f & 2) ? " arrived" : "", (f & 4) ? " write-back-not-issued" : "",
                    (f & 8) ? " writing" : "", (f & 16) ? " stash-ready" : "", (f & 32) ? " stash-quiet" : "", (f & 64) ? " record-in" : "",
                    (f & 128) ? " copy-running" : "");
        std::printf("debug (%s):   bucket port: %d addresses waiting for data, %d bursts waiting for B, %d reads outstanding, "
                    "AW/W/B/AR/R valid-ready 0x%02x; stash port: %d, %d, %d, 0x%02x (bucket %u)\n", where,
                    o(s[20]), o(s[21]), o(s[22]), s[23], o(s[24]), o(s[25]), o(s[26]), s[27], rd32(s + 28) & 0xFFFFFF);
    }
}

// per-access records -> distributions (on-package accesses) and an optional CSV (DOMA_ONPKG_CSV). With 128-byte
// records (v14c debug) the third beat describes the access's stash open on the stash port: the CSV gains 16 columns
// (s0 .. s15, the raw 16-bit words, see flat_oram_gcm.v dbg_st_rec) and the distributions a stash section.
struct OnpkgStats {
    static const int NQ = 26;
    const char* name[NQ] = {"write-back start", "release gate (handed off)", "last W accepted", "first W accepted",
                            "bucket record in", "stash open issued", "stash ready", "S_SCAN entered", "last copy landed",
                            "W held by memory (cycles)", "W starved (cycles)", "bucket read latency (AR to first R)",
                            // v14c, the stash open (128-byte records)
                            "stash open complete", "stash: first read address", "stash: first read beat", "stash: head(b) landed",
                            "stash: first level-2 read address", "stash: last read beat", "stash: position lookup done",
                            "stash open: duration (cycles)", "stash open: reads", "stash open: read beats",
                            "stash open: longest read (cycles)", "stash open: mean read latency", "stash open: no beat, reads out",
                            "stash: last write response to open"};
    std::vector<std::vector<uint64_t>> h;     // signed value + 32768
    std::vector<int> mx, mn; std::vector<uint64_t> n;
    uint64_t on = 0, all = 0, miss1 = 0, miss2 = 0, bc = 0, bad = 0, st_n = 0, st_def = 0, st_rq = 0, st_chain = 0, st_same = 0;
    uint64_t wcnt[16] = {0}, wsum[16] = {0}; int wmax[16] = {0};      // open duration by b's window entries
    FILE* csv = nullptr; uint64_t launch = 0; bool csv_hdr = false;
    explicit OnpkgStats(bool with_csv = false) : h(NQ, std::vector<uint64_t>(65536, 0)), mx(NQ, -32768), mn(NQ, 32767), n(NQ, 0) {
        if (const char* f = with_csv ? std::getenv("DOMA_ONPKG_CSV") : nullptr) {
            csv = std::fopen(f, "w");
            if (!csv) std::printf("cannot write %s\n", f);
        }
    }
    ~OnpkgStats() { if (csv) std::fclose(csv); }
    void put(int q, int v) { v = std::max(-32768, std::min(32767, v)); h[q][v + 32768]++; n[q]++; mx[q] = std::max(mx[q], v); mn[q] = std::min(mn[q], v); }
    // one access: r = the record's beat 1 (32 bytes), s = beat 2 (the stash open; nullptr with 64-byte records)
    void add(size_t cmd, const uint8_t* r, const uint8_t* s = nullptr) {
        uint16_t w[16]; std::memcpy(w, r, 32);
        uint16_t x[16]; if (s) std::memcpy(x, s, 32);
        if (csv && !csv_hdr) {   // the header once, by the record size
            std::fprintf(csv, "launch,cmd,flags,tarr,ea,dg,wl,wf,bm,so,sx,se,cl,wst,wsv,ar,r1,end%s\n",
                         s ? ",s0,s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15" : "");
            csv_hdr = true;
        }
        all++;
        if (w[15] == 0xFFFF && w[0] == 0xFFFF) { bad++; return; }     // no access ended (a halt)
        if (csv) { std::fprintf(csv, "%llu,%zu", (unsigned long long)launch, cmd);
                   const int ord[16] = {1, 0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
                   for (int k : ord) std::fprintf(csv, ",%u", w[k]);
                   if (s) for (int k = 0; k < 16; k++) std::fprintf(csv, ",%u", x[k]);
                   std::fprintf(csv, "\n"); }
        if (!(w[1] & 2)) return;                                     // off package: not this calibration
        on++; if (w[1] & 4) miss1++; if (w[1] & 8) miss2++; if (w[1] & 16) bc++;
        const int ta = w[0];
        auto rel = [&](int q, uint16_t v) { if (v != 0xFFFF && ta != 0xFFFF) put(q, int(v) - ta); };
        rel(0, w[2]); rel(1, w[3]); rel(2, w[4]); rel(3, w[5]); rel(4, w[6]); rel(5, w[7]); rel(6, w[8]); rel(7, w[9]);
        rel(8, w[10]); put(9, w[11]); put(10, w[12]);
        if (w[13] != 0xFFFF && w[14] != 0xFFFF) put(11, int(w[14]) - int(w[13]));
        if (!s || x[15] == 0xFFFF) return;                           // no stash open recorded
        st_n++;
        rel(12, x[15]); rel(13, x[2]); rel(14, x[3]); rel(15, x[4]); rel(16, x[13]); rel(17, x[5]); rel(18, x[12]);
        const int nr = x[0] >> 8;
        if (w[7] != 0xFFFF) put(19, int(x[15]) - int(w[7]));
        put(20, nr); put(21, x[1]); put(22, x[6]); if (nr) put(23, x[7] / nr); put(24, x[9]);
        if (x[11] != 0xFFFF) put(25, x[11]);
        st_def += (x[0] >> 7) & 1; st_chain += (x[0] >> 6) & 1; st_same += (x[0] >> 5) & 1; st_rq += (x[0] >> 4) & 1;
        if (w[7] != 0xFFFF) { const int k = x[0] & 15, d = int(x[15]) - int(w[7]); wcnt[k]++; wsum[k] += d; wmax[k] = std::max(wmax[k], d); }
    }
    int pct(int q, double p) const {                                  // nearest rank
        if (!n[q]) return 0;
        const uint64_t k = std::max<uint64_t>(1, uint64_t(std::ceil(p * n[q]))); uint64_t c = 0;
        for (int i = 0; i < 65536; i++) { c += h[q][i]; if (c >= k) return i - 32768; }
        return mx[q];
    }
    void print(const char* where, unsigned wbh, unsigned relh) const {
        if (!all) return;
        std::printf("on-package calibration (%s): %llu accesses, %llu on package (plaintext path); deadline (1) missed %llu, "
                    "deadline (2) missed %llu, bank conflicts %llu (against AR_WB_H %u, AR_REL_H %u)%s\n", where,
                    (unsigned long long)all, (unsigned long long)on, (unsigned long long)miss1, (unsigned long long)miss2,
                    (unsigned long long)bc, wbh, relh, bad ? " [some commands had no record]" : "");
        if (!on) return;
        std::printf("on-package calibration (%s): cycles after the arrival (t_arr) unless noted: p50 / p99 / p99.9 / p99.99 / max (min)\n", where);
        for (int q = 0; q < NQ; q++) {
            if (q == 12 && n[q]) std::printf("  stash open (v14c debug records; on-package accesses):\n");
            if (n[q]) std::printf("  %-38s %6d %6d %6d %6d %6d  (%d)\n", name[q], pct(q, 0.5), pct(q, 0.99), pct(q, 0.999),
                                  pct(q, 0.9999), mx[q], mn[q]);
        }
        if (st_n) {
            std::printf("  stash opens: %llu; requested block stashed %llu, b has a chain %llu, bt == b %llu, deferred until quiet %llu\n",
                        (unsigned long long)st_n, (unsigned long long)st_rq, (unsigned long long)st_chain, (unsigned long long)st_same,
                        (unsigned long long)st_def);
            std::printf("  open duration by b's window entries:");
            for (int k = 0; k < 16; k++) if (wcnt[k]) std::printf("  %d: %llu x, mean %.0f, max %d", k, (unsigned long long)wcnt[k], double(wsum[k]) / wcnt[k], wmax[k]);
            std::printf("\n");
        }
        std::printf("on-package calibration (%s): card worst write-back start %d (AR_WB_H %u), release gate %d (AR_REL_H %u); "
                    "set the budgets with sim/card_budgets.py on DOMA_ONPKG_CSV\n", where, mx[0], wbh, mx[1], relh);
    }
};
