#!/bin/bash
# calibrate_all_sizes.sh -- v14c: the card calibration of the on-package budgets (AR_WB_H, AR_REL_H, AR_DONE_H) for
# every block size below 4 KB at lambda 7, as one batch: build the debug bitstreams, run them, report, write.
# Everything it reports is printed as text (and kept in cal/report.txt); nothing has to be copied off the server.
#
#   bash calibrate_all_sizes.sh build  [SIZES]   # debug bitstreams (DEBUG=1 TRACE=1 SCHED=arrival LAMBDA=7), JOBS at once
#   bash calibrate_all_sizes.sh timing [SIZES]   # each bitstream's kernel clock (check_timing.sh)
#   bash calibrate_all_sizes.sh run    [SIZES]   # 100% and 20% on package, ACC accesses each, per-access records (CSV)
#   bash calibrate_all_sizes.sh report [SIZES]   # sim/card_budgets.py per size, then one summary table and the defines
#   bash calibrate_all_sizes.sh write  [SIZES]   # write the defines into ../rtl/oram_params.vh (the production tree)
#   bash calibrate_all_sizes.sh all    [SIZES]   # build, timing, run, report (not write)
#
# SIZES: block sizes in 32-byte beats, default "1 2 4 8 16 32 64" (32 B .. 2 KB; 4 KB is calibrated already).
# Environment:
#   JOBS=2          bitstream builds at once (each needs ~32 GB and several hours)
#   CFG=doma.cfg    the connectivity file of the production builds (the stash must sit where production puts it)
#   NMAX=<n>        the production build's NMAX (or NMAX_<beats>=<n> per size); unset: build.sh's default
#   ACC=1048576     accesses per run (per on-package share); the card's 4 KB calibration used 12.5M in all
#   PCTS="100 20"   on-package shares to run
#   PCT=10          the margin (percent) for the budgets; ABS=74 the absolute margin
#   CMDS=65536      commands per launch (host_phases' argument)
#   DOMA_N, DOMA_POOL, ... (or DOMA_N_<beats>=...): passed to host_phases unchanged; use the production values
#   CAL=cal         the work folder (one subfolder per size: its own rtl/ and vitis/ copy, logs, CSVs)
# Each size builds in its own copy of rtl/ and vitis/ (build.sh writes rtl/oram_build_cfg.vh), so builds can run in
# parallel and the production tree is untouched until "write".
set -uo pipefail
cd "$(dirname "$0")"
VIT=$(pwd); ROOT=$(cd .. && pwd)
PHASE=${1:-}; shift || true
SIZES=${*:-"1 2 4 8 16 32 64"}
JOBS=${JOBS:-2}; CFG=${CFG:-doma.cfg}; ACC=${ACC:-1048576}; PCTS=${PCTS:-"100 20"}; PCT=${PCT:-10}; ABS=${ABS:-74}
CMDS=${CMDS:-65536}; CAL=${CAL:-$ROOT/cal}
mkdir -p "$CAL"
LOG="$CAL/report.txt"
say() { echo "$*" | tee -a "$LOG"; }
var() { local v="${1}_$2"; echo "${!v:-${!1:-}}"; }      # var NAME beats: NAME_<beats>, else NAME

for b in $SIZES; do
    case $b in 1|2|4|8|16|32|64) ;; *) echo "size $b: not one of 1 2 4 8 16 32 64 beats"; exit 1 ;; esac
done

prep() {   # prep <beats>: the size's own copy of rtl/ and vitis/
    local d="$CAL/b$1"
    if [ ! -d "$d/vitis" ]; then
        mkdir -p "$d"; cp -r "$ROOT/rtl" "$d/rtl"; cp -r "$VIT" "$d/vitis"; rm -rf "$d/vitis/_x" "$d/vitis/"*.xclbin
    fi
}

build_one() {   # build_one <beats>
    local b=$1 d="$CAL/b$1" n
    prep "$b"; n=$(var NMAX "$b")
    echo "$(date +%T) build b$b ($((b * 32)) B) started" >> "$CAL/progress.log"
    ( cd "$d/vitis" && TARGET=hw CFG="$CFG" BEATS=$b LAMBDA=7 SCHED=arrival TRACE=1 DEBUG=1 ${n:+NMAX=$n} bash build.sh ) \
        > "$d/build.log" 2>&1
    local rc=$?
    echo "$(date +%T) build b$b exit $rc ($([ -f "$d/vitis/doma_hw.xclbin" ] && echo "xclbin written" || echo "no xclbin"))" >> "$CAL/progress.log"
    return $rc
}
export -f build_one prep var; export CAL ROOT VIT CFG

timing_one() {   # the kernel clock v++ achieved -> cal/b<B>/mhz
    local b=$1 d="$CAL/b$1"
    [ -f "$d/vitis/doma_hw.xclbin" ] || { say "b$b: no bitstream ($d/vitis/doma_hw.xclbin)"; return 1; }
    ( cd "$d/vitis" && ./check_timing.sh ) > "$d/timing.txt" 2>&1
    local mhz; mhz=$(grep -oE "kernel clock in doma_hw.xclbin: [0-9.]+ MHz" "$d/timing.txt" | grep -oE "[0-9.]+ MHz" | grep -oE "[0-9.]+")
    [ -n "$mhz" ] || { say "b$b: kernel clock unknown (see $d/timing.txt); assuming 300 MHz"; mhz=300; }
    echo "$mhz" > "$d/mhz"
    say "b$b ($((b * 32)) B): kernel clock $mhz MHz; $(grep -E "^(PASS|FAIL|WARN)" "$d/timing.txt" | head -1)"
}

run_one() {   # 100% and 20% on package with per-access records
    local b=$1 d="$CAL/b$1" p n pool
    [ -f "$d/vitis/doma_hw.xclbin" ] || { say "b$b: no bitstream"; return 1; }
    [ -x "$VIT/host_phases" ] || g++ -std=c++17 -O2 "$VIT/host_phases.cpp" -I"${XILINX_XRT:?source XRT setup.sh first}/include" -L"$XILINX_XRT/lib" \
        -lxrt_coreutil -pthread -o "$VIT/host_phases" || { say "cannot build host_phases"; return 1; }
    n=$(var DOMA_N "$b"); pool=$(var DOMA_POOL "$b")
    for p in $PCTS; do
        say "$(date +%T) b$b: run at $p% on package, $ACC accesses"
        env DOMA_LAMBDA=7 DOMA_BLOCK=$((b * 32)) ${n:+DOMA_N=$n} ${pool:+DOMA_POOL=$pool} DOMA_HBM_PCT=$p DOMA_PHASE_TRACE=1 \
            DOMA_ONPKG_CSV="$d/onpkg$p.csv" DOMA_PHASES="mix:$ACC" "$VIT/host_phases" "$d/vitis/doma_hw.xclbin" "$CMDS" \
            > "$d/run$p.log" 2>&1
        say "  exit $?; $(grep -cE '^' "$d/onpkg$p.csv" 2>/dev/null || echo 0) records; $(grep -E 'DEBUG BITSTREAM|on-package calibration \(whole run' "$d/run$p.log" | head -2 | tr '\n' ' ')"
        grep -E "halt record|errors 0x|FAIL|cannot" "$d/run$p.log" | head -5 | sed 's/^/  /' | tee -a "$LOG"
    done
}

report_one() {   # card_budgets.py on the size's CSVs
    local b=$1 d="$CAL/b$1" f="" p mhz
    for p in $PCTS; do [ -s "$d/onpkg$p.csv" ] && f="$f $d/onpkg$p.csv"; done
    [ -n "$f" ] || { say "b$b: no records"; return 1; }
    mhz=$(cat "$d/mhz" 2>/dev/null || echo 300)
    python3 "$ROOT/sim/card_budgets.py" --beats "$b" --pct "$PCT" --abs "$ABS" --mhz "$mhz" --params "$ROOT/rtl/oram_params.vh" $f \
        > "$d/budgets.txt" 2>&1
    say ""; say "==================== b$b ($((b * 32)) B), kernel clock $mhz MHz ===================="
    tee -a "$LOG" < "$d/budgets.txt"
}

case "$PHASE" in
    build)
        say "$(date +%T) building debug bitstreams for: $SIZES ($JOBS at once; progress in $CAL/progress.log)"
        printf "%s\n" $SIZES | xargs -P "$JOBS" -I{} bash -c 'build_one {}'
        for b in $SIZES; do say "b$b: $([ -f "$CAL/b$b/vitis/doma_hw.xclbin" ] && echo "bitstream built" || echo "BUILD FAILED (see $CAL/b$b/build.log)")"; done ;;
    timing) for b in $SIZES; do timing_one "$b"; done ;;
    run)    for b in $SIZES; do run_one "$b"; done ;;
    report|write)
        : > "$CAL/summary.txt"
        for b in $SIZES; do report_one "$b" && grep -E "^SUMMARY " "$CAL/b$b/budgets.txt" >> "$CAL/summary.txt"; done
        say ""; say "==================== summary (lambda 7, margin $PCT% + $ABS) ===================="
        say "$(printf '%-7s %6s %10s %8s %8s | %8s %8s | %8s %8s %9s | %9s %10s' size MHz on-pkg 'max ws' 'max rg' 'card WB' 'card REL' AR_WB_H AR_REL_H AR_DONE_H 'vs v11g' 'halts/20M')"
        say "$(printf '%-7s %6s %10s %8s %8s | %8s %8s | %8s %8s %9s | %9s %10s' '' '' accesses cycles cycles '' '' final final final 'earlier' expected)"
        while read -r _ kv; do
            eval "$kv"
            say "$(printf '%-7s %6s %10s %8s %8s | %8s %8s | %8s %8s %9s | %9s %10s' "$((beats * 32)) B" "$mhz" "$n" "$wsmax" "$rgmax" "$wbc" "$relc" "$wb" "$rel" "$done" "$v11" "$halts")"
            [ "$v11" -lt 0 ] 2>/dev/null && say "  ** $((beats * 32)) B: the on-package release would be $(( -v11 )) cycles LATER than v11g's encrypted path: report this before building"
        done < "$CAL/summary.txt"
        say ""; say "defines for rtl/oram_params.vh:"
        for b in $SIZES; do grep -E "^\`define" "$CAL/b$b/budgets.txt" 2>/dev/null | tee -a "$LOG"; done
        if [ "$PHASE" = write ]; then
            for b in $SIZES; do
                f=""; for p in $PCTS; do [ -s "$CAL/b$b/onpkg$p.csv" ] && f="$f $CAL/b$b/onpkg$p.csv"; done
                [ -n "$f" ] && python3 "$ROOT/sim/card_budgets.py" --beats "$b" --pct "$PCT" --abs "$ABS" --mhz "$(cat "$CAL/b$b/mhz" 2>/dev/null || echo 300)" \
                    --params "$ROOT/rtl/oram_params.vh" --write $f | grep -E "^(chosen|written)" | tee -a "$LOG"
            done
            say "then: rerun the regression (sim/run_verilator.sh, every size at lambda 7) and build the production bitstreams"
        fi ;;
    all) S="$VIT/$(basename "$0")"; bash "$S" build $SIZES && bash "$S" timing $SIZES && bash "$S" run $SIZES && bash "$S" report $SIZES ;;
    *) sed -n '2,27p' "$0"; exit 1 ;;
esac
