`timescale 1ns/1ps
`include "oram_params.vh"
// stash_hbm.v -- DOMA's stash in HBM (on-package, trusted): per-bucket WINDOWS plus CHAINS through a BOUNDED POOL.
//
// The only capacity that can be exceeded is the pool itself (P entries, the stash bound): allocating when the
// pool is exhausted is the one fail-stop overflow. Windows are a cache, chains and the free list live inside the
// pool, and staging holds at most 1 + W + 1 blocks per access. (docs/stash_chain_design.md)
//
// HBM layout (relative to the stash buffer; bases set at boot from the run-time bucket count nb and pool size P):
//   heads  bucket b at b * 32 * HB B, HB beats of W + 1 packed entries {valid, pool index} of PW + 1 bits each
//          (HB = 1 while the entries fit one beat, 2 at the 2^22 build with Z = 10):
//          entries 0..W-1 the window, entry W the chain head. Windows are kept compact (valid entries first):
//          b's eviction candidates (W = Z + 1: every read moves in every waiting slot that fits).
//          b's further waiting blocks are on b's chain.
//   meta   pool entry p at meta_base + p * 16 B: word 0 slot, word 1 next {valid[31], index}, word 2 prev.
//          Chain entries are doubly linked; free entries are singly linked by next (the free list).
//   data   pool entry p at data_base + p * BLOCK_BYTES.
// On chip: the free-list head (and its next, prefetched), the never-used counter `fresh`, the count.
//
// Per access, a fixed set of reads:
//   level 1 (at open): head(b), head(bt) unless bt == b, the requested block's meta + data if it is stashed,
//                      the free-list head's meta (its next) unless already known
//   level 2 (when head(b) lands): meta + data of b's window entries, the meta of b's chain head
// After `ready`: remap moves the stashed requested block from b to bt (its pool index stays; nothing moves when
// bt == b); insert allocates a pool entry for a block that came from the bucket; evictions take b's window
// entries in order and free them. At commit, exactly one entry moves from b's chain into b's window if there is
// room (the chain step). Then heads, changed meta fields (byte-strobed writes: no read-modify-write) and dirty
// staged blocks are written back.
//
// Interface as before (handles = staging slots; a registered eviction candidate with a busy cycle after any
// change; `ready` two cycles after the last landing; reads only while every earlier write is acknowledged), plus:
//   pool_n                    the run-time pool size P, latched at boot (0: N, one entry per slot)
//   open_instash / open_pidx  the requested block is stashed, at this pool index (from the position map)
//   ins_pidx                  the pool index an insert allocates (the controller stores it in the position map)
module stash_hbm #(
    parameter N          = `ORAM_N,
    parameter B          = `ORAM_B,
    parameter Z          = `ORAM_Z,
    parameter BEATS      = `BEATS_PER_BLOCK,
    parameter K          = `ORAM_STASH_SLOTS,                 // (unused: no fixed per-bucket lists)
    parameter P          = `ORAM_STASH_DEPTH,                 // (unused: the pool size is run-time)
    parameter BUCKET_W   = `BUCKET_ID_W,
    parameter SLOT_AW    = `SLOT_ADDR_W,
    parameter PTR_W      = `STASH_PTR_W,
    parameter BEAT_W     = `BEAT_CNT_W,
    parameter AXI_DW     = 256
) (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 init_go,
    input  wire [BUCKET_W:0]    nb,
    input  wire [$clog2(N):0]   pool_n,
    output reg                  init_done,
    input  wire                 open_en,
    input  wire [BUCKET_W-1:0]  open_b,
    input  wire [BUCKET_W-1:0]  open_bt,
    input  wire [SLOT_AW-1:0]   open_slot,
    input  wire                 open_instash,
    input  wire [$clog2(N)-1:0] open_pidx,
    output wire                 ready,
    input  wire                 commit,
    input  wire [SLOT_AW-1:0]   cam_slot_addr,
    input  wire                 cam_slot_en,
    output wire                 cam_slot_hit,
    output wire [PTR_W-1:0]     cam_slot_idx,
    input  wire [BUCKET_W-1:0]  cam_bkt_target,
    input  wire                 cam_bkt_en,
    output wire                 cam_bkt_hit,
    output wire [PTR_W-1:0]     cam_bkt_idx,
    output wire [SLOT_AW-1:0]   cam_bkt_slot_addr,
    output wire                 cam_bkt_inhibit_busy,
    input  wire [SLOT_AW-1:0]   ins_slot_addr,
    input  wire [BUCKET_W-1:0]  ins_target_bucket,
    input  wire                 ins_en,
    output wire [PTR_W-1:0]     ins_idx,
    output wire [$clog2(N)-1:0] ins_pidx,
    output wire                 ins_full,
    input  wire [PTR_W-1:0]     remap_idx,
    input  wire [BUCKET_W-1:0]  remap_new_bucket,
    input  wire                 remap_en,
    input  wire [PTR_W-1:0]     evict_idx,
    input  wire                 evict_en,
    input  wire [PTR_W-1:0]     dwr_entry,
    input  wire [BEAT_W-1:0]    dwr_beat,
    input  wire [AXI_DW-1:0]    dwr_data,
    input  wire                 dwr_en,
    input  wire [PTR_W-1:0]     drd_entry,
    input  wire [BEAT_W-1:0]    drd_beat,
    input  wire                 drd_en,
    output reg  [AXI_DW-1:0]    drd_data,
    output reg                  drd_valid,
    output wire [PTR_W:0]       occupancy,
    output wire                 wr_quiet,
    output reg                  err,
`ifdef ORAM_ONPKG_DEBUG
    output wire [7:0]           dbg_open,   // v14c debug build: {head(b) landed, b has a chain, bt == b, requested block
                                            // stashed, b's window entries (0..W)} of the open access
`endif
    output reg  [63:0]          m_araddr,
    output reg  [7:0]           m_arlen,
    output wire [2:0]           m_arsize,
    output wire [1:0]           m_arburst,
    output reg                  m_arvalid,
    input  wire                 m_arready,
    input  wire [AXI_DW-1:0]    m_rdata,
    input  wire                 m_rlast,
    input  wire                 m_rvalid,
    output wire                 m_rready,
    output reg  [63:0]          m_awaddr,
    output reg  [7:0]           m_awlen,
    output wire [2:0]           m_awsize,
    output wire [1:0]           m_awburst,
    output reg                  m_awvalid,
    input  wire                 m_awready,
    output reg  [AXI_DW-1:0]    m_wdata,
    output reg  [AXI_DW/8-1:0]  m_wstrb,
    output wire                 m_wlast,
    output reg                  m_wvalid,
    input  wire                 m_wready,
    input  wire                 m_bvalid,
    output wire                 m_bready
);
    localparam SLOT_W      = SLOT_AW - 12;
    localparam PW          = $clog2(N);                       // pool index width (the pool never exceeds N)
    localparam W           = Z + 1;                           // candidates per bucket head: Z + 1, so every read
                                                              // moves in every waiting slot that fits (README)
    localparam WI          = $clog2(W);                       // candidate index width
    localparam WC          = $clog2(W + 1);                   // candidate count width
    localparam EW          = PW + 1;                          // packed head entry: {valid, pool index}
`ifdef STASH_HEAD_BEATS
    localparam HB          = STASH_HB_MAX((W + 1) * EW, `STASH_HEAD_BEATS);   // test: force more beats per head
`else
    localparam HB          = ((W + 1) * EW + AXI_DW - 1) / AXI_DW;     // beats per head
`endif
    localparam BLOCK_BYTES = BEATS * 32;
    localparam BAI         = (BEATS > 1) ? $clog2(BEATS) : 1;
    localparam STG         = 16;                              // staging: 0 requested, 1..W window, W+1.. inserted
    localparam SW          = 4;
    localparam [BAI-1:0] BMASK = BEATS - 1;
    localparam MQ          = 16;                              // meta writes per access (at most Z + 5 used)
    // configuration check at elaboration: a head of at most 4 beats, and at least Z + 1 candidates
    generate if (HB > 4 || W < Z + 1) begin : bad_stash_config
        STASH_CONFIG_ERROR_head_too_wide_or_fewer_than_Z_plus_1_candidates u_config_error ();
    end endgenerate
    function integer STASH_HB_MAX; input integer bits; input integer force_hb;
        begin STASH_HB_MAX = ((bits + 255) / 256 > force_hb) ? (bits + 255) / 256 : force_hb; end endfunction
    function [SW+BAI-1:0] gaddr; input [SW-1:0] g; input [BEAT_W-1:0] bt;
        begin gaddr = {g, bt[BAI-1:0] & BMASK}; end endfunction

    // ---------------- run-time layout ----------------
    reg  [BUCKET_W:0]   nb_q;
    reg  [PW:0]         pn_q;                                  // pool size P
    reg  [63:0]         meta_base, data_base;
    function [63:0] meta_addr; input [PW-1:0] p; begin meta_addr = meta_base + ({{(64-PW){1'b0}}, p} >> 1) * 32; end endfunction
    function [63:0] data_addr; input [PW-1:0] p; begin data_addr = data_base + {{(64-PW){1'b0}}, p} * BLOCK_BYTES; end endfunction
    function [63:0] head_addr; input [BUCKET_W:0] b; begin head_addr = {{(63-BUCKET_W){1'b0}}, b} * (32 * HB); end endfunction

    // ---------------- pool allocation (the only overflow) ----------------
    reg  [PW:0]         fresh, used_n;
    reg                 fl_v;  reg [PW-1:0] fl_h;              // free-list head
    reg                 fn_v;  reg [PW-1:0] fn_i;              // its next
    reg                 fn_ok;                                 // fn_* is current for fl_h
    reg                 fresh_ok;                              // == (fresh < pn_q), kept in step (timing: no compare
    wire                alloc_fresh = fresh_ok;                //  in front of the allocation and its meta writes)
    wire                alloc_ok    = alloc_fresh || (fl_v && fn_ok);
    wire [PW-1:0]       alloc_i     = alloc_fresh ? fresh[PW-1:0] : fl_h;
    assign ins_pidx  = alloc_i;
    assign occupancy = (used_n >> PTR_W) != 0 ? {1'b1, {PTR_W{1'b0}}} : used_n[PTR_W:0];

    // ---------------- the open access ----------------
    reg  [BUCKET_W-1:0] ob, obt;
    reg                 same, opened, c_pend, pre_done, rq_st;
    reg  [PW-1:0]       rq_p;
    reg  [SLOT_W-1:0]   rq_s;
    reg  [PW-1:0]       wa_i [0:W-1];  reg [W-1:0] wa_v;  reg [SW-1:0] wa_g [0:W-1];   // b's window
    reg  [PW-1:0]       wt_i [0:W-1];  reg [W-1:0] wt_v;                              // bt's window
    reg                 ca_v, ct_v;    reg [PW-1:0] ca_i, ct_i;                       // chain heads
    reg                 ha_in;
    reg                 cs_v;  reg [PW-1:0] cs_i;              // b's chain head as read (the chain step)
    reg                 cs_nv; reg [PW-1:0] cs_ni; reg cs_in;  // its next
    reg                 rm_nv, rm_pv; reg [PW-1:0] rm_ni, rm_pi;   // the requested block's links
    reg                 rq_k_ok; reg [WI-1:0] rq_k;               // the requested block's position in b's window
    reg  [AXI_DW-1:0]   stg [0:(STG << BAI)-1];
    reg  [STG-1:0]      g_used, g_land, g_dirty;
    reg  [PW-1:0]       g_idx  [0:STG-1];
    reg  [SLOT_W-1:0]   g_slot [0:STG-1];
    wire [SW-1:0]       rh = remap_idx[SW-1:0], eh = evict_idx[SW-1:0], dh = drd_entry[SW-1:0], wh = dwr_entry[SW-1:0];
    reg  [1:0]          mq_k [0:MQ-1];                         // meta writes: 0 = {prev, next, slot}, 1 = next, 2 = prev
    reg  [PW-1:0]       mq_i [0:MQ-1];
    reg  [95:0]         mq_d [0:MQ-1];
    reg  [4:0]          mq_n, mq_r;

    // ---------------- outputs to the controller ----------------
    reg                 chg;                                   // b's window changed (candidate stale for a cycle)
    reg                 cb_hit_q; reg [SW-1:0] cb_h_q; reg [SLOT_W-1:0] cb_s_q;
    assign cam_slot_hit         = opened && rq_st;
    assign cam_slot_idx         = {PTR_W{1'b0}};             // the requested block's handle: staging slot 0
    assign cam_bkt_hit          = opened && cb_hit_q && (cam_bkt_target == ob);
    assign cam_bkt_idx          = {{(PTR_W-SW){1'b0}}, cb_h_q};
    assign cam_bkt_slot_addr    = {{(SLOT_AW-SLOT_W-12){1'b0}}, cb_s_q, 12'd0};
    assign cam_bkt_inhibit_busy = chg;
    // v14b (timing): the free staging slot is found from g_used one cycle ahead and registered, so the insert's logic
    // starts at a register (v14's card build failed 300 MHz on g_used -> td, 12 levels). g_used never changes in the
    // cycle before an insert (an insert follows ready, and two inserts are always cycles apart; checked below).
    reg fg_ok_c; reg [SW-1:0] fg_c; integer gi;
    always @(*) begin
        fg_ok_c = 0; fg_c = 0;
        for (gi = STG - 1; gi > W; gi = gi - 1) if (!g_used[gi]) begin fg_ok_c = 1; fg_c = gi[SW-1:0]; end
    end
    reg fg_ok; reg [SW-1:0] fg;
    always @(posedge clk) begin fg_ok <= fg_ok_c; fg <= fg_c; end
    assign ins_full = !alloc_ok || !fg_ok;                     // the POOL is exhausted (staging cannot fill)
    assign ins_idx  = {{(PTR_W-SW){1'b0}}, fg};

    // ---------------- AXI ----------------
    localparam [3:0] J_INIT = 4'd0, J_IDLE = 4'd1, J_RD = 4'd2, J_WHA = 4'd3, J_WHT = 4'd4, J_WMQ = 4'd5, J_WSTG = 4'd6;
    localparam [2:0] T_HA = 3'd0, T_HT = 3'd1, T_MR = 3'd2, T_MF = 3'd3, T_MW = 3'd4, T_MC = 3'd5, T_D = 3'd6;
    reg  [3:0]          job;
    reg  [BUCKET_W+2:0] init_b;                             // head beats zeroed so far
    wire [BUCKET_W+2:0] init_tot = nb_q * HB;               // head beats in all
    wire [BUCKET_W+2:0] init_rem = init_tot - init_b;       // still to zero (< 16 in the last burst)
    reg                 init_req;
    reg  [7:0]          rbeat, wbeat, wlen;
    reg  [4:0]          outst;
    reg                 aw_sent, w_on;
    reg  [SW-1:0]       wg; reg wg_go;
    reg  [2:0]          tq_k [0:31];
    reg  [SW-1:0]       tq_g [0:31];
    reg  [4:0]          tq_rp, tq_wp;
    reg  [5:0]          tq_n;
    reg                 i_ha, i_ht, i_mr, i_dr, i_mf, i_l2;
    reg  [WC-1:0]          i_w; reg [1:0] i_ph;              // window entry, and its phase: 0 prep, 1 meta, 2 data
    // timing: every read address is precomputed in a register, so the issue logic only selects one
    reg  [63:0]            a_ha, a_ht, a_mr, a_dr, a_mf, a_mc, cw_ma, cw_da;
    reg  [PW-1:0]          cw_i; reg cw_v, cw_rq, ha_in_d;
    reg  [2:0]             hk_r; reg [SW-1:0] hg_r;      // the tag queue's head (== tq_k / tq_g [tq_rp])
    reg  [1:0]          rdy_q;
    wire [2:0]          hk = hk_r;
    wire [SW-1:0]       hg = hg_r;
    always @(posedge clk) begin
        a_ha <= head_addr({1'b0, ob}); a_ht <= head_addr({1'b0, obt});      // ob, obt, rq_p: set at open
        a_mr <= meta_addr(rq_p);       a_dr <= data_addr(rq_p);
        a_mf <= meta_addr(fl_h);       a_mc <= meta_addr(ca_i);             // ca_i: when the head lands
        cw_v  <= (i_w < W) && wa_v[i_w[WI-1:0]];                             // the current window entry
        cw_rq <= (i_w < W) && wa_v[i_w[WI-1:0]] && rq_st && (wa_i[i_w[WI-1:0]] == rq_p);
        cw_i  <= wa_i[i_w[WI-1:0]];
        cw_ma <= meta_addr(wa_i[i_w[WI-1:0]]); cw_da <= data_addr(wa_i[i_w[WI-1:0]]);
    end
    assign m_arsize = 3'b101; assign m_arburst = 2'b01; assign m_rready = 1'b1;
    assign m_awsize = 3'b101; assign m_awburst = 2'b01; assign m_bready = 1'b1;
    assign m_wlast  = (wbeat == wlen);
    assign wr_quiet = init_done && (outst == 0) && !c_pend && (job == J_IDLE || job == J_RD) && !w_on && !m_awvalid;
`ifdef ORAM_ONPKG_DEBUG
    reg [3:0] dbg_wn; integer dbg_e;
    always @(*) begin dbg_wn = 4'd0; for (dbg_e = 0; dbg_e < W; dbg_e = dbg_e + 1) dbg_wn = dbg_wn + {3'd0, wa_v[dbg_e]}; end
    assign dbg_open = {ha_in, ca_v, same, rq_st, dbg_wn};
`endif
    wire   rdy_now  = opened && pre_done && !c_pend;
    assign ready    = rdy_now && rdy_q[1];

    wire              d_beat = (job == J_RD) && m_rvalid && (hk == T_D);
    wire              s_we = d_beat || dwr_en;
    wire [SW+BAI-1:0] s_wa = d_beat ? gaddr(hg, rbeat) : gaddr(wh, dwr_beat);
    wire [AXI_DW-1:0] s_wd = d_beat ? m_rdata : dwr_data;
    wire              w_hs = m_wvalid && m_wready;
    wire [7:0]        wb_next = w_hs ? wbeat + 1'b1 : wbeat;
    reg  [AXI_DW-1:0] stg_wb;
    reg  [HB*AXI_DW-1:0] wword;                             // a head (HB beats) or one meta beat
    reg  [HB*AXI_DW-1:0] hacc;                              // a head's earlier beats, while it lands
    reg               w_from_stg;
    always @(posedge clk) begin
        if (s_we) stg[s_wa] <= s_wd;
        drd_data <= stg[gaddr(dh, drd_beat)];
        stg_wb   <= stg[gaddr(wg, wb_next)];
    end
    // a head's beat k (k < HB); beats past the head (a zeroing burst) are zero: constant selects only
    reg [AXI_DW-1:0] wsel; integer ws;
    always @(*) begin
        wsel = {AXI_DW{1'b0}};
        for (ws = 0; ws < HB; ws = ws + 1) if (wbeat == ws) wsel = wword[ws*AXI_DW +: AXI_DW];
        m_wdata = w_from_stg ? stg_wb : wsel;
    end

    reg [W*PW-1:0] wa_flat, wt_flat; integer fj;
    always @(*) for (fj = 0; fj < W; fj = fj + 1) begin wa_flat[fj*PW +: PW] = wa_i[fj]; wt_flat[fj*PW +: PW] = wt_i[fj]; end
    function [HB*AXI_DW-1:0] head_word; input [W*PW-1:0] wi; input [W-1:0] wv; input cv; input [PW-1:0] ci;
        integer q; begin
            head_word = {(HB*AXI_DW){1'b0}};
            for (q = 0; q < W; q = q + 1) begin head_word[EW*q + PW] = wv[q]; head_word[EW*q +: PW] = wi[q*PW +: PW]; end
            head_word[EW*W + PW] = cv; head_word[EW*W +: PW] = ci;
        end endfunction
    function [WC-1:0] wcount; input [W-1:0] v; integer q; begin wcount = 0; for (q = 0; q < W; q = q + 1) if (v[q]) wcount = wcount + 1'b1; end endfunction
    function [31:0] lnk; input v; input [PW-1:0] i; begin lnk = 32'd0; lnk[31] = v; lnk[PW-1:0] = i; end endfunction

    always @(posedge clk) begin                                // the registered eviction candidate: b's first entry
        cb_hit_q <= wa_v[0] && g_used[wa_g[0]] && g_land[wa_g[0]];
        cb_h_q   <= wa_g[0];
        cb_s_q   <= g_slot[wa_g[0]];
    end

    task wstart; input [63:0] a; input [7:0] len; begin
        m_awaddr <= a; m_awlen <= len; wlen <= len; wbeat <= 0; m_awvalid <= 1'b1; aw_sent <= 1'b0; w_on <= 1'b1; m_wvalid <= 1'b1;
    end endtask

    // this cycle's meta writes (at most 4: unlink 2 + link 2), queued in order at the end of the cycle
    reg [1:0] tk [0:3]; reg [PW-1:0] ti [0:3]; reg [95:0] td [0:3]; integer tn, tj;
    reg [1:0] sk [0:3]; reg [PW-1:0] si [0:3]; reg [95:0] sd [0:3]; reg [2:0] sn;   // staged meta writes (timing)
    reg [W-1:0] vsel, oh;
    function [W-1:0] ffree; input [W-1:0] v; begin ffree = ~v & {v[W-2:0], 1'b1}; end endfunction   // first free slot
    task tpush; input [1:0] k; input [PW-1:0] i; input [95:0] d; begin tk[tn] = k; ti[tn] = i; td[tn] = d; tn = tn + 1; end endtask
    integer e, q2;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            init_done <= 1'b0; init_b <= 0; init_req <= 1'b0; job <= J_INIT; rbeat <= 0; wbeat <= 0; wlen <= 0; outst <= 0;
            aw_sent <= 1'b0; w_on <= 1'b0; m_arvalid <= 1'b0; m_awvalid <= 1'b0; m_wvalid <= 1'b0; m_wstrb <= {(AXI_DW/8){1'b1}};
            m_araddr <= 0; m_arlen <= 0; m_awaddr <= 0; m_awlen <= 0; wword <= 0; w_from_stg <= 1'b0;
            ob <= 0; obt <= 0; same <= 1'b0; opened <= 1'b0; c_pend <= 1'b0; pre_done <= 1'b0; rq_st <= 1'b0; rq_p <= 0; rq_s <= 0;
            wa_v <= 0; wt_v <= 0; ca_v <= 1'b0; ct_v <= 1'b0; ca_i <= 0; ct_i <= 0; ha_in <= 1'b0;
            cs_v <= 1'b0; cs_i <= 0; cs_nv <= 1'b0; cs_ni <= 0; cs_in <= 1'b0; rm_nv <= 1'b0; rm_pv <= 1'b0; rm_ni <= 0; rm_pi <= 0;
            rq_k_ok <= 1'b0; rq_k <= 0; g_used <= 0; g_land <= 0; g_dirty <= 0; mq_n <= 0; mq_r <= 0; chg <= 1'b0; sn <= 3'd0;
            wg <= 0; wg_go <= 1'b0; tq_rp <= 0; tq_wp <= 0; tq_n <= 0;
            i_ha <= 1'b0; i_ht <= 1'b0; i_mr <= 1'b0; i_dr <= 1'b0; i_mf <= 1'b0; i_l2 <= 1'b0; i_w <= 0; i_ph <= 2'd0; ha_in_d <= 1'b0; hk_r <= 0; hg_r <= 0;
            rdy_q <= 0; fresh <= 0; fresh_ok <= 1'b0; used_n <= 0; fl_v <= 1'b0; fl_h <= 0; fn_v <= 1'b0; fn_i <= 0; fn_ok <= 1'b0;
            drd_valid <= 1'b0; err <= 1'b0; nb_q <= 0; pn_q <= 0; meta_base <= 0; data_base <= 0;
        end else begin
            chg   <= 1'b0;
            rdy_q <= {rdy_q[0], rdy_now};
            outst <= outst + ((m_awvalid && m_awready) ? 5'd1 : 5'd0) - (m_bvalid ? 5'd1 : 5'd0);
            tn = 0;
            drd_valid <= drd_en && g_used[dh] && g_land[dh];
            if (drd_en && !(g_used[dh] && g_land[dh])) err <= 1'b1;
            if (dwr_en) begin if (g_used[wh]) g_dirty[wh] <= 1'b1; else err <= 1'b1; end
            if ((ins_en && remap_en) || (ins_en && evict_en) || (remap_en && evict_en)) err <= 1'b1;   // one per cycle

            // ---- insert: the requested block came from the bucket and now waits for bt ----
            if (ins_en) begin
                if (!opened || !alloc_ok || !fg_ok) err <= 1'b1;   // !alloc_ok: THE POOL IS EXHAUSTED (the only overflow)
                else begin : ins
                    reg [WC-1:0] cnt; reg [31:0] sl;
                    sl = {{(32-SLOT_W){1'b0}}, ins_slot_addr[SLOT_W+11:12]};
                    used_n <= used_n + 1'b1;
                    if (alloc_fresh) begin fresh <= fresh + 1'b1; fresh_ok <= (fresh + 1'b1 < pn_q); end
                    else begin fl_v <= fn_v; fl_h <= fn_i; fn_ok <= 1'b0; end      // popped the free list
                    g_used[fg] <= 1'b1; g_land[fg] <= 1'b1; g_dirty[fg] <= 1'b1; g_idx[fg] <= alloc_i; g_slot[fg] <= sl[SLOT_W-1:0];
                    vsel = same ? wa_v : wt_v; oh = ffree(vsel);   // windows are prefixes: full = top bit
                    if (!vsel[W-1]) begin                           // into bt's window
                        if (same) begin for (e = 0; e < W; e = e + 1) if (oh[e]) begin wa_i[e] <= alloc_i; wa_g[e] <= fg; wa_v[e] <= 1'b1; end chg <= 1'b1; end
                        else      begin for (e = 0; e < W; e = e + 1) if (oh[e]) begin wt_i[e] <= alloc_i; wt_v[e] <= 1'b1; end end
                        tpush(2'd0, alloc_i, {lnk(1'b0, {PW{1'b0}}), lnk(1'b0, {PW{1'b0}}), sl});
                    end else if (same) begin                        // onto the head of b's chain
                        tpush(2'd0, alloc_i, {lnk(1'b0, {PW{1'b0}}), lnk(ca_v, ca_i), sl});
                        if (ca_v) tpush(2'd2, ca_i, {64'd0, lnk(1'b1, alloc_i)});
                        ca_v <= 1'b1; ca_i <= alloc_i;
                    end else begin                                  // onto the head of bt's chain
                        tpush(2'd0, alloc_i, {lnk(1'b0, {PW{1'b0}}), lnk(ct_v, ct_i), sl});
                        if (ct_v) tpush(2'd2, ct_i, {64'd0, lnk(1'b1, alloc_i)});
                        ct_v <= 1'b1; ct_i <= alloc_i;
                    end
                end
            end
            // ---- remap: the stashed requested block moves from b to bt (its pool index stays) ----
            if (remap_en) begin
                if (!opened || !rq_st || rh != 0) err <= 1'b1;
                else begin : rmp
                    reg [WC-1:0] cnt;
                    rq_st <= 1'b0;
                    if (!same) begin                                // (bt == b: it already waits for b, nothing moves)
                        if (rq_k_ok) begin                          // out of b's window
                            for (q2 = 0; q2 < W - 1; q2 = q2 + 1) if (q2 >= rq_k) begin wa_i[q2] <= wa_i[q2+1]; wa_g[q2] <= wa_g[q2+1]; end
                            wa_v <= wa_v >> 1; chg <= 1'b1;
                        end else begin                              // off b's chain
                            if (rm_pv) tpush(2'd1, rm_pi, {64'd0, lnk(rm_nv, rm_ni)});      // prev.next = next
                            else begin ca_v <= rm_nv; ca_i <= rm_ni; end
                            if (rm_nv) tpush(2'd2, rm_ni, {64'd0, lnk(rm_pv, rm_pi)});      // next.prev = prev
                            // The chain step at commit moves b's chain head into b's window and makes the head's next,
                            // as read at open (cs_n*), the new head. If the block leaving b's chain IS that next, the new
                            // head is the block after it: otherwise the step re-heads the chain on a block no longer in
                            // it and leaves the real successor's prev pointing at the moved head, a dangling link that
                            // corrupts the free list once that entry is freed. (cs_n* has landed: ready needs pre_done.)
                            if (rm_pv && cs_v && rm_pi == cs_i) begin cs_nv <= rm_nv; cs_ni <= rm_ni; end
                        end
                        oh = ffree(wt_v);
                        if (!wt_v[W-1]) begin for (e = 0; e < W; e = e + 1) if (oh[e]) begin wt_i[e] <= rq_p; wt_v[e] <= 1'b1; end end   // into bt's window
                        else begin                                  // onto bt's chain
                            tpush(2'd0, rq_p, {lnk(1'b0, {PW{1'b0}}), lnk(ct_v, ct_i), {{(32-SLOT_W){1'b0}}, rq_s}});
                            if (ct_v) tpush(2'd2, ct_i, {64'd0, lnk(1'b1, rq_p)});
                            ct_v <= 1'b1; ct_i <= rq_p;
                        end
                    end
                end
            end
            // ---- evict: b's first window entry leaves the stash; its pool entry is freed ----
            if (evict_en) begin
                if (!opened || !wa_v[0] || wa_g[0] != eh) err <= 1'b1;
                else begin
                    for (q2 = 0; q2 < W - 1; q2 = q2 + 1) begin wa_i[q2] <= wa_i[q2+1]; wa_g[q2] <= wa_g[q2+1]; end
                    wa_v <= wa_v >> 1; chg <= 1'b1; used_n <= used_n - 1'b1;
                    tpush(2'd1, wa_i[0], {64'd0, lnk(fl_v, fl_h)});                     // freed.next = free head
                    fl_v <= 1'b1; fl_h <= wa_i[0]; fn_v <= fl_v; fn_i <= fl_h; fn_ok <= 1'b1;
                end
            end
            // ---- commit: the chain step, then write everything back ----
            if (commit && opened) begin : cmt
                reg [WC-1:0] cnt;
                oh = ffree(wa_v);
                if (cs_v && cs_in && ca_v && ca_i == cs_i && !wa_v[W-1]) begin
                    for (e = 0; e < W; e = e + 1) if (oh[e]) begin wa_i[e] <= cs_i; wa_v[e] <= 1'b1; end  // one entry from b's chain into b's window
                    ca_v <= cs_nv; ca_i <= cs_ni;
                    if (cs_nv) tpush(2'd2, cs_ni, {64'd0, lnk(1'b0, {PW{1'b0}})});        // the new head has no prev
                end
                c_pend <= 1'b1;
            end
            // meta writes: last cycle's (staged in registers) join the queue now, in order; this cycle's are
            // staged. Timing: no path from the window logic into the queue's 16 x 96-bit write crossbar.
            if (sn != 0) begin
                if (mq_n + sn > MQ) err <= 1'b1;
                else begin
                    for (tj = 0; tj < 4; tj = tj + 1) if (tj < sn) begin
                        mq_k[mq_n + tj] <= sk[tj]; mq_i[mq_n + tj] <= si[tj]; mq_d[mq_n + tj] <= sd[tj];
                    end
                    mq_n <= mq_n + {2'd0, sn};
                end
            end
            sn <= tn[2:0];
            for (tj = 0; tj < 4; tj = tj + 1) begin sk[tj] <= tk[tj]; si[tj] <= ti[tj]; sd[tj] <= td[tj]; end

            // ---- open an access ----
            if (open_en) begin
                if (!init_done || c_pend || job != J_IDLE) err <= 1'b1;
                ob <= open_b; obt <= open_bt; same <= (open_b == open_bt);
                rq_st <= open_instash; rq_p <= open_pidx; rq_s <= open_slot[SLOT_W+11:12];
                opened <= 1'b1; pre_done <= 1'b0; ha_in <= 1'b0; cs_in <= 1'b0;
                wa_v <= 0; wt_v <= 0; ca_v <= 1'b0; ct_v <= 1'b0; cs_v <= 1'b0; rq_k_ok <= 1'b0;
                g_used <= 0; g_land <= 0; g_dirty <= 0; mq_n <= 0; mq_r <= 0; chg <= 1'b1;
                i_ha <= 1'b0; i_ht <= (open_b == open_bt); i_mr <= !open_instash; i_dr <= !open_instash; i_mf <= !fl_v || fn_ok;
                i_l2 <= 1'b0; i_w <= 0; i_ph <= 2'd0; ha_in_d <= 1'b0; hk_r <= 0; hg_r <= 0;
                if (open_instash) begin g_used[0] <= 1'b1; g_idx[0] <= open_pidx; g_slot[0] <= open_slot[SLOT_W+11:12]; end
            end
            if (init_go) begin                                  // boot: sizes, bases, an empty pool; then zero the heads
                init_req  <= 1'b1; init_b <= 0; init_done <= 1'b0; job <= J_INIT;
                nb_q      <= (nb == 0) ? B : nb;
                pn_q      <= (pool_n == 0) ? N : pool_n;
                meta_base <= ((((nb == 0) ? B : nb) * 32 * HB + 4095) / 4096) * 4096;
                data_base <= ((((nb == 0) ? B : nb) * 32 * HB + 4095) / 4096) * 4096
                           + ((((pool_n == 0) ? N : pool_n) * 16 + 4095) / 4096) * 4096;
                fresh <= 0; used_n <= 0; fl_v <= 1'b0; fn_ok <= 1'b0;
                fresh_ok <= (((pool_n == 0) ? N : pool_n) != 0);   // 0 < the pool size just set
            end

            // ---- the AXI job engine ----
            if (m_awvalid && m_awready) begin m_awvalid <= 1'b0; aw_sent <= 1'b1; end
            if (w_hs) begin
                if (wbeat == wlen) begin m_wvalid <= 1'b0; w_on <= 1'b0; wbeat <= 0; end
                else wbeat <= wbeat + 1'b1;
            end
            case (job)
                J_INIT: if (init_req && !w_on && !m_awvalid && !init_go) begin   // zero every head beat, 16 per burst
                    if (init_b >= init_tot) begin if (outst == 0) begin init_done <= 1'b1; init_req <= 1'b0; job <= J_IDLE; end end
                    else begin
                        w_from_stg <= 1'b0; wword <= {(HB*AXI_DW){1'b0}}; m_wstrb <= {(AXI_DW/8){1'b1}};
                        wstart({{(61-BUCKET_W){1'b0}}, init_b} * 32, (init_rem >= 16) ? 8'd15 : {4'd0, init_rem[3:0] - 4'd1});
                        init_b <= (init_rem >= 16) ? init_b + 5'd16 : init_tot;
                    end
                end
                J_IDLE: begin
                    if (c_pend && !w_on && !m_awvalid) begin
                        w_from_stg <= 1'b0; m_wstrb <= {(AXI_DW/8){1'b1}};
                        wword <= head_word(wa_flat, wa_v, ca_v, ca_i);
                        wstart(head_addr({1'b0, ob}), HB - 1); job <= J_WHA;
                    end else if (opened && !pre_done && !open_en && outst == 0 && !m_arvalid) begin
                        job <= J_RD; rbeat <= 0;                // every earlier write is acknowledged
                    end
                end
                J_RD: begin
                    if (m_arvalid && m_arready) m_arvalid <= 1'b0;
                    ha_in_d <= ha_in;                                    // the chain head's address: a cycle after landing
                    begin : issue
                        reg go; reg [2:0] k; reg [SW-1:0] g; go = 0; k = T_HA; g = 0;
                        if (!m_arvalid || m_arready) begin
                            if (!i_ha) begin go = 1; k = T_HA; i_ha <= 1'b1; m_araddr <= a_ha; m_arlen <= HB - 1; end
                            else if (!i_ht) begin go = 1; k = T_HT; i_ht <= 1'b1; m_araddr <= a_ht; m_arlen <= HB - 1; end
                            else if (!i_mr) begin go = 1; k = T_MR; i_mr <= 1'b1; m_araddr <= a_mr; m_arlen <= 8'd0; end
                            else if (!i_dr) begin go = 1; k = T_D; g = 0; i_dr <= 1'b1; m_araddr <= a_dr; m_arlen <= BEATS - 1; end
                            else if (!i_mf) begin go = 1; k = T_MF; i_mf <= 1'b1; m_araddr <= a_mf; m_arlen <= 8'd0; end
                            else if (ha_in_d && !i_l2) begin                     // level 2: b's window, then b's chain head
                                if (i_ph == 2'd0) i_ph <= 2'd1;                  // prep: the entry's registers load
                                else if (cw_rq) begin
                                    wa_g[i_w[WI-1:0]] <= 4'd0; rq_k_ok <= 1'b1; rq_k <= i_w[WI-1:0];   // the requested block: slot 0
                                    i_w <= i_w + 1'b1; i_ph <= 2'd0;
                                end else if (cw_v) begin
                                    if (i_ph == 2'd1) begin go = 1; k = T_MW; g = i_w; m_araddr <= cw_ma; m_arlen <= 8'd0; i_ph <= 2'd2; end
                                    else begin
                                        go = 1; k = T_D; g = i_w + 1'b1; m_araddr <= cw_da; m_arlen <= BEATS - 1;
                                        g_used[i_w + 1'b1] <= 1'b1; g_idx[i_w + 1'b1] <= cw_i;
                                        wa_g[i_w[WI-1:0]] <= i_w + 1'b1; i_ph <= 2'd0; i_w <= i_w + 1'b1;
                                    end
                                end else begin
                                    i_l2 <= 1'b1; i_w <= W;
                                    if (ca_v) begin go = 1; k = T_MC; m_araddr <= a_mc; m_arlen <= 8'd0; cs_v <= 1'b1; cs_i <= ca_i; end
                                end
                            end
                        end
                        if (go) begin m_arvalid <= 1'b1; tq_k[tq_wp] <= k; tq_g[tq_wp] <= g; tq_wp <= tq_wp + 1'b1; end
                        tq_n <= tq_n + (go ? 6'd1 : 6'd0) - ((m_rvalid && m_rlast) ? 6'd1 : 6'd0);
                        begin : head                                     // keep the queue's head in registers
                            reg [4:0] nrp; reg [5:0] nn;
                            nrp = tq_rp + ((m_rvalid && m_rlast) ? 5'd1 : 5'd0);
                            nn  = tq_n + (go ? 6'd1 : 6'd0) - ((m_rvalid && m_rlast) ? 6'd1 : 6'd0);
                            if (nn != 0) begin
                                if (go && tq_wp == nrp) begin hk_r <= k; hg_r <= g; end
                                else begin hk_r <= tq_k[nrp]; hg_r <= tq_g[nrp]; end
                            end
                        end
                        if (!go && i_l2 && tq_n == 0 && !m_arvalid && !m_rvalid) begin
                            pre_done <= 1'b1; job <= J_IDLE; chg <= 1'b1;
                        end
                    end
                    if (m_rvalid) begin : land
                        reg [127:0] mh; reg [HB*AXI_DW-1:0] hw; reg hlast;
                        mh = 128'd0;
                        hw = hacc;                                   // a head: this beat over the earlier ones
                        for (e = 0; e < HB; e = e + 1) if (rbeat == e) hw[e*AXI_DW +: AXI_DW] = m_rdata;
                        hlast = (rbeat == HB - 1);
                        if ((hk == T_HA || hk == T_HT) && !hlast) hacc <= hw;
                        case (hk)
                            T_HA: if (hlast) begin
                                for (e = 0; e < W; e = e + 1) begin wa_v[e] <= hw[EW*e + PW]; wa_i[e] <= hw[EW*e +: PW]; end
                                ca_v <= hw[EW*W + PW]; ca_i <= hw[EW*W +: PW]; ha_in <= 1'b1; chg <= 1'b1;
                            end
                            T_HT: if (hlast) begin
                                for (e = 0; e < W; e = e + 1) begin wt_v[e] <= hw[EW*e + PW]; wt_i[e] <= hw[EW*e +: PW]; end
                                ct_v <= hw[EW*W + PW]; ct_i <= hw[EW*W +: PW];
                            end
                            T_MR: begin mh = rq_p[0] ? m_rdata[255:128] : m_rdata[127:0];
                                rm_nv <= mh[63]; rm_ni <= mh[32 +: PW]; rm_pv <= mh[95]; rm_pi <= mh[64 +: PW]; end
                            T_MF: begin mh = fl_h[0] ? m_rdata[255:128] : m_rdata[127:0];
                                fn_v <= mh[63]; fn_i <= mh[32 +: PW]; fn_ok <= 1'b1; end
                            T_MW: begin mh = wa_i[hg[WI-1:0]][0] ? m_rdata[255:128] : m_rdata[127:0];
                                g_slot[hg + 1'b1] <= mh[SLOT_W-1:0]; end
                            T_MC: begin mh = cs_i[0] ? m_rdata[255:128] : m_rdata[127:0];
                                cs_nv <= mh[63]; cs_ni <= mh[32 +: PW]; cs_in <= 1'b1; end
                            default: ;
                        endcase
                        rbeat <= rbeat + 1'b1;
                        if (m_rlast) begin
                            rbeat <= 0; tq_rp <= tq_rp + 1'b1;
                            if (hk == T_D) begin g_land[hg] <= 1'b1; chg <= 1'b1; end
                        end
                    end
                end
                J_WHA: if (!w_on && !m_awvalid) begin
                    if (!same) begin wword <= head_word(wt_flat, wt_v, ct_v, ct_i); wstart(head_addr({1'b0, obt}), HB - 1); end
                    job <= J_WHT;
                end
                J_WHT: if (!w_on && !m_awvalid) job <= J_WMQ;
                J_WMQ: if (!w_on && !m_awvalid) begin            // meta writes, byte-strobed
                    if (mq_r == mq_n) begin if (sn == 3'd0) job <= J_WSTG; end   // the stage has joined the queue too
                    else begin : mw
                        reg [5:0] off;
                        off = mq_i[mq_r][0] ? 6'd16 : 6'd0;
                        wword <= {AXI_DW{1'b0}}; m_wstrb <= {(AXI_DW/8){1'b0}};
                        case (mq_k[mq_r])
                            2'd0:    begin wword[8*off +: 96]    <= mq_d[mq_r];       m_wstrb[off +: 12]  <= 12'hFFF; end
                            2'd1:    begin wword[8*off+32 +: 32] <= mq_d[mq_r][31:0]; m_wstrb[off+4 +: 4] <= 4'hF; end
                            default: begin wword[8*off+64 +: 32] <= mq_d[mq_r][31:0]; m_wstrb[off+8 +: 4] <= 4'hF; end
                        endcase
                        w_from_stg <= 1'b0; wstart(meta_addr(mq_i[mq_r]), 8'd0); mq_r <= mq_r + 1'b1;
                    end
                end
                J_WSTG: if (wg_go) begin
                    wg_go <= 1'b0; w_from_stg <= 1'b1; m_wstrb <= {(AXI_DW/8){1'b1}};
                    wstart(data_addr(g_idx[wg]), BEATS - 1);
                end else if (!w_on && !m_awvalid) begin : nd   // dirty staged blocks back to the pool
                    reg f; reg [SW-1:0] g; f = 0; g = 0;
                    for (gi = STG - 1; gi >= 0; gi = gi - 1) if (g_used[gi] && g_dirty[gi]) begin f = 1; g = gi[SW-1:0]; end
                    if (f) begin wg <= g; g_dirty[g] <= 1'b0; wg_go <= 1'b1; end
                    else begin c_pend <= 1'b0; opened <= 1'b0; job <= J_IDLE; w_from_stg <= 1'b0; end
                end
                default: job <= J_IDLE;
            endcase
        end
    end
`ifndef SYNTHESIS
    reg [STG-1:0] g_used_d;
    always @(posedge clk) begin
        g_used_d <= g_used;
        if (rst_n && ins_en && g_used !== g_used_d)
            $fatal(1, "stash_hbm: an insert in the cycle after g_used changed (the registered free slot is stale)");
    end
    always @(posedge clk) if (rst_n && (fresh_ok !== (fresh < pn_q)))
        $fatal(1, "stash_hbm: fresh_ok out of step (fresh %0d, pool %0d)", fresh, pn_q);
`endif
`ifndef SYNTHESIS
    always @(posedge clk) if (rst_n && tq_n != 0 && (hk_r !== tq_k[tq_rp] || hg_r !== tq_g[tq_rp]))
        $fatal(1, "stash_hbm: the registered queue head is out of step (rp %0d)", tq_rp);
`endif
`ifndef SYNTHESIS
    // the windows' valid flags are always prefixes (filled from 0, shifted down on removal): ffree relies on it
    always @(posedge clk) if (rst_n && ((((wa_v + 1'b1) & wa_v) != 0) || (((wt_v + 1'b1) & wt_v) != 0)))
        $fatal(1, "stash_hbm: a window's valid flags are not a prefix (wa_v %b, wt_v %b)", wa_v, wt_v);
`endif
endmodule
