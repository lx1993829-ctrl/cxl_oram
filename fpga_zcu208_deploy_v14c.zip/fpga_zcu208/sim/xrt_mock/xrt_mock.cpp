// xrt_mock.cpp -- mock XRT (see xrt/xrt_mock.h) on a Verilated doma_kernel, one 300 MHz cycle per step.
//
// Environment:
//   MOCK_CFG=doma_hw|doma   memory placement of doma_hw.cfg (default: pages in HBM[8]) or doma.cfg (pages in HOST[0])
//   MOCK_HOST_LAT=<cycles>  host-memory read latency for pages in HOST[0] (default 100, as tb_doma_kernel.v)
//   MOCK_VERBOSE=1          print every launch (arguments, cycles, simulation speed)
//   MOCK_STASH_LAT=<cycles> the stash port's read latency (default 53)
//   MOCK_MAX_CYCLES=<n>     abort a launch after n cycles (default 4e9)
//   MOCK_FLIP=<k>           fault injection: flip one bit of the k-th data beat the kernel writes to resp_output
//                           (counted from 1 over the whole run), to check that the host's read check catches it
#include "xrt/xrt_mock.h"
#include "Vdoma_kernel.h"
#include "verilated.h"
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <map>
#include <stdexcept>
#include <string>

namespace xrt {
namespace mock {

struct BoImpl {
    uint64_t addr = 0; size_t size = 0; bool host_only = false; int group = 0;
    std::vector<uint8_t> host, dev;          // host_only: the device accesses `host` directly
    uint8_t* devmem() { return host_only ? host.data() : dev.data(); }
};

// placement of the kernel arguments (index -> memory tag), from the v++ configuration
struct Placement { std::vector<std::string> tag; std::vector<int> group; };
static Placement placement() {
    const char* c = std::getenv("MOCK_CFG");
    const bool host = c && std::string(c) == "doma";
    Placement p;
    p.tag   = {"HBM[6]", "HBM[7]", host ? "HOST[0]" : "HBM[8]", "", "HBM[10]", "HBM[11]", "HBM[12]", "", host ? "HBM[8]" : "HBM[9]", "", ""};
    p.group = {6, 7, host ? 32 : 8, -1, 10, 11, 12, -1, host ? 8 : 9, -1, -1};
    return p;
}

static uint32_t lcg(uint32_t& s) { s = s * 1664525u + 1013904223u; return s >> 8; }

struct Pins {
    QData* araddr; CData* arlen; CData* arvalid; CData* arready; VlWide<8>* rdata; CData* rlast; CData* rvalid; CData* rready; CData* rresp;
    QData* awaddr; CData* awlen; CData* awvalid; CData* awready; VlWide<8>* wdata; IData* wstrb; CData* wlast; CData* wvalid; CData* wready;
    CData* bvalid; CData* bready; CData* bresp;
};

struct Sim;
// AXI4 slave memory: INCR bursts, up to 16 reads outstanding (first beat `rlat` cycles after the address, then one
// beat per cycle), writes land when both their address and data are known, B `wlat` cycles after the last beat.
// slow_pct percent of reads take slow_extra more cycles (the U55C HBM profile the testbench uses).
struct Slave {
    const char* name = ""; Pins p{}; Sim* sim = nullptr;
    unsigned rlat = 40, wlat = 26, slow_pct = 0, slow_extra = 0; uint32_t seed = 1;
    struct RB { uint64_t addr; unsigned beats, i; uint64_t ready; };
    struct AW { uint64_t addr; unsigned beats, i; };
    struct WB { uint32_t d[8]; uint32_t s; bool last; };
    std::deque<RB> rq; std::deque<AW> awq; std::deque<WB> wq; std::deque<uint64_t> bq;
    bool hsAR = false, hsR = false, hsAW = false, hsW = false, hsB = false;
    uint64_t rbeats = 0, wbeats = 0;
    void drive(uint64_t cyc);
    void sample();
    void commit(uint64_t cyc);
};

struct Sim {
    VerilatedContext ctx;
    Vdoma_kernel* top = nullptr;
    uint64_t cyc = 0;
    Slave s[7];
    std::map<uint64_t, std::shared_ptr<BoImpl>> bos;          // by base address
    uint64_t next_dev[64] = {}, next_host = 0;
    unsigned errors = 0;
    unsigned host_lat = 100;
    uint64_t flip = 0, flip_seen = 0;                          // MOCK_FLIP
    // AXI-Lite: one transaction at a time
    enum { L_IDLE, L_W, L_WB, L_R, L_RW } lst = L_IDLE;
    uint32_t laddr = 0, ldata = 0;
    Sim();
    ~Sim() { if (top) { top->final(); delete top; } }
    void step();
    void lite_write(uint32_t a, uint32_t d) { laddr = a; ldata = d; lst = L_W; while (lst != L_IDLE) step(); }
    uint32_t lite_read(uint32_t a) { laddr = a; lst = L_R; while (lst != L_IDLE) step(); return ldata; }
    uint8_t* resolve(uint64_t addr, size_t len, const char* who, bool write) {
        auto it = bos.upper_bound(addr);
        if (it != bos.begin()) {
            --it; BoImpl& b = *it->second;
            if (addr >= b.addr && addr + len <= b.addr + b.size) return b.devmem() + (addr - b.addr);
            if (addr >= b.addr && addr < b.addr + b.size) {
                if (errors++ < 10) std::fprintf(stderr, "MOCK: %s %s 0x%llx+%zu crosses the end of a %zu-byte buffer at 0x%llx\n", who,
                                                write ? "write" : "read", (unsigned long long)addr, len, b.size, (unsigned long long)b.addr);
                return nullptr;
            }
        }
        if (errors++ < 10) std::fprintf(stderr, "MOCK: %s %s 0x%llx+%zu is outside every buffer\n", who, write ? "write" : "read",
                                        (unsigned long long)addr, len);
        return nullptr;
    }
};

static Sim* g_sim = nullptr;
static Sim& sim() { if (!g_sim) g_sim = new Sim(); return *g_sim; }

#define BIND(k, n) do { Pins& q = s[k].p; \
    q.araddr = &top->m_axi_gmem##n##_araddr; q.arlen = &top->m_axi_gmem##n##_arlen; q.arvalid = &top->m_axi_gmem##n##_arvalid; \
    q.arready = &top->m_axi_gmem##n##_arready; q.rdata = &top->m_axi_gmem##n##_rdata; q.rlast = &top->m_axi_gmem##n##_rlast; \
    q.rvalid = &top->m_axi_gmem##n##_rvalid; q.rready = &top->m_axi_gmem##n##_rready; q.rresp = &top->m_axi_gmem##n##_rresp; \
    q.awaddr = &top->m_axi_gmem##n##_awaddr; q.awlen = &top->m_axi_gmem##n##_awlen; q.awvalid = &top->m_axi_gmem##n##_awvalid; \
    q.awready = &top->m_axi_gmem##n##_awready; q.wdata = &top->m_axi_gmem##n##_wdata; q.wstrb = &top->m_axi_gmem##n##_wstrb; \
    q.wlast = &top->m_axi_gmem##n##_wlast; q.wvalid = &top->m_axi_gmem##n##_wvalid; q.wready = &top->m_axi_gmem##n##_wready; \
    q.bvalid = &top->m_axi_gmem##n##_bvalid; q.bready = &top->m_axi_gmem##n##_bready; q.bresp = &top->m_axi_gmem##n##_bresp; } while (0)

Sim::Sim() {
    top = new Vdoma_kernel(&ctx);
    BIND(0, 0); BIND(1, 1); BIND(2, 2); BIND(3, 3); BIND(4, 4); BIND(5, 5); BIND(6, 6);
    const char* names[7] = {"gmem0 cmd_input", "gmem1 resp_output", "gmem2 pages", "gmem3 meta", "gmem4 brec", "gmem5 stash", "gmem6 pages_hbm"};
    const bool host = std::getenv("MOCK_CFG") && std::string(std::getenv("MOCK_CFG")) == "doma";
    if (std::getenv("MOCK_FLIP")) flip = std::strtoull(std::getenv("MOCK_FLIP"), nullptr, 10);
    if (std::getenv("MOCK_HOST_LAT")) host_lat = unsigned(std::atoi(std::getenv("MOCK_HOST_LAT")));
    for (int k = 0; k < 7; k++) {
        s[k].name = names[k]; s[k].sim = this; s[k].seed = 17u + k;
        if (k >= 3 || (k == 2 && !host)) { s[k].rlat = 53; s[k].wlat = 26; s[k].slow_pct = 2; s[k].slow_extra = 105; }   // HBM
        if (k == 2 && host) { s[k].rlat = host_lat; s[k].wlat = 1; }
    }
    // v14b MOCK_STASH_LAT=<cycles>: the stash port's read latency (default 53, as the other HBM ports), e.g. to see the
    // on-package deadlines missed in a debug bitstream (build_model.sh DEBUG=1)
    if (std::getenv("MOCK_STASH_LAT")) s[5].rlat = unsigned(std::atoi(std::getenv("MOCK_STASH_LAT")));
    // reset, as the platform holds ap_rst_n low after programming
    top->ap_rst_n = 0; top->ap_clk = 0;
    for (int i = 0; i < 32; i++) step();
    top->ap_rst_n = 1;
    for (int i = 0; i < 8; i++) step();
}

void Slave::drive(uint64_t cyc) {
    *p.arready = rq.size() < 16; *p.awready = 1; *p.wready = wq.size() < 4096;
    *p.rresp = 0; *p.bresp = 0;
    *p.rvalid = 0; *p.rlast = 0;
    if (!rq.empty() && rq.front().ready <= cyc) {
        RB& r = rq.front();
        const uint8_t* m = sim->resolve(r.addr + uint64_t(r.i) * 32, 32, name, false);
        for (int w = 0; w < 8; w++) { uint32_t v = 0xDEADBEEF; if (m) std::memcpy(&v, m + w * 4, 4); (*p.rdata)[w] = v; }
        *p.rvalid = 1; *p.rlast = (r.i + 1 == r.beats);
    }
    *p.bvalid = !bq.empty() && bq.front() <= cyc;
}
void Slave::sample() {
    hsAR = *p.arvalid && *p.arready; hsR = *p.rvalid && *p.rready; hsAW = *p.awvalid && *p.awready;
    hsW = *p.wvalid && *p.wready; hsB = *p.bvalid && *p.bready;
    if (hsAR) {
        uint64_t a = *p.araddr; unsigned n = unsigned(*p.arlen) + 1;
        if (((a & 4095) + n * 32) > 4096 && sim->errors++ < 10) std::fprintf(stderr, "MOCK: %s read burst 0x%llx x%u crosses 4 KB\n", name, (unsigned long long)a, n);
        if ((a & 31) && sim->errors++ < 10) std::fprintf(stderr, "MOCK: %s unaligned read 0x%llx\n", name, (unsigned long long)a);
        sim->resolve(a, size_t(n) * 32, name, false);
        uint64_t lat = rlat + ((slow_pct && lcg(seed) % 100 < slow_pct) ? slow_extra : 0);
        rq.push_back({a, n, 0, sim->cyc + lat});
    }
    if (hsAW) {
        uint64_t a = *p.awaddr; unsigned n = unsigned(*p.awlen) + 1;
        if (((a & 4095) + n * 32) > 4096 && sim->errors++ < 10) std::fprintf(stderr, "MOCK: %s write burst 0x%llx x%u crosses 4 KB\n", name, (unsigned long long)a, n);
        sim->resolve(a, size_t(n) * 32, name, true);
        awq.push_back({a, n, 0});
    }
    if (hsW) { WB b; for (int w = 0; w < 8; w++) b.d[w] = (*p.wdata)[w]; b.s = *p.wstrb; b.last = *p.wlast; wq.push_back(b); }
}
void Slave::commit(uint64_t cyc) {
    if (hsR) { RB& r = rq.front(); rbeats++; if (++r.i == r.beats) rq.pop_front(); }
    if (hsB) bq.pop_front();
    while (!awq.empty() && !wq.empty()) {                     // land write beats in order
        AW& a = awq.front(); WB& b = wq.front();
        uint8_t* m = sim->resolve(a.addr + uint64_t(a.i) * 32, 32, name, true);
        if (m) for (int y = 0; y < 32; y++) if (b.s >> y & 1) m[y] = uint8_t(b.d[y / 4] >> (8 * (y % 4)));
        if (m && this == &sim->s[1] && sim->flip && a.beats > 1 && ++sim->flip_seen == sim->flip) {
            m[5] ^= 0x10;
            std::fprintf(stderr, "MOCK: fault injected: bit flipped in resp_output data beat %llu (0x%llx)\n",
                         (unsigned long long)sim->flip, (unsigned long long)(a.addr + uint64_t(a.i) * 32));
        }
        const bool last = (a.i + 1 == a.beats);
        if (b.last != last && sim->errors++ < 10) std::fprintf(stderr, "MOCK: %s wlast framing wrong (beat %u of %u)\n", name, a.i + 1, a.beats);
        wq.pop_front(); wbeats++;
        if (++a.i == a.beats) { bq.push_back(cyc + wlat); awq.pop_front(); }
    }
}

void Sim::step() {
    top->ap_clk = 0;
    for (auto& x : s) x.drive(cyc);
    // AXI-Lite master
    top->s_axi_control_awvalid = (lst == L_W); top->s_axi_control_wvalid = (lst == L_W);
    top->s_axi_control_awaddr = uint16_t(laddr); top->s_axi_control_wdata = ldata; top->s_axi_control_wstrb = 0xF;
    top->s_axi_control_bready = (lst == L_WB);
    top->s_axi_control_arvalid = (lst == L_R); top->s_axi_control_araddr = uint16_t(laddr);
    top->s_axi_control_rready = (lst == L_RW);
    top->eval();
    for (auto& x : s) x.sample();
    int nl = lst;
    if (lst == L_W && top->s_axi_control_awready && top->s_axi_control_wready) nl = L_WB;
    else if (lst == L_WB && top->s_axi_control_bvalid) nl = L_IDLE;
    else if (lst == L_R && top->s_axi_control_arready) nl = L_RW;
    else if (lst == L_RW && top->s_axi_control_rvalid) { ldata = top->s_axi_control_rdata; nl = L_IDLE; }
    top->ap_clk = 1;
    top->eval();
    for (auto& x : s) x.commit(cyc);
    lst = decltype(lst)(nl);
    cyc++;
}

} // namespace mock

using mock::sim;

xclbin::xclbin(const std::string& p) : path(p) {}
xclbin::kernel xclbin::get_kernel(const std::string& name) const {
    if (name != "doma_kernel") throw std::runtime_error("mock xclbin: only doma_kernel");
    mock::Placement pl = mock::placement();
    kernel k;
    for (size_t i = 0; i < pl.tag.size(); i++) {
        arg a; if (!pl.tag[i].empty()) a.mems.push_back(mem{pl.tag[i], pl.group[i]});
        k.args.push_back(a);
    }
    return k;
}
device::device(unsigned int) { sim(); }
device::device(const std::string&) { sim(); }
uuid device::load_xclbin(const xclbin& xb) {
    std::printf("MOCK XRT: '%s' -> Verilated doma_kernel (%s placement)\n", xb.path.c_str(),
                (std::getenv("MOCK_CFG") && std::string(std::getenv("MOCK_CFG")) == "doma") ? "doma.cfg" : "doma_hw.cfg");
    return uuid{xb.path};
}

bo::bo(const device&, size_t size, flags f, int group) {
    mock::Sim& S = sim();
    impl_ = std::make_shared<mock::BoImpl>();
    impl_->size = size; impl_->group = group; impl_->host_only = (f == flags::host_only);
    if (impl_->host_only != (group == 32)) {
        // XRT allocates a host_only buffer in host memory whatever the group; a normal buffer for a HOST[0] argument
        // would be placed in device memory the kernel cannot reach through that port
        std::fprintf(stderr, "MOCK: %s buffer for memory group %d (%s)\n", impl_->host_only ? "host_only" : "device",
                     group, group == 32 ? "HOST[0]" : "an HBM bank");
        S.errors++;
    }
    const size_t span = (size + 4095) & ~size_t(4095);
    if (impl_->host_only) { impl_->addr = 0x00007f0000000000ULL + S.next_host; S.next_host += span + 4096; }
    else { int g = (group >= 0 && group < 64) ? group : 63;
           impl_->addr = 0x0000004000000000ULL + (uint64_t(g) << 33) + S.next_dev[g]; S.next_dev[g] += span + 4096;
           if (S.next_dev[g] > (512ull << 20))
               throw std::runtime_error("mock: HBM bank " + std::to_string(g) + " has no room for " + std::to_string(size) + " bytes (512 MB per bank)");
           impl_->dev.assign(size, 0xCD); }
    impl_->host.assign(size, 0);
    S.bos[impl_->addr] = impl_;
}
void bo::sync(xclBOSyncDirection dir, size_t size, size_t offset) {
    if (!impl_) throw std::runtime_error("mock: sync on an empty bo");
    if (offset + size > impl_->size) throw std::runtime_error("mock: sync beyond the buffer");
    if (impl_->host_only) return;
    if (dir == XCL_BO_SYNC_BO_TO_DEVICE) std::memcpy(impl_->dev.data() + offset, impl_->host.data() + offset, size);
    else std::memcpy(impl_->host.data() + offset, impl_->dev.data() + offset, size);
}
size_t bo::size() const { return impl_ ? impl_->size : 0; }
uint64_t bo::address() const { return impl_ ? impl_->addr : 0; }
void* bo::host_ptr() { return impl_ ? impl_->host.data() : nullptr; }

kernel::kernel(const device&, const uuid&, const std::string& name) : name_(name) {
    if (name != "doma_kernel") throw std::runtime_error("mock: only doma_kernel is modeled");
}
int kernel::group_id(int argno) const {
    mock::Placement pl = mock::placement();
    if (argno < 0 || size_t(argno) >= pl.group.size() || pl.group[argno] < 0) throw std::runtime_error("mock: argument has no memory");
    return pl.group[argno];
}

static uint64_t g_launch_start = 0;
static std::chrono::steady_clock::time_point g_t0;
static std::vector<uint64_t> g_args;
run kernel::start(const std::vector<uint64_t>& a) {
    if (a.size() != 11) throw std::runtime_error("mock: doma_kernel takes 11 arguments, got " + std::to_string(a.size()));
    mock::Sim& S = sim();
    // register map of package_kernel.tcl: pointers 64-bit, scalars 32-bit
    const uint32_t off[11] = {0x10, 0x1C, 0x28, 0x34, 0x3C, 0x48, 0x54, 0x60, 0x68, 0x74, 0x7C};
    const bool ptr[11] = {1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0};
    for (int i = 0; i < 11; i++) {
        S.lite_write(off[i], uint32_t(a[i]));
        if (ptr[i]) S.lite_write(off[i] + 4, uint32_t(a[i] >> 32));
    }
    S.lite_write(0x00, 1);                                   // ap_start
    g_launch_start = S.cyc; g_t0 = std::chrono::steady_clock::now(); g_args = a;
    run r; r.started_ = true; return r;
}
void run::wait() {
    if (!started_) return;
    mock::Sim& S = sim();
    const uint64_t maxc = std::getenv("MOCK_MAX_CYCLES") ? std::strtoull(std::getenv("MOCK_MAX_CYCLES"), nullptr, 10) : 4000000000ull;
    for (;;) {
        for (int i = 0; i < 64; i++) S.step();
        if (S.lite_read(0x00) & 0x2) break;                  // ap_done (clear on read)
        if (S.cyc - g_launch_start > maxc) throw std::runtime_error("mock: launch did not finish");
    }
    started_ = false;
    const double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - g_t0).count();
    if (std::getenv("MOCK_VERBOSE"))
        std::printf("MOCK XRT: launch size %llu, nblk %llu: %llu cycles in %.1f s (%.0f cycles/s)\n", (unsigned long long)g_args[3],
                    (unsigned long long)g_args[7], (unsigned long long)(S.cyc - g_launch_start), dt, (S.cyc - g_launch_start) / std::max(dt, 1e-9));
    if (S.errors) std::fprintf(stderr, "MOCK XRT: %u memory-access errors so far\n", S.errors);
}

} // namespace xrt

// end of the program: report anything the mock caught
static struct MockReport { ~MockReport() {
    std::fflush(stdout);
    if (xrt::mock::g_sim) std::fprintf(stderr, "MOCK XRT: %llu cycles simulated, %u memory-access errors\n",
                                        (unsigned long long)xrt::mock::g_sim->cyc, xrt::mock::g_sim->errors);
} } g_report;
