// axi_mem_model.v -- AXI4 slave memory for the doma_kernel testbench (simulation only).
// INCR bursts, up to 16 reads outstanding (each served RLAT cycles after its address),
// optional random read-data gaps, write data accepted before its address (W FIFO).
`timescale 1ns/1ps
module axi_mem_model #(
    parameter integer WF_DEPTH = 1024,   // write beats buffered until they land (limit: depth - 24)
    parameter integer DW    = 256,
    parameter integer WORDS = 65536,             // memory size in DW-bit words
    parameter [63:0]  BASE  = 64'd0,             // byte address of word 0
    parameter integer RLAT  = 40                 // cycles from address to first read beat
) (
    input  wire              clk,
    input  wire              rst_n,              // the bus is ignored while reset is held, as a real interconnect does
    input  wire [63:0]       araddr,  input wire [7:0] arlen, input wire arvalid, output wire arready,
    output reg  [DW-1:0]     rdata,   output wire [1:0] rresp, output reg rlast, output reg rvalid, input wire rready,
    input  wire [63:0]       awaddr,  input wire [7:0] awlen, input wire awvalid, output wire awready,
    input  wire [DW-1:0]     wdata,   input wire [DW/8-1:0] wstrb, input wire wlast, input wire wvalid, output wire wready,
    output wire [1:0]        bresp,   output reg bvalid, input wire bready
);
    reg [DW-1:0] mem [0:WORDS-1];
    integer      lat = RLAT;             // may be changed by the testbench
    integer      gap_pct = 0;            // percent of cycles with no read beat
    // HBM-like latency: slow_pct percent of reads take slow_extra more cycles (refresh, row
    // conflicts). The U55C's HBM measured ~98% near 55 cycles and the rest near 160.
    integer      slow_pct = 0, slow_extra = 0, lat_seed = 1;
    integer      wlat = 0;               // cycles before a write lands; reads meanwhile see the old data
    integer      rdy_gap = 0;            // percent of cycles on which arready/awready/wready are held low
    integer      w_hold = 0;             // v14: wready held low for this many cycles after every write address (slow writes)
    integer      w_hold_n = 0;
    // v14b, HBM-like behaviour (default off: the model as before). b_early: a write's B as soon as its data is in and its
    // address accepted (the card's HBM controllers acknowledge a write when they queue it), while it lands wlat cycles
    // later; rd_wait_wr: a read is served only once every write accepted before it has landed (the controller keeps a
    // read behind the writes queued ahead of it on the channel), its latency counted from then; w_lead >= 0: W beats are
    // refused while the beats received exceed the accepted addresses' beats by w_lead (0: no W before its AW).
    integer      b_early = 0, rd_wait_wr = 0, w_lead = -1;
    integer      land_tot = 0, eb_n = 0;     // write bursts landed since reset; bursts in the queue already acknowledged (b_early)
    reg [31:0]   aw_q = 0, land_q = 0;       // the same, registered: what the read side sees (no same-cycle race between the blocks)
    always @(posedge clk) begin aw_q <= aw_q + ((awvalid && awready) ? 1 : 0); land_q <= land_tot; end
    integer      perr = 0;               // AXI protocol violations seen (wlast framing, 4 KB crossing)
    reg          ar_blk = 0, aw_blk = 0, w_blk = 0;
    // Deterministic pseudo-random draws (xorshift32): identical on every simulator version. Verilator's $random sequence
    // changed between releases, which changed the stimulus and with it the calibrated timing budgets.
    function [31:0] xs32; input [31:0] x; reg [31:0] y; begin
        y = (x == 32'd0) ? 32'h2545F491 : x; y = y ^ (y << 13); y = y ^ (y >> 17); xs32 = y ^ (y << 5);
    end endfunction
    reg [31:0] rng_rdy = 32'h2545F491 ^ BASE[31:0] ^ (RLAT * 32'h9E3779B1) ^ WORDS;   // per-instance streams
    reg [31:0] rng_gap = 32'h6C8E9CF5 ^ BASE[31:0] ^ (RLAT * 32'h85EBCA6B) ^ WORDS;
    always @(posedge clk) begin : rdy_draw
        reg [31:0] a, b, c;
        a = xs32(rng_rdy); b = xs32(a); c = xs32(b); rng_rdy <= c;
        ar_blk <= (rdy_gap > 0) && (a % 100 < rdy_gap);
        aw_blk <= (rdy_gap > 0) && (b % 100 < rdy_gap);
        w_blk  <= (rdy_gap > 0) && (c % 100 < rdy_gap);
    end
    function cross4k; input [63:0] a; input [7:0] len; begin cross4k = ((a & 64'hFFF) + (len + 1) * (DW / 8)) > 4096; end endfunction
    integer      errors = 0;
    integer      cyc = 0;
    always @(posedge clk) cyc <= cyc + 1;
    // word index of a byte address, or -1 outside this memory (checked on the full 64-bit address,
    // so an address far outside cannot alias onto a valid word after truncation)
    function integer widx; input [63:0] a; reg [63:0] off; begin
        off = a - BASE;
        if (a < BASE || off >= WORDS * (DW / 8)) widx = -1;
        else widx = off >> $clog2(DW/8);
    end endfunction

    // ---------------- reads ----------------
    reg [63:0] rq_addr [0:15]; reg [7:0] rq_len [0:15]; integer rq_t [0:15]; integer rq_lat [0:15]; integer rq_ws [0:15];
    integer rq_wp = 0, rq_rp = 0, rq_n = 0, rbeat = 0; reg rbusy = 0;
    assign arready = rst_n && (rq_n < 16) && !ar_blk;
    assign rresp = 2'b00;
    initial begin rvalid = 0; rlast = 0; rdata = 0; bvalid = 0; end
    always @(posedge clk) begin : rd
        integer w;
        if (!rst_n) begin rvalid <= 0; rlast <= 0; end
        else begin
        rng_gap = xs32(rng_gap);
        if (arvalid && arready) begin
            if (cross4k(araddr, arlen)) begin perr = perr + 1; errors = errors + 1;
                if (perr < 5) $display("AXI PROTOCOL: read burst at %h len %0d crosses a 4 KB boundary", araddr, arlen + 1); end
            rq_addr[rq_wp] = araddr; rq_len[rq_wp] = arlen; rq_t[rq_wp] = cyc; rq_ws[rq_wp] = aw_q + ((awvalid && awready) ? 1 : 0);
            if (slow_pct > 0) lat_seed = xs32(lat_seed);           // lat_seed: the stream's state (the testbench may seed it)
            rq_lat[rq_wp] = lat + ((slow_pct > 0 && ($unsigned(lat_seed) % 100) < slow_pct) ? slow_extra : 0);
            rq_wp = (rq_wp + 1) % 16; rq_n = rq_n + 1;
        end
        // rd_wait_wr: the head read waits for the writes accepted before it, and its latency starts once they landed
        if (rd_wait_wr != 0 && rq_n > 0 && rbeat == 0 && land_q < rq_ws[rq_rp]) rq_t[rq_rp] = cyc;
        if (rvalid && rready) begin
            rvalid <= 0;
            if (rlast) begin rbusy = 0; rq_rp = (rq_rp + 1) % 16; rq_n = rq_n - 1; rbeat = 0; end
            else rbeat = rbeat + 1;
        end
        if ((!rvalid || rready) && rq_n > 0 && !(rvalid && rready && rlast) && cyc >= rq_t[rq_rp] + rq_lat[rq_rp]
            && (rd_wait_wr == 0 || land_q >= rq_ws[rq_rp])
            && (gap_pct == 0 || rng_gap % 100 >= gap_pct)) begin
            w = (widx(rq_addr[rq_rp]) < 0) ? -1 : widx(rq_addr[rq_rp]) + rbeat;
            if (w < 0 || w >= WORDS) begin errors = errors + 1; rdata <= {DW{1'b0}}; end
            else rdata <= mem[w];
            rlast  <= (rbeat == rq_len[rq_rp]);
            rvalid <= 1;
        end
        end
    end

    // ---------------- writes ----------------
    reg [DW-1:0] wf_d [0:WF_DEPTH-1]; reg [DW/8-1:0] wf_s [0:WF_DEPTH-1]; reg wf_l [0:WF_DEPTH-1]; integer wf_wp = 0, wf_rp = 0, wf_n = 0;
    reg [63:0] aw_addr [0:15]; reg [7:0] aw_len [0:15]; integer aw_t [0:15]; integer aw_end [0:15]; integer aw_done [0:15]; integer aw_cum = 0, w_rx = 0; integer aw_wp = 0, aw_rp = 0, aw_n = 0, b_pend = 0;
    assign wready  = rst_n && (wf_n < WF_DEPTH - 24) && !w_blk && (w_hold_n == 0) &&
                     (w_lead < 0 || w_rx < aw_cum + ((awvalid && awready) ? awlen + 1 : 0) + w_lead);
    always @(posedge clk) begin                                   // v14: +..._whold (deterministic write backpressure)
        if (awvalid && awready && w_hold > 0) w_hold_n <= w_hold;
        else if (w_hold_n > 0) w_hold_n <= w_hold_n - 1;
    end
    assign awready = rst_n && (aw_n < 16) && !aw_blk;
    assign bresp   = 2'b00;
    always @(posedge clk) begin : wr
        integer k, w, by, q, qi;
        if (!rst_n) begin bvalid <= 0; aw_cum = 0; w_rx = 0; end
        else begin
        if (wvalid && wready) begin wf_d[wf_wp] = wdata; wf_s[wf_wp] = wstrb; wf_l[wf_wp] = wlast; wf_wp = (wf_wp + 1) % WF_DEPTH; wf_n = wf_n + 1; w_rx = w_rx + 1; end
        if (awvalid && awready) begin
            if (cross4k(awaddr, awlen)) begin perr = perr + 1; errors = errors + 1;
                if (perr < 5) $display("AXI PROTOCOL: write burst at %h len %0d crosses a 4 KB boundary", awaddr, awlen + 1); end
            aw_addr[aw_wp] = awaddr; aw_len[aw_wp] = awlen; aw_t[aw_wp] = cyc;
            aw_cum = aw_cum + awlen + 1; aw_end[aw_wp] = aw_cum; aw_done[aw_wp] = (w_rx >= aw_cum) ? cyc : -1;
            aw_wp = (aw_wp + 1) % 16; aw_n = aw_n + 1; end
        // a burst lands wlat cycles after its last data beat has arrived
        // each burst's data-complete time; a burst lands wlat cycles after its own (pipelined,
        // in order) -- not after the previous burst has landed
        for (q = 0; q < aw_n; q = q + 1) begin
            qi = (aw_rp + q) % 16;
            if (aw_done[qi] < 0 && w_rx >= aw_end[qi]) aw_done[qi] = cyc;
        end
        // b_early: each burst's B once its data is in (in order), before it lands
        if (b_early != 0) while (eb_n < aw_n && aw_done[(aw_rp + eb_n) % 16] >= 0) begin eb_n = eb_n + 1; b_pend = b_pend + 1; end
        if (aw_n > 0 && aw_done[aw_rp] >= 0 && wf_n >= aw_len[aw_rp] + 1 && cyc >= aw_done[aw_rp] + wlat) begin
            for (k = 0; k <= aw_len[aw_rp]; k = k + 1) begin
                w = (widx(aw_addr[aw_rp]) < 0) ? -1 : widx(aw_addr[aw_rp]) + k;
                if (wf_l[wf_rp] !== (k == aw_len[aw_rp])) begin perr = perr + 1; errors = errors + 1;
                    if (perr < 5) $display("AXI PROTOCOL: wlast=%0d on beat %0d of a %0d-beat write burst at %h", wf_l[wf_rp], k, aw_len[aw_rp] + 1, aw_addr[aw_rp]); end
                if (w < 0 || w >= WORDS) errors = errors + 1;
                else for (by = 0; by < DW/8; by = by + 1)
                    if (wf_s[wf_rp][by]) mem[w][by*8 +: 8] = wf_d[wf_rp][by*8 +: 8];
                wf_rp = (wf_rp + 1) % WF_DEPTH; wf_n = wf_n - 1;
            end
            aw_rp = (aw_rp + 1) % 16; aw_n = aw_n - 1; land_tot = land_tot + 1;
            if (eb_n > 0) eb_n = eb_n - 1; else b_pend = b_pend + 1;
        end
        if (bvalid && bready) begin bvalid <= 0; b_pend = b_pend - 1; end
        else if (b_pend > 0) bvalid <= 1;
        end
    end
endmodule
