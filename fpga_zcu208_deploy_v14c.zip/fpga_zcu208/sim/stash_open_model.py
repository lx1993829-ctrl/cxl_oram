#!/usr/bin/env python3
"""stash_open_model.py -- v14c: a timing model of the on-package stash open (rtl/stash_hbm.v, J_RD), and the table of
tail options of docs/v14c_report.md section 1.3.

    python3 stash_open_model.py [--dmax 2108] [--sx 794] [--dec 255] [--wr 1156] [--write 1030] [--lat 58]

The open reads, in issue order (one read address per cycle):
  level 1: b's head (2 beats), bt's head (2, if bt != b), the requested block's metadata (1) and data (128, if it is
           stashed), the free list (1);
  level 2, issued two cycles after b's head has landed: per window entry a prep cycle, its metadata (1), its data (128);
           then the chain head (1) if b has a chain.
Memory: a read's first beat comes no earlier than its address plus the latency L, beats return in order at c cycles
per beat, with one idle cycle between reads (fitted to the RTL simulation: 62 + ~131 cycles per window entry at
57-cycle reads). The stash is ready two cycles after its last beat.

The two profiles are fitted so that a full window (9 entries, bt != b, a chain) takes --dmax cycles, the card's slowest
open: P1 latency-bound (1 beat per cycle, L fitted), P2 bandwidth-bound (L = --lat, c fitted). Each option's worst open
then gives the worst stash ready after the arrival (--sx today), the write-back start (+ --dec, the decisions), the
release gate (+ --write), and the budgets by sim/card_budgets.py's rule at 10% + 74, never below v14's simulated
855 / 1,938 (4 KB). "Recovers" is against today's AR_REL_H; v11g releases at t_arr + 3,141.
"""
import math, sys

WB_FLOOR, REL_FLOOR, V11G_REL = 855, 1938, 3141


def open_dur(w, rq, same=0, chain=0, L=57.0, c=1.0, ports=1, gap=1):
    beats = [2] + ([] if same else [2]) + ([1, 128] if rq else []) + [1]
    l2 = []
    for _ in range(w - rq):                  # the requested block is one of b's w entries; its data came in level 1
        l2 += [("MW", 1), ("D", 128)]
    if chain: l2 += [("MC", 1)]
    pfree = [0.0] * ports
    def serve(ar, nb, p):
        start = max(ar + L, pfree[p] + gap); end = start + nb * c; pfree[p] = end; return end
    ends = []
    for i, nb in enumerate(beats):
        e = serve(i + 1, nb, 0); ends.append(e)
        if i == 0: head = e
    t = head + 2; k = 0
    for name, nb in l2:
        t += 1
        p = (k % ports) if (name == "D" and ports > 1) else 0
        if name == "D": k += 1
        ends.append(serve(t, nb, p))
        if name == "MW": t += 1
    return max(ends) + 2


def fit(dmax, lat):
    def bis(f, lo, hi):
        for _ in range(60):
            m = (lo + hi) / 2
            if f(m) < dmax: lo = m
            else: hi = m
        return lo
    L1 = bis(lambda m: open_dur(9, 0, chain=1, L=m, c=1.0), 20, 5000)
    c2 = bis(lambda m: open_dur(9, 0, chain=1, L=lat, c=m), 0.5, 10)
    return L1, c2


def main(a):
    o = {"dmax": 2108.0, "sx": 794.0, "dec": 255.0, "wr": 1156.0, "write": 1030.0, "lat": 58.0, "pct": 10.0, "abs": 74}
    i = 0
    while i < len(a):
        k = a[i].lstrip("-")
        if k not in o: sys.exit(__doc__)
        o[k] = float(a[i + 1]); i += 2
    print("RTL check (57-cycle reads, 1 beat per cycle; RTL medians 62 / 246 / 770 / 1294 for 0 / 1 / 5 / 9 entries):",
          " / ".join(f"{open_dur(w, 0, L=52):.0f}" for w in (0, 1, 5, 9)))
    L1, c2 = fit(o["dmax"], o["lat"])
    P = {"P1": dict(L=L1, c=1.0), "P2": dict(L=o["lat"], c=c2)}
    print(f"profiles for a {o['dmax']:.0f}-cycle full-window open: P1 latency-bound, {L1:.0f}-cycle reads at 1 beat per cycle; "
          f"P2 bandwidth-bound, {o['lat']:.0f}-cycle reads at {1 / c2:.2f} beats per cycle")
    def budgets(sx):
        ws = sx + o["dec"]; rg = ws + o["write"]
        wbc = math.ceil(ws * (1 + o["pct"] / 100)) + o["abs"]
        relc = max(math.ceil(rg * (1 + o["pct"] / 100)) + o["abs"], wbc + o["wr"])
        return max(WB_FLOOR, wbc), max(REL_FLOOR, int(relc))
    wb_now, rel_now = budgets(o["sx"])
    print(f"today: stash ready +{o['sx']:.0f} after the arrival -> AR_WB_H {wb_now}, AR_REL_H {rel_now} "
          f"(release {V11G_REL - rel_now} cycles earlier than v11g; the tail costs {rel_now - REL_FLOOR})")
    opts = [("A  more outstanding stash reads (none limit an open today)", {}),
            ("B  stash spread over HBM[12:15], one port (P2: if the channel, not the port, limits)", {"c1": 1}),
            ("C  a second stash read port", {"ports": 2}),
            ("C4 four stash read ports", {"ports": 4}),
            ("D1 issue earlier within the access: no deferral (worst case -120)", {"early": 120}),
            ("F  read only the evicted blocks and the requested block (worst: 8 evictions)", {"entries": 8})]
    print(f"{'option':84s} {'P1: open  ready  recovers':>28s}   {'P2: open  ready  recovers':>28s}")
    for name, x in opts:
        row = []
        for p, kw in P.items():
            kw = dict(kw)
            if x.get("c1") and p == "P2": kw["c"] = 1.0
            d0 = open_dur(9, 0, chain=1, **P[p])
            d = open_dur(x.get("entries", 9), 0, chain=1, ports=x.get("ports", 1), **kw) - x.get("early", 0)
            sx = max(2.0, o["sx"] - (d0 - d))
            _, rel = budgets(sx)
            row.append(f"{d:6.0f} {sx:+6.0f} {rel_now - rel:9d}")
        print(f"{name:84s} {row[0]:>28s}   {row[1]:>28s}")
    print("D2 (open the next access's stash during this access's write-back) and E + F (decide from the metadata): the stash")
    print("   is ready by the arrival in both profiles; they recover the whole tail (see docs/v14c_report.md 1.3).")


if __name__ == "__main__":
    main(sys.argv[1:])
