#!/bin/bash
# repro_card_halt.sh -- v14b: the card's v14 on-package halts (4 KB, lambda 7), reproduced in simulation.
#
# On the U55C, v14 halted with 0x108 during the preload: at 100% on package in state 24 (S_RES_STREAM, the write handed
# off in time, so deadline (1): the write-back had started after t_arr + AR_WB_H), at 20% in state 22 (S_DDR_WRITE:
# deadline (2), the write not handed off at t_arr + AR_REL_H), both ~3,300-3,400 cycles into the access. On package,
# the eviction decisions wait for the stash open (S_SCAN waits for the stash to be ready); v14's budgets assumed every
# stash read within 200 cycles. With the stash port slower than that model -- longer reads, or fewer beats per cycle --
# the production RTL halts exactly like the card; the debug build (DEBUG=1) runs the same accesses without halting and
# records them. Runs (production build, then the debug build):
#   st350  every stash read 350 cycles           -> state 24, deadline (1)
#   st450  every stash read 450 cycles           -> state 22, deadline (2)
#   g40    stash read beats on 60% of cycles     -> state 22, deadline (2)
#   p20    20% on package, stash reads 600 cycles -> state 22, deadline (2) (the card's 20% halt)
#   dbg350 the debug build with st350            -> no halt; the counters and the first-overrun snapshot
# Usage: bash repro_card_halt.sh   (about 15 minutes; logs in build/repro_*.log)
set -u
cd "$(dirname "$0")"
RTL=../rtl; SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
mkdir -p build
mk() {   # mk <name> <defines...>
    local n=$1; shift
    [ -x build/$n/V$n ] && return 0
    verilator --binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-BLKANDNBLK \
        -I$RTL -DORAM_BLOCK_BEATS=128 -DORAM_C=7 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL "$@" --top-module tb_doma_kernel \
        ./tb_doma_kernel.v ./oram_timing_monitor.v ./axi_mem_model.v $SRCS $RTL/doma_kernel.v -Mdir build/$n -o V$n > build/$n.build.log 2>&1 \
        || { echo "build of $n failed (build/$n.build.log)"; exit 1; }
}
mk repro_ar
mk repro_dbg -DORAM_PHASE_TRACE -DORAM_ONPKG_DEBUG
BASE="+hb=0 +preload +seed=3 +cmds=200 +cmds2=4 +halt_wait=60000"
for v in "st350:+hbm_pct=100 +stash_lat=350" "st450:+hbm_pct=100 +stash_lat=450" "g40:+hbm_pct=100 +stash_gap=40" "p20:+hbm_pct=20 +stash_lat=600 +host_lat=263 +host_wlat=98"; do
    t=${v%%:*}; a=${v#*:}
    build/repro_ar/Vrepro_ar $BASE $a > build/repro_$t.log 2>&1
    echo "== $t ($a), production build"
    grep -E "^(preload|run1): halt record|^HALTING-ACCESS" build/repro_$t.log | head -3
done
build/repro_dbg/Vrepro_dbg $BASE +hbm_pct=100 +stash_lat=350 +phase_trace +dbg_csv=build/repro_dbg350.csv > build/repro_dbg350.log 2>&1
echo "== dbg350 (+hbm_pct=100 +stash_lat=350), debug build"
grep -E "^run2: debug counters|^run2: debug first overrun|DOMA KERNEL" build/repro_dbg350.log
python3 card_budgets.py build/repro_dbg350.csv | grep -E "^card_budgets|write-back start|release gate|stash ready|against|chosen"
