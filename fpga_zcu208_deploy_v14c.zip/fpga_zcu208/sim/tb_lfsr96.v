// tb_lfsr96.v -- v14b: aes_gcm_2lane's flattened 96-step LFSR advance (one XOR mask per output bit) against the
// 96-iteration loop it replaced, on 100,000 random states plus the single-bit states (iverilog).
`timescale 1ns/1ps
module tb_lfsr96;
    function [95:0] loop96; input [95:0] x; reg [95:0] s; reg fb; integer k; begin
        s = x; for (k = 0; k < 96; k = k + 1) begin fb = s[95] ^ s[9] ^ s[8] ^ s[5]; s = {s[94:0], fb}; end loop96 = s;
    end endfunction
    // the core's function, taken from its source (one instance of the module; its function called hierarchically)
    reg clk = 0;
    aes_gcm_2lane u (.clk(clk), .rst_n(1'b0), .enable(1'b0), .start(1'b0), .encrypt(1'b0), .key(128'd0), .iv(96'd0),
                     .iv_advance(1'b0), .data_in(256'd0), .data_mask(2'b11), .data_valid(1'b0), .data_last(1'b0), .tag_in(128'd0));
    integer i, bad; reg [95:0] x; reg [31:0] r;
    initial begin
        bad = 0; r = 32'h1234567;
        for (i = 0; i < 96; i = i + 1) begin x = 96'd1 << i; if (u.advance_lfsr_96(x) !== loop96(x)) bad = bad + 1; end
        for (i = 0; i < 100000; i = i + 1) begin
            r = r ^ (r << 13); r = r ^ (r >> 17); r = r ^ (r << 5); x[31:0] = r;
            r = r ^ (r << 13); r = r ^ (r >> 17); r = r ^ (r << 5); x[63:32] = r;
            r = r ^ (r << 13); r = r ^ (r >> 17); r = r ^ (r << 5); x[95:64] = r;
            if (u.advance_lfsr_96(x) !== loop96(x)) bad = bad + 1;
        end
        $display("LFSR96: flattened advance vs the 96-step loop: 100096 states, %0d mismatches", bad);
        $finish;
    end
endmodule
