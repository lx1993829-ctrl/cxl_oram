# v14c: card-calibrated 4 KB budgets, the stash tail, all sizes

**In short.**

- **4 KB budgets:** `rtl/oram_params.vh` carries the card calibration at a 10% margin: AR_WB_H 1,228, AR_REL_H 2,384, AR_DONE_H 2,818 (4 KB, λ = 7). The release moves from v14's simulated `t_arr + 1,938` to `t_arr + 2,384`. Of v14's 1,203-cycle saving per on-package access over v11g, 757 cycles (63%) remain; the stash tail costs the other 446.
- **Stash tail (report only, nothing implemented):**
  - **Cause:** the stash open reads the whole 4 KB block of every entry in the bucket's stash window, up to 9 blocks, and its second round trip waits for the first. On the card the slowest open takes 2,108 cycles, against 1,294 in simulation.
  - **Your class split (13.46M records) confirms it:** how late the stash is follows this access's own window, not deferral, the previous access, GET vs PUT, or the bucket's arrival. The slowest access of all evicted nothing: it read 9 blocks it did not use. The same window size is sometimes on time, so the stash port's throughput varies from access to access; a fixed long latency is ruled out.
  - **What recovers it:** a second stash read port, or opening the next access's stash during this access's write-back, recovers all 446 cycles. Spreading the stash over HBM[12:15] behind one port may recover most of it. More outstanding reads, or removing the deferral, recover nothing. No further debug bitstream is needed to choose; cashing in any change needs one calibration run after it.
- **Margin:** 10% is enough. The tail check on your 13.46M records expects 0.0034 deadline misses per 20M accesses at 1,228 / 2,384, a 0.3% chance that a 20M run halts. An expected 0.01 needs only AR_WB_H 1,195. The 20% values (1,333 / 2,489 / 2,923) are kept as the fallback if a validation run halts.
- **All sizes:** `vitis/calibrate_all_sizes.sh` builds the 32 B – 2 KB debug bitstreams, runs them, and prints per-size budgets and one summary table as text.
- **host_ycsb:** your per-request latency distributions, GET-vs-PUT KS test, `DOMA_LAT_HIST` and `DOMA_SLOW_DUMP` are in `vitis/host_ycsb.cpp`.
- **Debug records:** the debug build's trace records grow to 128 bytes. The third beat records the access's stash open on the stash port.
- **Production RTL:** identical to v14b except the 4 KB budget values.

## 1. The stash tail

### 1.1 What the open does

The stash open (`rtl/stash_hbm.v`, `J_RD`) is issued once the position lookup gives the bucket `b`, about 61 cycles
into the access. On the card that is about 1,314 cycles before the bucket arrives. It reads, in order:

1. **Level 1:** b's window head (2 beats), the target bucket's head (2, if `bt ≠ b`), the requested block's metadata and its 4 KB data (if it is stashed), and the free list (1).
2. **Level 2, issued when b's head has landed:** for each entry of b's window, its metadata (1 beat) and its **4 KB data** (128 beats); then the chain head (1).

The decisions start when everything has landed. So an open costs two read round trips plus 129 beats per window
entry. In the RTL simulation (57-cycle reads, 1 beat per cycle) it takes 62 cycles for an empty window and, with
entries, about 115 + 131 per entry (the second round trip adds about 55): at most 1,294 cycles for a full window of 9. A small timing model, `sim/stash_open_model.py`,
reproduces this to within 4 cycles.

### 1.2 What the card shows

- **Slowest opens:** 1,964–2,108 cycles, issue to ready, against 1,294 in simulation for a full window.
- **Deferral:** about a quarter of the slowest were held 40–120 cycles until the stash's earlier writes had landed.
- **After the stash is ready:** the decisions take 136–273 cycles and the write 1,030.
- **Other ports:** the bucket port reads at 57–59 cycles and 0.97 beats per cycle, and the bucket-record port at 61.

Two memory profiles reproduce the worst open as a full window. Any mix of the two also fits.

| Profile | Stash reads | Comment |
|---|---|---|
| **P1, latency-bound** | 460 cycles each, 1 beat per cycle | ~8× the latency of the other HBM ports; physically less likely |
| **P2, bandwidth-bound** | 58 cycles, 0.59 beats per cycle | HBM[12] giving ~60% of the bucket port's throughput on random 4 KB reads mixed with 32-byte metadata reads |

Your class split (below) rules out P1, so the P2 column of the option table applies, with throughput that varies
from access to access.

**What else is on HBM[12]:** in every `.cfg` of the package only the stash port is mapped there (`doma.cfg`,
`doma_hw.cfg`: `stash:HBM[12]`; `doma_big*.cfg`: `HBM[12:14]` or `[12:15]`). If your card build used its own `.cfg`,
its `sp=` lines would show whether anything shares HBM[12]; nothing in the class split suggests it.

**What your class split shows** (`card_budgets.py` on the v14b CSVs: 13,457,612 on-package accesses; 0.60% had the
stash ready more than 100 cycles after the arrival, 0.35% more than 200):

| Split | Share later than 100 cycles | Worst |
|---|---|---|
| Eviction copies of this access: 0 / 1 / 2 / 3 / 4 | 0.41% / 0.69% / 0.13% / 0.48% / 1.6% | 794 / 776 / 675 / 778 / 782 |
| Eviction copies of this access: 5 / 6 / 7 / 8 | 5.4% / 17% / 49% / 89% | 721 / 694 / 733 / 661 |
| Eviction copies of the access before: 0 … 7 | 0.48–0.64%, flat | 603–794 |
| GET / PUT | 0.61% / 0.60% | 794 / 778 |
| Open on time / deferred 0–159 cycles | 0.56% / 0.9–1.2% | 794 / 705–782 |
| S_SCAN entered | always within 4 cycles of the arrival | |

- **This access's window decides it.** An access evicts only from its own window, so its eviction count is a lower bound on the window size. Lateness climbs steeply with it. The previous access's writes, the command type, and the bucket's arrival (S_SCAN) play no part. Deferral doubles the share but not the worst case: the slowest access was not deferred.
- **The open reads data it does not use.** The slowest access of all (794) evicted nothing. Its bucket was full, so none of the window's blocks moved, yet the open read all of them. 84% of accesses evict 0 or 1 blocks.
- **The window statistics match the simulation.** The card's eviction-count distribution equals the RTL simulation's to within a few percent at every count (41.6 / 42.8 / 9.5 / 3.9 / 1.5 / 0.53 / 0.16 / 0.04 / 0.009% vs 41.5 / 42.6 / 9.6 / 4.0 / 1.7 / 0.47 / 0.13 / 0.05 / 0.01%). So the simulated window sizes used in §1.3 are the card's.
- **The stash port's speed varies per access.** 11% of the accesses that evicted 8 blocks, whose windows hold at least 8, were not late at all. In those, the open ran near the simulation's speed: a full window then finishes 20 cycles before the arrival. 69% of the same class were more than 200 late. A fixed latency (P1) would make every such access late by about the same amount, so it is ruled out. What is left is throughput on HBM[12] that changes from open to open: around 60–85% of the simulation's for the large opens, sometimes all of it. The likely cause is the pattern of up to 9 random 4 KB blocks and 32-byte metadata reads on one HBM channel.
- **The 11% from the earlier table.** Those accesses are not in these CSVs. The table you pasted before counted exactly 1,639,540 more accesses than these records, and exactly 1,639,540 more accesses between 100 and 200 cycles. So it included a separate set of 1.64M accesses, all 100–200 cycles late, that the CSVs do not hold (possibly a preload or another run). None of them is later than 200, so they do not touch the budgets.

### 1.3 Options, and what each recovers

Each option is evaluated on the worst case the card showed, a 2,108-cycle open. The P2 column is the one that applies
(P1 is ruled out above); P1 is kept for comparison. "Recovers" is
out of the 446 cycles the tail costs today; at 446, the release returns to v14's `t_arr + 1,938`, with the full
1,203-cycle saving over v11g. The budgets never go below v14's simulated 855 / 1,938.

| Option | P1: worst open, stash ready, recovers | P2: worst open, stash ready, recovers |
|---|---|---|
| A. More outstanding stash reads | 2,108, +794, **0** | 2,108, +794, **0** |
| B. Stash spread over HBM[12:15], one port | 2,108, +794, **0** | 1,304, +2, **446** (only if HBM[12]'s efficiency is the limit) |
| C. A second stash read port (window data alternate) | 1,592, +278, **446** | 1,238, +2, **446** |
| C4. Four stash read ports | 1,334, +20, **446** | 804, +2, **446** |
| D1. Issue earlier within the access: no deferral | 2,108, +794, **0** (the slowest access was not deferred) | 2,108, +794, **0** |
| D2. Issue earlier across accesses: open the next access's stash during this access's write-back | ready long before the arrival, **446** | same, **446** |
| F. Read only the data the access uses: the blocks it evicts and the requested block | 1,977, +663, **144** | 1,884, +574, **242** |
| E + F. Decide from the metadata; read only the evicted blocks, which the write needs only when it reaches them | write-back start back to the floor, **~446** | **~446** |

Notes:

- **A, more outstanding reads.** The open issues its reads back to back. The RTL keeps up to 32 in flight and an open needs at most 24, so this is not the limit. It would matter only if the card's interconnect serialised the stash reads, and then no full window could ever finish at the simulation's speed, which the card sometimes does.
- **B, spreading over HBM[12:15].** One AXI port tops out at 1 beat per cycle (256 bits at 300 MHz). The card sometimes reaches that speed, so the limit is the channel's efficiency on this pattern, which spreading addresses. It is cheap: the pool's slots are interleaved across the four channels, plus a `.cfg` change. But even at full speed a full window finishes only 10–20 cycles before the arrival, so B leaves no slack and may not recover all 446.
- **C, more read ports.** A second `m_axi` port in `stash_hbm.v`, with the pool split across two channels and window data reads alternating between them.
- **D1, earlier within the access.** The open needs `b`, so it cannot start before the position lookup. Only the deferral can go, and the slowest access was not deferred.
- **D2, earlier across accesses.** After this access's stash commit, the stash port is idle for about 2,300 cycles until the next access's open. Moving the next access's position lookup and stash open into that gap gives the open about 3,600 cycles before its arrival, against 1,314 today. The worst open measured is 2,108.
  - It needs a one-command lookahead from the kernel.
  - It needs a second set of the stash's read buffers (about 40 KB at 4 KB blocks), because this access still uses the first set until its copies are done.
  - It needs two ordering rules: the next lookup must see this access's position update, and the next open must see this access's stash commit.
  - No new HBM port. It is the largest change.
- **F, read only the data the access uses.** Most of the window is not used: an access evicts 0–1 blocks in 84% of accesses (simulation), but today the open reads every window entry's data. Reading only what is used makes late opens 3–13× rarer. The worst case, a nearly empty bucket evicting 8 blocks, is only one block shorter, and that worst case sets the budgets.
- **E + F, decide from the metadata.** Deadline (1) returns to the floor. The hand-off then waits only for the evicted blocks. To recover all 446 cycles, `card_budgets.py`'s second release term must use the card's write-back start instead of the floor.
- **How the table was computed:** `sim/stash_open_model.py`, with the profiles fitted to the 2,108-cycle open. Window and eviction counts for F come from the RTL simulation (10,221 opens, N = 2,048); the card's eviction counts match them (§1.2).

**Recommendation.** If the 446 cycles are worth a later version, take C: a second stash read port, with the pool
split over HBM[12] and HBM[13] and the window reads alternating.

- It halves the per-port data and spreads the channel load.
- A full window then finishes before the arrival even at today's slowest throughput: by about 75 cycles, or about 500 with four ports. So the stash should no longer set the budgets.
- It is contained in `stash_hbm.v`, the kernel's ports and the `.cfg`.

D2 recovers the same with no new port, but changes how accesses are sequenced. B is the cheapest change, but it leaves
a full window only 10–20 cycles of slack.

Whichever is chosen, the budgets fall only after one calibration on the card with the change in. That needs either a
debug bitstream, as for v14c, or a production bitstream with model-derived budgets that passes the 20M-access
validation runs.

### 1.4 The v14c debug records

The v14c debug bitstream is still built with `build.sh DEBUG=1 TRACE=1 SCHED=arrival`. Its trace records are now
128 bytes: summary byte 2 bit 3 is set, and the hosts read the size from it. The third beat describes the access's
stash open as seen on the stash port, as 16-bit access-cycle words (65535 = did not happen):

| Word | Field |
|---|---|
| 0 | reads issued [15:8]; the open was deferred until the stash was quiet [7]; b has a chain [6]; bt == b [5]; the requested block is stashed [4]; b's window entries [3:0] |
| 1 | read beats |
| 2 | first read address |
| 3 | first read beat |
| 4 | b's head landed (level 2 may start) |
| 5 | last read beat |
| 6 | longest read, address to first beat (includes in-order queueing) |
| 7 | sum of the read latencies (saturating) |
| 8 | cycles a read address waited for the port |
| 9 | cycles with reads out and no beat |
| 10 | stash write beats during the open |
| 11 | cycles from the last stash write response to the open |
| 12 | position lookup done |
| 13 | first level-2 read address |
| 14 | stash writes outstanding at the open [15:8]; the bucket's fill [7:0] |
| 15 | the open complete (stash ready) |

The regression (`onpkg` group, test (g)) checks every word against the testbench's own view of the stash port, for
every access: 1,416 accesses with a preload and 408 with slow writes or a slow stash, 0 differences. The production
RTL is unchanged: preprocessed without `ORAM_ONPKG_DEBUG`, the sources equal v14b's but for the budget values.

`host_phases` writes the 16 words as CSV columns `s0`–`s15` after v14b's columns (`DOMA_ONPKG_CSV`). It prints
their distributions under "stash open".

`sim/card_budgets.py` now prints:

- the stash-ready times split by deferral, eviction copies (this access and the one before), command and S_SCAN entry; this works on v14b CSVs too;
- with v14c records, open duration by window size and requested-block status;
- the fit `duration ≈ fixed + c × read beats` over opens with level-2 reads. The fixed term is the two round trips, so it separates P1 from P2 directly. In simulation: 120 + 1.00 × beats with 53-cycle reads, and 712 + 0.98 × beats with 350-cycle reads;
- the slowest accesses with all stash fields.

### 1.5 Reproducing the analysis

`python3 sim/stash_open_model.py` prints the profile fit and the option table; `--dmax`, `--sx`, `--dec` and `--wr` take
the card's numbers. The model's check against the RTL:

| Window entries | RTL median (cycles) | Model (cycles) |
|---|---|---|
| 1 | 246 | 242 |
| 5 | 770 | 766 |
| 9 | 1,294 | 1,290 |

### 1.6 Nothing more is needed for v14c

Your class split answered what the v14c debug records were meant to settle: which profile applies, and whether
deferral or the previous access matters. No further debug bitstream is needed for v14c. The 128-byte stash records
stay in the debug build for any later calibration.

## 2. Is 10% enough?

Yes. `card_budgets.py`'s tail check fits an exponential to the top 50 write-back starts and release gates of your
13,457,612 records. The write-back start decays by a factor e every 30.5 cycles above 923; the release gate every 30.6
cycles above 1,954. Expected misses per 20M accesses:

| Margin | AR_WB_H | AR_REL_H | Deadline (1) | Deadline (2) | P(a 20M run halts) |
|---|---|---|---|---|---|
| 5% | 1,176 | 2,332 | 0.018 | 0.0003 | 1.8% |
| **10% (v14c)** | **1,228** | **2,384** | **0.0033** | **0.00006** | **0.3%** |
| 15% | 1,281 | 2,465 | 0.0006 | 0.000004 | 0.06% |
| 20% | 1,333 | 2,569 | 0.0001 | 0.0000001 | 0.01% |

An expected 0.01 halts per 20M accesses, a 1% chance, needs only AR_WB_H 1,195 and AR_REL_H 2,351. 10% clears that
with about a 3× lower risk.

Two cross-checks:

- The stash-ready tail falls 3.4×, 6.7× and 13× over its last three 100-cycle steps. It decays faster and faster, i.e. lighter than the exponential the check assumes, so the check is cautious.
- The maximum grew only 18 cycles (776 → 794) between 2.46M and 13.46M accesses, while 10% leaves 179 cycles above the worst write-back start.

An estimate from the stash-ready times alone, which assumes every tail access also takes the slowest decisions ever
seen, gives up to 0.11 per 20M. That over-counts: the write-back start's own tail, fitted above, already contains the
real decision times.

**Fallback.** If a validation run halts anyway, use 20% on the write-back start, with the release set to AR_WB_H plus
the worst write (1,156): AR_WB_H 1,333, AR_REL_H 2,489, AR_DONE_H 2,923. That costs 105 cycles per on-package
access, about 2.5% per request at 100% on package. The write's own spread is small (W held at most 1 cycle, starved
4), so this protects deadline (2) as well as the script's 20% (1,333 / 2,569 / 3,003) does. The fallback is not in the
package; the validation plan (§5) says when to switch.

**One risk the records do not cover: temperature.** HBM refreshes twice as often above 85 °C, and the calibration
runs did not record the HBM temperature. The validation plan includes a hot run.

## 3. All sizes (32 B – 2 KB, λ = 7)

`vitis/calibrate_all_sizes.sh` runs the 4 KB method for sizes 1, 2, 4, 8, 16, 32 and 64 beats, as one batch. Each
size gets its own copy of `rtl/` and `vitis/` under `cal/b<beats>/`, so builds run in parallel and the production
tree is untouched until `write`. Everything is printed as text and kept in `cal/report.txt`.

```bash
cd vitis
JOBS=2 NMAX=<n> bash calibrate_all_sizes.sh build        # 7 debug bitstreams, 2 at once (progress: ../cal/progress.log)
bash calibrate_all_sizes.sh timing                        # each bitstream's kernel clock (check_timing.sh)
DOMA_N=<n> ACC=2097152 bash calibrate_all_sizes.sh run    # 100% and 20% on package per size, per-access records
bash calibrate_all_sizes.sh report                        # card_budgets.py per size, summary table, define lines
bash calibrate_all_sizes.sh write                         # writes the defines into rtl/oram_params.vh
#   or: bash calibrate_all_sizes.sh all   (build, timing, run, report); SIZES as arguments, e.g. ... report 8 16
```

- **Settings:** per-size overrides as `NMAX_<beats>`, `DOMA_N_<beats>` and `DOMA_POOL_<beats>`. `CFG` is the production `.cfg`; the stash must sit where production puts it. `PCT` (default 10) and `ABS` (74) set the margin.
- **Report:** for each size, the full `card_budgets.py` output, with the 10% budgets, the tail check and the define lines. Then one table: size, clock, accesses, worst write-back start and release gate, card budgets, final budgets (never below the current values), cycles earlier than v11g, and expected halts per 20M.
- **Warning:** a size whose on-package release would come later than v11g's encrypted path is flagged before anything is written.

`card_budgets.py` was rewritten to stream: histograms plus the slowest N accesses, constant memory. With numpy it reads
1.4M records in 4 s on this machine; without numpy it falls back to pure Python, with identical output. It adds:

- the survival tables of stash ready, write-back start, release gate and open duration, in 50- or 100-cycle steps;
- the budgets at 0, 5, 10, 15 and 20%;
- the tail check: an exponential fit to the top 50 values, the expected misses per 20M accesses at each margin, and the budget for an expected 0.01;
- a `SUMMARY` line for scripts, and `--define-only`.

The default margin is now 10%.

## 4. host_ycsb: your additions

`vitis/host_ycsb.cpp` is your file (md5 0d156472accb…, CR line ends stripped) with two v14c changes:

- the v14b refusal of debug bitstreams;
- `fclose` of the slow-request dump.

It has the per-request latency distributions, the GET-vs-PUT Kolmogorov–Smirnov test, `DOMA_LAT_HIST` and
`DOMA_SLOW_DUMP` / `DOMA_SLOW_CYC`. In the mock (λ = 7, N = 4,096, 100% on package) it ran clean:

- latency 3,995 cycles;
- KS: "same distribution";
- the histogram and slow-request files written.

## 5. Deliverables, regression, validation on the card

**Package:** `fpga_zcu208_deploy_v14c.zip`, with `patches/fpga_v14c_card_budgets.patch` against v14b.

Changed files:

- `rtl/`:
  - `oram_params.vh`: the 4 KB budgets;
  - `flat_oram_gcm.v`, `stash_hbm.v`, `secure_oram_top.v`, `doma_kernel.v`: the debug-only stash records.
- `vitis/`:
  - `doma_debug.h`, `host_phases.cpp`: 128-byte records;
  - `host_ycsb.cpp`: your additions;
  - `calibrate_all_sizes.sh`: new.
- `sim/`:
  - `card_budgets.py`;
  - `stash_open_model.py`: new, the option table of §1.3;
  - `tb_doma_kernel.v`: the stash-record checks;
  - `run_verilator.sh`: the slow-stash tests pick a latency the budgets cannot absorb.
- `docs/`: this report, `v14c_regression_lambda7.txt`, and updates to `v14b_card_calibration.md` and `README_FPGA.md`.

**Regression, λ = 7, every block size:** 880 PASS, 0 FAIL (`docs/v14c_regression_lambda7.txt`): every group at
every size, 32–256 B on your laptop and 512 B–4 KB here, plus `onpkg` and `lint` on the final sources at every size.

- **Below 4 KB:** every run is identical to v14b's on every result line (88 runs per size).
- **At 4 KB:** every on-package release and end moves by exactly +446 cycles, and every off-package access shape is unchanged. Launch cycles, the host bucket-port gap hash and the debug maxima follow from that.

Two things changed in the tests:

- The 4 KB on-package budgets now absorb a 600-cycle stash. The two checks that force a stash overrun therefore use the first of 600 / 800 / 1,000 / 1,200 cycles that the budgets cannot absorb: 800 at 4 KB.
- 4 KB on-package release offsets move by +446 cycles against v14b, by design. Every off-package observable is unchanged.

**Validation on the card (production 4 KB bitstream: `LAMBDA=7 SCHED=arrival`, no DEBUG, no TRACE):**

1. **Timing:** `check_timing.sh` reports 300 MHz.
2. **20M accesses at 100% on package and 20M at 20%** (`host_phases`, `DOMA_PHASES=mix:20000000`, production `DOMA_N` / `DOMA_POOL`). Pass: errors 0x0 in both, no halt record.
   - Expected cycles per request, from the interim's measurements (release 154 cycles earlier): about 4,198 at 100% (interim 4,352.1, v13 4,953.1) and about 4,998 at 20% (interim 5,028.8).
3. **Hot run:** repeat the 100% run back to back with `xbutil examine -r thermal` (or `xrt-smi`) logged before and after. Report the HBM temperature. If it exceeds 85 °C and the run passes, the margin holds at the doubled refresh rate.
4. **YCSB** with the new `host_ycsb` (workloads as before):
   - the per-request distributions;
   - the KS line (GET vs PUT expected "same distribution");
   - `DOMA_LAT_HIST=hist.csv`;
   - `DOMA_SLOW_DUMP=slow.txt` with the default `DOMA_SLOW_CYC=5400`; send its line count.
5. **If any run halts:** send the host's decoded halt record (deadline, missed by). Rebuild with the 20% variant of §2 (`ORAM_AR_WB_H_L7_B128 1333`, `ORAM_AR_REL_H_L7_B128 2489`, `ORAM_AR_DONE_H_L7_B128 2923`) and rerun steps 2–4.

After step 2 passes, 4 KB is final. The other sizes follow `calibrate_all_sizes.sh`. Any stash-tail change from §1.3
would be a later version, with its own calibration.
