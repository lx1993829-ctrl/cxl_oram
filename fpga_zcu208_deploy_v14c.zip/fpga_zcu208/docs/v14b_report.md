# v14b: the card's on-package halts — cause, records, calibration, timing

**What happened.** On the U55C, at 4 KB and λ = 7, the v14 bitstream (295 MHz) ran correctly at 0% on package. At
100% and at 20% on package it halted with 0x108 during the preload, and every later command was refused.

**Short answer.** The halts are on-package budget overruns, not a protocol stall.

- The eviction decisions of a plaintext on-package access wait for the stash open.
- v14 budgeted them from a simulation in which the stash is ready when the bucket arrives.
- A slower stash port reproduces both of the card's halt records in simulation.
- v14b leaves the datapath and budgets as they were. It adds what is needed to set the budgets from the card itself:
  - a halt record that names the deadline and the cycles missed;
  - a debug build that records overruns instead of halting, with per-access records;
  - `card_budgets.py`, which turns those records into budgets.
  - interim budgets (`build.sh INTERIM=1`, 4 KB, λ = 7) that cover stash reads of up to 500 cycles, for running on the card until the calibration.
- It also fixes the two 300 MHz paths.
- In simulation it is cycle-for-cycle identical to v14.

## 1. Which deadline fired

| Run | Halt record | Deadline |
|---|---|---|
| 100% on package | state 24 (S_RES_STREAM), access cycle 3,311, bucket 7,842, no unit error | **(1)**, the write-back start. At the release check (`t_arr + 1938`) the write had been handed off, so the overrun was `byp_ov`. In v14 that flag was set by deadline (1) or by a scratch bank conflict; no simulation has ever shown a conflict. v14b's record tells the two apart (code 01 vs 11). |
| 20% on package | state 22 (S_DDR_WRITE), access cycle 3,417, bucket 22,573 | **(2)**, the hand-off. The write was still being sent at the release time. |

Both access cycles equal `t_arr + AR_REL_H + 1`: the record is latched one cycle after the release check. The
deadline fired; nothing stalled. The latency fields reported as "2,007,748" and "5,778,868" are encoded halt
records, not latencies.

## 2. What the write-back waits for on real HBM

On the plaintext path:

1. The access reaches `S_SCAN` once the bucket and its record are in.
2. It leaves `S_SCAN` only when the stash is ready (`st_ready`). The stash open, issued at the position lookup, has then read the bucket's stash window: lists, metadata and up to a window of 4 KB blocks from HBM[12].
3. The eviction decisions follow, and the write-back is issued at `S_EA_START`.

In the memory models the open is ready a few cycles after a 4 KB bucket arrives. The worst write-back start is 283–295
cycles after the arrival, and 729–730 with every HBM read at 200 cycles. v14's AR_WB_H = 855 rests on that.

In v11g and v13 the same wait sat behind the decryption pass and re-encryption, under an AR_WB_H of 2,025, which is
why v13 runs on the card. v14 removed the crypto, so the stash open became the critical path.

The suspects, checked against the controller and against the HBM controller and SmartConnect behaviour:

- **W held mid-burst while a copy is pending.** This is by design on the plaintext path (`axim_wdata_hold`), and it is not an overrun. The copies come from on-chip staging at one beat per cycle. At 100% the write was handed off in time, so this cannot be the 100% cause. At 20% the debug record separates "W held by the HBM" from "no W offered (waiting for copies)".
- **The HBM controller holding a read behind an unfinished write.** Modelled (`+hbm_like=W`: B when the data is queued, landing W cycles later, reads held behind the writes accepted before them). At W = 300 the worst write-back start (295) and release gate (1,324) are unchanged. The stash's commit writes, and the bucket's write-back acknowledgements, are long done before the next access opens the stash or reads its bucket. `axi_master` already holds a bucket read until every B is in, and on package a late bucket read moves `t_arr`, which the deadlines follow, so it is not an overrun.
- **SmartConnect or HBM refusing W before its AW.** Modelled (`w_lead = 0`). No deadlock and no change: `axi_master` issues the address first.
- **The deferred bank-conflict path** (flat_oram_gcm.v around line 980). The conflict flag is sticky and, on package, raises `byp_ov` like deadline (1), so v14's record could not tell them apart. v14b's can. The debug build counts conflicts cycle by cycle (`bank_clash_now`). None has been seen in any simulation.

## 3. Memory models, and a simulation that reproduces it

`axi_mem_model.v` has three new options, off by default, so every existing run is unchanged:

- `b_early`
- `rd_wait_wr`
- `w_lead`

The testbench also gains:

- `+hbm_like=W`, which sets all three on every HBM port;
- `+stash_gap=P`, read gaps on the stash port only;
- `+stash_slow=L +stash_slow_at=K`, slow stash reads from access K on, leaving the boot untouched;
- `+halt_wait=N`.

Production RTL, 4 KB, λ = 7, preload, 100% on package unless noted (`sim/repro_card_halt.sh`):

| Stash port | Result |
|---|---|
| as before (53 cycles) | no halt |
| every read 350 cycles | **state 24, deadline (1)**: write-back issued 882 cycles after the arrival, missed by 27; handed off in time |
| every read 450 cycles | **state 22, deadline (2)**: release gate reached 1,968 after the arrival, missed by 30 |
| read beats on 60% of cycles | **state 22, deadline (2)**: release gate 2,069, missed by 131 |
| 20% on package, every read 600 cycles | **state 22, deadline (2)**: write-back issued 977, release gate 2,006, missed by 68 (the card's 20% halt) |

The debug build on the same 350-cycle stash runs every access without halting and shows:

- the stash ready up to 597 cycles after the arrival (it was 3 before);
- one deadline (1) miss among 716 accesses;
- the first-overrun snapshot in state 12, 855 cycles after the arrival, 0 copy beats landed.

A miss is a tail event. It comes from the accesses whose stash window is largest. In the card's preload it happened
early, so the card's stash port is slower than the model by a wide margin. Only the card can say by how much. That is
what the debug build measures.

## 3a. The fix: card budgets, and interim budgets until then

**The fix.** Set AR_WB_H and AR_REL_H from the card's worst case plus margin (docs/v14b_card_calibration.md). The
models now reproduce the halt, but the right budget needs the card's numbers. The flow is:

1. Build the debug bitstream.
2. Run at least 1M accesses at 100% and at 20% on package.
3. Run `sim/card_budgets.py`.
4. Rebuild with the new defaults.

**Until then: `build.sh INTERIM=1`** (4 KB, λ = 7 only). It sets AR_WB_H 1,455, AR_REL_H 2,538 and AR_DONE_H 2,972,
in place of 855 / 1,938 / 2,372.

- These cover every stash and bucket-record read taking up to 500 cycles. The cycle model on the directed worst cases at that profile gives a write-back start of 1,381 and a release gate of 2,410 after the arrival, with v14's margins added.
- An on-package access then releases 603 cycles earlier than v11g, half of the saving. It takes 4,157 cycles at 100% on package in simulation, against 3,557 with v14's budgets.
- Checked in simulation (production build):
  - no overrun with 500-cycle stash and record reads, at 100% and 20% on package and in the directed worst cases (worst 1,378 / 2,407);
  - release and end the same across stash histories and speeds;
  - halts at exactly `t_arr + 2,538` beyond the bound, with the deadline named;
  - identical to the default build at 0% on package.

## 4. Halt record and debug summary fields

Every build's halt record adds:

- **[33:32]** the on-package deadline: 01 write-back start, 10 hand-off, 11 bank conflict.
- **[31:20]** the cycles it was missed by. This counter keeps running until the late event happens, so a later launch's summary has the final value.
- **[16]** "lower bound": set when the late event had not yet happened as the record was written.

`host_doma` and `host_phases` decode the record from any halted launch, the first and the last. Previously only the
boot's was decoded.

The debug build (`build.sh DEBUG=1 TRACE=1`) records and counts an on-package overrun and does not halt. It writes:

- **[n+2]:** counters since boot (accesses, misses of each deadline and the worst miss of each, bank conflicts, worst write-back start, release gate and stash ready after the arrival).
- **[n+3]:** the first on-package overrun, latched as it fires:
  - which deadline, FSM state, access number, access cycle, cycles since the arrival;
  - cycles missed (final at the access's end);
  - copy beats landed, copies done and queued, the pending-copy mask, bucket beats written;
  - on the bucket port and on the stash port: AW without data, bursts awaiting B, reads outstanding, and the valid-ready levels.
- **[n+4]:** the first deadline (2) miss, in the same layout.
- **A 64-byte trace record per command:** the phase timestamps, then the controller's own 16 timestamps for its access. `host_phases` turns these into p50 / p99 / p99.9 / p99.99 / max per phase and a CSV.

In simulation every record equals the testbench's own timestamps of the same events (408 per run in the regression
test), and the counters and snapshots match their tally. The calibration flow, from `host_phases` through the CSV
to `card_budgets.py`, ran end to end through the mock XRT.

## 5. Timing (300 MHz)

| Path (v14, Vivado) | Cause | v14b |
|---|---|---|
| `u_aes_gcm/iv_lfsr_reg[4]` → `iv_lfsr_reg[0..1]`, 11 levels, −0.093 ns | The 96-step LFSR advance, written as a 96-iteration loop, feeds the LFSR's own input through its update mux. It was added to the IV path by v14's IV advance. | The advance is registered (`lfsr_advanced`), one cycle behind `iv_lfsr`; every use comes at least two cycles after `iv_lfsr` last changed (a simulation check at each use). It is also written as one XOR per output bit (at most 44 inputs: three LUT levels when balanced). It equals the loop on 100,096 states (`tb_lfsr96.v`). The IV-advance and two-lane GCM tests are unchanged. |
| `u_stash/g_used_reg[10]_replica` → `td_reg[1][*]`, 12 levels, −0.096 ns | The logic is unchanged since v11g: `stash_hbm.v` in v14 is byte-identical to v11g's (v14's base). v14 did not change the path; it only crowded it. | The free staging-slot search (`g_used` → `fg`) is registered. `g_used` never changes in the cycle before an insert, and a `$fatal` check at every insert ensures it. The stash unit tests pass, including 150,000–200,000-access runs. |

Both changes are cycle-neutral: every v14b regression run is identical to v14's (section 6).

## 6. Regression

λ = 7, every group at every block size (docs/v14b_regression_lambda7.txt): 120 groups, 776 checks, all passed. 512 B–4 KB ran
on the cloud machine, 32 B–256 B on the laptop.

**Comparison with v14** (`sim/compare_v14.py`, every result line of every run against v14's own regression logs):

- **512 B–4 KB:** 83 runs per size identical on every line. That covers boot, cycles, latencies, timing hashes, per-access shapes, on-package release/end hashes, traffic, bucket-write digests and calibration maxima.
- **New runs:** the LFSR equivalence test, the halt-record tests and the debug-build tests.
- **32 B–256 B:** the laptop's v14b logs match v14's on 69 runs per size. The 14 tb_ni runs (ni, bp, worst, combined, hostwait, secure, stress) differ by one cycle from the start: "ORAM ready after 550,880" against 550,881.

  The same runs, rebuilt and rerun on the cloud machine with v14's RTL and with v14b's, are identical to each other, and to the laptop's v14b logs. This is the laptop simulator's testbench race already recorded for v14 (docs/v14_regression_lambda7.txt, recheck), which there resolved in the other direction.
  At both 256 B and 32 B, all 16 tb_ni runs are identical across cloud v14, cloud v14b and laptop v14b.

**After the regression:** the final sources add the `INTERIM=1` option, its check (onpkg (h)) and a testbench print fix. Their onpkg and lint groups at 4 KB pass, and every run is again identical to v14's.

## 7. Files

**RTL**
- `flat_oram_gcm.v`: deadline wires, the halt record's new fields, the debug block.
- `scratch_buf.v`: `bank_clash_now`.
- `secure_oram_top.v`, `doma_kernel.v`: debug records and 64-byte trace records.
- `aes_gcm_2lane.v`, `stash_hbm.v`: timing.
- `oram_params.vh`: the interim budgets (`ORAM_ONPKG_INTERIM`).

**Hosts**
- `vitis/doma_debug.h` (new).
- `host_doma.cpp`, `host_phases.cpp`.
- `build.sh`: `DEBUG=1`, `INTERIM=1`.

**Simulation**
- `tb_doma_kernel.v`, `axi_mem_model.v`, `run_verilator.sh` (onpkg (f), (g), (h); lint of the debug build; crypto: `tb_lfsr96.v`).
- New: `card_budgets.py`, `repro_card_halt.sh`, `compare_v14.py`.
- `xrt_mock/`: `DEBUG=1`, `MOCK_STASH_LAT`.

**Docs**
- `v14b_card_calibration.md` (the method), this report, the regression log, and v14b sections in `README_FPGA.md` and `README_SIM.md`.
