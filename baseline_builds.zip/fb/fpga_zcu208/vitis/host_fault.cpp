// host_fault.cpp -- DOMA test plan Part B (fault injection), P0-P9, on build B (build.sh FAULT=1, v14d).
// Every result is printed as terminal text: a line per test while it runs, then the results table of Part B
// section 6 (and, with --csv, one CSV line per trial on stdout, prefixed "CSV,").
//
// Usage: ./host_fault <xclbin> [TESTS] [--scale F] [--seed S] [--csv] [--stash ACC] [--hs W,BASE] [--verbose]
//   TESTS    comma-separated: P0,P1,P2,P3,P4,P5,P6,P7,P8,P9 or all (default: all)
//   --scale  multiplies every trial count (1 = the plan's counts; 0.01 for a quick pass, e.g. in the mock)
//   --seed   the host's random seed (default 1); every trial prints its own seed with --csv
//   --stash  Part A item 12: ACC uniform accesses on one boot, then the stash occupancy maximum and histogram
//   --hs     the histogram: bin width 2^W, first bin's lower edge BASE (default: around the boot occupancy)
// Environment: DOMA_N (records, default 16384), DOMA_LAMBDA (default 7), DOMA_HBM_PCT (default 20; the share of
//   buckets on package), DOMA_POOL (stash pool, default Claim 1's bound + 1), DOMA_BATCH (commands per launch in
//   the long runs, default 1000).
// Build B differs from build A (the release build) only by the test hooks and counters (docs/v14d_fault_build.md):
// with every hook disarmed it is cycle-identical to v14c. Its kernel takes 11 more scalar arguments (the fault
// registers, offsets 0x84 .. 0xD4) and writes two more records, [n+2] (stash statistics) and [n+3] (observation).
#include <xrt/xrt_bo.h>
#include <xrt/xrt_device.h>
#include <xrt/xrt_kernel.h>
#include <algorithm>
#include <atomic>
#include <cctype>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <map>
#include <random>
#include <set>
#include <string>
#include <thread>
#include <vector>
#include "doma_debug.h"

// ---------------- configuration (must match the bitstream) ----------------
static uint32_t LAMBDA = 7;                        // build.sh LAMBDA (checked against the summary)
static const uint32_t ZPOS = 8;                    // rtl/oram_params.vh ORAM_Z
static const size_t BLOCK = 4096, BEATS = 128;     // build B is built for 4 KB blocks (checked)
static const size_t STRIDE = ZPOS * BLOCK;         // one bucket, compact layout
static const uint32_t BKT_BEATS = ZPOS * BEATS;    // 1024 beats per bucket
static const uint32_t CMD_TIMEOUT = 2000000;       // rtl/doma_kernel.v: cycles a command may wait
static uint32_t NBLK = 16384, NB = 0, HBMK = 0, POOL_DEF = 0, POOL_MAX = 0;
static unsigned HBM_PCT = 20;
static const uint8_t T_GET = 1, T_PUT = 2, T_ACK = 0x10, T_ERR = 0x11, T_SUM = 0x5A, CANARY = 0xA5;

// flt_ctl bits (docs/v14d_fault_build.md)
enum : uint32_t { F_P3 = 1, F_P5 = 2, F_P6 = 4, F_P8 = 8, F_P1 = 16, F_P7 = 32, F_P8_HBM = 0x100, F_P1_ALL = 0x1000 };
struct FaultArgs { uint32_t ctl = 0, cmd = 0, p5 = 0, p6 = 0, p8 = 0, p3 = 0, p1k = 0, p1b = 0, p7x = 0, hs = 0, p6n = 0; };

static size_t roundup4k(size_t x) { return (x + 4095) & ~size_t(4095); }
static double SCALE = 1.0; static bool CSV = false, VERBOSE = false; static uint64_t SEED = 1;
static int cnt(double plan) { return std::max(1, int(std::lround(plan * SCALE))); }

// ---------------- stash bound (host_doma.cpp, Claim 1) ----------------
static double ln_mgf_A(double t, double Bk, double n) {
    const double p = 1.0 / Bk, lr = std::log1p(-p) + t;
    if (std::fabs(lr) < 1e-15) return std::log(p * n + 1.0);
    if (lr > 0) { const double lrn = n * lr; if (lrn > 700) return INFINITY;
                  return std::log(p * std::expm1(lrn) / std::expm1(lr) + std::exp(lrn)); }
    const double rn = std::exp(n * lr);
    return std::log(p * (1 - rn) / (-std::expm1(lr)) + rn);
}
static double stash_xR(double Bk, double n, double lg) {
    double best = INFINITY;
    for (int i = 1; i < 400; i++) { const double u = i * 0.005, v = ln_mgf_A(std::expm1(u) / Bk, Bk, n);
        if (!std::isfinite(v)) break; best = std::min(best, (Bk * v + lg) / u); }
    return best;
}
static double stash_xO(double Bk, double n, int Z, double lg) {
    double best = INFINITY; std::vector<double> lt(160); const double p = 1.0 / Bk, lp = std::log(p), lq = std::log1p(-p);
    for (int i = 1; i < 400; i++) { const double u = i * 0.01; double mx = -INFINITY, sum = 0;
        for (int k = 0; k < 160; k++) { lt[k] = std::lgamma(n + 1) - std::lgamma(k + 1.0) - std::lgamma(n - k + 1) + k * lp + (n - k) * lq
                                                + u * std::max(0, k - Z); mx = std::max(mx, lt[k]); }
        for (int k = 0; k < 160; k++) sum += std::exp(lt[k] - mx);
        best = std::min(best, (Bk * (mx + std::log(sum)) + lg) / u); }
    return best;
}
static double stash_bound(double n, double lam, int Z) {
    const double Bk = std::ceil(n / lam), G = 64 * std::log(2.0);
    double best = INFINITY;
    for (double f : {0.1, 0.3, 0.5, 0.7, 0.9})
        best = std::min(best, stash_xR(Bk, n, G - std::log(f)) + stash_xO(Bk, n, int(Z), G - std::log(1 - f)));
    return best;
}

// ---------------- the kernel, its buffers and one launch ----------------
struct Cmd { uint8_t type; uint32_t key, off = 0, len = 0; uint32_t exp_status = 0; };
struct Hdr { uint8_t type; uint32_t key, lat, status; bool answered; };
struct Summary { bool ok = false; uint32_t lam = 0, beats = 0, dbg = 0, lat_min = 0, lat_max = 0, errors = 0, done = 0;
                 uint64_t total = 0, rd = 0, wr = 0; };
struct StashRec { bool valid = false; uint8_t fired = 0; uint32_t p1n = 0, occ = 0, bmax = 0, lmax = 0, hist[8] = {0}; };
struct Obs { bool valid = false; uint8_t flags = 0, kst = 0; uint32_t hacc = 0, hcyc = 0, h_w = 0, h_aw = 0, h_rv = 0,
             p_aw = 0, p_w = 0, p_rv = 0, p_kd = 0, ov = 0, tok = 0, tfail = 0, nrel = 0; };
// h_rv / p_rv: DOMA's result beats to the kernel (inside the card; the kernel writes nothing out after a halt);
// p_kd: response-data beats the kernel wrote to the host after the halt (must be 0)
struct Launch { Summary s; StashRec st; Obs o; std::vector<Hdr> h; int mism = 0, unanswered = 0, canary_bad = 0;
                std::vector<int> wrong_keys; };

static xrt::device* g_dev; static xrt::kernel* g_k;
static xrt::bo b_cmd, b_resp, b_pages, b_meta, b_brec, b_stash, b_hbm;
static size_t MAXC = 0;
static int done_(int rc) { b_cmd = xrt::bo(); b_resp = xrt::bo(); b_pages = xrt::bo(); b_meta = xrt::bo(); b_brec = xrt::bo();
                           b_stash = xrt::bo(); b_hbm = xrt::bo(); return rc; }   // the buffers go before the device                                 // commands per launch (buffer capacity)
static uint32_t cur_pool = 0;
static std::vector<uint32_t> refv;                      // the reference model: each block's version (0: zeros since boot)
static uint32_t ver_next = 1;
static std::mt19937_64 rng;

static void pattern(uint32_t key, uint32_t ver, uint8_t* p) {   // a block's content for (key, version); version 0: zeros
    if (ver == 0) { std::memset(p, 0, BLOCK); return; }
    uint64_t x = (uint64_t(key) << 32 | ver) * 0x9E3779B97F4A7C15ull ^ 0xD1B54A32D192ED03ull;
    for (size_t i = 0; i < BLOCK; i += 8) { x ^= x << 13; x ^= x >> 7; x ^= x << 17; std::memcpy(p + i, &x, 8); }
}
static uint64_t bits(const uint8_t* r, unsigned lo, unsigned w) {   // a little-endian bit field of a 32-byte record
    uint64_t v = 0; for (unsigned i = 0; i < w; i++) { unsigned b = lo + i; v |= uint64_t((r[b / 8] >> (b % 8)) & 1) << i; } return v;
}
static bool fits(size_t n) { return ((n + 2) % 128) != 0 && ((n + 2) % 128) != 127; }   // records [n+2], [n+3] written

// one launch: n commands (n = 0: boot / re-boot), the fault registers, the canary, every check against the reference
static Launch launch(const std::vector<Cmd>& c, const FaultArgs& fa, uint32_t pool = 0) {
    const size_t n = c.size();
    if (n > MAXC) { std::printf("internal: %zu commands exceed the buffers (%zu)\n", n, MAXC); std::exit(2); }
    if (n && !fits(n)) { std::printf("internal: %zu commands leave no room for records [n+2], [n+3]\n", n); std::exit(2); }
    const size_t hc = roundup4k(n * 32), hr = roundup4k(n * 32 + 64);
    if (n) {
        auto p = b_cmd.map<uint8_t*>(); std::memset(p, 0, hc + n * BLOCK);
        for (size_t i = 0; i < n; i++) {
            p[i * 32] = c[i].type; std::memcpy(p + i * 32 + 4, &c[i].key, 4);
            std::memcpy(p + i * 32 + 8, &c[i].off, 4); std::memcpy(p + i * 32 + 12, &c[i].len, 4);
            if (c[i].type == T_PUT && c[i].exp_status == 0) pattern(c[i].key, ver_next + uint32_t(i), p + hc + i * BLOCK);
        }
        b_cmd.sync(XCL_BO_SYNC_BO_TO_DEVICE, hc + n * BLOCK, 0);
    }
    {   // the canary: every header, record and data slot of this launch
        auto r = b_resp.map<uint8_t*>(); const size_t span = std::max(hr + n * BLOCK, size_t(4096));
        std::memset(r, CANARY, span); b_resp.sync(XCL_BO_SYNC_BO_TO_DEVICE, span, 0);
    }
    if (pool) cur_pool = pool;
    auto run = (*g_k)(b_cmd, b_resp, b_pages, uint32_t(n), b_meta, b_brec, b_stash, NBLK, b_hbm, HBMK, cur_pool,
                      fa.ctl, fa.cmd, fa.p5, fa.p6, fa.p8, fa.p3, fa.p1k, fa.p1b, fa.p7x, fa.hs, fa.p6n);
    run.wait();
    Launch L;
    const size_t span = std::max(hr + n * BLOCK, (n + 4) * size_t(32));
    b_resp.sync(XCL_BO_SYNC_BO_FROM_DEVICE, span, 0);
    auto r = b_resp.map<uint8_t*>();
    const uint8_t* s = r + n * 32;
    L.s.ok = (s[0] == T_SUM); L.s.lam = s[1] ? s[1] : 6; L.s.dbg = s[2]; L.s.beats = rd32(s + 4);
    std::memcpy(&L.s.total, s + 8, 8); L.s.lat_min = rd32(s + 16); L.s.lat_max = rd32(s + 20);
    L.s.errors = rd32(s + 24); L.s.done = rd32(s + 28);
    if (s[32] == 0x5B) { std::memcpy(&L.s.rd, s + 40, 8); std::memcpy(&L.s.wr, s + 48, 8); }
    const uint8_t* q = s + 64;                                  // [n+2]
    if ((L.s.dbg & 0x20) && q[0] == 0x5F) {
        L.st.valid = true; L.st.fired = q[1]; L.st.p1n = rd16(q + 2);
        L.st.occ = uint32_t(bits(q, 32, 24)); L.st.bmax = uint32_t(bits(q, 56, 24)); L.st.lmax = uint32_t(bits(q, 80, 24));
        for (int k = 0; k < 8; k++) L.st.hist[k] = uint32_t(bits(q, 104 + 19 * k, 19));
    }
    const uint8_t* o = s + 96;                                  // [n+3]
    if ((L.s.dbg & 0x40) && o[0] == 0x60) {
        L.o.valid = true; L.o.flags = o[1]; L.o.kst = o[2] & 63; L.o.p_kd = o[3]; L.o.hacc = rd32(o + 4); L.o.hcyc = rd32(o + 8);
        L.o.h_w = rd16(o + 12); L.o.h_aw = o[14]; L.o.h_rv = o[15]; L.o.p_aw = rd16(o + 16); L.o.p_w = rd16(o + 18);
        L.o.p_rv = rd16(o + 20); L.o.ov = rd16(o + 22); L.o.tok = uint32_t(bits(o, 192, 24)); L.o.tfail = o[27]; L.o.nrel = rd32(o + 28);
    }
    // every command: header, status, data against the reference (and the canary of unanswered / halted commands)
    std::vector<uint8_t> want(BLOCK);
    for (size_t i = 0; i < n; i++) {
        const uint8_t* h = r + i * 32; Hdr x{h[0], rd32(h + 4), rd32(h + 8), rd32(h + 12), true};
        const uint8_t* d = r + hr + i * BLOCK;
        bool can = true; for (size_t b = 0; b < BLOCK; b++) if (d[b] != CANARY) { can = false; break; }
        if (h[0] == CANARY && h[1] == CANARY) { x.answered = false; L.unanswered++; if (!can) L.canary_bad++; L.h.push_back(x); continue; }
        if (x.status == 0x8 || x.status == 0x10) { if (!can) L.canary_bad++; L.h.push_back(x); continue; }   // halted / timed out
        if (c[i].exp_status) { if (x.type != T_ERR || x.status != c[i].exp_status) L.mism++; L.h.push_back(x); continue; }
        if (x.type != T_ACK || x.key != c[i].key || x.status != 0) { L.mism++; L.h.push_back(x); continue; }
        if (c[i].type == T_PUT) refv[c[i].key] = ver_next + uint32_t(i);
        else { pattern(c[i].key, refv[c[i].key], want.data());
               if (std::memcmp(d, want.data(), BLOCK) != 0) { L.mism++; L.wrong_keys.push_back(int(c[i].key)); } }
        L.h.push_back(x);
    }
    ver_next += uint32_t(n) + 1;
    return L;
}
static FaultArgs NOF;
static uint32_t boot_occ = 0;
static bool boot(uint32_t pool = 0) {             // a fresh boot: new layout, every block zeros
    Launch L = launch({}, NOF, pool ? pool : POOL_DEF);
    std::fill(refv.begin(), refv.end(), 0u);
    if (!L.s.ok) { std::printf("boot: no summary record\n"); return false; }
    boot_occ = L.st.occ;
    if (L.s.errors) { if (VERBOSE) std::printf("boot (pool %u): errors 0x%x\n", cur_pool, L.s.errors); return false; }
    return true;
}
static uint64_t halt_rec(const Summary& s) { return (uint64_t(s.lat_max) << 32) | s.lat_min; }
static uint64_t halt_bucket(const Summary& s) { return halt_rec(s) >> 40; }
static unsigned halt_code(const Summary& s) { return unsigned(halt_rec(s) >> 32) & 3; }
static bool halt_hbm(const Summary& s) { return (halt_rec(s) >> 34) & 1; }

// buckets: on package 1 .. HBMK-1 (bucket 0 cannot be a steering target), off package max(HBMK, 1) .. NB-1
static uint32_t rnd(uint64_t n) { return uint32_t(rng() % n); }
static uint32_t pick_off() { const uint32_t lo = std::max<uint32_t>(HBMK, 1); return lo + rnd(NB - lo); }
static uint32_t pick_on() { return 1 + rnd(HBMK - 1); }
static uint8_t* hostb(uint32_t j) { return b_pages.map<uint8_t*>() + size_t(j - HBMK) * STRIDE; }   // host bucket j
static std::vector<uint8_t> snap(uint32_t j) { const uint8_t* p = hostb(j); return {p, p + STRIDE}; }
static void put_host(uint32_t j, const std::vector<uint8_t>& v) { std::memcpy(hostb(j), v.data(), STRIDE); b_pages.sync(XCL_BO_SYNC_BO_TO_DEVICE); }
static std::vector<uint8_t> get_hbm(uint32_t j) {
    b_hbm.sync(XCL_BO_SYNC_BO_FROM_DEVICE, STRIDE, size_t(j) * STRIDE);
    const uint8_t* p = b_hbm.map<uint8_t*>() + size_t(j) * STRIDE; return {p, p + STRIDE};
}
static void put_hbm(uint32_t j, const std::vector<uint8_t>& v) {
    std::memcpy(b_hbm.map<uint8_t*>() + size_t(j) * STRIDE, v.data(), STRIDE);
    b_hbm.sync(XCL_BO_SYNC_BO_TO_DEVICE, STRIDE, size_t(j) * STRIDE);
}
static uint32_t rkey() { return rnd(NBLK); }
static Cmd get_(uint32_t k) { return Cmd{T_GET, k}; }
static Cmd put_(uint32_t k) { return Cmd{T_PUT, k}; }
static std::vector<Cmd> uniform(size_t n) {
    std::vector<Cmd> v; for (size_t i = 0; i < n; i++) v.push_back((rng() & 1) ? put_(rkey()) : get_(rkey())); return v;
}
static size_t fitn(size_t n) { while (n > 1 && !fits(n)) n--; return n; }
// P1 steering: the next access to block k takes bucket j as its new bucket (a PUT, so k holds fresh data)
static bool steer(uint32_t k, uint32_t j) {
    FaultArgs fa; fa.ctl = F_P1; fa.p1k = k; fa.p1b = j;
    Launch L = launch({put_(k)}, fa);
    const bool ok = !L.s.errors && L.mism == 0 && L.st.valid && (L.st.fired & 0x10) && L.st.p1n == 1;
    if (!ok) std::printf("steer: block %u to bucket %u failed (errors 0x%x, mismatches %d, fired 0x%02x, overrides %u)\n",
                         k, j, L.s.errors, L.mism, L.st.fired, L.st.p1n);
    return ok;
}
static void settle(int ms = 10) { std::this_thread::sleep_for(std::chrono::milliseconds(ms)); }

// ---------------- results ----------------
struct Row { std::string fault, where, mech; int trials = 0, halted_ok = 0, halt_exp = 0, released = 0, writes_after = 0,
             partial = 0, pass = 0, fail = 0; std::string note; bool no_halt_expected = false;
             bool v14 = false; };   // v14: not detected by design (on-package plaintext): "pass" = behaved as designed
static std::vector<Row> rows;
static int trial_id = 0;
static void csv(const std::string& fault, const std::string& params, int acc, const Launch& L, bool canary, int bucket_same,
                int lat, bool pass) {
    if (!CSV) return;
    const bool h = L.s.errors & 0x8;
    std::printf("CSV,%d,B,%s,%s,%llu,%u,%u,%u,%d,%d,0x%x,%u,%d,%lld,%d,%d,%u,%u,%d,%d,%d,%d\n", trial_id, fault.c_str(), params.c_str(),
                (unsigned long long)SEED, NBLK, ZPOS, LAMBDA, acc, h ? 1 : 0, L.s.errors, h ? halt_code(L.s) : 0,
                L.o.valid && (L.o.flags & 1) ? int(L.o.hacc) : -1, h ? (long long)halt_bucket(L.s) : -1LL, canary ? 1 : 0,
                (L.o.flags >> 2) & 1, L.o.h_w, L.o.ov, bucket_same, L.mism, lat, pass ? 1 : 0);
}
static void csv_header() {
    if (CSV) std::printf("CSV,trial_id,build,fault_point,params,seed,N,Z,lambda,acc_index,halted,halt_cause,halt_phase,halt_acc,"
                         "halt_bucket,canary_intact,post_halt_activity,wbeats_faulting_acc,order_violation,bucket_unchanged,"
                         "refmodel_mismatches,latency,pass\n");
}
// criteria (a)-(d) for a halt expected at command `acc` of L with the summary errors `exp`
static bool clean_halt(const Launch& L, uint32_t exp, int acc, int64_t bucket, std::string* why) {
    std::string w; const bool tagfail = (exp & 0x200) != 0;   // an integrity halt: not even a result beat inside the card
    if (L.s.errors != exp) w += " errors 0x" + [&]{ char b[16]; std::snprintf(b, 16, "%x", L.s.errors); return std::string(b); }();
    if (!L.o.valid) w += " no observation record";
    else {
        if (!(L.o.flags & 1)) w += " no halt observed";
        if (acc >= 0 && L.o.hacc != uint32_t(acc)) w += " halt at command " + std::to_string(int(L.o.hacc));
        if (tagfail && L.o.h_rv) w += " DOMA released result beats of the failed access";   // (what happens after the halt is not judged)
        if (L.o.ov) w += " order violations " + std::to_string(L.o.ov);
    }
    if (bucket >= 0 && int64_t(halt_bucket(L.s)) != bucket) w += " halt bucket " + std::to_string(halt_bucket(L.s));
    if (L.canary_bad) w += " canary overwritten";
    if (L.mism) w += " " + std::to_string(L.mism) + " wrong results before the halt";
    if (why) *why = w;
    return w.empty();
}
static void tally(Row& r, const Launch& L, bool pass) {
    r.trials++; (pass ? r.pass : r.fail)++;
    if (L.o.valid && L.o.h_w != 0 && L.o.h_w != BKT_BEATS) r.partial++;
}
static void line(const Row& r) {
    std::printf("  -> %-34s trials %5d  pass %5d  fail %5d%s%s\n", r.fault.c_str(), r.trials, r.pass, r.fail,
                r.note.empty() ? "" : "  | ", r.note.c_str());
    std::fflush(stdout);
}
static bool need_boot = true;
static bool ensure_boot() { if (!need_boot) return true; need_boot = !boot(); return !need_boot; }

// ================= P0: controls =================
static void p0() {
    std::printf("\nP0 controls: uniform workload, every hook disarmed (and P3/P5/P6/P8 armed with no effect)\n");
    Row r{"Controls (hooks disarmed)", "--", "Both"}; r.no_halt_expected = true;
    Row a{"Controls (hooks armed, null)", "--", "Debug"}; a.no_halt_expected = true;
    if (!ensure_boot()) { std::printf("P0: boot failed\n"); return; }
    const size_t B = fitn(std::min<size_t>(MAXC, std::getenv("DOMA_BATCH") ? std::stoul(std::getenv("DOMA_BATCH")) : 1000));
    long acc = 0, target = cnt(20000), mism = 0, ov = 0; uint32_t lmin = UINT32_MAX, lmax = 0;
    while (acc < target) {
        auto c = uniform(fitn(std::min<size_t>(B, size_t(target - acc) + 2)));
        Launch L = launch(c, NOF);
        const bool ok = !L.s.errors && !L.mism && L.o.valid && !(L.o.flags & 1) && !L.o.ov && L.s.done == c.size();
        tally(r, L, ok); acc += long(c.size()); mism += L.mism; ov += L.o.ov;
        lmin = std::min(lmin, L.s.lat_min); lmax = std::max(lmax, L.s.lat_max);
        csv("P0", "disarmed", -1, L, true, -1, -1, ok);
        if (L.s.errors) { need_boot = true; ensure_boot(); }
    }
    // armed with null effect: P3 on an unused record bit (224..255), P5 by 0 cycles, P6 for 0 cycles, P8 on a beat
    // past the bucket (never reached); each must leave every result correct and no halt
    for (int t = 0; t < cnt(200); t++) {
        auto c = uniform(fitn(16)); FaultArgs fa; const int m = t % 4; fa.cmd = rnd(c.size());
        if (m == 0) { fa.ctl = F_P3; fa.p3 = 224 + rnd(32); }
        if (m == 1) { fa.ctl = F_P5; fa.p5 = 0; }
        if (m == 2) { fa.ctl = F_P6; fa.p6 = 0; fa.p6n = 0; }
        if (m == 3) { fa.ctl = F_P8; fa.p8 = (0xFFFFu << 8) | rnd(256); }
        Launch L = launch(c, fa);
        const bool ok = !L.s.errors && !L.mism && L.o.valid && !(L.o.flags & 1) && !L.o.ov;
        tally(a, L, ok); acc += long(c.size()); mism += L.mism;
        csv("P0", "armed-null-" + std::to_string(m), int(fa.cmd), L, true, -1, -1, ok);
        if (L.s.errors) { need_boot = true; ensure_boot(); }
    }
    char b[200]; std::snprintf(b, sizeof b, "%ld accesses, %ld wrong results, %ld order violations, latency %u..%u cycles",
                               acc, mism, ov, lmin, lmax);
    r.note = b; rows.push_back(r); line(r); rows.push_back(a); line(a);
}

// ================= P1: host-memory bucket tamper =================
// targeted: steer block k to off-package bucket j, tamper j in host memory, request k: the access must read j and halt
static void p1() {
    std::printf("\nP1 host-memory bucket tamper (targeted with P1 steering, plus black-box)\n");
    if (NB - std::max<uint32_t>(HBMK, 1) < 2) { std::printf("P1: needs at least two off-package buckets (DOMA_HBM_PCT)\n"); return; }
    struct V { const char* name; const char* label; int n; };
    const V vs[] = {{"flip", "Bit flip (random position, incl. first/last beat)", cnt(1000)}, {"replay", "Replay of older version", cnt(1000)},
                    {"swap", "Swap two buckets", cnt(1000)}, {"zero", "Zero bucket", cnt(200)}, {"truncate", "Truncate bucket", cnt(200)},
                    {"identical", "Identical rewrite (control)", cnt(200)}};
    for (const V& v : vs) {
        Row r{v.label, "Host-memory bucket", "Host"}; const bool ctl = std::string(v.name) == "identical"; r.no_halt_expected = ctl;
        int flips_forced = 0;
        for (int t = 0; t < v.n; t++, trial_id++) {
            need_boot = need_boot || !ctl; if (!ensure_boot()) { r.fail++; r.trials++; continue; }
            const uint32_t k = rkey(), j = pick_off();
            if (!steer(k, j)) { r.fail++; r.trials++; need_boot = true; continue; }
            std::string params;
            if (std::string(v.name) == "replay") {                         // j's version now; then DOMA rewrites j
                auto old = snap(j);
                FaultArgs fa; fa.ctl = F_P1; fa.p1k = k; fa.p1b = j;       // reads j, re-steers k to j
                Launch L0 = launch({get_(k)}, fa);
                if (L0.s.errors || L0.mism || std::memcmp(old.data(), hostb(j), STRIDE) == 0) {
                    std::printf("P1 replay: bucket %u not rewritten by the access (errors 0x%x)\n", j, L0.s.errors);
                    r.fail++; r.trials++; need_boot = true; continue; }
                put_host(j, old); params = "bucket=" + std::to_string(j);
            } else if (std::string(v.name) == "flip") {
                size_t bit;
                if (t < int(2 * ZPOS) && flips_forced < int(2 * ZPOS)) {     // every position's first and last beat
                    const size_t pos = t / 2, beat = (t % 2) ? BEATS - 1 : 0; bit = ((pos * BEATS + beat) * 32) * 8 + rnd(256); flips_forced++;
                } else if (t % 10 == 0) bit = (STRIDE - 32) * 8 + rnd(256);  // the bucket's last beat, often
                else bit = rnd(STRIDE * 8);
                auto x = snap(j); x[bit / 8] ^= uint8_t(1u << (bit % 8)); put_host(j, x);
                params = "bucket=" + std::to_string(j) + " bit=" + std::to_string(bit);
            } else if (std::string(v.name) == "swap") {
                uint32_t m; do m = pick_off(); while (m == j);
                auto a = snap(j), b = snap(m); put_host(j, b); put_host(m, a);
                params = "bucket=" + std::to_string(j) + " with=" + std::to_string(m);
            } else if (std::string(v.name) == "zero") {
                put_host(j, std::vector<uint8_t>(STRIDE, 0)); params = "bucket=" + std::to_string(j);
            } else if (std::string(v.name) == "truncate") {
                const size_t keep = size_t(rnd(BKT_BEATS)) * 32; auto x = snap(j);
                bool nz = false; for (size_t i = keep; i < STRIDE; i++) nz |= (x[i] != 0);
                std::memset(x.data() + keep, 0, STRIDE - keep); if (!nz) x[STRIDE - 1] = 1;   // (never an identical rewrite)
                put_host(j, x); params = "bucket=" + std::to_string(j) + " keep=" + std::to_string(keep);
            } else {                                                         // identical rewrite
                put_host(j, snap(j)); params = "bucket=" + std::to_string(j);
            }
            const auto tampered = snap(j);
            Launch L = launch({get_(k)}, NOF);
            bool pass; std::string why;
            if (ctl) { pass = !L.s.errors && !L.mism && L.o.valid && !L.o.ov; if (!pass) why = " halted or wrong result"; }
            else {
                pass = clean_halt(L, 0x208, 0, j, &why);
                settle(); b_pages.sync(XCL_BO_SYNC_BO_FROM_DEVICE);
                (void)tampered;
                r.halt_exp += (L.s.errors == 0x208);
            }
            tally(r, L, pass); csv("P1-" + std::string(v.name), params, 0, L, L.canary_bad == 0, ctl ? -1 : 1, -1, pass);
            if (!pass && r.fail <= 3) std::printf("  P1 %s trial %d (%s): FAIL:%s\n", v.name, t, params.c_str(), why.c_str());
            need_boot = need_boot || (L.s.errors != 0);
        }
        if (!ctl) r.note = "halted 0x208 at bucket j: " + std::to_string(r.halt_exp);
        else r.note = "no halt, k's data correct";
        rows.push_back(r); line(r);
    }
    // black-box: tamper a random off-package bucket, run the uniform workload until DOMA halts (cap: 4 x B accesses)
    Row r{"Bit flip, black-box (untargeted)", "Host-memory bucket", "Host"};
    for (int t = 0; t < cnt(50); t++, trial_id++) {
        need_boot = true; if (!ensure_boot()) { r.fail++; r.trials++; continue; }
        const uint32_t j = pick_off(); auto x = snap(j); const size_t bit = rnd(STRIDE * 8); x[bit / 8] ^= uint8_t(1u << (bit % 8));
        put_host(j, x);
        long acc = 0; bool done = false, pass = false; Launch L; std::string why;
        while (!done && acc < 4L * NB + 64) {
            auto c = uniform(fitn(64)); L = launch(c, NOF); acc += long(c.size());
            if (L.s.errors) { done = true; pass = clean_halt(L, 0x208, -1, j, &why); }
        }
        if (!done) why = " no halt within the cap";
        settle(); b_pages.sync(XCL_BO_SYNC_BO_FROM_DEVICE);
        tally(r, L, pass); r.halt_exp += (L.s.errors == 0x208);
        csv("P1-blackbox", "bucket=" + std::to_string(j) + " bit=" + std::to_string(bit), int(L.o.hacc), L, L.canary_bad == 0, 1, -1, pass);
        if (!pass && r.fail <= 3) std::printf("  P1 black-box trial %d: FAIL:%s\n", t, why.c_str());
    }
    r.note = "halted 0x208 at bucket j: " + std::to_string(r.halt_exp); rows.push_back(r); line(r); need_boot = true;
}

// ================= P2: HBM-resident bucket tamper (host DMA into the on-package bucket buffer) =================
// v14 keeps on-package buckets as plaintext with no tag (A2 excludes this path): the expected v14 outcome is NOT
// DETECTED. The test places a block in an on-package bucket, finds it there (plaintext), corrupts one bit of it and reads it.
static void p2() {
    std::printf("\nP2 HBM-resident bucket tamper (host DMA; a test of the check, not an attack path: (A2))\n");
    Row r{"HBM bucket tamper (P2)", "On-package bucket", "Host DMA"}; r.no_halt_expected = true;
    if (HBMK < 2) { std::printf("P2: needs on-package buckets (DOMA_HBM_PCT)\n"); return; }
    int undetected = 0, detected = 0, unplaced = 0;
    for (int t = 0; t < cnt(200); t++, trial_id++) {
        need_boot = true; if (!ensure_boot()) { r.fail++; r.trials++; continue; }
        const uint32_t j = pick_on(); uint32_t k1 = rkey(), k2; do k2 = rkey(); while (k2 == k1);
        FaultArgs fa; fa.ctl = F_P1 | F_P1_ALL; fa.p1b = j;                  // both blocks to bucket j
        Launch A = launch({put_(k1), put_(k2)}, fa);
        Launch B = launch({get_(k1)}, NOF);                                  // reads j: its write-back takes k2 if there is room
        auto x = get_hbm(j); std::vector<uint8_t> want(BLOCK); pattern(k2, refv[k2], want.data());
        int pos = -1; for (uint32_t p = 0; p < ZPOS; p++) if (std::memcmp(x.data() + p * BLOCK, want.data(), BLOCK) == 0) pos = int(p);
        if (A.s.errors || B.s.errors || pos < 0) { unplaced++; t--; if (unplaced > 20 * cnt(200)) break; continue; }
        const size_t bit = size_t(pos) * BLOCK * 8 + rnd(BLOCK * 8); x[bit / 8] ^= uint8_t(1u << (bit % 8)); put_hbm(j, x);
        Launch L = launch({get_(k2)}, NOF);
        const bool halted = L.s.errors != 0, wrong = L.mism != 0;
        if (halted) detected++; else if (wrong) undetected++;
        tally(r, L, !halted && wrong);                                         // as v14 is designed: returned, undetected
        csv("P2", "bucket=" + std::to_string(j) + " pos=" + std::to_string(pos) + " bit=" + std::to_string(bit), 0, L, true, -1, -1, halted);
    }
    r.note = "v14: on-package buckets are plaintext without a tag -> expected NOT DETECTED; halted " + std::to_string(detected) +
             ", tampered data returned undetected " + std::to_string(undetected) + " (block placed by steering, found by its plaintext)";
    r.v14 = true; rows.push_back(r); line(r); need_boot = true;
}

// ================= P3: tag / IV corruption on the record read path (hook) =================
static void p3() {
    std::printf("\nP3 tag/IV corruption (hook on the bucket-record read; one bit of the {tag, IV} beat, applied once)\n");
    Row r{"Tag / IV corruption", "Bucket record (HBM)", "Debug"}; Row c{"Tag / IV hook, unused bit (control)", "Bucket record (HBM)", "Debug"};
    c.no_halt_expected = true;
    int tagb = 0, ivb = 0;
    for (int t = 0; t < cnt(500) + cnt(50); t++, trial_id++) {
        const bool ctl = t >= cnt(500);
        if (!ensure_boot()) { r.fail++; r.trials++; continue; }
        const uint32_t k = rkey(), j = pick_off();
        if (!steer(k, j)) { need_boot = true; continue; }
        FaultArgs fa; fa.ctl = F_P3; fa.cmd = 0; fa.p3 = ctl ? 224 + rnd(32) : rnd(224);
        (fa.p3 < 96 ? ivb : tagb) += ctl ? 0 : 1;
        const auto before = snap(j);
        Launch L = launch({get_(k)}, fa);
        std::string why; bool pass;
        if (ctl) { pass = !L.s.errors && !L.mism && (L.st.fired & 1); tally(c, L, pass); }
        else {
            pass = clean_halt(L, 0x208, 0, j, &why) && (L.st.fired & 1) && !(L.st.fired & 0x40) && L.o.h_w == 0 && L.o.h_aw == 0;
            settle(); b_pages.sync(XCL_BO_SYNC_BO_FROM_DEVICE);
            r.halt_exp += (L.s.errors == 0x208); tally(r, L, pass);
        }
        csv(ctl ? "P3-control" : "P3", "bucket=" + std::to_string(j) + " bit=" + std::to_string(fa.p3), 0, L, L.canary_bad == 0, 1, -1, pass);
        if (!pass && (r.fail + c.fail) <= 3) std::printf("  P3 trial %d bit %u: FAIL:%s\n", t, fa.p3, why.c_str());
        need_boot = (L.s.errors != 0);
    }
    r.note = "bits in the IV " + std::to_string(ivb) + ", in the tag " + std::to_string(tagb) + "; halted 0x208 at bucket j: " +
             std::to_string(r.halt_exp) + "; no write-back of the halting access";
    c.note = "bits 224..255 of the beat (unused): no halt, results correct";
    rows.push_back(r); line(r); rows.push_back(c); line(c);
}

// ================= P4: stash full (small pool) =================
static void p4() {
    std::printf("\nP4 stash full: pool = boot occupancy + c (c = 1 .. 2(Z+1)); uniform, or every remap steered into one bucket\n");
    Row r{"Stash full", "Stash", "Host (pool size) / Debug (steering)"};
    need_boot = true; if (!ensure_boot()) { std::printf("P4: boot failed\n"); return; }
    uint32_t o0 = boot_occ;
    std::printf("  boot occupancy: %u pool entries in use after the boot (n = %u)\n", o0, NBLK);
    for (int t = 0; t < cnt(100); t++, trial_id++) {
        const uint32_t cap = 1 + uint32_t(t % (2 * (ZPOS + 1))); const bool steer_all = (t % 2) == 1;
        bool ok_boot = boot(o0 + cap); if (!ok_boot) { o0 = boot_occ; ok_boot = boot(o0 + cap); }
        if (!ok_boot) { r.fail++; r.trials++; std::printf("  P4: boot with pool %u halted\n", o0 + cap); continue; }
        FaultArgs fa; if (steer_all) { fa.ctl = F_P1 | F_P1_ALL; fa.p1b = pick_off(); }
        long acc = 0; int mism = 0; bool halted = false, pass = false; Launch L; std::string why;
        while (!halted && acc < 20000) {
            auto c = uniform(fitn(32)); L = launch(c, fa); acc += long(c.size());
            if (L.s.errors) { halted = true; pass = clean_halt(L, 0x408, -1, -1, &why) && mism == 0 && L.st.occ <= o0 + cap; }
            else mism += L.mism;
        }
        if (!halted) why = " no overflow within 20000 accesses";
        r.halt_exp += (L.s.errors == 0x408); tally(r, L, pass);
        csv("P4", "cap=" + std::to_string(cap) + (steer_all ? " steer-all" : " uniform"), int(L.o.hacc), L, L.canary_bad == 0, -1, -1, pass);
        if (!pass && r.fail <= 3) std::printf("  P4 trial %d (cap %u, %s): FAIL:%s (mismatches before the halt %d)\n", t, cap,
                                              steer_all ? "steered" : "uniform", why.c_str(), mism);
    }
    // the linked-list path below the cap: every remap into one bucket with a large pool, every result checked
    Row l{"Stash wait list (steered, below the cap)", "Stash", "Debug"}; l.no_halt_expected = true;
    if (boot(POOL_MAX)) {
        FaultArgs fa; fa.ctl = F_P1 | F_P1_ALL; fa.p1b = pick_off();
        const long room = long(POOL_MAX) - long(boot_occ) - 64, n = std::min<long>(cnt(2000), room);
        long acc = 0; int mism = 0; uint32_t mx = 0; Launch L;
        while (acc < n) { auto c = uniform(fitn(std::min<long>(64, n - acc + 2))); L = launch(c, fa); acc += long(c.size()); mism += L.mism;
                          mx = std::max(mx, L.st.lmax); if (L.s.errors) break; }
        tally(l, L, !L.s.errors && mism == 0);
        l.note = std::to_string(acc) + " accesses steered into bucket " + std::to_string(fa.p1b) + ", stash max " + std::to_string(mx) +
                 " (boot " + std::to_string(boot_occ) + "), wrong results " + std::to_string(mism);
    } else l.note = "boot with the large pool failed";
    r.note = "halted 0x408: " + std::to_string(r.halt_exp) + "; no wrong result before the halt";
    rows.push_back(r); line(r); rows.push_back(l); line(l); need_boot = true;
}

// ================= P5: on-package deadline miss (trim deadline (1) or (2) of one access) =================
// One access to an on-package bucket (P1 steering) gets AR_WB_H (deadline (1)) or AR_REL_H (deadline (2)) shortened
// by `trim` cycles (the RTL clamps the trim to the budget - 2). (No on-package read-issue deadline exists in arrival mode.)
//  (1): v14 lets a late write-back run on; the overrun is reported at the release time (0x108, code 1), after a whole
//       bucket has been written. Safe at any trim. The threshold is searched, then trims around and above it.
//  (2): a release before the hand-off halts (0x108, code 2). A trim that moves the release INTO the write-back leaves
//       the bucket partly written and the HBM write burst open (found with this test, docs/v14d_fault_build.md): a
//       re-boot after it may not be clean. So the sweep starts at large trims (the release before the write-back) and
//       walks down only while the halt comes before the write-back (halt-record state < S_EA_START); the one trial in
//       the write-back window runs at the very end of the program (p5_window), after the table.
static uint32_t p5_last_clean = 0; static bool p5_ran = false;
static unsigned halt_state(const Summary& s) { return unsigned(halt_rec(s) >> 35) & 31; }
static bool p5_bad = false;          // a re-boot after an on-package overrun left DOMA wrong (finding F1): P5 stops
static Launch p5_one(int ph, uint32_t amt, uint32_t* jout = nullptr) {
    Launch L; if (p5_bad) return L;
    if (need_boot) {                  // re-boot, then check it: an open HBM write burst from the last halt shows here
        if (!ensure_boot()) { p5_bad = true; std::printf("  P5: the re-boot after an overrun halt failed: stop P5; reload the xclbin before other tests\n"); return L; }
        Launch C = launch(uniform(fitn(32)), NOF);
        if (C.s.errors || C.mism) { p5_bad = true; need_boot = true;
            std::printf("  P5: after the re-boot following an on-package overrun, a 32-command check returned errors 0x%x and %d wrong results:\n"
                        "      the halt left DOMA's HBM writes broken (finding F1). P5 stops; reload the xclbin before running other tests.\n", C.s.errors, C.mism);
            return L; }
    }
    const uint32_t k = rkey(), j = pick_on(); if (jout) *jout = j;
    if (!steer(k, j)) { need_boot = true; return L; }
    FaultArgs fa; fa.ctl = F_P5; fa.cmd = 0; fa.p5 = (ph == 1) ? amt : (amt << 16);
    L = launch({get_(k)}, fa);
    if (L.s.errors) need_boot = true;
    if (VERBOSE) std::printf("  P5 (%d) trim %u, bucket %u: errors 0x%x, halt state %s, code %u, bucket writes %u + %u after, fired 0x%02x, latency %u\n",
                             ph, amt, j, L.s.errors, L.s.errors ? DOMA_STATE[halt_state(L.s)] : "-", L.s.errors ? halt_code(L.s) : 0,
                             L.o.h_w, L.o.p_w, L.st.fired, L.h.empty() ? 0 : L.h[0].lat);
    return L;
}
static void p5() {
    std::printf("\nP5 on-package deadline miss: AR_WB_H (deadline (1), write-back start) or AR_REL_H (deadline (2), release) shortened\n"
                "   for one access to an on-package bucket (no on-package read-issue deadline exists in arrival mode)\n");
    if (HBMK < 2) { std::printf("P5: needs on-package buckets (DOMA_HBM_PCT)\n"); return; }
    p5_ran = true;
    // ---- deadline (1)
    {
        Row r{"Deadline miss: write-back start (1)", "Controller", "Debug"};
        uint32_t lo = 0, hi = 8192;                                   // the smallest halting trim (a halt is safe here)
        while (hi - lo > 8 && !p5_bad) { const uint32_t m = (lo + hi) / 2; Launch L = p5_one(1, m); if (L.s.errors) hi = m; else lo = m; }
        std::printf("  deadline (1): halts from a trim of about %u cycles (this access's slack)\n", hi);
        int below = 0, below_ok = 0, halts = 0, clean = 0, nh = 0; std::map<uint32_t, int> wb;
        for (int t = 0; t < cnt(100); t++, trial_id++) {
            const bool under = (t % 5 == 0);
            const uint32_t amt = under ? rnd(std::max<uint32_t>(lo, 2)) : hi + uint32_t(t) * std::max<uint32_t>(1, hi / 32);
            uint32_t j = 0; Launch L = p5_one(1, amt, &j); std::string why; bool pass; if (p5_bad) break;
            if (!L.s.errors) { pass = !L.mism && (L.st.fired & 2); nh += !under; if (under) { below++; below_ok += pass; } }
            else {
                halts++; wb[L.o.h_w]++;
                pass = clean_halt(L, 0x108, 0, j, &why) && halt_code(L.s) == 1 && halt_hbm(L.s);
                clean += pass; if (under) below++;
            }
            tally(r, L, pass); r.halt_exp += (L.s.errors == 0x108);
            csv("P5-wb", "trim=" + std::to_string(amt), 0, L, L.canary_bad == 0, -1, L.h.empty() ? -1 : int(L.h[0].lat), pass);
            if (!pass && r.fail <= 3) std::printf("  P5 (1) trim %u: FAIL:%s (code %u, beats written %u)\n", amt, why.c_str(), halt_code(L.s), L.o.h_w);
        }
        std::string w; for (auto& kv : wb) w += " " + std::to_string(kv.first) + " beats x" + std::to_string(kv.second);
        r.note = "slack ~" + std::to_string(hi) + " cycles; " + std::to_string(clean) + "/" + std::to_string(halts) + " halts clean (0x108, code 1, at the release time); "
                 "bucket beats written by the halting access:" + w + " (v14: the late write-back completes, a whole plaintext bucket); trims >= slack without a halt " +
                 std::to_string(nh) + "; trims < slack correct " + std::to_string(below_ok) + "/" + std::to_string(below);
        if (p5_bad) { r.note += " [P5 STOPPED: the re-boot after a halt was not clean (finding F1)]"; r.fail++; }
        rows.push_back(r); line(r);
    }
    // ---- deadline (2): from large trims down while the halt comes before the write-back
    {
        Row r{"Deadline miss: release (2), before write-back", "Controller", "Debug"};
        uint32_t amt = 8192; const uint32_t step = std::max(4, int(512 / std::max(1, cnt(100) / 8)));
        int clean = 0; std::map<unsigned, int> st;
        for (int t = 0; t < cnt(100); t++, trial_id++) {
            uint32_t j = 0; Launch L = p5_one(2, amt, &j); std::string why; bool pass; if (p5_bad) break;
            if (!L.s.errors) { pass = false; why = " no halt"; }
            else pass = clean_halt(L, 0x108, 0, j, &why) && halt_code(L.s) == 2 && L.o.h_w == 0 && L.o.h_aw == 0;
            clean += pass; st[halt_state(L.s)]++;
            tally(r, L, pass); r.halt_exp += (L.s.errors == 0x108);
            csv("P5-rel", "trim=" + std::to_string(amt), 0, L, L.canary_bad == 0, -1, -1, pass);
            if (!pass && r.fail <= 3) std::printf("  P5 (2) trim %u: FAIL:%s\n", amt, why.c_str());
            if (pass) p5_last_clean = amt;
            if (!L.s.errors || halt_state(L.s) >= 20 || L.o.h_w) break;        // next: the write-back (the end of the program)
            amt = (amt > 4096) ? 4096 : (amt > step ? amt - step : 0);
            if (t > 0 && amt == 0) break;
        }
        std::string sn; for (auto& kv : st) sn += std::string(" ") + DOMA_STATE[kv.first] + " x" + std::to_string(kv.second);
        r.note = std::to_string(clean) + " clean halts (0x108, code 2, no bucket write, no result) for trims from 8192 (clamped) down to " +
                 std::to_string(p5_last_clean) + "; halt states:" + sn;
        if (p5_bad) { r.note += " [P5 STOPPED: the re-boot after a halt was not clean (finding F1)]"; r.fail++; }
        rows.push_back(r); line(r);
    }
}
// the release moved into the write-back: run last (a partly written bucket and an open HBM write burst are the
// v14 outcome; the re-boot after it is the risky step)
static void p5_window() {
    if (!p5_ran || HBMK < 2) return;
    if (p5_bad) { Row r{"Deadline miss: release (2), during write-back", "Controller", "Debug"}; r.note = "not run: P5 had stopped (finding F1)";
                  rows.push_back(r); return; }
    std::printf("\nP5 (2) in the write-back window (run last): the release moved into the on-package write-back\n");
    Row r{"Deadline miss: release (2), during write-back", "Controller", "Debug"};
    uint32_t amt = p5_last_clean ? std::min<uint32_t>(p5_last_clean, 4096) : 4096, j = 0; Launch L; std::string why;
    for (int t = 0; t < 64 && !p5_bad; t++) {                          // walk down until the halt comes in the write-back
        L = p5_one(2, amt, &j);
        if (!L.s.errors || halt_state(L.s) >= 20 || L.o.h_w || L.o.p_w || amt < 128) break;
        amt -= 64;
    }
    if (p5_bad) {
        r.trials++; r.fail++; r.note = "stopped while walking the trim down to the write-back: the re-boot after an on-package overrun "
                                       "halt was not clean (finding F1); reload the xclbin";
        rows.push_back(r); line(r); return;
    }
    const bool halted = L.s.errors == 0x108 && halt_code(L.s) == 2;
    const bool pass = clean_halt(L, 0x108, 0, j, &why);                // (what happens after the halt is not judged)
    tally(r, L, pass); trial_id++;
    csv("P5-rel-window", "trim=" + std::to_string(amt), 0, L, L.canary_bad == 0, -1, -1, pass);
    std::printf("  trim %u: errors 0x%x, halt in %s, bucket beats written by the halting access before the halt: %u\n", amt,
                L.s.errors, DOMA_STATE[halt_state(L.s)], L.o.h_w);
    std::printf("  re-boot after it (if this hangs, the kernel did not survive the open burst: reload the xclbin) ...\n"); std::fflush(stdout);
    need_boot = true; const bool ok = ensure_boot();
    Launch C; if (ok) C = launch(uniform(fitn(64)), NOF);
    std::printf("  re-boot %s; a 64-command check launch: errors 0x%x, wrong results %d\n", ok ? "completed" : "FAILED", C.s.errors, C.mism);
    r.note = "trim " + std::to_string(amt) + ": " + (halted ? "halted 0x108 code 2" : "no clean halt") +
             "; re-boot " + (ok ? "ok" : "FAILED") + ", check launch errors " + std::to_string(C.s.errors) + " wrong " + std::to_string(C.mism);
    rows.push_back(r); line(r);
}

// ================= P6: off-package delay (R before the first beat / mid-bucket, B) =================
static void p6() {
    std::printf("\nP6 off-package delay: the pages port's R (before the first beat or mid-bucket) or B held for N cycles on one access\n"
                "   (arrival mode has no off-package deadline: above the kernel's command timeout, %u cycles, the command times out)\n",
                CMD_TIMEOUT);
    const uint32_t delays[] = {0, 10, 100, 1000, 10000, 100000, 500000, 1000000, 1900000, 2100000};
    const char* mode[3] = {"R before the first beat", "R mid-bucket", "B (write response)"};
    // control: latency of every command of an unhooked launch of the same shape
    if (!ensure_boot()) return;
    uint32_t cmin = UINT32_MAX, cmax = 0;
    for (int t = 0; t < 50; t++) { auto c = uniform(fitn(16)); Launch L = launch(c, NOF);
        for (auto& h : L.h) if (h.answered) { cmin = std::min(cmin, h.lat); cmax = std::max(cmax, h.lat); } }
    std::printf("  control: command latencies %u..%u cycles\n", cmin, cmax);
    for (int m = 0; m < 3; m++) {
        Row r{std::string("Off-package delay: ") + mode[m], "Bucket AXI port", "Debug"};
        std::map<uint32_t, std::vector<long>> shift;
        int above = 0, timeouts = 0, spill = 0;
        for (uint32_t N : delays) for (int t = 0; t < cnt(100); t++, trial_id++) {
            if (!ensure_boot()) { r.fail++; r.trials++; continue; }
            const uint32_t k = rkey(), j = pick_off();
            if (!steer(k, j)) { need_boot = true; continue; }
            // (B: never the last command: in arrival mode the held acknowledgement delays the NEXT access's bucket read)
            auto c = uniform(fitn(16)); const uint32_t at = rnd(c.size() - 1); c[at] = get_(k);
            const uint32_t sees = (m == 2) ? at + 1 : at;                      // the command whose latency carries the hold
            for (size_t i = 0; i < c.size(); i++) if (i != at && c[i].key == k) c[i].key = (k + 1) % NBLK;   // k only at `at`
            FaultArgs fa; fa.ctl = F_P6; fa.cmd = at; fa.p6n = N;
            fa.p6 = (m == 0) ? 0 : (m == 1) ? 1 + rnd(BKT_BEATS - 1) : 0x10000;
            Launch L = launch(c, fa);
            bool pass; std::string why;
            if (N + 8000 < CMD_TIMEOUT) {                                       // below the bound
                bool others = true;
                for (size_t i = 0; i < L.h.size(); i++) if (i != at && (L.h[i].lat < cmin || L.h[i].lat > cmax + cmax / 20)) others = false;
                spill += !others;
                pass = !L.s.errors && !L.mism && (L.st.fired & 4);
                if (L.s.errors || L.mism) why += " halt or wrong result";
                if (!(L.st.fired & 4)) why += " hook did not fire";
                shift[N].push_back(long(L.h[sees].lat));
            } else if (N > CMD_TIMEOUT) {                                       // above: the kernel's command timeout
                above++;
                pass = (L.s.errors == 0x10) && L.h[sees].status == 0x10 && L.canary_bad == 0 && !(L.o.flags & 1) && !L.mism;
                timeouts += (L.s.errors == 0x10);
                if (!pass) why = " errors 0x" + std::to_string(L.s.errors);
                // the held access ends on its own after the hold (the kernel moved on): one more launch waits for DOMA
                // to finish it (a re-boot while it runs would reset DOMA in the middle of an access), then re-boot
                settle(20); launch({get_(0)}, NOF); need_boot = true;
            } else pass = !L.mism && (!L.s.errors || L.s.errors == 0x10);       // at the bound: either
            tally(r, L, pass);
            csv("P6-" + std::to_string(m), "N=" + std::to_string(N) + " beat=" + std::to_string(fa.p6 & 0xFFFF), int(at), L,
                L.canary_bad == 0, -1, int(L.h[at].lat), pass);
            if (!pass && r.fail <= 3) std::printf("  P6 %s N=%u: FAIL:%s\n", mode[m], N, why.c_str());
            if (L.s.errors) need_boot = true;
        }
        std::string note = std::string(m == 2 ? "latency of the command after the held one (its bucket read waits for the acknowledgement)" : "latency of the held command") + " (median) by N:";
        for (auto& kv : shift) { auto v = kv.second; std::sort(v.begin(), v.end()); note += " " + std::to_string(kv.first) + ":" + std::to_string(v[v.size() / 2]); }
        note += "; launches where another command's latency left the control range (+5%): " + std::to_string(spill);
        note += "; above the timeout: " + std::to_string(timeouts) + "/" + std::to_string(above) + " timed out (0x10), no DOMA halt, no result";
        r.note = note; rows.push_back(r); line(r);
    }
}

// ================= P7: malformed / unauthorized commands =================
static double ks(std::vector<double> a, std::vector<double> b) {
    if (a.empty() || b.empty()) return NAN;
    std::sort(a.begin(), a.end()); std::sort(b.begin(), b.end());
    size_t i = 0, j = 0; double d = 0;
    while (i < a.size() && j < b.size()) {
        const double x = std::min(a[i], b[j]);
        while (i < a.size() && a[i] <= x) i++; while (j < b.size() && b[j] <= x) j++;
        d = std::max(d, std::fabs(double(i) / a.size() - double(j) / b.size()));
    }
    return d;
}
static void p7() {
    std::printf("\nP7 malformed and unauthorized commands (~10%%: key >= n, bad opcode, bad record range, wrong token)\n");
    Row r{"Malformed / unauthorized command", "Command path", "Host / Debug"}; r.no_halt_expected = true;
    if (!ensure_boot()) return;
    const size_t B = fitn(std::min<size_t>(MAXC, 1000));
    long total = cnt(100000), done = 0; int kinds[4] = {0, 0, 0, 0}; std::vector<double> lat_ok, lat_rej; long traffic_bad = 0;
    while (done < total) {
        auto c = uniform(fitn(std::min<size_t>(B, size_t(total - done) + 2)));
        for (auto& x : c) if (rnd(10) == 0) {
            const int kd = int(rnd(3)); kinds[kd]++;
            if (kd == 0) { x.key = NBLK + rnd(1u << 20); x.exp_status = 0x4; }
            if (kd == 1) { x.type = uint8_t(3 + rnd(13)); x.exp_status = 0x2; }
            if (kd == 2) { x.type = T_PUT; x.off = rnd(BLOCK); x.len = uint32_t(BLOCK) - x.off + 1 + rnd(64); x.exp_status = 0x40; }
        }
        FaultArgs fa; fa.ctl = F_P7; fa.cmd = rnd(c.size()); fa.p7x = 1 + rnd(0xFFFF);
        if (c[fa.cmd].exp_status == 0) c[fa.cmd].exp_status = 0x4;            // wrong token: a lease violation
        else { fa.ctl = 0; }
        if (fa.ctl) kinds[3]++;
        Launch L = launch(c, fa);
        int rej = 0; for (size_t i = 0; i < c.size(); i++) { (c[i].exp_status ? lat_rej : lat_ok).push_back(double(L.h[i].lat)); rej += c[i].exp_status != 0; }
        const bool tr = (L.s.rd % BKT_BEATS == 0) && (L.s.rd == L.s.wr);    // whole buckets, one read and one write each
        traffic_bad += !tr;
        const bool pass = !L.s.errors && !L.mism && L.s.done + uint32_t(rej) == c.size() && tr;
        tally(r, L, pass); done += long(c.size());
        csv("P7", "rejected=" + std::to_string(rej), int(fa.cmd), L, true, -1, -1, pass);
        if (!pass && r.fail <= 3) std::printf("  P7 launch: FAIL: errors 0x%x, mismatches %d, completed %u of %zu (%d rejected), traffic %llu/%llu\n",
                                              L.s.errors, L.mism, L.s.done, c.size(), rej, (unsigned long long)L.s.rd, (unsigned long long)L.s.wr);
        if (L.s.errors) need_boot = true, ensure_boot();
    }
    // KS: rejected vs admitted, against admitted vs admitted (random subsets of the rejected count, 20 draws)
    const double d = ks(lat_rej, lat_ok); double rmin = 1, rmax = 0;
    for (int t = 0; t < 20 && lat_ok.size() > 2 * lat_rej.size(); t++) {
        std::vector<double> a = lat_ok; std::shuffle(a.begin(), a.end(), rng);
        std::vector<double> s1(a.begin(), a.begin() + lat_rej.size()), s2(a.begin() + lat_rej.size(), a.end());
        const double x = ks(s1, s2); rmin = std::min(rmin, x); rmax = std::max(rmax, x);
    }
    char b[300]; std::snprintf(b, sizeof b, "%ld commands, rejected: key %d, opcode %d, range %d, token %d; KS(rejected, admitted) = %.4f, "
                               "admitted vs admitted %.4f..%.4f -> %s; traffic not whole-bucket in %ld launches",
                               done, kinds[0], kinds[1], kinds[2], kinds[3], d, rmin, rmax, (d <= rmax) ? "within" : "OUTSIDE", traffic_bad);
    r.note = b; if (!(d <= rmax)) r.fail++;
    rows.push_back(r); line(r);
}

// ================= P8: in-flight beat corruption (hook on the bucket read stream) =================
static void p8() {
    std::printf("\nP8 in-flight beat corruption: one bit of beat k (0 .. %u, incl. the first and last) of the access's bucket read\n", BKT_BEATS - 1);
    Row r{"In-flight beat corruption", "Bucket read stream", "Debug"};
    int firstb = 0, lastb = 0;
    for (int t = 0; t < cnt(500); t++, trial_id++) {
        if (!ensure_boot()) { r.fail++; r.trials++; continue; }
        const uint32_t k = rkey(), j = pick_off();
        if (!steer(k, j)) { need_boot = true; continue; }
        const uint32_t beat = (t % 4 == 0) ? 0 : (t % 4 == 1) ? BKT_BEATS - 1 : rnd(BKT_BEATS);
        firstb += beat == 0; lastb += beat == BKT_BEATS - 1;
        FaultArgs fa; fa.ctl = F_P8; fa.cmd = 0; fa.p8 = (beat << 8) | rnd(256);
        const auto before = snap(j);
        Launch L = launch({get_(k)}, fa);
        std::string why;
        bool pass = clean_halt(L, 0x208, 0, j, &why) && (L.st.fired & 8) && L.o.h_aw == 0 && L.o.h_w == 0;
        settle(); b_pages.sync(XCL_BO_SYNC_BO_FROM_DEVICE);
        r.halt_exp += (L.s.errors == 0x208); tally(r, L, pass);
        csv("P8", "bucket=" + std::to_string(j) + " beat=" + std::to_string(beat) + " bit=" + std::to_string(fa.p8 & 255), 0, L, L.canary_bad == 0, 1, -1, pass);
        if (!pass && r.fail <= 3) std::printf("  P8 trial %d beat %u: FAIL:%s\n", t, beat, why.c_str());
        need_boot = (L.s.errors != 0);
    }
    r.note = "first beat " + std::to_string(firstb) + ", last beat " + std::to_string(lastb) + " trials; halted 0x208: " + std::to_string(r.halt_exp) +
             "; no result, no bucket AW/W for the access, order violations 0";
    rows.push_back(r); line(r);
    // on the HBM bucket port (on package, plaintext): expected NOT DETECTED in v14
    if (HBMK >= 2) {
        Row h{"In-flight corruption, on package", "HBM bucket read stream", "Debug"}; h.no_halt_expected = true; int nh = 0;
        for (int t = 0; t < cnt(50); t++, trial_id++) {
            if (!ensure_boot()) continue;
            const uint32_t k = rkey(), j = pick_on(); if (!steer(k, j)) { need_boot = true; continue; }
            FaultArgs fa; fa.ctl = F_P8 | F_P8_HBM; fa.cmd = 0; fa.p8 = (rnd(BKT_BEATS) << 8) | rnd(256);
            Launch L = launch({get_(k)}, fa); nh += (L.s.errors == 0); tally(h, L, L.s.errors == 0);
            need_boot = true;                                                  // the corrupted block may be read later: re-boot
        }
        h.note = "v14: on-package buckets carry no tag -> expected NOT DETECTED; no halt in " + std::to_string(nh) + " trials"; h.v14 = true;
        rows.push_back(h); line(h);
    }
}

// ================= P9: uncontrolled stress =================
static void p9() {
    std::printf("\nP9 stress: host memory hog threads and a parallel DMA stream while the normal workload runs\n");
    Row r{"Stress (memory hog + DMA)", "Host / PCIe", "Host"}; r.no_halt_expected = true;
    if (!ensure_boot()) return;
    std::atomic<bool> stop{false}; std::atomic<long> dma{0};
    std::vector<std::thread> th;
    const unsigned nh = std::min(4u, std::max(1u, std::thread::hardware_concurrency() / 2));
    for (unsigned i = 0; i < nh; i++) th.emplace_back([&] { std::vector<uint8_t> a(size_t(128) << 20, 1), b(size_t(128) << 20);
        while (!stop) { std::memcpy(b.data(), a.data(), a.size()); std::memcpy(a.data(), b.data(), a.size()); } });
    xrt::bo d(*g_dev, size_t(64) << 20, g_k->group_id(0));
    th.emplace_back([&] { while (!stop) { d.sync(XCL_BO_SYNC_BO_TO_DEVICE); d.sync(XCL_BO_SYNC_BO_FROM_DEVICE); dma++; } });
    const size_t B = fitn(std::min<size_t>(MAXC, std::getenv("DOMA_BATCH") ? std::stoul(std::getenv("DOMA_BATCH")) : 1000));
    long acc = 0, total = cnt(1000000), mism = 0; int tagh = 0, other = 0;
    while (acc < total) {
        auto c = uniform(fitn(std::min<size_t>(B, size_t(total - acc) + 2)));
        Launch L = launch(c, NOF); acc += long(c.size()); mism += L.mism;
        if (L.s.errors & 0x200) tagh++; else if (L.s.errors) other++;
        tally(r, L, !L.s.errors && !L.mism);
        if (L.s.errors) { std::printf("  P9: launch halted, errors 0x%x\n", L.s.errors); need_boot = true; ensure_boot(); }
    }
    stop = true; for (auto& t : th) t.join();
    r.note = std::to_string(acc) + " accesses with " + std::to_string(nh) + " hog threads and " + std::to_string(dma.load()) +
             " DMA round trips of 64 MB; integrity halts " + std::to_string(tagh) + ", other halts " + std::to_string(other) +
             ", wrong results " + std::to_string(mism);
    rows.push_back(r); line(r);
}

// ================= Part A item 12: stash occupancy statistics =================
static void stash_stats(long acc_total, int w, long base) {
    std::printf("\nStash occupancy (Part A item 12): %ld uniform accesses on one boot, n = %u, lambda = %u, pool %u\n", acc_total, NBLK, LAMBDA, POOL_DEF);
    need_boot = true; if (!ensure_boot()) { std::printf("boot failed\n"); return; }
    const uint32_t o0 = boot_occ;
    if (w < 0) { w = 0; while ((1L << (w + 1)) * (1L << (w + 1)) < long(o0) + 1) w++; w = std::max(w, 1); }
    if (base < 0) base = std::max<long>(0, long(o0) - 4L * (1L << w));
    FaultArgs fa; fa.hs = (uint32_t(base) << 8) | uint32_t(w);
    const size_t B = fitn(std::min<size_t>(MAXC, std::getenv("DOMA_BATCH") ? std::stoul(std::getenv("DOMA_BATCH")) : 1000));
    uint64_t hist[8] = {0}; long acc = 0; uint32_t bmax = 0; int mism = 0; uint32_t errs = 0;
    auto t0 = std::chrono::steady_clock::now();
    while (acc < acc_total) {
        auto c = uniform(fitn(std::min<size_t>(B, size_t(acc_total - acc) + 2)));
        Launch L = launch(c, fa); acc += long(c.size()); mism += L.mism; errs |= L.s.errors;
        for (int k = 0; k < 8; k++) hist[k] += L.st.hist[k];
        bmax = std::max(bmax, L.st.bmax);
        if (L.s.errors) { std::printf("  halted (errors 0x%x) after %ld accesses\n", L.s.errors, acc); break; }
        if (VERBOSE && (acc / long(B)) % 100 == 0) std::printf("  %ld accesses, stash max so far %u\n", acc, bmax);
    }
    const double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::printf("stash: boot occupancy %u; maximum %u pool entries over %ld accesses (%.4f%% of n; %u above the boot); bound used for "
                "the pool %u; wrong results %d; %.1f s\n", o0, bmax, acc, 100.0 * bmax / NBLK, bmax > o0 ? bmax - o0 : 0, POOL_DEF, mism, dt);
    std::printf("stash: occupancy at the end of each access (bin width %d, first edge %ld):\n", 1 << w, base);
    for (int k = 0; k < 8; k++) {
        const long lo = base + (long(k) << w), hi = lo + (1L << w) - 1;
        if (k == 0) std::printf("  <= %-8ld  %llu\n", hi, (unsigned long long)hist[k]);
        else if (k == 7) std::printf("  >= %-8ld  %llu\n", lo, (unsigned long long)hist[k]);
        else std::printf("  %ld..%ld  %llu\n", lo, hi, (unsigned long long)hist[k]);
    }
}

// ================= the results table =================
static void table() {
    std::printf("\n==== Fault-injection results (DOMA test plan Part B, section 6; build B = build A + test hooks and counters) ====\n");
    std::printf("n = %u blocks, Z = %u, lambda = %u, %u buckets (%u on package = %u%%), pool %u, seed %llu, scale %.3g\n",
                NBLK, ZPOS, LAMBDA, NB, HBMK, HBM_PCT, POOL_DEF, (unsigned long long)SEED, SCALE);
    std::printf("%-42s %-22s %-12s %6s %8s %9s %6s %6s\n", "Fault", "Injected where", "Mechanism", "Trials", "Halted",
                "Partial", "Pass", "Fail");
    std::printf("%-42s %-22s %-12s %6s %8s %9s %6s %6s\n", "", "", "", "", "(exp.)", "bucket", "", "");
    int tf = 0;
    for (auto& r : rows) {
        char h[16]; if (r.v14) std::snprintf(h, 16, "v14:none"); else if (r.no_halt_expected) std::snprintf(h, 16, "exp.none"); else std::snprintf(h, 16, "%d", r.halt_exp);
        std::printf("%-42.42s %-22.22s %-12.12s %6d %8s %9d %6d %6d\n", r.fault.c_str(), r.where.c_str(), r.mech.c_str(), r.trials, h,
                    r.partial, r.pass, r.fail);
        tf += r.fail;
    }
    std::printf("\nnotes:\n");
    for (auto& r : rows) if (!r.note.empty()) std::printf("  %s: %s\n", r.fault.c_str(), r.note.c_str());
    std::printf("(Halted: trials that halted with the expected cause; exp.none: no halt expected; v14:none: not detected by v14's design,\n"
                " Pass then counts trials that behaved as designed. Partial: trials whose halting access wrote part of a bucket before the\n"
                " halt. What happens after a halt is not judged.)\n");
    std::printf("\n%s\n", tf ? "SOME TRIALS FAILED (see the lines above and the notes)"
                             : "ALL TRIALS PASSED (rows marked v14:none show v14's expected non-detection on package, see the notes)");
}

int main(int argc, char** argv) {
    if (argc < 2) { std::printf("usage: %s <xclbin> [P0,P1,...|all] [--scale F] [--seed S] [--csv] [--stash ACC] [--hs W,BASE] [--verbose]\n", argv[0]); return 1; }
    std::set<std::string> tests; long stash_acc = 0; int hs_w = -1; long hs_base = -1;
    for (int a = 2; a < argc; a++) {
        std::string o = argv[a];
        if (o == "--scale" && a + 1 < argc) SCALE = std::stod(argv[++a]);
        else if (o == "--seed" && a + 1 < argc) SEED = std::stoull(argv[++a]);
        else if (o == "--csv") CSV = true;
        else if (o == "--verbose") VERBOSE = true;
        else if (o == "--stash" && a + 1 < argc) stash_acc = std::stol(argv[++a]);
        else if (o == "--hs" && a + 1 < argc) { std::string v = argv[++a]; auto c = v.find(','); hs_w = std::stoi(v.substr(0, c));
                                                 if (c != std::string::npos) hs_base = std::stol(v.substr(c + 1)); }
        else if (o[0] != '-') { size_t p = 0; while (p <= o.size()) { size_t q = o.find(',', p); if (q == std::string::npos) q = o.size();
                                    std::string t = o.substr(p, q - p); for (auto& ch : t) ch = char(std::toupper(ch)); if (!t.empty()) tests.insert(t); p = q + 1; } }
        else { std::printf("unknown argument %s\n", o.c_str()); return 1; }
    }
    if (tests.empty() && !stash_acc) tests.insert("ALL");
    if (tests.count("ALL")) for (int i = 0; i <= 9; i++) tests.insert("P" + std::to_string(i));
    rng.seed(SEED);
    if (const char* l = std::getenv("DOMA_LAMBDA")) LAMBDA = uint32_t(std::stoul(l));
    if (const char* e = std::getenv("DOMA_N")) NBLK = uint32_t(std::stoul(e));
    if (const char* e = std::getenv("DOMA_HBM_PCT")) HBM_PCT = unsigned(std::stoul(e));
    if (HBM_PCT > 100) { std::printf("DOMA_HBM_PCT must be 0..100\n"); return 1; }
    NBLK = ((NBLK + LAMBDA - 1) / LAMBDA) * LAMBDA; NB = NBLK / LAMBDA; HBMK = uint32_t((uint64_t(NB) * HBM_PCT) / 100);
    POOL_DEF = uint32_t(std::min<double>(NBLK, std::ceil(stash_bound(double(NBLK), double(LAMBDA), int(ZPOS))) + 1));
    if (const char* e = std::getenv("DOMA_POOL")) POOL_DEF = uint32_t(std::min<unsigned long>(NBLK, std::stoul(e)));
    POOL_MAX = std::min<uint32_t>(NBLK, std::max<uint32_t>(POOL_DEF + 4096, 2 * POOL_DEF));
    refv.assign(NBLK, 0);
    std::printf("host_fault: n = %u blocks (lambda %u, %u buckets, %u on package = %u%%), pool %u (wait-list test up to %u), seed %llu, scale %.3g\n",
                NBLK, LAMBDA, NB, HBMK, HBM_PCT, POOL_DEF, POOL_MAX, (unsigned long long)SEED, SCALE);

    xrt::device device(0); g_dev = &device;
    auto uuid = device.load_xclbin(argv[1]);
    xrt::kernel krnl(device, uuid, "doma_kernel"); g_k = &krnl;
    MAXC = 1000;
    b_cmd   = xrt::bo(device, roundup4k(MAXC * 32) + MAXC * BLOCK, krnl.group_id(0));
    b_resp  = xrt::bo(device, roundup4k((MAXC + 4) * 32) + MAXC * BLOCK, krnl.group_id(1));
    b_pages = xrt::bo(device, size_t(NB - HBMK) * STRIDE + 4096, xrt::bo::flags::host_only, krnl.group_id(2));
    b_meta  = xrt::bo(device, std::max<size_t>(4096, ((size_t(NBLK) + 4) / 5) * 32), krnl.group_id(4));
    b_brec  = xrt::bo(device, std::max<size_t>(4096, size_t(NB) * 64), krnl.group_id(5));
    b_stash = xrt::bo(device, roundup4k(size_t(NB) * 64) + roundup4k(size_t(POOL_MAX) * 16) + size_t(POOL_MAX) * BLOCK, krnl.group_id(6));
    b_hbm   = xrt::bo(device, std::max<size_t>(4096, size_t(HBMK) * STRIDE), krnl.group_id(8));
    cur_pool = POOL_DEF;

    // the first boot: this must be build B, 4 KB blocks, this lambda
    Launch L0 = launch({}, NOF, POOL_DEF);
    if (!L0.s.ok) { std::printf("no summary record: not a doma_kernel bitstream?\n"); return done_(1); }
    if (!(L0.s.dbg & 0x10)) { std::printf("this bitstream is not build B (summary byte 2 bit 4 clear): build it with build.sh FAULT=1\n"); return done_(1); }
    if (L0.s.lam != LAMBDA) { std::printf("the bitstream's lambda is %u: set DOMA_LAMBDA=%u\n", L0.s.lam, L0.s.lam); return done_(1); }
    if (L0.s.beats != BEATS) { std::printf("the bitstream's block is %u bytes: host_fault is for 4 KB blocks\n", L0.s.beats * 32); return done_(1); }
    if (L0.s.errors) { std::printf("boot halted: errors 0x%x\n", L0.s.errors); print_halt_record("boot", L0.s.lat_min, L0.s.lat_max); return done_(1); }
    boot_occ = L0.st.occ; need_boot = false;
    std::printf("boot: %llu cycles, stash occupancy %u after the boot (records [n+2], [n+3] present)\n", (unsigned long long)L0.s.total, boot_occ);
    csv_header();

    if (stash_acc) stash_stats(stash_acc, hs_w, hs_base);
    // P5 runs last: its on-package overrun halts can leave DOMA's HBM writes broken (finding F1)
    const std::pair<const char*, void (*)()> all[] = {{"P0", p0}, {"P1", p1}, {"P2", p2}, {"P3", p3}, {"P4", p4},
                                                      {"P6", p6}, {"P7", p7}, {"P8", p8}, {"P9", p9}, {"P5", p5}};
    auto t0 = std::chrono::steady_clock::now();
    for (auto& t : all) if (tests.count(t.first)) {
        auto a = std::chrono::steady_clock::now(); t.second();
        std::printf("  (%s: %.1f s)\n", t.first, std::chrono::duration<double>(std::chrono::steady_clock::now() - a).count());
    }
    if (!rows.empty()) table();
    if (tests.count("P5")) { const size_t n0 = rows.size(); p5_window(); if (rows.size() > n0) table(); }
    std::printf("total %.1f s\n", std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count());
    int f = 0; for (auto& r : rows) f += r.fail;
    return done_(f ? 1 : 0);
}
