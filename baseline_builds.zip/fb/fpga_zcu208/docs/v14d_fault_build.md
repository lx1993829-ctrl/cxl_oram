# v14d: build B, the fault-injection build (DOMA test plan, Part B)

Build B is the v14c production design (4 KB blocks, lambda = 7, arrival mode, production layout) plus test hooks and
counters, all behind one define, `DOMA_FAULT`. Build A (the release build) is unchanged: with `DOMA_FAULT` undefined
the preprocessed RTL is byte-identical to v14c's (production, trace and debug variants). With every hook disarmed,
build B is cycle-identical to build A: every timing hash, latency, device total and traffic count is equal in
simulation (`sim/run_verilator.sh fault`).

Build B is a test bitstream. Never measure with it, never deploy it, and say in the paper which tests used it.

What build B contains: the hooks P1 (steering), P3, P5, P6, P7, P8, a stash occupancy counter (maximum and
histogram, Part A item 12), and an observation record (the plan's status block, Part B section 4). What it does not
contain: Part C's logger and X4's slack counters (not requested), and an ILA.

## Build

In its own folder (it writes the same file names as build A):

    mkdir buildB && cd buildB
    unzip -q ../fpga_zcu208_deploy_v14c.zip                  # the v14c tree (fpga_zcu208/)
    unzip -o -q ../fpga_v14d_buildB_overlay.zip              # this overlay, over it
    (cd fpga_zcu208 && sha256sum -c --quiet MANIFEST.sha256) && echo tree ok
    cd fpga_zcu208/vitis
    CFG=doma_big2m.cfg NMAX=2097152 LAMBDA=7 SCHED=arrival FAULT=1 TARGET=hw bash build.sh

`FAULT=1` writes `` `define DOMA_FAULT`` into `rtl/oram_build_cfg.vh`, packages the kernel with
`kernel_fault.xml` (22 arguments), and builds `host_fault` next to `host_doma`. It refuses TRACE, DEBUG, INTERIM,
PLAIN and block sizes other than 4 KB. The RTL refuses the same combinations (synthesis stops). Build A is built
exactly as before (without FAULT=1) and is unchanged.

## Arguments (AXI-Lite registers)

The 11 build-A arguments are unchanged. Build B adds 11 scalar arguments, 32 bits each, 8 bytes apart (like
`hbm_bkts` and `pool_n`). All are 0 at reset, which disarms every hook. They are latched at the start of each
launch, and every hook fires at most once per launch, during the access of command `flt_cmd`. A hook armed for a
launch never affects another launch.

| id | name      | offset | fields |
|----|-----------|--------|--------|
| 11 | `flt_ctl` | 0x084  | arm bits: [0] P3, [1] P5, [2] P6, [3] P8, [4] P1, [5] P7; [8] P8 on the HBM bucket port (0: the pages port); [12] P1 on every access; [13] P1 on every access to `flt_p1k` (0: only the first) |
| 12 | `flt_cmd` | 0x08C  | the command index (0 .. size-1) whose access P3, P5, P6, P7 and P8 target |
| 13 | `flt_p5`  | 0x094  | P5: [15:0] cycles off AR_WB_H (deadline (1)), [31:16] cycles off AR_REL_H (deadline (2)); each is clamped to the budget - 2 |
| 14 | `flt_p6`  | 0x09C  | P6: [15:0] the pages-port R beat of the access to hold (0: before the first beat); [16] hold the access's first pages-port B response instead |
| 15 | `flt_p8`  | 0x0A4  | P8: [7:0] the bit (0..255) of the beat; [23:8] the beat (0..1023) of the access's bucket read on the chosen port |
| 16 | `flt_p3`  | 0x0AC  | P3: the bit (0..255) of the bucket record's {tag, IV} beat: 0..95 the IV, 96..223 the tag, 224..255 unused (a control) |
| 17 | `flt_p1k` | 0x0B4  | P1: the block (key) to steer |
| 18 | `flt_p1b` | 0x0BC  | P1: its new bucket (1 .. buckets-1; bucket 0 cannot be a target) |
| 19 | `flt_p7x` | 0x0C4  | P7: XOR applied to the command's lease token (0 means 1) |
| 20 | `flt_hs`  | 0x0CC  | the stash histogram: [4:0] log2 of the bin width, [31:8] the first bin's lower edge |
| 21 | `flt_p6n` | 0x0D4  | P6: the cycles to hold (32 bits) |

Host programs that pass 11 arguments (`host_doma`, `host_ycsb`, `host_phases`) are meant for build A. With XRT,
arguments a host does not pass should be 0 in the run's register map, which leaves build B disarmed [check on the
card before relying on it]; `host_fault` always passes all 22.

## The hooks

* **P1 steering** (`dbg_prng_override`, which build B wires to a register): the access to block `flt_p1k` takes
  `flt_p1b` as its new bucket. One-shot by default (the first access to that block in the launch); [13] steers every
  access to the block, [12] every access of the launch to `flt_p1b`. Requesting the block again then reads that
  bucket: the targeted P1, P2, P3, P5, P6 and P8 tests all use it.
* **P3**: XOR of one bit on the bucket-record read data (gmem4) into DOMA, on the {tag, IV} beat of the first record
  read of the target access. Nothing in memory changes. On an on-package bucket the IV/tag beat is unused (v14
  plaintext): the record's flag shows where it fired.
* **P5**: the target access's deadline (1) and/or (2) moved earlier by a set number of cycles (the plan's trim; a
  stall has the same effect on the deadline check). Off-package accesses have no on-package deadline: the record's
  flag shows that. Arrival mode has no on-package read-issue deadline, so the plan's "read issue" phase does not apply.
* **P6**: an AXI shim on the pages port (host-memory buckets). It holds RVALID/RREADY before beat k of the target
  access's read (k = 0: before the first beat) or the access's first B response, for `flt_p6n` cycles. In arrival
  mode an access ends once its write data is handed off, so a B hold runs on past the access's end, on its own
  counter: it delays the next access's bucket read (which waits for the acknowledgement), not the held access.
* **P7**: the target command is presented with a wrong lease token (the token is kept on chip). DOMA serves it as a
  lease violation: status 0x4, a dummy access.
* **P8**: XOR of one bit on read beat k of the target access's bucket read, in flight, on the pages port or (with
  `flt_ctl[8]`) the HBM port. k = 1023 is the last beat, which only the final tag check can catch.

## Records after the summary

Build B writes two records after the summary [n] and the traffic record [n+1], in the free space before the
response data (the layout of build A is unchanged). Summary byte 2 tells which: bit 4 build B, bit 5 record [n+2]
written, bit 6 record [n+3] written. They are written when they fit: not when (n + 2) % 128 is 0 ([n+2] and [n+3]
are absent) or 127 ([n+3] is absent). `host_fault` never uses such sizes.

Record [n+2], stash statistics (byte 0 = 0x5F):

| bytes | field |
|-------|-------|
| 1     | hooks fired this launch: [0] P3 [1] P5 (on package) [2] P6 [3] P8 [4] P1 [5] P7; [6] P3's record was on package; [7] P5's access was off package |
| 2-3   | P1 overrides this launch |
| 4-6   | stash occupancy now (pool entries in use) |
| 7-9   | the maximum since the boot |
| 10-12 | the maximum during this launch |
| 13-31 | histogram: 8 bins of 19 bits (bin 0 first), the occupancy at the end of each access of this launch; bin = min(7, (occupancy - edge) >> width) |

Record [n+3], observation (byte 0 = 0x60), the plan's status block:

| bytes | field |
|-------|-------|
| 1     | flags: [0] halted in this launch; [1] already halted at the launch start; [2] activity after the halt; [3] the halt came during an access; [4] that access's bucket read was on package; [5] it had verified (tag check passed, or on package); [6] it failed its tag check |
| 2     | the command engine state at the halt |
| 3     | response-data beats the kernel wrote to the host after the halt (must be 0) |
| 4-7   | the command index at the halt (all ones: no halt) |
| 8-11  | cycles from the launch start to the halt |
| 12-13 | bucket W beats of the halting access before the halt |
| 14    | its bucket AW handshakes |
| 15    | its result beats (DOMA's client data, to the kernel) |
| 16-17 | bucket AW handshakes after the halt (both ports) |
| 18-19 | bucket W beats after the halt |
| 20-21 | DOMA's result beats to the kernel after the halt (inside the card; the kernel writes none of them out) |
| 22-23 | order violations |
| 24-26 | tag checks passed this launch |
| 27    | tag checks failed |
| 28-31 | accesses that released a result this launch |

The record is written at the end of the launch: activity after that (until the next launch) is not in it. The
testbench also counts bucket writes from the halt to the re-boot (`FLT-POSTHALT`, finding F1).

`order_violation` counts a result beat leaving DOMA, or a bucket AW handshake, while the latest bucket read has not
verified (its tag check has not passed; an on-package read counts as verified at once, v14 has no tag there).

The halt record in the summary (in place of the latency min/max, as in v14b) gives the halting bucket, its port,
the state and the deadline code. A halt already ends the run: the kernel answers the halted command with status
0x8, leaves its data slot untouched (the canary), answers no later command and writes the summary.

## Expected outcomes (simulation, `sim/run_verilator.sh fault`)

The regression's output is in `docs/v14d_regression_fault.txt` (all checks pass); a run of `host_fault` in the XRT
mock (every test, one trial each) is in `docs/v14d_mock_host_fault.txt`.

| test | hook / host action | outcome in v14 (build B, Verilator) |
|------|--------------------|-------------------------------------|
| P0 | none | identical to build A: all hashes, latencies and traffic equal; 0 order violations |
| P1 targeted | steer block k to off-package bucket 40, flip one bit of its last beat (or zero it) in host memory, request k | halt 0x208 at that command, bucket 40, no result, no write after the halt, the bucket keeps the tampered bytes |
| P1 control | the same bucket rewritten unchanged | no halt |
| P1 every remap into one bucket | `flt_ctl` 0x1010 | below the pool: 200 accesses through the stash wait list, every result correct; pool 60: overflow halt 0x408 |
| P3 | a tag bit, an IV bit | halt 0x208 at the command, no write-back of the access, nothing after the halt |
| P3 control | bit 224 (unused) | no halt |
| P4 | pool = 56 entries (boot occupancy 49) | overflow halt 0x408, nothing after it, no wrong result before it |
| P5 (1) | 1024 cycles off AR_WB_H | overrun halt 0x108 at the release time, deadline code 1; the access first wrote its whole bucket (1024 beats; v14 lets a late on-package write-back run on, it is plaintext) |
| P5 (2) | 3072 cycles off AR_REL_H | overrun halt 0x108, code 2, before the write-back: no write, no result |
| P5 (2), small | 1024 cycles off AR_REL_H | no halt: the result is released 1024 cycles earlier (within the slack) |
| P5 (2), mid write-back | 1500 or 2000 cycles off AR_REL_H | halt 0x108 code 2 with the bucket PARTLY written (110 or 610 beats, then 19 more after the halt) and its HBM write burst left open; see finding F1 |
| P5 off package | | nothing to shorten (flag), no halt |
| P6 R / R mid-bucket | 1000 cycles | no halt, the command 1000 cycles later, on-package release/end times unchanged |
| P6 B | 1000 cycles | no halt, absorbed before the next access's bucket read |
| P6 B | 100,000 cycles | no halt; the held access unchanged; the next access waits for the acknowledgement before its bucket read (its latency grows by about the hold; an on-package next access keeps its deadlines, which count from its bucket's arrival) |
| P6 past the bound | 2,100,000 cycles | arrival mode has no off-package deadline: the kernel's command timeout (2,000,000 cycles) answers 0x10, no DOMA halt, no result; the held access completes after the hold |
| P7 | wrong token | status 0x4, a dummy access, latency like any command's, no halt |
| P8 | beat 0 or the last beat (1023) | halt 0x208, no result, no bucket AW/W of the access, order violations 0 |
| P8 on package | | not detected (plaintext, no tag): as designed in v14 |

## Deviations from the plan

* **On-package buckets are plaintext in v14** (no IV, no tag). P2 (host DMA into the HBM buckets) and P8 on the HBM
  port are therefore not detected; `host_fault` reports them as "v14: not detected by design" rather than as
  failures. (A2) excludes the path; the paper must not claim them.
* **P5 trims the deadline** instead of stalling the step it covers; for the deadline check the two are equivalent. At
  deadline (1), v14 lets the late on-package write-back finish (a whole plaintext bucket) and reports the overrun at
  the release time: the plan's "0 write beats" does not hold there, by v14's rule.
* **P6 has no off-package bound to cross** in arrival mode. Above the kernel's command timeout the command is
  answered 0x10 and the run ends; DOMA does not halt, and the held access completes afterwards.
* **P4 uses the pool size** (`pool_n`, a host argument) instead of a capacity override: the pool is the stash's
  capacity. The cap is the boot occupancy plus c.
* **The plan's halt cause and phase** come from the summary's errors (0x200 tag, 0x400 stash, 0x100 timing) and the
  halt record's deadline code.
* **ILA spot checks** are not part of build B. The P8 timing (last read beat, tag check, first result, first AW) is
  replaced by the counters: the halting access released no result and issued no bucket AW.

## Findings about build A (report only; build A is unchanged)

* **F1. An on-package overrun halt can leave the bucket partly written and an HBM write burst open.** DOMA's
  on-package write-back runs partly outside the controller's state machine. When an overrun halt (0x108) comes while
  it is streaming, it goes on for a while after the halt and then stops in the middle of a burst. Testbench, deadline
  (2) trimmed into the write-back: 110 beats before the halt, 19 more before the record was written and 267 in all
  before the re-boot (377 of 1,024; the burst stays open); the re-boot then makes 383-1,247 AXI protocol errors on the
  HBM port in the testbench's memory model. XRT mock (other memory latencies): a deadline (2) halt before the
  write-back (state S_OP) was still followed by the bucket's 8 write addresses and 12 beats after the record; the
  re-boot then mis-framed the HBM writes and later results were wrong without any halt (the on-package buckets are
  plaintext). Off-package (host) bucket writes after a halt were never seen; tag and stash-overflow halts left
  nothing open. On the card this can happen without a hook whenever an on-package deadline is missed. After an
  on-package overrun halt, reload the xclbin rather than re-boot by an init launch. A fix for a later version: on a
  halt, finish (or never start) an open write burst, e.g. the remaining beats with their strobes off, so the bus stays
  clean; the run is over either way. `host_fault` runs P5 last, checks every re-boot after a P5 halt with a 32-command
  launch, and stops P5 (telling you to reload the xclbin) if that check fails.
* **F2. A re-boot while DOMA is still in an access corrupts the next run.** After a command timeout (0x10) the
  access keeps running; an init launch right after it resets DOMA in the middle of the access (in simulation: order
  violations and a spurious halt in the next run). Wait for the access to end first: one more launch (it waits for
  DOMA), then the re-boot. `host_fault` does this.

## host_fault

    DOMA_N=16384 DOMA_LAMBDA=7 DOMA_HBM_PCT=20 ./host_fault doma_hw.xclbin all          # P0-P9, the plan's trial counts
    DOMA_N=16384 DOMA_LAMBDA=7 DOMA_HBM_PCT=20 ./host_fault doma_hw.xclbin all --scale 0.1
    DOMA_N=1048576 DOMA_LAMBDA=7 DOMA_HBM_PCT=20 ./host_fault doma_hw.xclbin P0,P1,P3,P8 --scale 0.05   # the 1M subset
    DOMA_N=1048576 DOMA_LAMBDA=7 ./host_fault doma_hw.xclbin --stash 20000000                         # Part A item 12

Options: a test list (`P0,...,P9` or `all`), `--scale F` (multiplies every trial count; 1 = the plan's), `--seed S`,
`--csv` (one line per trial, prefixed `CSV,`, the plan's fields), `--stash ACC` (stash statistics over ACC accesses on
one boot), `--hs W,BASE` (the histogram's bin width 2^W and first edge), `--verbose`. Everything is printed as
terminal text; the run ends with the results table of Part B section 6 and a note per row.

Each fault trial boots DOMA afresh (boot time grows with n: about 50 ms at n = 16,384), places its target with P1
steering, injects the fault and checks the plan's criteria (a)-(e): the halt's cause, command and bucket; the canary
(the halted command's data slot untouched); no bucket AW/W or result after the halt; no order violation; the
tampered host bucket unchanged 10 ms after the halt; every other result against the reference model. The P5 trial in
the write-back window (finding F1) runs last, after the table, because the re-boot after it is the risky step.
P5 itself runs after every other test for the same reason (finding F1).

In the XRT mock (`sim/xrt_mock`, `FAULT=1 bash build_model.sh`, `HOSTS=fault bash build_hosts.sh`), run it with
`MOCK_CFG=doma DOMA_N=140 ... --scale 0.001`: the mock simulates about 80,000 cycles per second. `MOCK_QUEUES=1`
prints, after every launch, the writes still open on each port.
