#!/bin/bash
# make_fault_build.sh <baseline: baseline.zip or its fpga_zcu208 tree> <new folder> -- set up the fault-injection build of the serial baseline
#   bash make_fault_build.sh ~/baseline.zip ~/baseline_fault
# Copies the sources to <new folder>/fpga_zcu208, applies patches/fault_baseline.patch (v14d build B's hooks, rebased on the baseline: active only with
# FAULT=1), adds host_fault.cpp and kernel_fault.xml, and prints the build command. The source is only read.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)/fpga_zcu208"
SRC="${1:?usage: bash make_fault_build.sh <baseline.zip or tree> <new folder>}"; DST="${2:?usage: bash make_fault_build.sh <baseline.zip or tree> <new folder>}"
if [ -f "$SRC" ]; then TMPZ="$(mktemp -d)"; trap 'rm -rf "$TMPZ"' EXIT; unzip -q "$SRC" -d "$TMPZ"; SRC="$TMPZ/fpga_zcu208"; fi
SRC="$(cd "$SRC" && pwd)"
[ -f "$SRC/rtl/doma_kernel.v" ] && [ -f "$SRC/vitis/build.sh" ] || { echo "$SRC is not an fpga_zcu208 tree"; exit 1; }
[ -e "$DST" ] && { echo "$DST exists: give a new folder"; exit 1; }
grep -q 'DOMA_FAULT' "$SRC/rtl/doma_kernel.v" && { echo "$SRC already has the fault hooks"; exit 1; }
mkdir -p "$DST/fpga_zcu208"
rsync -a --exclude '_x' --exclude '.Xil' --exclude '.ipcache' --exclude 'doma_ip' --exclude 'doma_pack' --exclude '*.xo' --exclude '*.xclbin' --exclude '*.csv' --exclude '*.log' --exclude '*.out' --exclude 'obj_dir' "$SRC/" "$DST/fpga_zcu208/"
cd "$DST/fpga_zcu208"
patch -p1 --dry-run < "$HERE/patches/fault_baseline.patch" > /dev/null || { echo "the patch does not apply: nothing changed in $SRC; remove $DST"; exit 1; }
patch -p1 < "$HERE/patches/fault_baseline.patch"
cp "$HERE"/vitis/host_fault.cpp "$HERE"/vitis/kernel_fault.xml vitis/; mkdir -p patches docs; cp "$HERE"/patches/fault_baseline.patch patches/; cp "$HERE"/docs/v14d_fault_build.md docs/
echo "== the fault build is in $DST/fpga_zcu208. Build it with:"
echo "   cd $DST/fpga_zcu208/vitis && FAULT=1 FIXWB=1 RAMA=1 BEATS=128 SCHED=arrival CFG=doma_big2m_rama.cfg NMAX=2097152 LAMBDA=7 TARGET=hw MHZ=300 nohup bash build.sh > build.log 2>&1 &"
