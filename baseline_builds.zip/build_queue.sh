#!/bin/bash
# build_queue.sh -- builds the baseline's test bitstreams, at most SLOTS (default 3) at a time; a queued build starts as soon as a slot is free. One folder per
# build; a build that fails does not stop the others. It first waits for the builds named in WAIT_ON ("pid:folder ..."): each counts as finished when the process has
# ended or the folder has its bitstream.
#   WAIT_ON="3129845:$HOME/p3rx300krttest 3130486:$HOME/p3rx300krt" BZIP=~/baseline.zip nohup bash build_queue.sh > ~/build_queue.log 2>&1 &
#   cat ~/build_queue/status.txt
# Builds: bl_trace ~/bl_trace (TRACE=1 + stash record), bl_debug ~/bl_debug (TRACE=1 DEBUG=1 + stash record), bl_fault ~/bl_fault (FAULT=1); ONLY="bl_prod" also builds
# the baseline itself in ~/bl_prod.
# A folder that already has a bitstream is skipped. A folder without one is left alone and reported: move it away to build it again.
# ONLY="krt_test bl_fault" builds just those. DRY=1 sets up the folders without running Vivado.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"; Q=$HOME/build_queue; mkdir -p "$Q"; ST=$Q/status.txt
BZIP=${BZIP:-$HOME/baseline.zip}
say() { echo "$(date '+%m-%d %H:%M') $*" | tee -a "$ST"; }
BARGS="FIXWB=1 RAMA=1 BEATS=128 SCHED=arrival CFG=doma_big2m_rama.cfg NMAX=2097152 LAMBDA=7 TARGET=hw MHZ=300"
ALL="bl_trace bl_debug bl_fault"

folder() { echo "$HOME/$1"; }

setup_baseline_leak() {   # the baseline leak suite into a tree: $1 fpga_zcu208 tree, $2 apply the stash record (yes/no)
    local T=$1
    cp "$HERE"/ltf/fpga_zcu208/vitis/host_leak.cpp "$HERE"/ltf/fpga_zcu208/vitis/leak_runs.sh "$HERE"/ltf/fpga_zcu208/vitis/leak_highstash.sh "$T/vitis/"
    cp "$HERE"/ltf/fpga_zcu208/sim/card_leak_analyze.py "$HERE"/ltf/fpga_zcu208/sim/card_highstash.py "$HERE"/ltf/fpga_zcu208/sim/card_rate_check.py "$T/sim/"
    mkdir -p "$T/patches" "$T/docs"; cp "$HERE"/ltf/fpga_zcu208/patches/baseline_stash_trace.patch "$T/patches/"; cp "$HERE"/ltf/fpga_zcu208/docs/LEAK_CARD_RUNBOOK.md "$T/docs/"
    if [ "$2" = yes ]; then (cd "$T" && patch -p1 --dry-run < patches/baseline_stash_trace.patch > /dev/null && patch -s -p1 < patches/baseline_stash_trace.patch) || return 1; fi
}

job() {
    local j=$1 D V A=""; D=$(folder "$j"); V=$D/fpga_zcu208/vitis
    if [ -f "$V/doma_hw.xclbin" ]; then say "$j: $D already has a bitstream, skipped"; return 0; fi
    if [ -e "$D" ]; then say "$j: $D exists without a bitstream: left alone, not built (move it away to build it)"; return 1; fi
    case $j in
        bl_prod|bl_trace|bl_debug) mkdir -p "$D" && (cd "$D" && unzip -q "$BZIP") || { say "$j: unzip failed"; return 1; }
                  local st=yes; [ "$j" = bl_prod ] && st=no
                  setup_baseline_leak "$D/fpga_zcu208" "$st" || { say "$j: the stash patch did not apply"; return 1; }
                  case $j in bl_prod) A=$BARGS;; bl_trace) A="$BARGS TRACE=1";; bl_debug) A="$BARGS TRACE=1 DEBUG=1";; esac ;;
        bl_fault) bash "$HERE/fb/make_fault_build.sh" "$BZIP" "$D" > "$Q/$j.setup" 2>&1 || { say "$j: setup failed (see $Q/$j.setup)"; return 1; }
                  A="$BARGS FAULT=1" ;;
        *) say "unknown build $j"; return 1 ;;
    esac
    say "$j: build started in $D ($A)"
    [ "${DRY:-0}" = 1 ] && { say "$j: DRY=1, not built"; return 0; }
    ( cd "$V" && env $A bash build.sh ) > "$D/build.log" 2>&1
    case $j in
        bl_*)     [ "$j" = bl_fault ] || (cd "$V" && g++ -std=c++17 -O2 host_leak.cpp -I. -I"$XILINX_XRT/include" -L"$XILINX_XRT/lib" -lxrt_coreutil -pthread -o host_leak) >> "$D/build.log" 2>&1 ;;
    esac
    if [ ! -f "$V/doma_hw.xclbin" ]; then say "$j: BUILD FAILED, no bitstream (see $D/build.log)"; return 1; fi
    if grep -q 'TIMING NOT CLOSED' "$D/build.log"; then say "$j: BUILT, BUT TIMING NOT CLOSED: do not use it (see $D/build.log)"; return 1; fi
    say "$j: built, timing closed ($D/build.log)"
}

if [ "${1:-}" = job ]; then source /opt/xilinx/xrt/setup.sh > /dev/null 2>&1; source /tools/Xilinx/Vitis/2024.1/settings64.sh > /dev/null 2>&1; job "$2"; exit $?; fi

[ -f "$BZIP" ] || { echo "no package $BZIP (set BZIP=)"; exit 1; }
for w in ${WAIT_ON:-}; do
    p=${w%%:*}; d=${w#*:}; say "waiting for $d (process $p)"
    while kill -0 "$p" 2> /dev/null && [ ! -f "$d/fpga_zcu208/vitis/doma_hw.xclbin" ]; do sleep 60; done
    say "$d: finished or bitstream present"
done
L=${ONLY:-$ALL}
say "queue started: $L, ${SLOTS:-3} at a time"
printf '%s\n' $L | xargs -P "${SLOTS:-3}" -n 1 bash "$0" job
say "queue finished"
grep -E 'built|FAILED|skipped|left alone|setup failed' "$ST" | tail -12
