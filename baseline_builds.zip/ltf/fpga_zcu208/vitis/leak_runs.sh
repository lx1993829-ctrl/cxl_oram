#!/bin/bash
# leak_runs.sh -- the card leakage runs as used for the paper's design (Option A, 2026-11-05).
# Run A: the production build with timestamps (TRACE=1); Run B: the debug build (TRACE=1 DEBUG=1), which also records
# each access's location and stash hit. Each run: seven phases of 1M requests (five coin-interleaved pairs, then a
# uniform and a sequential-scan segment), 1M records (1,048,576), 4 KB blocks, 20% of the buckets in HBM.
# Usage, from fpga_zcu208/vitis/ (host_leak built here, ../sim/card_leak_analyze.py beside it):
#   bash leak_runs.sh <traced.xclbin> <debug.xclbin> <results folder> [<production.xclbin> for the rate check]
set -e
XT=$1; XD=$2; R=${3:-leak_results}; mkdir -p $R
exec 9> "$HOME/.u55c_card.lock"; flock -n 9 || { echo "another program is using the card ($HOME/.u55c_card.lock): wait for it to finish"; exit 2; }
# the on-package budgets of the build (deadlines in the debug analysis). Defaults: the baseline, Option A + RAMA (FIXWB=1 RAMA=1)
WBH=${WBH:-440}; RELH=${RELH:-1669}
source /opt/xilinx/xrt/setup.sh > /dev/null; export DOMA_LAMBDA=7
PH=pair:uni/fixed:1000000,pair:get/put:1000000,pair:uni/rereq:1000000,pair:put/zero:1000000,pair:uni/bad:1000000,uni:1000000,scan:1000000
# Run A
DOMA_N=1048576 DOMA_HBM_PCT=20 DOMA_PHASE_TRACE=1 DOMA_LEAK_CSV=$R/leakA.csv DOMA_PHASES=$PH ./host_leak $XT 65536 > $R/leakA.log 2>&1
tail -1 $R/leakA.log; python3 ../sim/card_leak_analyze.py $R/leakA.csv --wbh $WBH --relh $RELH --out $R/summaryA.json > $R/analysisA.txt 2>&1
sed -n '/== padded offsets/,$p' $R/analysisA.txt
# Run B
DOMA_N=1048576 DOMA_HBM_PCT=20 DOMA_PHASE_TRACE=1 DOMA_LEAK_CSV=$R/leakB.csv DOMA_ONPKG_CSV=$R/onpkgB.csv DOMA_PHASES=$PH ./host_leak $XD 65536 > $R/leakB.log 2>&1
tail -1 $R/leakB.log; python3 ../sim/card_leak_analyze.py $R/leakB.csv $R/onpkgB.csv --wbh $WBH --relh $RELH --out $R/summaryB.json > $R/analysisB.txt 2>&1
grep -aE "split agrees|== deadlines|bucket hit / stash hit|NO LEAK|LEAK FOUND" $R/analysisB.txt
# the largest detection threshold (cycles) on response latency, per location, in each run
for j in A B; do python3 -c "import json,sys; C=[c for c in json.load(open(sys.argv[1]))['comparisons'] if c['judged'] and c['q']=='lat']; [print(f'Run {sys.argv[2]}: largest detection threshold, lat, {l} package: {max(c[\"detect\"] for c in C if c[\"loc\"]==l):.2f} cycles') for l in ('off','on')]" $R/summary$j.json $j; done
# the access rate per kind of command (run on the production build if given as the fourth argument): latency starts when a command is issued, so
# a stall before the issue only shows in device cycles per command
XP=${4:-$XT}
for n in 4096 1048576; do
  DOMA_N=$n DOMA_HBM_PCT=20 DOMA_PHASES=get:500000,put:500000,zero:500000,mix:500000,fixed:500000,rereq:500000,scan:500000,bad:500000,get:500000 ./host_leak $XP 65536 > $R/rate_n$n.log 2>&1 || true
  python3 ../sim/card_rate_check.py $R/rate_n$n.log | tee $R/rate_n$n.txt | tail -1
done
