#!/usr/bin/env python3
"""leak_analyze.py -- analyse the 4 KB leakage runs of leak_4k.sh.

    python3 leak_analyze.py build_leak          # prints the PASS/FAIL table, writes build_leak/summary.json

Checks
  E (exact pairs, 0% / 100% on package): within each (share, memory profile, seed), every variant (uniform, fixed,
     scan, re-request keys; all GETs; all PUTs; zero payloads) gives identical run1 hashes: bucket-port timing and
     off-package shape at 0%, on-package release/end at 100%. Every run must also pass its own data checks.
  P (20% on package, per-access CSV): every observable offset takes a single value per (location, previous
     location) in every run, the same value in every variant; bucket indices are uniform over the B buckets and
     independent of the variant; the on-package share matches the configured fixed set.
  C (positive controls): the injected one-cycle leak must make the paired hashes differ and must break the
     single-value check. If it does not, the pipeline is broken and no other result counts.
Internal state (stash hits, occupancy) is reported per variant to show the classes really differ inside DOMA.
"""
import csv, glob, json, os, re, sys
from collections import defaultdict

import numpy as np
from scipy import stats

D = sys.argv[1] if len(sys.argv) > 1 else "build_leak"
N_BLK, LAMBDA, HBM_PCT = 512, 7, 20                      # leak_4k.sh's build and P20 runs
B = (N_BLK + LAMBDA - 1) // LAMBDA
B_HBM = (B * HBM_PCT) // 100
OBS = ["ar0", "r0", "rl", "aw0", "w0", "wl", "rel", "end"]

RX = {}
for _l, _sfx in (("run1", ""), ("run2", "2")):           # run1's hashes as bus/shape/onpkg, run2's as bus2/shape2/onpkg2
    RX["bus" + _sfx] = re.compile(rf"^{_l}: bucket-port timing hash ([0-9a-f]+) over (\d+)")
    RX["shape" + _sfx] = re.compile(rf"^{_l}: off-package access shape hash ([0-9a-f]+) over (\d+)")
    RX["onpkg" + _sfx] = re.compile(rf"^{_l}: on-package release/end hash ([0-9a-f]+) over (\d+) accesses \(release (\d+)\.\.(\d+), end (\d+)\.\.(\d+)")


def parse_log(path):
    r = {"ok": False, "fails": 0}
    with open(path, errors="replace") as f:
        for line in f:
            if "ALL CHECKS PASSED" in line:
                r["ok"] = True
            if line.startswith("FAIL") or " FAIL " in line:
                r["fails"] += 1
            for k, rx in RX.items():
                m = rx.match(line.strip())
                if m:
                    r[k] = m.groups()
    return r


def tag_parts(tag):          # E0_def_s3_k1 -> ("E0", "def", "s3", "k1")
    return tuple(tag.split("_"))


def load_csv(path, launch="run1"):
    with open(path) as f:
        rows = list(csv.DictReader(f))
    for i, r in enumerate(rows):
        for k in r:
            if k != "launch":
                r[k] = int(r[k])
        r["prev"] = rows[i - 1]["loc"] if i > 0 else -1
    return [r for r in rows if r["launch"] == launch]


def obs_key(r):
    return tuple(r[k] for k in OBS)


def exact_group(logs, prefix):
    """Group runs by everything but the variant; each group's hashes must be identical."""
    groups = defaultdict(dict)
    for tag, r in logs.items():
        p = tag_parts(tag)
        if p[0] == prefix:
            groups[p[:3]][p[3]] = r
    out = []
    for g, runs in sorted(groups.items()):
        keys = {"E0": ["bus", "shape"], "E100": ["onpkg"], "R0": ["bus2", "shape2"], "R100": ["onpkg2"]}[prefix]
        ok_runs = all(r["ok"] and r["fails"] == 0 for r in runs.values())
        same = all(len({str(r.get(k)) for r in runs.values()}) == 1 and all(k in r for r in runs.values()) for k in keys)
        n = max(int(runs[v][keys[0]][1]) for v in runs if keys[0] in runs[v]) if any(keys[0] in r for r in runs.values()) else 0
        out.append(dict(group="_".join(g), variants=sorted(runs), accesses=n, runs_pass=ok_runs, identical=same,
                        result="PASS" if ok_runs and same else "FAIL"))
    return out


def per_access(prefix, launch="run1"):
    csvs = sorted(glob.glob(os.path.join(D, prefix + "_*.csv")))
    runs = {os.path.basename(c)[:-4]: load_csv(c, launch) for c in csvs}
    res = dict(runs=len(runs), accesses=sum(len(v) for v in runs.values()))
    ctx_vals = defaultdict(set)          # (loc, prev) -> observable tuples over every run and variant
    worst = 0
    for tag, rows in runs.items():
        per = defaultdict(set)
        for r in rows:
            per[(r["loc"], r["prev"])].add(obs_key(r))
            ctx_vals[(r["loc"], r["prev"])].add(obs_key(r))
        worst = max(worst, max((len(s) for s in per.values()), default=0))
    res["max_distinct_per_run_context"] = worst
    res["distinct_per_context_all_runs"] = {f"loc{k[0]}_prev{k[1]}": len(v) for k, v in sorted(ctx_vals.items())}
    res["single_valued"] = all(len(v) == 1 for v in ctx_vals.values())
    res["overruns"] = sum(r["ovr"] for rows in runs.values() for r in rows)
    # internal state per variant: the classes differ inside DOMA
    var_state = defaultdict(lambda: dict(n=0, stash_hit=0, occ=[]))
    for tag, rows in runs.items():
        v = tag_parts(tag)[3]
        for r in rows:
            var_state[v]["n"] += 1
            var_state[v]["stash_hit"] += r["fis"]
            var_state[v]["occ"].append(r["occ"])
    res["internal_state"] = {v: dict(accesses=s["n"], stash_hit_pct=round(100 * s["stash_hit"] / max(s["n"], 1), 1),
                                     occ_mean=round(float(np.mean(s["occ"])), 1) if s["occ"] else None)
                             for v, s in sorted(var_state.items())}
    # trace: uniform buckets, independent of the variant, fixed on-package set. Only the four key patterns are
    # pooled: get, put and zero use k0's keys and seed, so they read the same buckets as k0 and would count them twice.
    # The prototype's generator (rtl/rng_bucket.v) has a fixed seed and draws the same targets for any request
    # stream, so runs that differ only in +seed can read the identical bucket sequence (a fixed or re-requested key
    # reads the previous target every time). Duplicate sequences are dropped; each distinct sequence is tested on its
    # own and the p-values are combined (Fisher).
    runs = {t: rows for t, rows in runs.items() if tag_parts(t)[3] in ("k0", "k1", "k2", "k3")}
    uniq = {}
    for t, rows in sorted(runs.items()):
        uniq.setdefault(tuple(r["bkt"] for r in rows), t)
    runs = {t: runs[t] for t in uniq.values()}
    res["distinct_bucket_sequences"] = len(runs)
    allb = np.array([r["bkt"] for rows in runs.values() for r in rows])
    if len(allb):
        ps = [stats.chisquare(np.bincount([r["bkt"] for r in rows], minlength=B)[:B]).pvalue for rows in runs.values()]
        res["p_bucket_uniform_per_run_min"] = float(min(ps))
        res["p_bucket_uniform"] = float(stats.combine_pvalues(ps).pvalue)
        g = 8
        tab = []
        for tag, rows in sorted(runs.items()):
            tab.append(np.bincount([r["bkt"] * g // B for r in rows], minlength=g))
        by_var = defaultdict(lambda: np.zeros(g, int))
        for tag, t in zip(sorted(runs), tab):
            by_var[tag_parts(tag)[3]] += t
        m = np.array(list(by_var.values()))
        m = m[:, m.sum(0) > 0]
        res["p_bucket_indep_of_variant"] = float(stats.chi2_contingency(m).pvalue) if m.shape[0] > 1 else None
        locs = np.array([r["loc"] for rows in runs.values() for r in rows])
        res["onpkg_set_exact"] = bool(np.all(locs == (allb < B_HBM)))
        res["p_onpkg_share"] = float(stats.binomtest(int(locs.sum()), len(locs), B_HBM / B).pvalue)
    return res


def main():
    logs = {os.path.basename(p)[:-4]: parse_log(p) for p in glob.glob(os.path.join(D, "*.log"))
            if not p.endswith(".build.log")}
    if not logs:
        sys.exit(f"no run logs in {D}")
    summary = {}
    print(f"== E: exact pairs ({len([t for t in logs if t.startswith('E')])} runs)")
    for pre in ("E0", "E100", "R0", "R100"):
        rows = exact_group(logs, pre)
        if pre == "R0" and rows:
            print(f"== R: rejection pairs, run2 with no / an out-of-range key / a bad token in its middle")
        summary[pre] = rows
        for r in rows:
            print(f"  {r['result']}  {r['group']:<16} {len(r['variants'])} variants, {r['accesses']} accesses each, "
                  f"runs pass={r['runs_pass']} identical={r['identical']}")
    r20 = per_access("R20", "run2")
    if r20["runs"]:
        ok = r20["single_valued"] and r20["overruns"] == 0
        print(f"  {'PASS' if ok else 'FAIL'}  R20 ({r20['runs']} runs, {r20['accesses']} accesses): offsets single-valued per "
              f"(location, previous location) = {r20['single_valued']} {r20['distinct_per_context_all_runs']}, overruns {r20['overruns']}")
    summary["R20"] = r20
    print("== C: positive controls (must differ)")
    ctl = []
    for kind, a, b, keys in (("stash", "k0", "k3", ["bus", "shape"]), ("put", "get", "put", ["bus", "shape"])):
        ta = [t for t in logs if t.startswith(f"C0_{kind}_") and t.endswith("_" + a)]
        tb = [t for t in logs if t.startswith(f"C0_{kind}_") and t.endswith("_" + b)]
        if ta and tb:
            differ = any(logs[ta[0]].get(k) != logs[tb[0]].get(k) for k in keys)
            ctl.append(dict(control=f"C0_{kind}", differ=differ, result="PASS" if differ else "FAIL (not detected)"))
            print(f"  {ctl[-1]['result']}  C0_{kind}: {a} vs {b} hashes differ = {differ}")
    p20 = per_access("P20")
    c20 = per_access("C20")
    c20_detect = (not c20["single_valued"]) if c20["runs"] else None
    if c20["runs"]:
        ctl.append(dict(control="C20_stash", differ=c20_detect, result="PASS" if c20_detect else "FAIL (not detected)"))
        print(f"  {ctl[-1]['result']}  C20_stash: single-value check broken = {c20_detect}")
    summary["C"] = ctl
    print(f"== P: 20% on package, per access ({p20['runs']} runs, {p20['accesses']} accesses)")
    if p20["runs"]:
        ok = p20["single_valued"] and p20["overruns"] == 0
        print(f"  {'PASS' if ok else 'FAIL'}  observable offsets single-valued per (location, previous location): "
              f"{p20['single_valued']} (max distinct in one run {p20['max_distinct_per_run_context']}; "
              f"over all runs {p20['distinct_per_context_all_runs']}), overruns {p20['overruns']}")
        print(f"  info  bucket uniformity over {p20.get('distinct_bucket_sequences')} distinct sequences: combined "
              f"p={p20.get('p_bucket_uniform', float('nan')):.3g} (smallest per run {p20.get('p_bucket_uniform_per_run_min', float('nan')):.3g}), "
              f"independent of variant p={p20.get('p_bucket_indep_of_variant') or float('nan'):.3g}, "
              f"on-package set exact={p20.get('onpkg_set_exact')}, share p={p20.get('p_onpkg_share', float('nan')):.3g}")
        for v, s in p20["internal_state"].items():
            print(f"  info  {v:<5} stash hits {s['stash_hit_pct']:5.1f}%  mean stash occupancy {s['occ_mean']}")
    summary["P20"], summary["C20"] = p20, c20
    allpass = all(r["result"] == "PASS" for k in ("E0", "E100", "R0", "R100") for r in summary[k]) \
        and (not r20["runs"] or (r20["single_valued"] and r20["overruns"] == 0)) \
        and all(c["result"] == "PASS" for c in ctl) and (not p20["runs"] or (p20["single_valued"] and p20["overruns"] == 0))
    summary["all_pass"] = allpass
    with open(os.path.join(D, "summary.json"), "w") as f:
        json.dump(summary, f, indent=1)
    print(f"== {'ALL LEAKAGE CHECKS PASSED' if allpass else 'SOME CHECKS FAILED'} (details: {D}/summary.json)")
    sys.exit(0 if allpass else 1)


if __name__ == "__main__":
    main()
