#!/usr/bin/env python3
"""card_leak_analyze.py -- analyse a card leakage run of vitis/host_leak (docs/LEAK_CARD_RUNBOOK.md).

    python3 card_leak_analyze.py leak.csv [onpkg.csv] [--out summary.json] [--wbh 1228 --relh 2384] [--split 230]

leak.csv   DOMA_LEAK_CSV: one row per command (phase, launch, cmd, class, kind, op, key, lat, tar, trl, twf, twl, status);
           the header times are cycles since the request reached the kernel.
onpkg.csv  DOMA_ONPKG_CSV from a debug bitstream (optional but recommended): the controller's own record of every
           access, joined on (launch, cmd). It gives each access's location (on or off package, flag bit 0), the
           deadline misses (bits 2, 3), and with v14c 128-byte records whether the requested block was in the stash
           (s0 bit 4). Without it, the location comes from the bucket read latency (--split cycles).

Quantities per command (cycles):
  tar    bucket read issued after the request         (padded: the position lookup; waits for the last write ack)
  lrd    trl - tar, bucket read latency               (not padded: depends on where the random bucket lives)
  dwf    twf - trl, write-back's first beat after the bucket's last beat   (padded, plus W acceptance)
  dwl    twl - twf, write-back duration               (not padded: the memory's write acceptance)
  dend   lat - trl, completion after the bucket's last beat               (padded)
  lat    request to completion
Checks
  1. Class pairs (pair:A/B phases): within each location, Welch's t and the two-sample KS test of every quantity
     between the two classes. A comparison fails if |t| > 4.5 or if its p-value (t or KS) is rejected by Holm's
     method at family-wise alpha = 0.01 over all comparisons. Each row reports the smallest mean difference the
     test could have detected (4.5 standard errors), in cycles.
  2. Stash hits (debug CSV with stash records): the same tests between accesses whose block was in the stash and
     those whose block was in its bucket, within each location, over all non-rejected commands.
  3. Padded offsets: the distinct values of tar, dwf and dend per (location, previous location); reported, and a
     difference between classes in them is caught by check 1.
  4. Deadlines (debug CSV): deadline (1) / (2) misses must be 0; the smallest on-package slack, AR_WB_H - write-back
     start and AR_REL_H - release gate after the bucket's last beat (--wbh, --relh: v14c 4 KB lambda 7 defaults).
  5. Lag: the next command's observable timing, split by whether the previous access found its block in the stash
     (debug CSV) and, in class pairs, by the previous command's class. An on-package access's write-back to HBM is
     stash-dependent by design (v14 plaintext path), and the next bucket read waits for its acknowledgements, so a
     late acknowledgement would show here.
  Observable quantities: everything for an off-package access (its bucket traffic crosses PCIe); for an on-package
  access only lat, the time from request to result, since its bucket traffic stays on the HBM port inside the package.
  The other quantities of on-package accesses are printed as internal information and never judged.
  Segments (scan:N against uni:N phases) are compared the same way but are reported apart: they are not interleaved,
  so slow drift (temperature, stash growth) can separate them without any leak.
"""
import argparse, csv, json, sys, warnings
from collections import defaultdict
warnings.filterwarnings("ignore", category=RuntimeWarning)   # scipy: near-identical samples (padded, often constant)

import numpy as np
from scipy import stats

Q = ["tar", "lrd", "dwf", "dwl", "dend", "lat"]
OBS = {0: set(Q), 1: {"lat"}}           # observable per location (0 off package, 1 on package)
NONE16 = 0xFFFF


def read_leak(path):
    rows = []
    with open(path) as f:
        for r in csv.DictReader(f):
            d = {k: r[k] for k in ("kind", "op")}
            for k in ("phase", "launch", "cmd", "class", "key", "lat", "tar", "trl", "twf", "twl"):
                d[k] = int(r[k])
            d["status"] = int(r["status"], 16)
            rows.append(d)
    return rows


def read_onpkg(path):
    rec = {}
    with open(path) as f:
        for r in csv.DictReader(f):
            v = {k: int(x) for k, x in r.items()}
            rec[(v["launch"], v["cmd"])] = v
    return rec


def welch_ks(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    if len(a) < 2 or len(b) < 2:
        return None
    se = np.sqrt(a.var(ddof=1) / len(a) + b.var(ddof=1) / len(b))
    if se == 0:   # both constant
        same = a[0] == b[0]
        return dict(n0=len(a), n1=len(b), mean0=float(a.mean()), mean1=float(b.mean()), t=0.0 if same else float("inf"),
                    p_t=1.0 if same else 0.0, ks=0.0 if same else 1.0, p_ks=1.0 if same else 0.0, detect=0.0)
    t, pt = stats.ttest_ind(a, b, equal_var=False)
    ks = stats.ks_2samp(a, b, method="asymp")
    return dict(n0=len(a), n1=len(b), mean0=float(a.mean()), mean1=float(b.mean()), t=float(t), p_t=float(pt),
                ks=float(ks.statistic), p_ks=float(ks.pvalue), detect=float(4.5 * se))


def holm(p, alpha=0.01):
    p = np.asarray(p); order = np.argsort(p); m = len(p); rej = np.zeros(m, bool)
    for i, idx in enumerate(order):
        if p[idx] <= alpha / (m - i):
            rej[idx] = True
        else:
            break
    return rej


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("leak_csv"); ap.add_argument("onpkg_csv", nargs="?")
    ap.add_argument("--out", default="card_leak_summary.json")
    ap.add_argument("--wbh", type=int, default=1228); ap.add_argument("--relh", type=int, default=2384)
    ap.add_argument("--split", type=int, default=0,
                    help="without onpkg.csv: accesses with dend (result after the last beat) below this are on package; "
                         "default 0 = automatic, from dend's two padded values")
    a = ap.parse_args()

    rows = read_leak(a.leak_csv)
    rec = read_onpkg(a.onpkg_csv) if a.onpkg_csv else {}
    rows.sort(key=lambda r: (r["launch"], r["cmd"]))
    joined = missing = 0
    for r in rows:
        r["lrd"] = r["trl"] - r["tar"]; r["dwf"] = r["twf"] - r["trl"]; r["dwl"] = r["twl"] - r["twf"]; r["dend"] = r["lat"] - r["trl"]
    # without debug records: the result follows the bucket's last beat by a padded time that differs by location, so
    # dend takes two values; the one whose accesses read their bucket faster (HBM) is on package
    split = a.split
    if not split:                                             # with debug records too: checked against their flags below
        vals, cnt = np.unique([r["dend"] for r in rows], return_counts=True)
        top = sorted(vals[np.argsort(cnt)[-2:]]) if len(vals) >= 2 else list(vals)
        if len(top) == 2:
            mid = (top[0] + top[1]) / 2
            lo_lrd = np.median([r["lrd"] for r in rows if r["dend"] < mid])
            hi_lrd = np.median([r["lrd"] for r in rows if r["dend"] >= mid])
            split = mid if lo_lrd < hi_lrd else -mid          # negative: on package is the upper value
            print(f"location from dend: values {top[0]} and {top[1]}; on package = "
                  f"{'the lower' if split > 0 else 'the upper'} (median bucket read {min(lo_lrd, hi_lrd):.0f} vs {max(lo_lrd, hi_lrd):.0f} cycles)")
        else:
            split = float("inf"); print("location from dend: only one value, every access taken as off package")
    for r in rows:
        g = rec.get((r["launch"], r["cmd"]))
        if g is not None:
            joined += 1
            r["loc"] = g["flags"] & 1
            r["miss1"], r["miss2"] = (g["flags"] >> 2) & 1, (g["flags"] >> 3) & 1
            r["stashed"] = ((g["s0"] >> 4) & 1) if "s0" in g and g.get("s15", NONE16) != NONE16 else None
            ta = g["tarr"]
            r["wb_after"] = g["ea"] - ta if NONE16 not in (g["ea"], ta) else None
            r["rel_after"] = g["dg"] - ta if NONE16 not in (g["dg"], ta) else None
        else:
            missing += rec != {}
            r["loc"] = int(r["dend"] < split) if split > 0 else int(r["dend"] >= -split)
            r["miss1"] = r["miss2"] = 0; r["stashed"] = None; r["wb_after"] = r["rel_after"] = None
    for i, r in enumerate(rows):
        r["prev"] = rows[i - 1]["loc"] if i else -1
    src = "debug records" if rec else f"dend split at {abs(split)} cycles"
    if rec and split not in (0, float("inf")):
        by_dend = [int(r["dend"] < split) if split > 0 else int(r["dend"] >= -split) for r in rows]
        agree = sum(int(x == r["loc"]) for x, r in zip(by_dend, rows))
        print(f"the dend split agrees with the debug records' location on {agree} of {len(rows)} commands"
              f" ({'Run A can rely on it' if agree == len(rows) else 'check before trusting a run without debug records'})")
    print(f"{len(rows)} commands, {len(set(r['phase'] for r in rows))} phases; location from {src}"
          + (f"; {joined} joined, {missing} without a record" if rec else ""))

    tests = []                                   # (label, location, quantity, result)
    phases = defaultdict(list)
    for r in rows:
        phases[r["phase"]].append(r)
    names = {}
    for ph, rs in sorted(phases.items()):
        kinds = sorted({(r["class"], r["kind"]) for r in rs})
        names[ph] = "/".join(k for _, k in kinds)
        if len(kinds) == 2:                      # a class pair
            for loc in (0, 1):
                for q in Q:
                    x0 = [r[q] for r in rs if r["loc"] == loc and r["class"] == 0]
                    x1 = [r[q] for r in rs if r["loc"] == loc and r["class"] == 1]
                    t = welch_ks(x0, x1)
                    if t:
                        tests.append((f"pair {names[ph]} (phase {ph})", loc, q, t))
    st = [r for r in rows if r["stashed"] is not None and r["kind"] != "bad"]
    if st:
        for loc in (0, 1):
            for q in Q:
                t = welch_ks([r[q] for r in st if r["loc"] == loc and r["stashed"] == 0],
                             [r[q] for r in st if r["loc"] == loc and r["stashed"] == 1])
                if t:
                    tests.append(("bucket hit / stash hit (logged)", loc, q, t))
    # lag: the next command (same launch) by the previous one's stash hit, and by its class within a pair
    pairs_lag = [(rows[i - 1], rows[i]) for i in range(1, len(rows)) if rows[i - 1]["launch"] == rows[i]["launch"]]
    if any(p["stashed"] is not None for p, _ in pairs_lag):
        for loc in (0, 1):
            for q in Q:
                sel = [(p, c) for p, c in pairs_lag if c["loc"] == loc and p["stashed"] is not None and p["kind"] != "bad"]
                t = welch_ks([c[q] for p, c in sel if p["stashed"] == 0], [c[q] for p, c in sel if p["stashed"] == 1])
                if t:
                    tests.append(("lag: previous bucket hit / stash hit", loc, q, t))
    for ph, rs in sorted(phases.items()):
        if len({r["class"] for r in rs}) != 2:
            continue
        sel = [(p, c) for p, c in pairs_lag if p["phase"] == ph and c["phase"] == ph]
        for loc in (0, 1):
            for q in Q:
                t = welch_ks([c[q] for p, c in sel if c["loc"] == loc and p["class"] == 0],
                             [c[q] for p, c in sel if c["loc"] == loc and p["class"] == 1])
                if t:
                    tests.append((f"lag: previous class, {names[ph]}", loc, q, t))
    seg = []
    single = {ph: rs[0]["kind"] for ph, rs in phases.items() if len({r["kind"] for r in rs}) == 1}
    for sp, k in single.items():
        if k != "scan":
            continue
        up = [ph for ph, kk in single.items() if kk == "uni"]
        if not up:
            continue
        for loc in (0, 1):
            for q in Q:
                t = welch_ks([r[q] for r in phases[up[0]] if r["loc"] == loc], [r[q] for r in phases[sp] if r["loc"] == loc])
                if t:
                    seg.append((f"segment uni (phase {up[0]}) / scan (phase {sp})", loc, q, t))

    judged = [x for x in tests if x[2] in OBS[x[1]]]
    info = [x for x in tests if x[2] not in OBS[x[1]]]
    rej = holm([min(t["p_t"], t["p_ks"]) for *_, t in judged]) if judged else []
    print("\n== observable timing (|t| <= 4.5 and Holm at 0.01 over %d comparisons)" % len(judged))
    print(f"  {'comparison':<44}{'loc':<5}{'qty':<6}{'n0':>9}{'n1':>9}{'mean diff':>11}{'|t|':>8}{'KS':>8}{'detect':>8}  result")
    flagged = 0
    out_tests = []
    for (lab, loc, q, t), hr in zip(judged, rej):
        bad = bool(abs(t["t"]) > 4.5 or hr)
        flagged += int(bad)
        out_tests.append(dict(test=lab, loc="on" if loc else "off", q=q, judged=True, flagged=bad, **t))
        print(f"  {lab:<44}{'on' if loc else 'off':<5}{q:<6}{t['n0']:>9}{t['n1']:>9}{t['mean0'] - t['mean1']:>11.3f}"
              f"{abs(t['t']):>8.2f}{t['ks']:>8.4f}{t['detect']:>8.2f}  {'FLAG' if bad else 'ok'}")
    if info:
        print("\n== internal timing of on-package accesses (HBM port, inside the package: information only, not judged)")
        for lab, loc, q, t in info:
            out_tests.append(dict(test=lab, loc="on", q=q, judged=False, flagged=False, **t))
            print(f"  {lab:<44}{'on':<5}{q:<6}{t['n0']:>9}{t['n1']:>9}{t['mean0'] - t['mean1']:>11.3f}"
                  f"{abs(t['t']):>8.2f}{t['ks']:>8.4f}{t['detect']:>8.2f}")
    if seg:
        print("\n== segments (not interleaved: drift can separate them; reported, not judged)")
        for lab, loc, q, t in seg:
            print(f"  {lab:<44}{'on' if loc else 'off':<5}{q:<6}{t['n0']:>9}{t['n1']:>9}{t['mean0'] - t['mean1']:>11.3f}"
                  f"{abs(t['t']):>8.2f}{t['ks']:>8.4f}{t['detect']:>8.2f}")

    print("\n== padded offsets: distinct values per (location, previous location)")
    pad = {}
    for loc in (0, 1):
        for prev in (0, 1):
            sel = [r for r in rows if r["loc"] == loc and r["prev"] == prev]
            if not sel:
                continue
            d = {}
            for q in ("tar", "dwf", "dend"):
                v = np.array([r[q] for r in sel])
                d[q] = dict(distinct=int(len(np.unique(v))), min=int(v.min()), max=int(v.max()))
            pad[f"loc{loc}_prev{prev}"] = dict(n=len(sel), **d)
            print(f"  loc {'on ' if loc else 'off'} prev {'on ' if prev else 'off'} n={len(sel):>8}  "
                  + "  ".join(f"{q} {x['distinct']} value(s) {x['min']}..{x['max']}" for q, x in d.items()))

    dl = {}
    if rec:
        m1 = sum(r["miss1"] for r in rows); m2 = sum(r["miss2"] for r in rows)
        on = [r for r in rows if r["loc"] == 1]
        wb = [r["wb_after"] for r in on if r["wb_after"] is not None]
        rl = [r["rel_after"] for r in on if r["rel_after"] is not None]
        dl = dict(miss1=m1, miss2=m2, on_package=len(on),
                  min_slack_wb=(a.wbh - max(wb)) if wb else None, min_slack_rel=(a.relh - max(rl)) if rl else None,
                  worst_wb_after=max(wb) if wb else None, worst_rel_after=max(rl) if rl else None)
        print(f"\n== deadlines: deadline (1) misses {m1}, deadline (2) misses {m2}; on package ({len(on)} accesses): "
              f"worst write-back start {dl['worst_wb_after']} vs AR_WB_H {a.wbh} (slack {dl['min_slack_wb']}), "
              f"worst release gate {dl['worst_rel_after']} vs AR_REL_H {a.relh} (slack {dl['min_slack_rel']})")
    ok = flagged == 0 and (not dl or (dl["miss1"] == 0 and dl["miss2"] == 0))
    json.dump(dict(commands=len(rows), location_source=src, comparisons=out_tests, flagged=flagged,
                   segments=[dict(test=l, loc=lo, q=q, **t) for l, lo, q, t in seg], padded=pad, deadlines=dl, all_pass=ok),
              open(a.out, "w"), indent=1)
    print(f"\n== {'NO LEAK FOUND' if ok else 'CHECK THE FLAGGED ROWS'}: {flagged} of {len(judged)} comparisons flagged"
          + (f", deadline misses {dl['miss1']}/{dl['miss2']}" if dl else "") + f" (details: {a.out})")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
