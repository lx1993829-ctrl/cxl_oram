// tb_doma_kernel_leak.v -- copy of tb_doma_kernel.v for the 4 KB leakage tests (sim/leak_4k.sh). Additions only:
//   +key_mode=M     keys of +cmds/+cmds2 runs: 0 uniform (as tb_doma_kernel), 1 one fixed key, 2 sequential scan,
//                   3 re-request the previous key (a near-certain stash hit). Keys and operations are still drawn as
//                   before and then overwritten, so the operation sequence and the random streams do not change.
//   +pay_zero       every written block is all zeros (preload and PUTs; the GET checks follow)
//   +acc_log=<f>    one CSV line per access (location, bucket, Algorithm 1 case, stash occupancy, observable offsets)
//   +no_bad         run2 has no rejected command (the rejection pair compares it with the default bad key and +badtok)
//   +leak_inject=K  positive control: after an access whose block was in the stash (+leak_put: after a PUT), the
//                   next host bucket read takes K extra cycles. A leak the tests must detect.
// tb_doma_kernel.v -- end-to-end test of the doma_kernel Vitis wrapper, with the testbench
// playing XRT: it writes the arguments and ap_start over AXI-Lite and polls ap_done.
//   run 0: size = 0      (boot, key load and lease grant; the analogue of BOLT's init_kernel)
//   run 1: +cmds commands (random GET/PUT over keys 0..N-1), every GET checked
//   run 2: +cmds2 commands, one of them an out-of-range key that must come back rejected
// Options: +cmds=N +cmds2=N +seed=N +host_lat=N (host-memory read latency, cycles)
//          +host_gap=P (percent of cycles without a host read beat)
`timescale 1ns/1ps
`include "oram_params.vh"
module tb_doma_kernel_leak;
    localparam integer DW = 256, BEATS = `BEATS_PER_BLOCK, N = `ORAM_N;
    // memory models sized from the build: commands/responses hold a full preload (N blocks, plus a margin),
    // the stash holds its lists and one block per slot (never smaller than before)
    localparam integer CW_A = (((N > 512) ? N : 512) + 8) * (BEATS + 1) + 1024;
    localparam integer CMD_WORDS = (CW_A > (1 << 17)) ? CW_A : (1 << 17);
    localparam integer SW_A = ((((`ORAM_B * 512) + 4095) / 4096) * 4096 + N * BEATS * 32) / 32 + 64;
    localparam integer STASH_WORDS = (SW_A > (1 << 16)) ? SW_A : (1 << 16);
    integer NBLK = 0, NK = `ORAM_N;
    integer HBM_PCT = 0;
    integer POOL = 0;                       // +pool: stash pool entries (0 = n: cannot run out)                    // +hbm_pct: percentage of buckets kept in HBM (fixed boundary)
    reg [63:0] PAGES_OFF = 64'd0;           // +pagesoff: the pages buffer's offset (the re-boot test moves it)          // +nblk=n: run-time blocks (0 = the build's maximum); NK = effective n
    localparam [63:0] CMD_BASE = 64'h0000_0040_0000_0000, RESP_BASE = 64'h0000_0040_1000_0000,
                      HOST_BASE = 64'h0000_7f00_0000_0000, META_BASE = 64'h0000_0041_0000_0000, BREC_BASE = 64'h0000_0042_0000_0000, STASH_BASE = 64'h0000_0043_0000_0000,
                      HBMB_BASE = 64'h0000_0044_0000_0000;   // buckets kept in HBM (gmem6)
    reg clk = 0, rst_n = 0;
    always #1.667 clk = ~clk;                                  // ~300 MHz

    // ---------------- AXI-Lite master ----------------
    reg  [11:0] awaddr = 0, araddr = 0; reg awvalid = 0, wvalid = 0, bready = 0, arvalid = 0, rready = 0;
    reg  [31:0] wdata = 0; wire awready, wready, bvalid, arready, rvalid; wire [31:0] rdata; wire [1:0] bresp, rresp;
    wire irq;
    // ---------------- AXI masters ----------------
    wire [63:0] g0_araddr, g1_awaddr, g2_araddr, g2_awaddr, g0_awaddr, g1_araddr;
    wire [63:0] g6_araddr, g6_awaddr; wire [7:0] g6_arlen, g6_awlen;
    wire g6_arvalid, g6_arready, g6_rlast, g6_rvalid, g6_rready, g6_awvalid, g6_awready, g6_wlast, g6_wvalid, g6_wready, g6_bvalid, g6_bready;
    wire [DW-1:0] g6_rdata, g6_wdata; wire [DW/8-1:0] g6_wstrb;
    wire [7:0]  g0_arlen, g1_awlen, g2_arlen, g2_awlen, g0_awlen, g1_arlen;
    wire g0_arvalid, g0_arready, g0_rlast, g0_rvalid, g0_rready, g1_awvalid, g1_awready, g1_wlast, g1_wvalid, g1_wready,
         g1_bvalid, g1_bready, g2_arvalid, g2_arready, g2_rlast, g2_rvalid, g2_rready, g2_awvalid, g2_awready,
         g2_wlast, g2_wvalid, g2_wready, g2_bvalid, g2_bready;
    wire [DW-1:0] g0_rdata, g1_wdata, g2_rdata, g2_wdata; wire [DW/8-1:0] g1_wstrb, g2_wstrb;

    doma_kernel dut (
        .ap_clk(clk), .ap_rst_n(rst_n),
        .s_axi_control_awaddr(awaddr), .s_axi_control_awvalid(awvalid), .s_axi_control_awready(awready),
        .s_axi_control_wdata(wdata), .s_axi_control_wstrb(4'hF), .s_axi_control_wvalid(wvalid), .s_axi_control_wready(wready),
        .s_axi_control_bresp(bresp), .s_axi_control_bvalid(bvalid), .s_axi_control_bready(bready),
        .s_axi_control_araddr(araddr), .s_axi_control_arvalid(arvalid), .s_axi_control_arready(arready),
        .s_axi_control_rdata(rdata), .s_axi_control_rresp(rresp), .s_axi_control_rvalid(rvalid), .s_axi_control_rready(rready),
        .interrupt(irq),
        .m_axi_gmem0_araddr(g0_araddr), .m_axi_gmem0_arlen(g0_arlen), .m_axi_gmem0_arsize(), .m_axi_gmem0_arburst(),
        .m_axi_gmem0_arvalid(g0_arvalid), .m_axi_gmem0_arready(g0_arready), .m_axi_gmem0_rdata(g0_rdata),
        .m_axi_gmem0_rresp(2'b00), .m_axi_gmem0_rlast(g0_rlast), .m_axi_gmem0_rvalid(g0_rvalid), .m_axi_gmem0_rready(g0_rready),
        .m_axi_gmem0_awaddr(g0_awaddr), .m_axi_gmem0_awlen(g0_awlen), .m_axi_gmem0_awsize(), .m_axi_gmem0_awburst(),
        .m_axi_gmem0_awvalid(), .m_axi_gmem0_awready(1'b1), .m_axi_gmem0_wdata(), .m_axi_gmem0_wstrb(), .m_axi_gmem0_wlast(),
        .m_axi_gmem0_wvalid(), .m_axi_gmem0_wready(1'b1), .m_axi_gmem0_bresp(2'b00), .m_axi_gmem0_bvalid(1'b0), .m_axi_gmem0_bready(),
        .m_axi_gmem1_araddr(g1_araddr), .m_axi_gmem1_arlen(g1_arlen), .m_axi_gmem1_arsize(), .m_axi_gmem1_arburst(),
        .m_axi_gmem1_arvalid(), .m_axi_gmem1_arready(1'b1), .m_axi_gmem1_rdata({DW{1'b0}}), .m_axi_gmem1_rresp(2'b00),
        .m_axi_gmem1_rlast(1'b0), .m_axi_gmem1_rvalid(1'b0), .m_axi_gmem1_rready(),
        .m_axi_gmem1_awaddr(g1_awaddr), .m_axi_gmem1_awlen(g1_awlen), .m_axi_gmem1_awsize(), .m_axi_gmem1_awburst(),
        .m_axi_gmem1_awvalid(g1_awvalid), .m_axi_gmem1_awready(g1_awready), .m_axi_gmem1_wdata(g1_wdata),
        .m_axi_gmem1_wstrb(g1_wstrb), .m_axi_gmem1_wlast(g1_wlast), .m_axi_gmem1_wvalid(g1_wvalid), .m_axi_gmem1_wready(g1_wready),
        .m_axi_gmem1_bresp(2'b00), .m_axi_gmem1_bvalid(g1_bvalid), .m_axi_gmem1_bready(g1_bready),
        .m_axi_gmem2_araddr(g2_araddr), .m_axi_gmem2_arlen(g2_arlen), .m_axi_gmem2_arsize(), .m_axi_gmem2_arburst(),
        .m_axi_gmem2_arvalid(g2_arvalid), .m_axi_gmem2_arready(g2_arready), .m_axi_gmem2_rdata(g2_rdata),
        .m_axi_gmem2_rresp(2'b00), .m_axi_gmem2_rlast(g2_rlast), .m_axi_gmem2_rvalid(g2_rvalid), .m_axi_gmem2_rready(g2_rready),
        .m_axi_gmem2_awaddr(g2_awaddr), .m_axi_gmem2_awlen(g2_awlen), .m_axi_gmem2_awsize(), .m_axi_gmem2_awburst(),
        .m_axi_gmem2_awvalid(g2_awvalid), .m_axi_gmem2_awready(g2_awready), .m_axi_gmem2_wdata(g2_wdata),
        .m_axi_gmem2_wstrb(g2_wstrb), .m_axi_gmem2_wlast(g2_wlast), .m_axi_gmem2_wvalid(g2_wvalid), .m_axi_gmem2_wready(g2_wready),
        .m_axi_gmem2_bresp(2'b00), .m_axi_gmem2_bvalid(g2_bvalid), .m_axi_gmem2_bready(g2_bready),
        .m_axi_gmem6_araddr(g6_araddr), .m_axi_gmem6_arlen(g6_arlen), .m_axi_gmem6_arsize(), .m_axi_gmem6_arburst(),
        .m_axi_gmem6_arvalid(g6_arvalid), .m_axi_gmem6_arready(g6_arready), .m_axi_gmem6_rdata(g6_rdata),
        .m_axi_gmem6_rresp(2'b00), .m_axi_gmem6_rlast(g6_rlast), .m_axi_gmem6_rvalid(g6_rvalid), .m_axi_gmem6_rready(g6_rready),
        .m_axi_gmem6_awaddr(g6_awaddr), .m_axi_gmem6_awlen(g6_awlen), .m_axi_gmem6_awsize(), .m_axi_gmem6_awburst(),
        .m_axi_gmem6_awvalid(g6_awvalid), .m_axi_gmem6_awready(g6_awready), .m_axi_gmem6_wdata(g6_wdata),
        .m_axi_gmem6_wstrb(g6_wstrb), .m_axi_gmem6_wlast(g6_wlast), .m_axi_gmem6_wvalid(g6_wvalid), .m_axi_gmem6_wready(g6_wready),
        .m_axi_gmem6_bresp(2'b00), .m_axi_gmem6_bvalid(g6_bvalid), .m_axi_gmem6_bready(g6_bready),
        .m_axi_gmem3_araddr(g3_araddr), .m_axi_gmem3_arlen(g3_arlen), .m_axi_gmem3_arsize(), .m_axi_gmem3_arburst(),
        .m_axi_gmem3_arvalid(g3_arvalid), .m_axi_gmem3_arready(g3_arready), .m_axi_gmem3_rdata(g3_rdata), .m_axi_gmem3_rresp(2'b00),
        .m_axi_gmem3_rlast(g3_rlast), .m_axi_gmem3_rvalid(g3_rvalid), .m_axi_gmem3_rready(g3_rready),
        .m_axi_gmem3_awaddr(g3_awaddr), .m_axi_gmem3_awlen(g3_awlen), .m_axi_gmem3_awsize(), .m_axi_gmem3_awburst(),
        .m_axi_gmem3_awvalid(g3_awvalid), .m_axi_gmem3_awready(g3_awready), .m_axi_gmem3_wdata(g3_wdata), .m_axi_gmem3_wstrb(g3_wstrb),
        .m_axi_gmem3_wlast(g3_wlast), .m_axi_gmem3_wvalid(g3_wvalid), .m_axi_gmem3_wready(g3_wready),
        .m_axi_gmem3_bresp(2'b00), .m_axi_gmem3_bvalid(g3_bvalid), .m_axi_gmem3_bready(g3_bready),
        .m_axi_gmem4_araddr(g4_araddr), .m_axi_gmem4_arlen(g4_arlen), .m_axi_gmem4_arsize(), .m_axi_gmem4_arburst(),
        .m_axi_gmem4_arvalid(g4_arvalid), .m_axi_gmem4_arready(g4_arready), .m_axi_gmem4_rdata(g4_rdata), .m_axi_gmem4_rresp(2'b00),
        .m_axi_gmem4_rlast(g4_rlast), .m_axi_gmem4_rvalid(g4_rvalid), .m_axi_gmem4_rready(g4_rready),
        .m_axi_gmem4_awaddr(g4_awaddr), .m_axi_gmem4_awlen(g4_awlen), .m_axi_gmem4_awsize(), .m_axi_gmem4_awburst(),
        .m_axi_gmem4_awvalid(g4_awvalid), .m_axi_gmem4_awready(g4_awready), .m_axi_gmem4_wdata(g4_wdata), .m_axi_gmem4_wstrb(g4_wstrb),
        .m_axi_gmem4_wlast(g4_wlast), .m_axi_gmem4_wvalid(g4_wvalid), .m_axi_gmem4_wready(g4_wready),
        .m_axi_gmem4_bresp(2'b00), .m_axi_gmem4_bvalid(g4_bvalid), .m_axi_gmem4_bready(g4_bready),
        .m_axi_gmem5_araddr(g5_araddr), .m_axi_gmem5_arlen(g5_arlen), .m_axi_gmem5_arsize(), .m_axi_gmem5_arburst(),
        .m_axi_gmem5_arvalid(g5_arvalid), .m_axi_gmem5_arready(g5_arready), .m_axi_gmem5_rdata(g5_rdata), .m_axi_gmem5_rresp(2'b00),
        .m_axi_gmem5_rlast(g5_rlast), .m_axi_gmem5_rvalid(g5_rvalid), .m_axi_gmem5_rready(g5_rready),
        .m_axi_gmem5_awaddr(g5_awaddr), .m_axi_gmem5_awlen(g5_awlen), .m_axi_gmem5_awsize(), .m_axi_gmem5_awburst(),
        .m_axi_gmem5_awvalid(g5_awvalid), .m_axi_gmem5_awready(g5_awready), .m_axi_gmem5_wdata(g5_wdata), .m_axi_gmem5_wstrb(g5_wstrb),
        .m_axi_gmem5_wlast(g5_wlast), .m_axi_gmem5_wvalid(g5_wvalid), .m_axi_gmem5_wready(g5_wready),
        .m_axi_gmem5_bresp(2'b00), .m_axi_gmem5_bvalid(g5_bvalid), .m_axi_gmem5_bready(g5_bready)
    );
    // HBM buffers for commands and responses; host memory (PCIe) for the buckets
    axi_mem_model #(.DW(DW), .WORDS(CMD_WORDS), .BASE(CMD_BASE), .RLAT(40)) u_cmd (
        .clk(clk), .rst_n(rst_n), .araddr(g0_araddr), .arlen(g0_arlen), .arvalid(g0_arvalid), .arready(g0_arready),
        .rdata(g0_rdata), .rresp(), .rlast(g0_rlast), .rvalid(g0_rvalid), .rready(g0_rready),
        .awaddr(64'd0), .awlen(8'd0), .awvalid(1'b0), .awready(), .wdata({DW{1'b0}}), .wstrb({(DW/8){1'b0}}),
        .wlast(1'b0), .wvalid(1'b0), .wready(), .bresp(), .bvalid(), .bready(1'b1));
    axi_mem_model #(.DW(DW), .WORDS(CMD_WORDS), .BASE(RESP_BASE), .RLAT(40)) u_resp (
        .clk(clk), .rst_n(rst_n), .araddr(64'd0), .arlen(8'd0), .arvalid(1'b0), .arready(), .rdata(), .rresp(), .rlast(), .rvalid(), .rready(1'b1),
        .awaddr(g1_awaddr), .awlen(g1_awlen), .awvalid(g1_awvalid), .awready(g1_awready), .wdata(g1_wdata), .wstrb(g1_wstrb),
        .wlast(g1_wlast), .wvalid(g1_wvalid), .wready(g1_wready), .bresp(), .bvalid(g1_bvalid), .bready(g1_bready));
    // bucket records in HBM (metadata + per-position IV/tag), same measured HBM profile as the position map;
    // +brec_lat=N +brec_slow_pct=N +brec_slow_extra=N +brec_wlat=N change it.
    wire [63:0] g4_araddr, g4_awaddr; wire [7:0] g4_arlen, g4_awlen;
    wire g4_arvalid, g4_arready, g4_rvalid, g4_rlast, g4_rready, g4_awvalid, g4_awready;
    wire g4_wvalid, g4_wready, g4_wlast, g4_bvalid, g4_bready;
    wire [DW-1:0] g4_rdata, g4_wdata; wire [DW/8-1:0] g4_wstrb;
    // the stash in HBM (per-bucket lists + block pool), same measured HBM profile as the position map;
    // +stash_lat=N +stash_slow_pct=N +stash_slow_extra=N +stash_wlat=N change it.
    wire [63:0] g5_araddr, g5_awaddr; wire [7:0] g5_arlen, g5_awlen;
    wire g5_arvalid, g5_arready, g5_rvalid, g5_rlast, g5_rready, g5_awvalid, g5_awready;
    wire g5_wvalid, g5_wready, g5_wlast, g5_bvalid, g5_bready;
    wire [DW-1:0] g5_rdata, g5_wdata; wire [DW/8-1:0] g5_wstrb;
    axi_mem_model #(.DW(DW), .WORDS(1 << 16), .BASE(BREC_BASE), .RLAT(53)) u_brec (
        .clk(clk), .rst_n(rst_n), .araddr(g4_araddr), .arlen(g4_arlen), .arvalid(g4_arvalid), .arready(g4_arready),
        .rdata(g4_rdata), .rresp(), .rlast(g4_rlast), .rvalid(g4_rvalid), .rready(g4_rready),
        .awaddr(g4_awaddr), .awlen(g4_awlen), .awvalid(g4_awvalid), .awready(g4_awready), .wdata(g4_wdata), .wstrb(g4_wstrb),
        .wlast(g4_wlast), .wvalid(g4_wvalid), .wready(g4_wready), .bresp(), .bvalid(g4_bvalid), .bready(g4_bready));
    initial begin : brec_profile
        integer v;
        u_brec.slow_pct = 2; u_brec.slow_extra = 105; u_brec.wlat = 26;
        if ($value$plusargs("brec_lat=%d", v))        u_brec.lat = v;
        if ($value$plusargs("brec_slow_pct=%d", v))   u_brec.slow_pct = v;
        if ($value$plusargs("brec_slow_extra=%d", v)) u_brec.slow_extra = v;
        if ($value$plusargs("brec_wlat=%d", v))       u_brec.wlat = v;
        if ($value$plusargs("brec_gap=%d", v))        u_brec.gap_pct = v;     // % of cycles with no record read beat (the card's HBM has such gaps)
    end
    initial begin : hbm_gaps   // +hbm_gap=P: read-data gaps on every HBM memory (the card's HBM returns beats with gaps;
        integer v;             // v11b/v11c passed simulation without them and halted on the card at boot)
        if ($value$plusargs("hbm_gap=%d", v)) begin
            u_brec.gap_pct = v; u_meta.gap_pct = v; u_stmem.gap_pct = v; u_hbmb.gap_pct = v; u_cmd.gap_pct = v; u_resp.gap_pct = v;
        end
        // +hbm_rdy=P / +host_rdy=P: ready held low on P% of cycles (address and write data): backpressure
        if ($value$plusargs("hbm_rdy=%d", v)) begin
            u_brec.rdy_gap = v; u_meta.rdy_gap = v; u_stmem.rdy_gap = v; u_hbmb.rdy_gap = v; u_cmd.rdy_gap = v; u_resp.rdy_gap = v;
        end
        if ($value$plusargs("host_rdy=%d", v)) u_host.rdy_gap = v;
        // v14b +hbm_like=W: every HBM memory (buckets, stash, records, map) acknowledges a write once its data is in
        // and lands it W cycles later, keeps a read behind the writes accepted before it (its latency from their
        // landing), and takes no W beat before its address (axi_mem_model b_early, rd_wait_wr, w_lead = 0)
        if ($value$plusargs("hbm_like=%d", v)) begin
            u_hbmb.b_early = 1; u_hbmb.rd_wait_wr = 1; u_hbmb.w_lead = 0; u_hbmb.wlat = v;
            u_stmem.b_early = 1; u_stmem.rd_wait_wr = 1; u_stmem.w_lead = 0; u_stmem.wlat = v;
            u_brec.b_early = 1; u_brec.rd_wait_wr = 1; u_brec.w_lead = 0; u_brec.wlat = v;
            u_meta.b_early = 1; u_meta.rd_wait_wr = 1; u_meta.w_lead = 0; u_meta.wlat = v;
        end
    end
    axi_mem_model #(.DW(DW), .WORDS(STASH_WORDS), .BASE(STASH_BASE), .RLAT(53)) u_stmem (
        .clk(clk), .rst_n(rst_n), .araddr(g5_araddr), .arlen(g5_arlen), .arvalid(g5_arvalid), .arready(g5_arready),
        .rdata(g5_rdata), .rresp(), .rlast(g5_rlast), .rvalid(g5_rvalid), .rready(g5_rready),
        .awaddr(g5_awaddr), .awlen(g5_awlen), .awvalid(g5_awvalid), .awready(g5_awready), .wdata(g5_wdata), .wstrb(g5_wstrb),
        .wlast(g5_wlast), .wvalid(g5_wvalid), .wready(g5_wready), .bresp(), .bvalid(g5_bvalid), .bready(g5_bready));
    initial begin : stash_profile
        integer v;
        u_stmem.slow_pct = 2; u_stmem.slow_extra = 105; u_stmem.wlat = 26;
        if ($value$plusargs("stash_lat=%d", v))        u_stmem.lat = v;
        if ($value$plusargs("stash_slow_pct=%d", v))   u_stmem.slow_pct = v;
        if ($value$plusargs("stash_slow_extra=%d", v)) u_stmem.slow_extra = v;
        if ($value$plusargs("stash_wlat=%d", v))       u_stmem.wlat = v;
        if ($value$plusargs("stash_gap=%d", v))        u_stmem.gap_pct = v;   // v14b: % of cycles with no stash read beat
    end
    // DOMA's metadata (position map) in HBM, with the U55C's measured latency profile:
    // reads 53 cycles, 2% of them 105 slower; writes acknowledged after 26. +meta_lat=N +meta_slow_pct=N
    // +meta_slow_extra=N +meta_wlat=N change it.
    wire [63:0] g3_araddr, g3_awaddr; wire [7:0] g3_arlen, g3_awlen;
    wire g3_arvalid, g3_arready, g3_rvalid, g3_rlast, g3_rready, g3_awvalid, g3_awready, g3_wvalid, g3_wready, g3_wlast, g3_bvalid, g3_bready;
    wire [DW-1:0] g3_rdata, g3_wdata; wire [DW/8-1:0] g3_wstrb;
    axi_mem_model #(.DW(DW), .WORDS(1 << 16), .BASE(META_BASE), .RLAT(53)) u_meta (
        .clk(clk), .rst_n(rst_n), .araddr(g3_araddr), .arlen(g3_arlen), .arvalid(g3_arvalid), .arready(g3_arready),
        .rdata(g3_rdata), .rresp(), .rlast(g3_rlast), .rvalid(g3_rvalid), .rready(g3_rready),
        .awaddr(g3_awaddr), .awlen(g3_awlen), .awvalid(g3_awvalid), .awready(g3_awready), .wdata(g3_wdata), .wstrb(g3_wstrb),
        .wlast(g3_wlast), .wvalid(g3_wvalid), .wready(g3_wready), .bresp(), .bvalid(g3_bvalid), .bready(g3_bready));
    initial begin : meta_profile
        integer v;
        u_meta.slow_pct = 2; u_meta.slow_extra = 105; u_meta.wlat = 26;
        if ($value$plusargs("meta_lat=%d", v))        u_meta.lat = v;
        if ($value$plusargs("meta_slow_pct=%d", v))   u_meta.slow_pct = v;
        if ($value$plusargs("meta_slow_extra=%d", v)) u_meta.slow_extra = v;
        if ($value$plusargs("meta_wlat=%d", v))       u_meta.wlat = v;
    end
    // host memory: 8 KB per slot (the same as 32 KB per bucket at lambda = 4; independent of lambda), room for the
    // re-boot test's moved bucket area
    axi_mem_model #(.DW(DW), .WORDS((`ORAM_N > 4096) ? (1 << 20) : ((`ORAM_N << 13) / 32)), .BASE(HOST_BASE), .RLAT(100), .WF_DEPTH(8192)) u_host (
        .clk(clk), .rst_n(rst_n), .araddr(g2_araddr), .arlen(g2_arlen), .arvalid(g2_arvalid), .arready(g2_arready),
        .rdata(g2_rdata), .rresp(), .rlast(g2_rlast), .rvalid(g2_rvalid), .rready(g2_rready),
        .awaddr(g2_awaddr), .awlen(g2_awlen), .awvalid(g2_awvalid), .awready(g2_awready), .wdata(g2_wdata), .wstrb(g2_wstrb),
        .wlast(g2_wlast), .wvalid(g2_wvalid), .wready(g2_wready), .bresp(), .bvalid(g2_bvalid), .bready(g2_bready));
    // bucket-write digests (end-to-end check against v10e: the same buckets, bit for bit, in the same order)
    wire [63:0] bwd2_w, bwd2_a, bwd6_w, bwd6_a; wire [31:0] bwd2_nw, bwd2_na, bwd6_nw, bwd6_na;
    bucket_write_digest #(.DW(DW), .AW(64)) u_bwd2 (.clk(clk), .awaddr(g2_awaddr), .awlen(g2_awlen), .awvalid(g2_awvalid),
        .awready(g2_awready), .wdata(g2_wdata), .wstrb(g2_wstrb), .wvalid(g2_wvalid), .wready(g2_wready),
        .dig_w(bwd2_w), .dig_a(bwd2_a), .n_w(bwd2_nw), .n_a(bwd2_na));
    bucket_write_digest #(.DW(DW), .AW(64)) u_bwd6 (.clk(clk), .awaddr(g6_awaddr), .awlen(g6_awlen), .awvalid(g6_awvalid),
        .awready(g6_awready), .wdata(g6_wdata), .wstrb(g6_wstrb), .wvalid(g6_wvalid), .wready(g6_wready),
        .dig_w(bwd6_w), .dig_a(bwd6_a), .n_w(bwd6_nw), .n_a(bwd6_na));
    task bw_report; begin
        $display("bucket writes: host %0d beats digest %016h, %0d bursts address digest %016h; HBM %0d beats digest %016h, %0d bursts address digest %016h",
                 bwd2_nw, bwd2_w, bwd2_na, bwd2_a, bwd6_nw, bwd6_w, bwd6_na, bwd6_a);
    end endtask
    // buckets kept in HBM (gmem6, fixed boundary: buckets 0 .. hbm_bkts-1), HBM-like latency
    axi_mem_model #(.DW(DW), .WORDS((`ORAM_B * `BUCKET_BYTES) / 32 + 64), .BASE(HBMB_BASE), .RLAT(53)) u_hbmb (
        .clk(clk), .rst_n(rst_n), .araddr(g6_araddr), .arlen(g6_arlen), .arvalid(g6_arvalid), .arready(g6_arready),
        .rdata(g6_rdata), .rresp(), .rlast(g6_rlast), .rvalid(g6_rvalid), .rready(g6_rready),
        .awaddr(g6_awaddr), .awlen(g6_awlen), .awvalid(g6_awvalid), .awready(g6_awready), .wdata(g6_wdata), .wstrb(g6_wstrb),
        .wlast(g6_wlast), .wvalid(g6_wvalid), .wready(g6_wready), .bresp(), .bvalid(g6_bvalid), .bready(g6_bready));

    // ---------------- AXI-Lite tasks (what XRT does) ----------------
    // Driven on the falling edge, half a cycle from where the kernel samples. Each task waits for
    // the registered consequence of its handshake (bvalid / rvalid), never for a combinational
    // ready: the kernel holds awready/arready low while a response is pending, so the request
    // cannot be taken twice, and nothing depends on when combinational logic is re-evaluated.
    task axil_wr; input [11:0] a; input [31:0] d; begin
        @(negedge clk); awaddr = a; wdata = d; awvalid = 1; wvalid = 1;
        while (!bvalid) @(negedge clk);
        awvalid = 0; wvalid = 0; bready = 1;               // response taken on the next rising edge
        @(negedge clk); bready = 0;
    end endtask
    task axil_rd; input [11:0] a; output [31:0] d; begin
        @(negedge clk); araddr = a; arvalid = 1;
        while (!rvalid) @(negedge clk);
        d = rdata; arvalid = 0; rready = 1;
        @(negedge clk); rready = 0;
    end endtask

    // ---------------- host-side state ----------------
    integer last_put [0:N-1];            // command id of the last PUT to each key, -1 = never written
    integer cmd_key [0:4095], cmd_type [0:4095], cmd_id [0:4095];
    integer gid = 0, fails = 0, seed, ncmd1, ncmd2, hl, hg;
    reg badtok = 0, bt_arm = 0, bt_done = 0; integer bt_at = -1; reg [31:0] bt_save = 0;   // +badtok (see the monitor)
    // +packed=R: R-byte records packed into each block (offset and length in the command header).
    // Every GET is checked against a byte-exact image of the block, so the record's neighbours and
    // never-written bytes (zeros) are checked too; PUT data carries junk outside its record.
    integer rec_len = 0;
    integer cmd_off [0:4095], cmd_len [0:4095];
    reg [DW-1:0] refimg [0:N*BEATS-1];
    integer key_mode = 0; reg pay_zero = 0;                 // leak tests: +key_mode, +pay_zero
    initial begin
        if (!$value$plusargs("key_mode=%d", key_mode)) key_mode = 0;
        if ($test$plusargs("pay_zero")) pay_zero = 1;
    end
    function [DW-1:0] pat; input integer id, beat, key; begin
        pat = pay_zero ? {DW{1'b0}} : {8{id[15:0], beat[7:0], key[7:0]}};
    end endfunction

    // +put_pct=P: P% of the commands are PUTs (one random draw per command, as without it, so the keys are the
    // same for every P). Bucket-port timing: a hash of the gaps between consecutive read and write-back requests
    // on the host bucket port; equal hashes for different P mean the GET/PUT mix is invisible in the timing.
    integer put_pct, kseed;
    reg  [63:0] bus_h, key_h; integer bus_n; reg [63:0] bus_last;
    initial begin if (!$value$plusargs("put_pct=%d", put_pct)) put_pct = -1; bus_h = 0; bus_n = 0; bus_last = 0; end
    always @(posedge clk) if ((g2_arvalid && g2_arready) || (g2_awvalid && g2_awready)) begin
        bus_h    <= (bus_h * 64'd1000003) ^ (cyc_tb - bus_last) ^ ((g2_awvalid && g2_awready) ? 64'h8000_0000_0000_0000 : 64'd0);
        bus_last <= cyc_tb; bus_n <= bus_n + 1;
    end
    // Deterministic pseudo-random draws (xorshift32): identical on every simulator version. Verilator's $random sequence
    // changed between releases, which changed the stimulus and with it the calibrated timing budgets.
    function [31:0] xs32; input [31:0] x; reg [31:0] y; begin
        y = (x == 32'd0) ? 32'h2545F491 : x; y = y ^ (y << 13); y = y ^ (y >> 17); xs32 = y ^ (y << 5);
    end endfunction
    // prepare a run: headers at cmd word i, PUT data from word HC/32 + i*BEATS
    task prepare; input integer size; input integer bad_at; integer i, j, hcw; begin
        bus_h = 64'd0; bus_n = 0; bus_last = cyc_tb;                 // the bucket-port timing hash restarts per run
        key_h = 64'd0;
        hcw = (((size * 32) + 4095) / 4096) * 4096 / 32;
        for (i = 0; i < size; i = i + 1) begin
            if (put_pct < 0) begin seed = xs32(seed); cmd_type[i] = seed[0] ? 2 : 1; end
            else begin kseed = xs32(kseed); cmd_type[i] = (($unsigned(kseed) % 100) < put_pct) ? 2 : 1; end  // own stream: same keys for every P
            if (put_pct < 0) begin seed = xs32(seed); cmd_key[i] = $unsigned(seed) % NK; end
            else begin kseed = xs32(kseed); cmd_key[i] = $unsigned(kseed) % NK; end
            if (key_mode == 1) cmd_key[i] = 1 % NK;                  // leak tests: overwrite the drawn key
            else if (key_mode == 2) cmd_key[i] = i % NK;
            else if (key_mode == 3 && i > 0 && cmd_key[i-1] < NK) cmd_key[i] = cmd_key[i-1];   // never repeat run2's planted bad key
            cmd_off[i] = 0; cmd_len[i] = 0;                         // whole block
            if (rec_len > 0) begin                                   // one record of the block
                seed = xs32(seed); cmd_off[i] = ($unsigned(seed) % (BEATS*32/rec_len)) * rec_len;
                cmd_len[i] = rec_len;
            end
            if (i == bad_at && !badtok) begin
                if (rec_len > 0) begin cmd_type[i] = 2; cmd_off[i] = BEATS*32 - rec_len + 4; end   // runs past the block end
                else cmd_key[i] = NK + 5;                           // outside the ORAM's n blocks: must be rejected
            end
            cmd_id[i] = gid; gid = gid + 1;
            key_h = (key_h * 64'd31) ^ cmd_key[i];                   // the run's key sequence (diagnostic)
            u_cmd.mem[i] = {{(DW-128){1'b0}}, cmd_len[i][31:0], cmd_off[i][31:0], cmd_key[i][31:0], 24'd0, cmd_type[i][7:0]};
            if (cmd_type[i] == 2) for (j = 0; j < BEATS; j = j + 1) begin
                if (rec_len > 0) seed = xs32(seed);
                u_cmd.mem[hcw + i*BEATS + j] = pat(cmd_id[i], j, cmd_key[i]) ^ ((rec_len > 0) ? {DW/32{seed[31:0]}} : {DW{1'b0}});
            end
        end
    end endtask

    // +preload: like host_doma's initialization, PUT every key once, in order 0..n-1 (n = +nblk, else N)
    task prepare_seq; input integer size; integer i, j, hcw; begin
        hcw = (((size * 32) + 4095) / 4096) * 4096 / 32;
        for (i = 0; i < size; i = i + 1) begin
            cmd_type[i] = 2; cmd_key[i] = i % NK; cmd_id[i] = gid; gid = gid + 1; cmd_off[i] = 0; cmd_len[i] = 0;
            u_cmd.mem[i] = {{(DW-64){1'b0}}, cmd_key[i][31:0], 24'd0, cmd_type[i][7:0]};
            for (j = 0; j < BEATS; j = j + 1) u_cmd.mem[hcw + i*BEATS + j] = pat(cmd_id[i], j, cmd_key[i]);
        end
    end endtask

    // start a run like xrt::run, wait for ap_done, then check every response
    // the testbench's own count of handshaked beats on gmem2, per launch (checked against record [size+1])
    reg [63:0] tb_rd = 0, tb_wr = 0;
    // +badtok: run 2's rejected command stays valid, but the kernel's token is corrupted while it is requested,
    // so the core flags a lease violation and the kernel's viol_q path runs (unreachable from host commands).
    always @(posedge clk) if (badtok && !bt_done && dut.lease_ok && dut.idx == bt_at) begin
        if (!bt_arm && dut.kst == 6'd6) begin bt_save = dut.c_token; dut.c_token = ~dut.c_token; bt_arm = 1; end   // K_REQ
        else if (bt_arm && dut.kst == 6'd31) begin dut.c_token = bt_save; bt_arm = 0; bt_done = 1; end            // K_REQ_V
    end
    reg [31:0] tb_acc = 0;                       // DOMA accesses completed in this launch, rejected commands' dummies included
    always @(posedge clk) begin
        if (dut.c_done) tb_acc <= tb_acc + 1;                           // every DOMA access is a command (no boot pass)
        if (g2_rvalid && g2_rready) tb_rd <= tb_rd + 1;
        if (g2_wvalid && g2_wready) tb_wr <= tb_wr + 1;
    end
    task run; input integer size; input integer bad_at; input [8*8-1:0] name;
        integer i, j, b, hcw, hrw, t0, t1, bad, gets, puts, rej; reg [31:0] v; reg [DW-1:0] exp, got, sum, nd, trf; begin
        hcw = (((size * 32) + 4095) / 4096) * 4096 / 32;
`ifdef ORAM_ONPKG_DEBUG
        hrw = ((((size + 5) * 32) + 4095) / 4096) * 4096 / 32;              // after records [size] .. [size+4] (debug)
`else
        hrw = ((((size + 2) * 32) + 4095) / 4096) * 4096 / 32;              // after records [size], [size+1]
`endif
        for (i = 0; i <= size; i = i + 1) u_resp.mem[i] = {DW{1'b1}};          // poison the headers
        if (bad_at >= 0) for (j = 0; j < BEATS; j = j + 1) u_resp.mem[hrw + bad_at*BEATS + j] = {DW{1'b1}};   // and the rejected data slot
        bt_at = bad_at; bt_done = 0;
        axil_wr(12'h010, CMD_BASE[31:0]);  axil_wr(12'h014, CMD_BASE[63:32]);
        axil_wr(12'h01C, RESP_BASE[31:0]); axil_wr(12'h020, RESP_BASE[63:32]);
        axil_wr(12'h028, HOST_BASE[31:0] + PAGES_OFF[31:0]); axil_wr(12'h02C, HOST_BASE[63:32]);
        axil_wr(12'h03C, META_BASE[31:0]); axil_wr(12'h040, META_BASE[63:32]);
        axil_wr(12'h048, BREC_BASE[31:0]); axil_wr(12'h04C, BREC_BASE[63:32]);
        axil_wr(12'h054, STASH_BASE[31:0]); axil_wr(12'h058, STASH_BASE[63:32]);
        axil_wr(12'h060, NBLK);                                             // run-time blocks
        axil_wr(12'h068, HBMB_BASE[31:0]); axil_wr(12'h06C, HBMB_BASE[63:32]);
        axil_wr(12'h074, (((NK + `ORAM_C - 1) / `ORAM_C) * HBM_PCT) / 100);   // buckets in HBM
        axil_wr(12'h07C, POOL);                                             // stash pool entries
        axil_wr(12'h034, (ph_trace && size > 0) ? (size | 32'h8000_0000) : size);   // v14 +phase_trace: bit 31, a trace record per command
        axil_wr(12'h004, 32'h1); axil_wr(12'h008, 32'h1);                      // interrupts on
        t0 = u_cmd.cyc;
        tb_rd = 0; tb_wr = 0; tb_acc = 0; ph_k = 0;                             // this launch's gmem2 beats and accesses
        launch_name = name;                                                     // leak tests: the access log's launch column
        sh_h = 64'hCBF29CE484222325; sh_n = 0; op_h = 64'hCBF29CE484222325; op_n = 0;   // v14 observables (below)
        op_rmin = 32'h7FFFFFFF; op_rmax = 0; op_emin = 32'h7FFFFFFF; op_emax = 0;
        axil_wr(12'h000, 32'h1);                                                // ap_start
        v = 0;
        while (!v[1]) begin repeat (200) @(posedge clk); axil_rd(12'h000, v); end
        t1 = u_cmd.cyc;
        if (!irq) begin $display("FAIL %0s: interrupt not raised", name); fails = fails + 1; end
        axil_wr(12'h00C, 32'h1);                                                // clear ISR
        @(posedge clk); @(posedge clk);
        if (irq) begin $display("FAIL %0s: interrupt not cleared", name); fails = fails + 1; end
        axil_rd(12'h000, v);
        if (!v[2] || v[1] || v[0]) begin $display("FAIL %0s: CTRL after done = %h (want idle, done cleared)", name, v); fails = fails + 1; end
        bad = 0; gets = 0; puts = 0; rej = 0;
        for (i = 0; i < size; i = i + 1) begin
            got = u_resp.mem[i];
            if (i == bad_at) begin
                if (got[7:0] !== 8'h11 || got[127:96] !== ((rec_len > 0 && !badtok) ? 32'h40 : 32'h4)) begin bad = bad + 1;
                    $display("FAIL %0s: cmd %0d (key %0d outside the ORAM) not rejected: type %h status %h", name, i, cmd_key[i], got[7:0], got[127:96]); end
                else rej = rej + 1;
                for (j = 0; j < BEATS; j = j + 1)       // as an admitted command's: a GET's slot gets zeros, a PUT's stays untouched
                    if (u_resp.mem[hrw + i*BEATS + j] !== ((cmd_type[i] == 2) ? {DW{1'b1}} : {DW{1'b0}})) begin
                        if (bad < 4) $display("FAIL %0s: rejected cmd %0d (type %0d) data beat %0d is not %0s", name, i, cmd_type[i], j, (cmd_type[i] == 2) ? "untouched" : "zero");
                        bad = bad + 1; j = BEATS;
                    end
            end else if (got[7:0] !== 8'h10 || got[63:32] !== cmd_key[i]) begin
                bad = bad + 1;
                if (bad < 4) $display("FAIL %0s: cmd %0d header type %h key %0d status %h", name, i, got[7:0], got[63:32], got[127:96]);
            end else if (cmd_type[i] == 2) begin
                last_put[cmd_key[i]] = cmd_id[i]; puts = puts + 1;
                if (rec_len > 0) for (j = 0; j < BEATS; j = j + 1) begin      // the record's bytes land, nothing else
                    nd = u_cmd.mem[hcw + i*BEATS + j];
                    for (b = 0; b < DW/8; b = b + 1)
                        if (cmd_len[i] == 0 || (j*32 + b >= cmd_off[i] && j*32 + b < cmd_off[i] + cmd_len[i]))   // 0 = whole block
                            refimg[cmd_key[i]*BEATS + j][8*b +: 8] = nd[8*b +: 8];
                end
            end else if (rec_len > 0) begin
                gets = gets + 1;
                for (j = 0; j < BEATS; j = j + 1)
                    if (u_resp.mem[hrw + i*BEATS + j] !== refimg[cmd_key[i]*BEATS + j]) begin
                        if (bad < 4) $display("FAIL %0s: GET cmd %0d key %0d beat %0d differs from the block image (record or neighbour)", name, i, cmd_key[i], j);
                        bad = bad + 1; j = BEATS;
                    end
            end else begin
                gets = gets + 1;
                for (j = 0; j < BEATS; j = j + 1) begin
                    exp = (last_put[cmd_key[i]] < 0) ? {DW{1'b0}} : pat(last_put[cmd_key[i]], j, cmd_key[i]);
                    if (u_resp.mem[hrw + i*BEATS + j] !== exp) begin
                        if (bad < 4) $display("FAIL %0s: GET cmd %0d key %0d beat %0d data mismatch", name, i, cmd_key[i], j);
                        bad = bad + 1; j = BEATS;
                    end
                end
            end
        end
        sum = u_resp.mem[size];
        if (sum[223:192] == 0 && tb_acc != size) begin                          // rejected commands make a dummy access too (no halt)
            $display("FAIL %0s: %0d DOMA accesses for %0d commands (every command, rejected or not, makes one)", name, tb_acc, size);
            fails = fails + 1;
        end
        $display("%0s: size=%0d  host cycles=%0d  device total=%0d  completed=%0d  latency min/max=%0d/%0d  errors=%h  gets=%0d puts=%0d rejected=%0d  bad=%0d",
                 name, size, t1 - t0, sum[127:64], sum[255:224], sum[159:128], sum[191:160], sum[223:192], gets, puts, rej, bad);
        if (sum[7:0] !== 8'h5A || sum[63:32] !== `BEATS_PER_BLOCK ||        // bytes 4-7: block size in beats
            sum[255:224] !== size - (bad_at >= 0 ? 1 : 0) || sum[223:192] !== 0) begin
            $display("FAIL %0s: summary record wrong", name); fails = fails + 1; end
        trf = u_resp.mem[size + 1];                                             // traffic record [size+1]
        if (ph_trace && size > 0) ph_check(size, hrw, name);
        if (sum[195]) halt_decode(sum, name);                                   // a halted launch: its halt record
        // +halt_wait=N: after a halted launch, N cycles before the next (the card's launches are far apart: the halting
        // access ends meanwhile, and the next summary's halt record holds the final missed time)
        if (sum[195] && $value$plusargs("halt_wait=%d", j)) repeat (j) @(posedge clk);
`ifdef ORAM_ONPKG_DEBUG
        dbg_check(size, hrw, name);
`endif
        $display("%0s: bucket-port timing hash %h over %0d requests (keys %h)", name, bus_h, bus_n, key_h);
        $display("%0s: off-package access shape hash %h over %0d accesses", name, sh_h, sh_n);
        if (op_n > 0)
            $display("%0s: on-package release/end hash %h over %0d accesses (release %0d..%0d, end %0d..%0d cycles after the access start)",
                     name, op_h, op_n, op_rmin, op_rmax, op_emin, op_emax);
        $display("%0s: traffic record: read beats %0d, write beats %0d on the bucket port (testbench saw %0d / %0d)",
                 name, trf[127:64], trf[191:128], tb_rd, tb_wr);
        if (trf[7:0] !== 8'h5B || trf[127:64] !== tb_rd || trf[191:128] !== tb_wr || trf[255:192] !== 0) begin
            $display("FAIL %0s: traffic record wrong", name); fails = fails + 1; end
        fails = fails + bad;
    end endtask

    initial begin : main
        integer k; reg [31:0] v;
        if (!$value$plusargs("seed=%d", seed)) seed = 7;
        kseed = seed + 1000;                                   // +put_pct: operations and keys only
        if ($value$plusargs("nblk=%d", NBLK)) NK = (NBLK == 0 || NBLK > N) ? N : NBLK;
        if (!$value$plusargs("cmds=%d", ncmd1)) ncmd1 = 120;
        if (!$value$plusargs("cmds2=%d", ncmd2)) ncmd2 = 40;
        if ($value$plusargs("host_lat=%d", hl)) u_host.lat = hl;
        if ($value$plusargs("hbm_pct=%d", hl)) HBM_PCT = hl;
        if ($value$plusargs("pool=%d", hl)) POOL = hl;
        if ($test$plusargs("badtok")) badtok = 1;
        if ($value$plusargs("hbmb_lat=%d", hl)) u_hbmb.lat = hl;

        if ($value$plusargs("host_gap=%d", hg)) u_host.gap_pct = hg;
        if ($value$plusargs("host_wlat=%d", hg)) u_host.wlat = hg;   // writes land late: reads can overtake them
        if ($value$plusargs("host_rdy_gap=%d", hg)) begin u_host.rdy_gap = hg; u_cmd.rdy_gap = hg; u_resp.rdy_gap = hg; end
        for (k = 0; k < N; k = k + 1) last_put[k] = -1;
        // v14 +junk_mem: the bucket memories start with junk, so the boot's format must really write every bucket
        // (an on-package bucket's zeros included) for never-written blocks to read and inspect as zeros
        if ($test$plusargs("junk_mem")) begin
            for (k = 0; k < (`ORAM_B * `BUCKET_BYTES) / 32 + 64; k = k + 1) u_hbmb.mem[k] = {8{32'hDEAD0000 | k[15:0]}};
            for (k = 0; k < ((`ORAM_N > 4096) ? (1 << 20) : ((`ORAM_N << 13) / 32)); k = k + 1) u_host.mem[k] = {8{32'hBEEF0000 | k[15:0]}};
        end
        if ($value$plusargs("packed=%d", rec_len)) begin
            if (rec_len <= 0 || rec_len > BEATS*32 || (BEATS*32) % rec_len != 0) begin
                $display("FAIL: +packed=%0d must divide the %0d-byte block", rec_len, BEATS*32); fails = fails + 1; rec_len = 0; end
            for (k = 0; k < N*BEATS; k = k + 1) refimg[k] = {DW{1'b0}};
            $display("packed records: %0d bytes, %0d per block", rec_len, (rec_len > 0) ? BEATS*32/rec_len : 0);
        end
        $display("tb_doma_kernel | %0s | N=%0d block=%0d B | host read latency %0d cycles, gaps %0d%%, writes land after %0d cycles",
                 `ORAM_PKG_REV, N, BEATS*32, u_host.lat, u_host.gap_pct, u_host.wlat);
        $fflush;
        repeat (20) @(posedge clk); rst_n = 1;
        axil_rd(12'h000, v);
        if (!v[2]) begin $display("FAIL: kernel not idle after reset (CTRL=%h)", v); fails = fails + 1; end
        // +start_delay=N: the host launches the kernel only N cycles after reset (XRT and emulation
        // take far longer than this testbench); the kernel must not touch memory before that
        if ($value$plusargs("start_delay=%d", k)) repeat (k) @(posedge clk);
        run(0, -1, "init");                                         // boot + key + lease, like init_kernel
        if ($test$plusargs("preload")) begin prepare_seq(NK); run(NK, -1, "preload"); end   // every key of the n blocks once
        prepare(ncmd1, -1); run(ncmd1, -1, "run1");
        if ($test$plusargs("no_bad")) begin prepare(ncmd2, -1); run(ncmd2, -1, "run2"); end   // leak tests: run2 with no rejected command
        else begin
        prepare(ncmd2, ncmd2 / 2); run(ncmd2, ncmd2 / 2, "run2");     // second launch, lease reused, one bad key (packed: one bad record range)
        end
        // +reboot: an init launch on the booted kernel re-boots DOMA with new arguments (+nblk2, +pagesoff),
        // as a new host process does. Every block then reads as zeros, and commands must run without 0x20.
        if ($test$plusargs("reboot")) begin
            if ($value$plusargs("nblk2=%d", v)) begin NBLK = v; NK = (NBLK == 0 || NBLK > N) ? N : NBLK; end
            if ($value$plusargs("pagesoff=%d", v)) PAGES_OFF = v;
            for (k = 0; k < N*BEATS; k = k + 1) refimg[k] = {DW{1'b0}};
            run(0, -1, "reinit");
            prepare(ncmd1, -1); run(ncmd1, -1, "run3");
        end
        if (u_hbmb.errors) begin $display("FAIL: memory errors on the HBM bucket port: %0d", u_hbmb.errors); fails = fails + 1; end
        if (u_cmd.errors || u_resp.errors || u_host.errors || u_meta.errors || u_brec.errors || u_stmem.errors) begin
            $display("FAIL: memory errors (out of range or AXI protocol): cmd %0d resp %0d host %0d meta %0d brec %0d stash %0d (protocol %0d/%0d/%0d/%0d/%0d/%0d)", u_cmd.errors, u_resp.errors, u_host.errors, u_meta.errors, u_brec.errors, u_stmem.errors, u_cmd.perr, u_resp.perr, u_host.perr, u_meta.perr, u_brec.perr, u_stmem.perr);
            fails = fails + 1; end
`ifdef TB_V11G_REF
        $display("calib: ar_max_wb=%0d ar_max_wb_h=%0d ct_max_wb=%0d ct_max_done=%0d", dut.u_doma.u_oram.ar_max_wb, dut.u_doma.u_oram.ar_max_wb_h, dut.u_doma.u_oram.ct_max_wb, dut.u_doma.u_oram.ct_max_done);
`else
        $display("calib: ar_max_wb=%0d ar_max_wb_h=%0d ct_max_wb=%0d ct_max_done=%0d ar_max_rel_h=%0d", dut.u_doma.u_oram.ar_max_wb, dut.u_doma.u_oram.ar_max_wb_h, dut.u_doma.u_oram.ct_max_wb, dut.u_doma.u_oram.ct_max_done, dut.u_doma.u_oram.ar_max_rel_h);
`endif
        if ($value$plusargs("inspect=%s", insp_fn)) inspect_dump;   // worst encryption end after the arrival, from the start; worst completion
        if (fails == 0) $display("*** DOMA KERNEL: ALL CHECKS PASSED ***");
        else            $display("*** DOMA KERNEL: %0d FAILURE(S) ***", fails);
        bw_report; $finish;
    end
    // ---------------- v14: phase trace (+phase_trace, builds with ORAM_PHASE_TRACE) ----------------
    // Every command's 16-slot trace record (doma_kernel.v): an on-package access has no crypto, so its decryption
    // (slot 5 to 6) and re-encryption (slot 8 to 10) must take zero cycles, with every slot present (but 9, the strict
    // write-back gate) and in order; an off-package access's crypto phases must take time.
    reg ph_trace = 0; integer ph_k = 0; reg ph_hbm [0:4095];
    initial ph_trace = $test$plusargs("phase_trace");
    always @(posedge clk) if (dut.c_done) begin ph_hbm[ph_k % 4096] = dut.u_doma.u_oram.acc_hbm; ph_k = ph_k + 1; end
    task ph_check; input integer size; input integer hrw; input [8*8-1:0] name;
        integer i, k, bad, non, noff; reg [255:0] r; reg [15:0] t [0:15]; reg ok; begin
        bad = 0; non = 0; noff = 0;
        if (ph_k != size) begin $display("FAIL %0s: %0d accesses for %0d trace records", name, ph_k, size); bad = bad + 1; end
        for (i = 0; i < size && i < 4096; i = i + 1) begin
`ifdef ORAM_ONPKG_DEBUG
            r = u_resp.mem[hrw + size * BEATS + 4 * i];                          // debug: 128-byte records (v14c), beat 0
`else
            r = u_resp.mem[hrw + size * BEATS + i];
`endif
            for (k = 0; k < 16; k = k + 1) t[k] = r[16*k +: 16];
            if (ph_hbm[i]) begin
                non = non + 1;
                ok = (t[5] == t[6]) && (t[8] == t[10]) && (t[9] == 0);
                for (k = 0; k < 15; k = k + 1) if (k != 8 && k != 9 && t[k] > t[k+1]) ok = 0;
                if (t[8] > t[10] || t[10] > t[11]) ok = 0;
                for (k = 0; k < 16; k = k + 1) if (k != 9 && t[k] == 0) ok = 0;
            end else begin
                noff = noff + 1;
                ok = (t[5] < t[6]) && (t[8] < t[10]);
            end
            if (!ok) begin
                if (bad < 3) $display("FAIL %0s: command %0d (%0s package) trace %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d", name, i,
                                      ph_hbm[i] ? "on" : "off", t[0], t[1], t[2], t[3], t[4], t[5], t[6], t[7], t[8], t[9], t[10], t[11], t[12], t[13], t[14], t[15]);
                bad = bad + 1;
            end
        end
        $display("%0s: phase trace: %0d on-package records with zero-length crypto phases and every slot in order, %0d off-package records with timed crypto phases; %0d bad",
                 name, non, noff, bad);
        fails = fails + bad;
    end endtask
    // ---------------- v14b: the halt record (every build) ----------------
    // decoded from the summary's latency fields, as host_doma prints it; and, for the access that raised the first
    // timing overrun, the testbench's own times after its arrival (to check the record's deadline and missed time)
    task halt_decode; input [255:0] sm; input [8*8-1:0] name;
        reg [63:0] h; begin
        h = {sm[191:160], sm[159:128]};
        if (h[16])
            $display("%0s: halt record: state %0d, access cycle %0d, bucket %0d (%0s), on-package deadline %0s, missed by at least %0d cycles (still running), memory-unit errors %b",
                     name, h[39:35], h[15:0], h[63:40], h[34] ? "HBM" : "host",
                     (h[33:32] == 2'b01) ? "(1) write-back start" : (h[33:32] == 2'b10) ? "(2) hand-off by the release" :
                     (h[33:32] == 2'b11) ? "scratch bank conflict" : "none", h[31:20], h[19:17]);
        else
            $display("%0s: halt record: state %0d, access cycle %0d, bucket %0d (%0s), on-package deadline %0s, missed by %0d cycles, memory-unit errors %b",
                     name, h[39:35], h[15:0], h[63:40], h[34] ? "HBM" : "host",
                     (h[33:32] == 2'b01) ? "(1) write-back start" : (h[33:32] == 2'b10) ? "(2) hand-off by the release" :
                     (h[33:32] == 2'b11) ? "scratch bank conflict" : "none", h[31:20], h[19:17]);
    end endtask
    integer hz_on = 0, hz_ea = -1, hz_dg = -1; reg hz_q = 0;      // the halting access (the first overrun's): its times
    always @(posedge clk) begin : halt_access
        reg [4:0] st;
        st = dut.u_doma.u_oram.state;
        hz_q <= dut.u_doma.u_oram.err_ct_overrun_r;
        if (st == 5'd1 && hz_on != 1) hz_ea = -1;                          // an access starts (its write-back not issued)
        if (st == 5'd20 && hz_ea < 0 && hz_on != 2) hz_ea = dut.u_doma.u_oram.ct_cnt - dut.u_doma.u_oram.t_arr;
        if (dut.u_doma.u_oram.err_ct_overrun_r && !hz_q && hz_on == 0) begin hz_on = 1; hz_dg = -1; end
        if (hz_on == 1) begin
            if (st == 5'd23 && hz_dg < 0) begin
                hz_dg = dut.u_doma.u_oram.ct_cnt - dut.u_doma.u_oram.t_arr; hz_on = 2;
                $display("HALTING-ACCESS: write-back issued %0d and release gate reached %0d cycles after the arrival (AR_WB_H %0d, AR_REL_H %0d)",
                         hz_ea, hz_dg, `ORAM_AR_WB_H, `ORAM_AR_REL_H);
            end
        end
    end
`ifdef ORAM_ONPKG_DEBUG
    // ---------------- v14b debug build: the core's records against the testbench's own observation ----------------
    // Per access (relative to its start, which is the core's access cycle): S_EA_START and S_DONE_GATE entered, the
    // core's bucket-port W/AR/R handshakes, the end; then every 128-byte trace record's second beat must hold exactly
    // these, its deadline flags must follow from them, and the counters and snapshot records must match the tallies.
    integer d_k = 0, dt_acc = 0, dt_on = 0, dt_n1 = 0, dt_n2 = 0, dt_by1 = 0, dt_by2 = 0, dt_wb = 0, dt_rel = 0;
    integer dt_fa = -1, dt_fa_ev = 0, dt_fa_by = 0, dt_fb = -1, dt_fb_by = 0;   // first overrun / first deadline (2) miss
    integer x_ea [0:4095]; integer x_dg [0:4095]; integer x_wf [0:4095]; integer x_wl [0:4095]; integer x_ar [0:4095];
    integer x_r1 [0:4095]; integer x_end [0:4095]; integer x_ta [0:4095]; reg x_byp [0:4095];
    integer c_ea = -1, c_dg = -1, c_wf = -1, c_wl = -1, c_ar = -1, c_r1 = -1, c_t0 = 0; reg c_on = 0; reg [4:0] c_ps = 0;
    always @(posedge clk) begin : dbg_obs
        reg [4:0] st; integer ct;
        st = dut.u_doma.u_oram.state; ct = cyc_tb - c_t0;
        if (st == 5'd1 && c_ps == 5'd0) begin c_on = 1; c_t0 = cyc_tb; ct = 0; c_ea = -1; c_dg = -1; c_wf = -1; c_wl = -1; c_ar = -1; c_r1 = -1; end
        if (c_on) begin
            if (dut.u_doma.u_oram.axim_cmd_write && c_ea < 0) c_ea = ct - 1;
            if (st == 5'd23 && c_dg < 0) c_dg = ct;
            if (dut.u_doma.u_oram.m_axi_wvalid && dut.u_doma.u_oram.m_axi_wready) begin c_wl = ct; if (c_wf < 0) c_wf = ct; end
            if (dut.u_doma.u_oram.m_axi_arvalid && dut.u_doma.u_oram.m_axi_arready && c_ar < 0) c_ar = ct;
            if (dut.u_doma.u_oram.m_axi_rvalid && dut.u_doma.u_oram.m_axi_rready && c_r1 < 0) c_r1 = ct;
        end
        if (dut.c_done) begin
            x_ea[d_k % 4096] = c_ea; x_dg[d_k % 4096] = c_dg; x_wf[d_k % 4096] = c_wf; x_wl[d_k % 4096] = c_wl;
            x_ar[d_k % 4096] = c_ar; x_r1[d_k % 4096] = c_r1; x_end[d_k % 4096] = ct - 1;
            x_ta[d_k % 4096] = dut.u_doma.u_oram.t_arr; x_byp[d_k % 4096] = dut.u_doma.u_oram.acc_hbm;
            d_k = d_k + 1; c_on = 0;
        end
        c_ps <= st;
    end
    function [15:0] f16; input integer x; begin f16 = (x < 0) ? 16'hFFFF : x[15:0]; end endfunction
    // +dbg_csv=FILE: every per-access record as one CSV line, the format host_phases writes (DOMA_ONPKG_CSV), so
    // sim/card_budgets.py can be run on simulation output as on the card's
    integer dbg_fd = 0, dbg_launch = 0; reg [8*256-1:0] dbg_fn;
    initial if ($value$plusargs("dbg_csv=%s", dbg_fn)) begin
        dbg_fd = $fopen(dbg_fn, "w");
        $fdisplay(dbg_fd, "launch,cmd,flags,tarr,ea,dg,wl,wf,bm,so,sx,se,cl,wst,wsv,ar,r1,end,s0,s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15");
    end
    // v14c: the access's stash open, as the testbench sees the stash port (the core's rules: from the cycle after the
    // open is issued until the stash is ready, at least 4 cycles later; per access, cleared in S_IDLE; access cycles)
    integer so_nr = 0, so_nb = 0, so_ar1 = -1, so_r1 = -1, so_rl = -1, so_end = -1, so_arw = 0, so_lmax = 0, so_age = 0;
    integer so_q [0:63]; integer so_wp = 0, so_rp = 0; reg so_on = 0, so_first = 1;
    integer y_nr [0:4095]; integer y_nb [0:4095]; integer y_ar1 [0:4095]; integer y_r1 [0:4095]; integer y_rl [0:4095];
    integer y_end [0:4095]; integer y_arw [0:4095]; integer y_lmax [0:4095];
    integer so_k = 0;
    always @(posedge clk) begin : st_obs
        integer ct, l;
        ct = dut.u_doma.u_oram.ct_cnt[15:0];
        // the kernel takes the core's record at c_done, before this edge's updates (and before the reset in S_IDLE)
        if (dut.c_done) begin
            y_nr[so_k % 4096] = so_nr; y_nb[so_k % 4096] = so_nb; y_ar1[so_k % 4096] = so_ar1; y_r1[so_k % 4096] = so_r1;
            y_rl[so_k % 4096] = so_rl; y_end[so_k % 4096] = so_end; y_arw[so_k % 4096] = so_arw; y_lmax[so_k % 4096] = so_lmax;
            so_k = so_k + 1;
        end
        if (dut.u_doma.u_oram.state == 5'd0) begin
            so_nr = 0; so_nb = 0; so_ar1 = -1; so_r1 = -1; so_rl = -1; so_end = -1; so_arw = 0; so_lmax = 0;
            so_on = 0; so_age = 0; so_wp = 0; so_rp = 0; so_first = 1;
        end else if (dut.u_doma.u_oram.fmt_done_r) begin
            if (so_on) begin
                if (dut.u_doma.u_oram.m_stash_arvalid && dut.u_doma.u_oram.m_stash_arready) begin
                    so_q[so_wp % 64] = ct; so_wp = so_wp + 1; so_nr = so_nr + 1; if (so_ar1 < 0) so_ar1 = ct; end
                if (dut.u_doma.u_oram.m_stash_arvalid && !dut.u_doma.u_oram.m_stash_arready) so_arw = so_arw + 1;
                if (dut.u_doma.u_oram.m_stash_rvalid && dut.u_doma.u_oram.m_stash_rready) begin
                    so_nb = so_nb + 1; so_rl = ct; if (so_r1 < 0) so_r1 = ct;
                    if (so_first) begin l = (ct - so_q[so_rp % 64]) & 16'hFFFF; if (l > so_lmax) so_lmax = l; so_first = 0; end
                    if (dut.u_doma.u_oram.m_stash_rlast) begin so_rp = so_rp + 1; so_first = 1; end
                end
                if (dut.u_doma.u_oram.st_ready && so_age >= 4) begin so_on = 0; so_end = ct; end
                if (so_age < 15) so_age = so_age + 1;
            end
            if (dut.u_doma.u_oram.st_open_en) begin so_on = 1; so_age = 0; end
        end
    end
    task dbg_check; input integer size; input integer hrw; input [8*8-1:0] name;
        integer i, k, bad, wb, rl, f1, f2, sbad, sopen; reg [255:0] r, r2, r3, cr, sa, sb; reg [15:0] w [0:15]; reg [15:0] x [0:15]; begin
        sbad = 0; sopen = 0;
        bad = 0; dbg_launch = dbg_launch + 1;
        if (d_k != size) begin $display("FAIL %0s: %0d accesses for %0d records", name, d_k, size); bad = bad + 1; end
        for (i = 0; i < size && i < 4096; i = i + 1) begin
            r  = ph_trace ? u_resp.mem[hrw + size * BEATS + 4 * i + 1] : 256'd0;
            r2 = ph_trace ? u_resp.mem[hrw + size * BEATS + 4 * i + 2] : 256'd0;
            r3 = ph_trace ? u_resp.mem[hrw + size * BEATS + 4 * i + 3] : 256'd0;
            if (!ph_trace) i = size;
            else begin
                for (k = 0; k < 16; k = k + 1) begin w[k] = r[16*k +: 16]; x[k] = r2[16*k +: 16]; end
                if (dbg_fd != 0) $fdisplay(dbg_fd, "%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d", dbg_launch, i,
                                           w[1], w[0], w[2], w[3], w[4], w[5], w[6], w[7], w[8], w[9], w[10], w[11], w[12], w[13], w[14], w[15],
                                           x[0], x[1], x[2], x[3], x[4], x[5], x[6], x[7], x[8], x[9], x[10], x[11], x[12], x[13], x[14], x[15]);
                // v14c: the stash open (beat 2) against the testbench's view of the stash port; beat 3 is zero
                if (x[15] != 16'hFFFF) sopen = sopen + 1;
                if (x[0][15:8] != ((y_nr[i] > 255) ? 255 : y_nr[i]) || x[1] != y_nb[i][15:0] || x[2] != f16(y_ar1[i]) || x[3] != f16(y_r1[i]) ||
                    x[5] != f16(y_rl[i]) || x[15] != f16(y_end[i]) || x[8] != y_arw[i][15:0] || x[6] != y_lmax[i][15:0] || r3 != 256'd0 ||
                    (x[15] != 16'hFFFF && (x[2] > x[3] || x[3] > x[5] || x[5] > x[15] || (x[4] != 16'hFFFF && x[4] > x[5] + 16'd1)))) begin
                    if (sbad < 4) $display("FAIL %0s: access %0d stash open record reads %0d beats %0d AR1 %0d R1 %0d last %0d ready %0d AR-wait %0d longest %0d, the testbench saw %0d %0d %0d %0d %0d %0d %0d %0d",
                        name, i, x[0][15:8], x[1], x[2], x[3], x[5], x[15], x[8], x[6], y_nr[i], y_nb[i], y_ar1[i], y_r1[i], y_rl[i], y_end[i], y_arw[i], y_lmax[i]);
                    sbad = sbad + 1;
                end
                if (w[0] != f16(x_ta[i]) || w[2] != f16(x_ea[i]) || w[3] != f16(x_dg[i]) || w[4] != f16(x_wl[i]) || w[5] != f16(x_wf[i]) ||
                    w[13] != f16(x_ar[i]) || w[14] != f16(x_r1[i]) || w[15] != f16(x_end[i]) || w[1][0] != x_byp[i]) begin
                    if (bad < 4) $display("FAIL %0s: access %0d record %0d %0d %0d %0d %0d %0d %0d %0d %0d, the testbench saw %0d %0d %0d %0d %0d %0d %0d %0d %0d", name, i,
                        w[0], w[2], w[3], w[4], w[5], w[13], w[14], w[15], w[1][0], x_ta[i], x_ea[i], x_dg[i], x_wl[i], x_wf[i], x_ar[i], x_r1[i], x_end[i], x_byp[i]);
                    bad = bad + 1;
                end
                dt_acc = dt_acc + 1;
                if (w[1][1]) begin                                        // on the plaintext path: the deadlines
                    wb = w[2] - w[0]; rl = w[3] - w[0]; f1 = (wb > `ORAM_AR_WB_H); f2 = (rl > `ORAM_AR_REL_H);
                    dt_on = dt_on + 1;
                    if (w[1][2] != f1 || w[1][3] != f2) begin
                        if (bad < 4) $display("FAIL %0s: access %0d flags d1 %0d d2 %0d, but write-back %0d / release gate %0d after the arrival", name, i, w[1][2], w[1][3], wb, rl);
                        bad = bad + 1;
                    end
                    if (wb > dt_wb) dt_wb = wb; if (rl > dt_rel) dt_rel = rl;
                    if (f1) begin dt_n1 = dt_n1 + 1; if (wb - `ORAM_AR_WB_H > dt_by1) dt_by1 = wb - `ORAM_AR_WB_H; end
                    if (f2) begin dt_n2 = dt_n2 + 1; if (rl - `ORAM_AR_REL_H > dt_by2) dt_by2 = rl - `ORAM_AR_REL_H; end
                    if ((f1 || f2 || w[1][4]) && dt_fa < 0) begin dt_fa = dt_acc - 1; dt_fa_ev = f1 ? 1 : f2 ? 2 : 3;
                        dt_fa_by = f1 ? wb - `ORAM_AR_WB_H : f2 ? rl - `ORAM_AR_REL_H : 0; end
                    if (f2 && dt_fb < 0) begin dt_fb = dt_acc - 1; dt_fb_by = rl - `ORAM_AR_REL_H; end
                end
            end
        end
        // the counters [size+2] and the snapshots [size+3], [size+4]
        cr = u_resp.mem[size + 2]; sa = u_resp.mem[size + 3]; sb = u_resp.mem[size + 4];
        $display("%0s: debug counters: %0d on-package accesses since boot, deadline (1) missed %0d (worst by %0d), deadline (2) missed %0d (worst by %0d), bank conflicts %0d; worst write-back start %0d, release gate %0d, stash ready %0d cycles after the arrival (AR_WB_H %0d, AR_REL_H %0d)",
                 name, cr[95:64], cr[127:96], cr[63:48], cr[159:128], cr[207:192], cr[191:160], cr[223:208], cr[239:224], cr[255:240], cr[31:16], cr[47:32]);
        if (ph_trace && (cr[7:0] !== 8'h5C || cr[95:64] != dt_on || cr[127:96] != dt_n1 || cr[159:128] != dt_n2 || cr[63:48] != dt_by1 ||
            cr[207:192] != dt_by2 || cr[223:208] != dt_wb || cr[239:224] != dt_rel || cr[31:16] != `ORAM_AR_WB_H || cr[47:32] != `ORAM_AR_REL_H)) begin
            $display("FAIL %0s: debug counters differ from the records' tally (%0d on package, %0d / %0d misses, worst by %0d / %0d, worst %0d / %0d)",
                     name, dt_on, dt_n1, dt_n2, dt_by1, dt_by2, dt_wb, dt_rel);
            bad = bad + 1;
        end
        if (sa[7:0] == 8'h5D)
            $display("%0s: debug first overrun: deadline %0d, state %0d, access %0d, access cycle %0d, %0d cycles after the arrival, missed by %0d; %0d copy beats landed, %0d of %0d copies done, %0d bucket beats written; bucket port AW-W %0d, W-B %0d, AR-R %0d, levels %b; stash port AW-W %0d, W-B %0d, AR-R %0d, levels %b; flags %b",
                     name, sa[9:8], sa[20:16], sa[63:32], sa[79:64], sa[95:80], sa[111:96], sa[127:112], sa[135:132], sa[131:128], sa[159:144],
                     $signed(sa[167:160]), $signed(sa[175:168]), $signed(sa[183:176]), sa[191:184], $signed(sa[199:192]), $signed(sa[207:200]), $signed(sa[215:208]), sa[223:216], sa[31:24]);
        if (sb[7:0] == 8'h5E)
            $display("%0s: debug first deadline (2) miss: state %0d, access %0d, %0d cycles after the arrival, missed by %0d; %0d bucket beats written, bucket port W-B %0d",
                     name, sb[20:16], sb[63:32], sb[95:80], sb[111:96], sb[159:144], $signed(sb[175:168]));
        if (ph_trace) begin
            if (dt_fa >= 0 && (sa[7:0] !== 8'h5D || sa[9:8] != dt_fa_ev || sa[63:32] != dt_fa || sa[111:96] != dt_fa_by ||
                               sa[95:80] != ((dt_fa_ev == 1) ? `ORAM_AR_WB_H : `ORAM_AR_REL_H))) begin
                $display("FAIL %0s: first-overrun record (want deadline %0d, access %0d, missed by %0d)", name, dt_fa_ev, dt_fa, dt_fa_by); bad = bad + 1; end
            if (dt_fa < 0 && sa[7:0] !== 8'h00) begin $display("FAIL %0s: a first-overrun record without an overrun", name); bad = bad + 1; end
            if (dt_fb >= 0 && (sb[7:0] !== 8'h5E || sb[9:8] != 2 || sb[63:32] != dt_fb || sb[111:96] != dt_fb_by ||
                               sb[95:80] != `ORAM_AR_REL_H || sb[20:16] == 5'd23)) begin
                $display("FAIL %0s: first deadline (2) record (want access %0d, missed by %0d)", name, dt_fb, dt_fb_by); bad = bad + 1; end
            $display("%0s: debug records: %0d per-access records equal to the testbench's own timestamps, flags and counters consistent; %0d bad", name, size, bad);
            $display("%0s: debug stash records: %0d stash opens, every record equal to the testbench's view of the stash port; %0d bad", name, sopen, sbad);
            bad = bad + sbad;
        end
        d_k = 0; so_k = 0;
        fails = fails + bad;
    end endtask
`endif
    // ---------------- v14: observable timing per access ----------------
    // Relative to the access start (the controller leaves S_IDLE for the position lookup), so a launch-wide shift
    // (the boot, or faster accesses before) drops out. An off-package access (its bucket in host memory): every host
    // bucket-port handshake (AR, R, AW, W) with its type, then the release (the result's first beat) and the end
    // (client_done), hashed in order (sh_h). An on-package access shows only its release and end (op_h). The same
    // code runs against v11g's RTL (-DTB_V11G_REF), so the off-package hashes of the two can be compared.
    reg  [63:0] sh_h = 64'hCBF29CE484222325, op_h = 64'hCBF29CE484222325;
    integer     sh_n = 0, op_n = 0, op_rmin = 0, op_rmax = 0, op_emin = 0, op_emax = 0;
    integer     a_t0 = 0, a_rel = -1; reg a_on = 0; reg [4:0] a_ps = 0;
    reg         ovr_q = 0;                                                  // the controller's overrun flag, last cycle
    function [63:0] fnv64; input [63:0] h; input [63:0] x; begin fnv64 = (h ^ x) * 64'h00000100000001B3; end endfunction
    always @(posedge clk) begin : obs
        reg [4:0] st; reg [31:0] dt;
        st = dut.u_doma.u_oram.state; dt = cyc_tb - a_t0;
        if (st == 5'd1 && a_ps == 5'd0) begin a_on = 1; a_t0 = cyc_tb; a_rel = -1; dt = 0; end
        if (a_on) begin
            if (!dut.u_doma.u_oram.acc_hbm) begin
                if (g2_arvalid && g2_arready) sh_h = fnv64(sh_h, {32'h1, dt});
                if (g2_rvalid && g2_rready)   sh_h = fnv64(sh_h, {32'h2, dt});
                if (g2_awvalid && g2_awready) sh_h = fnv64(sh_h, {32'h3, dt});
                if (g2_wvalid && g2_wready)   sh_h = fnv64(sh_h, {32'h4, dt});
            end
            if (st == 5'd24 && a_ps == 5'd23) a_rel = dt;                     // S_DONE_GATE -> S_RES_STREAM: the release
            if (dut.u_doma.u_oram.client_done && !dut.u_doma.u_oram.err_ct_overrun_r && !ovr_q) begin   // (after a halt: not served)
                if (dut.u_doma.u_oram.acc_hbm) begin
                    op_h = fnv64(op_h, {a_rel[31:0], dt}); op_n = op_n + 1;
                    if (a_rel < op_rmin) op_rmin = a_rel; if (a_rel > op_rmax) op_rmax = a_rel;
                    if (dt < op_emin) op_emin = dt; if (dt > op_emax) op_emax = dt;
                end else begin
                    sh_h = fnv64(sh_h, {32'h5, a_rel[31:0]}); sh_h = fnv64(sh_h, {32'h6, dt}); sh_n = sh_n + 1;
                end
                a_on = 0;
            end
            if (dut.u_doma.u_oram.client_done) a_on = 0;
        end
        a_ps <= st;
    end
    // ---------------- leak tests: per-access log (+acc_log) and positive control (+leak_inject) ----------------
    // Offsets are counted from the access start, as in obs above; -1 = the event did not happen (an on-package
    // access makes no host bucket-port handshake). Internal state (fib, fis, occ, bkt) is logged for the
    // correlation and uniformity checks only: the adversary never sees it.
    integer al_fd = 0, al_seq = 0, lk_k = 0, lk_base = -1;
    reg [8*8-1:0] launch_name = "none";
    reg lk_put = 0;
    reg [8*256-1:0] al_fname;
    initial begin
        if ($value$plusargs("acc_log=%s", al_fname)) begin
            al_fd = $fopen(al_fname, "w");
            if (al_fd) $fdisplay(al_fd, "launch,seq,loc,bkt,op,fib,fis,occ,ar0,r0,rl,aw0,w0,wl,rel,end,ovr");
        end
        if (!$value$plusargs("leak_inject=%d", lk_k)) lk_k = 0;
        if ($test$plusargs("leak_put")) lk_put = 1;
    end
    integer l_t0 = 0, l_ar0 = -1, l_r0 = -1, l_rl = -1, l_aw0 = -1, l_w0 = -1, l_wl = -1, l_rel = -1;
    reg l_on = 0; reg [4:0] l_ps = 0;
    always @(posedge clk) begin : acclog
        reg [4:0] st; integer dt; reg hit;
        st = dut.u_doma.u_oram.state; dt = cyc_tb - l_t0;
        if (st == 5'd1 && l_ps == 5'd0) begin
            l_on = 1; l_t0 = cyc_tb; dt = 0;
            l_ar0 = -1; l_r0 = -1; l_rl = -1; l_aw0 = -1; l_w0 = -1; l_wl = -1; l_rel = -1;
        end
        if (l_on) begin
            if (g2_arvalid && g2_arready && l_ar0 < 0) l_ar0 = dt;
            if (g2_rvalid && g2_rready) begin if (l_r0 < 0) l_r0 = dt; l_rl = dt; end
            if (g2_awvalid && g2_awready && l_aw0 < 0) l_aw0 = dt;
            if (g2_wvalid && g2_wready) begin if (l_w0 < 0) l_w0 = dt; l_wl = dt; end
            if (st == 5'd24 && l_ps == 5'd23) l_rel = dt;                    // S_DONE_GATE -> S_RES_STREAM: the release
            if (dut.u_doma.u_oram.client_done) begin
                if (al_fd) $fdisplay(al_fd, "%0s,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d",
                    launch_name, al_seq, dut.u_doma.u_oram.acc_hbm, dut.u_doma.u_oram.req_b, dut.u_doma.u_oram.req_op,
                    dut.u_doma.u_oram.found_in_bucket, dut.u_doma.u_oram.found_in_stash, dut.u_doma.u_oram.stash_occupancy,
                    l_ar0, l_r0, l_rl, l_aw0, l_w0, l_wl, l_rel, dt, dut.u_doma.u_oram.err_ct_overrun_r);
                al_seq = al_seq + 1;
                if (lk_k > 0) begin                                             // positive control: a request-dependent read latency
                    if (lk_base < 0) lk_base = u_host.lat;
                    hit = lk_put ? dut.u_doma.u_oram.req_op : dut.u_doma.u_oram.found_in_stash;
                    u_host.lat = lk_base + (hit ? lk_k : 0);
                end
                l_on = 0;
            end
        end
        l_ps <= st;
    end
    // +hbmb_whold=H +hbmb_whold_at=K: the HBM bucket port takes writes slowly (wready low H cycles after each write
    // address) from the K-th access of the whole test on (default 0: from the start)
    integer whold_v = 0, whold_at = 0, acc_all = 0;
    initial begin
        if ($value$plusargs("hbmb_whold=%d", whold_v)) begin end
        if ($value$plusargs("hbmb_whold_at=%d", whold_at)) begin end
    end
    // v14b +stash_slow=L +stash_slow_at=K: every stash read takes L cycles from the K-th access on (the boot untouched)
    integer sslow_v = 0, sslow_at = 0, sslow_base = 53;
    initial begin
        if ($value$plusargs("stash_slow=%d", sslow_v)) begin end
        if ($value$plusargs("stash_slow_at=%d", sslow_at)) begin end
        #1 sslow_base = u_stmem.lat;
    end
    always @(posedge clk) begin
        if (dut.c_done) acc_all = acc_all + 1;
        u_hbmb.w_hold = (acc_all >= whold_at) ? whold_v : 0;
        if (sslow_v > 0) u_stmem.lat = (acc_all >= sslow_at) ? sslow_v : sslow_base;
    end
    // the first timing overrun: where it was raised, relative to the access's bucket arrival (the on-package rule
    // raises it at exactly t_arr + AR_REL_H)
    always @(posedge clk) begin
        ovr_q <= dut.u_doma.u_oram.err_ct_overrun_r;
        if (dut.u_doma.u_oram.err_ct_overrun_r && !ovr_q)
            $display("OVERRUN-AT: state %0d, raised in access cycle %0d, %0d cycles after the bucket's last beat (arrival seen %0d), on-package %0d",
                     dut.u_doma.u_oram.state, dut.u_doma.u_oram.ct_cnt - 1, dut.u_doma.u_oram.ct_cnt - 1 - dut.u_doma.u_oram.t_arr,
                     dut.u_doma.u_oram.arr_seen, dut.u_doma.u_oram.acc_hbm);
    end
    // ---------------- v14: memory inspection (+inspect=<file>, after the last launch) ----------------
    // Every bucket's record (metadata and IV/tag beats) and contents, and every block's expected contents, for
    // sim/inspect_check.py: on-package buckets must hold the blocks in plaintext, off-package ones ciphertext that
    // verifies under the bucket's IV and tag and decrypts to the blocks.
    reg [1023:0] insp_fn;
    task inspect_dump; integer fd, b, k, j, nb, hbm, w, hb4k; begin
        nb = (NK + `ORAM_C - 1) / `ORAM_C; hbm = (nb * HBM_PCT) / 100;
        hb4k = ((hbm * `BUCKET_BYTES) / 4096) * 4096;
        fd = $fopen(insp_fn, "w");
        $fdisplay(fd, "H %0d %0d %0d %0d %0d %0d %0d %032h %0d", `ORAM_Z, BEATS, nb, hbm, NK, `SLOT_ID_W, `FILL_CNT_W,
                  dut.AES_KEY, `BUCKET_BYTES);
        for (b = 0; b < nb; b = b + 1) begin
            $fdisplay(fd, "R %0d %064h %064h", b, u_brec.mem[2*b], u_brec.mem[2*b + 1]);
            $fwrite(fd, "D %0d", b);
            for (j = 0; j < `ORAM_Z * BEATS; j = j + 1) begin
                if (b < hbm) w = (b * `BUCKET_BYTES) / 32 + j;
                else         w = (PAGES_OFF + b * `BUCKET_BYTES - hb4k) / 32 + j;
                $fwrite(fd, " %064h", (b < hbm) ? u_hbmb.mem[w] : u_host.mem[w]);
            end
            $fwrite(fd, "\n");
        end
        for (k = 0; k < NK; k = k + 1) begin
            $fwrite(fd, "E %0d", k);
            for (j = 0; j < BEATS; j = j + 1)
                $fwrite(fd, " %064h", (rec_len > 0) ? refimg[k*BEATS + j] : ((last_put[k] < 0) ? {DW{1'b0}} : pat(last_put[k], j, k)));
            $fwrite(fd, "\n");
        end
        $fclose(fd);
        $display("INSPECT: %0d buckets (%0d on package) and %0d blocks written to %0s", nb, hbm, NK, insp_fn);
    end endtask
    // heartbeat (+hb=N cycles, default 50000) and a global limit (+limit=N cycles, default 20M)
    integer hb_n, lim, cyc_tb = 0, ar_host = 0, aw_host = 0;
    // +trace_ctl: every AXI-Lite cycle in the first 600 cycles
    always @(posedge clk) if ($test$plusargs("trace_ctl") && cyc_tb < 600 && (awvalid || wvalid || bvalid || arvalid || rvalid || dut.ap_start_r))
        $display("CTL cyc=%0d aw=%0d/%0d w=%0d/%0d b=%0d/%0d ar=%0d/%0d r=%0d/%0d awaddr=%h araddr=%h start=%0d kst=%0d", cyc_tb,
                 awvalid, awready, wvalid, wready, bvalid, bready, arvalid, arready, rvalid, rready, awaddr, araddr, dut.ap_start_r, dut.kst);
    always @(posedge clk) begin
        cyc_tb <= cyc_tb + 1;
        if (g2_arvalid && g2_arready) ar_host <= ar_host + 1;
        if (g2_awvalid && g2_awready) aw_host <= aw_host + 1;
        if (hb_n > 0 && cyc_tb % hb_n == 0 && cyc_tb > 0) begin
            $display("HB cyc=%0d kst=%0d key_ready=%0d oram_ready=%0d lease=%0d idx=%0d host AR=%0d AW=%0d",
                     cyc_tb, dut.kst, dut.key_ready, dut.oram_ready, dut.lease_ok, dut.idx, ar_host, aw_host);
            $fflush;
        end
        if (cyc_tb == lim) begin $display("FAIL: global limit of %0d cycles reached (kst=%0d)", lim, dut.kst); $fflush; bw_report; $finish; end
    end
    initial begin
        if (!$value$plusargs("hb=%d", hb_n)) hb_n = 50000;
        if (!$value$plusargs("limit=%d", lim)) lim = 200000000;   // boot (format, random placement, settle) plus the commands
    end
    // +layout_log=<file>: every position-map write of the boot layout (before the format completes), one line
    // "slot bucket status" (status 1 = in the bucket, 2 = in the stash, waiting for that bucket); sim/layout_check.py
    // checks the placement (every slot once, the first Z of each bucket in it, the rest in the stash) and its
    // statistics (per-bucket counts against Binomial(n, 1/B)).
`ifndef ORAM_PLAIN
    integer lay_fd = 0, lay_nstash = 0;
    reg lay_open = 0, lay_said = 0;
    reg [1023:0] lay_fn;
    initial if ($value$plusargs("layout_log=%s", lay_fn)) begin lay_fd = $fopen(lay_fn, "w"); lay_open = 1; end
    always @(posedge clk) begin
        if (lay_open && !dut.u_doma.u_oram.fmt_done_r && dut.u_doma.u_oram.pm_wr_en) begin
            $fdisplay(lay_fd, "%0d %0d %0d", dut.u_doma.u_oram.pm_wr_addr >> 12, dut.u_doma.u_oram.pm_wr_bucket, dut.u_doma.u_oram.pm_wr_status);
            if (dut.u_doma.u_oram.pm_wr_status == 2'b10) lay_nstash = lay_nstash + 1;
        end
        if (lay_open && dut.u_doma.u_oram.fmt_done_r && !lay_said) begin
            $fdisplay(lay_fd, "# done: %0d slots in the stash at boot", lay_nstash); $fflush(lay_fd); lay_said = 1;
            $display("LAYOUT: boot placement put %0d blocks in the stash", lay_nstash);
        end
    end
`endif
`ifndef ORAM_PLAIN
    // Boot report (v11b fixed-time boot): the controller must become ready a fixed number of cycles after the layout
    // starts, whatever the placement. Printed for every boot: the cycles from the layout's start to ready, the budget,
    // when the placement was done, how many slots it put in the stash, and the worst cycles of one slot's placement
    // in its bucket and in the stash (these calibrate ORAM_LAY_TB / ORAM_LAY_TS0).
    // +rng_seed=<hex>: start the position generator from another state (testbench only; at the format's start, before
    // any draw), so that two runs place the slots differently with the same n.
    reg [63:0] rng_seed; reg seed_req = 0, seeded = 0, lay_was = 0, rdy_was = 0; integer lay_s0 = 0, bt_cyc = 0;
    initial if ($value$plusargs("rng_seed=%h", rng_seed)) seed_req = 1;
    always @(posedge clk) begin
        bt_cyc <= bt_cyc + 1;
        if (seed_req && !seeded && dut.u_doma.u_oram.st_init_go) begin dut.u_doma.u_oram.u_rng.x <= rng_seed; seeded = 1; end
        lay_was <= dut.u_doma.u_oram.lay_run;
        if (dut.u_doma.u_oram.lay_run && !lay_was) lay_s0 = bt_cyc;
        rdy_was <= dut.u_doma.u_oram.fmt_done_r;
        if (dut.u_doma.u_oram.fmt_done_r && !rdy_was)
            $display("BOOT: ready %0d cycles after the layout started (budget %0d + settle); placement done after %0d (slack %0d); %0d slots placed in the stash; worst slot %0d cycles in its bucket, %0d in the stash",
                     bt_cyc - lay_s0, dut.u_doma.u_oram.lay_budget, dut.u_doma.u_oram.lay_end, dut.u_doma.u_oram.lay_budget - dut.u_doma.u_oram.lay_end, dut.u_doma.u_oram.lay_nst, dut.u_doma.u_oram.lay_max_b, dut.u_doma.u_oram.lay_max_s);
        if (lay_was && !dut.u_doma.u_oram.lay_run && !dut.u_doma.u_oram.fmt_done_r)
            $display("BOOT: halted %0d cycles after the layout started (budget %0d): %0s; placement %0s", bt_cyc - lay_s0, dut.u_doma.u_oram.lay_budget,
                     dut.u_doma.u_oram.err_stash_overflow ? "stash overflow" : "timing overrun", (dut.u_doma.u_oram.state == 5'd29) ? "not done" : "done");
    end
`endif
endmodule
