#!/usr/bin/env python3
"""card_highstash.py leak.csv [--out summary.json] -- does latency depend on how full the stash is? (docs/LEAK_CARD_RUNBOOK.md)

leak.csv comes from vitis/leak_highstash.sh on a TRACE=1 bitstream built with patches/baseline_stash_trace.patch. Per request it holds
the stash at its open: occ pool entries in use, chain the bucket has blocks waiting beyond its window, wc entries in its window.
Phases alternate a sequential scan (the stash fills) and uniform requests (it drains).

Comparisons of the request's own latency, separately for on- and off-package buckets (from the result's padded time, as in
card_leak_analyze.py): the fullest 10% of requests against the emptiest 10%, and the bucket's waiting list, longest identifiable
(window full and more on a chain, or, if too few, the fullest window seen) against shortest (empty window, no chain). The design
keeps no per-bucket count, so the waiting list is not a full length. A flag is |t| > 4.5 or a Holm rejection at 0.01 of the smaller
of the t and KS p-values. These are not randomized (no coin decides a request's stash level), so slow drift can show up as a difference."""
import argparse, csv, json, sys, warnings
from array import array
warnings.filterwarnings("ignore", category=RuntimeWarning)
import numpy as np
from scipy import stats

def welch_ks(a, b):
    if len(a) < 2 or len(b) < 2: return None
    t, pt = stats.ttest_ind(a, b, equal_var=False)
    if not np.isfinite(t): t, pt = 0.0, 1.0
    ks, pks = stats.ks_2samp(a, b)
    return dict(n0=len(a), n1=len(b), mean0=float(a.mean()), mean1=float(b.mean()), t=float(t), p_t=float(pt), ks=float(ks), p_ks=float(pks),
                detect=4.5 * float(np.sqrt(a.var(ddof=1) / len(a) + b.var(ddof=1) / len(b))))
def holm(p, alpha=0.01):
    o = np.argsort(p); rej = [False] * len(p)
    for i, k in enumerate(o):
        if p[k] <= alpha / (len(p) - i): rej[k] = True
        else: break
    return rej

ap = argparse.ArgumentParser(); ap.add_argument("leak_csv"); ap.add_argument("--out", default="highstash.json")
ap.add_argument("--min-group", type=int, default=200, help="fewest requests in a group for a comparison")
a = ap.parse_args()
NUM = ("lat", "tar", "trl", "occ", "chain", "wc")
col = {k: array("q") for k in NUM}; kinds = []; cut = 0
with open(a.leak_csv) as f:
    for r in csv.DictReader(f):
        try: v = [int(r[k]) for k in NUM]
        except (TypeError, ValueError, KeyError): cut += 1; continue
        for k, x in zip(NUM, v): col[k].append(x)
        kinds.append(r["kind"])
d = {k: np.frombuffer(v, dtype=np.int64) if len(v) else np.zeros(0, np.int64) for k, v in col.items()}
n = len(d["lat"])
if n == 0 or not np.any(d["occ"] != 0):
    sys.exit("card_highstash: no stash records in this CSV (a TRACE=1 bitstream built with patches/baseline_stash_trace.patch, and DOMA_PHASE_TRACE=1)")
kinds = np.array(kinds); occ = d["occ"]; peak = int(occ.max())
if cut: print(f"note: {cut} incomplete row(s) skipped")
print(f"{n} requests; stash occupancy: min {int(occ.min())}, median {int(np.median(occ))}, peak {peak} pool entries" + (" (saturated)" if peak >= 0x7FFFF else ""))
for k in ("scan", "uni"):
    m = kinds == k
    if m.any(): print(f"  {k:<5} requests {int(m.sum())}: occupancy median {int(np.median(occ[m]))}, peak {int(occ[m].max())}")
print(f"  buckets with blocks waiting beyond the window (chain): {100.0 * d['chain'].mean():.3f}% of requests; window entries at open: "
      + ", ".join(f"{int(v)}: {int(c)}" for v, c in zip(*np.unique(d['wc'], return_counts=True))))
# location: the result follows the bucket's last beat by a padded time with two values; the one whose reads are faster is on package
dend = d["lat"] - d["trl"]; lrd = d["trl"] - d["tar"]
vals, cnt = np.unique(dend, return_counts=True)
top = sorted(vals[np.argsort(cnt)[-2:]]) if len(vals) >= 2 else list(vals)
if len(top) == 2:
    mid = (top[0] + top[1]) / 2; lo = dend < mid
    on = lo if np.median(lrd[lo]) < np.median(lrd[~lo]) else ~lo
    print(f"location from the padded time after the last beat: values {int(top[0])} and {int(top[1])}; on package {100.0 * on.mean():.1f}% of requests")
else:
    on = np.zeros(n, bool); print("location: one padded time only, every request taken as off package")
tests = []
for flag, name in ((True, "on"), (False, "off")):
    m = on == flag
    if m.sum() < 10 * a.min_group: print(f"note: too few {name}-package requests ({int(m.sum())})"); continue
    lo, hi = np.percentile(occ[m], 10), np.percentile(occ[m], 90)
    x0, x1 = d["lat"][m & (occ <= lo)].astype(float), d["lat"][m & (occ >= hi)].astype(float)
    if len(x0) >= a.min_group and len(x1) >= a.min_group and hi > lo:
        t = welch_ks(x0, x1)
        if t: tests.append((f"occupancy fullest 10% (>= {int(hi)}) vs emptiest 10% (<= {int(lo)})", name, t))
    else: print(f"note: occupancy groups not separable for {name} package (10th {int(lo)}, 90th {int(hi)})")
    long1 = m & (d["chain"] == 1); desc = "window full and a chain"
    if long1.sum() < a.min_group:
        tw = int(d["wc"][m].max()); long1 = m & (d["wc"] == tw); desc = f"fullest window seen ({tw} entries)"
    short = m & (d["wc"] == 0) & (d["chain"] == 0)
    if long1.sum() >= a.min_group and short.sum() >= a.min_group:
        t = welch_ks(d["lat"][short].astype(float), d["lat"][long1].astype(float))
        if t: tests.append((f"waiting list: {desc} vs empty", name, t))
    else: print(f"note: too few requests for the waiting-list comparison, {name} package (long {int(long1.sum())}, empty {int(short.sum())})")
rej = holm([min(t["p_t"], t["p_ks"]) for *_, t in tests]) if tests else []
print(f"\n== comparisons (flag: |t| > 4.5, or Holm at 0.01 over {len(tests)})")
print(f"  {'comparison':<66}{'loc':<5}{'n0':>9}{'n1':>9}{'mean diff':>11}{'|t|':>8}{'KS':>8}{'detect':>9}  result")
flagged = 0; out = []
for (lab, loc, t), hr in zip(tests, rej):
    bad = bool(abs(t["t"]) > 4.5 or hr); flagged += int(bad); out.append(dict(test=lab, loc=loc, flagged=bad, **t))
    print(f"  {lab:<66}{loc:<5}{t['n0']:>9}{t['n1']:>9}{t['mean0'] - t['mean1']:>11.3f}{abs(t['t']):>8.2f}{t['ks']:>8.4f}{t['detect']:>9.2f}  {'FLAG' if bad else 'ok'}")
json.dump(dict(requests=n, peak_occupancy=peak, comparisons=out, flagged=flagged), open(a.out, "w"), indent=1)
ok = bool(tests) and flagged == 0 and not cut
print(f"\n== {'NO STASH-LEVEL DEPENDENCE FOUND' if ok else ('CHECK THE FLAGGED ROWS' if flagged else 'INCOMPLETE')}: {flagged} of {len(tests)} comparisons flagged; peak stash {peak} pool entries (details: {a.out})")
sys.exit(0 if ok else 1)
