#!/bin/bash
# leak_4k.sh -- 4 KB leakage tests in simulation (arrival build, lambda = 7, production ORAM_SECURE_BUILD).
# Uses tb_doma_kernel_leak.v (a copy of tb_doma_kernel.v with +key_mode, +pay_zero, +acc_log, +leak_inject);
# tb_doma_kernel.v and the RTL are not modified. Analyse with: python3 leak_analyze.py build_leak
#
#   bash leak_4k.sh                  # build once, run the whole matrix in parallel
#   CMDS=1000 SEEDS="3 5 7 11" JOBS=20 STASH_SLOW=300 bash leak_4k.sh
#
# Groups (every run: boot, preload of the n blocks, run1 = CMDS commands, run2 = 4 commands with one rejected key):
#   E0, E100  exact pairs, 0% / 100% of the buckets on package. Within one (location share, memory profile, seed),
#             every variant must give the same run1 bucket-port timing, off-package shape and on-package
#             release/end hashes. Variants: uniform/fixed/scan/re-request keys (mixed GET/PUT), all GETs,
#             all PUTs, all-zero payloads.
#             Memory profiles: def (the testbench's models: metadata, record and stash reads 2% slow by 105 cycles),
#             jit (10% slow), sslow (every stash read STASH_SLOW cycles).
#   P20       the paper's configuration, 20% on package, with the per-access log (+acc_log), for the
#             per-location checks, class comparisons and bucket uniformity.
#   C         positive controls: +leak_inject=1 (one extra cycle on the next host read after a stash hit, or after
#             a PUT with +leak_put). Their hashes and logs must show the difference.
#   R0, R20, R100  rejection pairs: run2 (CMDS commands) with no rejected command, a key outside the ORAM, or a
#             corrupted lease token in its middle; run2's hashes (0%, 100%) and per-access offsets (20%) must agree.
#   ONLY=E|P|C|R runs one group and keeps the others' results (e.g. ONLY=R bash leak_4k.sh).
set -u
cd "$(dirname "$0")"
RTL=${RTL_DIR:-../rtl}
CMDS=${CMDS:-1000}                 # at most ~1,000 at N = 512: the command memory holds 2^17 words, 128 per 4 KB PUT
SEEDS=${SEEDS:-"3 5 7 11"}
JOBS=${JOBS:-$(nproc)}
STASH_SLOW=${STASH_SLOW:-300}
OUT=build_leak
mkdir -p $OUT
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
VFLAGS="--binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-BLKANDNBLK -I$RTL"
VFLAGS="$VFLAGS -DORAM_BLOCK_BEATS=128 -DORAM_C=7 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL"

if [ ! -x $OUT/kern_leak/Vkern_leak ] || [ -n "${REBUILD:-}" ]; then
    echo "building kern_leak (4 KB, lambda 7, arrival) ..."
    rm -rf $OUT/kern_leak
    verilator $VFLAGS --top-module tb_doma_kernel_leak ./tb_doma_kernel_leak.v ./oram_timing_monitor.v ./axi_mem_model.v \
        $SRCS $RTL/doma_kernel.v -Mdir $OUT/kern_leak -o Vkern_leak > $OUT/kern_leak.build.log 2>&1 \
        || { echo "BUILD FAILED ($OUT/kern_leak.build.log)"; exit 2; }
fi

BASE="+hb=0 +preload +host_lat=263 +host_wlat=98"
RUN="+cmds=$CMDS +cmds2=4"                  # E, P and C: run1 is the measured launch
RRUN="+cmds=4 +cmds2=$CMDS"                 # R: run2 is the measured launch, its middle command rejected or not
ONLY=${ONLY:-all}                           # all | E | P | C | R: generate only one group (results of others are kept)
want() { [ "$ONLY" = all ] || [ "$ONLY" = "$1" ]; }
declare -A PROF=( [def]="" [jit]="+meta_slow_pct=10 +brec_slow_pct=10 +stash_slow_pct=10" [sslow]="+stash_slow=$STASH_SLOW" )
# variant -> plusargs; every variant uses +put_pct so that keys and operations come from the same stream
declare -A VAR=( [k0]="+key_mode=0 +put_pct=50" [k1]="+key_mode=1 +put_pct=50" [k2]="+key_mode=2 +put_pct=50"
                 [k3]="+key_mode=3 +put_pct=50" [get]="+key_mode=0 +put_pct=0" [put]="+key_mode=0 +put_pct=100"
                 [zero]="+key_mode=0 +put_pct=50 +pay_zero" )

LIST=$OUT/runs.txt; : > $LIST
for s0 in $SEEDS; do
    # each seed also restarts the bucket generator from its own state (tb +rng_seed), so different seeds give
    # independent bucket sequences; every variant of one seed shares it, as the exact pairs require
    sa="+seed=$s0 +rng_seed=$(printf '%016x' $(( (s0 * 0x9E3779B97F4A7C15) & 0x7FFFFFFFFFFFFFFF )))"
    want E && for pct in 0 100; do
        for p in def jit sslow; do
            for v in k0 k1 k2 k3 get put zero; do
                echo "E${pct}_${p}_s${s0}_${v} $RUN $sa +hbm_pct=$pct ${PROF[$p]} ${VAR[$v]}" >> $LIST
            done
        done
    done
    want P && for v in k0 k1 k2 k3 get put zero; do
        echo "P20_def_s${s0}_${v} $RUN $sa +hbm_pct=20 ${VAR[$v]} +acc_log=$OUT/P20_def_s${s0}_${v}.csv" >> $LIST
    done
    # R: rejection pairs. run2's middle command is valid (none), has a key outside the ORAM (key: the kernel serves
    # a dummy GET of slot 0) or a corrupted lease token (tok: the core serves it as a dummy). Same keys otherwise.
    want R && for pct in 0 20 100; do
        for v in none key tok; do
            ra="$RRUN $sa +hbm_pct=$pct +key_mode=0 +put_pct=50"
            [ $v = none ] && ra="$ra +no_bad"; [ $v = tok ] && ra="$ra +badtok"
            [ $pct = 20 ] && ra="$ra +acc_log=$OUT/R20_def_s${s0}_${v}.csv"
            echo "R${pct}_def_s${s0}_${v} $ra" >> $LIST
        done
    done
done
s=${SEEDS%% *}
if want C; then
for v in k0 k3; do echo "C0_stash_s${s}_${v} $RUN +seed=$s +hbm_pct=0 ${VAR[$v]} +leak_inject=1" >> $LIST; done
for v in get put; do echo "C0_put_s${s}_${v} $RUN +seed=$s +hbm_pct=0 ${VAR[$v]} +leak_inject=1 +leak_put" >> $LIST; done
for v in k0 k3; do echo "C20_stash_s${s}_${v} $RUN +seed=$s +hbm_pct=20 ${VAR[$v]} +leak_inject=1 +acc_log=$OUT/C20_stash_s${s}_${v}.csv" >> $LIST; done
fi

n=$(wc -l < $LIST)
echo "running $n simulations, $JOBS at a time, $CMDS accesses in run1 each ..."
t0=$(date +%s)
run_one() { local tag=$1; shift; ./$OUT/kern_leak/Vkern_leak $BASE "$@" > $OUT/$tag.log 2>&1; echo "  done $tag"; }
export -f run_one; export OUT BASE
xargs -P "$JOBS" -L 1 bash -c 'run_one "$@"' _ < $LIST | sort | uniq -c | awk '{s+=$1} END {print "  finished", s, "runs"}'
echo "elapsed $(( $(date +%s) - t0 )) s; analyse with: python3 leak_analyze.py $OUT"
