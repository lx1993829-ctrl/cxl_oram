#!/usr/bin/env python3
"""card_rate_check.py RATE.log [--limit 0.2] -- does the access rate depend on the commands? (docs/LEAK_CARD_RUNBOOK_OV.md)

RATE.log is host_leak_ov's output for single-kind phases that start and end with get. A command's latency starts only when it
is issued, so latency comparisons and the exact schedule check, which takes the request time as an input, cannot see a stall
before the issue. Device cycles per command can. Each kind is compared with the mean of the two get phases; the difference
between those two is the run's drift. Flag: more than --limit percent from get, or the longest response write more than
twice get's. Exit 0 only if nothing is flagged."""
import argparse, re, sys
ap = argparse.ArgumentParser(); ap.add_argument("log"); ap.add_argument("--limit", type=float, default=0.2); a = ap.parse_args()
R = {}
for l in open(a.log, errors="replace"):
    m = re.match(r"phase (\d+): \d+ (\S+) in \d+ launch.*device ([0-9.]+) cycles per command, errors (\S+)", l)
    if m: R[int(m[1])] = dict(kind=m[2], cyc=float(m[3]), err=m[4], late=None, wo=None)
    m = re.match(r"phase (\d+): results landing during a response write (\d+), longest response write (\d+)", l)
    if m and int(m[1]) in R: R[int(m[1])].update(late=int(m[2]), wo=int(m[3]))
g = [r for r in R.values() if r["kind"] == "get"]
if len(g) < 2: sys.exit("card_rate_check: need two get phases; was the run cut short?")
base = sum(r["cyc"] for r in g) / len(g); wo0 = max((r["wo"] or 0) for r in g)
drift = 100 * (max(r["cyc"] for r in g) - min(r["cyc"] for r in g)) / base
print(f"{'phase':<7}{'kind':<10}{'cycles/cmd':>12}{'vs get':>10}{'late results':>14}{'longest write':>15}  result")
bad = 0
for i, r in sorted(R.items()):
    d = 100 * (r["cyc"] - base) / base
    f = abs(d) > a.limit or (wo0 > 0 and (r["wo"] or 0) > 2 * wo0)
    bad += f
    print(f"{i:<7}{r['kind']:<10}{r['cyc']:>12.1f}{d:>9.2f}%{str(r['late']):>14}{str(r['wo']):>15}  {'FLAG' if f else 'ok'}")
print(f"== {'RATE DOES NOT DEPEND ON THE COMMANDS' if not bad else 'RATE DEPENDS ON THE COMMANDS'}: {bad} of {len(R)} phases flagged, limit {a.limit}%; drift between the get phases {drift:.3f}%")
sys.exit(1 if bad else 0)
