#!/bin/bash
# run_tinyoram_mutants.sh -- mutation checks for the Tiny ORAM kernel wrapper and adapter (Verilator 5).
#   bash run_tinyoram_mutants.sh          # every mutant must be caught by the test named next to it
# Each mutant is one deliberate bug in tinyoram_kernel.v or tinyoram_axi_adapter.v. A mutant is caught
# when its test reports a failure or hangs to the cycle limit. Exit code 0 = every mutant caught.
# m12 (release tested before halted in K_WAIT) is not in the list: it is equivalent for the headers and the
# completed count, since K_HQ then charges the command; only the summary's latency min/max would differ.
# Logs: build_tinyoram/mut/. Needs Tiny ORAM fetched and patched (bash ../tinyoram/fetch_tinyoram.sh).
set -u
cd "$(dirname "$0")"
TOR=../tinyoram
[ -f $TOR/build/src/files.f ] || bash $TOR/fetch_tinyoram.sh 4k || exit 2
SRC=$TOR/build/src
M=build_tinyoram/mut
rm -rf $M && mkdir -p $M/cfg $M/cfg4k && cp $TOR/config/tinyoram_config_64.vh $M/cfg/tinyoram_config.vh
cp $TOR/config/tinyoram_config_4k.vh $M/cfg4k/tinyoram_config.vh

python3 - "$M" <<'EOF' || exit 2
import sys
M = sys.argv[1]
k  = open('../tinyoram/rtl/tinyoram_kernel.v').read()
ad = open('../tinyoram/rtl/tinyoram_axi_adapter.v').read()
def mut(name, src, a, b):
    if src.count(a) != 1: sys.exit('mutant %s: pattern not found once' % name)
    open('%s/%s.v' % (M, name), 'w').write(src.replace(a, b))
# kernel
mut('m1', k, "(lastb >> 5);                       // beat of the last byte", "(gb0 + ((clen[15:0] - 16'd1) >> 5));")
mut('m2', k, "                    t_wmask <= {DMWidth{1'b1}};                                  // whole block unless K_MASK rebuilds it\n", "\n")
mut('m3', k, "if (a_idle || wait_cnt >= CMD_TIMEOUT) begin core_run <= 1'b0; if (!a_idle) errs <= errs | 32'h10; end",
             "if (a_idle || wait_cnt >= CMD_TIMEOUT) begin core_run <= core_run; if (!a_idle) errs <= errs | 32'h10; end")
mut('m4', k, "                        pages_base <= arg_pages; top_base <= arg_top; top_q <= arg_top_eff; booted <= 1'b1; zf_err <= 1'b0;",
             "                        top_base <= arg_top; top_q <= arg_top_eff; booted <= 1'b1; zf_err <= 1'b0;")
mut('m5', k, """                    else if (ctype == T_PUT && bad_range) begin stat <= 32'h40; kst <= K_HQ; end
                    else if (halted) begin stat <= 32'h8; errs <= errs | 32'h8; kst <= K_HQ; end
                    else if (ckey >= nkeys_rt) begin stat <= 32'h4; kst <= K_HQ; end
                    else if (bad_range) begin stat <= 32'h40; kst <= K_HQ; end""", """                    else if (bad_range) begin stat <= 32'h40; kst <= K_HQ; end
                    else if (halted) begin stat <= 32'h8; errs <= errs | 32'h8; kst <= K_HQ; end
                    else if (ckey >= nkeys_rt) begin stat <= 32'h4; kst <= K_HQ; end""")
mut('m6', k, "                    fst <= F_IDLE; f_idx <= 32'hFFFF_FFFF; f_go <= 1'b0;      // every run starts with no prefetch", "                    f_go <= 1'b0;")
mut('m8', k, "                    if (wait_cnt == 0 && idx + 1 < nsize) begin f_go <= 1'b1; f_go_idx <= idx + 1; end",
             "                    if (wait_cnt == 0) begin f_go <= 1'b1; f_go_idx <= idx + 1; end")
HQ = ("                if (halted) begin hq_ackw <= 1'b0; hq_stat <= hq_stat | 32'h8; errs_q <= errs_q | 32'h8; nlate <= nlate + 1; end\n"
      "                else if (a_wacked) hq_ackw <= 1'b0;\n")
mut('m9', k, HQ, "                if (halted) begin hq_ackw <= 1'b0; end\n                else if (a_wacked) hq_ackw <= 1'b0;\n")
mut('m10', k, "hq_stat <= hq_stat | 32'h8; errs_q <= errs_q | 32'h8; nlate <= nlate + 1; end", "hq_stat <= hq_stat | 32'h8; errs_q <= errs_q | 32'h8; end")
mut('m11', k, HQ, "                if (a_wacked) hq_ackw <= 1'b0;\n"
                  "                else if (halted) begin hq_ackw <= 1'b0; hq_stat <= hq_stat | 32'h8; errs_q <= errs_q | 32'h8; nlate <= nlate + 1; end\n")
mut('m13', k, """hq_stat <= (released && halted) ? (stat | 32'h8) : stat;
                    if (released && halted) begin errs_q <= errs_q | 32'h8; nlate <= nlate + 1; end""", "hq_stat <= stat;")
# adapter (merged build)
mut('a1', ad, "    wire wpend  = (b_out != 16'd0) || awv_h || awv_t || (m_v && !m_rd) || (wf_cnt != 0);", "    wire wpend  = awv_h || awv_t || (m_v && !m_rd);")
mut('a2', ad, "(h_off < top_bytes)", "(h_off <= top_bytes)")
mut('a3', ad, "                    (m_next[11:0] != 12'd0) && (m_beats + BPC <= MAXB) && (h_rd ? room : 1'b1);",
              "                    (m_beats + BPC <= MAXB) && (h_rd ? room : 1'b1);")
mut('a4', ad, "                    else     begin arv_h <= 1'b1; ara_h <= base   + m_off; arl_h <= m_beats - 9'd1; end",
              "                    else     begin arv_h <= 1'b1; ara_h <= {base[63:32], base[31:0] + m_off[31:0]}; arl_h <= m_beats - 9'd1; end")
# lint: a name used in a port connection before its declaration (Vivado: "already declared")
mut('l1', k, ".quiet_w(a_quiet_w),", ".quiet_w(a_quiet_w_late),")
s = open('%s/l1.v' % M).read().replace("    wire        a_wacked = a_quiet_w && a_wdone;", "    wire        a_quiet_w_late;\n    wire        a_wacked = a_quiet_w && a_wdone;")
open('%s/l1.v' % M, 'w').write(s)
EOF

VFLAGS="--binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-WIDTH -Wno-ZERODLY -Wno-BLKANDNBLK"
FILES="$(sed "s#^#$SRC/#" $SRC/files.f | tr '\n' ' ')"
build() {   # build <build name> <kernel file> <adapter file> <config dir> <extra flags>
    verilator $VFLAGS -I$4 -I$SRC -DSIMULATION $5 --top-module tb_tinyoram_kernel ./tb_tinyoram_kernel.v ./axi_mem_model.v \
        $2 $3 $FILES -Mdir $M/b_$1 -o Vtb > $M/$1.build.log 2>&1 || { echo "  BUILD FAILED: $1 ($M/$1.build.log)"; exit 2; }
}
AD=../tinyoram/rtl/tinyoram_axi_adapter.v; KR=../tinyoram/rtl/tinyoram_kernel.v
for m in m1 m2 m3 m4 m5 m6 m8 m9 m10 m11 m13; do echo "  building $m ..."; build $m $M/$m.v $AD $M/cfg ""; done
for m in a1 a2 a3; do echo "  building $m ..."; build $m $KR $M/$m.v $M/cfg -DTINYORAM_MERGE=1; done
echo "  building a4 ..."; build a4 $KR $M/a4.v $M/cfg ""
# the hold with slow acknowledgements at 4 KB, both adapters
echo "  building a1_4k_1to1 ..."; build a1_4k_1to1 $KR $M/a1.v $M/cfg4k -DTINYORAM_MERGE=0
echo "  building a1_4k_merged ..."; build a1_4k_merged $KR $M/a1.v $M/cfg4k -DTINYORAM_MERGE=1

MISSED=0; n=0
# the lint mutants (lint_tinyoram.sh must fail on each):
#   l1: a name used in a port connection before its declaration, in the kernel (Vivado: "already declared")
#   l2: DRAMInitializer.v back among the sources: a dead file with an undeclared name (Vivado: [Synth 8-36]), which
#       stopped a Vivado run on the server
#   l3: queue entry q6's geometry (4 KB, L = 12, merged) with Tiny ORAM's 3-bit PosMap depth rule instead of the
#       block-size one fetch_tinyoram.sh writes: depth 3, an empty final PosMap, CountAlarm #(.Threshold(0))
n=$((n+1))
KR=$M/l1.v bash ./lint_tinyoram.sh $SRC $M/cfg/tinyoram_config.vh $M/lint_l1 > $M/run_$n.log 2>&1
f=$(grep -m1 "a_quiet_w_late" $M/run_$n.log | sed 's/^ *//' | cut -c1-120)
if [ -n "$f" ]; then echo "  caught  l1 (a name used in a port connection before its declaration) [lint_tinyoram.sh]: $f"
else echo "  MISSED  l1 (a name used in a port connection before its declaration) [lint_tinyoram.sh]"; MISSED=$((MISSED+1)); fi
n=$((n+1)); rm -rf $M/src_l2 && cp -r $SRC $M/src_l2 && cp "$(find $TOR/build/patched -name DRAMInitializer.v | head -1)" $M/src_l2/
bash ./lint_tinyoram.sh $M/src_l2 $M/cfg/tinyoram_config.vh $M/lint_l2 > $M/run_$n.log 2>&1
f=$(grep -m1 "LastBuckerAddr" $M/run_$n.log | sed 's/^ *//' | cut -c1-120)
if [ -n "$f" ]; then echo "  caught  l2 (DRAMInitializer.v among the sources: an undeclared name in a file nothing uses) [lint_tinyoram.sh]: $f"
else echo "  MISSED  l2 (DRAMInitializer.v among the sources) [lint_tinyoram.sh]"; MISSED=$((MISSED+1)); fi
n=$((n+1)); mkdir -p $M/cfg_l3 && sed -E 's/^(`define TINYORAM_ORAML +)[0-9]+/\112/; s#^`endif#`define TINYORAM_MERGE 1\n`endif#' $TOR/config/tinyoram_config_4k.vh > $M/cfg_l3/tinyoram_config.vh
bash ./lint_tinyoram.sh $SRC $M/cfg_l3/tinyoram_config.vh $M/lint_l3 > $M/run_$n.log 2>&1
f=$(grep -m1 -iE "repeat may not be zero|CountAlarm" $M/run_$n.log | sed 's/^ *//' | cut -c1-120)
if [ -n "$f" ]; then echo "  caught  l3 (4 KB, L = 12 with the 3-bit PosMap depth: an empty final PosMap) [lint_tinyoram.sh]: $f"
else echo "  MISSED  l3 (4 KB, L = 12 with the 3-bit PosMap depth) [lint_tinyoram.sh]"; MISSED=$((MISSED+1)); fi
while read -r m what args; do
    n=$((n+1))
    C="+cmds=40 +cmds2=10 +limit=20000000"; case " $args " in *" +cmds="*) C="" ;; esac   # the 4 KB rows give their own
    ( ulimit -s unlimited 2>/dev/null; timeout 3000 ./$M/b_$m/Vtb +hb=0 $C $args > $M/run_$n.log 2>&1 )
    f=$(grep -m1 -E 'FAIL|ERROR' $M/run_$n.log | cut -c1-120)
    if grep -q "ALL CHECKS PASSED" $M/run_$n.log && [ -z "$f" ]; then echo "  MISSED  $m (${what//_/ }) [$args]"; MISSED=$((MISSED+1))
    else echo "  caught  $m (${what//_/ }) [$args]: ${f:-no verdict}"; fi
done <<'EOF'
m1 wrong_last-beat_formula +ranges +preload +host_gap=30
m2 mask_not_restored_after_a_partial_PUT +ranges +preload +host_gap=30
m3 no_core_reset_at_init +reboot +packed=8 +preload
m3 no_core_reset_at_init +reboot +reboot_same +packed=8 +preload
m4 pages_not_re-latched_at_init +reboot +packed=8 +preload
m5 Phase_2_check_order +packed=8 +preload
m6 prefetch_not_cleared_at_run_start
m8 prefetch_past_the_last_command
m9 error_after_release_not_charged_to_its_header +berr_rel +host_wlat=200 +preload
m10 error_after_release_still_counted_as_completed +berr_rel +host_wlat=200 +preload
m11 all-acknowledged_checked_before_the_error_(the_failing_B_is_the_last) +berr_last +host_wlat=200 +preload
m13 no_charge_for_an_error_between_release_and_the_header_queue +berr_early +host_wlat=200 +preload
a1 reads_not_held_behind_unacknowledged_writes +host_wlat=200 +preload
a1 reads_not_held_behind_unacknowledged_writes +host_wlat=200 +packed=8 +preload
a2 off-by-one_in_the_tree-top_split +top=16384 +packed=8 +preload
a3 merged_burst_crossing_4_KB +top_all +ranges +preload
a4 32-bit_base_+_offset_(the_tree_crosses_a_4_GB_boundary) +preload
a1_4k_1to1 4_KB,_1:1:_reads_not_held,_acknowledgements_6,000_cycles_late +cmds=12 +cmds2=4 +limit=60000000 +preload +host_wlat_after=6000
a1_4k_merged 4_KB,_merged:_reads_not_held,_acknowledgements_6,000_cycles_late +cmds=12 +cmds2=4 +limit=60000000 +preload +host_wlat_after=6000
EOF
echo
[ $MISSED -eq 0 ] && echo "ALL $n MUTANT CHECKS CAUGHT" || echo "$MISSED OF $n MUTANT CHECKS MISSED"
exit $MISSED
