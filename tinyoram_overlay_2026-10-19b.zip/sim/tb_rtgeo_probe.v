// tb_rtgeo_probe.v -- TinyRTGeo (patch 08) against the native build's own constants: compiled with ORAML = L, the
// run-time geometry of depth L must equal every compile-time constant it replaces (run_tinyoram_rteq.sh, every size, L = 6..22).
`include "Const.vh"
`include "RTGeo.vh"
module probe;
	`include "PathORAM.vh"
	`include "UORAM.vh"
	`include "DDR3SDRAMLocal.vh"
	`include "BucketLocal.vh"
	`include "StashLocal.vh"
	`include "PLBLocal.vh"
	localparam PRNGLWidth = 1 << `log2(ORAML);       // BackendCoreController.v
	reg clk = 0; wire [`RTGW-1:0] g; reg [4:0] L = ORAML;
	TinyRTGeo t(.Clock(clk), .L(L), .Geo(g));
	integer bad = 0;
	task chk; input [8*8-1:0] nm; input [63:0] got, exp; begin if (got !== exp) begin bad = bad + 1; $display("  L=%0d %0s: run-time %0d, native %0d", ORAML, nm, got, exp); end end endtask
	initial begin
		#1 clk = 1; #1;
		chk("L", g[`RTG_L], ORAML); chk("BOP", g[`RTG_BOP], BlocksOnPath); chk("CAP", g[`RTG_CAP], StashCapacity);
		chk("PDRB", g[`RTG_PDRB], PathSize_DRBursts); chk("PBED", g[`RTG_PBED], PathSize_BEDChunks); chk("PPBED", g[`RTG_PPBED], PathPSize_BEDChunks);
		chk("NTALL", g[`RTG_NTALL], numTallST); chk("LSB", g[`RTG_LSB], (ORAML + 1) % L_st); chk("LPAD", g[`RTG_LPAD], numST * L_st);
		chk("NVB", g[`RTG_NVB], NumValidBlock); chk("FSTART", g[`RTG_FSTART], FinalPosMapStart); chk("FENTRY", g[`RTG_FENTRY], FinalPosMapEntry);
		chk("LMASK", g[`RTG_LMASK], (64'd1 << ORAML) - 1); chk("PRNGK", g[`RTG_PRNGK], PRNGLWidth / 8);
		chk("TBURSTS", g[`RTG_TBURSTS], NumBuckets * BktSize_DRBursts);
		$display("PROBE L=%0d R=%0d %0d mismatches", ORAML, Recursion, bad); $finish;
	end
endmodule
