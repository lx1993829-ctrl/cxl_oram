#!/bin/bash
# check_rtdepth_native.sh -- patch 08 (run-time tree depth) must not change a native build: for every core file it
# touches, the preprocessed source (iverilog -E, comments and white space removed) with patches 01-07 and with
# 01-08 must be identical when TINYORAM_RTDEPTH is not defined. Configuration: each block size at its default depth,
# 1:1 and merged. Exit 0 = identical everywhere.
set -u
cd "$(dirname "$0")"
TOR=$(cd ../tinyoram && pwd)
[ -f $TOR/upstream/TinyORAMCore.v ] || bash $TOR/fetch_tinyoram.sh 4k > /dev/null || exit 2
W=$(mktemp -d); trap 'rm -rf "$W"' EXIT
for t in p7 p8; do
    cp -rL $TOR/upstream $W/$t
    for p in $TOR/patches/0[1-7]*.diff; do (cd $W/$t && patch -s -p1 < $p) || { echo "patch $p failed"; exit 2; }; done
done
(cd $W/p8 && patch -s -p1 < $(cd $TOR/patches && pwd)/08_runtime_depth.diff) || { echo "patch 08 failed"; exit 2; }
files=$(grep -E '^\+\+\+ b/.*\.v$' $TOR/patches/08_runtime_depth.diff | sed -E 's#^\+\+\+ b/##; s#\t.*##' | grep -v '^rtdepth/')
norm() { python3 -c '
import re, sys
s = open(sys.argv[1]).read()
s = re.sub(r"/\*.*?\*/", " ", s, flags=re.S); s = re.sub(r"//[^\n]*", " ", s)
s = re.sub(r"\s+", " ", s); s = re.sub(r" ?([()\[\],;{}=:]) ?", r"\1", s); print(s.strip())' "$1"; }
bad=0; n=0
for sz in 64 128 256 4k; do for mg in 0 1; do
    mkdir -p $W/cfg; cp $TOR/config/tinyoram_config_$sz.vh $W/cfg/tinyoram_config.vh
    [ $mg = 1 ] && sed -i 's#^`endif#`define TINYORAM_MERGE 1\n`endif#' $W/cfg/tinyoram_config.vh
    for f in $files; do
        n=$((n+1))
        for t in p7 p8; do iverilog -E -I$W/cfg -I$W/$t/include -o $W/$t.E $W/$t/$f 2>/dev/null || { echo "  $f: iverilog -E failed ($t)"; bad=1; }; norm $W/$t.E > $W/$t.N; done
        cmp -s $W/p7.N $W/p8.N || { echo "  $f differs ($sz B, merge=$mg)"; bad=1; }
    done
done; done
[ $bad = 0 ] && echo "   patch 08 without TINYORAM_RTDEPTH: $(echo $files | wc -w) core files, 8 configurations ($n comparisons), preprocessed sources identical"
exit $bad
