#!/bin/bash
# run_tinyoram_rteq.sh -- the run-time tree depth (TINYORAM_RTDEPTH, patch 08) must behave exactly like the native build.
#   bash run_tinyoram_rteq.sh            # the full set below (about an hour with 2 cores)
#   RTEQ_SET=quick bash run_tinyoram_rteq.sh      # one pair only;  RTEQ_SET=mutants: the mutants only
#   RTEQ_RESUME=1 bash run_tinyoram_rteq.sh       # after an interrupted run: pairs that passed are not run again
# For each pair (block size, native depth L, L_max, adapter): the native build of depth L and the run-time build of
# depth L_max started at depth L (+rtl=L) run the same testbench commands with the same seeds. They must both pass,
# print the same per-launch lines (latencies, traffic, status, and a hash of every data beat written and read on the
# tree ports), and issue the same tree bursts in the same cycles (+axitrace: port, cycle, offset, length of every AR
# and AW on both tree ports). One mismatch fails the pair: the same bursts, the same bytes, the same cycles.
# Then mutants of patch 08 (one edit each in a copy of the L_max = 12 build): each must break the equivalence.
# Then two checks of the run-time build alone: a re-boot to another depth (+reboot +rtl2), and an unsupported depth
# (status 0x100, L_max kept). Exit 0 = every check passed. Logs: build_tinyoram/rteq/
set -u
cd "$(dirname "$0")"
TOR=../tinyoram
B=build_tinyoram/rteq; mkdir -p $B
[ -f $TOR/upstream/TinyORAMCore.v ] || bash $TOR/fetch_tinyoram.sh 4k > /dev/null || exit 2
VFLAGS="--binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-WIDTH -Wno-ZERODLY -Wno-BLKANDNBLK"
FAILS=0; NCHK=0
pass() { echo "  PASS  $1"; NCHK=$((NCHK+1)); }
fail() { echo "  FAIL  $1"; FAILS=$((FAILS+1)); NCHK=$((NCHK+1)); }
mk() {   # mk <name> <tree buffer words> <fetch args...>: a private fetch and a Verilator build (kept between runs)
    local name=$1 words=$2; shift 2; local g=$B/$name
    [ -x $g/obj/Vtb ] && [ -z "${REBUILD:-}" ] && return 0
    rm -rf $g; mkdir -p $g
    cp $TOR/fetch_tinyoram.sh $g/ && cp -r $TOR/config $TOR/patches $g/ && ln -s $(cd $TOR && pwd)/upstream $g/upstream
    bash $g/fetch_tinyoram.sh "$@" > $g/fetch.log 2>&1 || { echo "  FETCH FAILED: $name ($g/fetch.log)"; exit 2; }
    echo "  building $name ($(tail -1 $g/fetch.log | sed -E 's/.*configuration //')) ..."
    verilator $VFLAGS -I$g/build/src -DSIMULATION -DTB_HOST_WORDS=$words --top-module tb_tinyoram_kernel ./tb_tinyoram_kernel.v ./axi_mem_model.v \
        $TOR/rtl/tinyoram_kernel.v $TOR/rtl/tinyoram_axi_adapter.v $(sed "s#^#$g/build/src/#" $g/build/src/files.f | tr '\n' ' ') \
        -Mdir $g/obj -o Vtb > $g/build.log 2>&1 || { echo "  BUILD FAILED: $name ($g/build.log)"; exit 2; }
}
run() { local name=$1 tag=$2; shift 2; ( ulimit -s unlimited 2>/dev/null; ./$B/$name/obj/Vtb +hb=0 "$@" > $B/$tag.log 2>&1 ); }
ok() { grep -q "TINYORAM KERNEL: ALL CHECKS PASSED" $B/$1.log && ! grep -qE "ERROR|Error:" $B/$1.log; }
lines() { grep -E "^[a-z0-9]+: (size=|latency to|traffic record|tree data hash)|^read-behind-write hold|^NOTE" $B/$1.log; }
eqpair() {   # eqpair <native build> <rt build> <L> <label> <tb args...>
    local nb=$1 rb=$2 L=$3 lab=$4; shift 4; local t=${lab// /_}
    # RTEQ_RESUME=1: a pair that already passed (both traces kept, identical) is not run again
    if [ -n "${RTEQ_RESUME:-}" ] && [ -s $B/n_$t.trace ] && cmp -s $B/n_$t.trace $B/r_$t.trace; then
        pass "$lab: identical ($(wc -l < $B/n_$t.trace) bursts; passed in an earlier run, RTEQ_RESUME)"; return; fi
    run $nb n_$t +axitrace "$@" & run $rb r_$t +axitrace +rtl=$L "$@" & wait
    grep "^T " $B/n_$t.log > $B/n_$t.trace; grep "^T " $B/r_$t.log > $B/r_$t.trace
    local why=""
    ok n_$t || why="native fails ($B/n_$t.log)"
    [ -z "$why" ] && { ok r_$t || why="run-time build fails ($B/r_$t.log)"; }
    [ -z "$why" ] && { cmp -s <(lines n_$t) <(lines r_$t) || why="per-launch lines differ (diff $B/n_$t.log $B/r_$t.log)"; }
    [ -z "$why" ] && { cmp -s $B/n_$t.trace $B/r_$t.trace || why="tree bursts differ: $(diff $B/n_$t.trace $B/r_$t.trace | head -2 | tr '\n' ' ')"; }
    if [ -z "$why" ]; then pass "$lab: identical ($(wc -l < $B/n_$t.trace) bursts, $(lines n_$t | grep -c 'size=') launches; $(grep -oE 'run1: size=[0-9]+ .*latency min/max=[0-9/]+' $B/n_$t.log | grep -oE 'latency min/max=[0-9/]+'))"
    else fail "$lab: $why"; rm -f $B/n_$t.trace $B/r_$t.trace; fi
    [ -z "$why" ] && rm -f $B/n_$t.log $B/r_$t.log                     # the traces stay (comparable later); logs only on failure
}
# the testbench commands (the regression's, with packed records and a split where they apply)
small_tests() {   # small_tests <native> <rt> <L> <prefix> <top bytes> [4k]
    local nb=$1 rb=$2 L=$3 p=$4 top=$5 c="+cmds=120 +cmds2=40" c2="+cmds=40 +cmds2=10" wl=200 sa=2000
    [ "${6:-}" = 4k ] && { c="+cmds=40 +cmds2=12"; c2="+cmds=12 +cmds2=4"; sa=6000; }
    # the testbench holds 4096 commands per launch: no preload above N = 4096 blocks (L > 10); those tests then run
    # on the empty tree with 32 repeated keys instead
    local pre=+preload; [ $((4 << L)) -gt 4096 ] && pre=+keys=32
    eqpair $nb $rb $L "$p e2e"      $c
    [ $pre = +preload ] && eqpair $nb $rb $L "$p preload"  +preload $c2
    eqpair $nb $rb $L "$p gaps"     +host_rdy_gap=30 +host_gap=30 $c2
    eqpair $nb $rb $L "$p wlat"     +host_wlat=$wl $pre $c2
    eqpair $nb $rb $L "$p packed8"  +packed=8 $pre $c2
    eqpair $nb $rb $L "$p ranges"   +ranges $pre +host_gap=30 $c2
    eqpair $nb $rb $L "$p split"    +top=$top +packed=8 $pre +host_gap=30 +host_rdy_gap=30 $c2
    eqpair $nb $rb $L "$p slowack"  $pre +host_wlat_after=$sa $c2
    eqpair $nb $rb $L "$p keys"     +keys=32 +packed=8 $c
}
SET=${RTEQ_SET:-full}
echo "== the geometry table against the native constants"
g=$B/geo_probe; rm -rf $g; mkdir -p $g
cp $TOR/fetch_tinyoram.sh $g/ && cp -r $TOR/config $TOR/patches $g/ && ln -s $(cd $TOR && pwd)/upstream $g/upstream
np=0; nbad=""
for sz in 64 128 256 4k; do for L in $(seq 6 22); do
    bash $g/fetch_tinyoram.sh $sz $L > $g/fetch.log 2>&1 || { nbad="$nbad $sz/$L(fetch)"; continue; }
    iverilog -g2012 -I$g/build/src -o $g/a.out -s probe ./tb_rtgeo_probe.v $g/build/src/TinyRTGeo.v > $g/c.log 2>&1 || { nbad="$nbad $sz/$L(compile)"; continue; }
    vvp -n $g/a.out > $g/p_${sz}_$L.log 2>&1; np=$((np+1))
    grep -q " 0 mismatches" $g/p_${sz}_$L.log || nbad="$nbad $sz/$L"
done; done
[ -z "$nbad" ] && pass "TinyRTGeo equals the native constants at $np geometries (64/128/256 B and 4 KB, L = 6..22)" || fail "TinyRTGeo differs from the native constants at:$nbad ($g)"
echo "== run-time depth vs native ($SET)"
# 64 B, merged bursts: L_max = 12 run at 6, 7, 9 and 12 (one subtree, a short bottom subtree, PosMap recursion
# depth 1 / 2 / 3, all three dummy-leaf PRNG widths are 8/16 bits here; 12 = L_max itself)
mk r64_12m 524288 64 12 merge rtdepth
for L in 6 7 9 12; do
    if [ $SET = quick ] && [ $L != 9 ]; then continue; fi
    [ $SET = mutants ] && continue
    mk n64_${L}m 524288 64 $L merge
    small_tests n64_${L}m r64_12m $L "64 B merged, L=$L on L_max=12" 16384
done
if [ $SET = full ]; then
    # 64 B, 1:1 adapter: L = 9 on L_max = 12
    mk r64_12 524288 64 12 rtdepth; mk n64_9 524288 64 9
    small_tests n64_9 r64_12 9 "64 B 1:1, L=9 on L_max=12" 16384
    # 64 B, merged: the planned card build (L_max = 19, 2M blocks) run at L = 15 (Q1's depth, 32-bit dummy-leaf PRNG
    # in the native build of 19 but 16-bit at 15) and at 12; no preload at these depths (too slow to simulate)
    mk r64_19m 1048576 64 19 merge rtdepth; mk n64_15m 1048576 64 15 merge
    for t in "e2e:+cmds=60 +cmds2=20" "keys:+keys=64 +packed=8 +cmds=120 +cmds2=40" "split:+top=49152 +packed=8 +host_gap=30 +host_rdy_gap=30 +cmds=60 +cmds2=20" "slowack:+host_wlat_after=2000 +keys=64 +cmds=60 +cmds2=20"; do
        eqpair n64_15m r64_19m 15 "64 B merged, L=15 on L_max=19 ${t%%:*}" ${t#*:}
    done
    # (the testbench's random stream depends on the tree buffer's size: the native build gets the same buffer)
    mk n64_12mw 1048576 64 12 merge
    eqpair n64_12mw r64_19m 12 "64 B merged, L=12 on L_max=19 keys" +keys=64 +packed=8 +cmds=120 +cmds2=40
    # 4 KB, merged: L_max = 9 run at 6 and 8 (subtrees of 2 levels: tall and short bottom subtrees alternate)
    mk r4k_9m 4194304 4k 9 merge rtdepth
    for L in 6 8; do mk n4k_${L}m 4194304 4k $L merge; small_tests n4k_${L}m r4k_9m $L "4 KB merged, L=$L on L_max=9" 1048576 4k; done
fi
if [ $SET = full ] || [ $SET = mutants ]; then
    echo "== mutants of patch 08: each must break the equivalence (or fail the run)"
    mk r64_12m 524288 64 12 merge rtdepth; mk n64_9m 524288 64 9 merge; mk n64_7m 524288 64 7 merge
    mut() {   # mut [-eq] <name> <file> <old> <new> <native> <L> <label> <tb args...>: a copy of r64_12m's sources with one edit
        local want=caught; [ "$1" = -eq ] && { want=equal; shift; }   # -eq: an edit expected to make no observable difference
        local name=$1 file=$2 old=$3 new=$4 nb=$5 L=$6 lab=$7; shift 7; local g=$B/$name
        if [ ! -x $g/obj/Vtb ] || [ -n "${REBUILD:-}" ]; then
            rm -rf $g; mkdir -p $g/build; cp -r $B/r64_12m/build/src $g/build/src
            python3 - "$g/build/src/$file" "$old" "$new" <<'PY' || { fail "mutant $name: edit not applied"; return; }
import sys; p, o, n = sys.argv[1:4]; s = open(p).read()
if s.count(o) != 1: sys.exit("not found once: " + o)
open(p, 'w').write(s.replace(o, n))
PY
            verilator $VFLAGS -I$g/build/src -DSIMULATION -DTB_HOST_WORDS=524288 --top-module tb_tinyoram_kernel ./tb_tinyoram_kernel.v ./axi_mem_model.v \
                $TOR/rtl/tinyoram_kernel.v $TOR/rtl/tinyoram_axi_adapter.v $(sed "s#^#$g/build/src/#" $g/build/src/files.f | tr '\n' ' ') \
                -Mdir $g/obj -o Vtb > $g/build.log 2>&1 || { fail "mutant $name: does not build ($g/build.log)"; return; }
        fi
        local f0=$FAILS n0=$NCHK
        eqpair $nb $name $L "mutant $name ($lab)" +limit=6000000 "$@" > $B/mut_$name.out
        local got=equal; [ $FAILS -gt $f0 ] && got=caught; FAILS=$f0; NCHK=$n0
        if [ $want = caught ] && [ $got = caught ]; then pass "mutant $name ($lab) caught: $(sed -E 's/^ *FAIL *//; s/^mutant [^:]*: //' $B/mut_$name.out | cut -c1-100)"
        elif [ $want = caught ]; then fail "mutant $name ($lab) MISSED: the run-time build still matched"
        elif [ $got = equal ]; then pass "no observable effect, as expected: $name ($lab)"
        else fail "$name ($lab) was expected to make no observable difference, but: $(sed -E 's/^ *FAIL *//' $B/mut_$name.out | cut -c1-100)"; fi
    }
    mut m_nvb    UORAMController.v "AddrQ[QDepth+1] = RTGeo[\`RTG_NVB] + AddrQ[QDepth] / LeafInBlock;" "AddrQ[QDepth+1] = NumValidBlock + AddrQ[QDepth] / LeafInBlock;" \
        n64_9m 9 "PosMap block addresses from the build's N" +keys=32 +packed=8 +cmds=60 +cmds2=20
    # three edits that must make no observable difference (bursts, cycles, block bytes, latencies): the stash's
    # capacity only shows at an overflow, which the background eviction prevents, and its list rebuild is hidden under
    # the path write-back; leaf bits above L are ignored by every path and placement decision (the level mask), so
    # the leaf masks only keep the stored leaf values those of the native build
    mut -eq m_sync StashCore.v "SyncCount_PreLatch == (RTGeo[\`RTG_CAP] - 32'd1);" "SyncCount_PreLatch == (StashCapacity - 32'd1);" \
        n64_9m 9 "stash list rebuild over the build's capacity" +preload +cmds=40 +cmds2=10
    mut m_level  StashScanTable.v " | (i > RTGeo[\`RTG_L]);" ";" n64_9m 9 "no level mask: blocks placed below the leaves" +preload +cmds=40 +cmds2=10
    mut m_prng   BackendCoreController.v "wire	[2:0]			DL_K = RTGeo[\`RTG_PRNGK];" "wire	[2:0]			DL_K = 3'd4;" \
        n64_9m 9 "one 32-bit dummy-leaf PRNG for every depth" +preload +cmds=40 +cmds2=10
    mut m_layout AddrGenBktHead.v "<< RTGeo[\`RTG_LSB]) :" "<< LogSTSizeBottom) :" n64_7m 7 "the build's subtree layout" +cmds=60 +cmds2=20
    mut m_aes    AESPathORAM.v "wire [15:0] PathCmp_RT = RTGeo[\`RTG_PBED] - 1'b1;" "wire [15:0] PathCmp_RT = PathSize_BEDChunks - 1;" \
        n64_9m 9 "the build's path length in the AES path counter" +cmds=60 +cmds2=20
    mut m_wb     Stash.v "assign	ReadingLastBlock =" "assign	ReadingLastBlock = 1'b0 &" n64_9m 9 "write-back never ends (BlocksOnPath ignored)" +cmds=20 +cmds2=6
    mut m_fstart PosMapPLB.v "assign InOnChipPosMap = AddrIn >= RTGeo[\`RTG_FSTART];" "assign InOnChipPosMap = AddrIn >= FinalPosMapStart;" \
        n64_9m 9 "the build's final PosMap start" +keys=32 +packed=8 +cmds=60 +cmds2=20
    mut -eq m_leaf IntegrityVerifier.v "AESDataOut[ORAML-1:0] & RTGeo[\`RTG_LMASK];" "AESDataOut[ORAML-1:0];" n64_9m 9 "PRF leaves of the build's width" +keys=32 +packed=8 +cmds=60 +cmds2=20
    mut -eq m_dleaf BackendCoreController.v "DummyLeaf_Wide[ORAML-1:0] & RTGeo[\`RTG_LMASK];" "DummyLeaf_Wide[ORAML-1:0];" n64_9m 9 "dummy leaves of the PRNG's width" +preload +cmds=40 +cmds2=10
fi
echo "== the run-time build alone"
# a re-boot to another depth (+rtl2): the second session must be a correct ORAM of the new depth
run r64_12m reb +rtl=9 +reboot +rtl2=6 +packed=8 +preload +cmds=40 +cmds2=10
ok reb && grep -q "^init2:" $B/reb.log && pass "re-boot from L=9 to L=6 on L_max=12: both sessions correct" || fail "re-boot to another depth ($B/reb.log)"
# an unsupported depth: L_max is kept and the init reports 0x100 (+rtlbad: the testbench expects both)
for K in 13 5; do
    run r64_12m bad$K +rtlbad=$K +cmds=20 +cmds2=6
    ok bad$K && grep -qE "^init: .*errors=00000100" $B/bad$K.log \
        && pass "an unsupported depth ($K on L_max=12): status 0x100, then a correct ORAM of depth L_max" || fail "unsupported depth $K ($B/bad$K.log)"
done
echo
if [ $FAILS = 0 ]; then echo "ALL $NCHK RUN-TIME DEPTH CHECKS PASSED"; exit 0; else echo "$FAILS OF $NCHK CHECK(S) FAILED"; exit 1; fi
