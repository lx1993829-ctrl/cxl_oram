// tinyoram_axi_adapter.v -- Tiny ORAM's DRAM interface to AXI4 (m_axi_gmem2 and m_axi_gmem3).
//
// Tiny ORAM issues 64-byte memory commands (one DDR3 burst each, DRAMAddress in 64-bit words) and
// expects the in-order DDR3 MIG it was designed for. This adapter gives it that on AXI:
//   * MERGE = 0 (1:1): every command becomes its own AXI burst of DDR_BITS/DW beats (2 at 256 bits).
//     MERGE = 1: consecutive commands of the same direction to contiguous addresses are merged into one
//     burst (a bucket is a run of contiguous commands), up to MAX_BEATS beats, never across a 4 KB
//     boundary or the top/bottom split. A burst is closed by a command that does not continue it, by
//     MERGE_WAIT idle cycles, or by a limit. Nothing inside Tiny ORAM changes.
//   * tree split: byte offsets below top_bytes go to port T (gmem3, on-package HBM), the rest to port H
//     (gmem2, host memory or HBM). Tiny ORAM lays its tree out subtree by subtree in breadth-first order,
//     so the low offsets are the top of the tree: top_bytes is a tree-top cache of that many bytes.
//     top_bytes = 0: everything on port H.
//   * single ID per port, so each port returns reads in order; read data from the two ports is
//     delivered to Tiny ORAM in command order (a per-burst order FIFO), write data likewise.
//   * ordering Tiny ORAM assumes from a DDR3 MIG and AXI does not give: no read is issued while any
//     earlier write is pending or unacknowledged (no B yet), on either port, and no write is issued
//     while any earlier read still has data to return. (doma_kernel holds reads the same way.)
//   * read data: Tiny ORAM has no ready on it, so beats are buffered here (one buffer per port); a read
//     joins a burst only when its port's buffer has room for all its beats (rready stays high).
//   * write data: Tiny ORAM's AES has only about two buckets of keystream buffering and no way to stall
//     it, so a long W-channel stall would lose keystream ("Lose Masks!"). Like a memory controller's
//     write FIFO, a buffer of 2^WBUF_LOG2 beats absorbs AXI write stalls; beats leave it only after
//     their burst's AW has been accepted.
// Status: quiet_w (every write beat Tiny ORAM sent is on a bus), wdone (no B outstanding), idle, error
// (a non-OKAY response or an address beyond the tree), and beat counters (both ports).
`timescale 1ns/1ps
module tinyoram_axi_adapter #(
    parameter integer DW         = 256,   // AXI data width = Tiny ORAM BEDWidth
    parameter integer DDR_BITS   = 512,   // Tiny ORAM DDRDWidth (one command)
    parameter integer AW_CORE    = 20,    // Tiny ORAM DDRAWidth
    parameter [63:0]  TREE_BYTES = 64'd0, // size of the tree region; 0 = no range check
    parameter integer RBUF_LOG2  = 9,     // read buffer depth per port (beats) = 2^RBUF_LOG2
    parameter integer WBUF_LOG2  = 9,     // write buffer depth (beats) = 2^WBUF_LOG2
    parameter integer MERGE      = 0,     // 0: one burst per command (1:1); 1: merge contiguous commands
    parameter integer MAX_BEATS  = 128,   // merged burst limit in beats (128 x 32 B = 4 KB)
    parameter integer MERGE_WAIT = 4,     // idle cycles an open burst waits for a contiguous command
    parameter integer FQ_LOG2    = 6      // order FIFOs (closed bursts in flight) = 2^FQ_LOG2 entries
) (
    input  wire               clk,
    input  wire               rst,          // synchronous, active high
    input  wire [63:0]        base,         // port H: byte address of the tree region (latched pages)
    input  wire [63:0]        base_t,       // port T: byte address of the tree-top region
    input  wire [63:0]        top_bytes,    // offsets below this go to port T (a multiple of 4 KB)
    input  wire [63:0]        tree_lim,     // the tree's size for the range check (TREE_BYTES, or the active depth's)
    // ---- Tiny ORAM side ----
    input  wire [AW_CORE-1:0] core_addr,    // in 64-bit words
    input  wire [2:0]         core_cmd,     // 0 write, 1 read
    input  wire               core_cmd_valid,
    output wire               core_cmd_ready,
    output reg  [DW-1:0]      core_rdata,
    output reg                core_rvalid,
    input  wire [DW-1:0]      core_wdata,
    input  wire               core_wvalid,
    output wire               core_wready,
    // ---- AXI4 master H (gmem2) ----
    output wire [63:0]        araddr,  output wire [7:0] arlen, output wire [2:0] arsize, output wire [1:0] arburst,
    output wire               arvalid, input  wire       arready,
    input  wire [DW-1:0]      rdata,   input  wire [1:0] rresp, input wire rlast, input wire rvalid, output wire rready,
    output wire [63:0]        awaddr,  output wire [7:0] awlen, output wire [2:0] awsize, output wire [1:0] awburst,
    output wire               awvalid, input  wire       awready,
    output wire [DW-1:0]      wdata,   output wire [DW/8-1:0] wstrb, output wire wlast, output wire wvalid, input wire wready,
    input  wire [1:0]         bresp,   input  wire       bvalid, output wire bready,
    // ---- AXI4 master T (gmem3) ----
    output wire [63:0]        t_araddr,  output wire [7:0] t_arlen, output wire [2:0] t_arsize, output wire [1:0] t_arburst,
    output wire               t_arvalid, input  wire       t_arready,
    input  wire [DW-1:0]      t_rdata,   input  wire [1:0] t_rresp, input wire t_rlast, input wire t_rvalid, output wire t_rready,
    output wire [63:0]        t_awaddr,  output wire [7:0] t_awlen, output wire [2:0] t_awsize, output wire [1:0] t_awburst,
    output wire               t_awvalid, input  wire       t_awready,
    output wire [DW-1:0]      t_wdata,   output wire [DW/8-1:0] t_wstrb, output wire t_wlast, output wire t_wvalid, input wire t_wready,
    input  wire [1:0]         t_bresp,   input  wire       t_bvalid, output wire t_bready,
    // ---- status ----
    output wire               quiet_w,      // no write pending and every write beat Tiny ORAM sent is on a bus
    output wire               wdone,        // every issued write acknowledged (no B outstanding)
    output wire               idle,         // nothing queued, nothing outstanding (incl. B)
    output reg                error,        // sticky: SLVERR/DECERR or address outside the tree
    output reg  [63:0]        rd_beats,     // AXI read beats received, both ports (traffic counter)
    output reg  [63:0]        wr_beats      // AXI write beats sent, both ports
);
    localparam integer BPC   = DDR_BITS / DW;           // beats per command
    localparam integer BB    = DW / 8;                  // bytes per beat
    localparam integer DEPTH = 1 << RBUF_LOG2;
    localparam integer MAXB  = (MERGE != 0) ? MAX_BEATS : BPC;
    localparam integer FQD   = 1 << FQ_LOG2;
`ifndef SYNTHESIS
    initial if (DDR_BITS % DW != 0 || BPC < 1 || MAXB > 256 || MAXB % BPC != 0 || MAXB * BB > 4096) begin
        $display("ERROR: tinyoram_axi_adapter: DDR_BITS a multiple of DW; MAX_BEATS a multiple of the command, <= 256 beats and <= 4 KB"); $finish; end
`endif

    // ---------------- command queue (4 deep, registered ready) ----------------
    reg  [AW_CORE-1:0] cq_addr [0:3];
    reg                cq_rd   [0:3];
    reg  [1:0]         cq_wp, cq_rp;
    reg  [2:0]         cq_n;
    wire               cq_push = core_cmd_valid && core_cmd_ready;
    wire               cq_pop;
    assign core_cmd_ready = (cq_n < 3'd3);               // depends on a register only
    wire [AW_CORE-1:0] h_addr = cq_addr[cq_rp];
    wire               h_rd   = cq_rd[cq_rp];
    wire               h_val  = (cq_n != 3'd0);
    wire [63:0]        h_off  = {{(64-AW_CORE-3){1'b0}}, h_addr, 3'b000};   // byte offset in the tree
    wire               h_t    = (h_off < top_bytes);                         // port T (tree top)

    // ---------------- hazard bookkeeping ----------------
    reg  [15:0] b_out;                  // AWs accepted (both ports) whose B has not arrived
    reg  [15:0] rres_h, rres_t;         // read beats reserved (joined a burst) and not yet received, per port
    reg  [RBUF_LOG2:0] rbn_h, rbn_t;    // beats held in each read buffer
    reg         arv_h, arv_t, awv_h, awv_t;
    reg  [63:0] ara_h, ara_t, awa_h, awa_t;
    reg  [7:0]  arl_h, arl_t, awl_h, awl_t;
    // the open (merging) burst
    reg         m_v, m_rd, m_t;
    reg  [63:0] m_off;
    reg  [8:0]  m_beats;
    reg  [7:0]  m_wait;
    wire [63:0] m_next = m_off + {55'd0, m_beats} * BB;                     // offset just past the open burst
    // order FIFOs (closed bursts, in command order): reads (port, beats) and writes (port, beats)
    reg         of_t [0:FQD-1];  reg [8:0] of_n [0:FQD-1];
    reg  [FQ_LOG2-1:0] of_wp, of_rp; reg [FQ_LOG2:0] of_cnt;
    reg         wf_t [0:FQD-1];  reg [8:0] wf_n [0:FQD-1];
    reg  [FQ_LOG2-1:0] wf_wp, wf_rp; reg [FQ_LOG2:0] wf_cnt;
    reg  [15:0] awf_h, awf_t;           // AWs accepted per port whose W beats have not all been sent

    wire room_h = ({{(16-RBUF_LOG2-1){1'b0}}, rbn_h} + rres_h + BPC <= DEPTH);
    wire room_t = ({{(16-RBUF_LOG2-1){1'b0}}, rbn_t} + rres_t + BPC <= DEPTH);
    wire room   = h_t ? room_t : room_h;
    wire wpend  = (b_out != 16'd0) || awv_h || awv_t || (m_v && !m_rd) || (wf_cnt != 0);
    wire rd_ok  = !wpend && room;
    wire wr_ok  = (rres_h == 16'd0) && (rres_t == 16'd0) && (b_out < 16'hFFF0);
    wire of_full = (of_cnt >= FQD - 1), wf_full = (wf_cnt >= FQD - 1);

    wire merge_ok = (MERGE != 0) && m_v && h_val && (h_rd == m_rd) && (h_t == m_t) && (h_off == m_next) &&
                    (m_next[11:0] != 12'd0) && (m_beats + BPC <= MAXB) && (h_rd ? room : 1'b1);
    wire reg_free = m_rd ? (m_t ? !arv_t : !arv_h) : (m_t ? !awv_t : !awv_h);
    wire fifo_ok  = m_rd ? !of_full : !wf_full;
    wire close_want = m_v && !merge_ok && ((MERGE == 0) || (m_beats + BPC > MAXB) || (m_next[11:0] == 12'd0) ||
                                           h_val || (m_wait >= MERGE_WAIT));
    wire close_now  = close_want && reg_free && fifo_ok;
    // a new burst opens from the head when the slot is free (or freed this cycle); the hazard checks see
    // the burst being closed as still pending, so a read never opens behind a write or vice versa
    wire open_now = h_val && !merge_ok && (!m_v || close_now) && (h_rd ? rd_ok : wr_ok);
    assign cq_pop = merge_ok || open_now;

    assign arvalid = arv_h; assign araddr = ara_h; assign arlen = arl_h;
    assign awvalid = awv_h; assign awaddr = awa_h; assign awlen = awl_h;
    assign t_arvalid = arv_t; assign t_araddr = ara_t; assign t_arlen = arl_t;
    assign t_awvalid = awv_t; assign t_awaddr = awa_t; assign t_awlen = awl_t;
    assign arsize = $clog2(BB); assign awsize = $clog2(BB); assign t_arsize = $clog2(BB); assign t_awsize = $clog2(BB);
    assign arburst = 2'b01; assign awburst = 2'b01; assign t_arburst = 2'b01; assign t_awburst = 2'b01;
    wire arf_h = arv_h && arready, arf_t = arv_t && t_arready;
    wire awf_hf = awv_h && awready, awf_tf = awv_t && t_awready;

    // ---------------- write data: buffer, then out to the port of the oldest burst ----------------
    localparam integer WDEPTH = 1 << WBUF_LOG2;
    reg  [DW-1:0] wbuf [0:WDEPTH-1];
    reg  [WBUF_LOG2-1:0] wb_wp, wb_rp;
    reg  [WBUF_LOG2:0]   wb_n;          // beats in wbuf (not counting the output register)
    reg  [DW-1:0] wout;                 // output register (head beat)
    reg           wout_v;
    reg  [8:0]    wbeat;                // beat within the oldest write burst
    reg           wb_full;              // registered: core_wready depends on a register only
    wire   wb_push   = core_wvalid && core_wready;
    assign core_wready = !wb_full;
    wire   wf_v      = (wf_cnt != 0);
    wire   wf_head_t = wf_t[wf_rp];
    wire [8:0] wf_head_n = wf_n[wf_rp];
    wire   w_go      = wout_v && wf_v && (wf_head_t ? (awf_t != 16'd0) : (awf_h != 16'd0));
    assign wvalid    = w_go && !wf_head_t;
    assign t_wvalid  = w_go &&  wf_head_t;
    assign wdata     = wout;  assign t_wdata = wout;
    assign wstrb     = {(DW/8){1'b1}}; assign t_wstrb = {(DW/8){1'b1}};
    assign wlast     = (wbeat == wf_head_n - 9'd1); assign t_wlast = wlast;
    wire   w_fire    = (wvalid && wready) || (t_wvalid && t_wready);
    wire   w_end     = w_fire && (wbeat == wf_head_n - 9'd1);
    wire   wb_load   = (wb_n != 0) && (!wout_v || w_fire);     // move the next beat into the output register
    assign bready    = 1'b1; assign t_bready = 1'b1;
    assign quiet_w   = !(m_v && !m_rd) && !awv_h && !awv_t && !wf_v && !(h_val && !h_rd) && (wb_n == 0) && !wout_v;
    assign wdone     = (b_out == 16'd0);
    assign idle      = (cq_n == 3'd0) && !m_v && !arv_h && !arv_t && !awv_h && !awv_t && (b_out == 16'd0) &&
                       (rres_h == 16'd0) && (rres_t == 16'd0) && (rbn_h == 0) && (rbn_t == 0) && (of_cnt == 0) &&
                       !wf_v && (wb_n == 0) && !wout_v;
    always @(posedge clk) begin
        if (wb_push) wbuf[wb_wp] <= core_wdata;
        if (wb_load) wout <= wbuf[wb_rp];
    end

    // ---------------- read buffers (one per port) and in-order delivery ----------------
    reg  [DW-1:0] rbuf_h [0:DEPTH-1];
    reg  [DW-1:0] rbuf_t [0:DEPTH-1];
    reg  [RBUF_LOG2-1:0] rwp_h, rrp_h, rwp_t, rrp_t;
    assign rready = 1'b1; assign t_rready = 1'b1;       // room was reserved when the read joined its burst
    wire   of_v      = (of_cnt != 0);
    wire   of_head_t = of_t[of_rp];
    reg  [8:0] of_left;                                 // beats of the oldest read burst still to deliver
    wire   pop_t = of_v && of_head_t  && (rbn_t != 0);
    wire   pop_h = of_v && !of_head_t && (rbn_h != 0);
    wire [8:0] of_cur = (of_left == 9'd0) ? of_n[of_rp] : of_left;   // beats left, counting this one
    wire   of_last = (pop_t || pop_h) && (of_cur == 9'd1);
    always @(posedge clk) begin
        if (rvalid)   rbuf_h[rwp_h] <= rdata;
        if (t_rvalid) rbuf_t[rwp_t] <= t_rdata;
        if (pop_h) core_rdata <= rbuf_h[rrp_h];
        if (pop_t) core_rdata <= rbuf_t[rrp_t];
    end

    always @(posedge clk) begin
        if (rst) begin
            cq_wp <= 0; cq_rp <= 0; cq_n <= 0;
            b_out <= 0; rres_h <= 0; rres_t <= 0; rbn_h <= 0; rbn_t <= 0;
            arv_h <= 1'b0; arv_t <= 1'b0; awv_h <= 1'b0; awv_t <= 1'b0;
            ara_h <= 0; ara_t <= 0; awa_h <= 0; awa_t <= 0; arl_h <= 0; arl_t <= 0; awl_h <= 0; awl_t <= 0;
            m_v <= 1'b0; m_rd <= 1'b0; m_t <= 1'b0; m_off <= 64'd0; m_beats <= 9'd0; m_wait <= 8'd0;
            of_wp <= 0; of_rp <= 0; of_cnt <= 0; of_left <= 9'd0; wf_wp <= 0; wf_rp <= 0; wf_cnt <= 0;
            awf_h <= 0; awf_t <= 0; wbeat <= 9'd0;
            rwp_h <= 0; rrp_h <= 0; rwp_t <= 0; rrp_t <= 0; core_rvalid <= 1'b0;
            wb_wp <= 0; wb_rp <= 0; wb_n <= 0; wout_v <= 1'b0; wb_full <= 1'b0;
            error <= 1'b0; rd_beats <= 64'd0; wr_beats <= 64'd0;
        end else begin
            // queue
            if (cq_push) begin cq_addr[cq_wp] <= core_addr; cq_rd[cq_wp] <= (core_cmd == 3'd1); cq_wp <= cq_wp + 1'b1; end
            if (cq_pop)  cq_rp <= cq_rp + 1'b1;
            cq_n <= cq_n + (cq_push ? 3'd1 : 3'd0) - (cq_pop ? 3'd1 : 3'd0);
            if (cq_pop && TREE_BYTES != 0 && h_off + DDR_BITS / 8 > tree_lim) error <= 1'b1;

            // the open burst: extend, close, open
            if (merge_ok) begin m_beats <= m_beats + BPC; m_wait <= 8'd0; end
            else if (m_v && !(close_now)) m_wait <= (m_wait == 8'hFF) ? m_wait : m_wait + 8'd1;
            if (close_now) begin
                if (m_rd) begin
                    if (m_t) begin arv_t <= 1'b1; ara_t <= base_t + m_off; arl_t <= m_beats - 9'd1; end
                    else     begin arv_h <= 1'b1; ara_h <= base   + m_off; arl_h <= m_beats - 9'd1; end
                    of_t[of_wp] <= m_t; of_n[of_wp] <= m_beats; of_wp <= of_wp + 1'b1;
                end else begin
                    if (m_t) begin awv_t <= 1'b1; awa_t <= base_t + m_off; awl_t <= m_beats - 9'd1; end
                    else     begin awv_h <= 1'b1; awa_h <= base   + m_off; awl_h <= m_beats - 9'd1; end
                    wf_t[wf_wp] <= m_t; wf_n[wf_wp] <= m_beats; wf_wp <= wf_wp + 1'b1;
                end
                m_v <= 1'b0;
            end
            if (open_now) begin
                m_v <= 1'b1; m_rd <= h_rd; m_t <= h_t; m_off <= h_off; m_beats <= BPC; m_wait <= 8'd0;
            end
            if (arf_h) arv_h <= 1'b0;
            if (arf_t) arv_t <= 1'b0;
            if (awf_hf) awv_h <= 1'b0;
            if (awf_tf) awv_t <= 1'b0;
            of_cnt <= of_cnt + ((close_now && m_rd) ? 1'b1 : 1'b0) - (of_last ? 1'b1 : 1'b0);
            wf_cnt <= wf_cnt + ((close_now && !m_rd) ? 1'b1 : 1'b0) - (w_end ? 1'b1 : 1'b0);

            // outstanding counts
            b_out  <= b_out + (awf_hf ? 16'd1 : 16'd0) + (awf_tf ? 16'd1 : 16'd0)
                            - ((bvalid && bready) ? 16'd1 : 16'd0) - ((t_bvalid && t_bready) ? 16'd1 : 16'd0);
            rres_h <= rres_h + ((cq_pop && h_rd && !h_t) ? BPC : 16'd0) - (rvalid   ? 16'd1 : 16'd0);
            rres_t <= rres_t + ((cq_pop && h_rd &&  h_t) ? BPC : 16'd0) - (t_rvalid ? 16'd1 : 16'd0);
            awf_h  <= awf_h + (awf_hf ? 16'd1 : 16'd0) - ((w_end && !wf_head_t) ? 16'd1 : 16'd0);
            awf_t  <= awf_t + (awf_tf ? 16'd1 : 16'd0) - ((w_end &&  wf_head_t) ? 16'd1 : 16'd0);
            if (w_fire) wbeat <= w_end ? 9'd0 : wbeat + 9'd1;
            if (w_end) wf_rp <= wf_rp + 1'b1;
            // write buffer
            if (wb_push) wb_wp <= wb_wp + 1'b1;
            if (wb_load) wb_rp <= wb_rp + 1'b1;
            wb_n <= wb_n + (wb_push ? 1'b1 : 1'b0) - (wb_load ? 1'b1 : 1'b0);
            if (wb_load) wout_v <= 1'b1; else if (w_fire) wout_v <= 1'b0;
            wb_full <= (wb_n + (wb_push ? 1 : 0) - (wb_load ? 1 : 0)) >= WDEPTH - 2;
            // read buffers and delivery in command order
            if (rvalid)   rwp_h <= rwp_h + 1'b1;
            if (t_rvalid) rwp_t <= rwp_t + 1'b1;
            if (pop_h) rrp_h <= rrp_h + 1'b1;
            if (pop_t) rrp_t <= rrp_t + 1'b1;
            rbn_h <= rbn_h + (rvalid   ? 1'b1 : 1'b0) - (pop_h ? 1'b1 : 1'b0);
            rbn_t <= rbn_t + (t_rvalid ? 1'b1 : 1'b0) - (pop_t ? 1'b1 : 1'b0);
            if (pop_h || pop_t) begin
                if (of_last) begin of_rp <= of_rp + 1'b1; of_left <= 9'd0; end
                else of_left <= of_cur - 9'd1;
            end
            core_rvalid <= pop_h || pop_t;
            // status
            if ((rvalid && rresp != 2'b00) || (bvalid && bresp != 2'b00) ||
                (t_rvalid && t_rresp != 2'b00) || (t_bvalid && t_bresp != 2'b00)) error <= 1'b1;
            rd_beats <= rd_beats + (rvalid ? 64'd1 : 64'd0) + (t_rvalid ? 64'd1 : 64'd0);
            wr_beats <= wr_beats + (w_fire ? 64'd1 : 64'd0);
        end
    end
endmodule
