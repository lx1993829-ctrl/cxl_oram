#!/bin/bash
# sweep_tiny.sh -- Tiny ORAM's card sweeps, one per built bitstream of the queue, through scan.sh.
#
#   bash sweep_tiny.sh [id ...]        every entry queue.sh finished (DONE or DONE_LOWER), or only these
#   TOPS="0 doma:0 doma:20 doma:50 doma:100" (default)   CMDS=20000 (default)
#   RT_NS="100000 1000000 10000000" (64 B) / "16384 65536" (4 KB): the N swept on a run-time-depth entry (PM column rt),
#          those up to the entry's N; the host selects the depth for each at its init
#
# Settings matched to sweep_doma.sh: the same host program, generator, seed and command count. For the 64 B builds
# the matched budgets (doma:<p>) are those of doma_kernel with 32-byte blocks packed 4 per block (DOMA_MATCH_BLOCK=32,
# DOMA_PACK=1: exactly sweep_doma.sh's 32 B configuration); for the 4 KB builds, 4 KB blocks unpacked. The flat
# position map's entry (FLATPM=1) also takes its 1 MB on-chip position map off the top (DOMA_TINY_FLATPM=1).
# Output: DEST/results/tiny_q<id>_<name>.csv (scan.sh's columns) and .log (every run's full output);
# DEST/results/clocks.txt gets each bitstream's kernel clock. Pass: every row has a KQPS value, errors 0x0, bad 0.
set -u
CARD=$(cd "$(dirname "$0")" && pwd)
PKG=$(cd "$CARD/../.." && pwd)
DEST=${DEST:-$(dirname "$(dirname "$PKG")")}
Q=$DEST/queue; RES=$DEST/results; mkdir -p "$RES"
XRT_SETUP=${XRT_SETUP:-/opt/xilinx/xrt/setup.sh}
TOPS=${TOPS:-"0 doma:0 doma:20 doma:50 doma:100"}; CMDS=${CMDS:-20000}
command -v xbutil > /dev/null || source "$XRT_SETUP" > /dev/null 2>&1
st_get() { [ -f "$Q/$1.status" ] && awk -F= -v k="$2" '$1 == k {v = substr($0, length(k) + 2)} END {print v}' "$Q/$1.status"; }
fail=0
while read -r id name sz n pack cfg merge flatpm freq purpose; do
    [ $# -gt 0 ] && ! printf '%s\n' "$@" | grep -qx "$id" && continue
    stage=$(st_get $id stage); x=$(st_get $id xclbin)
    case "$stage" in DONE*) ;; *) echo "q$id $name: not built ($stage), skipped"; continue ;; esac
    d=$(dirname "$x"); [ -f "$x" ] && [ -x "$d/host_doma" ] || { echo "q$id $name: $x or its host_doma missing"; fail=1; continue; }
    bb=$sz; [ "$sz" = 4k ] && bb=4096
    ns=$n
    if [ "$flatpm" = rt ]; then   # one run-time-depth bitstream: every N of RT_NS up to its own
        ns=""; for x in ${RT_NS:-$([ $bb = 4096 ] && echo "16384 65536" || echo "100000 1000000 10000000")}; do [ $x -le $n ] && ns="$ns $x"; done
        ns=${ns# }
    fi
    env=(DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=$bb "NS=$ns" "TOPS=$TOPS" OUT=$RES/tiny_q${id}_$name.csv)
    [ "$pack" = 1 ] && env+=(DOMA_PACK=1)
    [ "$bb" = 4096 ] && env+=(DOMA_MATCH_BLOCK=4096) || env+=(DOMA_MATCH_BLOCK=32)
    [ "$flatpm" = 1 ] && env+=(DOMA_TINY_FLATPM=1)
    [ "$cfg" = tinyoram_host.cfg ] || env+=(DOMA_PAGES_HBM=1)
    echo "== q$id $name: $(basename "$x"), N=$ns, TOPS=$TOPS, $CMDS commands"
    ( cd "$d" && env "${env[@]}" bash scan.sh "$(basename "$x")" $CMDS < /dev/null )
    echo "tiny q$id $name $(st_get $id clock_mhz)" >> "$RES/clocks.txt"
    awk -F, 'NR > 1 && ($4 == "" || $9 != "0x0" || $10 != "0") {bad = 1} END {exit bad}' "$RES/tiny_q${id}_$name.csv" \
        && echo "   PASS: every row measured, errors 0x0, all responses correct" || { echo "   FAIL: see $RES/tiny_q${id}_$name.log"; fail=1; }
done < <(awk '!/^#/ && NF >= 9' "$CARD/queue.txt")
exit $fail
