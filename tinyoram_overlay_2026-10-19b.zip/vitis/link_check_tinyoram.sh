#!/bin/bash
# link_check_tinyoram.sh -- a short v++ link of the fetched Tiny ORAM sources at FREQ, stopped once the platform's block
# design is assembled, validated and its targets generated, i.e. before synthesis (about 10-20 minutes instead of hours).
# It catches what the elaboration and the out-of-context runs cannot, because they do not involve the platform: the
# clock metadata of the kernel's interfaces against the platform's kernel clock ([VPL-1] ... clock metadata ... does
# not match, which stopped q1 and q8 at FREQ = 230), the connectivity and the memory banks of CFG.
#   bash ../tinyoram/fetch_tinyoram.sh 64 6 merge
#   FREQ=230 CFG=tinyoram_host.cfg bash link_check_tinyoram.sh
# Last line: "LINK CHECK PASS: ..." (exit 0) or "LINK CHECK FAIL: ..." (exit 1). Logs: link_check_<FREQ>mhz_<cfg>_{pack,link}.log
set -u
cd "$(dirname "$0")"
PLATFORM=${PLATFORM:-xilinx_u55c_gen3x16_xdma_3_202210_1}
FREQ=${FREQ:-230}
CFG=${CFG:-tinyoram_host.cfg}
CN=$(basename "$CFG" .cfg); TAG=linkcheck_${FREQ}mhz_$CN; W=_x_$TAG; LOG=link_check_${FREQ}mhz_$CN
fail() { echo "LINK CHECK FAIL: $*"; exit 1; }
[ -f "$CFG" ] || fail "no link configuration $CFG"
[ -f ../tinyoram/build/src/files.f ] || fail "no ../tinyoram/build/src/files.f: run ../tinyoram/fetch_tinyoram.sh first"
command -v v++ > /dev/null && command -v vivado > /dev/null || fail "v++/vivado not found (source the Vitis and XRT setup scripts)"
rm -rf tinyoram_ip tinyoram_pack $W $TAG.xo
vivado -mode batch -nojournal -nolog -source package_tinyoram.tcl -tclargs ../tinyoram/rtl ../tinyoram/build/src $TAG.xo \
    > ${LOG}_pack.log 2>&1
[ -f $TAG.xo ] || fail "packaging (${LOG}_pack.log)"
f=$(unzip -p $TAG.xo '*component.xml' 2>/dev/null | grep -A2 -i "FREQ_HZ" | grep -oE "[0-9]{6,}" | head -1)
[ -n "$f" ] && [ "$f" != 300000000 ] && fail "the .xo declares ap_clk FREQ_HZ = $f, not 300000000 (package_tinyoram.tcl)"
# the latest v++ step before synthesis that this Vitis lists (generate_target, else update_bd)
steps=$(v++ -l -t hw --platform $PLATFORM --list_steps 2>/dev/null | grep -oE "vpl\.[A-Za-z_.]+" | sort -u)
stop=""; for s in vpl.generate_target vpl.update_bd; do echo "$steps" | grep -qx "$s" && { stop=$s; break; }; done
[ -n "$stop" ] || stop=vpl.generate_target      # no listing: try it anyway (v++ refuses an unknown step)
v++ -l -t hw --platform $PLATFORM --kernel_frequency $FREQ --config $CFG --save-temps --temp_dir $W --to_step $stop \
    -o $TAG.xclbin $TAG.xo > ${LOG}_link.log 2>&1
rc=$?
# v++ repeats the platform flow's errors in its own output; the flow's log (vivado.log) has them first-hand
errs=$(cat ${LOG}_link.log $W/link/vivado/vpl/vivado.log 2>/dev/null | grep -E "^ERROR:|\[VPL-1\]|\[VPL 60-|CRITICAL WARNING: \[BD" \
       | grep -v "^INFO" | awk '!seen[$0]++' | head -6)
if [ $rc = 0 ] && [ -z "$(echo "$errs" | grep -E '^ERROR:|\[VPL-1\]')" ]; then
    [ -n "$errs" ] && { echo "critical warnings:"; echo "$errs" | sed 's/^/  /'; }
    rm -rf $W $TAG.xo    # nothing past the block design was built; the log is kept
    echo "LINK CHECK PASS: v++ link at --kernel_frequency $FREQ with $CFG reaches $stop without errors (${LOG}_link.log)"
    exit 0
fi
echo "$errs" | sed 's/^/  /'
fail "v++ link at --kernel_frequency $FREQ with $CFG, stopped at $stop: exit $rc (${LOG}_link.log)"
