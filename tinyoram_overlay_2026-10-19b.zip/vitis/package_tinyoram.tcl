# package_tinyoram.tcl -- package tinyoram_kernel as a Vitis RTL kernel (.xo)  (UNTESTED here)
# Usage (after ../tinyoram/fetch_tinyoram.sh <size>):
#   vivado -mode batch -source package_tinyoram.tcl -tclargs ../tinyoram/rtl ../tinyoram/build/src tinyoram_kernel.xo
# The kernel IP always declares ap_clk at 300 MHz, as package_kernel.tcl (doma_kernel) does; the real clock comes from
# v++ --kernel_frequency at link. A FREQ_HZ other than the platform kernel clock's default metadata (300 MHz) fails
# the link ([VPL-1] ulp_memory_subsystem_0: ... clock metadata ... does not match), so a fourth argument (the old
# [MHz]) is accepted and ignored.
# Same flow and settings as package_kernel.tcl (doma_kernel); the sources are our wrapper and
# adapter plus Tiny ORAM's patched sources and headers, all in one flat directory, so every
# `include resolves next to the file that includes it.
set rtl_dir [lindex $argv 0]
set src_dir [lindex $argv 1]
set xo_path [lindex $argv 2]
set part    xcu55c-fsvh2892-2L-e
set ip_dir  ./tinyoram_ip

create_project -force tinyoram_pack ./tinyoram_pack -part $part
add_files -norecurse [list $rtl_dir/tinyoram_kernel.v $rtl_dir/tinyoram_axi_adapter.v]
add_files -norecurse [glob $src_dir/*.v $src_dir/*.vh $src_dir/DRAM.constants]
set_property file_type {Verilog Header} [get_files -regexp {.*\.(vh|constants)$}]
set_property include_dirs [list $src_dir] [current_fileset]
set_property top tinyoram_kernel [current_fileset]
update_compile_order -fileset sources_1

ipx::package_project -root_dir $ip_dir -vendor user.org -library kernel -taxonomy /KernelIP -import_files -set_current false
ipx::unload_core $ip_dir/component.xml
ipx::edit_ip_in_project -upgrade true -name tmp_edit_project -directory $ip_dir $ip_dir/component.xml
set core [ipx::current_core]
set_property core_revision 1 $core
foreach up [ipx::get_user_parameters] { ipx::remove_user_parameter [get_property NAME $up] $core }

foreach bif {s_axi_control m_axi_gmem0 m_axi_gmem1 m_axi_gmem2 m_axi_gmem3} {
    ipx::associate_bus_interfaces -busif $bif -clock ap_clk $core
}
set clkbif [ipx::get_bus_interfaces -of $core ap_clk]
set_property value 300000000 [ipx::add_bus_parameter -quiet FREQ_HZ $clkbif]   ;# always 300 MHz: v++ --kernel_frequency sets the clock

set mm [ipx::add_memory_map -quiet s_axi_control $core]
set ab [ipx::add_address_block -quiet reg0 $mm]
foreach {name off sz bif} {CTRL 0x000 32 {} GIER 0x004 32 {} IP_IER 0x008 32 {} IP_ISR 0x00C 32 {}
                           cmd_input 0x010 64 m_axi_gmem0 resp_output 0x01C 64 m_axi_gmem1
                           pages 0x028 64 m_axi_gmem2 size 0x034 32 {}
                           top 0x03C 64 m_axi_gmem3 top_bytes 0x048 32 {}} {
    set r [ipx::add_register $name $ab]
    set_property address_offset $off $r
    set_property size $sz $r
    if {$bif ne ""} { set_property value $bif [ipx::add_register_parameter ASSOCIATED_BUSIF $r] }
}
set_property slave_memory_map_ref s_axi_control [ipx::get_bus_interfaces -of $core s_axi_control]

set_property xpm_libraries {XPM_CDC XPM_MEMORY XPM_FIFO} $core
set_property sdx_kernel true $core
set_property sdx_kernel_type rtl $core
set_property supported_families { } $core
set_property auto_family_support_level level_2 $core
ipx::create_xgui_files $core
ipx::update_checksums $core
ipx::check_integrity -kernel $core
ipx::save_core $core
close_project -delete

package_xo -force -xo_path $xo_path -kernel_name tinyoram_kernel -ip_directory $ip_dir -kernel_xml ./kernel_tinyoram.xml
