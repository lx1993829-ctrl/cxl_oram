#!/bin/bash
# check_sizes_vivado.sh -- the Vivado and v++ checks of the block sizes added on 2026-10-19 (README §21), before any
# board build of them. Run it in the bring-up copy (DEST/bringup/fpga_zcu208/tinyoram/card); it fetches into that copy's
# tinyoram/build and touches no other copy, no card and no card configuration.
#
#   bash check_sizes_vivado.sh elab    Vivado elaboration (elab_tinyoram.tcl) of 512 B, 1 KB and 2 KB, each native
#                                      L = 6 and run-time depth L_max = 18, merged adapter: 6 runs, a few minutes each
#   bash check_sizes_vivado.sh link    the short v++ link (link_check_tinyoram.sh: block design built and validated, no
#                                      synthesis) of 512 B, 1 KB, 2 KB and 4 KB, run-time depth L_max = 18, merged, at
#                                      FREQ (default 230) with tinyoram_host.cfg (tree top over HBM[8:15], commands
#                                      HBM[16:23], responses HBM[24:31]; README §22, §23), as q15, q13, q14, q12 build
#   bash check_sizes_vivado.sh         both, elab first
#   bash check_sizes_vivado.sh report  print the report so far
# Pass: every line PASS; the last line "SIZES VIVADO CHECKS PASSED". Every verdict is appended to
# DEST/bringup/sizes_report.txt: send me that file (and, on a FAIL, the log it names).
set -u
CARD=$(cd "$(dirname "$0")" && pwd)
PKG=$(cd "$CARD/../.." && pwd)
V=$PKG/vitis
REP=$(dirname "$PKG")/sizes_report.txt
VITIS_SETTINGS=${VITIS_SETTINGS:-/tools/Xilinx/Vitis/2024.1/settings64.sh}
XRT_SETUP=${XRT_SETUP:-/opt/xilinx/xrt/setup.sh}
FREQ=${FREQ:-230}
say() { echo "$*"; echo "$*" >> "$REP"; }
command -v vivado > /dev/null || { source "$VITIS_SETTINGS" > /dev/null 2>&1; source "$XRT_SETUP" > /dev/null 2>&1; }
command -v vivado > /dev/null || { echo "vivado not found: source $VITIS_SETTINGS (or set VITIS_SETTINGS)"; exit 2; }
cd "$V" || exit 2
FAILED=0
fetch() {   # fetch <log> <fetch args...>
    local lg=$1; shift
    bash ../tinyoram/fetch_tinyoram.sh "$@" > $lg 2>&1 || { say "  FAIL  fetch_tinyoram.sh $* ($V/$lg)"; FAILED=1; return 1; }
}
do_elab() {
    say "== elaboration: 512 B, 1 KB, 2 KB; native L = 6 and run-time L_max = 18; merged ($(date '+%F %T'))"
    for sz in 512 1k 2k; do for v in "6:merge" "18:merge rtdepth"; do
        L=${v%%:*}; o=${v#*:}; t=${sz}_L$L; [ $L = 18 ] && t=${t}_rt
        fetch sizes_fetch_$t.log $sz $L $o || continue
        el=sizes_elab_$t.log
        vivado -mode batch -nojournal -nolog -source elab_tinyoram.tcl > $el 2>&1
        if grep -q "^ELAB PASS" $el && ! grep -q "^ERROR:" $el; then say "  PASS  $(grep -m1 '^ELAB PASS' $el | cut -c12-)"
        else say "  FAIL  $sz B L=$L ($o): $(grep -m1 -E '^ERROR:|^ELAB FAIL' $el | cut -c1-160) ($V/$el)"; FAILED=1; fi
    done; done
}
do_link() {
    say "== short v++ link at $FREQ MHz, tinyoram_host.cfg (top HBM[8:15], commands HBM[16:23], responses HBM[24:31]): 512 B, 1 KB, 2 KB, 4 KB, run-time L_max = 18, merged ($(date '+%F %T'))"
    for sz in 512 1k 2k 4k; do
        fetch sizes_fetch_${sz}_L18_rt.log $sz 18 merge rtdepth || continue
        lg=sizes_link_${sz}.log
        FREQ=$FREQ CFG=tinyoram_host.cfg bash link_check_tinyoram.sh > $lg 2>&1
        r=$(tail -1 $lg | sed "s/(link_check_/(sizes_${sz}_link_check_/")   # the name the logs get below
        case "$r" in "LINK CHECK PASS"*) say "  PASS  $sz B: ${r#LINK CHECK PASS: }" ;;
            *) say "  FAIL  $sz B: ${r#LINK CHECK FAIL: } (logs in $V)"; grep -E "^  " $lg | head -5 | sed 's/^/      /' | tee -a "$REP"; FAILED=1 ;; esac
        # link_check_tinyoram.sh names its logs by clock and configuration only: keep each size's
        for f in link_check_${FREQ}mhz_tinyoram_host_{pack,link}.log; do [ -f $f ] && mv $f sizes_${sz}_$f; done
    done
}
case "${1:-all}" in
    elab) do_elab ;;
    link) do_link ;;
    all)  do_elab; do_link ;;
    report) cat "$REP"; exit 0 ;;
    *) sed -n '2,15p' "$0"; exit 1 ;;
esac
[ $FAILED = 0 ] && say "SIZES VIVADO CHECKS PASSED" || say "SIZES VIVADO CHECKS FAILED: send me $REP and the named logs"
exit $FAILED
