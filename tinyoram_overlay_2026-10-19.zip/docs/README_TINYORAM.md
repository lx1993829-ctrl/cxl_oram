# Tiny ORAM as a U55C kernel — Step 1 notes and Step 2 configuration

Status 2026-10-18: Phase 1 (port onto step 5.2, §10) and Phase 2 (packed records, §11) done; the card
bring-up at 64 B (Phase 3) and the 1M-record build (Phase 4) are written up as commands with expected
output in `docs/TINYORAM_CARD_RUNBOOK.md` (§12). Audit fixes in §13. The changes for a fair comparison
with DOMA are in §14: front end, merged bursts, tree-top split, flat position map, latency spread.
Rebased onto DOMA's current package (Z = 10, compact buckets, 300 MHz closure, prefetch, arrival-mode
early release): DOMA's regressions pass on it at 32 B and 4 KB with the expected timing hashes, and
`scan.sh` runs both kernels. §15 adds the implicit-net lint, slow-acknowledgement tests with a stale-read
monitor, 4 GB-crossing buffers, per-port traffic, and the card scripts (install, bring-up, build queue,
sweeps, merged table) in `tinyoram/card/`. §17 fixes the PosMap depth at 4 KB; §18 adds a run-time tree depth
(one build for every N up to L_max, checked cycle by cycle against native builds). Regression and mutation counts: see
`docs/tinyoram_regression_2026-10-18.txt` and `docs/tinyoram_mutants_2026-10-18.txt`. Packaging, host program and build scripts are untested on Vitis: no Vivado/Vitis/XRT where
they were written (the host was checked against a functional mock of XRT).

Source studied: `github.com/ascend-secure-processor/oram`, branch `oram_fpga_public`,
commit `18ece07` (2017-07-12). Simulator: Verilator 5.020. The harness and patches used
below are in `tinyoram/study/` (`run_study.sh setup` fetches the source and applies
`sim_patches.diff`; no Tiny ORAM source is copied into this package).

## 1. Summary

* **One RTL tree, not an FPGA/ASIC split.** `oram_fpga_public` is `master` plus two
  README commits. The RTL is the MIT "chip" snapshot (2014–15). FPGA and ASIC builds
  share it through `` `ifdef FPGA ``. The board files, Xilinx IP and test scripts the README
  refers to (`../boards`, `../tests`) are not in the repository.
* **4 KB blocks work.** N = 256, 4 KB blocks, encryption and PMMAC integrity on: random
  GET/PUT traffic matched a reference model with BEDWidth 128 and with 256.
* **Read-after-write ordering is required.** Tiny ORAM assumes a MIG-style in-order DRAM.
  When writes become visible late, the harness fails ("block already present in stash").
  The AXI adapter must hold reads until earlier writes are acknowledged.
* **Random initial values are fine; never-written tree memory must read as zeros.**
  (Corrected 2026-10-10: the "hang with random initial values" reported here first was a bug
  in my testbench's memory model, which returned random data for never-written memory under
  `--x-initial unique`. With that fixed, Tiny ORAM passes with `+verilator+rand+reset+2`.)
* **Only one secure configuration works.** That is the Path ORAM backend with AES and
  PMMAC. RAW Path ORAM (`EnableREW=1`) does not work in this snapshot.
* **License:** the MIT-written files carry no license and the repository has no LICENSE
  file (§6).

## 2. Interfaces

### Frontend (user side of `TinyORAMCore`)

| Signal | Meaning |
|---|---|
| `Cmd[1:0]` + `PAddr[31:0]`, `CmdValid/CmdReady` | Commands: `0` Update (write), `2` Read. `1` Append and `3` ReadRmv are internal (PosMap). An Update to a never-written block works, because the frontend turns it into an Append. `PAddr` is the block index and must be < N. |
| `WMask[ORAMB/8-1:0]` | Byte write mask, 4096 bits at 4 KB. Tie it to all ones. |
| `DataIn[FEDWidth]`, valid/ready | Write data. After an accepted Update, ORAMB/FEDWidth beats (512 at 4 KB). |
| `DataOut[FEDWidth]`, valid/ready | Read data, same beat count. |

* **One command at a time.** `CmdReady` stays low until the frontend is free again.
* **No write acknowledgement.** `CmdReady` going high again does not mean the access has
  finished. A trace of one 4 KB access with BEDWidth = 256 (`-DTRACE`), in cycles from the
  command:

  | Phase | GET | PUT |
  |---|---|---|
  | Path read: commands | 39–2040 | |
  | Path read: data | 80–4083 | |
  | Data returned to the user | 4883–5394 | |
  | `CmdReady` high again | | 546 |
  | Path writeback | 4769–8744 | ~8800 (ends) |

  So the user sees a GET finish about 3.4k cycles before the writeback ends, and a PUT
  finish about 8k cycles before it ends.
* **Out-of-range `PAddr` is not handled.** It only sets a sticky error flag (simulation
  calls `$finish`). The wrapper must reject keys ≥ N itself (status 0x4).

### DRAM side ("MIG-like")

* **Command channel:** `DRAMAddress[DDRAWidth]`, `DRAMCommand[2:0]` (0 = write, 1 = read),
  valid/ready.
  * The address counts 64-bit words and is always a multiple of 8. Each command is one
    64-byte burst.
  * A bucket is a run of consecutive bursts. Buckets are laid out in subtrees of height 2
    (at 4 KB), which keeps each subtree within one DDR3 row.
  * The adapter can merge consecutive commands into AXI bursts, but must split them at
    4 KB boundaries. A 4 KB-block bucket is 16,512 B, so it is not 4 KB-aligned.
* **Write data:** `BEDWidth` beats with valid/ready, 512/BEDWidth beats per write command,
  in command order.
* **Read data:** `BEDWidth` beats with **no ready**, in command order.
  * The AES engine must take a beat every cycle. Overflow only sets an error flag
    (`ERROR_OF1`, "Lose ciphertexts").
  * So the adapter buffers the AXI R channel. It pushes at most one beat per cycle into
    the core, and throttles `rready` on its own FIFO.
* **Ordering:** the core issues a whole path of reads, then a whole path of writes. The
  next access's reads start with the root bucket that was just written. The adapter
  therefore needs a single ID with in-order reads, and must hold reads until every
  earlier write has its B response. The `WR_LAG=20000` run shows what happens without
  this.
* **Initial memory contents:** there is no DRAM initialiser ("we got rid of DRAMInit").
  * A bucket whose stored IV is 0 is treated as empty.
  * The tree region must be zero before first use. Garbage happened to pass in simulation,
    but it can turn into fake blocks.
  * Proposal: the kernel zero-fills the tree at the first (size = 0) launch, counted as
    initialization. This matches DOMA formatting its buckets at boot.

## 3. Parameters

| Parameter | Default | Notes |
|---|---|---|
| `ORAMB` (block size, bits) | 512 (64 B) | The FCCM'15 paper claims 64 B–4 KB. 32768 tested here. |
| `ORAMZ` | 4 | Effectively fixed: the frontend assumes Z = 4. N = 4·2^L, so the tree is 50 % full. |
| `ORAML` | 23 (19 in sim) | Number of levels = L + 1. N = 256 gives L = 6: 127 buckets, 508 slots. |
| `ORAMC` (stash) | 10 | Extra entries on top of one path: 10 + 4·7 = 38 entries (152 KB at 4 KB). The backend does background eviction (dummy accesses) when the stash fills. |
| `FEDWidth` | 64 | Only 64 works. 128 and 256 hang at 4 KB. |
| `BEDWidth` | 128 | Must divide 512. 128 and 256 both pass. |
| `Overclock` | 1 | Extra stash pipelining "needed for 200 MHz". |
| PosMap | Unified frontend, PLB 8 KB, `PRFPosMap=1` | Recursion = ⌈(L+2−10)/3⌉+1, which is 1 at N = 256. The whole PosMap (256 counters) is on chip, so there are no PosMap ORAMs and the PLB does nothing. Recursion appears at larger N. The 3 is log2 of the 8 leaves in a 64 B PosMap block; for larger blocks `fetch_tinyoram.sh` writes the same rule with log2(ORAMB/64) (§17). |
| `EnableAES` | 1 | AES-128 counter mode. Each bucket gets a 64-bit IV from a global counter, stored in clear. Pipelined tiny_aes (21-cycle latency), with BEDWidth/128 lanes running at line rate. |
| `EnableIV` (PMMAC) | 1 | Keyed SHA-3 (Keccak, 224-bit digest truncated to 128) over (counter, address, data). It is checked in the frontend; the counter in the PosMap gives freshness. Leaves are AES-PRF(counter). The MACs grow the bucket header from 1 to 2 bursts. |
| `EnableREW` | 0 | RAW Path ORAM. **Not usable**, see below. |
| Keys | hard-coded | AES key all ones, PRF and MAC keys fixed. This is the same situation as DOMA's stand-in keys. |

Which security switches actually work in this snapshot:

* **AES on, PMMAC on: works.** This contradicts the README, which says integrity needs
  the RAW backend.
* **AES on, PMMAC off: works** with `PRFPosMap=0`. With `PRFPosMap=1` and no PMMAC, the
  leaves would be the raw counters.
* **RAW backend: does not work.**
  * With PMMAC it stops with "Not supported yet" (it needs a 1-burst header).
  * Without PMMAC it stops with "Path buffer overflow". The source itself says
    "this won't work right now".

Geometry and traffic at N = 256 and 4 KB, with PMMAC:

* **Bucket:** 258 bursts = 16,512 B.
* **Path:** 7 buckets = 115,584 B.
* **Per access:** 231,168 B moved (56× the block), plus occasional background evictions.
* **Tree:** 2.0 MB in use. The address span is 3.35 MB because of the subtree padding.
  DOMA's pages buffer is 2 MB, so the host must size the pages buffer per kernel.

## 4. Dependencies and porting to UltraScale+ / Vivado 2024.1

* **Xilinx IP is not needed** for the proposed configuration.
  * The only IP instances are `ClkCross512x{128,144,512}` (async FIFOs, RAW backend with
    `FPGA` defined) and `aes_clock` (MMCM, only when `SlowAESClock=0`). Neither is used.
  * There are no Xilinx primitives. RAMs are behavioural (`gatelib/RAM.v`).
  * `FPGA_MEMORY` must be defined. Otherwise the RAMs map to IBM 32SOI SRAM wrappers.
* **Two build flows:**
  * **`FPGA` defined:** parameters are passed down the hierarchy. The backend and AES
    resets are tied to 0, and their FSMs depend on `initial` blocks. `Const.vh` also needs
    `SYNTHESIS` (Vivado synth) or `MODELSIM` (simulation) defined, or its macros
    disappear.
  * **Without `FPGA` (the "ASIC" flow):** resets are real, but `Frontend`,
    `PathORAMBackendCore` and `AESPathORAM` take their parameters from `PathORAM.vh`
    instead of from the parent. One instance per build, configured by editing that file.
  * Both flows gave identical results at 4 KB. **I'd use the ASIC flow plus
    `FPGA_MEMORY`**, because its resets are real.
* **Old-Verilog issues:**
  * Zero-width replications in gatelib parameter defaults (`{Width{1'b0}}` with Width = 0):
    errors in Verilator 5 and Icarus 12. Vivado's behaviour still needs checking with
    `synth_ooc.tcl`.
  * `PrioritySelect.v` has an unnamed instance, which is a syntax error. It is unused, so
    I excluded it.
  * `ClockSource.v` starts the clock on `posedge` of a constant, so it never starts in
    Verilator.
  * 233 `(* mark_debug = "TRUE" *)` attributes. They should be stripped so they don't pin
    nets.
  * Many simulation-only checks are not gated by reset.
* **Random initial values:** Tiny ORAM's logic passes (corrected 2026-10-10, see §1). Only
  its simulation-only self-checks fire on the first clock edge, before reset takes effect,
  so the random-init run compiles Tiny ORAM without `SIMULATION`.
* **Timing:** the original target was 200 MHz on a Virtex-7 (XC7VX485T). Likely long
  paths at 300 MHz:
  * Keccak `round2in1` (two rounds per cycle);
  * the tiny_aes table rounds;
  * the stash scan logic.

  I can't estimate slack without Vivado. That is the first `worst_paths.tcl` job.

## 5. Its own tests

* **The shipped test** is `frontend/test/testUORAM.v`, driving `TinyORAMASICWrap` and
  `TrafficGenASIC`. The README says the per-module testbenches are out of date.
  * It needs files that are not in the repository (`tests/software/testORAM.v`,
    `network_define.v`). `+define+SIMULATION_VIVADO` avoids them.
  * Its dummy generator hard-fails on any configuration other than the default one
    (64 B blocks, Z = 4, PMMAC on).
* **Icarus 12:** does not elaborate (indefinite-width concatenations). Not pursued.
* **Verilator 5.020:** needed four simulation-only patches:
  * zero-width defaults;
  * a nonblocking assignment in a loop in an AddrGen checker;
  * the clock start;
  * an `ORAML` override, since L = 19 is too slow.

  With those it gives **"TrafficGen: ALL TESTS PASSED"**: default configuration, L = 10,
  6,144 accesses.
* **My harness** (`tinyoram/study/tb_core.sv`) drives `TinyORAMCore` directly.
  * Preload of all N blocks, then 200 random commands (50 % PUT), every GET checked.
  * DRAM model: in-order, 40-cycle read latency, 10 % random gaps on every DRAM channel,
    never-written memory reads as zeros.

| Configuration | Result | Cycles/cmd | Read + written per cmd |
|---|---|---|---|
| 64 B, L = 10 (N = 4096), FED 64, BED 128, AES + PMMAC | PASS | 1,328 | 7.3 + 7.2 KB |
| 64 B, L = 10, BED 256 | PASS | 824 | 7.4 + 7.4 KB |
| **4 KB, L = 6 (N = 256), FED 64, BED 128, AES + PMMAC** | PASS | 18,364 | 112.5 + 112.3 KB |
| **4 KB, L = 6, FED 64, BED 256, AES + PMMAC** | PASS | 9,636 | 112.9 + 112.4 KB |
| 4 KB, BED 256, AES only (`PRFPosMap=0`) | PASS | 8,962 | 112.9 + 112.4 KB |
| 4 KB, same with `FPGA` defined | PASS, identical | 9,636 | |
| 4 KB, FED 128 or 256 | hang | | |
| 4 KB, writes visible 20k cycles late | FAIL (duplicate block in stash) | | |
| 4 KB, random initial values | PASS (the first "hang" was a testbench bug) | 9,613 | |
| 64 B, RAW backend, no PMMAC | FAIL (path buffer overflow) | | |

The cycles-per-command figures come from an idealised DRAM. HBM, and later host memory,
will be slower. At 300 MHz, 9,636 cycles is 32 µs, about 31 k commands/s, as an upper
bound.

## 6. License

* **Third-party cores** carry permissive notices: UC Berkeley GateLib (BSD-3),
  tiny_aes and the Keccak core by Homer Hsing (Apache-2.0), and the OpenCores AES by
  R. Usselmann (BSD-style).
* **The MIT-written files** (frontend, backend, stash, addr, integrity, `TinyORAMCore`,
  `include/`) have no license header, and there is no LICENSE file.
* By default that means all rights reserved, so redistributing modified copies is not
  clearly allowed. Until that's settled, I'd ship Tiny ORAM changes only as patches plus a
  fetch script, as `tinyoram/study/` does now.
* The authors to ask are C. Fletcher, L. Ren and A. Kwon (commit authors).

## 7. Step 2 configuration (agreed 2026-10-09)

**Baseline A, same N and block size as DOMA:**

* **Protocol:** Path ORAM backend, Z = 4, L = 6, N = 256, 4 KB blocks, C = 10.
* **Security:** AES-128 counter mode on, PMMAC integrity on, `PRFPosMap=1`. The PLB is
  configured but idle.
* **Widths:** FEDWidth 64, BEDWidth 256, so a 256-bit AXI beat is one core beat.
* **Clock:** the same 300 MHz kernel clock, with the AES on that clock
  (`SlowAESClock=1`). If timing fails, report the achieved frequency rather than lowering
  the target.
* **Tree:** in `m_axi_gmem2`, HBM[8] first, then HOST[0]. The pages buffer is at least
  3.35 MB and zero-filled by the kernel at the first launch.
* **Build:** ASIC flow plus `FPGA_MEMORY`, `mark_debug` stripped, minimal fixes for
  Vivado and for random initial values, each one recorded in the README.

Baseline A is the most comparable to DOMA. It is also not Tiny ORAM's favourable regime:
its 2-burst headers and 56× path traffic dominate. A second configuration (B) would cover
BOLT-like sizes:

* 64 B blocks (Tiny ORAM's native and minimum size); 8–256 B records fit in one block;
* N sized like BOLT's key space, which brings in PosMap recursion and the PLB as Tiny
  ORAM was designed;
* later, also 256 B.

**Latency definition.** DOMA's `client_done` fires after its writeback is acknowledged.
For a fair comparison I propose:

* a command is done when its data is back (GET) **and** the backend is idle **and** the
  adapter has no outstanding writes;
* the next command is issued only after that.

This needs one internal tap (the backend controller's idle state). I would also record
"data ready" time as a second figure.

**Decided:**

* 2026-10-09: keep Tiny ORAM's own cryptography; do not swap in DOMA's AES-GCM. That
  means tiny_aes (pipelined AES-128 in counter mode) for bucket encryption, the OpenCores
  AES as the counter-to-leaf PRF, and keyed SHA-3 for PMMAC. The comparison is against
  Tiny ORAM as published. The README for the results will state the primitive
  difference: AES-CTR plus SHA-3 MAC versus DOMA's AES-GCM.
* 2026-10-09: integrity (PMMAC) stays on.
* 2026-10-09: latency definition.
  * A command's latency ends when its path writeback has been fully sent: the last write
    data beat has been accepted on `m_axi_gmem2`. The kernel does not wait for the write
    responses (B) before stopping the latency counter.
  * For correctness, the adapter still holds later reads until earlier writes are
    acknowledged (§2). Any wait for B responses therefore shows up in the next command's
    latency and in the total query time, not in this command's latency.
  * A GET's data-ready time is recorded as a second figure.
* 2026-10-09: add reset-time clears to Tiny ORAM's uninitialised RAMs and registers, so the
  random-initial-value test passes. **Superseded 2026-10-10:** no clears are needed; the hang
  was a testbench bug (§1), and Tiny ORAM passes the random-init test unchanged.
* 2026-10-09: no license request to the authors. Tiny ORAM will be cited (Fletcher et al.,
  FCCM 2015). Since the MIT files carry no license, the package keeps shipping Tiny ORAM as
  the upstream commit plus our patches and a fetch script, not as copied sources.
* 2026-10-10: record sizes. Both are kept: BOLT-like records of 8–256 B, and 4 KB (DOMA's
  size). All use N = 256 with AES and PMMAC on.
  * Tiny ORAM's block size `ORAMB` is fixed at build time, so each block size is its own
    xclbin.
  * In simulation (harness, BEDWidth 256, 400 random commands after preload), 64 B and up
    pass. 8, 16 and 32 B blocks hang before the first PUT completes, which matches the
    paper's 64 B minimum.
  * So 8–64 B records are stored in 64 B blocks, padded. This costs nothing in memory
    traffic, because Tiny ORAM pads every block to a whole 64 B burst anyway. 128 B,
    256 B and 4 KB are native blocks.
  * That makes four builds:

    | Records | `ORAMB` | Bucket | Path (read, = written) | Sim cycles/cmd |
    |---|---|---|---|---|
    | 8, 16, 32, 64 B | 512 (64 B) | 6 bursts = 384 B | 2,688 B | 351 |
    | 128 B | 1024 | 10 bursts = 640 B | 4,480 B | 499 |
    | 256 B | 2048 | 18 bursts = 1,152 B | 8,064 B | 777 |
    | 4 KB | 32768 | 258 bursts = 16,512 B | 115,584 B | 9,636 |

    The cycle counts come from the idealised DRAM model (40-cycle reads, 10 % gaps), so
    they are upper bounds on speed.
  * The kernel takes the first `ORAMB` bits of each 4 KB PUT slot in the command buffer
    and writes the record (`ORAMB` bits) at the start of the GET slot, so the host layout
    stays the same as DOMA's. **Superseded 2026-10-13 (§11):** slots are block-sized, as DOMA's.

## 8. Step 3 (adapter and kernel) and Step 4 (simulation) — 2026-10-10

### What was built

| File | What it is |
|---|---|
| `tinyoram/rtl/tinyoram_kernel.v` | The Vitis kernel. Same arguments, control registers, buffer layout, response and summary records as `doma_kernel.v`, with Tiny ORAM in DOMA's place. |
| `tinyoram/rtl/tinyoram_axi_adapter.v` | Tiny ORAM's DDR3-controller-style memory port to `m_axi_gmem2`. |
| `tinyoram/fetch_tinyoram.sh` | Downloads Tiny ORAM at commit 18ece07 and applies `tinyoram/patches/`. It writes a flat source directory, `tinyoram/build/src/`, with the configuration header for one block size. |
| `tinyoram/config/tinyoram_config_{64,128,256,4k}.vh` | One configuration header per block size (each size is its own xclbin). |
| `sim/tb_tinyoram_kernel.v`, `sim/run_tinyoram.sh` | Kernel regression (the testbench plays XRT), run with Verilator. |
| `sim/run_xsim_tinyoram.sh` | The same test in Vivado's simulator (untested here). |
| `vitis/synth_ooc_tinyoram.tcl` | Out-of-context synthesis and place & route on the U55C part at 300 MHz. Run this first. |
| `vitis/package_tinyoram.tcl`, `kernel_tinyoram.xml`, `tinyoram_hw.cfg`, `tinyoram_host.cfg`, `build_tinyoram.sh` | Packaging and v++ link, mirroring the DOMA files. |
| `vitis/host_doma.cpp` | Shared with DOMA. Selects the kernel with `--kernel tinyoram_kernel` or `DOMA_KERNEL`; see §10. |

### Changes to Tiny ORAM (patches against 18ece07)

| Patch | Change | Why |
|---|---|---|
| 01 | `Const.vh`/`PathORAM.vh` include `tinyoram_config.vh`. `ORAMB`, `ORAML` and `BEDWidth` defaults can be overridden; `FPGA_MEMORY` is defined. | Per-build configuration. |
| 02 | New `Idle` output, passed up from the backend controller and the integrity verifier. | Status only, for the agreed latency definition. No behaviour change. |
| 03 | gatelib parameter defaults `{Width{…}}` → `{(Width>0?Width:1){…}}`. | Zero-width replication is illegal in current tools. The values are unchanged. |
| 04 | Three simulation-only self-checks: one no longer runs during reset, one fixes a Verilator loop construct. | Inside `ifdef SIMULATION`; no effect on hardware. |
| 05 | `PosMapPLB.v`: `OldLeafOut <= PosMapOut[LeafOutWidth-1:0]` (was `[ORAML-1:0]`). | **Bug fix.** See below. |
| 06 | Remove all 233 `(* mark_debug = ... *)` attributes (14 files). | They pin nets, which costs resources and timing; DOMA has none. Plan step B4: 20/20 with identical cycle counts. |

The patch 05 bug, in more detail:

* In PRF mode the PosMap holds a 64-bit access counter per block, and the leaf is
  AES(address ‖ counter).
* The old counter was cut to `ORAML` bits while the new one kept all 64. So after 2^`ORAML`
  accesses to one block, the old and new leaves disagree, and Tiny ORAM stops on its own
  check ("block being accessed didn't have correct leaf").
* At the authors' `ORAML` = 23 that needs 8 M accesses to one block. At ours (6) it needs 64.
  A uniform 5,000-command run would rarely reach that, but repeated runs without reloading
  the xclbin would.
* Reproduced on the unpatched source: it fails on the 64th access to one key. With the fix,
  300 consecutive accesses to one key pass.

No reset-time clears were needed (§1). Crypto and keys are as published.

### Adapter (1:1, as agreed)

* **Translation:** one Tiny ORAM command (64 B) becomes one 2-beat AXI burst, with a single
  ID. A 64-byte-aligned 2-beat burst can't cross a 4 KB boundary.
* **Ordering:** a read is not issued while any write lacks its B response. A write is not
  issued while any read still has data to return. This is the ordering of the DDR3
  controller Tiny ORAM was built for.
* **Read buffer:** 512 beats; an AR is issued only when there is room for all its data.
  This is needed because Tiny ORAM can't apply backpressure on read data.
* **Write buffer:** 512 beats, and a beat leaves only after its AW. This is needed because
  Tiny ORAM's AES has about two buckets of keystream buffering and no stall. Without the
  buffer, a long W stall loses keystream (Tiny ORAM's own "Lose Masks!" check). A memory
  controller's write FIFO plays the same role in the original setup.
* **Address check:** an address outside the tree raises the kernel's error flag (0x8).

### Kernel specifics

* **First launch:** latches the pages address and zero-fills the tree. An all-zero bucket is
  Tiny ORAM's "never written" bucket, and Tiny ORAM has no DRAM initialiser of its own. Only
  then is Tiny ORAM released from reset; nothing touches memory before the first `ap_start`.
* **Tree size:** the zero-fill covers 49,536 B / 123,520 B / 185,472 B / 3,517,056 B for
  64 B / 128 B / 256 B / 4 KB blocks at L = 6. The host sizes the pages buffer from
  `DOMA_N` and `DOMA_BLOCK` (§10).
* **Key range:** keys ≥ N are rejected (0x4).
* **Changed 2026-10-13 (§10):** the zero-fill moved from the init launch to the first launch
  with size > 0, so the host can check the geometry first.
* **Latency end:** superseded on 2026-10-12 by plan step B1 (§9): the primary figure now ends
  at write-back acknowledged, and "data ready" and "last write beat" are secondary figures.

### Simulation results (Verilator 5.020, `sim/run_tinyoram.sh`, log in `docs/tinyoram_regression_2026-10-12.txt`)

All 20 checks pass: four block sizes × five tests (e2e, late start + 256 PUTs, 30 % gaps, late
writes, random initial values).

Per-command latency at the testbench's 100-cycle tree latency:

| Block size | Latency (cycles) |
|---|---|
| 64 B | 571 |
| 128 B | 834 |
| 256 B | 1,318 |
| 4 KB | 16,936 |

The testbench's memory model accepts at most 16 outstanding reads. With 64-byte bursts that
caps reads at 16 × 2 beats per 100 cycles. So simulated 4 KB latency is mostly that limit,
not Tiny ORAM; HBM's real outstanding-read limit will set the board number.

Memory model: `+host_wlat=200` lands each burst 200 cycles after its own last beat. The
current `sim/axi_mem_model.v` does this itself (bursts land pipelined), so the `wlat_pipe`
option this test used on the old base is no longer needed and `axi_mem_model.v` is unchanged.

### Next on the U55C machine

Superseded by §10 (host usage) and the Phase 3 instructions.

## 9. Modification plan, 2026-10-12

Status of the plan's steps:

| Step | Status |
|---|---|
| A (port onto the current package) | **Waiting for the current `fpga_zcu208_deploy.zip`** (step 4, 26/26). Everything below was done on Tiny ORAM's own files, ready to port. |
| B1 latency | Done, using the recommended definition. |
| B2 byte counters | Done (Tiny ORAM side). |
| B3 packing | `WMask` verified; packing itself not yet started. |
| B4 `mark_debug` | Done (patch 06). |
| B5 clock | Done. |
| B6 burst merging | Decided 2026-10-12: decide after the first 4 KB card results (see below). |
| C | Needs the card. |
| D | Recursion and PLB tested; tree-size table below. |

### B1: latency ends at write-back acknowledged

The response header now carries three figures, all counted from issuing the command to Tiny
ORAM:

| Header bytes | Figure | Ends when |
|---|---|---|
| 8–11 (primary, and the summary min/max) | write-back acknowledged | data done, Tiny ORAM `Idle`, and every write's B response received (adapter idle). This is the same end point as DOMA's `client_done`. |
| 16–19 | data ready | GET record received, or PUT record sent. |
| 20–23 | last write beat | Tiny ORAM `Idle` and every write beat on the bus. |

The testbench checks data ready ≤ last write beat ≤ acknowledged for every command. DOMA's
header bytes 16–31 are zero today; the host can read these two fields for Tiny ORAM only.

### B2: record [size+1]

Format, as in the plan:
* byte 0: `0x5B`;
* bytes 8–15: read beats on gmem2 during the launch;
* bytes 16–23: write beats on gmem2;
* bytes 24–31: zero (DOMA). Since 2026-10-13 Tiny ORAM puts its geometry there (§10).

The init launch counts the zero-fill (64 B tree: 1,548 write beats = 49,536 B). The testbench
compares both counts with its own beat counters on gmem2: exact in all 20 runs. Per command
(run 1, 64 B blocks): 84 read + 84 write beats = 2,688 B each way, exactly one path.

**Layout edge case: settled.** DOMA moved GET data to HR = roundup((size+2)·32, 4 KB) in step
5.2; Tiny ORAM does the same (§10).

### B3 (check): `WMask` works

Test (`tinyoram/study/tb_core.sv -DMASK_TEST`): three quarters of the PUTs to existing blocks
get a partial byte mask, either a random byte range (any offset and length) or an aligned
8-byte slot, against a byte-level reference.

| Configuration | Partial PUTs | Commands | Result |
|---|---|---|---|
| 64 B | 126 | 300 | PASS |
| 4 KB | 48 | 120 | PASS |
| N = 16K, 64 B | 1,124 | 3,000 | PASS |
| N = 64K, 64 B | 1,116 | 3,000 | PASS |

Packing through `WMask` is therefore feasible. The kernel changes it needs (header bytes 8–15,
status 0x40, block-sized slots, block size in summary bytes 4–7) wait for step A, so they
match the current DOMA layout.

### B5: clock

* `FREQ=<MHz> bash build_tinyoram.sh`: `--kernel_frequency`, the packaged `FREQ_HZ` and
  `check_timing.sh`'s `WANT_MHZ` all follow it.
* For `FREQ` ≠ 300 the xclbin is named `tinyoram_<size>_<FREQ>mhz_<target>.xclbin`.
* `synth_ooc_tinyoram.tcl -tclargs route <MHz>` checks another clock out of context.

### D: recursion and the PLB at large N (harness, 64 B blocks, AES and PMMAC on, random partial writes)

| N (blocks) | L | Recursion levels | Preload | 3,000 random commands | Traffic per command |
|---|---|---|---|---|---|
| 16,384 | 12 | 3 | 16,384 PUTs | PASS, 1,398 cycles/cmd | 13.2 KB read + 13.2 KB written: ~2.6 paths (one path = 4,992 B), the extra from PosMap blocks missing the PLB |
| 65,536 | 14 | 3 | 65,536 PUTs | PASS, 1,669 cycles/cmd | 16.5 KB each way: ~2.9 paths (one path = 5,760 B) |

So at large N, PosMap recursion multiplies Tiny ORAM's traffic. The byte counters (B2) will
show this on the card.

Tree size per N, packed 8-byte records (8 per 64 B block). Choose L as the smallest value
with 4·2^L ≥ blocks. The tree span includes the subtree-padding buckets.

| Records | Blocks | L | Blocks held | Recursion | Tree span | One path, each way |
|---|---|---|---|---|---|---|
| 2,048 | 256 | 6 | 256 | 1 | 48 KB | 2,688 B |
| 16,384 | 2,048 | 9 | 2,048 | 2 | 0.4 MB | 3,840 B |
| 131,072 | 16,384 | 12 | 16,384 | 3 | 3.0 MB | 4,992 B |
| 1,048,576 | 131,072 | 15 | 131,072 | 4 | 30 MB | 6,144 B |
| 10,000,000 | 1,250,000 | 19 | 2,097,152 | 5 | 390 MB | 7,680 B |

10M records fit an HBM bank (512 MB), with about 120 MB to spare. The kernel already derives
its key-range check and zero-fill size from the geometry; once packing is in, the host's
`--n` must name records and the matching build.

### B6: burst merging, decided after the card results (2026-10-12)

The 1:1 adapter stays the default and the faithful baseline. After the first 4 KB run with the
tree in HBM[8], compute Tiny ORAM's effective tree bandwidth:

    (read beats + write beats from record [size+1]) x 32 B / query time

Compare it with what the same HBM bank delivers to DOMA's 4 KB bursts. If Tiny ORAM is clearly
limited by per-transaction cost (2-beat bursts) rather than by its own path traffic, add the
merged variant and report both. The merged variant combines consecutive commands into longer
bursts, split at 4 KB boundaries, adapter only, nothing inside Tiny ORAM. Otherwise report 1:1
only.

**Stated limitation (2026-10-13 status note: "not now").** The adapter is 1:1: every Tiny ORAM
memory command is its own 64-byte, 2-beat AXI burst, as with the DDR3 controller Tiny ORAM was
built for. DOMA moves whole blocks in long bursts. The board numbers for Tiny ORAM therefore
include HBM's per-transaction cost of 64-byte bursts; merging consecutive commands into longer
bursts (adapter only) could lower it, and is not done.

## 10. Phase 1: port onto the step 5.2 package (2026-10-13)

### Layout

* Tiny ORAM's kernel and adapter moved from `rtl/` to **`tinyoram/rtl/`**. DOMA's
  `package_kernel.tcl`, `synth_ooc.tcl` and `worst_paths.tcl` read every `rtl/*.v`, and Tiny
  ORAM's files need its headers, so leaving them in `rtl/` would break DOMA's builds. DOMA's
  `rtl/` is now byte-identical to the step 5.2 package.
* Response data at HR = roundup((size+2)·32, 4 KB), after the summary record [size] and the
  traffic record [size+1], as DOMA.

### Init launch and geometry

* **The init launch (size = 0) only latches the pages address and reports the geometry.** It
  touches no memory. The zero-fill of the tree moved to the first launch with size > 0 (in the
  host flow, the first preload batch, so it still counts as initialization), followed by Tiny
  ORAM's release from reset.
* **Record [size+1] bytes 24–31** (zero for DOMA): bytes 24–27 the build's N (blocks), bytes
  28–31 the tree size in 64-byte bursts (a 32-bit byte count would overflow above 4 GB).
* The testbench checks both fields, and that the init launch issued no AR or AW on the tree port.

### Host (`vitis/host_doma.cpp`, shared)

Additive; without the new option or variable the DOMA path is unchanged (checked: identical
output to the step 5.2 host against a functional mock of XRT, with and without `DOMA_N`,
`DOMA_BLOCK`, `DOMA_PACK`, `DOMA_PAGES_HBM`).

| Item | Behaviour |
|---|---|
| Kernel selection | `./host_doma <xclbin> [CMD_SIZE] [--kernel tinyoram_kernel]`, or `DOMA_KERNEL=tinyoram_kernel`. Default `doma_kernel`. |
| Arguments | DOMA: 8 (cmd, resp, pages, size, meta, brec, stash, nblk). Tiny ORAM: 4 (cmd, resp, pages, size). meta/brec/stash are allocated only for DOMA. |
| `DOMA_N` | Records, for both kernels. For Tiny ORAM the host derives L (smallest with 4·2^L ≥ N) and refuses a bitstream with a different N, naming the L it needs. Unset: the bitstream's N. |
| `DOMA_BLOCK` | Sizes Tiny ORAM's tree buffer before the first launch (default 4096, which covers every block size at the same L). If the bitstream's tree is larger than the buffer, the host stops and prints the `DOMA_N`/`DOMA_BLOCK` to use. |
| `DOMA_PACK` | Refused for Tiny ORAM until Phase 2 (allowed since then, §11). |
| Output | Tiny ORAM prints its geometry after init, and per run the three latencies: data ready, last write-back beat, write-back acknowledged (min..max). The traffic line prints for both kernels. |

The host's tree-size formula is a port of Tiny ORAM's `BucketLocal.vh`; it matches the RTL's
own value at 64 B, 128 B, 256 B and 4 KB for L = 6, 14, 18 and 22 (16 points).

### Build scripts

* `fetch_tinyoram.sh <size> [L]`: optional tree depth (6..26), written into the build's
  configuration header. The default stays L = 6.
* `build_tinyoram.sh`: `N=<records>` picks L (one bitstream per N; xclbin
  `tinyoram_<size>_n<N>_<target>.xclbin`), passes the same post-placement hook as `build.sh`
  (`post_place.tcl`, hardware builds only), and prints the host command with the matching
  `DOMA_KERNEL`, `DOMA_BLOCK`, `DOMA_N` and (for `tinyoram_hw.cfg`) `DOMA_PAGES_HBM=1`.
* `check_timing.sh` / `worst_paths.tcl` (shared): `XCLBIN` and `XDIR` overrides (defaults
  `doma_hw.xclbin`, `_x`), kernel-name-neutral path names; `WANT_MHZ` was already there.

### Tree sizes (bytes, from the RTL)

| Block | L = 6 | L = 14 | L = 18 | L = 22 |
|---|---|---|---|---|
| 64 B | 49,536 | 18,923,904 | 207,667,584 | 4,032,872,832 |
| 128 B | 123,520 | 23,634,560 | 505,979,520 | 5,539,144,320 |
| 256 B | 185,472 | 38,966,400 | 642,946,176 | 10,910,602,368 |
| 4 KB | 3,517,056 | 901,769,856 | 14,428,400,256 | 230,854,486,656 |

An HBM pseudo-channel holds 512 MB, so with the tree in HBM[8] the unpacked 64 B build tops
out at L = 18 (1M blocks). With 8 records per block (Phase 2), 1M records need L = 15 and 10M
records L = 19, both within one bank.

## 11. Phase 2: packed records (2026-10-13)

`tinyoram/rtl/tinyoram_kernel.v`, following `doma_kernel.v`'s packed-record layout:

| Item | Behaviour |
|---|---|
| Header | bytes 8–11 record offset in the block, 12–15 record length; length 0 = whole block (all unpacked commands). |
| Range check | `length != 0` and (`offset >= block` or `length > block - offset`): status **0x40**, no Tiny ORAM access. Checked for GETs and PUTs (DOMA checks PUTs only, since its GETs return the whole block). |
| PUT | Tiny ORAM's own byte write mask (`WMask`, one bit per byte) selects the record. The kernel builds it 128 bytes per cycle before issuing the command: 1 cycle at 64 and 128 B, 2 at 256 B, 32 at 4 KB (before the latency counter starts, like DOMA's issue). The PUT data fed to Tiny ORAM is zero outside the record. |
| GET | Only the record's bytes are written into the response slot (byte strobes on `gmem1`, a burst covering just the record's beats); the rest of the slot is untouched. |
| Slots | Block-sized: command data at `HC + i·BLOCK`, GET data at `HR + i·BLOCK`, as DOMA. |
| Summary | bytes 4–7: block size in 32-byte beats, as DOMA. The host reads it and lays out its buffers to match. |

**Why the PUT data is zeroed outside the record.** Tiny ORAM turns the first write to a block into an
`Append` of the whole block, and the mask is applied only to `Update`s (`IntegrityVerifier.v`: the read
block and the new data are merged under the mask). Without zeroing, a record written into a
never-written block would carry the host's slot contents around it. With it, the bytes around a first
record are zeros, which is what a never-written block reads as. In the host's flow every block is
written by the preload first, so this only matters for byte-exactness in the tests.

**Unchanged:** whole-block commands (length 0) take the same path as before plus one cycle for the
check, so unpacked latencies are as in Phase 1. A GET of a block that was never written returns
whatever Tiny ORAM returns (stale data from its buffers); the host never does this, since it preloads
every key.

**Tests** (`sim/run_tinyoram.sh`, at 64 B and 4 KB, mirroring DOMA's packed kernel tests):

* `+packed=8 +preload`: the preload writes every block whole, then 8-byte records with junk around
  them in each PUT slot. Every GET is checked byte for byte against an image of the block; bytes of the
  response slot outside the record must keep their poison. Run 2's bad command is a PUT whose range
  runs past the block (0x40). A last launch GETs 64 whole blocks (length 0), which checks every byte of
  the image, and ends with a GET whose range runs past the block (0x40).
* `+packed=16 +host_wlat=200 +host_gap=30`: the same with writes landing 200 cycles late and 30% gaps
  in read data, without preload, so records are also written into never-written blocks.
* `+ranges +preload +host_gap=30` (all four block sizes): records at random byte offsets and lengths,
  crossing beat boundaries anywhere and up to the whole block, with one command in eight a whole-block
  command. The verify launch ends with four bad ranges: past the end, an offset beyond the block, a
  wrapping length (0xFFFFFFF8) and a length beyond the block. Each must come back 0x40 with its data
  slot untouched. This test was added after an independent review of the RTL found that the packed tests
  alone would miss two mutations: a wrong last-beat formula, and a mask not restored to all ones after a
  partial PUT. The test catches both (checked with the two mutants).

**Implementation notes.** The byte enables of a beat come from the record's first and last beat and two
32-bit edge masks, all registered when the command is checked, so the per-beat logic is two
comparisons and an AND. The 4,096-bit mask is reset to all ones when the header arrives, not at the end
of the command checks. The kernel refuses (in simulation) a block size that is not a power of two, or
a build without PMMAC: Tiny ORAM applies `WMask` in its integrity verifier, so without PMMAC a packed
PUT would overwrite the rest of the block with zeros.

**Host:** `DOMA_PACK=1` now works for Tiny ORAM, with the same meaning as for DOMA (block/8 records per
block). `DOMA_N` stays records: the host divides by the records per block to get the blocks and L.
Command and response buffers are block-sized. `build_tinyoram.sh PACK=1` picks L the same way.

## 12. Phases 3 and 4: on the card

`docs/TINYORAM_CARD_RUNBOOK.md`: the commands, in order, with the output to expect at each step and
what to report.

## 13. Audit fixes before the card (2026-10-13)

**Re-boot on every init launch** (`tinyoram/rtl/tinyoram_kernel.v`, as `doma_kernel.v` now does).
XRT does not reprogram the card between host processes that use the same xclbin. Before this fix, the
kernel latched the tree buffer for its lifetime, so a second host run would either get error `0x20` (its
buffer at a new address) or silently inherit the previous run's ORAM. Now:
* Every launch with `size = 0` holds Tiny ORAM and the adapter in reset (state `K_RST`, 16 cycles; the
  reset continues until the tree is filled), latches `pages` again, and reports the geometry without
  touching memory.
* The next launch with commands zero-fills the tree again and releases Tiny ORAM. Its reset
  re-initialises the on-chip state (PosMap, PLB, stash).
* `0x20` is only for a launch with commands that names a different buffer than the last init launch.
  The latched buffer is kept.
* While filling, the zero-fill counts only its own write responses and never goes below zero, so a
  stray response left over from an aborted run cannot stall it.

Tests (`+reboot`, every block size; `+reboot +reboot_same` at 64 B):
1. A first session: init, preload, runs, and the packed verify launch.
2. A second init with the tree buffer moved to another address (or, with `+reboot_same`, at the same
   address). The init must touch no memory.
3. A probe. One record goes into each of blocks 0–7, which the first session had filled, and then each
   whole block is read back. A fresh ORAM returns the record with zeros around it; a kept ORAM
   returns the old block.
4. Commands and a verify launch, checked against a fresh reference model.
5. A launch with commands naming yet another buffer. It must report `0x20`, keep using the latched
   buffer, and stay correct.

Throughout, every tree burst must fall inside the buffer latched by the last init launch. Mutants:
* not resetting Tiny ORAM at init: caught by the probe;
* not re-latching `pages`: caught by the address monitor and the summary.

**Check order.** `K_CHK` now follows `doma_kernel.v`'s order: opcode (0x2), then the range of a PUT
(0x40), then a halted ORAM (0x8), then the key (0x4). Only after those does it check the range of a GET
(0x40), which is Tiny ORAM only, since `doma_kernel`'s GETs return the whole block. So a command with
both a bad range and a bad key gets the status DOMA gives it: 0x40 for a PUT, 0x4 for a GET. The verify
launch tests both cases, and the Phase 2 order (range first for GETs too) fails it.

**Testbench random numbers.** `$random(seed)` is replaced by two xorshift32 generators, as in
`tb_stash.v`: one for commands and the stale tree contents, and one for packed mode's offsets, lengths and
junk. In Verilator, `$random(seed)` produced degenerate sequences that touched few distinct keys. All
checks and the mutation checks were rerun with the new generators. The Phase 4 simulation
(`docs/tinyoram_l15_sim_2026-10-13.txt`) was also rerun, because its traffic figure depends on how many
distinct blocks the commands touch.

## 14. Changes for a fair comparison with DOMA (2026-10-18)

Requested in the comparability note of 2026-10-18. Everything here is in Tiny ORAM's own files and
the host's Tiny ORAM path. Tiny ORAM's RTL changes only through the optional patch 07, whose default
leaves it as published.

### Kernel front end, as doma_kernel's (`tinyoram/rtl/tinyoram_kernel.v`)

* **Prefetch.** A fetcher reads command k+1's header while command k is in `K_WAIT`; for a PUT it
  also reads the data into a block-sized buffer (2 beats at 64 B, 128 at 4 KB). Every run start
  clears it. A request stays pending until the fetcher takes it, so a rejected command can't drop it.
* **Posted response writes.** GET data and headers are written without waiting for their B responses.
  `wb_pend` counts them, and the run waits for all of them once, before the summary.
* **Early release (the latency end point).** A command ends when its data is done and Tiny ORAM is
  idle with every write-back beat handed off on the bus. That is the primary latency (header bytes
  8–11, summary min/max), the same end point as DOMA's arrival mode. The next command is issued then;
  the adapter still holds its reads until every write is acknowledged, exactly as before. The
  command's header waits in a one-entry queue until then, so header bytes 20–23 can carry the latency
  to write-back acknowledged. Bytes 16–19 are still data ready.
* **Saving:** in simulation (64 B, 100-cycle memory), the same 120 commands take 33,439 device cycles
  instead of 39,749, about 52 cycles per command.

### Merged bursts (B6), adapter option `TINYORAM_MERGE` (`fetch_tinyoram.sh ... merge`, `build_tinyoram.sh MERGE=1`)

* **What merges:** consecutive commands of the same direction to contiguous addresses become one
  AXI burst. A burst never crosses 4 KB or the tree-top split. It closes on a command that does not
  continue it, after 4 idle cycles, or at a limit.
* **Result:** at 64 B a read burst is 12 beats, one 384-byte bucket; buckets on a path are not
  contiguous, because the path leaves its subtree. At 4 KB a 16.5 KB bucket becomes 4 KB bursts.
* **Ordering:** the read-behind-unacknowledged-write hold is kept, on both ports.
* **Effect in simulation:** at 64 B with 1M-record geometry (L = 15, packed), 200 commands take
  268,212 cycles merged against 403,362 with the 1:1 adapter, with the same traffic.
* **The 1:1 adapter remains the default** (`TINYORAM_MERGE 0`). It is Tiny ORAM as built for its
  DDR3 controller, and is reported too.

### Tree-top split (matched on-package budgets)

* **Interface:** the kernel has a fourth memory port, `top` (`m_axi_gmem3`, HBM), and a scalar
  `top_bytes`. Tree byte offsets below `top_bytes` live in `top`; the rest live in `pages` (host
  memory in the headline configuration).
* **Why a byte prefix is the tree top:** Tiny ORAM lays the tree out subtree by subtree, in
  breadth-first order (`AddrGenBktHead.v`: bucket index = index in subtree + subtree index ·
  2^L_st). At 64 B, a subtree has L_st = 7 levels and occupies 49,152 B.

  | Geometry | Subtree | Top prefixes (bytes) | Whole tree |
  |---|---|---|---|
  | 64 B, L = 15 (1M records packed) | 7 levels | levels 0–6: 49,152; 0–13: 6,340,608 | 31,506,816 B |
  | 4 KB, L = 12 (16,384 blocks) | 2 levels | 0–1: 66,048; 0–5: 1,387,008; 0–9: 22,522,368 | 225,438,336 B |
  | 4 KB, L = 14 (65,536 blocks) | 2 levels | 0–9: 22,522,368; 0–11: 90,155,520 | 901,769,856 B |

  Any byte count works. A count between two subtree levels covers part of the next level's
  subtrees. The split is a fixed address map, so it reveals nothing about the access pattern.
* **Host:** `DOMA_TINY_TOP=<bytes>` (`all` = the whole tree on-package). The host prints the
  placement and the per-record bytes on-package and in `pages`. The kernel rounds a count below the
  tree down to 4 KB and flags it (summary error 0x80 at init).
* **Matched budgets:** `DOMA_TINY_TOP=doma:<p>` makes the top the bytes `doma_kernel` keeps on-package
  at `<p>`% HBM for the same records. That is its position map, bucket records, stash and HBM buckets,
  sized as the host sizes DOMA's buffers. The blocks are `DOMA_MATCH_BLOCK` bytes (default 32), packed
  as `DOMA_PACK` says. Against the buffers the host actually allocates for `doma_kernel` (checked under
  the XRT mock), the figures agree to the byte. For 1M 8-byte records:

  | DOMA point | DOMA on-package | Tiny ORAM top (4 KB multiple) | Share of the tree |
  |---|---|---|---|
  | 0% HBM | 8,076,960 B | 8,073,216 B | 25.6% |
  | 20% | 10,076,960 B | 10,076,160 B | 32.0% |
  | 100% | 18,076,960 B | 18,075,648 B | 57.4% |

  So even at DOMA's 100% point, Tiny ORAM keeps a little over half of its tree on-package, because its
  tree (31.5 MB at Z = 4 with headers and MACs) is larger than DOMA's whole footprint. With
  `DOMA_TINY_FLATPM=1` (for a `FLATPM=1` bitstream), the 1 MB on-chip position map comes off the top.
* **Zero-fill:** at the first command launch it covers both regions.
* **Ordering across ports:** read data from the two ports reaches Tiny ORAM in command order, through
  a per-burst order FIFO and one read buffer per port. Write data follows the same rule.
* **Traffic record:** counts both ports.
* **Link configs:** `tinyoram_hw.cfg` maps `top` to HBM[9]; `tinyoram_host.cfg` maps `pages` to
  HOST[0] and `top` to HBM[8].

### Sweeps: `scan.sh` with `DOMA_KERNEL=tinyoram_kernel`

The same script, host, command stream and CSV columns as DOMA's sweeps. For Tiny ORAM, `NS` must be
the bitstream's own record count, and the second axis is the tree-top setting `TOPS` (default
`0 doma:0 doma:20 doma:100`) in place of `HBMS`. It goes in the `hbm_pct` column. `0` is the
whole tree in host memory, the headline comparison with DOMA at 0% HBM; `doma:<p>` are the matched
budgets. Each run's full output (latency spread, histogram, placement, traffic) goes to a `.log` next
to the CSV. With `doma_kernel`, `scan.sh` behaves exactly as before (its CSV checked unchanged under the
XRT mock).

### Position map under both trust assumptions (patch 07, `fetch_tinyoram.sh ... flatpm`, `build_tinyoram.sh FLATPM=1`)

* **(a) As published.** PosMap recursion with the PLB: at L = 15, 4 levels (3 PosMap ORAMs in
  untrusted memory).
* **(b) Same trust as DOMA.** `TINYORAM_RECURSION 1` is a one-line override of the recursion depth in
  Tiny ORAM's `UORAM.vh`. Tiny ORAM then keeps all N position-map entries on chip (64-bit PRF
  counters: 1 MB at 131,072 blocks, block RAM or URAM) and has no PosMap ORAMs.
  * **Budget:** that 1 MB is trusted on-package storage and counts against the matched budget.
  * **Bias:** it is on chip rather than in HBM, which favours Tiny ORAM slightly over an HBM position
    map: no HBM round trip per access. Moving it to HBM would need a new PosMap memory with a latency
    protocol inside Tiny ORAM's frontend. That is not done; this is a stated limitation.
  * **Simulation (64 B, L = 15, packed, merged, no preload):** 200 commands take 81,387 cycles flat
    against 268,212 recursive, and move 103 beats each way per command against 356.

### Latency spread and timing protection

* **No timing protection.** Tiny ORAM as published pads nothing. Its latency varies with background
  evictions, PLB hits and, with recursion, the number of PosMap ORAM accesses. DOMA pads every access
  to calibrated budgets (arrival-relative scheduling, about a quarter of each access). **So DOMA's
  figures include its timing padding and Tiny ORAM's do not.**
* **What the host reports for Tiny ORAM:** min, p50, p90, p99, p99.9, max and mean of the primary
  latency, and a 16-bin histogram, from every command's header. `DOMA_LAT_HIST=1` prints the same for
  doma_kernel; without it, DOMA's output is unchanged.

### Independent review of this rewrite, and what changed after it

A separate read of the new adapter and command engine found no defects in the adapter. It found four in
the kernel's new paths, all fixed and now tested:
1. **A write error after release was not charged to its command.** A SLVERR/DECERR arriving after a
   command was released now marks that command's queued header 0x8 and the summary. The new `+berr=K`
   test injects SLVERR on the K-th tree write response. The run must report 0x8 in the summary and on
   the header of the command that write belongs to (the released command whose header waits for its
   acknowledgements, otherwise the command in progress), without hanging; a re-boot must follow and the
   fresh run after it must be correct.
   The summary's completed count (bytes 28–31) leaves such a command out, so it always equals the
   number of headers without an error; the fault runs check that. (Its latency stays in the summary's
   min/max, which cover every released command.)

   A later test found the same-cycle race behind this: the adapter decrements its count of
   outstanding writes and sets its error flag on the same edge. So when the failing response was the
   last one outstanding, "all acknowledged" and the error showed together, and the header queue took
   the first. That released the header clean and charged the error to the next command. It showed at
   128 B, merged, with the split. Now an error wins over "all acknowledged" in three places:
   * in the header queue;
   * in `K_WAIT`, where a halted ORAM is an error even if the write-back has been handed off;
   * in `K_HQ`, where a released command is charged if the ORAM halted before its header was queued.
     Only that command's writes can be in flight then: the next command has not started, and Tiny
     ORAM is idle, so its integrity checks are done.
2. **The acknowledged latency undercounted.** After release the counter now keeps running through the
   GET write-back and the header queue, and the acknowledgement time is captured whenever it happens.
3. **An error flag could be lost** when two parts of the engine set it in the same cycle. Errors found
   while a header waits now go to their own register, OR-ed into the summary.
4. **Re-boot after an aborted run.** The init launch now lets any traffic left in the adapter finish
   (bounded by the command timeout) before resetting it. `K_BOOT` has a timeout. The run's end waits,
   bounded, for Tiny ORAM and the adapter to be idle, so the traffic record includes an access Tiny ORAM
   finishes after a fault. A zero-fill write error now halts the ORAM (0x8).

Two test gaps it pointed out are also closed:
* **A one-command run before run 1:** a prefetch left over from it must not leak into the next run.
* **A monitor on command reads:** only headers and data slots of the current launch's commands may be
  read, which catches prefetching past the last command.

Known and accepted:
* **Early release needs its 2-cycle filter.** Tiny ORAM reports idle for one cycle while a write
  command still sits in a register before its DRAM port, so releasing after one idle cycle would end
  the latency count 1–2 cycles early. Data stays correct either way, because the adapter's
  read-after-write hold still applies.
* **Write channel ordering.** Every master here asserts WVALID only after AWREADY, as `doma_kernel`
  does. The Xilinx interconnect and HBM accept that; a slave that waits for WVALID before AWREADY
  would not.
* **Buffer alignment.** XRT buffers are 4 KB aligned, which the 4 KB burst rule assumes.

### Tests and mutation checks

`sim/run_tinyoram.sh`: 81 checks over the four block sizes (log: `docs/tinyoram_regression_2026-10-18.txt`).
Per size, with the 1:1 adapter: e2e, late, gaps, wlat, xinit, reboot, split, fault, faultlast,
faultearly, ranges; packed8 and packed16 at 64 B and 4 KB; rebootsame at 64 B. With the merged adapter
(its own build): m_e2e, m_gaps, m_wlat, m_split, m_fault, m_faultlast, m_faultearly, m_topall.

Fault injection (the testbench drives SLVERR on a tree write response; every fault run must report
0x8 in the summary and on the header of the command the write belongs to, the summary's completed
count must equal the headers without an error, and a re-boot and a correct fresh run must follow):

| Option | Where the error lands |
|---|---|
| `+berr=K` | the K-th write response of the run (in practice, while a command runs) |
| `+berr_rel` | the first response while a released command's header waits for its acknowledgements |
| `+berr_last` | the last response outstanding then (the error and "all acknowledged" show in the same cycle) |
| `+berr_early` | after a GET's release, before its header is queued: the testbench stalls the response port, as a slave may, until one of the GET's tree write responses arrives |

The fault-after-release checks need a response still outstanding at the release: writes land 200
cycles late, 2,000 at 4 KB, where Tiny ORAM reports idle long after its last write beat.

`sim/run_tinyoram_mutants.sh` (new): 16 mutation checks at 64 B, each a deliberate bug in the kernel or
the adapter, and each must be caught (log: `docs/tinyoram_mutants_2026-10-18.txt`).

| Mutant | Test | Caught by |
|---|---|---|
| m1 wrong last-beat formula | `+ranges` | hang at the cycle limit |
| m2 mask not restored after a partial PUT | `+ranges` | verify mismatch |
| m3 no core reset at init | `+reboot`, `+reboot +reboot_same` | hang in `K_RST` |
| m4 `pages` not re-latched | `+reboot` | summary wrong |
| m5 Phase 2 check order | `+packed=8` | GET with a bad range and a bad key gets 0x40 |
| m6 prefetch not cleared at run start | default | run 1's first command runs a stale prefetched header (wrong key) |
| m8 prefetch past the last command | default | command-read monitor |
| m9 error after release not charged to its header | `+berr_rel +host_wlat=200` | header without 0x8 |
| m10 such a command still counted as completed | `+berr_rel +host_wlat=200` | summary count ≠ headers without error |
| m11 "all acknowledged" tested before the error in the header queue | `+berr_last +host_wlat=200` | header without 0x8 |
| m13 no charge in `K_HQ` for an error before the header is queued | `+berr_early +host_wlat=200` | header without 0x8 |
| a1 reads not held behind unacknowledged writes | `+host_wlat=200 +preload` (and `+packed=8`) | Tiny ORAM's stash check: a block read back twice |
| a2 off-by-one in the tree-top split | `+top=16384` | address monitor |
| a3 merged burst crossing 4 KB | `+top_all +ranges` | address monitor |

Two of these were missed by the first version of the tests, so the tests were strengthened:
* **a1** passed `+host_wlat=200` without a preload. Probably because the tree then holds few real
  blocks, so a read that overtakes a write rarely brings back a stale copy of a block that has moved.
  With the preload, every block is in the tree and the stale copy hits Tiny ORAM's own stash check.
  The late-write tests (`wlat`, `m_wlat`) now preload first.
* **m9** passed `+berr=40`: the error arrived before any command was released, and took the ordinary
  path. `+berr_rel` puts the error on the first write response that arrives while a released command's
  header waits for its acknowledgements, and requires 0x8 on that header. It also found that such a
  command was still counted as completed, fixed above (m10 is that fix's mutant). Running it at every
  size then found the same-cycle race above. `+berr_last` and `+berr_early` were added for it, and
  they run at every size in both builds (`faultlast`, `faultearly`, `m_faultlast`, `m_faultearly`).

Two mutants are left out because they are not bugs in what is checked:
* **m7, releasing after one idle cycle instead of two:** see "Known and accepted" above.
* **m12, `K_WAIT` testing release before `halted`:** `K_HQ` then charges the command, so its header and
  the completed count are still right; only the summary's latency min/max would include it.

### A Tiny ORAM behaviour the tests now model

A GET of a never-written block returns Tiny ORAM's `FakePattern` (0x00af1234, `UORAM.vh`). From then
on the block behaves as written, with undefined contents. This was observed in simulation: a later
partial PUT kept non-zero bytes around its record. The testbench's block image marks such bytes as unknown. The host
never does this: its preload writes every record first.

## 15. Before the builds: checks and card scripts (2026-10-18, second note)

### Vivado's "already declared" error (item 2)

Vivado treats a name used in a port connection before its declaration as an implicit wire, then rejects
the later declaration. Verilator accepts it. `run_tinyoram.sh` now starts each size with
`iverilog -Wimplicit` over the kernel, the adapter and the fetched core, for the 1:1, merged and
flat-position-map variants (their generate branches differ):
* **The kernel and the adapter:** no implicit nets.
* **The core:** eight implicit nets (`AESREWORAM.v` 535–538, `PathORAMBackend.v` 369–380 since patch 08, 359–370 before). All are in the
  REW-ORAM branch (`EnableREW = 1`), which this build does not elaborate, and none is declared later. They
  are listed exactly in the script; anything else fails.
* **One iverilog-only workaround:** iverilog cannot size `DataIn + j` in `AES_DW.v` (a genvar), which Vivado
  does. The lint therefore sizes it in a lint-only copy; the core is built as published.
* **Mutant l1** (a name used before its declaration in the kernel) is caught.

### The read-behind-write hold under slow acknowledgements (item 3)

* **The test** (`slowack`, `m_slowack`, every size, both adapters): after the preload, tree writes are
  acknowledged 2,000 cycles after their data (6,000 at 4 KB), longer than a whole path write-back. The
  models hold all of it, through `axi_mem_model`'s `WF_DEPTH` and a new `AW_DEPTH` parameter (default 16,
  as before). The longest hold must reach 1,000 / 3,000 cycles: the next path's reads did wait for the
  acknowledgements. At 4 KB both adapters hold reads for up to 5,051 cycles.
* **A bus monitor, on in every test:** it fails any tree read that overlaps a write not yet
  acknowledged, which is the read that would return stale data.
* **Mutant a1** (no hold), at 4 KB on both adapters: the 1:1 build fails with Tiny ORAM's own stash check
  (a block not found), and both are caught by the monitor at the root bucket. The merged build's stale
  reads did not change any result: the top buckets of a Path ORAM tree hold mostly dummy blocks. That is
  why the monitor, not the data, is the criterion.

### Addresses above 4 GB (item 4)

* **Offsets:** the adapter's tree offsets are Tiny ORAM's DRAM address times 8 in 64 bits, and every
  base + offset is a 64-bit sum. Tiny ORAM sizes its DRAM address to its tree. The kernel's tree size,
  zero-fill offsets and split point are 64-bit too.
* **Tested:** the testbench's tree and tree-top buffers now start 16 KB below a 4 GB boundary, so every
  tree crosses one. A 32-bit base + offset sum (mutant a4) is caught: Tiny ORAM's stash check stops on
  the wrapped addresses before the address monitor has to.
* **Limits that remain** (documented, not fixed):
  * `top_bytes` is a 32-bit argument, so the on-package top is at most 4 GB − 4 KB, and `all` means the
    whole tree only for a tree under 4 GB. The top buffer is one HBM bank (HBM[8], 512 MB) anyway.
  * The traffic record gives the tree size in 32 bits of 64-byte bursts (256 GB), and the top port's
    traffic in 28 bits of 64-byte units per direction and launch (17 GB).
* **Planned trees:**

  | Build | Blocks | L | Tree |
  |---|---|---|---|
  | 64 B, 1M records packed | 125,000 | 15 | 31.5 MB |
  | 64 B, 100K packed | 12,500 | 12 | 3.2 MB |
  | 64 B, 10M packed | 1,250,000 | 19 | 409 MB |
  | 4 KB, N = 16K | 16,384 | 12 | 225 MB |
  | 4 KB, N = 64K | 65,536 | 14 | 902 MB |

### Counts

`run_tinyoram.sh` now has 93 checks: the 81 of §14, plus the lint at each size (4) and `slowack` and
`m_slowack` at each size (8). `run_tinyoram_mutants.sh` has 21, adding l1, a4, a1 at 4 KB on both adapters,
and (§16) l2. Logs: `docs/tinyoram_regression_2026-10-18.txt`, `docs/tinyoram_mutants_2026-10-18.txt`.

### Traffic by port

The traffic record's free bytes 1–7 now carry the top port's share (64-byte units). The host prints
`traffic split: pages (off-package) … ; top (on-package) …` per command, so at a matched budget Tiny ORAM's
host-memory traffic is measured, as DOMA's is.

### Card scripts (`tinyoram/card/`, items 1 and 5–7)

| Script | What it does | Pass |
|---|---|---|
| `install_tinyoram.sh <base.zip> <overlay.zip> [DEST] [--check]` | Verifies the base's manifest. Overlays Tiny ORAM's files. Replaces a shared file whole only if the base has the version the overlay was made from, otherwise applies `docs/tinyoram_fair_shared_files.diff` and stops if it does not apply. Regenerates and verifies the manifest. Makes one copy per bitstream. `--check` runs DOMA's regression at both sizes and both Tiny ORAM regressions. | `INSTALL OK` (with `--check`: `…, ALL REGRESSIONS PASSED`) |
| `bringup_64.sh ooc / emu / hw / card` | Runbook 3.2–3.5 at 64 B, L = 6. The out-of-context check covers both adapters. Emulation uses merged bursts with the tree in HBM. The board build is the headline configuration at small size: merged, tree in host memory. Card runs exercise the split, the whole tree on-package and a back-to-back run. The post-placement check is automatic. Every step appends to `bringup_report.txt`, which is what to send back. | each step's last line |
| `queue.sh start / status / pause / stop / reset` | The 7 builds of `queue.txt`, one at a time, each in its own copy. Out-of-context timing at that geometry comes first; a failure skips the board build and gives the reachable clock. The board build is stopped if post-place WNS < −0.5 ns. Then `check_timing.sh`'s verdict. | `DONE` per entry |
| `sweep_tiny.sh` / `sweep_doma.sh` | `scan.sh` with matching settings. Tiny ORAM: `TOPS="0 doma:0 doma:20 doma:50 doma:100"`, matched budgets for DOMA's 32-byte blocks packed 4 per block (4 KB unpacked for the 4 KB builds). DOMA: `DOMA_PACK=1 NS="100000 1000000 10000000" HBMS="0 20 50 100"`. Logs keep latency spread, placement and traffic for both. | `PASS` per bitstream |
| `merge_results.py` | One table per configuration from both designs' results: KQPS, primary latency (p50, p99, max; max also in µs at the clock), off- and on-package bytes per command, on-package and host bytes per record, clock. | writes `comparison.md` and `comparison.csv` |

All five were dry-run here against stand-ins for XRT, Vivado and v++ (no tools here). That covered the
install on your package and on a base with newer shared files, and a conflicting base that must stop
the install. It also covered the bring-up's card checks passing and failing, the queue's DONE,
FAILED_OOC and FAILED_PLACE paths (the build is stopped), and the sweep → merge chain.

DOMA's host gets two opt-in lines for the table, neither changing its default output (checked in 11
configurations):
* **`DOMA_PLACEMENT=1`:** DOMA's on-package and host bytes per record.
* **A cross-check:** a warning appears if the matched-budget sizes ever differ from the buffers the DOMA
  path allocates. It never fired.

`scan.sh` gets `SCAN_LOG=1`, which keeps DOMA's full output.

### To state with the results (item 8)

* **Timing protection:** DOMA pads every access to fixed budgets and handles GETs and PUTs identically,
  so they look alike on the bus; it pays a small cost for this. Tiny ORAM has no timing protection, and
  it prefetches only PUT data.
* **Variant (b):** Tiny ORAM's position map is on chip, which saves it an HBM round trip per access
  compared with DOMA.
* **DOMA's 0% point:** DOMA still keeps about 8 MB on-package (per 1M records). The `0` run gives Tiny
  ORAM nothing on-package; `doma:0` gives it the same 8 MB.

`merge_results.py` prints these at the top of `comparison.md`.

## 16. A dead upstream file stopped Vivado (bring-up, 2026-10-18 evening)

**What happened.** The bring-up's `ooc` step failed in Vivado with `[Synth 8-36] 'LastBuckerAddr' is not
declared [DRAMInitializer.v:96]`, then `module 'tinyoram_kernel' not found`.
* **Why Vivado:** `DRAMInitializer.v` is unused upstream (nothing instantiates it at 18ece07), and
  `LastBuckerAddr` is defined nowhere. Vivado analyses every file it is given: the out-of-context script
  reads `files.f`, and `package_tinyoram.tcl` globs every `.v` in `build/src`. So the dead file broke the
  out-of-context run, and it would have broken every board build.
* **Why not the simulators:** Verilator and the iverilog lint elaborate only from `tinyoram_kernel`, so
  they never looked at it.

**Fixes:**
* **`fetch_tinyoram.sh` leaves out dead files.** These are files whose modules no other file names, in
  any configuration (`DRAMInitializer`, `aes_192`, `aes_256`, `ClockSource`, `FIFOLinear`, `LFSR`,
  `ROISeedGenerator`, `SynthesizedRandDRAM`), plus the `DRAM2RAM`/`SynthesizedDRAM` pair, which only
  each other and `SynthesizedRandDRAM` name. That makes 72 sources into 62.
  * **How "dead" was decided:** Verilator's elaborated module list, over all four block sizes, the 1:1,
    merged and flat-position-map variants, with and without `SIMULATION`. None of the ten has a module
    in any of them.
  * **What stays:** files named by an inactive generate branch (the REW-ORAM files, `Bin2Gray`/`Gray2Bin`,
    `padder1`), so every tool still finds the modules those branches name.
  * **`aes_192`/`aes_256`** also instantiate their rounds with the wrong number of ports, a second trap of
    the same kind.
* **`vitis/elab_tinyoram.tcl`:** a one-minute Vivado elaboration (`synth_design -rtl` of
  `tinyoram_kernel`) of exactly the files the builds read. It runs:
  * in `build_tinyoram.sh` after the fetch, before packaging, for every board and emulation build
    (`ELAB=0` skips it);
  * in `bringup_64.sh ooc` before each out-of-context run;
  * in `queue.sh` before each entry's out-of-context run.

  A source error now fails in a minute, not hours.
* **`sim/lint_tinyoram.sh`** (used by `run_tinyoram.sh`): besides the elaboration from the top, it
  elaborates every module of every source file as its own top, as Vivado analyses every file. It fails
  on undeclared or unbound names, unknown modules, port mismatches, syntax errors, and unlisted implicit
  nets.
  * **What it reports:** with the dead files left out, 74 modules, all clean. Three (`DM_Cache`,
    `Keccak_WF`, `REWStatCtr`) show only `CountAlarm`'s zero-width replication with their default
    parameters as their own top; in the design their parameters are set.
  * **New mutants:** l2 puts `DRAMInitializer.v` back and is caught; so is `aes_192.v` put back.

**`AES_DW.v:146`** (`{{(AESWidth-AESEntropy){1'b0}}, DataIn + j}`, which iverilog will not size).
* **By the standard:** a genvar is a 32-bit integer, so the operand is sized. `DataIn` is
  `AESEntropy` = 64 bits, the sum is 64 bits, and the concatenation is exactly `AESWidth` = 128 bits.
  Verilator computes it this way, and the regression's AES results depend on it.
* **Not confirmed in Vivado here:** there is no Vivado in this environment. The module is in the
  design (`PRNG` instantiates `AES_DW`), so the elaboration step elaborates this line: if Vivado rejected
  it, `elab_tinyoram.tcl` would fail there, within a minute.

## 17. The 4 KB queue geometries and the PosMap depth (2026-10-18, night)

**What happened.** `lint_tinyoram.sh` failed for queue entries q6 (`4k_n16K_merge`, L = 12) and q7
(`4k_n64K_merge`, L = 14): `CountAlarm.v:97: error: Concatenation repeat may not be zero`. The regression
had linted every block size only at its default depth, L = 6, so it never saw these geometries.

**The instance:** `tinyoram_kernel.u_tiny.front_end.uoram.PPP.PosMapInitCounter` (`PosMapPLB.v:93`,
`CountAlarm #(.Threshold(FinalPosMapEntry))`). Its threshold is 0, not 1: `CWidth = log2(0) = 0`, hence `{0{...}}`.
It counts through the on-chip final PosMap at initialisation, and `FinalPosMapEntry` is the size of that PosMap.

**Why it is 0.** Tiny ORAM's depth rule (`UORAM.vh`) is "recursive until < 1024 entries in PosMap", written
as `divceil(L + 2 − 10, 4 − PRFPosMap) + 1`. That is 3 bits per level, because a 64 B PosMap block holds 8
leaves (`LeafInBlock = ORAMB / 64`; 64-bit PRF leaves). A 4 KB block holds 512 leaves, which is 9 bits per
level. So the 3-bit form adds levels that have nothing left to hold:

| Geometry | Tiny ORAM's form | Final PosMap | Same rule, 9 bits per level | Final PosMap |
|---|---|---|---|---|
| 4 KB, L = 12 (16,384 blocks) | depth 3 | 16,384 / 512² = **0** | depth 2 | 32 entries |
| 4 KB, L = 14 (65,536 blocks) | depth 3 | **0** | depth 2 | 128 entries |
| 64 B, any L | ⌈(L − 8)/3⌉ + 1 | 1..1024 | identical | identical |

* **At 4 KB with L ≥ 12, the published formula gives a design with an empty final PosMap.** A
  zero-entry PosMap with a zero-width counter is not a real configuration. Neither Verilator nor iverilog
  will build it (IEEE 1800-2017 §11.4.12.1 allows a zero replication only inside a larger concatenation),
  so no simulator ever ran it. Whatever Vivado does with it would not be meaningful either.
* **Why not widen `CountAlarm` instead:** `CWidth ≥ 1` would compile, but it would hide the empty PosMap
  rather than fix it. It would also change a core file every geometry uses.

**Fix: `fetch_tinyoram.sh` applies the same rule at the block's real width.**
* **The rule:** `divceil(L + 2 − 10, log2(ORAMB/64)) + 1`.
* **Where it is written:** through patch 07's existing `TINYORAM_RECURSION` define, and only when the
  result differs from Tiny ORAM's form. That leaves 64 B untouched at every L, and so all of q1–q5 and the
  headline.
* **The guard:** the fetch stops if a depth would leave a final PosMap outside 1..1024 entries.
* **What the fetch writes:**
  * 4 KB, L = 12 and 14: depth 2.
  * 4 KB, L = 18: depth 3 (published form: 5).
  * 128 B and 256 B with L ≥ 12: one level less than the published form. There the published form still
    builds, but has a final PosMap far below its own 1,024-entry target, for example 64 entries at 128 B
    with L = 12. Neither size is in the queue.
* **What it costs:** nothing new. The core is unchanged, and this is the case its own comment describes.
  The on-chip final PosMap is 32 / 128 entries.
* **It makes the 4 KB comparison more faithful:** the PosMap ORAM is one level, not two, so a PLB miss
  costs up to one PosMap path fewer than the published formula would charge.

**Checks:**
* **`run_tinyoram.sh`:** a new first stage fetches every `queue.txt` geometry into its own copy, as
  `queue.sh` does, and lints it. That is 7 checks, about two minutes; `SIZES=""` runs only this stage, and
  `QUEUE_LINT=0` skips it.
* **A q6 simulation:** 4 KB, L = 12, depth 2, built with a 256 MB tree buffer. With `+keys=32`, a new
  opt-in testbench option, 32 keys 512 apart sit one per PosMap block, against a PLB of two blocks, so
  PosMap blocks keep being evicted and read back. Packed records, the first 1 MB of the tree on the top port, and 30% read
  gaps are on. Every GET checked. `GEOM_SIM=0` skips it.
* **By hand here:**
  * q7 at L = 14, merged, with a 1 GB tree buffer, 32 keys, the first 1 MB on the top port, and gaps.
  * q6 with the 1:1 adapter, 64 keys, with late writes.

  Both `ALL CHECKS PASSED` (`docs/tinyoram_4k_geometry_sim_2026-10-18.txt`). The testbench's top buffer is
  4 MB, so a split must fit in it, as well as being a multiple of 4 KB (else 0x80).
* **Mutant l3:** q6's geometry with the published depth. The lint catches it at `CountAlarm.v:97`.

## 18. Run-time tree depth (patch 08, 2026-10-19)

**What it is.** Today's builds fix the tree depth L at build time. With `TINYORAM_RTDEPTH`, a build is made for
L_max, and the host picks any L from 6 to L_max at its init launch. The core then runs as the native build of
depth L.
* **What the build serves:** one 64 B build at L_max = 19 (10M records packed) serves the 100K, 1M and 10M points.
* **Fairness requirement:** a run-time-depth build must not walk L_max-long paths for a small N. It must behave
  exactly like the native build of the same L.
* **Acceptance (card):** N = 1M on the L_max = 19 build against the native L = 15 build (queue entry q1). Both
  must give the same throughput and latency within run-to-run noise, at the same clock.
* **Block size stays a build parameter** on both sides, as for DOMA.

### What changes with L, and where the run-time value comes from

`rtdepth/TinyRTGeo.v` holds a table of every depth-dependent quantity for L = 0..31. The table is computed at
elaboration by a constant function that applies the same formulas as Tiny ORAM's headers, so in hardware it is
a 32-entry lookup and a register. The kernel holds the active depth and passes the table row to the core as one
bus (`RTGeo`, `include/RTGeo.vh`). Each module that used a compile-time constant takes it from the bus instead:

| Quantity (native constant) | Used in | Run-time version |
|---|---|---|
| path length `ORAML + 1` | `AddrGen` (`Ready`, `CmdValid`) | the bus's L |
| `PathSize_DRBursts`, `PathSize_BEDChunks`, `PathPSize_BEDChunks` | `BackendCoreController` (two `REWStatCtr`), `DRAMToStash` (`REWStatCtr`), `AESPathORAM` (path counter) | counters with a run-time threshold (`CountAlarmRT`, `REWStatCtr` with `RTChunks = 1`), same terminal test as `CountCompare` |
| `BlocksOnPath` | `Stash` (write-back counters), `StashScanTable` (per-access reset) | from the bus |
| `StashCapacity` | `StashCore` (free-list reset, per-access list rebuild) | from the bus; the free list ends with SNULL at the active capacity, the rebuild stops there |
| levels on a path | `StashScanTable` (deepest bucket a block may go to) | levels below the active leaves count as full, so no block is placed there |
| subtree layout `numTallST`, `(L+1) % L_st`, `numST · L_st` | `AddrGenBktHead` | from the bus: the native build's addresses, bucket for bucket |
| `NumValidBlock` (N) | `UORAMController` (range check, PosMap block addresses) | from the bus |
| `FinalPosMapStart`, `FinalPosMapEntry` | `PosMapPLB` (on-chip PosMap select, address, init count) | from the bus; the on-chip PosMap RAM is sized for 1,024 entries, the largest any depth needs |
| leaf width `ORAML` | `IntegrityVerifier` (PRF leaf), `BackendCoreController` (dummy leaf), `PosMapPLB` (the PLB's leaf tag) | masked to L bits |
| dummy-leaf PRNG width `1 << log2(ORAML)` | `BackendCoreController` | one PRNG per width the build can need (8, 16, 32 bits), same key, the active one selected |
| tree size, N, the records | kernel: zero-fill, key check, tree-top split, record [size+1], adapter range check | from the bus |

Some things stay at L_max size: memories and counter widths, `SNULL`, and the stash's `StashAlmostFull`
expression. `StashAlmostFull` reduces to "occupancy ≥ C − 1" at any L, so it triggers exactly as in the native
build.

**Unchanged without the define.** Without `TINYORAM_RTDEPTH`, patch 08 changes nothing. `sim/check_rtdepth_native.sh`
preprocesses each of the 17 core files it touches with patches 01–07 and with 01–08, then compares them with
comments and white space removed. They are identical in all 8 configurations (4 block sizes, 1:1 and merged). The
regression runs this check.

**The dummy-leaf PRNG.** The native build of depth L draws its dummy-access leaves from a PRNG `1 << log2(L)`
bits wide: 8 bits for L ≤ 8, 16 for 9..16, 32 for 17..32. It splits each AES output into chunks of that width.
* **Why it matters:** a single PRNG of L_max's width would draw a different (equally uniform) stream, so the
  run-time build would diverge from the native one at the first dummy access.
* **The fix:** the run-time build instantiates each width it can need, all with the same key, and uses the
  active depth's. Dummy accesses are then identical too, value for value and cycle for cycle.
* **The cost:** up to two extra small AES cores.

### Interface

* **Selecting the depth.** An init launch with `size = 0x8000_0000 | L` selects depth L; `size = 0` selects
  L_max. The depth is applied while the core is held in reset, then the tree-top split is computed against
  the new tree size. A depth outside 6..L_max keeps L_max and sets status 0x100.
* **What the summary reports.** Bytes 1–3 of the summary give the active L, L_max and the smallest L (6); a
  native build leaves them 0. Record [size+1] reports N and the tree of the active depth.
* **Host (`vitis/host_doma.cpp`, shared file, additive).** When the init's summary shows a run-time-depth
  bitstream and `DOMA_N` needs another L, the host sends the depth-selecting init and prints
  `Tiny ORAM bitstream: run-time depth, L = 6..19; running at L=15`.
  * Everything after that is unchanged: the pages buffer, the checks and the runs follow the active depth.
  * A `DOMA_N` above L_max stops with a message.
  * DOMA's output is unchanged.
* **Build.** `RTDEPTH=1 bash build_tinyoram.sh` (tag `_rt`), or `fetch_tinyoram.sh <size> <L_max> [merge] rtdepth`.
  A flat position map cannot be combined with it, because its size depends on N.
* **Queue entries.**
  * q8 `64_n10M_merge_rt`: 64 B, L_max = 19, host memory, merged; for q4/q1/q5's N.
  * q9 `4k_n64K_merge_rt`: 4 KB, L_max = 14; for q6/q7's N.

  Their PM column says `rt`. `sweep_tiny.sh` sweeps every N of `RT_NS` up to the entry's N on them.
  `merge_results.py` adds a table of each run-time-depth row against the native row of the same N, adapter and
  setting.

### Checks

* **Geometry (`sim/tb_rtgeo_probe.v`).** For every block size and L = 6..22 (68 geometries), the table row of
  depth L equals all 15 compile-time constants of the native build compiled with ORAML = L. That includes the
  4 KB recursion depth that `fetch_tinyoram.sh` writes. All 68 match.
* **Equivalence (`sim/run_tinyoram_rteq.sh`).** The native build of depth L and the run-time build started at L
  run the same testbench commands and seeds, with tree buffers of the same size (the testbench's random stream
  depends on it). The check fails on any of the following:
  * either build fails;
  * any per-launch line differs (latency min/max, the three latency figures, traffic, status);
  * any tree burst differs in port, cycle, offset or length (`+axitrace`);
  * the hash of every block byte written to the tree differs. This hash covers each beat outside the bucket
    headers, with its strobes and tree offset.

  **Header contents.** The bucket headers are not compared, because their size is the same but their layout is
  not. A run-time-depth build packs its Z leaf labels as L_max-bit fields, so the MAC fields start
  Z (L_max − L) bits later. Same 2 bursts, same AES and MAC work, different ciphertext. A per-beat comparison
  (L = 9 on L_max = 12, 16,356 write beats) found 501 differing beats, all in the first three beats of a bucket
  header, and none in a block.

  The tests are e2e, preload, gaps, late writes, packed records, byte ranges, the tree-top split, slow
  acknowledgements and repeated keys. 67 pairs, all identical (results in `docs/tinyoram_rteq_2026-10-19.txt`):
  * 64 B merged, L_max = 12, at L = 6, 7, 9 and 12. These cover one subtree, a short bottom subtree, PosMap
    recursion depths 1–3, and dummy-leaf PRNG widths of 8 and 16 bits.
  * 64 B 1:1, L = 9 on L_max = 12.
  * **64 B merged, L = 15 and 12 on L_max = 19, the planned card build.** L = 15 uses a 16-bit dummy-leaf PRNG
    where L_max uses 32 bits.
  * 4 KB merged, L = 6 and 8 on L_max = 9 (two-level subtrees).

  The preloads are mostly dummy accesses: at L = 9, 1,057 of 1,133 path reads. So the dummy-access path and
  its PRNG are exercised.
* **Mutants of patch 08** (one edit each in a copy of the L_max = 12 build). Each of these must break the
  equivalence:
  * PosMap block addresses from the build's N;
  * no level mask in the scan table;
  * one 32-bit dummy-leaf PRNG;
  * the build's subtree layout;
  * the build's path length in the AES path counter;
  * a write-back that never ends;
  * the build's final-PosMap start.

  **Three edits that must not show** (bursts, cycles, block bytes and latencies all stay equal):
  * **The stash's list rebuild over the build's capacity.** The stash capacity only matters at an overflow,
    which the background eviction prevents, and the rebuild is hidden under the path write-back.
  * **PRF leaves at the build's width.**
  * **Dummy leaves at the PRNG's width.** For both leaf edits, every path and placement decision ignores leaf
    bits above L because of the level mask.

  Patch 08 keeps all three (the active depth's capacity, the leaf masks) so that the stored values are those of
  the native build.
* **The run-time build alone:**
  * a re-boot from L = 9 to L = 6 (both sessions correct);
  * depths 13 and 5 on L_max = 12, each refused with status 0x100, followed by a correct ORAM of depth L_max.
* **Host:** against an XRT mock with a run-time-depth kernel. For `DOMA_N` = 1M it selects L = 15, for 10M
  L = 19, and with 10M on L_max = 15 it stops with a message. A native bitstream never receives a depth-selecting
  launch (the mock fails if it does). DOMA's output is unchanged in three configurations.
* **Not covered:** the PLB's leaf tag is masked to L bits as in the native build. That only shows after 2^L
  writes of one PosMap block, too long to simulate, so no mutant covers it. Like the other leaf masks, it keeps
  the native value.

### Effort and timing closure

* **The patch:** a 1,259-line diff, 508 lines added.
  * 17 core files are touched, each change under `ifdef`.
  * New: `TinyRTGeo.v`, `CountAlarmRT.v`, `RTGeo.vh`.
  * In the wrapper, about 70 lines: the active depth, the geometry, and the depth-selecting init.
* **The logic added:** a 262-bit register loaded from a 32-entry constant table. Constant comparisons become
  comparisons with registers. One variable shift is added in the bucket address (`AddrGenBktHead`: by
  `(L+1) % L_st`, at most 6 positions at 64 B), and a level mask in the scan table. Up to two more PRNGs.
* **The structural cost** is that of the native L_max build: a stash for Z(L_max + 1) + C blocks, L_max-wide
  leaves, and a scan table for L_max + 1 levels. The native q5 (L = 19) has the same. So **q5's timing is the
  reference**:
  * If q5 meets 300 MHz, the run-time build most likely does too. The only path that could get longer is the
    variable shift in the bucket address.
  * The geometry register changes only while the core is in reset. If its fan-out ever showed up on a critical
    path, a false path from `u_geo/Geo_reg` would be correct (and is not set today).
* **Builds saved.**
  * Of the planned 64 B entries, q8 replaces q4 and q5; q1 stays, as the acceptance reference.
  * q9 replaces q6 and q7.
  * Any further N between 6 and L_max costs no build.

### On the card

1. Build q8 (`bash queue.sh start 8`), after q1, at 300 MHz like q1.
2. Run `bash accept_rt.sh 1 8` (`tinyoram/card/accept_rt.sh`). It runs N = 1M on both bitstreams, alternating,
   5 times each, at `DOMA_TINY_TOP` 0 and doma:20. Pass:
   * traffic per command identical (exact);
   * p50 and p99 within 2%;
   * KQPS within the larger of 2% and twice the native build's own spread;
   * every run correct;
   * the same clock.

   Last line `ACCEPT PASS`; report in `results/accept_rt.txt`.
3. If it passes, use q8 for the 100K and 10M points (`bash sweep_tiny.sh 8`) and skip q4 and q5. If it fails,
   keep the native builds and send the report.
