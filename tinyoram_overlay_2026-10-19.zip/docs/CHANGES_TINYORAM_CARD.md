# Tiny ORAM: before the U55C builds (2026-10-18, second note)

Base: your `fpga_zcu208_deploy.zip` of 2026-10-18 14:48, with `tinyoram_fair_rebased_2026-10-18.zip` (this
overlay replaces it). **The newest DOMA package (with `patches/fpga_vivado_order.patch`) was not attached**, so
this overlay could not be checked on it. `install_tinyoram.sh` is written for exactly that case: it verifies
whichever base it is given, patches the shared files if they changed since 14:48 (and stops if a patch does not
apply), regenerates the manifest, and with `--check` reruns DOMA's regression at both sizes on the result. The
newest package's changes (`rtl/doma_kernel.v`, `sim/run_verilator.sh`, `docs/README_FPGA.md`) are files this overlay
does not touch.

| Note item | File | Change |
|---|---|---|
| 1. Manifest, install | `tinyoram/card/install_tinyoram.sh` (new) | Base manifest verified; overlay; shared files replaced only if unchanged since the overlay's base, else patched; manifest regenerated over the combined tree and verified; one copy per bitstream; `--check` runs DOMA's regression at both sizes and both Tiny ORAM regressions. Tested here on your 14:48 package, on a base with newer shared files (patched, both sides' changes kept, CRLF kept), and on a conflicting base (stops). The overlay's own `MANIFEST.sha256` is the one for your 14:48 package plus the overlay; on the newest package, use the script, which regenerates it. |
| 2. Vivado's implicit-net error | `sim/run_tinyoram.sh`, `sim/run_tinyoram_mutants.sh` | `iverilog -Wimplicit` per size over the kernel, the adapter and the fetched core, for the 1:1, merged and flat-position-map variants. The kernel and the adapter have none. The core's eight are all in its REW-ORAM branch, which is not built and never declared later; they are listed exactly, and anything else fails. Mutant l1 (a use before its declaration) is caught. Nothing needed fixing. |
| 3. Hold under slow acknowledgements | `sim/tb_tinyoram_kernel.v`, `sim/run_tinyoram.sh`, `sim/axi_mem_model.v` | `slowack` and `m_slowack` at every size: acknowledgements 2,000 cycles late (6,000 at 4 KB), longer than a path write-back. The models hold all of it (`WF_DEPTH`, and a new `AW_DEPTH` parameter, default 16, as before). The longest hold must reach 1,000 / 3,000 cycles. A bus monitor, on in every test, fails any read overlapping an unacknowledged write. Mutant a1 (no hold) at 4 KB on both adapters is caught. |
| 4. Addresses above 4 GB | `sim/tb_tinyoram_kernel.v`; README §15 | The adapter and kernel are 64-bit throughout. The testbench's tree and top buffers now straddle a 4 GB boundary; mutant a4 (32-bit base + offset) is caught. Documented limits: `top_bytes` is 32-bit (top ≤ 4 GB − 4 KB); the record fields are 256 GB / 17 GB per launch. Largest planned tree: 902 MB. |
| Traffic by port | `tinyoram/rtl/tinyoram_kernel.v`, `vitis/host_doma.cpp` | Record bytes 1–7: the top port's share. The host prints `traffic split:` pages (off-package) / top (on-package) per command. |
| 5. Bring-up | `tinyoram/card/bringup_64.sh` (new) | `ooc` / `emu` / `hw` / `card`, each with its pass criterion and a report to send back (`bringup_report.txt`). The board build is the headline configuration at small size (merged, tree in host memory). The card runs cover the split, the whole tree on-package and back-to-back runs. The post-placement check is automatic. |
| 6. Build queue | `tinyoram/card/queue.sh`, `queue.txt` (new) | The 7 builds, one at a time, each in its own copy. Out-of-context timing at its geometry first: a failure skips the board build and names the reachable clock. Post-place WNS < −0.5 ns stops the build. Then the timing verdict. Commands: `status`, `pause`, `stop`, `reset`, `log`. |
| 7. Sweeps and table | `tinyoram/card/sweep_tiny.sh`, `sweep_doma.sh`, `merge_results.py` (new); `vitis/scan.sh`, `vitis/host_doma.cpp` | Matching settings: Tiny ORAM `TOPS="0 doma:0 doma:20 doma:50 doma:100"`, with matched budgets for DOMA's 32-byte blocks packed 4 per block (4 KB unpacked); DOMA `DOMA_PACK=1 NS="100000 1000000 10000000" HBMS="0 20 50 100"`. One table per configuration. DOMA's host gets opt-in `DOMA_PLACEMENT=1` and a check that the matched-budget sizes equal its buffers; `scan.sh` gets opt-in `SCAN_LOG=1`. DOMA's default output and CSV are unchanged (mock, 11 configurations). |
| 8. Differences to state | README §15, `merge_results.py` | GET/PUT-uniform padded DOMA vs unprotected Tiny ORAM (PUT data prefetch only); the on-chip position map in (b); DOMA's ~8 MB on-package at 0%. `comparison.md` opens with them. |
| Docs | README §15 and status line, runbook (scripts first; OOC first-line text), this file, the logs | |

## Fix after the bring-up's `ooc` failure (2026-10-18 evening)

| Item | File | Change |
|---|---|---|
| 1. The dead `DRAMInitializer.v` | `tinyoram/fetch_tinyoram.sh` | It and nine more dead files are left out of `build/src` (so out of `files.f` and the packager's glob): every file whose modules no other file names in any configuration, plus the `DRAM2RAM`/`SynthesizedDRAM` pair only those name. 72 → 62 sources; nothing the design uses changes (README §16). Replaces your local edit. |
| 2. A one-minute Vivado elaboration | `vitis/elab_tinyoram.tcl` (new), `vitis/build_tinyoram.sh`, `tinyoram/card/bringup_64.sh`, `tinyoram/card/queue.sh` | `synth_design -rtl` of `tinyoram_kernel` from exactly the files the builds read. It runs after every fetch in `build_tinyoram.sh` (`ELAB=0` skips it), before each out-of-context run in the bring-up, and before each queue entry (`FAILED_ELAB`). Last line `ELAB PASS` / `ELAB FAIL`. Untested here (no Vivado). |
| 3. Every file, not only what the top reaches | `sim/lint_tinyoram.sh` (new), `sim/run_tinyoram.sh`, `sim/run_tinyoram_mutants.sh` | Every module of every source file elaborated as its own top: it fails on undeclared or unbound names, unknown modules, port mismatches, syntax errors and unlisted implicit nets. 74 modules clean (3 with default-parameter-only notes). Mutant l2 (`DRAMInitializer.v` back) is caught. `AES_DW.v:146` is legal by the standard (a genvar is a 32-bit integer; 64 + 64 = 128 bits); Vivado's verdict comes from the elaboration step. |

## Fix after the 4 KB queue lint failure (2026-10-18 night)

| Item | File | Change |
|---|---|---|
| 3. The instance | README §17 | `u_tiny.front_end.uoram.PPP.PosMapInitCounter` (`PosMapPLB.v:93`), `CountAlarm #(.Threshold(FinalPosMapEntry))` with **Threshold = 0**: the on-chip final PosMap is empty. Only at 4 KB with L ≥ 12 (q6, q7), position map as published, both adapters. |
| 2. `CountAlarm` | `tinyoram/fetch_tinyoram.sh` | Not widened: that would build a PosMap with no entries. The cause is the depth: Tiny ORAM's rule "recursive until < 1024 entries" is written for 3 bits per level, i.e. 8 leaves per 64 B PosMap block, and a 4 KB block holds 512. The fetch writes the same rule with log2(ORAMB/64) bits per level through patch 07's `TINYORAM_RECURSION`, only where it differs. That gives depth 2 at 4 KB, L = 12 / 14 (final PosMap 32 / 128 entries). 64 B is unchanged at every L. The fetch stops if a final PosMap would fall outside 1..1024 entries. Vivado's verdict on `{0{x}}` is not relied on: the standard, Verilator and iverilog all reject it. |
| 1. Every queue geometry | `sim/run_tinyoram.sh` | A first stage fetches each `queue.txt` geometry into its own copy, as `queue.sh` does, and runs the full lint on it: 7 checks, about 2 minutes (`SIZES=""` runs only this stage). Then a q6 simulation (depth 2) with 32 keys, one per PosMap block, so the 2-block PLB keeps missing; packed records, split, gaps. |
| Checks | `sim/tb_tinyoram_kernel.v`, `sim/run_tinyoram_mutants.sh`, `docs/tinyoram_4k_geometry_sim_2026-10-18.txt` | `+keys=K` (opt-in: K keys N/K apart; the random streams are unchanged). Mutant l3, q6 with the published depth, is caught by the lint. q7 (L = 14, merged) and q6 with the 1:1 adapter were simulated by hand; both pass. |
| Robustness | `tinyoram/fetch_tinyoram.sh`, `vitis/elab_tinyoram.tcl`, `vitis/synth_ooc_tinyoram.tcl` | The fetch copies through a linked `upstream/` (`cp -rL`) instead of patching it in place. The flat-PosMap tag matches `RECURSION 1` only, not 2 or 3. |

## Run-time tree depth (2026-10-19)

You asked for one build at L_max that runs at any L ≤ L_max exactly like the native build of that L. README §18 has
the design, the checks and the card procedure.

| Item | File | Change |
|---|---|---|
| Core | `tinyoram/patches/08_runtime_depth.diff` (new) | `TINYORAM_RTDEPTH`: 17 core files take every depth-dependent constant from a geometry bus: path length, path chunk/burst counts, BlocksOnPath, StashCapacity, the scan table's levels, the subtree layout, N, the final PosMap's start and size, leaf width, and the dummy-leaf PRNG width (one PRNG per width, so the dummy stream is the native one). New: `rtdepth/TinyRTGeo.v` (a constant table over L = 0..31), `rtdepth/CountAlarmRT.v`, `include/RTGeo.vh`. Without the define the preprocessed core is unchanged (`sim/check_rtdepth_native.sh`, in the regression). |
| Fetch | `tinyoram/fetch_tinyoram.sh` | Option `rtdepth`: writes `TINYORAM_RTDEPTH 1`; L is L_max. Cannot be combined with `flatpm`. |
| Wrapper | `tinyoram/rtl/tinyoram_kernel.v`, `tinyoram/rtl/tinyoram_axi_adapter.v` | An init with `size = 0x8000_0000 \| L` selects L (applied with the core in reset; status 0x100 if outside 6..L_max). Summary bytes 1–3: active L, L_max, 6. The zero-fill, key check, top split, record [size+1] and the adapter's range check follow the active depth. In a native build the summary bytes stay 0 and everything else is the build's constants, as before. |
| Host | `vitis/host_doma.cpp` (shared, additive) | On a run-time-depth bitstream, the depth `DOMA_N` needs is selected by a second init; a `DOMA_N` above L_max stops with a message. Native bitstreams and DOMA are unaffected (mock: DOMA's output identical in three configurations; a native bitstream never gets a depth-selecting launch). `docs/tinyoram_fair_shared_files.diff` regenerated. |
| Build | `vitis/build_tinyoram.sh`, `synth_ooc_tinyoram.tcl`, `elab_tinyoram.tcl` | `RTDEPTH=1` (tag `_rt`); labels. |
| Queue | `tinyoram/card/queue.txt`, `queue.sh`, `sweep_tiny.sh`, `merge_results.py` | The PM column takes `rt`. New q8 `64_n10M_merge_rt` (L_max = 19) and q9 `4k_n64K_merge_rt` (L_max = 14). The sweep runs every N of `RT_NS` up to the entry's; the table compares run-time rows with native rows. |
| Card acceptance | `tinyoram/card/accept_rt.sh` (new) | N = 1M on q8 against q1, alternating, 5 reps at two settings. Pass: identical traffic per command, p50/p99 within 2%, KQPS within noise, same clock, all correct. Dry-run against the mock. |
| Checks | `sim/run_tinyoram_rteq.sh`, `sim/tb_rtgeo_probe.v` (new), `sim/tb_tinyoram_kernel.v`, `sim/run_tinyoram.sh` | The geometry table equals the native constants at 68 geometries. In every test pair the run-time build issues the same tree bursts on the same cycles, writes the same block bytes and gives the same per-launch lines as the native build; only the bucket headers' internal layout differs (L_max-wide leaf fields, same size). The 7 mutants of patch 08 are caught; 3 edits that should not show do not (`docs/tinyoram_rteq_2026-10-19.txt`). Testbench: `+rtl`, `+rtl2`, `+rtlbad`, `+axitrace` (bursts and a block-data hash), and an explicit failure above its 4,096 commands per launch. The regression lints q8/q9 and runs the native-identity check. |

## Acceptance

Run here on your 14:48 package with this overlay on it (the newest package was not attached):
* **DOMA:** `ORAM_BEATS=1 bash run_verilator.sh` and `bash run_verilator.sh` both `ALL CHECKS PASSED`, 37 checks
  each, with the same timing hashes: 32 B `fc899eb5aae696a2` / `c9fbaacc72ad716a`, 4 KB `05a12e803b18dc9f` /
  `e99b1b2a7b33c7bb` (`docs/doma_regression_rebase_2026-10-18.txt`). This includes the memory model's new
  `AW_DEPTH` parameter, which defaults to the old 16.
* **Tiny ORAM:**
  * `run_tinyoram.sh` 104/104: the 81 before, plus 4 lint, 8 slow-acknowledgement, 9 queue-geometry lint
    (q8/q9 run-time depth), 1 q6-geometry simulation and 1 native-identity (patch 08) checks.
  * `run_tinyoram_rteq.sh` 81/81: the geometry table, 67 pairs against native builds, 7 mutants caught,
    3 edits without observable effect, re-boot to another depth and 2 unsupported depths.
  * `run_tinyoram_mutants.sh` 22/22, adding l1, a4, a1 at 4 KB on both adapters, l2 and l3.
  * All three were run on 2026-10-19 with patch 08 in, the 64 fetched sources (62 + `TinyRTGeo.v` and
    `CountAlarmRT.v`). See `docs/tinyoram_regression_2026-10-18.txt`, `docs/tinyoram_mutants_2026-10-18.txt`
    and `docs/tinyoram_rteq_2026-10-19.txt`.
  * By hand: q7 (L = 14) and q6 with the 1:1 adapter (`docs/tinyoram_4k_geometry_sim_2026-10-18.txt`).
* **Scripts:** all dry-run here against stand-ins for XRT, Vivado and v++ (README §15). On the card they are
  untested, and the bring-up is what tests them.
* **On the newest package:** `install_tinyoram.sh <newest zip> <this zip> ~/tiny --check` does the same and must
  end with `INSTALL OK, ALL REGRESSIONS PASSED`.

## Files

Unzip over your 14:48 package (nothing is deleted), or better, use `tinyoram/card/install_tinyoram.sh`, which
works on any later base too.

New in this round: `tinyoram/card/` (`install_tinyoram.sh`, `bringup_64.sh`, `queue.sh`, `queue.txt`,
`sweep_tiny.sh`, `sweep_doma.sh`, `merge_results.py`), `docs/CHANGES_TINYORAM_CARD.md`, `docs/tinyoram_4k_geometry_sim_2026-10-18.txt`.

Changed in this round: `tinyoram/rtl/tinyoram_kernel.v` (traffic by port), `sim/tb_tinyoram_kernel.v`,
`sim/run_tinyoram.sh`, `sim/run_tinyoram_mutants.sh`, `vitis/host_doma.cpp`, `vitis/scan.sh`,
`sim/axi_mem_model.v` (shared: `AW_DEPTH`, default 16), `docs/README_TINYORAM.md` (§15),
`docs/TINYORAM_CARD_RUNBOOK.md`, `docs/CHANGES_TINYORAM_FAIR.md` (pointer), the logs,
`docs/tinyoram_fair_shared_files.diff` (now all three shared files), `MANIFEST.sha256`.

Carried from the previous rounds (also not in your package): everything in `CHANGES_TINYORAM_FAIR.md` and
`CHANGES_TINYORAM_AUDIT.md`.

Shared files, all by additions with defaults that leave DOMA unchanged: `vitis/host_doma.cpp`, `vitis/scan.sh`,
`sim/axi_mem_model.v` (patch: `docs/tinyoram_fair_shared_files.diff`). `check_timing.sh`, `worst_paths.tcl` and
everything of DOMA's are untouched.
