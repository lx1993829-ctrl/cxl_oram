# Card leakage tests (4 KB, λ = 7, arrival): runbook

Files added for these tests (nothing else in the package is changed):
- `vitis/host_leak.cpp`: a copy of `host_phases.cpp` with class pairs, scan phases and a per-command CSV.
- `sim/card_leak_analyze.py`: the analysis.
- This runbook.

The simulation part (`sim/leak_4k.sh`, `sim/leak_analyze.py`) is separate and already done.

## What the tests show

DOMA pads the position lookup and everything after a bucket's last beat, so a request's timing should depend only on
where its random bucket lives and how fast that memory answers. On the card, `host_leak` sends each pair of request
classes interleaved by an independent coin and records each command's timing:
- uniform vs. a fixed key;
- GET vs. PUT;
- uniform vs. re-requesting the previous key;
- random vs. all-zero PUT data;
- valid vs. rejected.

The analysis compares the classes within each bucket location. For each pair it reports:
- Welch's t and the KS distance;
- the smallest difference the test could have detected, in cycles;
- with the debug bitstream, deadline misses and the smallest on-package slack.

## 1. Bitstreams

Two bitstreams are needed. If you already built them from the v14c sources, reuse them; build each in its own folder.

| Run | Bitstream | Why |
|---|---|---|
| A (measured) | production arrival build with phase timestamps: `TARGET=hw LAMBDA=7 SCHED=arrival TRACE=1 NMAX=1048576 bash build.sh` | The timing results. `TRACE=1` only adds the header timestamps; the datapath is the untraced design. |
| B (supporting) | the v14c debug build: `TARGET=hw LAMBDA=7 SCHED=arrival TRACE=1 DEBUG=1 NMAX=1048576 bash build.sh` | Each access's exact location, whether its block was in the stash, deadline misses, slack. `build.sh` says not to measure with it, so its timing results are supporting evidence only. |

## 2. Build the host (in `vitis/`)

```bash
g++ -std=c++17 -O2 host_leak.cpp -I$XILINX_XRT/include -L$XILINX_XRT/lib -lxrt_coreutil -pthread -o host_leak
```

Run it from `vitis/`. It checks Z and λ against `../rtl` and refuses to run on a mismatch.

## 3. Run

The same command serves both bitstreams. It uses 1M records with 20% of the buckets in HBM, as in the paper, and
1M commands per class pair; each pair takes about 20 s, plus the preload.

```bash
PH=pair:uni/fixed:1000000,pair:get/put:1000000,pair:uni/rereq:1000000,pair:put/zero:1000000,pair:uni/bad:1000000,uni:1000000,scan:1000000

# Run A: production TRACE=1 bitstream
DOMA_LAMBDA=7 DOMA_N=1048576 DOMA_HBM_PCT=20 DOMA_PHASE_TRACE=1 DOMA_LEAK_CSV=leakA.csv DOMA_PHASES=$PH \
  ./host_leak <trace bitstream>.xclbin 65536 | tee leakA.log

# Run B: debug bitstream (adds the controller's own record of every access)
DOMA_LAMBDA=7 DOMA_N=1048576 DOMA_HBM_PCT=20 DOMA_PHASE_TRACE=1 DOMA_LEAK_CSV=leakB.csv DOMA_ONPKG_CSV=onpkgB.csv \
  DOMA_PHASES=$PH ./host_leak <debug bitstream>.xclbin 65536 | tee leakB.log
```

Each log must end with `ALL PHASES CORRECT`. Every rejected command is checked: it must come back rejected (0x11, status 0x4).

Optional settings:
- `DOMA_LEAK_SEED=<n>` changes the class coin.
- A second run with another seed is the replication for any flagged row.

## 4. Analyse

On any machine with Python 3, numpy and scipy:

```bash
python3 card_leak_analyze.py leakA.csv --out summaryA.json | tee analysisA.txt
python3 card_leak_analyze.py leakB.csv onpkgB.csv --out summaryB.json | tee analysisB.txt
```

**Run A, location split.** Without the debug CSV, each access's location comes from `dend`, the time from the
bucket's last beat to the result. Padding fixes `dend` to one value per location, and the value whose accesses read
their bucket faster is taken as on package. In Run B the analysis prints how often this split agrees with the debug
records. If they ever disagree, rerun A with an explicit `--split <cycles>`.

**What is judged.** For an off-package access, every quantity is judged, because its bucket traffic crosses PCIe.
For an on-package access only `lat` (request to result) is judged; its bucket traffic stays on the HBM port inside
the package, which the threat model treats as unobservable. The on-package write-back time depends on the stash by
design (the plaintext path streams it behind the eviction copies). That shows up in the "internal timing" section as
information, never as a failure. The lag rows check that this internal timing does not reach the next access's
visible timing.

**Pass.** The analysis ends with `NO LEAK FOUND`, which means:
- no class comparison has |t| > 4.5, or a p-value rejected by Holm at 0.01;
- with Run B, also 0 deadline (1) and deadline (2) misses.

The "segments" block (uni vs. scan phases) is not interleaved, so drift can separate them. It is reported, not judged.

**If a row is flagged:**
1. Rerun with another `DOMA_LEAK_SEED`.
2. A flag that does not repeat is a false alarm under the multiple-comparison budget.
3. A flag that repeats is a finding. Send the logs.

## 5. Send back

- `leakA.log`, `analysisA.txt`, `summaryA.json`
- `leakB.log`, `analysisB.txt`, `summaryB.json`
- the CSVs, if they are small enough to transfer (otherwise the summaries are enough)
- the achieved clock of both bitstreams
