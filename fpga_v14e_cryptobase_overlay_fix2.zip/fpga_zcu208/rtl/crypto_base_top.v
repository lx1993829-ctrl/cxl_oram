`timescale 1ns / 1ps
// crypto_base_top.v -- the crypto, non-oblivious baseline core (ORAM_CRYPTO_BASE, build.sh BASELINE=crypto); see the
// comment block after the port list. Ports: plain_oram_top's (secure_oram_top's).
`include "oram_params.vh"

module crypto_base_top #(
    parameter UNIFORM_FILL = 0,   // 1: GETs take the write-data fill too (data ignored), so GET and PUT start alike
    parameter N            = `ORAM_N,
    parameter Z            = `ORAM_Z,
    parameter B            = `ORAM_B,
    parameter STASH_DEPTH  = `ORAM_STASH_DEPTH,
    parameter AXI_DW       = `AXI_DATA_W,
    parameter AXI_AW       = `AXI_ADDR_W,
    parameter AXI_SW       = `AXI_STRB_W,
    parameter AXI_IDW      = `AXI_ID_W,
    parameter AXI_LENW     = `AXI_LEN_W,
    parameter NUM_CLIENTS    = `ORAM_NUM_CLIENTS,
    parameter TDM_CID_W      = (NUM_CLIENTS > 1) ? $clog2(NUM_CLIENTS) : 1,
    parameter NUM_REGIONS    = 16,
    parameter TOKEN_WIDTH    = 32,
    parameter LEASE_ID_WIDTH = 8,
    parameter SLOT_AW        = `SLOT_ADDR_W
)(
    input  wire                 clk,
    input  wire                 rst_n,

    // Management Interface
    input  wire                                   mgmt_req,
    input  wire [2:0]                             mgmt_op,
    input  wire [LEASE_ID_WIDTH-1:0]              mgmt_lease_id,
    input  wire [TDM_CID_W-1:0]                   mgmt_client_id,
    input  wire [SLOT_AW-1:0]                     mgmt_base_addr,   // slot addresses (slot << 12)
    input  wire [SLOT_AW-1:0]                     mgmt_size,
    input  wire [31:0]                            mgmt_duration,
    input  wire [TOKEN_WIDTH-1:0]                 mgmt_token_in,
    output wire                                   mgmt_ack,
    output wire                                   mgmt_error,
    output wire [TOKEN_WIDTH-1:0]                 mgmt_token_out,
    output wire [NUM_CLIENTS*TOKEN_WIDTH-1:0]     client_token_out,
    output wire [63:0]                            dbg_halt_info,

    // Client Interface (flattened)
    input  wire [NUM_CLIENTS-1:0]                     client_req,
    input  wire [NUM_CLIENTS-1:0]                     client_op,
    input  wire [NUM_CLIENTS*SLOT_AW-1:0]             client_slot_addr,
    input  wire [NUM_CLIENTS*AXI_DW-1:0]              client_wdata,
    input  wire [NUM_CLIENTS*AXI_DW/8-1:0]            client_wstrb,   // byte strobes per write beat (all ones = whole block)
    input  wire [NUM_CLIENTS-1:0]                     client_wdata_valid,
    input  wire [NUM_CLIENTS*TOKEN_WIDTH-1:0]         client_token,
    input  wire [NUM_CLIENTS*LEASE_ID_WIDTH-1:0]      client_lease_id,
    output wire [NUM_CLIENTS-1:0]                     client_done,
    output wire [NUM_CLIENTS*AXI_DW-1:0]              client_rdata,
    output wire [NUM_CLIENTS-1:0]                     client_rdata_valid,
    output wire [NUM_CLIENTS-1:0]                     access_violation,
    output wire [NUM_CLIENTS-1:0]     client_lockout,   // F10: client locked after repeated violations
    input  wire                       key_load,         // F1: latch aes_key/aes_iv_seed (once per boot)
    output wire                       key_ready,        // F1: a key is loaded; accesses are accepted
    output wire                       err_ct_overrun,   // Phase 2: sticky timing-gate overrun (fail-stop)
    output wire                       oram_ready,       // Phase 2: key loaded and DDR formatted
    // Phase 3: static time-division arbiter. Configuration latched ONCE, on the
    // first cycle after reset (boot-time); slots start when oram_ready rises.
    input  wire [15:0]                cfg_tdm_slot_cycles, // access window length (0 = `ORAM_TDM_SLOT)
    output wire [NUM_CLIENTS*`BEAT_CNT_W-1:0] client_wbeat_req, // write beat each client should present
    output wire [NUM_CLIENTS-1:0]     client_ready,        // client may issue a request
    output wire                       err_slot_overrun,    // sticky: controller busy at a slot start
    output wire                       dbg_slot_start,      // debug builds only (0 otherwise)
    output wire [31:0]                dbg_real_cnt,

    // BRAM Init Interface
    input  wire                                       init_mode,
    input  wire [SLOT_AW-1:0]                         init_pm_wr_addr,
    input  wire [`BUCKET_ID_W-1:0]                    init_pm_wr_bucket,
    input  wire [1:0]                                 init_pm_wr_status,
    input  wire                                       init_pm_wr_en,
    input  wire [`BUCKET_ID_W-1:0]                    init_bm_wr_bucket,
    input  wire [Z*`SLOT_ID_W-1:0]                    init_bm_wr_slot_list,
    input  wire [`FILL_CNT_W-1:0]                     init_bm_wr_fill,
    input  wire                                       init_bm_wr_en,

    // AES-GCM Configuration
    input  wire [127:0]                               aes_key,
    input  wire [95:0]                                aes_iv_seed,
    input  wire [`SLOT_ID_W:0]                        cfg_n,            // run-time blocks (0: the build's maximum)
    input  wire [`BUCKET_ID_W:0]                      cfg_hbm_bkts,     // buckets 0 .. cfg_hbm_bkts-1 in HBM
    input  wire [`SLOT_ID_W:0]                        cfg_pool_n,       // stash pool entries (0: N)

    // AXI Master -> DDR
    output wire [AXI_IDW-1:0]   m_axi_arid,
    output wire [AXI_AW-1:0]    m_axi_araddr,
    output wire [AXI_LENW-1:0]  m_axi_arlen,
    output wire [2:0]            m_axi_arsize,
    output wire [1:0]            m_axi_arburst,
    output wire                  m_axi_arvalid,
    input  wire                  m_axi_arready,
    input  wire [AXI_IDW-1:0]   m_axi_rid,
    input  wire [AXI_DW-1:0]    m_axi_rdata,
    input  wire [1:0]            m_axi_rresp,
    input  wire                  m_axi_rlast,
    input  wire                  m_axi_rvalid,
    output wire                  m_axi_rready,
    output wire [AXI_IDW-1:0]   m_axi_awid,
    output wire [AXI_AW-1:0]    m_axi_awaddr,
    output wire [AXI_LENW-1:0]  m_axi_awlen,
    output wire [2:0]            m_axi_awsize,
    output wire [1:0]            m_axi_awburst,
    output wire                  m_axi_awvalid,
    input  wire                  m_axi_awready,
    output wire [AXI_DW-1:0]    m_axi_wdata,
    output wire [AXI_SW-1:0]    m_axi_wstrb,
    output wire                  m_axi_wlast,
    output wire                  m_axi_wvalid,
    input  wire                  m_axi_wready,
    input  wire [AXI_IDW-1:0]   m_axi_bid,
    input  wire [1:0]            m_axi_bresp,
    input  wire                  m_axi_bvalid,
    output wire                  m_axi_bready,
    // position map in HBM: addresses relative to the metadata buffer (the kernel adds its base)
    output wire [63:0]           m_meta_araddr,
    output wire [7:0]            m_meta_arlen,
    output wire [2:0]            m_meta_arsize,
    output wire [1:0]            m_meta_arburst,
    output wire                  m_meta_arvalid,
    input  wire                  m_meta_arready,
    input  wire [AXI_DW-1:0]     m_meta_rdata,
    input  wire                  m_meta_rlast,
    input  wire                  m_meta_rvalid,
    output wire                  m_meta_rready,
    output wire [63:0]           m_meta_awaddr,
    output wire [7:0]            m_meta_awlen,
    output wire [2:0]            m_meta_awsize,
    output wire [1:0]            m_meta_awburst,
    output wire                  m_meta_awvalid,
    input  wire                  m_meta_awready,
    output wire [AXI_DW-1:0]     m_meta_wdata,
    output wire [AXI_DW/8-1:0]   m_meta_wstrb,
    output wire                  m_meta_wlast,
    output wire                  m_meta_wvalid,
    input  wire                  m_meta_wready,
    input  wire                  m_meta_bvalid,
    output wire                  m_meta_bready,
    // bucket records in HBM (metadata + IV/tag), addresses relative to their buffer
    output wire [63:0]                 m_brec_araddr,
    output wire [7:0]                  m_brec_arlen,
    output wire [2:0]                  m_brec_arsize,
    output wire [1:0]                  m_brec_arburst,
    output wire                        m_brec_arvalid,
    input  wire                        m_brec_arready,
    input  wire [AXI_DW-1:0]           m_brec_rdata,
    input  wire                        m_brec_rlast,
    input  wire                        m_brec_rvalid,
    output wire                        m_brec_rready,
    output wire [63:0]                 m_brec_awaddr,
    output wire [7:0]                  m_brec_awlen,
    output wire [2:0]                  m_brec_awsize,
    output wire [1:0]                  m_brec_awburst,
    output wire                        m_brec_awvalid,
    input  wire                        m_brec_awready,
    output wire [AXI_DW-1:0]           m_brec_wdata,
    output wire [AXI_DW/8-1:0]         m_brec_wstrb,
    output wire                        m_brec_wlast,
    output wire                        m_brec_wvalid,
    input  wire                        m_brec_wready,
    input  wire                        m_brec_bvalid,
    output wire                        m_brec_bready,
    output wire [63:0]                 m_stash_araddr,
    output wire [7:0]                  m_stash_arlen,
    output wire [2:0]                  m_stash_arsize,
    output wire [1:0]                  m_stash_arburst,
    output wire                        m_stash_arvalid,
    input  wire                        m_stash_arready,
    input  wire [AXI_DW-1:0]           m_stash_rdata,
    input  wire                        m_stash_rlast,
    input  wire                        m_stash_rvalid,
    output wire                        m_stash_rready,
    output wire [63:0]                 m_stash_awaddr,
    output wire [7:0]                  m_stash_awlen,
    output wire [2:0]                  m_stash_awsize,
    output wire [1:0]                  m_stash_awburst,
    output wire                        m_stash_awvalid,
    input  wire                        m_stash_awready,
    output wire [AXI_DW-1:0]           m_stash_wdata,
    output wire [AXI_DW/8-1:0]         m_stash_wstrb,
    output wire                        m_stash_wlast,
    output wire                        m_stash_wvalid,
    input  wire                        m_stash_wready,
    input  wire                        m_stash_bvalid,
    output wire                        m_stash_bready,
    output wire [4:0] dbg_oram_state,
    // Status
    output wire                  oram_busy,
    output wire                  err_stash_overflow,
    output wire                  err_bucket_overflow,
    output wire                  err_tag_mismatch,
    output wire [`BEAT_CNT_W-1:0]  oram_beat_cnt,
    output wire dbg_gcm_tag_match,
    output wire dbg_gcm_tag_valid,

    // Test controls
    input  wire dbg_force_same_bucket,
    input  wire [`BUCKET_ID_W-1:0] dbg_prng_override,
    input  wire perf_reset,

    // Performance counters - 4-way: rb=read/bucket, rs=read/stash, wb=write/bucket, ws=write/stash
    output wire [31:0] perf_rb_ddr_rd, perf_rb_decrypt, perf_rb_encrypt,
    output wire [31:0] perf_rb_compact, perf_rb_evict, perf_rb_ddr_wr,
    output wire [31:0] perf_rb_scan, perf_rb_stash,
    output wire [31:0] perf_rb_total, perf_rb_ops,
    output wire [31:0] perf_rs_ddr_rd, perf_rs_decrypt, perf_rs_encrypt,
    output wire [31:0] perf_rs_compact, perf_rs_evict, perf_rs_ddr_wr,
    output wire [31:0] perf_rs_scan, perf_rs_stash,
    output wire [31:0] perf_rs_total, perf_rs_ops,
    output wire [31:0] perf_wb_ddr_rd, perf_wb_decrypt, perf_wb_encrypt,
    output wire [31:0] perf_wb_compact, perf_wb_evict, perf_wb_ddr_wr,
    output wire [31:0] perf_wb_scan, perf_wb_stash,
    output wire [31:0] perf_wb_total, perf_wb_ops,
    output wire [31:0] perf_ws_ddr_rd, perf_ws_decrypt, perf_ws_encrypt,
    output wire [31:0] perf_ws_compact, perf_ws_evict, perf_ws_ddr_wr,
`ifdef ORAM_PHASE_TRACE
    output wire [10:0] phase_ent,           // build option: the core's phase-entry pulses
`endif
    output wire [31:0] perf_ws_scan, perf_ws_stash,
    output wire [31:0] perf_ws_total, perf_ws_ops
);

// crypto_base_top -- the crypto, non-oblivious baseline (build option ORAM_CRYPTO_BASE, build.sh BASELINE=crypto), with
// secure_oram_top's ports, to measure the cost of obliviousness alone (docs/v14e_crypto_baseline.md). Against DOMA it
// has no stash, no position map, no random buckets and no timing padding; it keeps everything else:
//   Placement: record k is block k at a fixed place. Blocks 0 .. K_ON-1 are on package (HBM), the rest in host memory,
//     K_ON = cfg_hbm_bkts x lambda: the same share of blocks as DOMA's cfg_hbm_bkts of its n / lambda buckets. Block k
//     sits at bucket-port address k x BLOCK on package and (k + cfg_hbm_bkts x (Z - lambda)) x BLOCK off package, so
//     doma_kernel's fixed boundary (cfg_hbm_bkts x Z x BLOCK) routes it, and the host's buffers (sized for DOMA) hold it.
//   Crypto as DOMA v14c treats memory: off-package blocks in AES-GCM (DOMA's aes_gcm_2lane, unchanged: two lanes, one
//     beat per cycle), on-package blocks in plaintext. One GCM message per block (DOMA: one per bucket). The IV is
//     DOMA's: every encryption takes the engine's next IV (its 96-bit LFSR, seeded with aes_iv_seed, never repeating
//     within a boot), and the IV used is stored with the tag, as DOMA stores each bucket's.
//   Integrity with replay protection, as DOMA's: per block a 32-byte record {version (32 bits), IV (96), tag (128)} on
//     package (the stash buffer, at k x 32), rewritten on every write with the new IV and tag and the version advanced.
//     A GET's plaintext is released only after its tag checks under the stored IV; a tampered, swapped or replayed
//     block fails the check and halts (err_tag_mismatch, summary 0x208), as DOMA. Version 0: never written, zeros.
//   Requests: one at a time, each done as soon as its own transfer and crypto are: a GET reads its block (and, off
//     package, its record, in parallel), decrypts and checks it, returns it; a PUT writes its block (off package: its
//     record read for the version, the encryption, the block and the new record written; done when both are handed
//     off, as DOMA in arrival mode). Reads start with the request, while the kernel streams the command's data slot
//     in; a whole-block PUT encrypts (off package) or writes (on package) its beats as they stream in, and a GET on
//     package returns its beats as they land. A packed PUT (a length, some byte strobes off) off package reads its
//     block with the request, checks and decrypts it, merges (read-modify-write); on package the byte strobes merge
//     it in memory.
//     A read waits until every earlier write on its port is acknowledged (the ordering DOMA's axi_master keeps).
//   Boot (key_load): the stash buffer is checked to hold n records (else a stash-overflow halt, 0x408: run the host
//     with a larger DOMA_POOL), every record is zeroed and the on-package blocks are zeroed; then oram_ready.
    localparam integer BEATS  = `BEATS_PER_BLOCK;
    localparam integer BLK_LG = $clog2(BEATS) + 5;               // log2 of the block size in bytes
    localparam integer BI_W   = (BEATS > 1) ? $clog2(BEATS) : 1;  // beat index
    localparam integer CNT_W  = $clog2(BEATS) + 1;               // beat count 0 .. BEATS
    localparam integer KW     = `SLOT_ID_W + 1;                  // block index / count (0 .. N)
    localparam integer LAM    = `ORAM_C;
    localparam [AXI_LENW-1:0] BLEN = BEATS - 1;
    // ---------------- configuration, latched at key_load ----------------
    reg  [KW-1:0]       n_q, kon_q;                               // blocks; blocks on package
    reg  [KW+3:0]       hoff_q;                                   // cfg_hbm_bkts x (Z - lambda): off-package address offset
    reg  [127:0]        key_q;
    reg  [95:0]         ivs_q;                                    // aes_iv_seed: the engine's first encryption seeds its IV
    // ---------------- state ----------------
    localparam [3:0] S_OFF = 4'd0, S_CHK = 4'd1, S_ZM = 4'd2, S_ZD = 4'd3, S_ZW = 4'd4, S_IDLE = 4'd5, S_RUN = 4'd6,
                     S_DONE = 4'd7, S_HALT = 4'd8;
    reg  [3:0]  st;
    reg         key_q_v, err_tag_r, err_cap_r, done_q, ack_q;
    reg         op;                                               // 1 = PUT
    reg  [KW-1:0] k;                                              // the block
    reg         on;                                               // on package
    reg  [15:0] wr_out, mw_out;                                   // writes not yet acknowledged: bucket port, record port
    wire        aw_hs  = m_axi_awvalid && m_axi_awready;
    wire        w_hs   = m_axi_wvalid && m_axi_wready;
    wire        mw_aw  = m_stash_awvalid && m_stash_awready;
    wire        mw_w   = m_stash_wvalid && m_stash_wready;
    // buffers: the command's data slot and strobes, the bucket-port beats (read, or ciphertext to write), the plaintext
    reg  [AXI_DW-1:0]   dbuf [0:BEATS-1];
    reg  [AXI_DW/8-1:0] sbuf [0:BEATS-1];
    reg  [AXI_DW-1:0]   xbuf [0:BEATS-1];
    reg  [AXI_DW-1:0]   pbuf [0:BEATS-1];
    // per-request progress
    reg  [CNT_W-1:0] fcnt, rcnt, gin, gout, wcnt, rel;            // fill, read beats in, GCM beats in / out, W beats, released
    reg         whole;                                            // a whole-block PUT (the kernel says so with the request:
                                                                  // client_lease_id[0], a PUT of length 0)
    reg         m_req, m_ar, m_done;                              // the record read: wanted, address sent, landed
    reg         d_req, d_ar;                                      // the block read: wanted, address sent (rcnt counts its beats)
    reg  [127:0] tag_q;  reg [95:0] iv_q;  reg [31:0] ver_q;      // the record
    localparam [2:0] PH_WAIT = 3'd0, PH_DEC = 3'd1, PH_OLD = 3'd2, PH_ENC = 3'd3, PH_ENCD = 3'd4;
    reg  [2:0]  ph;                                               // crypto phase: waiting, decrypting, old plaintext
                                                                  // ready (GET: release), encrypting, encrypted
    reg         g_dec;                                            // the running message is a decryption
    reg         p_valid;                                          // pbuf holds the old plaintext (else zeros: version 0)
    reg         w_aw, w_on;                                       // block write: address sent, writing
    reg         mw_pend, mw_aw_s, mw_on;                          // record write: wanted, address sent, data beat out
    reg  [127:0] tag_new;  reg [95:0] iv_new;
    reg         rel_on;
    // boot writes
    reg  [KW+7:0] bz_cnt, bz_end;                                 // beats written / to write (records, then on-package beats)
    reg  [AXI_AW-1:0] bz_addr;
    reg  [7:0]  bz_left;                                          // beats left in the current burst
    reg         bz_aw;                                            // the burst's address is out
    // ---------------- GCM (DOMA's engine; decryption takes the stored IV, encryption the engine's next one) ----------------
    wire         gcm_ready, gcm_busy, gcm_in_rdy, gcm_ov_v, gcm_ov_last, gcm_tag_v, gcm_tag_m, gcm_ivu, gcm_ctr_ov;
    wire [255:0] gcm_ov;
    wire [1:0]   gcm_ov_m;
    wire [127:0] gcm_tag_o;
    wire [95:0]  gcm_iv_o;
    reg          g_start, g_enc;
    reg  [31:0]  g_ver;
    wire [BI_W-1:0] gi = gin[BI_W-1:0];
    // the beat fed to GCM: decryption, the block as read; encryption, the command's bytes over the old plaintext
    wire [AXI_DW-1:0] old_b = p_valid ? pbuf[gi] : {AXI_DW{1'b0}};
    wire [AXI_DW-1:0] new_b;
    genvar gb;
    generate for (gb = 0; gb < AXI_DW/8; gb = gb + 1) begin : g_merge
        assign new_b[8*gb +: 8] = sbuf[gi][gb] ? dbuf[gi][8*gb +: 8] : old_b[8*gb +: 8];
    end endgenerate
    wire         g_on   = (ph == PH_DEC) || (ph == PH_ENC);
    wire         g_feed = g_on && gcm_in_rdy && (gin < BEATS) && (g_dec ? (gin < rcnt) : (gin < fcnt));   // (encryption: as the slot streams in)
    aes_gcm_2lane u_gcm (
        .clk(clk), .rst_n(rst_n), .enable(1'b1),
        .start(g_start), .encrypt(g_enc), .key(key_q), .iv(g_dec ? iv_q : ivs_q), .iv_advance(1'b0),
        .data_in(g_dec ? xbuf[gi] : new_b), .data_mask(2'b11), .data_valid(g_feed), .data_last(g_feed && (gin == BEATS - 1)),
        .data_out(gcm_ov), .data_out_mask(gcm_ov_m), .data_out_valid(gcm_ov_v), .data_out_last(gcm_ov_last),
        .tag_in(tag_q), .tag_out(gcm_tag_o), .tag_valid(gcm_tag_v), .tag_match(gcm_tag_m),
        .ready(gcm_ready), .busy(gcm_busy), .input_ready(gcm_in_rdy),
        .iv_out(gcm_iv_o), .iv_updated(gcm_ivu), .counter_overflow(gcm_ctr_ov));
    // ---------------- addresses ----------------
    reg  [AXI_AW-1:0] blk_addr;                                   // the block's bucket-port address (set with the request)
    wire [KW-1:0]     kc = client_slot_addr[KW+11:12];
    wire [63:0]       rec_addr = {{(64-KW){1'b0}}, k} << 5;
    // the stash buffer must hold n records: roundup4k(NB x 64) + roundup4k(pool x 16) + pool x BLOCK >= 32 n (host_doma's
    // sizes). Checked conservatively, without a division: lambda x (pool x (16 + BLOCK)) + 64 (n - lambda) >= lambda x 32 n.
    reg  [KW+20:0] cap_p, cap_l, cap_r;                            // (pipelined: settled before S_CHK compares them)
    always @(posedge clk) begin
        cap_p <= {{21{1'b0}}, cfg_pool_n} * (16 + (1 << BLK_LG));
        cap_l <= LAM * cap_p + (({{21{1'b0}}, cfg_n} > LAM) ? 64 * ({{21{1'b0}}, cfg_n} - LAM) : 0);
        cap_r <= LAM * 32 * {{21{1'b0}}, cfg_n};
    end
    reg [2:0] chk_cnt;
    wire [KW+7:0] kon_c  = {{(KW+7-`BUCKET_ID_W){1'b0}}, cfg_hbm_bkts} * LAM;    // blocks on package: lambda per HBM bucket
    wire [KW+3:0] hoff_c = {{(KW+3-`BUCKET_ID_W){1'b0}}, cfg_hbm_bkts} * (Z - LAM);
    // ---------------- buffers ----------------
    wire fill_v = client_wdata_valid[0] && (st == S_RUN) && (fcnt < BEATS);
    // xbuf has one write port (distributed RAM): the block's read beats and the ciphertext never land in the same
    // access phase (a read-modify-write's read is checked before its encryption starts)
    wire x_rd = (st == S_RUN) && m_axi_rvalid && m_axi_rready;
    always @(posedge clk) begin
        if (fill_v) begin dbuf[fcnt[BI_W-1:0]] <= client_wdata[AXI_DW-1:0]; sbuf[fcnt[BI_W-1:0]] <= client_wstrb[AXI_DW/8-1:0]; end
        if (x_rd || (gcm_ov_v && !g_dec)) xbuf[x_rd ? rcnt[BI_W-1:0] : gout[BI_W-1:0]] <= x_rd ? m_axi_rdata : gcm_ov;   // read beats / ciphertext
        if (gcm_ov_v && g_dec) pbuf[gout[BI_W-1:0]] <= gcm_ov;                      // plaintext (released after the tag)
    end
    // ---------------- control ----------------
    wire rd_last = m_axi_rvalid && m_axi_rready && m_axi_rlast;
    wire fill_done = (fcnt == BEATS);
    wire rd_done   = (rcnt == BEATS);
    wire put_ok_w  = w_on && w_hs && (wcnt == BEATS - 1);         // the block's last W beat handed off
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st <= S_OFF; key_q_v <= 1'b0; err_tag_r <= 1'b0; err_cap_r <= 1'b0; done_q <= 1'b0; ack_q <= 1'b0;
            op <= 1'b0; k <= 0; on <= 1'b0; blk_addr <= 0; wr_out <= 0; mw_out <= 0; n_q <= 0; kon_q <= 0; hoff_q <= 0; key_q <= 0; ivs_q <= 0; iv_q <= 0; iv_new <= 0;
            fcnt <= 0; rcnt <= 0; gin <= 0; gout <= 0; wcnt <= 0; rel <= 0; whole <= 1'b1;
            m_req <= 1'b0; m_ar <= 1'b0; m_done <= 1'b0; d_req <= 1'b0; d_ar <= 1'b0; tag_q <= 0; ver_q <= 0;
            ph <= PH_WAIT; g_dec <= 1'b0; p_valid <= 1'b0; w_aw <= 1'b0; w_on <= 1'b0;
            mw_pend <= 1'b0; mw_aw_s <= 1'b0; mw_on <= 1'b0; tag_new <= 0; rel_on <= 1'b0; g_start <= 1'b0; g_enc <= 1'b0; g_ver <= 0;
            bz_cnt <= 0; bz_end <= 0; bz_addr <= 0; bz_left <= 0; bz_aw <= 1'b0; chk_cnt <= 0;
        end else begin
            ack_q <= mgmt_req; done_q <= 1'b0; g_start <= 1'b0;
            wr_out <= wr_out + (aw_hs ? 16'd1 : 16'd0) - (m_axi_bvalid ? 16'd1 : 16'd0);
            mw_out <= mw_out + (mw_aw ? 16'd1 : 16'd0) - (m_stash_bvalid ? 16'd1 : 16'd0);
            case (st)
                // ---- boot
                S_OFF: if (key_load) begin
                    key_q <= aes_key; ivs_q <= aes_iv_seed; key_q_v <= 1'b1;
                    n_q <= cfg_n;
                    kon_q <= (kon_c > {8'd0, cfg_n}) ? cfg_n : kon_c[KW-1:0];
                    hoff_q <= hoff_c;
                    chk_cnt <= 0; st <= S_CHK;
                end
                S_CHK: if (chk_cnt != 3'd5) chk_cnt <= chk_cnt + 3'd1;          // the size products settle
                       else if (cap_l < cap_r) begin err_cap_r <= 1'b1; st <= S_HALT; end
                       else begin bz_cnt <= 0; bz_end <= {8'd0, n_q}; bz_addr <= 0; bz_left <= 0; bz_aw <= 1'b0; st <= S_ZM; end
                S_ZM, S_ZD: begin                                             // zero the records, then the on-package blocks
                    if (!bz_aw && bz_left == 0) begin
                        if (bz_cnt == bz_end) begin
                            if (st == S_ZM) begin bz_cnt <= 0; bz_end <= {8'd0, kon_q} << (BLK_LG - 5); bz_addr <= 0; st <= S_ZD; end
                            else st <= S_ZW;
                        end else bz_aw <= 1'b1;
                    end
                    if (bz_aw && (st == S_ZM ? m_stash_awready : m_axi_awready)) begin
                        bz_aw <= 1'b0;
                        bz_left <= ((bz_end - bz_cnt) > 128) ? 8'd128 : (bz_end - bz_cnt);
                    end
                    if (bz_left != 0 && (st == S_ZM ? m_stash_wready : m_axi_wready)) begin
                        bz_left <= bz_left - 8'd1; bz_cnt <= bz_cnt + 1'b1; bz_addr <= bz_addr + 32;
                    end
                end
                S_ZW: if (wr_out == 0 && mw_out == 0 && !aw_hs && !mw_aw) st <= S_IDLE;
                // ---- requests
                S_IDLE: if (client_req[0]) begin
                    op <= client_op[0]; k <= kc; on <= (kc < kon_q);
                    blk_addr <= (kc < kon_q) ? ({{(AXI_AW-KW){1'b0}}, kc} << BLK_LG)
                                             : (({{(AXI_AW-KW){1'b0}}, kc} + {{(AXI_AW-KW-4){1'b0}}, hoff_q}) << BLK_LG);
                    fcnt <= 0; rcnt <= 0; gin <= 0; gout <= 0; wcnt <= 0; rel <= 0; whole <= client_op[0] && client_lease_id[0];
                    m_req <= (kc >= kon_q); m_ar <= 1'b0; m_done <= 1'b0;
                    // a GET reads its block at once; so does a packed PUT off package (read-modify-write)
                    d_req <= !client_op[0] || (!(client_op[0] && client_lease_id[0]) && kc >= kon_q); d_ar <= 1'b0;
                    ph <= PH_WAIT; p_valid <= 1'b0; w_aw <= 1'b0; w_on <= 1'b0;
                    mw_pend <= 1'b0; mw_aw_s <= 1'b0; mw_on <= 1'b0; rel_on <= 1'b0;
                    st <= S_RUN;
                end
                S_RUN: begin
                    // the data slot
                    if (fill_v) fcnt <= fcnt + 1'b1;
                    // the record read (off package)
                    if (m_req && !m_ar && mw_out == 0 && m_stash_arready) m_ar <= 1'b1;
                    if (m_ar && !m_done && m_stash_rvalid) begin
                        tag_q <= m_stash_rdata[127:0]; iv_q <= m_stash_rdata[223:128]; ver_q <= m_stash_rdata[255:224]; m_done <= 1'b1;
                    end
                    // the block read
                    if (d_req && !d_ar && wr_out == 0 && m_axi_arready) d_ar <= 1'b1;
                    if (m_axi_rvalid && m_axi_rready) rcnt <= rcnt + 1'b1;
                    // GCM (off package), once the record is in: a GET decrypts and checks its block (version 0: zeros, no
                    // crypto); a PUT, once its slot is in, decrypts and checks the old block when some strobes are off
                    // (read-modify-write; version 0: zeros), then encrypts the merged block with the next version
                    if (ph == PH_WAIT && !on && m_done) begin
                        if (ver_q != 0 && (!op || !whole)) begin
                            g_start <= 1'b1; g_enc <= 1'b0; g_dec <= 1'b1; g_ver <= ver_q; gin <= 0; gout <= 0; ph <= PH_DEC;
                        end else begin p_valid <= 1'b0; ph <= PH_OLD; end
                    end
                    if (g_feed) gin <= gin + 1'b1;
                    if (gcm_ov_v) gout <= gout + 1'b1;
                    if (gcm_tag_v && ph == PH_DEC) begin
                        p_valid <= 1'b1; ph <= PH_OLD;
                        if (!gcm_tag_m) begin err_tag_r <= 1'b1; st <= S_HALT; end
                    end
                    if (gcm_tag_v && ph == PH_ENC) begin tag_new <= gcm_tag_o; iv_new <= gcm_iv_o; mw_pend <= 1'b1; ph <= PH_ENCD; end
                    if (ph == PH_OLD && op && !on && (!d_req || rd_done)) begin   // encrypt (the old block, if read, checked)
                        g_start <= 1'b1; g_enc <= 1'b1; g_dec <= 1'b0; g_ver <= ver_q + 32'd1; gin <= 0; gout <= 0;
                        ph <= PH_ENC; w_aw <= 1'b1;
                    end
                    // a PUT on package: its bytes, with their strobes, once the slot is in
                    if (op && on && !w_aw && !w_on && wcnt == 0) w_aw <= 1'b1;   // its bytes go out as the slot streams in
                    if (w_aw && aw_hs) begin w_aw <= 1'b0; w_on <= 1'b1; end
                    if (w_hs) begin wcnt <= wcnt + 1'b1; if (wcnt == BEATS - 1) w_on <= 1'b0; end
                    // the new record
                    if (mw_pend && !mw_aw_s && m_stash_awready) begin mw_aw_s <= 1'b1; mw_on <= 1'b1; mw_pend <= 1'b0; end
                    if (mw_on && m_stash_wready) mw_on <= 1'b0;
                    // GET: release the block (on package as it lands, off package once its tag checked)
                    if (!op && (on || (ph == PH_OLD && rd_done))) rel_on <= 1'b1;
                    if (client_rdata_valid[0]) rel <= rel + 1'b1;
                    // done
                    // (done only after the data slot is in: the kernel looks for client_done once it has streamed it)
                    if (fill_done && !op && rel == BEATS && (on || rd_done)) st <= S_DONE;
                    if (fill_done && op && on && wcnt == BEATS) st <= S_DONE;
                    if (fill_done && op && !on && wcnt == BEATS && ph == PH_ENCD && mw_aw_s && !mw_on && !mw_pend) st <= S_DONE;
                end
                S_DONE: begin done_q <= 1'b1; st <= S_IDLE; end
                S_HALT: ;                                                       // fail-stop
                default: st <= S_IDLE;
            endcase
        end
    end
    // ---------------- outputs ----------------
    assign mgmt_ack = ack_q; assign mgmt_error = 1'b0; assign mgmt_token_out = 0;
    assign client_token_out = {NUM_CLIENTS{{{(TOKEN_WIDTH-1){1'b0}}, 1'b1}}};
    // the halt record (secure_oram_top's format): the block in the bucket field, state 9 (the tag check) or 28 (halt)
    assign dbg_halt_info = {{(24-KW){1'b0}}, k, err_tag_r ? 5'd9 : 5'd28, 1'b0, 2'b00, 32'd0};
    assign key_ready = key_q_v; assign oram_ready = key_q_v && (st != S_OFF) && (st != S_CHK) && (st != S_ZM) && (st != S_ZD) && (st != S_ZW);
    assign client_ready = (st == S_IDLE);
    assign client_done = done_q;
    wire [BI_W-1:0] ri = rel[BI_W-1:0];
    assign client_rdata = on ? xbuf[ri] : (p_valid ? pbuf[ri] : {AXI_DW{1'b0}});
    assign client_rdata_valid = rel_on && (rel < BEATS) && (on ? (rel < rcnt) : 1'b1);
    // bucket port
    assign m_axi_arid = 0; assign m_axi_awid = 0;
    assign m_axi_araddr = blk_addr;
    assign m_axi_awaddr = (st == S_ZD) ? bz_addr : blk_addr;
    assign m_axi_arlen = BLEN;
    assign m_axi_awlen = (st == S_ZD) ? (((bz_end - bz_cnt) > 128) ? 8'd127 : (bz_end - bz_cnt - 1'b1)) : BLEN;
    assign m_axi_arsize = 3'd5; assign m_axi_awsize = 3'd5; assign m_axi_arburst = 2'd1; assign m_axi_awburst = 2'd1;
    assign m_axi_arvalid = (st == S_RUN) && d_req && !d_ar && (wr_out == 0);
    assign m_axi_rready = (st == S_RUN);
    assign m_axi_awvalid = (st == S_ZD) ? bz_aw : (st == S_RUN) && w_aw;
    wire [BI_W-1:0] wi = wcnt[BI_W-1:0];
    // W: on package the command's bytes and strobes; off package the ciphertext as it comes out of GCM
    assign m_axi_wvalid = (st == S_ZD) ? (bz_left != 0) : (st == S_RUN) && w_on && (on ? (wcnt < fcnt) : (wcnt < gout));
    assign m_axi_wdata = (st == S_ZD) ? {AXI_DW{1'b0}} : on ? dbuf[wi] : xbuf[wi];
    assign m_axi_wstrb = (st == S_ZD || !on) ? {AXI_SW{1'b1}} : sbuf[wi];
    assign m_axi_wlast = (st == S_ZD) ? (bz_left == 8'd1) : (wcnt == BEATS - 1);
    assign m_axi_bready = 1'b1;
    // record port (the stash buffer): reads and writes of one 32-byte record; the boot's zeroing
    assign m_stash_araddr = rec_addr; assign m_stash_arlen = 8'd0; assign m_stash_arsize = 3'd5; assign m_stash_arburst = 2'd1;
    assign m_stash_arvalid = (st == S_RUN) && m_req && !m_ar && (mw_out == 0);
    assign m_stash_rready = 1'b1;
    assign m_stash_awaddr = (st == S_ZM) ? {{(64-AXI_AW){1'b0}}, bz_addr} : rec_addr;
    assign m_stash_awlen = (st == S_ZM) ? (((bz_end - bz_cnt) > 128) ? 8'd127 : (bz_end - bz_cnt - 1'b1)) : 8'd0;
    assign m_stash_awsize = 3'd5; assign m_stash_awburst = 2'd1;
    assign m_stash_awvalid = (st == S_ZM) ? bz_aw : (st == S_RUN) && mw_pend && !mw_aw_s;
    assign m_stash_wdata = (st == S_ZM) ? {AXI_DW{1'b0}} : {g_ver, iv_new, tag_new};
    assign m_stash_wstrb = {(AXI_DW/8){1'b1}};
    assign m_stash_wlast = (st == S_ZM) ? (bz_left == 8'd1) : 1'b1;
    assign m_stash_wvalid = (st == S_ZM) ? (bz_left != 0) : (st == S_RUN) && mw_on;
    assign m_stash_bready = 1'b1;
    assign err_tag_mismatch = err_tag_r;
    assign err_stash_overflow = err_cap_r;
    assign oram_busy = (st == S_RUN);
    assign dbg_oram_state = {1'b0, st};
    // everything DOMA's core drives that the baseline does not use
    assign access_violation = 0;
    assign client_lockout = 0;
    assign err_ct_overrun = 0;
    assign client_wbeat_req = 0;
    assign err_slot_overrun = 0;
    assign dbg_slot_start = 0;
    assign dbg_real_cnt = 0;
    assign m_meta_araddr = 0;
    assign m_meta_arlen = 0;
    assign m_meta_arsize = 0;
    assign m_meta_arburst = 0;
    assign m_meta_arvalid = 0;
    assign m_meta_rready = 1'b1;
    assign m_meta_awaddr = 0;
    assign m_meta_awlen = 0;
    assign m_meta_awsize = 0;
    assign m_meta_awburst = 0;
    assign m_meta_awvalid = 0;
    assign m_meta_wdata = 0;
    assign m_meta_wstrb = 0;
    assign m_meta_wlast = 0;
    assign m_meta_wvalid = 0;
    assign m_meta_bready = 1'b1;
    assign m_brec_araddr = 0;
    assign m_brec_arlen = 0;
    assign m_brec_arsize = 0;
    assign m_brec_arburst = 0;
    assign m_brec_arvalid = 0;
    assign m_brec_rready = 1'b1;
    assign m_brec_awaddr = 0;
    assign m_brec_awlen = 0;
    assign m_brec_awsize = 0;
    assign m_brec_awburst = 0;
    assign m_brec_awvalid = 0;
    assign m_brec_wdata = 0;
    assign m_brec_wstrb = 0;
    assign m_brec_wlast = 0;
    assign m_brec_wvalid = 0;
    assign m_brec_bready = 1'b1;
    assign err_bucket_overflow = 0;
    assign oram_beat_cnt = 0;
    assign dbg_gcm_tag_match = 0;
    assign dbg_gcm_tag_valid = 0;
    assign perf_rb_ddr_rd = 0;
    assign perf_rb_decrypt = 0;
    assign perf_rb_encrypt = 0;
    assign perf_rb_compact = 0;
    assign perf_rb_evict = 0;
    assign perf_rb_ddr_wr = 0;
    assign perf_rb_scan = 0;
    assign perf_rb_stash = 0;
    assign perf_rb_total = 0;
    assign perf_rb_ops = 0;
    assign perf_rs_ddr_rd = 0;
    assign perf_rs_decrypt = 0;
    assign perf_rs_encrypt = 0;
    assign perf_rs_compact = 0;
    assign perf_rs_evict = 0;
    assign perf_rs_ddr_wr = 0;
    assign perf_rs_scan = 0;
    assign perf_rs_stash = 0;
    assign perf_rs_total = 0;
    assign perf_rs_ops = 0;
    assign perf_wb_ddr_rd = 0;
    assign perf_wb_decrypt = 0;
    assign perf_wb_encrypt = 0;
    assign perf_wb_compact = 0;
    assign perf_wb_evict = 0;
    assign perf_wb_ddr_wr = 0;
    assign perf_wb_scan = 0;
    assign perf_wb_stash = 0;
    assign perf_wb_total = 0;
    assign perf_wb_ops = 0;
    assign perf_ws_ddr_rd = 0;
    assign perf_ws_decrypt = 0;
    assign perf_ws_encrypt = 0;
    assign perf_ws_compact = 0;
    assign perf_ws_evict = 0;
    assign perf_ws_ddr_wr = 0;
    assign perf_ws_scan = 0;
    assign perf_ws_stash = 0;
    assign perf_ws_total = 0;
    assign perf_ws_ops = 0;
`ifdef ORAM_PHASE_TRACE
    assign phase_ent = 0;
`endif
endmodule
