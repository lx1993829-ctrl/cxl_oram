# v14e: the crypto, non-oblivious baseline (BASELINE=crypto)

A baseline that keeps everything DOMA does except obliviousness, so that DOMA's slowdown against it is the cost of
obliviousness alone. It has no stash, no position map, no random buckets and no timing padding. It keeps DOMA's
kernel, command path, placement share, AES-GCM engine, integrity with replay protection, memory layout and clock.

DOMA's own builds are unchanged: without `BASELINE=crypto` the preprocessed RTL of every DOMA variant (production,
trace, debug, PLAIN) is byte-identical to v14c's (checked by `sim/run_verilator.sh cbase` at every block size).
`aes_gcm_2lane.v` is not modified.

## Design (rtl/crypto_base_top.v)

`build.sh BASELINE=crypto` defines `ORAM_CRYPTO_BASE`. `doma_kernel` then instantiates `crypto_base_top` in place of
DOMA's core, under the same instance name and with the same ports, as the PLAIN baseline does. The kernel's command,
data-slot and response path, its batching and launch protocol are unchanged. Two kernel lines differ, both only in
this build: summary byte 2 bit 7 is set (the crypto baseline), and the core is told with each request whether it is a
whole-block PUT (length 0), through an input DOMA's core does not use here.

**Placement.** Record k is block k at a fixed place. Blocks 0 .. K_ON-1 are on package (HBM), the rest in host
memory over PCIe, with K_ON = hbm_bkts x lambda: the same share of blocks as DOMA's hbm_bkts of n / lambda buckets
(DOMA_HBM_PCT, default 20%). Block k sits at bucket-port address k x BLOCK on package and (k + hbm_bkts x (Z -
lambda)) x BLOCK off package. The kernel's fixed boundary (hbm_bkts x Z x BLOCK) therefore routes it, and the
host's buffers, sized for DOMA, hold it.

**Crypto, as DOMA v14c treats memory.**
- Off-package blocks are encrypted and authenticated with DOMA's `aes_gcm_2lane`: the same instance type, two lanes,
  one 256-bit beat per cycle, 23 + beats cycles from start to tag. One GCM message per block (DOMA: one per bucket).
- On-package blocks are plaintext. The package is trusted, as in v14c.

**Integrity with replay protection, as DOMA's.**
- Each block has a 32-byte record on package: {version (32 bits), IV (96), tag (128)}.
- Every write gets a fresh IV, the engine's next one. This is DOMA's scheme: a 96-bit LFSR seeded with `aes_iv_seed`
  that never repeats within a boot.
- Every write stores that IV with the new tag and advances the version, as DOMA stores each bucket's IV and tag.
- A GET's plaintext is released only after its tag checks under the stored IV. A tampered, swapped or replayed block
  fails the check and halts with the integrity error (summary 0x208), naming the block in the halt record.
- Version 0 means never written; the block reads as zeros.

**Why the IV comes from the engine, not from the block index and the counter.** DOMA's engine always takes its own
next IV for an encryption. Building the IV from {k, version} would mean changing `aes_gcm_2lane`, which DOMA's builds
share. The stored IV plays the version's role: a replayed old ciphertext carries an old IV and tag, while the record
holds the new ones. Swaps and tampering fail the same way. The version counter is kept in the record as well.

**Requests.** One at a time, each done as soon as its own transfer and crypto are:
- **GET:** reads its block (and, off package, its record) as soon as the request arrives, while the kernel streams the
  command's data slot in. On package it returns the beats as they land. Off package it decrypts as they land, checks
  the tag, then returns the block.
- **Whole-block PUT, on package:** writes its beats as they stream in.
- **Whole-block PUT, off package:** reads the record (for the version), encrypts the beats as they stream in, and
  writes the block and the new record. It is done when both are handed off, as DOMA is in arrival mode.
- **Packed PUT (DOMA_PACK), off package:** reads the block with the request, checks and decrypts it, merges the
  record, then encrypts and writes (read-modify-write).
- **Packed PUT, on package:** the byte strobes merge the record in memory.
- **Ordering:** a read waits until every earlier write on its port is acknowledged, the ordering DOMA's axi_master
  keeps.
- **Both ports' write responses, independently:** in this build the kernel takes the write responses of the two bucket
  ports (on package and host memory) independently, so posted PUTs may have writes unacknowledged on both ports at once
  and a PUT never waits to change ports. The core keeps one count of unacknowledged writes (see "Card fix" below).

**Where the records live.** In the stash buffer (DOMA's, unused otherwise), at k x 32. The boot checks that the
buffer holds n records; if not, it halts with a stash overflow (0x408), which host_doma reports as "halted at boot:
stash overflow".
- The host sizes that buffer from its stash pool. The default pool is large enough from 128 B blocks up at 1M and 2M
  records.
- At 32 B and 64 B, run with `DOMA_POOL=<n>` (for example `DOMA_POOL=1048576`; the host caps it at n).

**Boot.** Zeroes every record and every on-package block, then is ready. This takes n + K_ON x beats cycles: at 1M
records, 4 KB and 20% about 0.09 s. Boot is not timed.

## Card fix (v14e, Nov 2): mixed placement timed out on the first query

On the card the first overlay ran at DOMA_HBM_PCT=0 and 100 but not in between: boot and preload succeeded, then a
command timed out (kernel status and errors 0x10) and the run ended.

- **0x10** is the kernel's command timeout (`CMD_TIMEOUT`, 2,000,000 cycles in K_REQ / K_WAIT of doma_kernel.v, the
  same as v14c's). The kernel writes status 0x10 into that command's header, sets errors 0x10 and ends the run. Headers
  after it are never written: they still hold the previous launch's contents ("bad header"). The device total
  (2,000,284 cycles) is the timeout plus the launch.
- **Cause.** doma_kernel's bucket-port switch routes write responses by the port of the latest write address
  (`wsel_h`, registered on AWVALID; `m_axi_gmem2_bready = b_bready && !wsel_h`, gmem6 likewise). DOMA keeps one bucket
  in flight, so it never matters there. The baseline's PUTs are posted. A host-memory PUT whose response was still
  outstanding (PCIe write acknowledgements take about 100 cycles), followed by an on-package PUT (its address goes out
  at once), flipped `wsel_h`. The host response was then never accepted, and the core's count of unacknowledged writes
  never returned to zero. The reverse (an on-package write still unacknowledged when a host write goes out) is the same.
  PUTs never wait on that count, so the preload of PUT-only commands succeeded. The next GET waits for every earlier
  write to be acknowledged, so it waited forever, and the kernel timed it out. At 0% and 100% one port carries
  everything, so `wsel_h` never changes.
- **Layout was not the cause.** The testbench sizes host memory as host_doma does (hbm_bkts = n/lambda buckets x
  pct/100, block k at (k + hbm_bkts x (Z - lambda)) x BLOCK on the bucket port, i.e. (k - hbm_bkts x lambda) x BLOCK
  plus the 4 KB alignment pad in host_doma's pages buffer). Its host memory acknowledged writes immediately, and the
  XRT mock's after one cycle, so the stranded response never happened in simulation.
- **Fix** (doma_kernel.v, under `ifdef ORAM_CRYPTO_BASE` only): the kernel takes both bucket ports' write responses
  independently (`b_bvalid = gmem6_bvalid || gmem2_bvalid`; on package first when both arrive in a cycle, the other the
  next cycle; the core counts one per cycle). DOMA's builds keep the switch above, so their preprocessed RTL is still
  v14c's. Reads still wait until every earlier write is acknowledged.
- **Why not wait to change ports instead.** A first fix held a write to the other port until the earlier writes were
  acknowledged. Against independent responses, with the card's latencies (host read 263 cycles, host write
  acknowledgement 98, HBM 26), 20% on package, 50/50 GET/PUT, uniform keys, 500 requests, it cost 0.7-0.9% of device
  cycles at 32 B and 64 B (about 1.5 cycles per request; 20-29 writes waited) and nothing at 4 KB. With a 200-cycle
  host write acknowledgement it cost 2.3% at 64 B. Independent responses take the baseline out of that dependence.
- **Regression:** `cbase` now also runs every size with the card's write acknowledgements (host 98 cycles, HBM 26)
  at 0, 10, 20, 90 and 100% on package, whole and packed records, and reports the block writes sent to one port while
  the other had writes unacknowledged (at 4 KB these latencies never produce one). Two more runs use slow
  acknowledgements (host 1,000 cycles, HBM 300; 20% whole blocks, 50% packed records), and there such writes must
  happen, at every size. The testbench takes
  `+hbmb_wlat=<cycles>`, and the XRT mock `MOCK_HOST_WLAT=<cycles>`. The delivered overlay fails these runs (the first
  GET after a port change never completes); this one passes them.

## What is the same and what differs, against DOMA

| | DOMA v14c | crypto baseline |
|---|---|---|
| kernel, commands, responses, batching, launches | | the same |
| blocks on package | DOMA_HBM_PCT of n (buckets 0 .. hbm_bkts-1) | the same share (blocks 0 .. hbm_bkts x lambda - 1) |
| off package | AES-GCM (aes_gcm_2lane), one message per bucket | the same engine, one message per block |
| on package | plaintext | plaintext |
| integrity | per-bucket IV + tag on package, LFSR IV | per-block version + IV + tag on package, LFSR IV |
| per request | position map, a random bucket (Z blocks) read and written, stash, padding to fixed times | the record and the one block; done when its own transfer and crypto are |

## Running it

host_doma and host_phases run it unchanged. They take the same arguments and environment as for DOMA, plus
`DOMA_POOL=<n>` at 32 B and 64 B. `DOMA_MEMREPORT=1` works as for DOMA:
- the records are in the line "stash";
- "position map" and "bucket records" are allocated by the host but unused by this core.

## Simulation

`ORAM_LAMBDA=7 ORAM_BEATS=<beats> bash sim/run_verilator.sh cbase` (V14C_RTL=<v14c rtl> also checks DOMA's builds
against v14c). The regression output for all eight sizes is in `docs/v14e_regression_cbase.txt`.
- Every response is checked at 0%, 20% and 100% on package, for whole blocks and for packed 8-byte records (with a
  re-boot).
- The same at 0, 10, 20, 90 and 100% on package with the card's write acknowledgement latencies (host 98 cycles, HBM 26;
  reads 263 and 53), with host_doma's layout and its in-order preload; and with slow acknowledgements (host 1,000, HBM
  300), where writes go to one port while the other's are unacknowledged.
- Tamper, swap and replay of an off-package block each halt with 0x208, release nothing (data slot untouched) and
  name the block. A flipped bit in an on-package block is returned without a halt: plaintext by design.
- A stash buffer too small for the records halts the boot with 0x408.
- Cycles per GET and PUT, split into transfer, crypto and release.

The XRT mock (`sim/xrt_mock`, `BASELINE=crypto bash build_model.sh`) runs host_doma and host_phases on it unchanged:
whole and packed records, the memory report, every response correct.
