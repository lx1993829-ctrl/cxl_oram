// =============================================================================
// oram_params.vh - DOMA parameters and timing budgets
// =============================================================================
// Z = 8 positions per bucket, lambda = 6 slots per bucket by default (ORAM_C; build.sh LAMBDA=7 builds lambda = 7). ORAM_N is the build's maximum number of slots
// (vitis/build.sh NMAX; 512 by default for simulation: 86 buckets, the last one partial). The run-time n is a kernel
// argument, which the host programs round up to a multiple of lambda. The position map, the bucket records and the
// stash (64-byte heads per bucket plus a pool of blocks, sized by the host) live in HBM; no stash is on chip.

`ifndef ORAM_PARAMS_VH
`define ORAM_PARAMS_VH
`include "oram_build_cfg.vh"      // build-time settings from vitis/build.sh (empty by default)

// Package revision. The self-test testbench prints it at start-up and refuses to
// run without it, so an old copy of this header in the include path (for
// example one imported into a Vivado project earlier) cannot go unnoticed.
`define ORAM_PKG_REV "2026-10-31 v14c card-calibrated 4 KB on-package budgets (10% margin); v14b on-package halt record, debug build and card calibration, interim budgets option, 300 MHz fixes; v14 on-package buckets in plaintext (arrival builds), random direct placement at boot, fixed-time boot, two-lane AES-GCM, one client, Z=8, block size selectable"

// Simulation builds turn on the debug ports automatically: the self-test steers
// remaps and reads its performance counters through them, and every simulator
// leaves SYNTHESIS undefined (Vivado defines it only in synthesis). Synthesis
// still needs ORAM_DEBUG_PORTS explicitly (self-test bitstream), and production
// builds (ORAM_SECURE_BUILD) never get the debug ports.
`ifndef SYNTHESIS
  `ifndef ORAM_SECURE_BUILD
    `ifndef ORAM_DEBUG_PORTS
      `define ORAM_DEBUG_PORTS
    `endif
  `endif
`endif

// --- ORAM tree geometry ---
// --- Client configuration ---
// One client with one ORAM: accesses start on demand, one at a time, each in a
// fixed-length window; there is no schedule and no dummy access. The client-count
// and partition-width parameters remain, fixed at 1 and 0, so the generic intake
// and partition-check logic collapses to a single client in synthesis.
`define ORAM_NUM_CLIENTS    1
// ORAM_N is the build's MAXIMUM number of blocks (slots); widths derive from it. The host chooses the
// actual number n <= ORAM_N at boot (kernel argument nblk; 0 = ORAM_N), so one bitstream serves every
// size up to the maximum. Select a larger maximum with -DORAM_N=... (build.sh: NMAX=...).
`ifndef ORAM_N
`define ORAM_N              512   // slots (maximum); 86 buckets at lambda = 6, the last one partial
`endif
`define ORAM_Z              8   // positions per bucket: as BOLT's 8-slot pages (comparison setting)
`ifndef ORAM_C
`define ORAM_C              6   // lambda: average blocks per bucket (the smallest stash bound at Z = 8); build.sh LAMBDA=7 sets 7
`endif
`define ORAM_B              ((`ORAM_N + `ORAM_C - 1) / `ORAM_C)   // buckets (maximum) = ceil(N / lambda)
`define ORAM_PART_W         0     // one ORAM, no partitions
`define BUCKET_ID_W         $clog2(`ORAM_B)                       // 6 at N = 256
`define SLOT_ID_W           $clog2(`ORAM_N)                       // 8 at N = 256
`define ORAM_STASH_DEPTH    128   // entries per ORAM (per client in the two-client build)
// The stash lives in HBM: each bucket has a list of ORAM_STASH_SLOTS pointers (blocks waiting for it)
// into a pool of ORAM_STASH_DEPTH blocks. DOMA places each block in ONE random bucket, so the most
// blocks waiting for any bucket has a geometric tail; 64 makes overflow negligible up to N = 10M.
`define ORAM_STASH_SLOTS    64

// --- Fixed-time boot (v11b) ---
// The random placement at boot is padded to a budget, as every access is: the layout and all its writes must be
// done LAY_BUDGET = n * ORAM_LAY_TB + (n / 4) * (ORAM_LAY_TS0 + (Z + 3) * beats per block) + ORAM_LAY_BASE cycles
// after the layout starts, and the controller becomes ready exactly then (plus BOOT_SETTLE), or halts with a timing
// overrun (rtl/flat_oram_gcm.v). ORAM_LAY_TB bounds one slot placed in its bucket (a bucket-record read behind the
// previous slot's writes, then the record and position-map writes); ORAM_LAY_TS0 + (Z + 3) * beats one slot placed
// in the stash (the list open, which also reads the target's window blocks, W = Z + 1, a zero pool block, the
// commit, each behind the previous writes); n / 4 bounds the slots placed in the stash (expected 5.2% of n at
// lambda 6, 9.2% at lambda 7). Measured worst per slot with every HBM metadata read at 200 cycles (sim/run_verilator.sh
// boot, n = 4,092): in the bucket 234, in the stash 669 at 32 B and 1,535 at 4 KB (bounds 300; 851 and 2,248).
// At n = 1M: 1.8 s at 32 B, 3.0 s at 4 KB (300 MHz).
`ifndef ORAM_LAY_TB
`define ORAM_LAY_TB         300
`endif
`ifndef ORAM_LAY_TS0
`define ORAM_LAY_TS0        840
`endif
`ifndef ORAM_LAY_BASE
`define ORAM_LAY_BASE       4096
`endif

// --- Bit widths ---
// slot addresses are slot << 12; the IV/tag interface uses the same width for {bucket, position} << 12,
// so it must hold both (35 bits at 2^22 slots: 20-bit buckets + 3-bit positions + 12)
`define SLOT_ADDR_W_A      ((`SLOT_ID_W + 13 > 32) ? (`SLOT_ID_W + 13) : 32)   // room for a size of N x 4096 (n = N inclusive)
`define SLOT_ADDR_W         ((`BUCKET_ID_W + `POS_IN_BKT_W + 12 > `SLOT_ADDR_W_A) ? (`BUCKET_ID_W + `POS_IN_BKT_W + 12) : `SLOT_ADDR_W_A)
`define FILL_CNT_W          4         // ceil(log2(Z+1)) = 4, holds 0..8
`define POS_IN_BKT_W        3         // ceil(log2(Z)) = 3
`define STASH_PTR_W         7   // ceil(log2(STASH_DEPTH))

// --- AXI parameters ---
`define AXI_DATA_W          256       // 256-bit data bus (32 bytes per beat)
`define AXI_ADDR_W          40    // bucket byte offsets: 1 TB (32 wrapped at 4 GB: 4 KB blocks, N = 1M needs 5.4 GB)
`define AXI_STRB_W          32        // AXI_DATA_W / 8
`define AXI_ID_W            4
`define AXI_LEN_W           8         // AXI4 standard: 8-bit ARLEN/AWLEN

// --- Beat/block parameters ---
// Block (ORAM slot) size in 32-byte beats: 1, 2, 4 or 8 for 32-256-byte records (the value
// sizes of BOLT's experiments), 128 for 4 KB pages. Select with -DORAM_BLOCK_BEATS=N.
`ifndef ORAM_BLOCK_BEATS
`define ORAM_BLOCK_BEATS    128
`endif
`define BEATS_PER_BLOCK     `ORAM_BLOCK_BEATS
`define BEATS_PER_BKT       (`ORAM_Z * `BEATS_PER_BLOCK)                 // beats in one bucket
`define BEAT_CNT_W          $clog2(`ORAM_Z * `BEATS_PER_BLOCK + 1)       // holds 0..BEATS_PER_BKT

// --- DDR layout ---
`define DDR_BASE            32'h0000_0000
`define BUCKET_BYTES        (`ORAM_Z * `BEATS_PER_BLOCK * 32)            // compact layout: a bucket is exactly Z blocks
`define SCR_AW              (`POS_IN_BKT_W + $clog2(`BEATS_PER_BLOCK))    // a bucket beat's address: {position, beat in block}

// --- Slot status encoding ---
// bucket record in HBM: beat 0 metadata {slot list, fill}, beat 1 the bucket's {tag, IV} (per-bucket GCM): 64 bytes
`define ORAM_REC_BEATS      2
`define ST_DUMMY            2'b00
`define ST_VALID            2'b01
`define ST_IN_STASH         2'b10

// --- FSM states ---
`define S_IDLE              4'd0
`define S_POS_LOOKUP        4'd1
`define S_DDR_READ          4'd2
`define S_SCAN              4'd3
`define S_SCAN2             4'd4
`define S_EXTRACT           4'd5
`define S_STASH_SEARCH      4'd6
`define S_STASH_READ        4'd7
`define S_COMPACT           4'd8
`define S_EVICT             4'd9
`define S_DDR_WRITE         4'd10
`define S_RESPOND           4'd11


// Phase 2 constant-time budgets (cycles after an access is accepted): bucket
// read issue, write-back issue, result release. 0 = gate off (calibration).
// The position map is in HBM: the bucket read can start only once its lookup returns.
// ORAM_PM_LAT is the budget for that lookup; every fixed point moves out by it. Measured on the
// U55C (latency/): dependent 32-byte HBM reads average 64 cycles, at most 179 in 2M samples.
`ifndef ORAM_PM_LAT
`define ORAM_PM_LAT      250
`endif
`define ORAM_CT_RD_BASE  16      // with an on-chip map: calibrated on the testbench DDR model (arrival 2)
`ifndef ORAM_CT_RD
`define ORAM_CT_RD   (`ORAM_CT_RD_BASE + `ORAM_PM_LAT)
`endif
// Per block size (beats), from the regression's derived worst case on the testbench memory, with an
// on-chip position map (the selection below adds ORAM_PM_LAT):
//   CT_WB   = worst encryption end + 300 - (Z-1)*BEATS  (the write-back reaches the last position
//             (Z-1)*BEATS cycles after it starts), rounded up
//   CT_DONE = CT_WB + longest write-back + 250, rounded up
// Every supported size (32 B to 4 KB, BEATS 1..128 in powers of two) has its own budgets; any other size fails to build
// (flat_oram_gcm.v). 64 B to 2 KB: see the table after the 4 KB values.
`define ORAM_CT_WB_B1        666    // 32 B, Z = 8, 9 candidates: encryption ends at worst 267 + 179 + 191 + 1 (stash wait) + 44 + 187 = 869 <= 666+250+7 = 923
`define ORAM_CT_DONE_B1      766    // write-back (8 beats) + HBM acknowledgement: CT_DONE - CT_WB = 100 (write-back done at most 12 after it starts)
`define ORAM_CT_WB_B128      4223   // 4 KB, Z = 8: encryption ends at worst 267 + 307 (HBM 4 KB burst max) + 2,223 + 1 + 298 + 2,219 = 5,315 <= 4223+250+7*128 = 5,369
`define ORAM_CT_DONE_B128    5967   // write-back of 1,024 beats + acknowledgement + margin: CT_DONE - CT_WB = 1,744 (2,000 at Z = 10, 256 beats fewer)
// 64 B to 2 KB (BEATS 2..64), Z = 8: calibrated by sim/calibrate_sizes.sh (README); each AR_WB notes its inputs.
`define ORAM_CT_WB_B2         821
`define ORAM_CT_DONE_B2       934
`define ORAM_AR_WB_B2         542    // recalibrated: derived after the last beat 238, measured host 488, HBM (adverse, combined) 708 (sim/budgets.py)
`define ORAM_AR_DONE_B2       702
`define ORAM_AR_WB_H_B2       782
`define ORAM_AR_DONE_H_B2     838
`define ORAM_AR_REL_B2        590
`define ORAM_AR_REL_H_B2      824
`define ORAM_CT_WB_B4         875
`define ORAM_CT_DONE_B4       1014
`define ORAM_AR_WB_B4         550    // recalibrated: derived after the last beat 258, measured host 496, HBM (adverse, combined) 716 (sim/budgets.py)
`define ORAM_AR_DONE_B4       733
`define ORAM_AR_WB_H_B4       790
`define ORAM_AR_DONE_H_B4     870
`define ORAM_AR_REL_B4        618
`define ORAM_AR_REL_H_B4      849
`define ORAM_CT_WB_B8         983
`define ORAM_CT_DONE_B8       1174
`define ORAM_AR_WB_B8         566    // recalibrated: derived after the last beat 298, measured host 512, HBM (adverse, combined) 732 (sim/budgets.py)
`define ORAM_AR_DONE_B8       795
`define ORAM_AR_WB_H_B8       806
`define ORAM_AR_DONE_H_B8     933
`define ORAM_AR_REL_B8        672
`define ORAM_AR_REL_H_B8      899
`define ORAM_CT_WB_B16        1199
`define ORAM_CT_DONE_B16      1493
`define ORAM_AR_WB_B16        598    // recalibrated: derived after the last beat 378, measured host 544, HBM (adverse, combined) 764 (sim/budgets.py)
`define ORAM_AR_DONE_B16      920
`define ORAM_AR_WB_H_B16      838
`define ORAM_AR_DONE_H_B16    1060
`define ORAM_AR_REL_B16       781
`define ORAM_AR_REL_H_B16     998
`define ORAM_CT_WB_B32        1631
`define ORAM_CT_DONE_B32      2132
`define ORAM_AR_WB_B32        709    // recalibrated: derived after the last beat 545, measured host 655, HBM (adverse, combined) 875 (sim/budgets.py)
`define ORAM_AR_DONE_B32      1216
`define ORAM_AR_WB_H_B32      949
`define ORAM_AR_DONE_H_B32    1361
`define ORAM_AR_REL_B32       1048
`define ORAM_AR_REL_H_B32     1246
`define ORAM_CT_WB_B64        2495
`define ORAM_CT_DONE_B64      3411
`define ORAM_AR_WB_B64        1061    // recalibrated: derived after the last beat 897, measured host 1007, HBM (adverse, combined) 1227 (sim/budgets.py)
`define ORAM_AR_DONE_B64      1939
`define ORAM_AR_WB_H_B64      1301
`define ORAM_AR_DONE_H_B64    2092
`define ORAM_AR_REL_B64       1712
`define ORAM_AR_REL_H_B64     1871
`ifndef ORAM_CT_WB
`define ORAM_CT_WB ((`ORAM_BLOCK_BEATS == 1 ? `ORAM_CT_WB_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_CT_WB_B2 :  \
                       `ORAM_BLOCK_BEATS == 4 ? `ORAM_CT_WB_B4 : `ORAM_BLOCK_BEATS == 8 ? `ORAM_CT_WB_B8 :  \
                       `ORAM_BLOCK_BEATS == 16 ? `ORAM_CT_WB_B16 :  \
                       `ORAM_BLOCK_BEATS == 32 ? `ORAM_CT_WB_B32 :  \
                       `ORAM_BLOCK_BEATS == 64 ? `ORAM_CT_WB_B64 : `ORAM_CT_WB_B128) + `ORAM_PM_LAT)
`endif
`ifndef ORAM_CT_DONE
`define ORAM_CT_DONE ((`ORAM_BLOCK_BEATS == 1 ? `ORAM_CT_DONE_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_CT_DONE_B2 :  \
                       `ORAM_BLOCK_BEATS == 4 ? `ORAM_CT_DONE_B4 :  \
                       `ORAM_BLOCK_BEATS == 8 ? `ORAM_CT_DONE_B8 :  \
                       `ORAM_BLOCK_BEATS == 16 ? `ORAM_CT_DONE_B16 :  \
                       `ORAM_BLOCK_BEATS == 32 ? `ORAM_CT_DONE_B32 :  \
                       `ORAM_BLOCK_BEATS == 64 ? `ORAM_CT_DONE_B64 : `ORAM_CT_DONE_B128) + `ORAM_PM_LAT)
`endif

// Arrival-relative scheduling (build option ORAM_SCHED_ARRIVAL, build.sh SCHED=arrival). The write-back and the
// end of an access follow the bucket read's LAST BEAT by these fixed times, instead of fixed offsets from the
// access start: the attacker sees the off-package read's latency anyway, so only hidden work is padded (the
// read still issues at CT_RD, covering the hidden position-map lookup; AR_WB covers the worst-case on-chip work
// after the data arrives: verification, stash, evictions, re-encryption). AR_DONE - AR_WB covers the write-back
// and its acknowledgement (+70 over the HBM-calibrated gap: PCIe acknowledges in 98 cycles, HBM in 28).
// The boot format reads no bucket and keeps the strict offsets. Calibrated from ar_max_wb (see README).
// What stays padded is everything that depends on secrets: the position-map lookup (CT_RD), the requested block's
// own path (stash hit, compaction) and all eviction work and its writes (AR_WB, AR_DONE). A bucket's read latency
// is not: buckets are chosen at random, and the bucket bank serves only buckets. This holds for buckets in HBM
// too, PROVIDED the eviction-related metadata traffic does not interfere with the bucket bank (on the U55C the
// HBM bucket bank sits on a different memory controller from the position map, records and stash).
`define ORAM_AR_WB_B1         538    // recalibrated: derived after the last beat 228, measured host 484, HBM (adverse, combined) 704 (sim/budgets.py)
`define ORAM_AR_DONE_B1       686
`define ORAM_AR_WB_B128       1765    // recalibrated: derived after the last beat 1601, measured host 1711, HBM (adverse, combined) 1931 (sim/budgets.py)
`define ORAM_AR_DONE_B128     3385
// HBM buckets: their write-back point AR_WB_H covers a later stash. With the bucket read fast (HBM, 52 cycles at
// least), the stash can be ready after verification: it opens only after the position-map lookup, then needs two
// dependent HBM reads (its head, then the candidates). Budgeted at 200 cycles per HBM read (measured worst 191 on the
// U55C, latency/lat_multi). Off-package buckets are unaffected: PCIe's minimum latency exceeds the stash's worst.
`define ORAM_AR_WB_H_B1       778
`define ORAM_AR_WB_H_B128     2005
// lambda = 7 (ORAM_C = 7), through v11g: AR_WB_H(7) = max(AR_WB_H(6), measured HBM worst at lambda 7 + 74, the combined
// case's margin), written by sim/budgets_l7.py; release and acknowledgement deadlines move by the same amount. (v14
// replaces these on-package lambda = 7 values with the plaintext path's, sim/budgets_v14.py: see below.) Measured at
// lambda 7 (sim/measure_lambda.sh: the directed cases and the kernel runs, every arrival budget raised): v11b, worst
// work after an HBM bucket arrives 32 B 724, 64 B 728, 128 B 736, 256 B 752, 512 B 784, 1024 B 895, 2048 B 1247,
// 4096 B 1951, from the combined case (the kernel runs: 683 .. 1903, as in v11a). Through v11a the directed cases at
// lambda 7 equalled lambda 6's and the kernel's back-to-back stash drain set these budgets; since v11b's random
// placement, the directed cases' full stash windows (19 stash reads in one open, three behind the 16 in flight) set them.
// v14: on-package buckets are kept in plaintext in arrival builds (rtl/flat_oram_gcm.v, BYP): no decryption pass, tag
// check or re-encryption on their path, and their write-back streams behind the eviction copies, issued once every
// decision is made. Their lambda = 7 budgets below are those of that path (sim/budgets_v14.py, from the calibration
// runs; the cycle model, sim/worst_case.py part 4, on the directed worst cases with every metadata read at 200 cycles):
//   AR_WB_H(7)   = max(derived, measured) write-back start after the arrival + 74: an early check (a later start is a
//                  timing overrun, reported at the release time)
//   AR_REL_H(7)  = max(derived release gate + bp(b), measured) + 74: the release time; the write must be handed off (its
//                  last beat accepted) by then, or it is a timing overrun, raised at that cycle. bp(b) = ceil(0.05 (8 b +
//                  2 bursts + 22)) lets the HBM bucket port take the write 5% slower (v11g's HBM write allowance)
//   AR_DONE_H(7) = AR_REL_H(7) + the acknowledgement allowance as before (AR_DONE_H - AR_REL_H of v11g)
// Lambda = 6 keeps v11g's on-package budgets (not recalibrated for v14; they exceed the plaintext path's needs).
// v14c: 4 KB (B128) is calibrated on the card (U55C, 300 MHz; docs/v14b_card_calibration.md): ~12.5M on-package
// accesses of the debug build (2.05M and 10M at 100% on package, 0.41M at 20%), worst write-back start 1,049, worst
// release gate 2,079, worst write (release gate - write-back start) 1,156 cycles after the arrival; sim/card_budgets.py
// --pct 10: AR_WB_H = ceil(1,049 x 1.10) + 74 = 1,228, AR_REL_H = max(ceil(2,079 x 1.10) + 74, 1,228 + 1,156) = 2,384,
// AR_DONE_H = 2,384 + 434 = 2,818. The other sizes keep the simulation's values until their own card calibration
// (sim/calibrate_all_sizes.sh).
`ifdef ORAM_ONPKG_RAMA
// RAMA (2026-11-06, build.sh RAMA=1, CFG=doma_big2m_rama.cfg): the stash on AMD's RAMA IP. Card calibration (debug build,
// 2.46M on-package accesses, 300 MHz): the stash is ready before every arrival; worst write-back start 299, worst
// release gate 1,329 (the write-back start + the 1,024-beat write), the same in every record. At a 20% margin:
// AR_WB_H = ceil(299 x 1.2) + 74 = 433, raised to Option A's fixed write-back start (440); AR_REL_H = ceil(1,329 x 1.2)
// + 74 = 1,669 (>= 440 + the worst write 1,030); AR_DONE_H = 1,669 + 434 = 2,103 (docs/rama_baseline.md).
`define ORAM_AR_WB_H_L7_B1    644
`define ORAM_AR_WB_H_L7_B2    640
`define ORAM_AR_WB_H_L7_B4    632
`define ORAM_AR_WB_H_L7_B8    616
`define ORAM_AR_WB_H_L7_B16   584
`define ORAM_AR_WB_H_L7_B32   567
`define ORAM_AR_WB_H_L7_B64   663
`define ORAM_AR_WB_H_L7_B128  440
`else
`define ORAM_AR_WB_H_L7_B1    644
`define ORAM_AR_WB_H_L7_B2    640
`define ORAM_AR_WB_H_L7_B4    632
`define ORAM_AR_WB_H_L7_B8    616
`define ORAM_AR_WB_H_L7_B16   584
`define ORAM_AR_WB_H_L7_B32   567
`define ORAM_AR_WB_H_L7_B64   663
`define ORAM_AR_WB_H_L7_B128  1228
`endif
`define ORAM_AR_WB_H_L6 (`ORAM_BLOCK_BEATS == 1 ? `ORAM_AR_WB_H_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_AR_WB_H_B2 :  \
                       `ORAM_BLOCK_BEATS == 4 ? `ORAM_AR_WB_H_B4 :  \
                       `ORAM_BLOCK_BEATS == 8 ? `ORAM_AR_WB_H_B8 :  \
                       `ORAM_BLOCK_BEATS == 16 ? `ORAM_AR_WB_H_B16 :  \
                       `ORAM_BLOCK_BEATS == 32 ? `ORAM_AR_WB_H_B32 :  \
                       `ORAM_BLOCK_BEATS == 64 ? `ORAM_AR_WB_H_B64 : `ORAM_AR_WB_H_B128)
`define ORAM_AR_WB_H_L7 (`ORAM_BLOCK_BEATS == 1 ? `ORAM_AR_WB_H_L7_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_AR_WB_H_L7_B2 :  \
                       `ORAM_BLOCK_BEATS == 4 ? `ORAM_AR_WB_H_L7_B4 :  \
                       `ORAM_BLOCK_BEATS == 8 ? `ORAM_AR_WB_H_L7_B8 :  \
                       `ORAM_BLOCK_BEATS == 16 ? `ORAM_AR_WB_H_L7_B16 :  \
                       `ORAM_BLOCK_BEATS == 32 ? `ORAM_AR_WB_H_L7_B32 :  \
                       `ORAM_BLOCK_BEATS == 64 ? `ORAM_AR_WB_H_L7_B64 : `ORAM_AR_WB_H_L7_B128)
`define ORAM_AR_WB_H ((`ORAM_C == 7) ? `ORAM_AR_WB_H_L7 : `ORAM_AR_WB_H_L6)
// HBM buckets (fixed boundary): the same work after arrival; HBM acknowledges writes in 28 cycles (PCIe 98), so their
// completion follows the write-back by the strict-mode allowance (CT_DONE - CT_WB)
`define ORAM_AR_DONE_H_B1     822
`define ORAM_AR_DONE_H_B128   3555
`ifdef ORAM_ONPKG_RAMA
`define ORAM_AR_DONE_H_L7_B1    667
`define ORAM_AR_DONE_H_L7_B2    677
`define ORAM_AR_DONE_H_L7_B4    693
`define ORAM_AR_DONE_H_L7_B8    724
`define ORAM_AR_DONE_H_L7_B16   787
`define ORAM_AR_DONE_H_L7_B32   958
`define ORAM_AR_DONE_H_L7_B64   1429
`define ORAM_AR_DONE_H_L7_B128  2103
`else
`define ORAM_AR_DONE_H_L7_B1  667
`define ORAM_AR_DONE_H_L7_B2  677
`define ORAM_AR_DONE_H_L7_B4  693
`define ORAM_AR_DONE_H_L7_B8  724
`define ORAM_AR_DONE_H_L7_B16 787
`define ORAM_AR_DONE_H_L7_B32 958
`define ORAM_AR_DONE_H_L7_B64 1429
`define ORAM_AR_DONE_H_L7_B128  2818
`endif
`define ORAM_AR_DONE_H_L6 (`ORAM_BLOCK_BEATS == 1 ? `ORAM_AR_DONE_H_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_AR_DONE_H_B2 :  \
                       `ORAM_BLOCK_BEATS == 4 ? `ORAM_AR_DONE_H_B4 :  \
                       `ORAM_BLOCK_BEATS == 8 ? `ORAM_AR_DONE_H_B8 :  \
                       `ORAM_BLOCK_BEATS == 16 ? `ORAM_AR_DONE_H_B16 :  \
                       `ORAM_BLOCK_BEATS == 32 ? `ORAM_AR_DONE_H_B32 :  \
                       `ORAM_BLOCK_BEATS == 64 ? `ORAM_AR_DONE_H_B64 : `ORAM_AR_DONE_H_B128)
`define ORAM_AR_DONE_H_L7 (`ORAM_BLOCK_BEATS == 1 ? `ORAM_AR_DONE_H_L7_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_AR_DONE_H_L7_B2 :  \
                       `ORAM_BLOCK_BEATS == 4 ? `ORAM_AR_DONE_H_L7_B4 :  \
                       `ORAM_BLOCK_BEATS == 8 ? `ORAM_AR_DONE_H_L7_B8 :  \
                       `ORAM_BLOCK_BEATS == 16 ? `ORAM_AR_DONE_H_L7_B16 :  \
                       `ORAM_BLOCK_BEATS == 32 ? `ORAM_AR_DONE_H_L7_B32 :  \
                       `ORAM_BLOCK_BEATS == 64 ? `ORAM_AR_DONE_H_L7_B64 : `ORAM_AR_DONE_H_L7_B128)
`define ORAM_AR_DONE_H ((`ORAM_C == 7) ? `ORAM_AR_DONE_H_L7 : `ORAM_AR_DONE_H_L6)
`ifdef ORAM_ONPKG_RAMA
`ifndef ORAM_AR_WBF_H
// Option A + RAMA (2026-11-07, docs/rama_sizes.md): the fixed on-package write-back start per block size. 4 KB: 440
// (the card calibration). 32 B .. 2 KB keep their card-proven AR_WB_H / AR_REL_H / AR_DONE_H with RAMA (the stash's
// worst case there is a window of dependent reads, which RAMA does not shorten), and the start splits AR_WB_H's 74-cycle
// margin: WBF = AR_WB_H - 37, so 37 cycles over the derived worst decisions and about 40 before the release
`define ORAM_AR_WBF_H (`ORAM_BLOCK_BEATS == 1 ? 607 : `ORAM_BLOCK_BEATS == 2 ? 603 : `ORAM_BLOCK_BEATS == 4 ? 595 : `ORAM_BLOCK_BEATS == 8 ? 579 : `ORAM_BLOCK_BEATS == 16 ? 547 : `ORAM_BLOCK_BEATS == 32 ? 530 : `ORAM_BLOCK_BEATS == 64 ? 626 : 440)
`endif
`endif
`define ORAM_AR_WB_L6 (`ORAM_BLOCK_BEATS == 1 ? `ORAM_AR_WB_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_AR_WB_B2 :  \
                       `ORAM_BLOCK_BEATS == 4 ? `ORAM_AR_WB_B4 : `ORAM_BLOCK_BEATS == 8 ? `ORAM_AR_WB_B8 :  \
                       `ORAM_BLOCK_BEATS == 16 ? `ORAM_AR_WB_B16 :  \
                       `ORAM_BLOCK_BEATS == 32 ? `ORAM_AR_WB_B32 :  \
                       `ORAM_BLOCK_BEATS == 64 ? `ORAM_AR_WB_B64 : `ORAM_AR_WB_B128)
`define ORAM_AR_DONE_L6 (`ORAM_BLOCK_BEATS == 1 ? `ORAM_AR_DONE_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_AR_DONE_B2 :  \
                       `ORAM_BLOCK_BEATS == 4 ? `ORAM_AR_DONE_B4 :  \
                       `ORAM_BLOCK_BEATS == 8 ? `ORAM_AR_DONE_B8 :  \
                       `ORAM_BLOCK_BEATS == 16 ? `ORAM_AR_DONE_B16 :  \
                       `ORAM_BLOCK_BEATS == 32 ? `ORAM_AR_DONE_B32 :  \
                       `ORAM_BLOCK_BEATS == 64 ? `ORAM_AR_DONE_B64 : `ORAM_AR_DONE_B128)
// Arrival mode: the access ends (result released, next request accepted) once the write-back's data has been handed
// to the master, not after its acknowledgement: the acknowledgements drain during the next access's lookup, and every
// later read is ordered after them (axi_master holds a read until all earlier writes are acknowledged; pos_map_hbm and
// bucket_rec_hbm never let a read overtake a write; the stash opens only once quiet).
`define ORAM_AR_REL_B1        574
`define ORAM_AR_REL_B128      3013
`define ORAM_AR_REL_H_B1      814
`define ORAM_AR_REL_H_B128    3121
`define ORAM_AR_REL_L6 (`ORAM_BLOCK_BEATS == 1 ? `ORAM_AR_REL_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_AR_REL_B2 :  \
                       `ORAM_BLOCK_BEATS == 4 ? `ORAM_AR_REL_B4 : `ORAM_BLOCK_BEATS == 8 ? `ORAM_AR_REL_B8 :  \
                       `ORAM_BLOCK_BEATS == 16 ? `ORAM_AR_REL_B16 :  \
                       `ORAM_BLOCK_BEATS == 32 ? `ORAM_AR_REL_B32 :  \
                       `ORAM_BLOCK_BEATS == 64 ? `ORAM_AR_REL_B64 : `ORAM_AR_REL_B128)
`ifdef ORAM_ONPKG_RAMA
`define ORAM_AR_REL_H_L7_B1    659
`define ORAM_AR_REL_H_L7_B2    663
`define ORAM_AR_REL_H_L7_B4    672
`define ORAM_AR_REL_H_L7_B8    690
`define ORAM_AR_REL_H_L7_B16   725
`define ORAM_AR_REL_H_L7_B32   843
`define ORAM_AR_REL_H_L7_B64   1208
`define ORAM_AR_REL_H_L7_B128  1669
`else
`define ORAM_AR_REL_H_L7_B1   659
`define ORAM_AR_REL_H_L7_B2   663
`define ORAM_AR_REL_H_L7_B4   672
`define ORAM_AR_REL_H_L7_B8   690
`define ORAM_AR_REL_H_L7_B16  725
`define ORAM_AR_REL_H_L7_B32  843
`define ORAM_AR_REL_H_L7_B64  1208
`define ORAM_AR_REL_H_L7_B128  2384
`endif
`define ORAM_AR_REL_H_L6 (`ORAM_BLOCK_BEATS == 1 ? `ORAM_AR_REL_H_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_AR_REL_H_B2 :  \
                       `ORAM_BLOCK_BEATS == 4 ? `ORAM_AR_REL_H_B4 :  \
                       `ORAM_BLOCK_BEATS == 8 ? `ORAM_AR_REL_H_B8 :  \
                       `ORAM_BLOCK_BEATS == 16 ? `ORAM_AR_REL_H_B16 :  \
                       `ORAM_BLOCK_BEATS == 32 ? `ORAM_AR_REL_H_B32 :  \
                       `ORAM_BLOCK_BEATS == 64 ? `ORAM_AR_REL_H_B64 : `ORAM_AR_REL_H_B128)
`define ORAM_AR_REL_H_L7 (`ORAM_BLOCK_BEATS == 1 ? `ORAM_AR_REL_H_L7_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_AR_REL_H_L7_B2 :  \
                       `ORAM_BLOCK_BEATS == 4 ? `ORAM_AR_REL_H_L7_B4 :  \
                       `ORAM_BLOCK_BEATS == 8 ? `ORAM_AR_REL_H_L7_B8 :  \
                       `ORAM_BLOCK_BEATS == 16 ? `ORAM_AR_REL_H_L7_B16 :  \
                       `ORAM_BLOCK_BEATS == 32 ? `ORAM_AR_REL_H_L7_B32 :  \
                       `ORAM_BLOCK_BEATS == 64 ? `ORAM_AR_REL_H_L7_B64 : `ORAM_AR_REL_H_L7_B128)
`define ORAM_AR_REL_H ((`ORAM_C == 7) ? `ORAM_AR_REL_H_L7 : `ORAM_AR_REL_H_L6)
// v14b, interim on-package budgets (build.sh INTERIM=1: ORAM_ONPKG_INTERIM; 4 KB blocks, lambda = 7 only). Until
// the card calibration (docs/v14b_card_calibration.md) sets the defaults above from the card's own accesses, these
// cover every stash and bucket-record read taking 500 cycles (position map at 200): the cycle model (sim/worst_case.py
// part 4) on the directed worst cases at that profile derives the write-back start at 1 + 1,084 + 296 = 1,381 and the
// release gate at 1 + 1,084 + 1,325 = 2,410 cycles after the arrival (the stash wait 1,084 against 484 at 200 cycles:
// two dependent stash reads). Rule as sim/budgets_v14.py: AR_WB_H = 1,381 + 74, AR_REL_H = 2,410 + bp(128) 54 + 74,
// AR_DONE_H = AR_REL_H + 434 (the acknowledgement allowance). The release comes 603 cycles earlier than v11g's
// (3,141), half of v14's saving of 1,203.
`define ORAM_AR_WB_H_L7I_B128   1455
`define ORAM_AR_REL_H_L7I_B128  2538
`define ORAM_AR_DONE_H_L7I_B128 2972
`ifdef ORAM_ONPKG_INTERIM
`undef ORAM_AR_WB_H
`undef ORAM_AR_REL_H
`undef ORAM_AR_DONE_H
`define ORAM_AR_WB_H   `ORAM_AR_WB_H_L7I_B128
`define ORAM_AR_REL_H  `ORAM_AR_REL_H_L7I_B128
`define ORAM_AR_DONE_H `ORAM_AR_DONE_H_L7I_B128
`endif

// lambda = 7, host buckets (v11b): the random placement at boot leaves blocks waiting in the stash from the first
// access, so the directed calibration cases (hostwait, combined) reach full stash windows whose open needs 19 reads
// (three wait behind the 16 in flight), and at lambda = 7 their host worst exceeds lambda 6's by 20 cycles (measured
// 504, 508, 516, 532, 564, 675, 1027, 1731 for 32 B .. 4 KB). So host buckets get lambda = 7 budgets too, by the HBM
// buckets' rule: AR_WB(7) = max(AR_WB(6), measured host worst + 54), AR_REL(7) and AR_DONE(7) moved by the same
// amount (sim/budgets_l7.py). They are selected by ORAM_C == 7.
`define ORAM_AR_WB_L7_B1      558
`define ORAM_AR_WB_L7_B2      562
`define ORAM_AR_WB_L7_B4      570
`define ORAM_AR_WB_L7_B8      586
`define ORAM_AR_WB_L7_B16     618
`define ORAM_AR_WB_L7_B32     729
`define ORAM_AR_WB_L7_B64     1081
`define ORAM_AR_WB_L7_B128    1785
`define ORAM_AR_REL_L7_B1     594
`define ORAM_AR_REL_L7_B2     610
`define ORAM_AR_REL_L7_B4     638
`define ORAM_AR_REL_L7_B8     692
`define ORAM_AR_REL_L7_B16    801
`define ORAM_AR_REL_L7_B32    1068
`define ORAM_AR_REL_L7_B64    1732
`define ORAM_AR_REL_L7_B128   3033
`define ORAM_AR_DONE_L7_B1    706
`define ORAM_AR_DONE_L7_B2    722
`define ORAM_AR_DONE_L7_B4    753
`define ORAM_AR_DONE_L7_B8    815
`define ORAM_AR_DONE_L7_B16   940
`define ORAM_AR_DONE_L7_B32   1236
`define ORAM_AR_DONE_L7_B64   1959
`define ORAM_AR_DONE_L7_B128  3405
`define ORAM_AR_WB_L7 (`ORAM_BLOCK_BEATS == 1 ? `ORAM_AR_WB_L7_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_AR_WB_L7_B2 :  \
                       `ORAM_BLOCK_BEATS == 4 ? `ORAM_AR_WB_L7_B4 :  \
                       `ORAM_BLOCK_BEATS == 8 ? `ORAM_AR_WB_L7_B8 :  \
                       `ORAM_BLOCK_BEATS == 16 ? `ORAM_AR_WB_L7_B16 :  \
                       `ORAM_BLOCK_BEATS == 32 ? `ORAM_AR_WB_L7_B32 :  \
                       `ORAM_BLOCK_BEATS == 64 ? `ORAM_AR_WB_L7_B64 : `ORAM_AR_WB_L7_B128)
`define ORAM_AR_WB ((`ORAM_C == 7) ? `ORAM_AR_WB_L7 : `ORAM_AR_WB_L6)
`define ORAM_AR_DONE_L7 (`ORAM_BLOCK_BEATS == 1 ? `ORAM_AR_DONE_L7_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_AR_DONE_L7_B2 :  \
                       `ORAM_BLOCK_BEATS == 4 ? `ORAM_AR_DONE_L7_B4 :  \
                       `ORAM_BLOCK_BEATS == 8 ? `ORAM_AR_DONE_L7_B8 :  \
                       `ORAM_BLOCK_BEATS == 16 ? `ORAM_AR_DONE_L7_B16 :  \
                       `ORAM_BLOCK_BEATS == 32 ? `ORAM_AR_DONE_L7_B32 :  \
                       `ORAM_BLOCK_BEATS == 64 ? `ORAM_AR_DONE_L7_B64 : `ORAM_AR_DONE_L7_B128)
`define ORAM_AR_DONE ((`ORAM_C == 7) ? `ORAM_AR_DONE_L7 : `ORAM_AR_DONE_L6)
`define ORAM_AR_REL_L7 (`ORAM_BLOCK_BEATS == 1 ? `ORAM_AR_REL_L7_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_AR_REL_L7_B2 :  \
                       `ORAM_BLOCK_BEATS == 4 ? `ORAM_AR_REL_L7_B4 :  \
                       `ORAM_BLOCK_BEATS == 8 ? `ORAM_AR_REL_L7_B8 :  \
                       `ORAM_BLOCK_BEATS == 16 ? `ORAM_AR_REL_L7_B16 :  \
                       `ORAM_BLOCK_BEATS == 32 ? `ORAM_AR_REL_L7_B32 :  \
                       `ORAM_BLOCK_BEATS == 64 ? `ORAM_AR_REL_L7_B64 : `ORAM_AR_REL_L7_B128)
`define ORAM_AR_REL ((`ORAM_C == 7) ? `ORAM_AR_REL_L7 : `ORAM_AR_REL_L6)

// NOCRYPTO (build.sh NOCRYPTO=1: ORAM_NOCRYPTO, with Option A; docs/nocrypto.md; evaluation builds only). Every bucket,
// host memory included, takes the on-package plaintext path, so there is no decryption and re-encryption in any padded
// time. Each class of bucket (HBM, host) has two fixed times after its arrival: the write-back start (WBF, Option A's
// rule for both classes) and the release (REL). CT_RD is unchanged: it pads the position-map lookup, which has no crypto.
// Values per block size, lambda = 7, stash on RAMA, from sim/budgets_nocrypto.py: HBM buckets keep the baseline's times (build.sh FIXWB=1
// RAMA=1, card-proven; they have no crypto to remove); host buckets from simulation. vitis/calibrate_all_sizes.sh with NOCRYPTO=1 can
// replace them from the card (docs/nocrypto.md section 4). The FLOOR rows bound that calibration.
// Overrides: -DORAM_NC_WBF_H= -DORAM_NC_WBF= -DORAM_NC_REL_H= -DORAM_NC_REL= (build.sh WBF= WBF_HOST= REL= REL_HOST=).
`ifdef ORAM_NOCRYPTO
`define ORAM_NC_WBF_H_B1 607
`define ORAM_NC_REL_H_B1 659
`define ORAM_NC_WBF_B1 403
`define ORAM_NC_REL_B1 439
`define ORAM_NC_FLOOR_H_B1 182
`define ORAM_NC_FLOOR_B1 124
`define ORAM_NC_WBF_H_B2 603
`define ORAM_NC_REL_H_B2 663
`define ORAM_NC_WBF_B2 389
`define ORAM_NC_REL_B2 437
`define ORAM_NC_FLOOR_H_B2 176
`define ORAM_NC_FLOOR_B2 126
`define ORAM_NC_WBF_H_B4 595
`define ORAM_NC_REL_H_B4 672
`define ORAM_NC_WBF_B4 360
`define ORAM_NC_REL_B4 428
`define ORAM_NC_FLOOR_H_B4 162
`define ORAM_NC_FLOOR_B4 131
`define ORAM_NC_WBF_H_B8 579
`define ORAM_NC_REL_H_B8 690
`define ORAM_NC_WBF_B8 303
`define ORAM_NC_REL_B8 409
`define ORAM_NC_FLOOR_H_B8 139
`define ORAM_NC_FLOOR_B8 139
`define ORAM_NC_WBF_H_B16 547
`define ORAM_NC_REL_H_B16 725
`define ORAM_NC_WBF_B16 189
`define ORAM_NC_REL_B16 372
`define ORAM_NC_FLOOR_H_B16 157
`define ORAM_NC_FLOOR_B16 157
`define ORAM_NC_WBF_H_B32 530
`define ORAM_NC_REL_H_B32 843
`define ORAM_NC_WBF_B32 192
`define ORAM_NC_REL_B32 531
`define ORAM_NC_FLOOR_H_B32 192
`define ORAM_NC_FLOOR_B32 192
`define ORAM_NC_WBF_H_B64 626
`define ORAM_NC_REL_H_B64 1208
`define ORAM_NC_WBF_B64 263
`define ORAM_NC_REL_B64 914
`define ORAM_NC_FLOOR_H_B64 263
`define ORAM_NC_FLOOR_B64 263
`define ORAM_NC_WBF_H_B128 440
`define ORAM_NC_REL_H_B128 1669
`define ORAM_NC_WBF_B128 440
`define ORAM_NC_REL_B128 1688
`define ORAM_NC_FLOOR_H_B128 403
`define ORAM_NC_FLOOR_B128 403
`define ORAM_NC_SEL(b1, b2, b4, b8, b16, b32, b64, b128) (`ORAM_BLOCK_BEATS == 1 ? (b1) : `ORAM_BLOCK_BEATS == 2 ? (b2) : `ORAM_BLOCK_BEATS == 4 ? (b4) : `ORAM_BLOCK_BEATS == 8 ? (b8) : `ORAM_BLOCK_BEATS == 16 ? (b16) : `ORAM_BLOCK_BEATS == 32 ? (b32) : `ORAM_BLOCK_BEATS == 64 ? (b64) : `ORAM_BLOCK_BEATS == 128 ? (b128) : 0)
`ifndef ORAM_NC_WBF_H
`define ORAM_NC_WBF_H `ORAM_NC_SEL(`ORAM_NC_WBF_H_B1, `ORAM_NC_WBF_H_B2, `ORAM_NC_WBF_H_B4, `ORAM_NC_WBF_H_B8, `ORAM_NC_WBF_H_B16, `ORAM_NC_WBF_H_B32, `ORAM_NC_WBF_H_B64, `ORAM_NC_WBF_H_B128)
`endif
`ifndef ORAM_NC_WBF
`define ORAM_NC_WBF   `ORAM_NC_SEL(`ORAM_NC_WBF_B1, `ORAM_NC_WBF_B2, `ORAM_NC_WBF_B4, `ORAM_NC_WBF_B8, `ORAM_NC_WBF_B16, `ORAM_NC_WBF_B32, `ORAM_NC_WBF_B64, `ORAM_NC_WBF_B128)
`endif
`ifndef ORAM_NC_REL_H
`define ORAM_NC_REL_H `ORAM_NC_SEL(`ORAM_NC_REL_H_B1, `ORAM_NC_REL_H_B2, `ORAM_NC_REL_H_B4, `ORAM_NC_REL_H_B8, `ORAM_NC_REL_H_B16, `ORAM_NC_REL_H_B32, `ORAM_NC_REL_H_B64, `ORAM_NC_REL_H_B128)
`endif
`ifndef ORAM_NC_REL
`define ORAM_NC_REL   `ORAM_NC_SEL(`ORAM_NC_REL_B1, `ORAM_NC_REL_B2, `ORAM_NC_REL_B4, `ORAM_NC_REL_B8, `ORAM_NC_REL_B16, `ORAM_NC_REL_B32, `ORAM_NC_REL_B64, `ORAM_NC_REL_B128)
`endif
`undef ORAM_AR_WBF_H
`define ORAM_AR_WBF_H `ORAM_NC_WBF_H
`define ORAM_AR_WBF   `ORAM_NC_WBF
`undef ORAM_AR_WB_H
`undef ORAM_AR_REL_H
`undef ORAM_AR_DONE_H
`undef ORAM_AR_WB
`undef ORAM_AR_REL
`undef ORAM_AR_DONE
`define ORAM_AR_WB_H   `ORAM_NC_WBF_H
`define ORAM_AR_REL_H  `ORAM_NC_REL_H
`define ORAM_AR_DONE_H (`ORAM_NC_REL_H + (`ORAM_AR_DONE_H_L7 - `ORAM_AR_REL_H_L7))   // no RTL enforces AR_DONE (nor before); the allowance as before
`define ORAM_AR_WB     `ORAM_NC_WBF
`define ORAM_AR_REL    `ORAM_NC_REL
`define ORAM_AR_DONE   (`ORAM_NC_REL + (`ORAM_AR_DONE_L7 - `ORAM_AR_REL_L7))
`endif

// Phase 3 time-division arbiter: default slot length = padded access (completion
// gate) + result window + slack so a client that re-requests on completion (and
// must buffer a full write block) makes its next own slot.
`ifndef ORAM_TDM_SLOT
`define ORAM_TDM_SLOT (`ORAM_CT_DONE + 2*`BEATS_PER_BLOCK + 48)
`endif

`endif
