# DOMA as a Vitis RTL kernel (U55C), for a like-for-like comparison with BOLT

`rtl/doma_kernel.v` wraps the single-client DOMA in the Vitis RTL-kernel interface, so the same kind
of XRT host program that drives BOLT drives DOMA.

**Status:**
- **Simulated end to end** with Verilator (`sim/tb_doma_kernel.v`, regression group `kernel`). The
  testbench plays XRT: it writes the arguments and `ap_start` over AXI-Lite and polls `ap_done`.
- **The Vitis files in this folder are untested.** Vivado, Vitis and XRT were not available where they
  were written, so expect to adjust them on first use.

## What it mirrors from BOLT (read from BOLT-benchmark's xclbins and host code)

| | BOLT `chain_kernel` | `doma_kernel` |
|---|---|---|
| Platform, tools, clock | `xilinx_u55c_gen3x16_xdma_3_202210_1`, Vitis 2024.1, 300 MHz | same |
| Commands / responses | `cmd_input` HBM[6], `resp_output` HBM[7] | same banks |
| Off-package data | `pages` in HOST[0] (host DRAM over PCIe) | encrypted buckets in HOST[0] |
| Metadata | position map, stash, counts in HBM | position map, bucket metadata, IVs/tags, stash on chip |
| Call | one launch processes `size` commands | same |
| Query time | launch + `wait()`, commands staged on the card beforehand | same (`host_doma.cpp`) |
| Workload | mt19937 seed 1, 50% PUT, uniform keys, 5,000 commands | same generator; keys are dense slot numbers |

BOLT's repository ships only precompiled xclbins, so BOLT runs exactly as released. Its host code
for the experiments allocates 2,097,152 host pages of 8 tuples and fills each to at most 4, about
0.5 tuples per page at 1M entries. That is far lighter than the paper's c = 8, so report BOLT's
parameters as found and compare memory overhead.

## Interface

`doma_kernel(cmd_input, resp_output, pages, size)`, with control registers at 0x00 (`ap_start`,
`ap_done`, `ap_idle`, `ap_ready`), 0x04 GIE, 0x08 IER, 0x0C ISR, and the arguments at 0x10, 0x1C, 0x28
and 0x34.

**Buffers** (32-byte aligned; the host converts commands before timing starts):

| Buffer | Region | Contents |
|---|---|---|
| `cmd_input` | `[0, size*32)` | Headers: byte 0 type (0x01 GET, 0x02 PUT), bytes 4–7 key (slot) |
| | from `HC = roundup(size*32, 4 KB)` | PUT data, 4 KB per command |
| `resp_output` | record `i` | byte 0 0x10 ACK or 0x11 ERR; bytes 4–7 key; bytes 8–11 latency in cycles; bytes 12–15 status |
| | record `[size]` | Summary: 0x5A; bytes 8–15 total cycles; 16–19 min latency; 20–23 max latency; 24–27 errors; 28–31 completed |
| | from `HR = roundup((size+1)*32, 4 KB)` | GET data, 4 KB per command |

**Status and error flags:** 0x2 unknown opcode, 0x4 key outside the ORAM (rejected), 0x8 DOMA halted
(integrity failure or timing overrun), 0x10 command timeout. On 0x8 or 0x10 the run ends early, but
always with `ap_done` and the summary record.

**First launch:** run with `size = 0`. DOMA boots only now: it loads the key, lays out the buckets in
the `pages` buffer given at this launch (latched for the kernel's lifetime) and grants the lease. This
is the analogue of BOLT's `init_kernel`. `host_doma.cpp` then preloads every
slot and counts both steps as initialization time.

## On Windows

What runs in Windows Vivado (from the Vivado Tcl shell, Start menu > Vivado 2025.2 Tcl Shell):

    cd <package>/vitis
    vivado -mode batch -source synth_ooc.tcl -tclargs ../rtl                 # resources and timing on the U55C
    cd ../sim
    vivado -mode batch -source xsim_run.tcl -tclargs kernel                  # doma_kernel end to end in XSim
    vivado -mode batch -source xsim_run.tcl -tclargs kernel gui              # same, with waveforms

`package_kernel.tcl` (the `.xo`) should also run, since `package_xo` is a Vivado command.

**Needs Linux:**
- `v++` linking for the U55C (hardware emulation and the bitstream);
- XRT, and the U55C platform packages;
- the Verilator regression (`run_verilator.sh`);
- hosting the card itself.

On a Windows PC the practical route is WSL2 with Ubuntu 22.04 and the Linux installers of Vitis and
XRT. AMD does not officially support WSL2, but it is commonly used for builds. Allow well over
100 GB of disk and 32 GB or more of RAM for U55C builds. A lab Linux server works too, and the card
itself must go into a Linux machine.

## Without the card

    vivado -mode batch -source synth_ooc.tcl -tclargs ../rtl          # doma_kernel on the U55C part, 300 MHz
    vivado -mode batch -source synth_ooc.tcl -tclargs ../rtl xczu48dr-fsvg1517-2-e secure_oram_top clk 3.333

Out-of-context synthesis and place & route give resources and timing (`ooc_<top>/`) in well under an
hour, before any platform build. If hardware emulation rejects host memory, link with
`CFG=doma_emu.cfg`, which puts the buckets in HBM[8].

## Build (on a machine with Vitis 2024.1, XRT and the U55C platform)

    cd vitis
    TARGET=hw_emu bash build.sh     # no card needed: XCL_EMULATION_MODE=hw_emu ./host_doma doma_hw_emu.xclbin 200
    TARGET=hw     bash build.sh     # bitstream (hours); on the card: ./host_doma doma_hw.xclbin 5000

`package_kernel.tcl` packages `../rtl` into `doma_kernel.xo`. Synthesis defines `SYNTHESIS`, so the
production configuration is built with no debug ports. `doma.cfg` places the arguments. Host memory
must be enabled on the card (`xbutil configure --host-mem ...`; see AMD's XRT host-memory
documentation), as BOLT's own `host_only` buffers also require.

On-package budgets for the block sizes below 4 KB (v14c): `bash calibrate_all_sizes.sh all` builds a debug bitstream
per size, runs it at 100% and 20% on package, and prints each size's budgets and a summary table as text
(`bash calibrate_all_sizes.sh` alone prints the phases and settings; docs/v14c_report.md §3).

## Simulation results (`sim/tb_doma_kernel.v`, production build)

| Run | Device cycles | Latency min/max | Result |
|---|---|---|---|
| init (`size = 0`) | 168,604 | — | key, layout of 64 buckets, lease |
| 120 commands | 660,780 | 5,296 / 5,466 | every GET correct |
| 40 commands (second launch) | 214,608 | 5,296 / 5,466 | one out-of-range key rejected |

That is about 5,500 cycles per command (about 54 K operations per second at 300 MHz with 4 KB blocks).
With 30% gaps in host read data, latency is unchanged.

## If the kernel reports error 0x8 in emulation

The controller prints the cause in the emulation log:

    grep "DOMA HALT" .run/*/hw_emu/device0/binary_0/behav_waveform/xsim/simulate.log

Delete old build outputs before rebuilding after an RTL or budget change, so the IP packager cannot
reuse stale copies: `rm -rf doma_ip doma_pack doma_kernel.xo _x .ipcache`.

## Block size

- **Build:** `BEATS=8 TARGET=hw bash build.sh` builds 256-byte blocks (1, 2, 4, 8 beats = 32–256
  bytes); without `BEATS` it builds 4 KB. Rebuild the bitstream for each size.
- **Host:** `host_doma` reads the block size from the kernel's summary record after boot and lays out
  its data to match. Bitstreams from before this field report 0, and the host then assumes 4 KB.

## Metadata buffers (`meta`, `brec`, `stash`)

DOMA's trusted metadata lives in on-package HBM, in two kernel arguments:
- `meta`, the position map (48-bit entries, five per 32-byte beat), mapped to HBM[10];
- `brec`, the bucket records (64 bytes per bucket: the bucket's GCM metadata), mapped to HBM[11];
- `stash`, the stash (64-byte heads per bucket plus a pool of stash blocks: 16 bytes of metadata and the block
  each; the host sizes the pool from the stash bound), mapped to HBM[12] (HBM[12:14] or [12:15] in the large layouts).

`host_doma` allocates all three and passes them on every launch. DOMA latches them at the first launch, like
`pages`, and initializes them during boot.

## Packed records

`DOMA_PACK=1 ./host_doma <xclbin> 5000` packs `block ÷ 8` 8-byte records per block. Headers carry the
record's offset and length, PUTs write only that record (a masked write inside DOMA), and GETs return
the block with the record checked by the host. Unpacked runs are unchanged.

## Timing closure at 300 MHz

- **Board build:** `TARGET=hw ./build.sh` (default `CFG=doma.cfg`; `doma_big.cfg` for large N at 4 KB). Do not use
  `doma_hw.cfg`: it is the older layout with the bucket pages in HBM[8] instead of host memory. Both keep the kernel in SLR0 next to
  the HBM and the PCIe bridge, and sets aggressive optimization, placement, physical-optimization and
  routing directives. `build.sh` then runs `check_timing.sh`. That passes only if setup and hold slack
  are non-negative and the xclbin's kernel clock is 300 MHz; `v++` silently lowers the clock when
  timing fails.
- **Before a multi-hour build:** `vivado -mode batch -nojournal -nolog -source worst_paths.tcl` lists
  the 40 worst paths in `worst_paths.txt`, with resources in `worst_paths_util.txt`.
- **First board build (default settings): WNS = −8 ns.** The scratch-buffer banks had been coded with
  three write branches and two read branches, which synthesis could not map to block RAM. They became
  registers plus wide multiplexers. They are now coded as one write port and one registered read port,
  with identical behavior (the regression's timing hashes are unchanged).

## Before the board results mean anything

1. **PCIe latency.** With a 600-cycle (2 µs) host read latency, DOMA overruns its budget on the first
   access and halts. The kernel then ends the run with error 0x8 rather than hanging, and the
   regression checks this (since v11a at a host latency equal to the strict write-back gate,
   CT_WB + PM_LAT: with the two-lane core a 600-cycle read fits the strict budgets from 128 B up). The budgets (`ORAM_CT_WB`, `ORAM_CT_DONE`) must be recalibrated on the
   board with the derived-worst-case method, using the measured host-memory latency and its tail.
2. **Scale.** N = 256 slots, with all metadata on chip. BOLT's default is 1M entries; the IV/tag
   table alone would then be about 56 MB, which needs HBM.
3. **Record size.** DOMA moves 4 KB blocks, while BOLT's values are 8–256 bytes. Compare at matching
   record sizes, or report the bytes moved per access.


## Traffic record and response layout (shared with the Tiny ORAM kernel)

Since 2026-10-12, both kernels write two records after the per-command headers:
- **record `[size]`, the summary:** unchanged;
- **record `[size+1]`, traffic:**
  - byte 0: `0x5B`;
  - bytes 8–15: read beats on `gmem2` (the bucket port) during the launch;
  - bytes 16–23: write beats on it;
  - bytes 24–31: zero.

  Each is written as its own single-beat write: a 2-beat burst starting at `[size]` could cross a 4 KB
  boundary when `(size+1)·32` is a multiple of 4 KB.

**GET data therefore starts at `HR = roundup((size+2)·32, 4 KB)`** (previously `(size+1)`), for both kernels.
`host_doma` prints, after the device line:

    traffic: bucket port X B read, Y B written = A B read, B B written per command

The boot launch counts the boot traffic (at N = 256, 32-byte blocks: 384 write beats, the format of 64
buckets × 6 positions). A query moves one bucket each way per command: 192 B at 32-byte blocks, 24,576 B
at 4 KB. The kernel testbench counts `gmem2` handshakes itself and requires the record to match exactly at
every launch. Older bitstreams don't write the record; the host then prints no traffic line.

## DOMA without encryption, for the comparison with BOLT

`NOCRYPTO=1 FIXWB=1 SCHED=arrival LAMBDA=7 BEATS=<1 .. 128> ...`: every bucket in plaintext, evaluation only. Build commands,
fixed times and the card calibration: `docs/nocrypto.md`.

## Bitstreams for the N and HBM-share sweeps (Z = 10)

`build.sh` writes the block size into the shared `../rtl/oram_build_cfg.vh` and always names its output
`doma_hw.xclbin`, so **build each configuration in its own copy of the package** (two builds in one directory
overwrite each other). Before starting one, check that none is running there (`pgrep -fa "v\+\+|vivado"`).
```
cp -r ~/fpga_zcu208 ~/doma_b1   && cd ~/doma_b1/vitis
BEATS=1 NMAX=4194304 SCHED=arrival TARGET=hw nohup bash build.sh > build.log 2>&1 &     # 32 B, N up to 2^22
cp -r ~/fpga_zcu208 ~/doma_b128 && cd ~/doma_b128/vitis
NMAX=1048576 SCHED=arrival CFG=doma_big.cfg TARGET=hw nohup bash build.sh > build.log 2>&1 &   # 4 KB, N up to 2^20
```
`build.sh` ends with `check_timing.sh` (pass: 300 MHz, setup and hold met) and compiles `host_doma`.

**Capacity** (Z = 10, compact buckets: 10 blocks per bucket, 1.25 blocks of bucket space per record):

| Build | Layout | Largest N | HBM share at that N |
|---|---|---|---|
| 32 B, `doma.cfg` | stash HBM[12], HBM buckets HBM[8] (512 MB each) | 4M (2^22): buckets 160 MB in all | any (0-100%) |
| 4 KB, `doma_big.cfg` | stash HBM[12:14] (1.5 GB), HBM buckets HBM[16:23] (4 GB) | ~1M: stash pool ~1.2 GB, buckets 5 GB | up to ~80% at 1M, 100% up to ~800K |
| 4 KB, `doma.cfg` | 512 MB each | ~400K (stash pool) | up to ~25% at 400K |

Host memory (HOST[0], 8 GB) holds the buckets not in HBM: at 4 KB that is N x 5 KB x (1 - share).

**Scan** (after the build, in its `vitis/` folder; every response is verified):
```
NS="16384 65536 262144 1048576 4194304" HBMS="0 10 20 30 50 100" bash scan.sh doma_hw.xclbin 20000   # 32 B
NS="16384 65536 262144 1048576" HBMS="0 10 20 30 50 80" bash scan.sh doma_hw.xclbin 20000           # 4 KB
```
`scan.sh` takes the block size from the kernel (a short probe run), or set `DOMA_BLOCK` yourself. One CSV row per (N, share): KQPS, device cycles, per-command latency range, completions, errors, wrong responses,
pool size, init time, and the first error line if a run fails. The stash pool is sized per run from Claim 1
(`DOMA_POOL` overrides). Heads take 64 bytes per bucket in the stash buffer (two beats at the 2^22 build).
