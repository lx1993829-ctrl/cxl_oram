#!/bin/bash
# calibrate_all_sizes.sh -- v14c: the card calibration of the on-package budgets (AR_WB_H, AR_REL_H, AR_DONE_H) for
# every block size below 4 KB at lambda 7, as one batch: build the debug bitstreams, run them, report, write.
# Everything it reports is printed as text (and kept in cal/report.txt); nothing has to be copied off the server.
#
#   bash calibrate_all_sizes.sh build  [SIZES]   # debug bitstreams (DEBUG=1 TRACE=1 SCHED=arrival LAMBDA=7), JOBS at once
#   bash calibrate_all_sizes.sh timing [SIZES]   # each bitstream's kernel clock (check_timing.sh)
#   bash calibrate_all_sizes.sh run    [SIZES]   # 100% and 20% on package, ACC accesses each, per-access records (CSV)
#   bash calibrate_all_sizes.sh report [SIZES]   # sim/card_budgets.py per size, then one summary table and the defines
#   bash calibrate_all_sizes.sh write  [SIZES]   # write the defines into ../rtl/oram_params.vh (the production tree)
#   bash calibrate_all_sizes.sh all    [SIZES]   # build, timing, run, report (not write)
#
# SIZES: block sizes in 32-byte beats, default "1 2 4 8 16 32 64" (32 B .. 2 KB); 128 (4 KB) on request, e.g.
#   bash calibrate_all_sizes.sh all 128
# v14d, 4 KB: calibrated at the build's largest record count (NMAX_128, default 2,097,152: the stash then spans all of
# HBM[12:15], its slowest layout), at 20% and 50% on package (100% does not fit in HBM at 2M records), with
# CFG_128=doma_big2m.cfg. The budgets must hold at every record count up to NMAX; the largest count is the worst.
# Environment:
#   JOBS=2          bitstream builds at once (each needs ~32 GB and several hours)
#   CFG=doma.cfg    the connectivity file of the production builds (the stash must sit where production puts it);
#                   CFG_<beats>=... per size (4 KB default: doma_big2m.cfg)
#   NMAX=<n>        the production build's NMAX (or NMAX_<beats>=<n> per size); unset: build.sh's default
#                   (4 KB default: NMAX_128=2097152)
#   ACC=1048576     accesses per run (per on-package share); the card's 4 KB calibration used 12.5M in all
#   PCTS="100 20"   on-package shares to run (PCTS_<beats>=... per size; 4 KB default "20 50")
#   PCT=10          the margin (percent) for the budgets; ABS=74 the absolute margin
#   CMDS=65536      commands per launch (host_phases' argument)
#   DOMA_N, DOMA_POOL, ... (or DOMA_N_<beats>=...): passed to host_phases unchanged; use the production values
#                   (4 KB default: DOMA_N_128 = the largest multiple of 7 <= NMAX_128: 2,097,151)
#   CAL=cal         the work folder (one subfolder per size: its own rtl/ and vitis/ copy, logs, CSVs)
# Each size builds in its own copy of rtl/ and vitis/ (build.sh writes rtl/oram_build_cfg.vh), so builds can run in
# parallel and the production tree is untouched until "write".
# NOCRYPTO=1 (docs/nocrypto.md section 4): the NOCRYPTO build's times instead, 32 B - 4 KB by default (or SIZES), in cal_nc/: debug
# bitstreams with NOCRYPTO=1 FIXWB=1, runs at 20% (both classes) and 100% on package (4 KB: 20 and 50%), sim/card_budgets_nc.py
# for the report and "write". Defaults at every size, as the baseline: NMAX 2,097,152 (DOMA_N the largest multiple of
# lambda below it); CFG=doma_big2m_rama.cfg at every size (build.sh refuses another). NMAX=, DOMA_N= or NMAX_<beats>= etc. override them.
# Only host buckets' times are written: HBM buckets keep the baseline's. CAL_HBM=1 writes the HBM values too.
set -uo pipefail
cd "$(dirname "$0")"
VIT=$(pwd); ROOT=$(cd .. && pwd)
PHASE=${1:-}; shift || true
NOCRYPTO=${NOCRYPTO:-0}
if [ "$NOCRYPTO" = 1 ]; then SIZES=${*:-"1 2 4 8 16 32 64 128"}; CAL=${CAL:-$ROOT/cal_nc}; PCTS=${PCTS:-"20 100"}; NCB="NOCRYPTO=1 FIXWB=1 RAMA=1"
else SIZES=${*:-"1 2 4 8 16 32 64"}; CAL=${CAL:-$ROOT/cal}; PCTS=${PCTS:-"100 20"}; NCB=""; fi
if [ "$NOCRYPTO" = 1 ]; then
    for b in 1 2 4 8 16 32 64 128; do
        nd=2097152
        cd=doma_big2m_rama.cfg
        nv="NMAX_$b"; dv="DOMA_N_$b"; cv="CFG_$b"
        eval "$nv=\${$nv:-\${NMAX:-$nd}}"; eval "$dv=\${$dv:-\${DOMA_N:-\$(( $nv / 7 * 7 ))}}"; eval "$cv=\${$cv:-\${CFG:-$cd}}"
        export "$nv" "$dv" "$cv"
    done
fi
JOBS=${JOBS:-2}; CFG=${CFG:-doma.cfg}; ACC=${ACC:-1048576}; PCT=${PCT:-10}; ABS=${ABS:-74}
CMDS=${CMDS:-65536}
# v14d: 4 KB defaults (each can be overridden by the same variable)
NMAX_128=${NMAX_128:-2097152}; DOMA_N_128=${DOMA_N_128:-$(( NMAX_128 / 7 * 7 ))};   # the largest multiple of lambda the build serves
 PCTS_128=${PCTS_128:-"20 50"}; CFG_128=${CFG_128:-doma_big2m.cfg}
export NMAX_128 DOMA_N_128 PCTS_128 CFG_128
mkdir -p "$CAL"
LOG="$CAL/report.txt"
say() { echo "$*" | tee -a "$LOG"; }
var() { local v="${1}_$2"; echo "${!v:-${!1:-}}"; }      # var NAME beats: NAME_<beats>, else NAME

for b in $SIZES; do
    case $b in 1|2|4|8|16|32|64|128) ;; *) echo "size $b: not one of 1 2 4 8 16 32 64 128 beats"; exit 1 ;; esac
done

prep() {   # prep <beats>: the size's own copy of rtl/ and vitis/
    local d="$CAL/b$1"
    if [ ! -d "$d/vitis" ]; then
        mkdir -p "$d"; cp -r "$ROOT/rtl" "$d/rtl"; cp -r "$VIT" "$d/vitis"; rm -rf "$d/vitis/_x" "$d/vitis/"*.xclbin
    fi
}

build_one() {   # build_one <beats>
    local b=$1 d="$CAL/b$1" n c
    prep "$b"; n=$(var NMAX "$b"); c=$(var CFG "$b")
    echo "$(date +%T) build b$b ($((b * 32)) B) started" >> "$CAL/progress.log"
    ( cd "$d/vitis" && TARGET=hw CFG="$c" BEATS=$b LAMBDA=7 SCHED=arrival TRACE=1 DEBUG=1 env $NCB ${n:+NMAX=$n} bash build.sh ) \
        > "$d/build.log" 2>&1
    local rc=$?
    echo "$(date +%T) build b$b exit $rc ($([ -f "$d/vitis/doma_hw.xclbin" ] && echo "xclbin written" || echo "no xclbin"))" >> "$CAL/progress.log"
    return $rc
}
export -f build_one prep var; export CAL ROOT VIT CFG NMAX_128 DOMA_N_128 PCTS_128 CFG_128 NCB

timing_one() {   # the kernel clock v++ achieved -> cal/b<B>/mhz
    local b=$1 d="$CAL/b$1"
    [ -f "$d/vitis/doma_hw.xclbin" ] || { say "b$b: no bitstream ($d/vitis/doma_hw.xclbin)"; return 1; }
    ( cd "$d/vitis" && ./check_timing.sh ) > "$d/timing.txt" 2>&1
    local mhz; mhz=$(grep -oE "kernel clock in doma_hw.xclbin: [0-9.]+ MHz" "$d/timing.txt" | grep -oE "[0-9.]+ MHz" | grep -oE "[0-9.]+")
    [ -n "$mhz" ] || { say "b$b: kernel clock unknown (see $d/timing.txt); assuming 300 MHz"; mhz=300; }
    echo "$mhz" > "$d/mhz"
    say "b$b ($((b * 32)) B): kernel clock $mhz MHz; $(grep -E "^(PASS|FAIL|WARN)" "$d/timing.txt" | head -1)"
}

run_one() {   # 100% and 20% on package with per-access records
    local b=$1 d="$CAL/b$1" p n pool
    [ -f "$d/vitis/doma_hw.xclbin" ] || { say "b$b: no bitstream"; return 1; }
    [ -x "$VIT/host_phases" ] || g++ -std=c++17 -O2 "$VIT/host_phases.cpp" -I"${XILINX_XRT:?source XRT setup.sh first}/include" -L"$XILINX_XRT/lib" \
        -lxrt_coreutil -pthread -o "$VIT/host_phases" || { say "cannot build host_phases"; return 1; }
    n=$(var DOMA_N "$b"); pool=$(var DOMA_POOL "$b")
    for p in $(var PCTS "$b"); do
        say "$(date +%T) b$b: run at $p% on package, $ACC accesses"
        # v14d: run from the calibrated build's own vitis/ folder: host_phases checks lambda (and Z) against
        # ../rtl/oram_build_cfg.vh, which only the size's own copy has (build.sh wrote it there; the main tree's is empty)
        ( cd "$d/vitis" && env DOMA_LAMBDA=7 DOMA_BLOCK=$((b * 32)) ${n:+DOMA_N=$n} ${n:+DOMA_NMAX=$(var NMAX "$b")} ${pool:+DOMA_POOL=$pool} \
            DOMA_HBM_PCT=$p DOMA_PHASE_TRACE=1 DOMA_ONPKG_CSV="$d/onpkg$p.csv" DOMA_PHASES="mix:$ACC" \
            "$VIT/host_phases" "$d/vitis/doma_hw.xclbin" "$CMDS" ) > "$d/run$p.log" 2>&1
        say "  exit $?; $(grep -cE '^' "$d/onpkg$p.csv" 2>/dev/null || echo 0) records; $(grep -E 'DEBUG BITSTREAM|on-package calibration \(whole run' "$d/run$p.log" | head -2 | tr '\n' ' ')"
        grep -E "halt record|errors 0x|FAIL|cannot" "$d/run$p.log" | head -5 | sed 's/^/  /' | tee -a "$LOG"
    done
}

report_one() {   # card_budgets.py on the size's CSVs
    local b=$1 d="$CAL/b$1" f="" p mhz
    for p in $(var PCTS "$b"); do [ -s "$d/onpkg$p.csv" ] && f="$f $d/onpkg$p.csv"; done
    [ -n "$f" ] || { say "b$b: no records"; return 1; }
    mhz=$(cat "$d/mhz" 2>/dev/null || echo 300)
    if [ "$NOCRYPTO" = 1 ]; then
        python3 "$ROOT/sim/card_budgets_nc.py" --beats "$b" --pct "$PCT" --abs "$ABS" --mhz "$mhz" --params "$ROOT/rtl/oram_params.vh" ${CAL_HBM:+--hbm} $f > "$d/budgets.txt" 2>&1
    else
    python3 "$ROOT/sim/card_budgets.py" --beats "$b" --pct "$PCT" --abs "$ABS" --mhz "$mhz" --params "$ROOT/rtl/oram_params.vh" $f \
        > "$d/budgets.txt" 2>&1
    fi
    say ""; say "==================== b$b ($((b * 32)) B), kernel clock $mhz MHz ===================="
    tee -a "$LOG" < "$d/budgets.txt"
}

case "$PHASE" in
    build)
        say "$(date +%T) building debug bitstreams for: $SIZES ($JOBS at once; progress in $CAL/progress.log)"
        printf "%s\n" $SIZES | xargs -P "$JOBS" -I{} bash -c 'build_one {}'
        for b in $SIZES; do say "b$b: $([ -f "$CAL/b$b/vitis/doma_hw.xclbin" ] && echo "bitstream built" || echo "BUILD FAILED (see $CAL/b$b/build.log)")"; done ;;
    timing) for b in $SIZES; do timing_one "$b"; done ;;
    run)    for b in $SIZES; do run_one "$b"; done ;;
    report|write)
        : > "$CAL/summary.txt"
        for b in $SIZES; do report_one "$b" && grep -E "^SUMMARY " "$CAL/b$b/budgets.txt" >> "$CAL/summary.txt"; done
        say ""; say "==================== summary (lambda 7, margin $PCT% + $ABS) ===================="
        if [ "$NOCRYPTO" = 1 ]; then
            while read -r l; do say "$l"; done < "$CAL/summary.txt"
            say ""; say "defines for rtl/oram_params.vh (the regression: sim/run_nocrypto.sh; rerun it after write):"
            for b in $SIZES; do grep -E "^\`define" "$CAL/b$b/budgets.txt" 2>/dev/null | tee -a "$LOG"; done
            if [ "$PHASE" = write ]; then for b in $SIZES; do
                f=""; for p in $(var PCTS "$b"); do [ -s "$CAL/b$b/onpkg$p.csv" ] && f="$f $CAL/b$b/onpkg$p.csv"; done
                [ -n "$f" ] && python3 "$ROOT/sim/card_budgets_nc.py" --beats "$b" --pct "$PCT" --abs "$ABS" --mhz "$(cat "$CAL/b$b/mhz" 2>/dev/null || echo 300)" \
                    --params "$ROOT/rtl/oram_params.vh" ${CAL_HBM:+--hbm} --write $f | grep -E "^written" | tee -a "$LOG"
            done; fi
            exit 0
        fi
        say "$(printf '%-7s %6s %10s %8s %8s | %8s %8s | %8s %8s %9s | %9s %10s' size MHz on-pkg 'max ws' 'max rg' 'card WB' 'card REL' AR_WB_H AR_REL_H AR_DONE_H 'vs v11g' 'halts/20M')"
        say "$(printf '%-7s %6s %10s %8s %8s | %8s %8s | %8s %8s %9s | %9s %10s' '' '' accesses cycles cycles '' '' final final final 'earlier' expected)"
        while read -r _ kv; do
            eval "$kv"
            say "$(printf '%-7s %6s %10s %8s %8s | %8s %8s | %8s %8s %9s | %9s %10s' "$((beats * 32)) B" "$mhz" "$n" "$wsmax" "$rgmax" "$wbc" "$relc" "$wb" "$rel" "$done" "$v11" "$halts")"
            [ "$v11" -lt 0 ] 2>/dev/null && say "  ** $((beats * 32)) B: the on-package release would be $(( -v11 )) cycles LATER than v11g's encrypted path: report this before building"
        done < "$CAL/summary.txt"
        say ""; say "defines for rtl/oram_params.vh:"
        for b in $SIZES; do grep -E "^\`define" "$CAL/b$b/budgets.txt" 2>/dev/null | tee -a "$LOG"; done
        if [ "$PHASE" = write ]; then
            for b in $SIZES; do
                f=""; for p in $(var PCTS "$b"); do [ -s "$CAL/b$b/onpkg$p.csv" ] && f="$f $CAL/b$b/onpkg$p.csv"; done
                [ -n "$f" ] && python3 "$ROOT/sim/card_budgets.py" --beats "$b" --pct "$PCT" --abs "$ABS" --mhz "$(cat "$CAL/b$b/mhz" 2>/dev/null || echo 300)" \
                    --params "$ROOT/rtl/oram_params.vh" --write $f | grep -E "^(chosen|written)" | tee -a "$LOG"
            done
            say "then: rerun the regression (sim/run_verilator.sh, every size at lambda 7) and build the production bitstreams"
        fi ;;
    all) S="$VIT/$(basename "$0")"; bash "$S" build $SIZES && bash "$S" timing $SIZES && bash "$S" run $SIZES && bash "$S" report $SIZES ;;
    *) sed -n '2,34p' "$0"; exit 1 ;;
esac
