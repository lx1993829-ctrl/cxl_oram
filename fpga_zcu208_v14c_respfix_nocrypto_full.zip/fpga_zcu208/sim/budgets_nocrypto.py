#!/usr/bin/env python3
"""budgets_nocrypto.py -- the NOCRYPTO build's padded fixed times (docs/nocrypto.md), from sim/calibrate_nocrypto.sh's runs.

    python3 budgets_nocrypto.py --show  CALDIR [BEATS ...]
    python3 budgets_nocrypto.py --write PARAMS CALDIR [BEATS ...]      writes ORAM_NC_{WBF,REL,FLOOR}{,_H}_B<b> into PARAMS

CALDIR/b<b>/ holds the logs of one size, by memory profile: adv_*.log (every metadata read at 200 cycles, host reads at 240: the v14
adverse profile), slow_*.log (a slower stash on RAMA: 120-cycle reads, 40% data gaps, no same-ID blocking; sim/run_rama_base.sh's model)
and nom_*.log (the testbench's HBM profile, the directed worst cases at fixed latencies). Each has "nocrypto:" readout lines, per class of bucket:
  need  the earliest write-back time after the arrival that serves an access hold-free (the decisions done, every eviction
        copy in time for the write), worst over the run; wr  the write, issue to last beat accepted, worst over the run.

HBM buckets have no crypto to remove: their path is the baseline's (build.sh FIXWB=1 RAMA=1), so they keep the baseline's card-proven
WBF and REL at every size (BASE below; docs/rama_sizes.md). Their worst need is printed against that WBF, and run_nocrypto.sh checks it.
Host buckets lose decryption and re-encryption; their rules, per block size b (beats), cycles at 300 MHz, with M(x) = ceil(1.10 x) + 74:
  WBF   = M(worst need, any profile)        the write-back time after the arrival (Option A's rule); at 4 KB the baseline's 440, the
                                            start the card calibrated with RAMA (the decisions are the same)
  REL   = WBF + max(the class's hand-off allowance, ceil(1.10 worst write)). The allowance is the one its write has had since
          v11b, for a write started at a fixed time:
            host: ceil(1.2 (8 b + 2 bursts + 22)), 36 at 32 B (AR_REL_L7 - AR_WB_L7, unchanged by lambda)
            HBM:  max(36, ceil(1.05 (8 b + 2 bursts + 22)))
  FLOOR = M(worst need, nominal profile)    the lowest WBF the card calibration may set (normal memory only: the card's own
                                            worst decides above it): the directed worst paths are not
                                            sure to occur in a random card run (sim/card_budgets_nc.py)
"""
import glob, math, os, re, sys

Z = 8

def bursts(b): return math.ceil(Z * b * 32 / 4096)
def rel_host(b): return {1: 36, 128: 1248}.get(b, math.ceil(1.2 * (Z * b + 2 * bursts(b) + 22)))
def rel_hbm(b): return max(36, math.ceil(1.05 * (Z * b + 2 * bursts(b) + 22)))
def M(x): return math.ceil(x * 1.10 - 1e-9) + 74
# The card, stash on RAMA (Option A + RAMA, debug build, 2.46M on-package accesses, 300 MHz; docs/nocrypto.md): worst write-back start,
# worst write (release gate - write-back start). The stash was ready before every arrival, so the same holds for a later host arrival.
CARD = {128: dict(need=299, wr=1030)}
# The baseline's on-package times (rtl/oram_params.vh, ORAM_ONPKG_RAMA): WBF, REL, per block size
BASE = {1: (607, 659), 2: (603, 663), 4: (595, 672), 8: (579, 690), 16: (547, 725), 32: (530, 843), 64: (626, 1208), 128: (440, 1669)}

RE = re.compile(r"nocrypto: accesses=(\d+) need_host=(\d+) need_hbm=(\d+) dec_host=(\d+) dec_hbm=(\d+) wr_host=(\d+) wr_hbm=(\d+)")

def measure(d):
    out = {p: dict(need=[0, 0], dec=[0, 0], wr=[0, 0], n=0, logs=0) for p in ("adv", "slow", "nom")}
    for prof in out:
        for f in sorted(glob.glob(f"{d}/{prof}_*.log")):
            t = open(f, errors="replace").read()
            if "DOMA HALT" in t or "FAIL" in t.replace("FAILURE(S)", "") and "ALL CHECKS PASSED" not in t and "ct_overrun=0" not in t:
                sys.exit(f"budgets_nocrypto.py: {f} did not run clean")
            m = None
            for m in RE.finditer(t): pass
            if not m: sys.exit(f"budgets_nocrypto.py: no readouts in {f}")
            v = list(map(int, m.groups())); e = out[prof]
            e["n"] += v[0]; e["logs"] += 1
            for i, k in enumerate(("need", "dec", "wr")):
                e[k][0] = max(e[k][0], v[1 + 2 * i]); e[k][1] = max(e[k][1], v[2 + 2 * i])
    return out

def table(caldir, sizes):
    rows = []
    for b in sizes:
        x = measure(f"{caldir}/b{b}"); a, l, n = x["adv"], x["slow"], x["nom"]
        w = max(a["wr"][1], l["wr"][1], n["wr"][1]), max(a["wr"][0], l["wr"][0], n["wr"][0])       # HBM, host
        r = dict(b=b, n=a["n"] + l["n"] + n["n"], logs=a["logs"] + l["logs"] + n["logs"],
                 F_adv_h=a["need"][1], F_adv=a["need"][0], F_slow_h=l["need"][1], F_slow=l["need"][0], F_nom_h=n["need"][1], F_nom=n["need"][0],
                 wr_h=w[0], wr=w[1])
        c = CARD.get(b)
        r["WBF_H"], r["REL_H"] = BASE[b]
        r["A_H"] = r["REL_H"] - r["WBF_H"]
        r["WBF"] = BASE[b][0] if c else M(max(r["F_adv"], r["F_slow"], r["F_nom"]))
        if c: r["wr_h"] = max(r["wr_h"], c["wr"])
        r["A"] = max(rel_host(b), math.ceil(r["wr"] * 1.10 - 1e-9))
        r["REL"] = r["WBF"] + r["A"]
        r["FLOOR_H"], r["FLOOR"] = M(r["F_nom_h"]), M(r["F_nom"])
        r["FA_H"], r["FA"] = max(rel_hbm(b), math.ceil(r["wr_h"] * 1.10 - 1e-9)), r["A"]   # the write allowance at the floor
        rows.append(r)
    return rows

def show(rows):
    print("block | class | worst need: adverse / slower stash / nominal | WBF = M(worst) | write, allowance | REL = WBF + allowance | FLOOR = M(nominal) | REL at FLOOR")
    for r in rows:
        for c, s, l in (("HBM ", "_H", "_h"), ("host", "", "")):
            print(f"{r['b'] * 32:4d} B | {c} | {r['F_adv' + l]:4d} / {r['F_slow' + l]:4d} / {r['F_nom' + l]:4d} | WBF {r['WBF' + s]:4d} | write {r['wr' + l]:4d}, allowance {r['A' + s]:4d} | "
                  f"REL {r['REL' + s]:4d} | FLOOR {r['FLOOR' + s]:3d} | {r['FLOOR' + s] + r['FA' + s]:4d}   ({r['logs']} runs, {r['n']} accesses)")

def main(a):
    if len(a) < 2 or a[0] not in ("--show", "--write"): sys.exit(__doc__)
    params = None
    if a[0] == "--write": params = a[1]; a = a[1:]
    caldir = a[1]; sizes = [int(x) for x in a[2:]] or [1, 2, 4, 8, 16, 32, 64, 128]
    rows = table(caldir, sizes); show(rows)
    if params:
        raw = open(params, newline="").read(); crlf = "\r\n" in raw; s = raw.replace("\r\n", "\n")
        for r in rows:
            for k, v in (("WBF_H", r["WBF_H"]), ("REL_H", r["REL_H"]), ("WBF", r["WBF"]), ("REL", r["REL"]), ("FLOOR_H", r["FLOOR_H"]), ("FLOOR", r["FLOOR"])):
                pat = re.compile(r"^(`define ORAM_NC_%s_B%d +)\d+" % (k, r["b"]), re.M)
                if len(pat.findall(s)) != 1: sys.exit(f"budgets_nocrypto.py: ORAM_NC_{k}_B{r['b']} not found exactly once")
                s = pat.sub(lambda m: m.group(1) + str(v), s)
        open(params, "w", newline="").write(s.replace("\n", "\r\n") if crlf else s)
        print(f"written {params}")

if __name__ == "__main__":
    main(sys.argv[1:])
