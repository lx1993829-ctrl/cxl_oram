#!/bin/bash
# run_nocrypto.sh -- regression of the NOCRYPTO build (docs/nocrypto.md): no AES-GCM, every bucket on the plaintext path, on
# Option A's schedule for both classes, at every block size from 32 B to 4 KB, lambda 7, 4,096 records. Per block size:
#   Builds, from the same RTL: nc (production), nct (traced), ncd (debug), ncl (production with TB_NC_LEAK, the negative
#     control), nctd / ncth (debug / production with write-back times far too early), base (Option A, with encryption).
#   1. every run: all responses correct, eviction scoreboard 0 wrong, no halt;
#   2. every access (check_nocrypto.py): no crypto activity; the read at one offset; the write at exactly t_arr + WBF(class),
#      hold-free; the release at exactly t_arr + REL(class); the end one offset after it, whatever the arrival;
#   3. the fixed times hold: worst need <= WBF, worst write < REL - WBF, in every run;
#   4. what is visible does not depend on secrets or hidden memory speed: visible hashes (bucket-port timing, off-package
#      shape, on-package release/end) identical across the GET / PUT mix, and across the position map, records and stash at
#      their nominal speed, at 200 cycles a read and with the card-like stash;
#   5. the same ORAM as Option A: same accesses, evictions, read issue; identical HBM write digest, address digests;
#   6. no encryption: after the run every bucket, host memory included, holds its blocks in plaintext and every record's IV/tag
#      beat is zero (inspect_check.py --nocrypto, memories started with junk, 0 / 20 / 100% on package);
#   7. enforcement, both classes: decisions slowed, a write held, and times too early each stop the build by a fail-stop halt,
#      at exactly t_arr + REL, naming the deadline, never a wrong answer;
#   8. the debug records: every word equal to the testbench's view, and deadline (1) flagged exactly when word 12 (the
#      calibration's need) is after WBF, with the times far too early so that many accesses miss;
#   9. the negative control: a PUT's write one cycle late (TB_NC_LEAK): checks 2 and 4 must catch it;
#  10. packed records at 32 B: 8-byte and 16-byte values (+packed);
#  11. host_doma through the XRT mock, at each size's NMAX (HOSTSEQ=1, one size at a time).
# Usage: bash run_nocrypto.sh [BEATS ...]    default 1 2 4 8 16 32 64 128. Logs: build/nocrypto/b<beats>/. J=<jobs> (default nproc).
#        REUSE=1 keeps builds and finished runs. HOSTSEQ=1 also runs check 11.
set -u
cd "$(dirname "$0")"
SIM=$(pwd); RTL=$(cd "${RTL_DIR:-../rtl}" && pwd); SIZES=${*:-1 2 4 8 16 32 64 128}; J=${J:-$(nproc)}; REUSE=${REUSE:-0}
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
# what the Vivado project holds with NOCRYPTO=1 (vitis/package_kernel.tcl): no AES-GCM or GHASH source, so a stray dependency stops the build
SRCS_NC=$(grep -vE '^(aes|ghash)' files_rtl.lst | sed "s#^#$RTL/#" | tr '\n' ' ')
TOP=$SIM/build/nocrypto; mkdir -p $TOP
pass=0; fail=0
ok() { echo "PASS  $*"; pass=$((pass+1)); }
bad() { echo "FAIL  $*"; fail=$((fail+1)); }
pv() { grep -E "^\`define $1 " $RTL/oram_params.vh | tr -d '\r' | awk '{print $3}'; }
VF="--binary --timing -j 2 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-BLKANDNBLK -I$RTL"
build() {   # build <dir> <defines...>
    local d=$1; shift; local try
    [ "$REUSE" = 1 ] && [ -x $d/V ] && return 0
    local src=$SRCS; case " $* " in *" -DORAM_NOCRYPTO "*) src=$SRCS_NC ;; esac
    for try in 1 2 3 4; do
        rm -rf $d; verilator $VF -DORAM_C=7 -DORAM_N=4096 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -DORAM_ONPKG_FIXWB -DORAM_ONPKG_RAMA "$@" \
            --top-module tb_doma_kernel tb_doma_kernel.v oram_timing_monitor.v axi_mem_model.v $src $RTL/doma_kernel.v -Mdir $d -o V > $d.build.log 2>&1 && return 0
        grep -q "Internal Error" $d.build.log || break
    done
    [ -x $d/V ] && return 0
    echo "BUILD FAILED $d ($d.build.log)"; exit 1
}
clean() { grep -q "ALL CHECKS PASSED" $1 && grep -q "eviction scoreboard: .* 0 wrong" $1 && ! grep -q "DOMA HALT" $1; }
vis() { grep -E "^[a-z0-9]+: (bucket-port timing hash|folded off-package shape hash|off-package access shape hash|on-package release/end hash|traffic record)|^\*\*\* DOMA" $1; }
for B in $SIZES; do
    O=$TOP/b$B; mkdir -p $O
    W_H=$(pv ORAM_NC_WBF_H_B$B); W=$(pv ORAM_NC_WBF_B$B); R_H=$(pv ORAM_NC_REL_H_B$B); R=$(pv ORAM_NC_REL_B$B)
    T="$W_H $W $R_H $R"
    echo "== $((B*32)) B: WBF $W_H (HBM) / $W (host), REL $R_H / $R"
    D="-DORAM_BLOCK_BEATS=$B -DORAM_NOCRYPTO"
    ( build $O/nc $D ) & ( build $O/nct $D -DORAM_PHASE_TRACE ) & ( build $O/ncd $D -DORAM_PHASE_TRACE -DORAM_ONPKG_DEBUG ) &
    ( build $O/ncl $D -DTB_NC_LEAK ) & wait
    # the baseline: Option A + RAMA, exactly as build.sh FIXWB=1 RAMA=1 BEATS=<beats> configures it
    ( build $O/base -DORAM_BLOCK_BEATS=$B ) &
    ( build $O/nctd $D -DORAM_PHASE_TRACE -DORAM_ONPKG_DEBUG -DORAM_NC_WBF_H=30 -DORAM_NC_WBF=30 ) &
    ( build $O/ncth $D -DORAM_NC_WBF_H=30 -DORAM_NC_WBF=30 ) &
    # the times the card calibration may reach at most: FLOOR (sim/budgets_nocrypto.py), for the expected performance after it
    # (the HBM write's allowance at the floor: as budgets_nocrypto.py prints it, not the baseline's wider REL - WBF)
    FH=$(pv ORAM_NC_FLOOR_H_B$B); FO=$(pv ORAM_NC_FLOOR_B$B)
    FAH=$(python3 -c "import math; b=$B; print(max(max(36, math.ceil(1.05*(8*b+2*math.ceil(8*b*32/4096)+22))), math.ceil((1030 if b==128 else 8*b+5)*1.10)))")
    ( build $O/ncf $D -DORAM_NC_WBF_H=$FH -DORAM_NC_WBF=$FO -DORAM_NC_REL_H=$((FH + FAH)) -DORAM_NC_REL=$((FO + R - W)) ) & wait
    # (+hbmb_wlat=26: the HBM bucket port acknowledges as the card's does; the format's write acknowledgements depend on it)
    # (the host and HBM read tails: the baseline regression's card-like model, sim/run_rama_sizes.sh)
    TL="+host_slow_pct=3 +host_slow_extra=1500 +hbmb_slow_pct=3 +hbmb_slow_extra=300"
    H="+hb=0 +host_lat=480 +host_wlat=98 +hbmb_wlat=26 $TL +preload +cmds2=4"
    S0="+meta_slow_pct=0 +brec_slow_pct=0 +stash_slow_pct=0"; ADV="+meta_lat=200 +stash_lat=200 +brec_lat=200 $S0"
    # the baseline regression's RAMA-like stash (sim/run_rama_sizes.sh): every read 200 cycles, 40% data gaps, no same-ID blocking
    CS="+stash_gap=40 +stash_pcs=390 +stash_idblk=0 +stash_lat=200 +stash_slow_pct=0"
    # design A's stash (same-ID blocking across channels), which these times do not assume: a halt is allowed here, a wrong answer is not
    CA="+stash_gap=40 +stash_lat=120 +stash_slow_pct=0 +stash_pcs=390 +stash_idblk=1"
    # memory back-pressure inside the HBM allowance: 10%, but 4% at 2 KB, where the baseline's REL leaves 12% over the write
    HR=10; [ $B = 64 ] && HR=4
    : > $O/jobs.txt
    # the same cases on the NOCRYPTO build and on Option A
    for x in nc base; do cat >> $O/jobs.txt <<EOJ
$x p0 $H +hbm_pct=20 +cmds=1500 +put_pct=0 +seed=11
$x p50 $H +hbm_pct=20 +cmds=1500 +put_pct=50 +seed=11
$x p100 $H +hbm_pct=20 +cmds=1500 +put_pct=100 +seed=11
$x h0 $H +hbm_pct=0 +cmds=1000 +seed=23
$x h50 $H +hbm_pct=50 +cmds=1500 +seed=23
$x h100 $H +hbm_pct=100 +cmds=1500 +seed=37
$x cs20 $H $CS +hbm_pct=20 +cmds=1500 +seed=5
$x sk $H +hbm_pct=50 +cmds=600 +same_key=600 +put_pct=50 +seed=7
EOJ
    done
    cat >> $O/jobs.txt <<EOJ
nc n20 $H +hbm_pct=20 +cmds=1500 +seed=5
nc a20 $H $ADV +hbm_pct=20 +cmds=1500 +seed=5
nc a0 +hb=0 +host_lat=240 +host_wlat=98 +hbmb_wlat=26 +preload +cmds2=4 $ADV +hbm_pct=0 +cmds=1500 +seed=13
nc a100 $H $ADV +hbm_pct=100 +cmds=1500 +seed=13
nc csA $H $CA +hbm_pct=50 +cmds=1500 +seed=23
nc jit $H +host_gap=30 +hbm_gap=10 +hbm_pct=20 +cmds=1500 +seed=17
nc up0 $H +resp_pstrb=16 +hbm_pct=20 +cmds=1000 +put_pct=0 +seed=41
nc up50 $H +resp_pstrb=16 +hbm_pct=20 +cmds=1000 +put_pct=50 +seed=41
nc up100 $H +resp_pstrb=16 +hbm_pct=20 +cmds=1000 +put_pct=100 +seed=41
nc rdy $H +host_rdy=10 +hbm_rdy=$HR +hbm_pct=20 +cmds=1500 +seed=19
nc i0 +hb=0 +junk_mem +host_lat=480 +host_wlat=98 +hbmb_wlat=26 +preload +cmds2=4 +hbm_pct=0 +cmds=500 +seed=3 +inspect=$O/insp_i0.txt
nc i20 +hb=0 +junk_mem +host_lat=480 +host_wlat=98 +hbmb_wlat=26 +preload +cmds2=4 +hbm_pct=20 +cmds=500 +seed=3 +inspect=$O/insp_i20.txt
nc i100 +hb=0 +junk_mem +host_lat=480 +host_wlat=98 +hbmb_wlat=26 +preload +cmds2=4 +hbm_pct=100 +cmds=500 +seed=3 +inspect=$O/insp_i100.txt
nc wh100 +hb=0 +hbm_pct=100 +seed=3 +cmds=200 +cmds2=4 +host_lat=480 +host_wlat=98 +hbmb_wlat=26 +halt_wait=60000 +hbmb_whold=$R_H +hbmb_whold_at=50
nc wh0 +hb=0 +hbm_pct=0 +seed=3 +cmds=200 +cmds2=4 +host_lat=480 +host_wlat=98 +hbmb_wlat=26 +halt_wait=60000 +host_whold=$R +hbmb_whold_at=50
ncth th100 +hb=0 +preload +hbm_pct=100 +seed=3 +cmds=200 +cmds2=4 +host_lat=480 +host_wlat=98 +hbmb_wlat=26 +halt_wait=60000
ncth th0 +hb=0 +preload +hbm_pct=0 +seed=3 +cmds=200 +cmds2=4 +host_lat=480 +host_wlat=98 +hbmb_wlat=26 +halt_wait=60000
ncf f20 $H +hbm_pct=20 +cmds=1500 +put_pct=50 +seed=11
ncf f100 $H +hbm_pct=100 +cmds=1500 +seed=37
nct tr20 $H +hbm_pct=20 +phase_trace +cmds=500 +seed=23
ncd d20 $H +hbm_pct=20 +phase_trace +cmds=500 +seed=23 +dbg_csv=$O/dbg_d20.csv
ncd d100 $H $ADV +hbm_pct=100 +phase_trace +cmds=500 +seed=29 +dbg_csv=$O/dbg_d100.csv
nctd dt20 $H +hbm_pct=20 +phase_trace +cmds=500 +seed=23
nctd dt100 $H +hbm_pct=100 +phase_trace +cmds=500 +seed=29
ncl lk0 $H +hbm_pct=20 +cmds=800 +put_pct=0 +seed=11
ncl lk50 $H +hbm_pct=20 +cmds=800 +put_pct=50 +seed=11
EOJ
    # (the stash-slow cases: the first stash latency that stops each class)
    for ss in 800 1600 3200; do
        echo "nc sl100_$ss +hb=0 +hbm_pct=100 +seed=3 +cmds=200 +cmds2=4 +host_lat=480 +host_wlat=98 +hbmb_wlat=26 +halt_wait=60000 +stash_slow=$ss +stash_slow_at=20" >> $O/jobs.txt
        echo "nc sl0_$ss +hb=0 +hbm_pct=0 +seed=3 +cmds=200 +cmds2=4 +host_lat=480 +host_wlat=98 +hbmb_wlat=26 +halt_wait=60000 +stash_slow=$ss +stash_slow_at=20" >> $O/jobs.txt
    done
    [ "$B" = 1 ] && for pk in 8 16; do echo "nc pk$pk +hb=0 +host_lat=480 +host_wlat=98 +hbmb_wlat=26 +cmds=1200 +cmds2=4 +hbm_pct=20 +seed=7 +packed=$pk" >> $O/jobs.txt; done
    ( cd $O; O=$O REUSE=$REUSE xargs -P $J -L 1 bash -c 'x=$0; t=$1; shift 1; [ "$REUSE" = 1 ] && grep -q "Verilog \$finish" ${x}_$t.log 2>/dev/null && exit 0; timeout 7200 ./$x/V "$@" +phase_log=pl_${x}_$t.csv > ${x}_$t.log 2>&1' < jobs.txt )
    P="$((B*32)) B"
    # ---- 1, 2, 3
    nx=0; acc=0; for t in p0 p50 p100 h0 h50 h100 cs20 sk n20 a20 a0 a100 jit rdy; do
        l=$O/nc_$t.log; nx=$((nx+1))
        clean $l || { bad "$P $t: not clean ($l)"; continue; }
        f=""; [ "$t" = rdy ] && f=--bp
        r=""; case $t in p0|p50|p100|h0|h50|h100|cs20|sk) r="--ref $O/pl_base_$t.csv" ;; esac
        out=$(python3 check_nocrypto.py --beats $B --times $T $f $r $O/pl_nc_$t.csv 2>&1)
        [ $? = 0 ] && ok "$P $t: all correct, scoreboard 0 wrong, no halt; $(echo "$out" | sed 's/^PASS //')" || { bad "$P $t: schedule"; echo "$out" | head -6 | sed 's/^/      /'; }
        # 3
        nl=$(grep -a '^nocrypto:' $l)
        read -r nh nm wh wm <<< "$(echo "$nl" | sed -E 's/.*need_host=([0-9]+) need_hbm=([0-9]+) .*wr_host=([0-9]+) wr_hbm=([0-9]+).*/\1 \2 \3 \4/')"
        if [ "$nh" -gt "$W" ] || [ "$nm" -gt "$W_H" ] || [ $((W + wh)) -gt "$R" ] || [ $((W_H + wm)) -gt "$R_H" ]; then
            bad "$P $t: fixed times exceeded: $nl"; fi
    done
    wn=$(cat $O/nc_p*.log $O/nc_h*.log $O/nc_cs20.log $O/nc_sk.log $O/nc_n20.log $O/nc_a*.log $O/nc_jit.log $O/nc_rdy.log | grep -a '^nocrypto:' | sed -E 's/.*need_host=([0-9]+) need_hbm=([0-9]+) .*wr_host=([0-9]+) wr_hbm=([0-9]+).*/\1 \2 \3 \4/' | awk 'BEGIN{a=b=c=d=0} {if($1>a)a=$1; if($2>b)b=$2; if($3>c)c=$3; if($4>d)d=$4} END{print a,b,c,d}')
    # (ni directed cases at the final times)
    # ---- 4
    for g in "p0 p50 p100" "n20 a20 cs20"; do
        set -- $g; a0=$1; shift; va=$(vis $O/nc_$a0.log); e=1
        [ -n "$va" ] || e=0
        for x in "$@"; do [ "$va" = "$(vis $O/nc_$x.log)" ] || e=0; done
        [ $e = 1 ] && ok "$P visible hashes identical across $g: $(grep -E '^run1: bucket-port timing hash' $O/nc_$a0.log | grep -oE 'hash [0-9a-f]+ over [0-9]+ requests'), shape $(grep -E '^run1: folded off-package' $O/nc_$a0.log | grep -oE 'hash [0-9a-f]+ over [0-9]+ accesses')" || bad "$P visible hashes differ across $g"
    done
    # the response write (docs/resp_uniform_write.md): under slow partial writes, the visible schedule and device cycles per command do not
    # depend on the operation, and every PUT's slot reads zeros (the testbench checks that)
    va=$(vis $O/nc_up0.log); e=1; [ -n "$va" ] || e=0
    for x in up50 up100; do [ "$va" = "$(vis $O/nc_$x.log)" ] || e=0; done
    dc=$(for x in up0 up50 up100; do grep -E '^run1: size=' $O/nc_$x.log | sed -E 's/.*device total=([0-9]+).*/\1/'; done | sort -u | wc -l)
    if [ $e = 1 ] && [ "$dc" = 1 ] && clean $O/nc_up0.log && clean $O/nc_up50.log && clean $O/nc_up100.log; then ok "$P response write, slow partial writes: 0 / 50 / 100% PUTs identical in visible hashes and device cycles, every PUT's slot zeros"
    else bad "$P response write: 0 / 50 / 100% PUTs differ (e=$e, device totals $dc)"; fi
    # ---- 5
    for t in p50 h0 h50 h100 cs20; do
        a=$(grep -E '^bucket writes:' $O/base_$t.log); b=$(grep -E '^bucket writes:' $O/nc_$t.log)
        ha=$(echo "$a" | sed -E 's/.*; HBM //'); hb=$(echo "$b" | sed -E 's/.*; HBM //')
        ada=$(echo "$a" | grep -oE 'bursts address digest [0-9a-f]+' | tr '\n' ' '); adb=$(echo "$b" | grep -oE 'bursts address digest [0-9a-f]+' | tr '\n' ' ')
        hda=$(echo "$a" | grep -oE 'host [0-9]+ beats digest [0-9a-f]+'); hdb=$(echo "$b" | grep -oE 'host [0-9]+ beats digest [0-9a-f]+')
        nw=$(echo "$a" | grep -oE 'host [0-9]+ beats' | grep -oE '[0-9]+')
        if [ -n "$a" ] && [ "$ha" = "$hb" ] && [ "$ada" = "$adb" ] && { [ "$nw" = 0 ] || [ "$hda" != "$hdb" ]; }; then
            ok "$P $t: same ORAM as Option A: HBM write beats and addresses, host write addresses identical$([ "$nw" = 0 ] && echo ' (no host writes in this case)' || echo '; host data differs (plaintext against ciphertext)')"
        else bad "$P $t: write digests differ from Option A: $a / $b"; fi
    done
    # ---- 6
    for t in i0 i20 i100; do
        out=$(python3 inspect_check.py --nocrypto $O/insp_$t.txt 2>&1)
        if clean $O/nc_$t.log && echo "$out" | grep -q "INSPECT: PASS"; then ok "$P ${t#i}% on package: $(echo "$out" | sed 's/INSPECT: PASS: //')"; else bad "$P $t inspect: $out"; fi
        rm -f $O/insp_$t.txt
    done
    # ---- 7: enforcement
    enforce() {  # enforce <log> <class name> <REL> <deadline regex> <label>
        local l=$1 cl=$2 rel=$3 re=$4 lb=$5
        # a mismatch before the halt or a wrong evicted beat: wrong data (after a halt every command fails by design)
        if sed -n '1,/DOMA HALT/p' $l | grep -qE "data mismatch|not zero" || ! grep -q "eviction scoreboard: .* 0 wrong" $l; then bad "$P $lb: wrong data ($l)"
        elif ! grep -qE "^OVERRUN-AT: state [0-9]+, raised in access cycle [0-9]+, $rel cycles after the bucket's last beat \(arrival seen 1\)" $l; then bad "$P $lb: the halt is not at t_arr + $rel ($(grep -m1 OVERRUN-AT $l))"
        elif ! grep -qE "^(preload|run[12]): halt record: .*\($cl\), on-package deadline $re" $l; then bad "$P $lb: halt record ($(grep -m2 'halt record' $l | tail -1))"
        else ok "$P $lb: fail-stop at exactly t_arr + $rel, no wrong answer: $(grep -m1 -E '^(preload|run[12]): halt record' $l | sed -E 's/.*halt record: //' | cut -c1-110)"; fi
    }
    enforce $O/nc_wh100.log HBM $R_H '\(2\)' "a held HBM write"
    enforce $O/nc_wh0.log host $R '\(2\)' "a held host write"
    enforce $O/ncth_th100.log HBM $R_H '\(1\)' "write-back time too early, HBM"
    enforce $O/ncth_th0.log host $R '\(1\)' "write-back time too early, host"
    for c in 100 0; do
        l=""; for ss in 800 1600 3200; do grep -q "DOMA HALT" $O/nc_sl${c}_$ss.log && { l=$O/nc_sl${c}_$ss.log; s=$ss; break; }; done
        cln=$([ $c = 100 ] && echo HBM || echo host); rl=$([ $c = 100 ] && echo $R_H || echo $R)
        if [ -n "$l" ]; then enforce $l $cln $rl '\([12]\)' "stash reads of $s cycles, $cln"; else bad "$P stash reads up to 3200 cycles did not stop class $cln"; fi
    done
    # the same ORAM at the floor times, nominal memory: clean, every access on the schedule
    for t in f20 f100; do
        l=$O/ncf_$t.log; out=$(python3 check_nocrypto.py --beats $B --times $FH $FO $((FH + FAH)) $((FO + R - W)) $O/pl_ncf_$t.csv 2>&1)
        if clean $l && [ $? = 0 ] && echo "$out" | grep -q '^PASS'; then ok "$P floor times ($t): WBF $FH / $FO, REL $((FH + FAH)) / $((FO + R - W)): all correct, on the schedule; $(grep -E '^run1: size=' $l | sed -E 's/^run1: size=([0-9]+) +host cycles=([0-9]+).*/\2 cycles for \1 requests/')"
        else bad "$P floor times ($t) ($l): $(echo "$out" | head -2)"; fi
    done
    # design A's stash, no RAMA: never a wrong answer
    l=$O/nc_csA.log
    if sed -n '1,/DOMA HALT/p' $l | grep -qE "data mismatch|not zero" || ! grep -q "eviction scoreboard: .* 0 wrong" $l; then bad "$P design A's stash (no RAMA): wrong data ($l)"
    elif grep -q "DOMA HALT" $l; then ok "$P design A's stash (no RAMA): the times are missed, fail-stop, no wrong answer"
    else ok "$P design A's stash (no RAMA): fits these times in this run, all correct"; fi
    # ---- 8, traced
    clean $O/nct_tr20.log && grep -qE "^run1: phase trace: .*; 0 bad" $O/nct_tr20.log && ok "$P traced: $(grep -E '^run1: phase trace:' $O/nct_tr20.log | sed -E 's/^run1: phase trace: //; s/; 0 bad//')" || bad "$P traced ($O/nct_tr20.log)"
    for t in d20 d100; do
        l=$O/ncd_$t.log
        if clean $l && [ "$(grep -cE '^run[12]: debug records: .*; 0 bad' $l)" = 2 ] && [ "$(grep -cE '^run[12]: debug stash records: .*; 0 bad' $l)" = 2 ]; then
            ok "$P debug $t: records equal to the testbench's, $(grep -E '^run2: debug counters' $l | grep -oE 'deadline \(1\) missed [0-9]+.*deadline \(2\) missed [0-9]+')"
        else bad "$P debug $t ($l)"; fi
    done
    for t in dt20 dt100; do
        l=$O/nctd_$t.log
        n1=$(grep -E '^run2: debug counters' $l | grep -oE 'deadline \(1\) missed [0-9]+' | grep -oE '[0-9]+$')
        if grep -q "ALL CHECKS PASSED" $l && [ "$(grep -cE '^run[12]: debug records: .*; 0 bad' $l)" = 2 ] && [ "${n1:-0}" -gt 0 ]; then
            ok "$P need against deadline (1), $t, WBF 30: $n1 of $(grep -E '^run2: debug counters' $l | grep -oE '[0-9]+ on-package accesses' | grep -oE '^[0-9]+') accesses missed it, flagged exactly when word 12 is after WBF; every GET correct"
        else bad "$P need against deadline (1), $t ($l)"; fi
    done
    # ---- 9: the negative control
    out=$(python3 check_nocrypto.py --beats $B --times $T $O/pl_ncl_lk50.csv 2>&1); rc=$?
    va=$(grep -E '^run1: (bucket-port timing|off-package access shape)' $O/ncl_lk0.log); vb=$(grep -E '^run1: (bucket-port timing|off-package access shape)' $O/ncl_lk50.log)
    if [ $rc != 0 ] && [ "$va" != "$vb" ] && grep -q "ALL CHECKS PASSED" $O/ncl_lk50.log; then ok "$P negative control: a PUT's write one cycle late: the schedule check and the visible hashes both catch it (every response still correct)"
    else bad "$P negative control not caught (rc $rc; $O/ncl_lk50.log)"; fi
    # ---- 10
    if [ "$B" = 1 ]; then for pk in 8 16; do
        l=$O/nc_pk$pk.log; grep -q "ALL CHECKS PASSED" $l && ! grep -q "DOMA HALT" $l && ok "$P packed $pk-byte records: every GET equal to the block image (the record and its neighbours), $(grep -E '^run1: size=' $l | grep -oE 'gets=[0-9]+ puts=[0-9]+')" || bad "$P packed $pk-byte records ($l)"
    done; fi
    # the size's summary, for the report
    python3 - $O/nc_p50.log $O/base_p50.log $O/pl_nc_p50.csv $O/pl_base_p50.csv $O/ncf_f20.log <<'PY' | tee $O/summary.txt
import csv, re, sys
def sz(f):
    m = re.search(r"^run1: size=(\d+)\s+host cycles=(\d+)", open(f, errors="replace").read(), re.M); return int(m.group(2)) / int(m.group(1))
def cl(f):
    r = list(csv.DictReader(open(f))); o = {}
    for c in ("0", "1"):
        x = [a for a in r if a["hbm"] == c]
        if x: o[c] = (int(x[-1]["t_arr"]), int(x[-1]["release"]) - int(x[-1]["t_arr"]) - 1, int(x[-1]["end"]))
    return o
a, b = cl(sys.argv[3]), cl(sys.argv[4]); na, nb, nf = sz(sys.argv[1]), sz(sys.argv[2]), sz(sys.argv[5])
print(f"SUMMARY cycles per request, 20% on package: Option A {nb:.1f}, NOCRYPTO table {na:.1f} ({100 * (1 - na / nb):.1f}% fewer), NOCRYPTO floor {nf:.1f} ({100 * (1 - nf / nb):.1f}% fewer); table times: host: arrival {a['0'][0]}, release after it {a['0'][1]} (Option A {b['0'][1]}), end {a['0'][2]} (Option A {b['0'][2]}); HBM: arrival {a['1'][0]}, release after it {a['1'][1]} (Option A {b['1'][1]}), end {a['1'][2]} (Option A {b['1'][2]})")
PY
    echo "$P worst over the runs: need host/HBM, write host/HBM: $wn"
done
# ---- 11
if [ "${HOSTSEQ:-0}" = 1 ]; then for B in $SIZES; do
    NMX=2097152
    echo "== hostseq: host_doma through the XRT mock, $((B*32)) B, NMAX $NMX, 4,096 records, 20% on package, every response checked"
    M=$PWD/xrt_mock; Om=$TOP/mock_b$B; mkdir -p $Om
    ( cd xrt_mock && LAMBDA=7 ORAM_BEATS=$B ORAM_N=$NMX OUT=$Om RTL=$RTL EXTRA_DEFS="-DORAM_NOCRYPTO -DORAM_ONPKG_FIXWB -DORAM_ONPKG_RAMA" bash build_model.sh > $Om/build.log 2>&1 && OUT=$Om bash build_hosts.sh >> $Om/build.log 2>&1 && mkdir -p $Om/bin && mv host_*_sim $Om/bin/ ) || { bad "$B: mock build ($Om/build.log)"; continue; }
    ( cd xrt_mock; DOMA_LAMBDA=7 DOMA_BLOCK=$((B*32)) DOMA_PAGES_HBM=0 MOCK_CFG=doma DOMA_N=4096 DOMA_HBM_PCT=20 $Om/bin/host_doma_sim doma_hw.xclbin > $Om/run.log 2>&1 )
    grep -q "ALL RESPONSES CORRECT" $Om/run.log && grep -q "NO ENCRYPTION" $Om/run.log \
        && ok "$((B*32)) B host_doma, XRT mock: $(grep -oE 'query: [0-9]+ commands' $Om/run.log), all responses correct, NO ENCRYPTION printed" || bad "$((B*32)) B host_doma ($Om/run.log)"
    if [ "$B" = 1 ]; then    # the packed values at 32 B: 8 bytes (the hosts' default) and 16 bytes (-DDOMA_VALUE_BYTES=16)
        ( cd xrt_mock; DOMA_LAMBDA=7 DOMA_BLOCK=32 DOMA_PACK=1 DOMA_PAGES_HBM=0 MOCK_CFG=doma DOMA_N=4096 DOMA_HBM_PCT=20 $Om/bin/host_doma_sim doma_hw.xclbin 2000 > $Om/run_p8.log 2>&1 )
        ( cd xrt_mock && OUT=$Om HOST_DEFS=-DDOMA_VALUE_BYTES=16 bash build_hosts.sh >> $Om/build.log 2>&1 && mkdir -p $Om/bin16 && mv host_*_sim $Om/bin16/ )
        ( cd xrt_mock; DOMA_LAMBDA=7 DOMA_BLOCK=32 DOMA_PACK=1 DOMA_PAGES_HBM=0 MOCK_CFG=doma DOMA_N=4096 DOMA_HBM_PCT=20 $Om/bin16/host_doma_sim doma_hw.xclbin 2000 > $Om/run_p16.log 2>&1 )
        for v in 8 16; do grep -q "ALL RESPONSES CORRECT" $Om/run_p$v.log \
            && ok "32 B host_doma, XRT mock, DOMA_PACK=1, $v-byte values: $(grep -oE 'records: .*' $Om/run_p$v.log), all responses correct" || bad "32 B packed $v-byte values ($Om/run_p$v.log)"; done
    fi
    rm -f xrt_mock/xrt_mock.o
done; fi
echo "== $pass passed, $fail failed"
[ $fail = 0 ]
