#!/bin/bash
# calibrate_nocrypto.sh -- the NOCRYPTO build's fixed times in simulation (docs/nocrypto.md section 3): runs every worst
# case with placeholder times (long enough that no run stops on the times it calibrates), then sim/budgets_nocrypto.py.
#   bash calibrate_nocrypto.sh [BEATS ...]            default 1 2 4 8 16 32 64 128 (32 B - 4 KB); prints the table
#   WRITE=1 bash calibrate_nocrypto.sh                also writes it into rtl/oram_params.vh
# The runs, per size and class:
#   adverse  (adv_*): every metadata read at 200 cycles (v14's profile), host reads at 240 (below the U55C's lowest
#                     observed read): tb_ni's directed worst cases (8 evictions into an empty bucket, full stash windows,
#                     compaction); tb_doma_kernel at 0, 20, 100% on package after a preload
#   slower   (slow_*): tb_doma_kernel with the baseline regression's RAMA-like stash (200-cycle reads, 40% data gaps, no same-ID blocking)
#   nominal  (nom_*): the directed cases with fixed latencies; tb_doma_kernel with the testbench's HBM profile (2% of reads
#                     105 cycles slower)
# Logs in build/nc_cal/b<beats>/.
set -u
cd "$(dirname "$0")"
SIM=$(pwd); RTL=$(cd "${RTL_DIR:-../rtl}" && pwd); O=$SIM/build/nc_cal
SIZES=${*:-1 2 4 8 16 32 64 128}; J=${J:-$(nproc)}
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
VF="--binary --timing -j 2 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-BLKANDNBLK -I$RTL"
vbuild() {   # vbuild <dir> <top> <files...> -- <defines...>
    local d=$1 top=$2; shift 2; local try
    for try in 1 2 3 4; do
        rm -rf "$d"; verilator $VF "$@" --top-module $top -Mdir "$d" -o V > "$d.log" 2>&1 && return 0
        grep -q "Internal Error" "$d.log" || break
    done; [ -x "$d/V" ]
}
S0="+meta_slow_pct=0 +brec_slow_pct=0 +stash_slow_pct=0"; ADV="+meta_lat=200 +stash_lat=200 +brec_lat=200 $S0"
H="+hb=0 +preload +cmds=1500 +cmds2=4 +host_wlat=98 +hbmb_wlat=26"
# the baseline regression's RAMA-like stash (sim/run_rama_sizes.sh): every read 200 cycles, 40% data gaps, no same-ID blocking; and its
# card-like read tails on the host and HBM bucket ports
CS="+stash_gap=40 +stash_pcs=390 +stash_idblk=0 +stash_lat=200 +stash_slow_pct=0"
TL="+host_slow_pct=3 +host_slow_extra=1500 +hbmb_slow_pct=3 +hbmb_slow_extra=300"
: > $O.jobs 2>/dev/null || { mkdir -p "$(dirname $O)"; : > $O.jobs; }
for b in $SIZES; do
    d=$O/b$b; mkdir -p $d
    PH="-DORAM_NC_WBF_H=1200 -DORAM_NC_WBF=1200 -DORAM_NC_REL_H=2000 -DORAM_NC_REL=2000"   # placeholders
    [ $b -ge 16 ] && PH="-DORAM_NC_WBF_H=3000 -DORAM_NC_WBF=3000 -DORAM_NC_REL_H=5000 -DORAM_NC_REL=5000"
    D="-DORAM_BLOCK_BEATS=$b -DORAM_C=7 -DORAM_SCHED_ARRIVAL -DORAM_ONPKG_FIXWB -DORAM_ONPKG_RAMA -DORAM_NOCRYPTO $PH"
    ( vbuild $d/ni tb_ni tb_ni.v oram_timing_monitor.v axi_mem_model.v $SRCS $D -DORAM_DEBUG_PORTS || { echo "BUILD FAILED b$b ni"; exit 1; }
      vbuild $d/kern tb_doma_kernel tb_doma_kernel.v oram_timing_monitor.v axi_mem_model.v $SRCS $RTL/doma_kernel.v $D -DORAM_N=4096 -DORAM_SECURE_BUILD || { echo "BUILD FAILED b$b kern"; exit 1; } ) &
    cat >> $O.jobs <<JOBS
$d ni adv_dir_hbm +worst +heartbeat=0 +hbm_bkts=255 $ADV
$d ni adv_dir_host +worst +heartbeat=0 +hbm_bkts=0 +bkt_lat=240 $ADV
$d ni nom_dir_hbm +worst +heartbeat=0 +hbm_bkts=255 $S0
$d ni nom_dir_host +worst +heartbeat=0 +hbm_bkts=0 +bkt_lat=401 $S0
$d kern adv_k0 $H $ADV +host_lat=240 +hbm_pct=0 +seed=11
$d kern adv_k20 $H $ADV +host_lat=240 +hbm_pct=20 +seed=11
$d kern adv_k100 $H $ADV +host_lat=240 +hbm_pct=100 +seed=11
$d kern nom_k0 $H +host_lat=401 +hbm_pct=0 +seed=23
$d kern nom_k20 $H +host_lat=401 +hbm_pct=20 +seed=23
$d kern nom_k100 $H +host_lat=401 +hbm_pct=100 +seed=23
$d kern slow_cs20 $H $CS $TL +host_lat=480 +hbm_pct=20 +seed=5
$d kern slow_cs100 $H $CS $TL +host_lat=480 +hbm_pct=100 +seed=5
$d kern slow_h0 $H $CS +host_lat=240 +hbm_pct=0 +seed=5
JOBS
    [ $(jobs -r | wc -l) -ge 4 ] && wait -n
done
wait
xargs -P $J -L 1 bash -c 'd=$0; x=$1; n=$2; shift 2; cd $d; ./$x/V "$@" > $n.log 2>&1; echo "  $(basename $d) $n: $(grep -a "^nocrypto:" $n.log | sed "s/ (budgets.*//")"' < $O.jobs
python3 budgets_nocrypto.py --show $O $SIZES | tee $O/table.txt
[ "${WRITE:-0}" = 1 ] && python3 budgets_nocrypto.py --write $RTL/oram_params.vh $O $SIZES | tail -1
exit 0
