#!/usr/bin/env python3
"""card_budgets_nc.py -- the NOCRYPTO build's fixed times from the card's own per-access records (docs/nocrypto.md section 4).

    python3 card_budgets_nc.py --beats B [options] RECORDS.csv [RECORDS.csv ...]

RECORDS.csv: the debug bitstream's records (build.sh NOCRYPTO=1 FIXWB=1 DEBUG=1 TRACE=1 ...), host_phases DOMA_PHASE_TRACE=1
DOMA_ONPKG_CSV=<file>; the testbench writes the same format (+dbg_csv=<file>). In a NOCRYPTO debug bitstream:
  flags[0]  the class: 1 the bucket is in HBM, 0 in host memory (flags[1], the plaintext path, is set for both)
  ea        the decisions' end (S_EA_START)
  wsv       the earliest write-back time that would serve this access hold-free, raw access cycle ("need"): the decisions'
            end, and each eviction copy's landing less the time the write takes to reach its position
  wf, wl    first and last W accepted; dg  the hand-off (release gate reached); tarr  the arrival
So the bitstream's own write-back time does not matter: "need" says what any write-back time would have had to be.

Rule, per block size and class, with M(x) = ceil(x * s * (1 + pct/100)) + abs, s = max(1, 300 / MHz):
  WBF = max(FLOOR(class), M(worst need))                  FLOOR (rtl/oram_params.vh, sim/budgets_nocrypto.py): the directed
                                                          worst paths at the simulation's nominal memory, which a random run
                                                          need not reach
  REL = WBF + max(allowance(class), ceil(worst write * s * (1 + pct/100)))
        write = hand-off - first W + 4 (issue to first W is 4 cycles with AWREADY and WREADY up); the allowance is the one the
        class's write has had since v11b (sim/budgets_nocrypto.py)
Defaults: pct 10, abs 74. Unlike sim/card_budgets.py the result may fall below the current value: that is what this is for.

Tail check: each class's top --pot records of need and write are fitted with an exponential tail, as card_budgets.py does:
the expected misses per --runs accesses at the chosen times, and P(a run halts).

HBM buckets: the table keeps the baseline's card-proven times, because they have no crypto to remove. This script reports what the
rule would give them, but by default leaves them alone; --hbm also takes those values, for a comparison where the baseline's HBM times
are lowered the same way.

Options: --params FILE (default ../rtl/oram_params.vh) --pct P --abs N --mhz F --target-mhz F --pot K --runs R --write --hbm
         --define-only. --write replaces ORAM_NC_{WBF,REL}_B<B> (with --hbm also ORAM_NC_{WBF,REL}_H_B<B>) in --params (CRLF kept).
Prints a line "SUMMARY ..." for vitis/calibrate_all_sizes.sh.
"""
import importlib.util, math, os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("budgets_nocrypto", os.path.join(HERE, "budgets_nocrypto.py")); bn = importlib.util.module_from_spec(spec); spec.loader.exec_module(bn)
NONE = 65535; OFF = 32768
NEED = "launch cmd flags tarr ea dg wl wf sx wst wsv ar r1 end".split()
QS = [("need", "hold-free write-back time (need)"), ("dec", "decisions' end"), ("sx", "stash ready"), ("wr", "write, issue to hand-off"),
      ("wst", "W held by the memory (cycles)"), ("brl", "bucket read latency"), ("tarr", "arrival (access cycle)"), ("rel", "hand-off after the arrival")]
try:
    import numpy as np
except ImportError:
    np = None

class C:     # one class's histograms
    def __init__(self):
        self.h = {k: {} for k, _ in QS}; self.n = 0; self.m1 = 0; self.m2 = 0; self.bad = 0
    def put(self, k, v, c=1):
        self.h[k][v] = self.h[k].get(v, 0) + c

def pct(h, p):
    n = sum(h.values()); k = max(1, math.ceil(p * n)); c = 0
    for v in sorted(h):
        c += h[v]
        if c >= k: return v
    return None

def row(cl, r):
    if NONE in (r["tarr"], r["ea"], r["dg"], r["wf"], r["wsv"]): cl.bad += 1; return
    t = r["tarr"]; cl.n += 1; cl.m1 += (r["flags"] >> 2) & 1; cl.m2 += (r["flags"] >> 3) & 1
    cl.put("need", r["wsv"] - t); cl.put("dec", r["ea"] - t); cl.put("wr", r["dg"] - r["wf"] + 4); cl.put("wst", r["wst"]); cl.put("tarr", t); cl.put("rel", r["dg"] - t)
    if r["sx"] != NONE: cl.put("sx", r["sx"] - t)
    if NONE not in (r["r1"], r["ar"]): cl.put("brl", r["r1"] - r["ar"])

def read(files, Cs):
    total = 0
    for f in files:
        with open(f) as fh:
            hdr = fh.readline().strip().split(","); col = {k: i for i, k in enumerate(hdr)}
            miss = [k for k in NEED if k not in col]
            if miss: sys.exit(f"card_budgets_nc.py: {f}: columns missing: {' '.join(miss)}")
            nc = len(hdr)
            while True:
                lines = fh.readlines(16 << 20)
                if not lines: break
                lines = [l for l in lines if l.count(",") == nc - 1]
                total += len(lines)
                if np is None:
                    for l in lines:
                        v = l.split(","); r = {k: int(v[col[k]]) for k in NEED}
                        row(Cs[r["flags"] & 1], r)
                    continue
                M = np.array([l.split(",") for l in lines], dtype=np.int64)
                for c in (0, 1):
                    X = M[(M[:, col["flags"]] & 1) == c]
                    if not X.shape[0]: continue
                    g = lambda k: X[:, col[k]]
                    ok = (g("tarr") != NONE) & (g("ea") != NONE) & (g("dg") != NONE) & (g("wf") != NONE) & (g("wsv") != NONE)
                    Cs[c].bad += int((~ok).sum()); X = X[ok]
                    if not X.shape[0]: continue
                    g = lambda k: X[:, col[k]]
                    t = g("tarr"); fl = g("flags")
                    Cs[c].n += X.shape[0]; Cs[c].m1 += int(((fl >> 2) & 1).sum()); Cs[c].m2 += int(((fl >> 3) & 1).sum())
                    def add(k, v):
                        u, n = np.unique(v, return_counts=True)
                        for a, b in zip(u, n): Cs[c].put(k, int(a), int(b))
                    add("need", g("wsv") - t); add("dec", g("ea") - t); add("wr", g("dg") - g("wf") + 4); add("wst", g("wst")); add("tarr", t); add("rel", g("dg") - t)
                    m = g("sx") != NONE; add("sx", (g("sx") - t)[m])
                    m = (g("r1") != NONE) & (g("ar") != NONE); add("brl", (g("r1") - g("ar"))[m])
    return total

def tail(h, n, lim, pot, runs):
    """the exponential fit of card_budgets.py over the top values, from the histogram"""
    v = []
    for x in sorted(h, reverse=True):
        v += [x] * min(h[x], pot + 1 - len(v))
        if len(v) > pot: break
    if len(v) < 10: return None
    u = v[-1]; K = len(v) - 1; sigma = max(1.0, sum(x - u for x in v[:-1]) / K); p_u = K / n
    return runs * p_u * math.exp(-(lim - u) / sigma) if lim > u else runs * p_u

def main(a):
    o = dict(params=os.path.join(HERE, "..", "rtl", "oram_params.vh"), beats=None, pct=10.0, abs=74, mhz=300.0, target=300.0, pot=50, runs=20000000, write=False, define=False, hbm=False)
    files = []; i = 0
    while i < len(a):
        x = a[i]
        if x == "--write": o["write"] = True
        elif x == "--define-only": o["define"] = True
        elif x == "--hbm": o["hbm"] = True
        elif x in ("--params", "--beats", "--pct", "--abs", "--mhz", "--target-mhz", "--pot", "--runs"):
            k = {"--target-mhz": "target"}.get(x, x[2:]); v = a[i + 1]; i += 1
            o[k] = v if k == "params" else float(v) if k in ("pct", "mhz", "target") else int(v)
        elif x.startswith("-"): sys.exit(__doc__)
        else: files.append(x)
        i += 1
    if not files or o["beats"] is None: sys.exit(__doc__)
    b = o["beats"]
    raw = open(o["params"], newline="").read(); crlf = "\r\n" in raw; s = raw.replace("\r\n", "\n")
    def get(name):
        m = re.search(r"^`define %s +(\d+)" % name, s, re.M)
        if not m: sys.exit(f"card_budgets_nc.py: {name} not found in {o['params']}")
        return int(m.group(1))
    Cs = {0: C(), 1: C()}; total = read(files, Cs)
    P = (lambda *x: None) if o["define"] else print
    sc = max(1.0, o["target"] / o["mhz"]); pc = o["pct"] / 100.0
    P(f"card_budgets_nc.py: {total} records, block {b * 32} B ({b} beats), {o['mhz']:g} MHz" + (f": cycles scaled by {sc:.4f} to {o['target']:g} MHz" if sc > 1 else ""))
    res = {}
    for c, nm, sfx, allow in ((1, "HBM", "_H", bn.rel_hbm(b)), (0, "host", "", bn.rel_host(b))):
        cl = Cs[c]
        if not cl.n:
            P(f"class {nm}: no records"); continue
        P(f"class {nm}: {cl.n} accesses ({cl.bad} incomplete), flagged by this bitstream: deadline (1) {cl.m1}, deadline (2) {cl.m2}")
        P(f"  {'cycles after the arrival unless noted':38s} {'p50':>6s} {'p99':>6s} {'p99.9':>6s} {'p99.99':>6s} {'max':>6s} {'min':>6s}")
        for k, lab in QS:
            if cl.h[k]: P(f"  {lab:38s} " + " ".join(f"{pct(cl.h[k], p):6d}" for p in (0.5, 0.99, 0.999, 0.9999)) + f" {max(cl.h[k]):6d} {min(cl.h[k]):6d}")
        fl = get(f"ORAM_NC_FLOOR{sfx}_B{b}"); cur_w, cur_r = get(f"ORAM_NC_WBF{sfx}_B{b}"), get(f"ORAM_NC_REL{sfx}_B{b}")
        mn, mw = max(cl.h["need"]), max(cl.h["wr"])
        wbf_c = math.ceil(mn * sc * (1 + pc) - 1e-9) + o["abs"]; wbf = max(fl, wbf_c)
        a_c = math.ceil(mw * sc * (1 + pc) - 1e-9); A = max(allow, a_c); rel = wbf + A
        e1 = tail(cl.h["need"], cl.n, wbf / sc, o["pot"], o["runs"]); e2 = tail(cl.h["wr"], cl.n, A / sc, o["pot"], o["runs"])
        P(f"  WBF{sfx} = max(floor {fl}, ceil({mn} x {1 + pc:.2f}{' x %.4f' % sc if sc > 1 else ''}) + {o['abs']} = {wbf_c}) = {wbf} (now {cur_w}); "
          f"REL{sfx} = {wbf} + max(allowance {allow}, ceil({mw} x {1 + pc:.2f}{' x %.4f' % sc if sc > 1 else ''}) = {a_c}) = {rel} (now {cur_r})")
        if e1 is not None and e2 is not None:
            P(f"  tail check: expected misses per {o['runs']:,} accesses of this class: deadline (1) {e1:.3g}, deadline (2) {e2:.3g}; P(a run halts) ~ {1 - math.exp(-(e1 + e2)):.3g}")
        res[sfx] = (wbf, rel, mn, mw, cl.n, (e1 or 0) + (e2 or 0))
    if not res: sys.exit("card_budgets_nc.py: no records")
    wr = {k: v for k, v in res.items() if k == "" or o["hbm"]}     # what is written and printed as defines
    if "_H" in res and not o["hbm"]: P(f"HBM: keeping the baseline's WBF {get(f'ORAM_NC_WBF_H_B{b}')} and REL {get(f'ORAM_NC_REL_H_B{b}')} (--hbm would set {res['_H'][0]} and {res['_H'][1]})")
    for sfx, (wbf, rel, *_ ) in wr.items():
        d = f"`define ORAM_NC_WBF{sfx}_B{b} {wbf}\n`define ORAM_NC_REL{sfx}_B{b} {rel}"
        print(d)
    if not o["define"]:
        print("SUMMARY beats=%d mhz=%g %s" % (b, o["mhz"], " ".join(f"{'hbm' if sfx else 'host'}=n:{v[4]},need:{v[2]},wr:{v[3]},wbf:{v[0]},rel:{v[1]},halts:{v[5]:.2g}" for sfx, v in res.items())))
    if o["write"]:
        for sfx, (wbf, rel, *_ ) in wr.items():
            for k, v in (("WBF", wbf), ("REL", rel)):
                pat = re.compile(r"^(`define ORAM_NC_%s%s_B%d +)\d+" % (k, sfx, b), re.M)
                if len(pat.findall(s)) != 1: sys.exit(f"card_budgets_nc.py: ORAM_NC_{k}{sfx}_B{b} not found exactly once")
                s = pat.sub(lambda m: m.group(1) + str(v), s)
        open(o["params"], "w", newline="").write(s.replace("\n", "\r\n") if crlf else s)
        print(f"written {o['params']}")

if __name__ == "__main__":
    main(sys.argv[1:])
