#!/usr/bin/env python3
"""check_nocrypto.py -- one NOCRYPTO run's visible schedule, access by access (tb_doma_kernel +phase_log=<file>).

    python3 check_nocrypto.py --beats B --times WBF_H WBF REL_H REL [--bp] [--ref OPTIONA.csv] [--ctrd N] RUN.csv

Every access, by class of bucket (hbm 1 / 0), must have, in access cycles:
  no crypto  the core's start and tag columns all -1 (decryption and encryption)
  read       the bucket read issued at one offset after the access start (CT_RD: the padded lookup), the lookup within it
  write      issued at exactly t_arr + WBF(class) (logged one cycle later, as every write command) with no beat held for a
             copy, and streaming: BEATS * Z beats in BEATS * Z cycles from one offset after its issue (--bp: memory
             back-pressure in the run, so the span may grow, only the memory's own; no held beat all the same)
  release    at exactly t_arr + REL(class) (the state is entered one cycle later), the write handed off before it
  end        one offset after the release, for the whole run: what follows the arrival is a function of the arrival alone
--ref: the same run on Option A's build (with encryption): the same accesses (bucket class, command, evictions), and the
same read issue: the ORAM's decisions are unchanged. Exit 0 only if every check passes."""
import csv, sys
a = sys.argv[1:]; ref = None; bp = False; ctrd = 266; beats = None; t = None; f = None
while a:
    x = a.pop(0)
    if x == "--beats": beats = int(a.pop(0))
    elif x == "--times": t = [int(a.pop(0)) for _ in range(4)]
    elif x == "--ref": ref = a.pop(0)
    elif x == "--bp": bp = True
    elif x == "--ctrd": ctrd = int(a.pop(0))
    else: f = x
if beats is None or t is None or f is None: sys.exit(__doc__)
WBF, REL = {1: t[0], 0: t[1]}, {1: t[2], 0: t[3]}
rows = [{k: int(v) for k, v in r.items()} for r in csv.DictReader(open(f))]
if not rows: print(f"FAIL {f}: no accesses"); sys.exit(1)
bad = []
offs = {0: set(), 1: set()}; wf = {0: set(), 1: set()}; endo = {0: set(), 1: set()}; n = {0: 0, 1: 0}; mlk = 0; arr = {0: set(), 1: set()}
TOT = 8 * beats
for r in rows:
    c = r["hbm"]; n[c] += 1; A = r["acc"]; ta = r["t_arr"]
    for k in ("dec_start", "dec_tag", "enc_start", "enc_tag"):
        if r[k] != -1: bad.append(f"access {A}: crypto activity ({k} {r[k]})")
    offs[c].add(r["rd_issue"]); mlk = max(mlk, r["lookup"]); arr[c].add(ta)
    if r["lookup"] > ctrd: bad.append(f"access {A}: lookup {r['lookup']} past CT_RD {ctrd}")
    if r["wb_issue"] - ta != WBF[c] + 1: bad.append(f"access {A} (class {c}): write issued {r['wb_issue'] - ta - 1} after the arrival, not {WBF[c]}")
    if r["w_held"] != 0: bad.append(f"access {A} (class {c}): {r['w_held']} held cycles")
    sp = r["w_last"] - r["w_first"] + 1
    if (not bp and sp != TOT) or sp < TOT: bad.append(f"access {A} (class {c}): W span {sp}, not {TOT}")
    wf[c].add(r["w_first"] - r["wb_issue"])
    if r["release"] - ta != REL[c] + 1: bad.append(f"access {A} (class {c}): release {r['release'] - ta - 1} after the arrival, not {REL[c]}")
    if not (r["done_gate"] <= r["release"]): bad.append(f"access {A} (class {c}): hand-off {r['done_gate']} after the release {r['release']}")
    endo[c].add(r["end"] - r["release"])
for c in (0, 1):
    if len(offs[c]) > 1: bad.append(f"class {c}: read issue offsets {sorted(offs[c])}")
    if not bp and len(wf[c]) > 1: bad.append(f"class {c}: first-beat offsets {sorted(wf[c])}")
    if len(endo[c]) > 1: bad.append(f"class {c}: end offsets {sorted(endo[c])}")
if len(offs[0] | offs[1]) > 1: bad.append(f"the classes read at different offsets: {sorted(offs[0] | offs[1])}")
same = ""
if ref:
    R = [{k: int(v) for k, v in r.items()} for r in csv.DictReader(open(ref))]
    if len(R) != len(rows): bad.append(f"{len(R)} accesses on Option A, {len(rows)} here")
    for p, q in zip(R, rows):
        for k in ("hbm", "op", "nev", "rd_issue", "t_arr"):
            if p[k] != q[k]: bad.append(f"access {q['acc']}: {k} {p[k]} on Option A, {q[k]} here"); break
        else:
            if q["hbm"]:   # on package there is no crypto to remove: the same visible times as the baseline
                for k in ("wb_issue", "release"):
                    if p[k] - p["t_arr"] != q[k] - q["t_arr"]: bad.append(f"access {q['acc']} (HBM): {k} {p[k] - p['t_arr']} after the arrival on Option A, {q[k] - q['t_arr']} here")
                if p["end"] - p["release"] != q["end"] - q["release"]: bad.append(f"access {q['acc']} (HBM): end differs from Option A's")
    same = f"; class, command, evictions, read issue and arrival identical to the baseline's, and the HBM accesses' write-back, release and end, access by access"
if bad:
    for x in bad[:8]: print("FAIL", x)
    print(f"FAIL {f}: {len(bad)} problems")
    sys.exit(1)
def rg(s): return f"{min(s)}..{max(s)}" if len(s) > 1 else f"{min(s)}"
parts = []
for c, name in ((0, "host"), (1, "HBM")):
    if n[c]: parts.append(f"{name} {n[c]}: read at {rg(offs[c])}, arrival {rg(arr[c])}, write at t_arr + {WBF[c]}, release at t_arr + {REL[c]}, end {rg(endo[c])} after it")
print(f"PASS {len(rows)} accesses, no crypto activity, no held beat ({'; '.join(parts)}; worst lookup {mlk} of {ctrd}){same}")
