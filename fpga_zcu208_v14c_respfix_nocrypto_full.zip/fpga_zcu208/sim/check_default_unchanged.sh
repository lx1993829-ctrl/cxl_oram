#!/bin/bash
# check_default_unchanged.sh <reference package dir> -- without ORAM_NOCRYPTO, the RTL and testbenches changed by NOCRYPTO must
# preprocess to exactly the reference package's text (verilator -E -P), in every configuration: 2^8 combinations of the
# build options, at 4 KB, lambda 7, plus 8 block sizes x 2 lambdas with the options production uses. Text-identical sources
# give identical simulations and bitstream inputs, so the default build is unchanged by construction.
set -u
cd "$(dirname "$0")"
REF=$(cd "$1/rtl" && pwd); NEW=$(cd ../rtl && pwd); RS=$(cd "$1/sim" && pwd); NS=$(pwd)
J=${J:-$(nproc)}
RF="flat_oram_gcm.v secure_oram_top.v doma_kernel.v"; TF="tb_doma_kernel.v tb_ni.v"
OPTS=(ORAM_SCHED_ARRIVAL ORAM_ONPKG_FIXWB ORAM_PHASE_TRACE ORAM_ONPKG_DEBUG ORAM_STASH_PC_IDS ORAM_ONPKG_RAMA ORAM_OVERLAP2 ORAM_OVERLAP4)
L=$(mktemp); trap 'rm -f $L' EXIT
for m in $(seq 0 255); do d="-DORAM_C=7 -DORAM_SECURE_BUILD"; for i in 0 1 2 3 4 5 6 7; do [ $(( (m >> i) & 1 )) = 1 ] && d="$d -D${OPTS[$i]}"; done; echo "$d" >> $L; done
for b in 1 2 4 8 16 32 64 128; do for c in 6 7; do for x in "" "-DORAM_SCHED_ARRIVAL" "-DORAM_SCHED_ARRIVAL -DORAM_ONPKG_INTERIM" "-DORAM_SCHED_ARRIVAL -DORAM_ONPKG_FIXWB -DORAM_AR_WBF_H=300"; do
    echo "-DORAM_C=$c -DORAM_BLOCK_BEATS=$b -DORAM_SECURE_BUILD $x" >> $L; done; done; done
export REF NEW RS NS RF TF
one() {
    local d="$1" f r n
    for f in $RF; do
        r=$(verilator -E -P -Wno-fatal -I$REF $d $REF/$f 2>/dev/null | md5sum); n=$(verilator -E -P -Wno-fatal -I$NEW $d $NEW/$f 2>/dev/null | md5sum)
        [ "$r" = "$n" ] && echo same || echo "DIFF $f: $d"
    done
    for f in $TF; do
        r=$(verilator -E -P -Wno-fatal -I$REF $d $RS/$f 2>/dev/null | md5sum); n=$(verilator -E -P -Wno-fatal -I$NEW $d $NS/$f 2>/dev/null | md5sum)
        [ "$r" = "$n" ] && echo same || echo "DIFF $f: $d"
    done
}
export -f one
out=$(xargs -P $J -I{} bash -c 'one "{}"' < $L)
s=$(echo "$out" | grep -c '^same'); df=$(echo "$out" | grep -c '^DIFF')
echo "$(wc -l < $L) configurations x 5 files: $s identical to the reference, $df different"
echo "$out" | grep '^DIFF' | head -5
[ "$df" = 0 ]
