# NOCRYPTO: DOMA without encryption, for the comparison with BOLT (`NOCRYPTO=1`, `ORAM_NOCRYPTO`)

**Evaluation only.** Every bucket, host memory included, is in plaintext. The hosts print `NO ENCRYPTION` at boot, from
bit 4 of summary byte 2. This package is `fpga_zcu208_v14c_respfix_mhz_full.zip` (Option A + RAMA at every block size, the response-write
fix, `MHZ=`) with the switch added.

## 1. What changes and what does not

| | Baseline (`FIXWB=1 RAMA=1`) | `NOCRYPTO=1 FIXWB=1 RAMA=1` |
|---|---|---|
| Host-memory bucket read | Decrypted and verified | Plaintext path, as an on-package bucket |
| Host-memory bucket write | Re-encrypted, fresh IV and tag | Plaintext path, as an on-package bucket |
| AES-GCM core | Instantiated | **Not instantiated**; its sources are also left out of the Vivado project |
| Key and IV seed registers | Latched at boot | No loads, so synthesis should trim them; the boot sequence is unchanged |
| IV/tag beat of each bucket record | Used off package | Never read for a check, never written; the record stays 64 bytes |
| Boot format | Encrypted zeros off package | Zeros for every bucket, each write acknowledged before the next |
| HBM bucket: write-back, release | `t_arr + WBF`, `t_arr + AR_REL_H` | **The same times** |
| Host bucket: write-back | `t_arr + AR_WB`, encryption ahead of it | `t_arr + WBF`, hold-free (Option A's rule) |
| Host bucket: release | `t_arr + AR_REL` | `t_arr + REL`, earlier |
| A miss | HBM: at the release time. Host: at once | Both classes: recorded, fail-stop at exactly `t_arr + REL` |

**Unchanged:** the stash, the position map, eviction, the boot placement, the placement at 20% in HBM
(`DOMA_HBM_PCT=20`), Z = 8, λ = 7, the bucket layout, the serial design, the response write, RAMA on the stash port, and the read gate
`CT_RD`, which pads the position-map lookup and has no crypto in it.

There is no separate "version check" in this RTL. Freshness comes from the per-bucket IV and tag, so removing those
removes it.

**The switch.** `build.sh` writes `` `define ORAM_NOCRYPTO`` and requires `FIXWB=1 RAMA=1 SCHED=arrival LAMBDA=7
CFG=doma_big2m_rama.cfg`, with no `OVERLAP`, `INTERIM` or `PLAIN`. The RTL also stops elaboration on those combinations. Without the switch,
the changed RTL and testbenches preprocess to exactly this package's text (section 6).

## 2. What is visible

For every access, in access cycles, in both classes:

| Event | Time |
|---|---|
| Bucket read | At `CT_RD` after the access start, the padded lookup |
| Arrival `t_arr` | The memory's own |
| Write-back | At exactly `t_arr + WBF(class)`, then hold-free: `8 × BEATS` beats in `8 × BEATS` cycles, apart from the memory's own back-pressure |
| Release | At exactly `t_arr + REL(class)` |
| End | One fixed offset after the release |

The class of a bucket comes from its public bucket number, so a per-class time reveals nothing new.

## 3. The padded fixed times (simulation)

**HBM buckets keep the baseline's card-proven times** at every size (`docs/rama_sizes.md`). They have no crypto to remove, so their path is
the baseline's, and any difference between the two builds is then the cost of crypto. The regression checks this access by access.

**Host buckets lose decryption and re-encryption.** `sim/calibrate_nocrypto.sh` runs the worst cases with placeholder times, and
`sim/budgets_nocrypto.py` applies these rules, with `M(x) = ceil(1.10 x) + 74`, the margin of Option A and v14c:

- **`need`:** the earliest write-back time that serves one access hold-free. It is the later of the decisions' end and,
  for each eviction copy into position p, the copy's landing minus `p × BEATS`, the time the write takes to reach p.
  The write-back now waits only for this stash work.
- **Three memory profiles:**
  - **Adverse:** v14's: every metadata read at 200 cycles, host reads at 240.
  - **RAMA-like stash:** `sim/run_rama_sizes.sh`'s model: every stash read 200 cycles, 40% data gaps, no same-ID blocking, with its host and
    HBM read tails.
  - **Nominal:** the testbench's HBM profile and the directed worst paths.
- **`WBF = M(worst need, any profile)`.** At 4 KB it is the baseline's 440, the start the card calibrated with RAMA, because the decisions are
  the same.
- **`REL = WBF + max(allowance, ceil(1.10 × worst write))`.** The allowance is what the host write has had since v11b, for a write started at a
  fixed time: `ceil(1.2 (8b + 2 bursts + 22))`, 1,248 at 4 KB and 36 at 32 B.
- **`FLOOR = M(worst need, nominal)`:** the lowest WBF the card calibration may set. It exists because a random card run need not reach the
  directed worst paths. Above it, the card's own worst decides.

In cycles after the arrival:

| Block | Class | Worst need: adverse / RAMA-like / nominal | **WBF** | Write | **REL** | Baseline REL | FLOOR WBF | REL at FLOOR |
|---|---|---|---|---|---|---|---|---|
| 32 B | HBM | 486 / 339 / 98 | **607** | 13 | **659** | 659 | 182 | 218 |
| 32 B | host | 299 / 154 / 45 | **403** | 13 | **439** | 594 | 124 | 160 |
| 64 B | HBM | 473 / 331 / 92 | **603** | 21 | **663** | 663 | 176 | 218 |
| 64 B | host | 286 / 140 / 47 | **389** | 21 | **437** | 610 | 126 | 174 |
| 128 B | HBM | 447 / 301 / 80 | **595** | 37 | **672** | 672 | 162 | 221 |
| 128 B | host | 260 / 118 / 51 | **360** | 37 | **428** | 638 | 131 | 199 |
| 256 B | HBM | 395 / 261 / 59 | **579** | 69 | **690** | 690 | 139 | 232 |
| 256 B | host | 208 / 74 / 59 | **303** | 69 | **409** | 692 | 139 | 245 |
| 512 B | HBM | 293 / 203 / 75 | **547** | 133 | **725** | 725 | 157 | 317 |
| 512 B | host | 104 / 75 / 75 | **189** | 133 | **372** | 801 | 157 | 340 |
| 1 KB | HBM | 213 / 185 / 107 | **530** | 261 | **843** | 843 | 192 | 489 |
| 1 KB | host | 107 / 107 / 107 | **192** | 261 | **531** | 1,068 | 192 | 531 |
| 2 KB | HBM | 171 / 180 / 171 | **626** | 517 | **1,208** | 1,208 | 263 | 833 |
| 2 KB | host | 171 / 171 / 171 | **263** | 517 | **914** | 1,732 | 263 | 914 |
| 4 KB | HBM | 299 / 299 / 299 | **440** | 1,030 | **1,669** | 1,669 | 403 | 1,536 |
| 4 KB | host | 299 / 299 / 299 | **440** | 1,029 | **1,688** | 3,033 | 403 | 1,651 |

Measured over 13 runs per size (51,628 accesses); `docs/nocrypto_budgets.txt` has the table as printed. At 4 KB the simulated worst need under the
RAMA-like stash, 299, equals the card's measured worst write-back start with RAMA, also 299.

**`AR_DONE` is not enforced by any RTL**, so it is not a padded time. It stays defined, as `REL` plus the earlier allowance, for the tools that
read it. What ends an access is the release plus the result stream.

**Estimated throughput** at 300 MHz, 20% on package, 50% PUT, 4,096 records, the baseline regression's memory model (host reads 480 cycles, 3% of them
1,500 slower; 3% of HBM bucket reads 300 slower):

| Block | Baseline: cycles, KQPS | Table: cycles, KQPS | At FLOOR: cycles, KQPS | Cycles saved, table / FLOOR |
|---|---|---|---|---|
| 32 B | 1,339, 224 | 1,214, 247 | 903, 332 | 124 / 435 |
| 64 B | 1,363, 220 | 1,225, 245 | 926, 324 | 139 / 438 |
| 128 B | 1,410, 213 | 1,241, 242 | 968, 310 | 169 / 441 |
| 256 B | 1,501, 200 | 1,273, 236 | 1,051, 285 | 227 / 449 |
| 512 B | 1,683, 178 | 1,339, 224 | 1,232, 243 | 344 / 451 |
| 1 KB | 2,324, 129 | 1,893, 158 | 1,823, 165 | 431 / 501 |
| 2 KB | 3,260, 92 | 2,604, 115 | 2,530, 119 | 657 / 731 |
| 4 KB | 5,062, 59 | 3,982, 75 | 3,926, 76 | 1,080 / 1,136 |

These are estimates, not measurements. For a card figure, subtract the saved cycles from a card measurement of the baseline at the same settings.
The FLOOR column lowers the HBM times too, which only `CAL_HBM=1` does (section 4), and assumes the card's worst stays near the nominal memory.

## 4. Card calibration (as for v14c)

Run from `vitis/`. Each size builds in its own copy under `cal_nc/b<beats>/`. Defaults at every size, as the baseline: `NMAX=2097152`,
`DOMA_N=2097151`, `CFG=doma_big2m_rama.cfg`.

```bash
NOCRYPTO=1 JOBS=2 bash calibrate_all_sizes.sh build                  # 8 debug bitstreams (DEBUG=1 TRACE=1); or name sizes: ... build 1 2 4 8
NOCRYPTO=1 bash calibrate_all_sizes.sh timing                        # each bitstream's kernel clock
NOCRYPTO=1 ACC=2097152 bash calibrate_all_sizes.sh run               # 20% (both classes) and 100% on package (4 KB: 20 and 50%)
NOCRYPTO=1 bash calibrate_all_sizes.sh report                        # per-class distributions, tail check, defines
NOCRYPTO=1 bash calibrate_all_sizes.sh write                         # writes the host class's ORAM_NC_{WBF,REL}_B<beats>
```

Calibrate at the largest record count you will run: the times must hold at every count up to NMAX. `CAL_HBM=1` also writes the HBM class's values.
Then the HBM times no longer match the baseline's, so only use it for a comparison where the baseline's are lowered the same way.

**What the debug records hold in this build** (`DOMA_ONPKG_CSV`):

| Column | Meaning |
|---|---|
| `flags[0]` | The class: 1 HBM, 0 host. `flags[1]` is set for both |
| `ea` | The decisions' end |
| `wsv` (word 12) | `need`, as a raw access cycle. Host logs label this column "W not offered" |
| `wf`, `wl`, `dg`, `tarr` | First and last W accepted, hand-off, arrival |

So one debug bitstream is enough: `need` does not depend on the bitstream's own WBF. A debug bitstream never halts on a
missed deadline in either class.

**The rule** (`sim/card_budgets_nc.py`), per block size and class, with `s = max(1, 300 / MHz)`:

- `WBF = max(FLOOR, ceil(worst need × s × 1.10) + 74)`
- `REL = WBF + max(allowance, ceil(worst write × s × 1.10))`

**Then:**

1. Rerun the regression on the new values: `bash sim/run_nocrypto.sh`.
2. Build the production bitstreams (section 5). Check `check_timing.sh` passes; `build.sh` runs it.
3. Validate each size: 20M accesses at 20% on package with `host_phases`, `DOMA_PHASES=mix:20000000`. Pass: errors 0x0, no halt record.
4. Rate check, as for the baseline (`docs/resp_uniform_write.md`): `host_phases` get / put / mix / get, within 0.2% of the first GET phase.
5. Hot run: repeat back to back, with `xbutil examine -r thermal` logged before and after. HBM refreshes twice as often above 85 °C.
6. If a run halts, read the decoded halt record: it names the class (HBM or host), the deadline and the cycles missed.
   Rerun `report` with `PCT=20` and rebuild.

**One halt the deadlines do not cover:** a position-map lookup past `CT_RD` is an immediate overrun, not a deadline miss. A shorter REL starts the
next lookup sooner after the previous access's writes. In simulation the worst lookup is 207 of 266, with every metadata read at 200 cycles.

## 5. Build commands

Each configuration in its own copy of the package, because `build.sh` writes the shared `rtl/oram_build_cfg.vh` and always names its output
`doma_hw.xclbin`. These match the baseline's settings. `MHZ=<100..300>` lowers the clock, as for the baseline.

```bash
cd vitis && env NOCRYPTO=1 FIXWB=1 RAMA=1 SCHED=arrival BEATS=<1|2|4|8|16|32|64|128> CFG=doma_big2m_rama.cfg NMAX=2097152 LAMBDA=7 TARGET=hw bash build.sh
```

Add `TRACE=1` for the traced variant, in its own folder. To try other times without editing the table:
`WBF=<HBM> WBF_HOST=<host> REL=<HBM> REL_HOST=<host>`.

**Running at 20% on package** (`DOMA_N` as `host_doma`'s other runs):

```bash
DOMA_LAMBDA=7 DOMA_BLOCK=<block bytes> DOMA_N=1000000 DOMA_HBM_PCT=20 ./host_doma doma_hw.xclbin 2000000
```

**8 and 16 B values in 32 B blocks.** These use the 32 B bitstream with `DOMA_PACK=1`, and `DOMA_N` then counts values. The hosts' value size was
fixed at 8 bytes, so 16 B values need `g++ ... -DDOMA_VALUE_BYTES=16` on `host_doma.cpp` or `host_phases.cpp`. `host_ycsb` writes whole blocks and has no
packing option.

## 6. Regression

`sim/run_nocrypto.sh` (`HOSTSEQ=1` adds the mock-XRT runs), log in `docs/nocrypto_regression_2026-11-07.txt`.

**Results, 2026-11-07: 332 passed, 0 failed.** At each of 32 B, 64 B, 128 B, 256 B, 512 B, 1 KB, 2 KB and 4 KB, λ = 7, 4,096 records, built
without any AES or GHASH source:

- **Responses:** 14 cases (GET / PUT mixes, 0 / 20 / 50 / 100% on package, the RAMA-like stash, one key repeated, metadata at 200 cycles,
  host read gaps and tails, memory back-pressure): every response correct, eviction scoreboard 0 wrong, no halt.
- **Schedule, access by access (`check_nocrypto.py`):** no crypto activity; the read at one offset; the write at exactly
  `t_arr + WBF(class)` with no held beat; the release at exactly `t_arr + REL(class)`; the end one offset after it, with the arrival moving.
- **The baseline, built as `FIXWB=1 RAMA=1` configures it:** class, command, evictions, read issue and arrival identical access by access, and the
  HBM accesses' write-back, release and end; HBM write data and all write addresses identical; host write data differs, plaintext against
  ciphertext.
- **The response write:** under slow partial writes (`+resp_pstrb=16`), 0 / 50 / 100% PUTs give identical visible hashes and device cycles, and every PUT's
  slot reads zeros.
- **Visible hashes** (bucket-port timing, off-package shape, on-package release/end) identical across the GET / PUT mix, and across
  metadata at nominal speed, at 200 cycles and the RAMA-like stash.
- **No encryption:** with memories started as junk, every bucket holds its blocks in plaintext and every record's IV/tag beat is zero, at
  0, 20 and 100% on package.
- **Enforcement, both classes:** a held write, slowed stash reads, and write-back times too early each stop the build at
  exactly `t_arr + REL`, naming the deadline, with no wrong answer. Without RAMA's behaviour (same-ID blocking), a run either fits or halts, never a wrong answer.
- **Calibration measure:** with WBF far too early (30), deadline (1) was flagged exactly when `need` was after WBF, on every access, and
  every GET was still correct.
- **Debug and traced builds:** records equal to the testbench's own view; crypto phases zero-length on every access.
- **Negative control:** a PUT's write one cycle late (`TB_NC_LEAK`) is caught by the schedule check and by the visible hashes.
- **FLOOR times:** clean and on schedule at nominal memory, at 20 and 100% on package.
- **Packed records at 32 B:** 8 and 16 B values, in the testbench and through the XRT mock.
- **`host_doma` through the XRT mock:** NMAX 2,097,152, 20% on package, host memory, all responses correct, at every size.

**Back-pressure case:** ready is held low on 10% of cycles on both bucket ports, except 4% on the HBM port at 2 KB, where the baseline's REL leaves 12% over
the write.

**Default build:** `sim/check_default_unchanged.sh <package>` compares `verilator -E -P` output with the package as delivered, for 320 configurations × 5
files (`flat_oram_gcm.v`, `secure_oram_top.v`, `doma_kernel.v`, `tb_doma_kernel.v`, `tb_ni.v`): 1,600 identical, 0 different. The host programs change only by the
value-size define and a print behind the new flag bit. `build.sh` with your baseline's arguments writes no `NOCRYPTO` define.

## 7. Against BOLT

BOLT's results as measured on the card, 2026-11-07 (50 launches × 20,000 commands; 64 B against N: 218.6 KQPS at 100K, 210.9 at 500K, 209.2 at 1M, 208.1 at 2M).
DOMA's are simulation estimates at 4,096 records and 300 MHz, so this shows where a card run should land, not a result.

| Value | BOLT: HBM share, KQPS | DOMA `NOCRYPTO`, 20% in HBM: table, floor | DOMA `NOCRYPTO`, at BOLT's share: table, floor |
|---|---|---|---|
| 16 B (in 32 B blocks) | 41%, 199.8 | 247, 332 | 257, 366 |
| 32 B | 76%, 263.4 | 247, 332 | 278, 443 |
| 64 B | 60%, 209.2 | 245, 324 | 264, 394 |
| 128 B | 50%, 160.0 | 242, 310 | 255, 359 |
| 256 B | 46%, 108.5 | 236, 285 | 244, 323 |

- **HBM share.** BOLT's HBM share in these runs is 41–76%, not 20%. The last column interpolates DOMA between its host and HBM cycles at BOLT's share. Choose which
  comparison the paper reports.
- **16 B.** BOLT's row has 2 wrong GETs of 499,785, which no other row has. That needs explaining before the row is used.
- **Record count.** The value-size rows are taken as N = 1M, because the 64 B row equals N = 1M. DOMA's latency at 1M records has to come from the card.

## 8. What has not been checked

- **No Vivado and no card here.** Timing closure, resource use, the build-time saving, and every number on real memory are unverified. Removing the core should
  make timing easier, but that is an expectation.
- **`vitis/package_kernel.tcl`'s file removal and `v++`'s RAMA link have not been run.** Simulation confirms nothing needs the crypto sources: the regression builds
  without them, and the design elaborates without them with `SYNTHESIS` defined. RAMA itself is modelled, not simulated.
- **The host times rest on the 200-cycle adverse profile**, not on a card measurement. Only 4 KB has card data with RAMA, and that is on-package.

## 9. Things found along the way

- **Boot bug the switch would have hit on the card.** With no encryption between format writes, the last HBM bucket's write is followed at once by the first host
  bucket's. The kernel routes write responses by the latest address (`doma_kernel.v`, `wsel_h`), so the HBM response was lost and the boot halted. The testbench's HBM model
  acknowledged too fast to show it; the mock XRT's 26-cycle acknowledge did. The format now waits for each acknowledgement, and the regression runs with `+hbmb_wlat=26`.
- **`docs/fixwb_option_a.md` and the Option A debug build disagree (left as is).** The document says the debug record's write-back word is still the decisions' end. The RTL
  records the write's issue, so in Option A that word is `t_arr + WBF` by construction and shows no margin. `NOCRYPTO` records the decisions' end.
- **Stale reference in the delivered package (left as is).** `oram_params.vh` cites `docs/rama_baseline.md`, which is not in the package.
- **4 KB RAMA numbers.** The table you sent gives 403 / 1,559 at a 10% margin; the package and your build command use 440 / 1,669 at 20%. This build follows the package.
