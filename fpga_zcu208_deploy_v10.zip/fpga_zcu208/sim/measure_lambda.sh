#!/bin/bash
# measure_lambda.sh -- the worst work after a bucket's last beat, measured on the kernel tests (arrival group) at a given
# lambda, with every arrival budget of the size raised by 5,000 cycles so that no budget stops the run. These kernel runs
# include back-to-back accesses whose stash writes drain into the next access, which the directed combined case does not
# reproduce; budgets.py then takes the larger of the two.
#   ORAM_LAMBDA=7 bash sim/measure_lambda.sh                 # all sizes (beats 1 2 4 8 16 32 64 128)
#   ORAM_LAMBDA=7 BEATS_LIST="1 128" bash sim/measure_lambda.sh
# Output: one line per size and measure_lambda<L>.csv (beats,bytes,lambda,host_measured,hbm_measured,status).
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"; PKG="$(cd "$HERE/.." && pwd)"
L=${ORAM_LAMBDA:-6}; LIST=${BEATS_LIST:-"1 2 4 8 16 32 64 128"}
OUT="$PKG/measure_lambda$L.csv"; echo "beats,bytes,lambda,host_measured,hbm_measured,status" > "$OUT"
for b in $LIST; do
    W=$(mktemp -d /tmp/measure_l${L}_b${b}_XXXX)
    cp -r "$PKG/rtl" "$PKG/sim" "$W/" && rm -rf "$W/sim/build" "$W/sim/calib"
    # raise every arrival budget of this size (write-back, release, acknowledgement deadline; host and HBM)
    python3 - "$W/rtl/oram_params.vh" "$b" <<'EOF'
import re, sys
p, b = sys.argv[1], sys.argv[2]
raw = open(p, newline='').read(); crlf = '\r\n' in raw; s = raw.replace('\r\n', '\n')
s, n = re.subn(r'^(`define ORAM_AR_(?:WB|REL|DONE)(?:_H)?(?:_L7)?_B%s)(\s+)(\d+)' % b,
               lambda m: m.group(1) + m.group(2) + str(int(m.group(3)) + 5000), s, flags=re.M)
assert n >= 9, ("expected at least 6 arrival budgets for beats", b, n)
open(p, 'w', newline='').write(s.replace('\n', '\r\n') if crlf else s)
EOF
    [ $? -eq 0 ] || { echo "beats $b: could not raise the budgets"; echo "$b,$((b*32)),$L,,,budget-edit-failed" >> "$OUT"; continue; }
    ( cd "$W/sim" && ORAM_LAMBDA=$L ORAM_BEATS=$b bash run_verilator.sh arrival > arrival.out 2>&1 )
    host=$(grep -oE "worst work after the arrival fits AR_WB = [0-9]+ \(measured [0-9]+" "$W/sim/arrival.out" | grep -oE "[0-9]+$" | head -1)
    hbm=$(grep -oE "worst work after the arrival fits AR_WB_H = [0-9]+ \(measured [0-9]+" "$W/sim/arrival.out" | grep -oE "[0-9]+$" | head -1)
    # with raised budgets only the HBM-faster-than-0% comparison may fail (the release is padded far out); anything else is real
    other=$(grep -E "^\s+FAIL" "$W/sim/arrival.out" | grep -v "buckets in HBM is not faster" | head -1)
    st=ok; [ -n "$other" ] && st="FAILED: $(echo $other | cut -c1-80)"; [ -z "$host$hbm" ] && st="no measurement (see $W/sim/arrival.out)"
    echo "beats $b ($((b*32)) B), lambda $L: host ${host:-?}, HBM ${hbm:-?}  [$st]"
    echo "$b,$((b*32)),$L,${host:-},${hbm:-},$st" >> "$OUT"
    [ "$st" = ok ] && rm -rf "$W"
done
echo "written: $OUT"
