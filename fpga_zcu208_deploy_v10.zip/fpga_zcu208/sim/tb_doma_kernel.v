// tb_doma_kernel.v -- end-to-end test of the doma_kernel Vitis wrapper, with the testbench
// playing XRT: it writes the arguments and ap_start over AXI-Lite and polls ap_done.
//   run 0: size = 0      (boot, key load and lease grant; the analogue of BOLT's init_kernel)
//   run 1: +cmds commands (random GET/PUT over keys 0..N-1), every GET checked
//   run 2: +cmds2 commands, one of them an out-of-range key that must come back rejected
// Options: +cmds=N +cmds2=N +seed=N +host_lat=N (host-memory read latency, cycles)
//          +host_gap=P (percent of cycles without a host read beat)
`timescale 1ns/1ps
`include "oram_params.vh"
module tb_doma_kernel;
    localparam integer DW = 256, BEATS = `BEATS_PER_BLOCK, N = `ORAM_N;
    // memory models sized from the build: commands/responses hold a full preload (N blocks, plus a margin),
    // the stash holds its lists and one block per slot (never smaller than before)
    localparam integer CW_A = (((N > 512) ? N : 512) + 8) * (BEATS + 1) + 1024;
    localparam integer CMD_WORDS = (CW_A > (1 << 17)) ? CW_A : (1 << 17);
    localparam integer SW_A = ((((`ORAM_B * 512) + 4095) / 4096) * 4096 + N * BEATS * 32) / 32 + 64;
    localparam integer STASH_WORDS = (SW_A > (1 << 16)) ? SW_A : (1 << 16);
    integer NBLK = 0, NK = `ORAM_N;
    integer HBM_PCT = 0;
    integer POOL = 0;                       // +pool: stash pool entries (0 = n: cannot run out)                    // +hbm_pct: percentage of buckets kept in HBM (fixed boundary)
    reg [63:0] PAGES_OFF = 64'd0;           // +pagesoff: the pages buffer's offset (the re-boot test moves it)          // +nblk=n: run-time blocks (0 = the build's maximum); NK = effective n
    localparam [63:0] CMD_BASE = 64'h0000_0040_0000_0000, RESP_BASE = 64'h0000_0040_1000_0000,
                      HOST_BASE = 64'h0000_7f00_0000_0000, META_BASE = 64'h0000_0041_0000_0000, BREC_BASE = 64'h0000_0042_0000_0000, STASH_BASE = 64'h0000_0043_0000_0000,
                      HBMB_BASE = 64'h0000_0044_0000_0000;   // buckets kept in HBM (gmem6)
    reg clk = 0, rst_n = 0;
    always #1.667 clk = ~clk;                                  // ~300 MHz

    // ---------------- AXI-Lite master ----------------
    reg  [11:0] awaddr = 0, araddr = 0; reg awvalid = 0, wvalid = 0, bready = 0, arvalid = 0, rready = 0;
    reg  [31:0] wdata = 0; wire awready, wready, bvalid, arready, rvalid; wire [31:0] rdata; wire [1:0] bresp, rresp;
    wire irq;
    // ---------------- AXI masters ----------------
    wire [63:0] g0_araddr, g1_awaddr, g2_araddr, g2_awaddr, g0_awaddr, g1_araddr;
    wire [63:0] g6_araddr, g6_awaddr; wire [7:0] g6_arlen, g6_awlen;
    wire g6_arvalid, g6_arready, g6_rlast, g6_rvalid, g6_rready, g6_awvalid, g6_awready, g6_wlast, g6_wvalid, g6_wready, g6_bvalid, g6_bready;
    wire [DW-1:0] g6_rdata, g6_wdata; wire [DW/8-1:0] g6_wstrb;
    wire [7:0]  g0_arlen, g1_awlen, g2_arlen, g2_awlen, g0_awlen, g1_arlen;
    wire g0_arvalid, g0_arready, g0_rlast, g0_rvalid, g0_rready, g1_awvalid, g1_awready, g1_wlast, g1_wvalid, g1_wready,
         g1_bvalid, g1_bready, g2_arvalid, g2_arready, g2_rlast, g2_rvalid, g2_rready, g2_awvalid, g2_awready,
         g2_wlast, g2_wvalid, g2_wready, g2_bvalid, g2_bready;
    wire [DW-1:0] g0_rdata, g1_wdata, g2_rdata, g2_wdata; wire [DW/8-1:0] g1_wstrb, g2_wstrb;

    doma_kernel dut (
        .ap_clk(clk), .ap_rst_n(rst_n),
        .s_axi_control_awaddr(awaddr), .s_axi_control_awvalid(awvalid), .s_axi_control_awready(awready),
        .s_axi_control_wdata(wdata), .s_axi_control_wstrb(4'hF), .s_axi_control_wvalid(wvalid), .s_axi_control_wready(wready),
        .s_axi_control_bresp(bresp), .s_axi_control_bvalid(bvalid), .s_axi_control_bready(bready),
        .s_axi_control_araddr(araddr), .s_axi_control_arvalid(arvalid), .s_axi_control_arready(arready),
        .s_axi_control_rdata(rdata), .s_axi_control_rresp(rresp), .s_axi_control_rvalid(rvalid), .s_axi_control_rready(rready),
        .interrupt(irq),
        .m_axi_gmem0_araddr(g0_araddr), .m_axi_gmem0_arlen(g0_arlen), .m_axi_gmem0_arsize(), .m_axi_gmem0_arburst(),
        .m_axi_gmem0_arvalid(g0_arvalid), .m_axi_gmem0_arready(g0_arready), .m_axi_gmem0_rdata(g0_rdata),
        .m_axi_gmem0_rresp(2'b00), .m_axi_gmem0_rlast(g0_rlast), .m_axi_gmem0_rvalid(g0_rvalid), .m_axi_gmem0_rready(g0_rready),
        .m_axi_gmem0_awaddr(g0_awaddr), .m_axi_gmem0_awlen(g0_awlen), .m_axi_gmem0_awsize(), .m_axi_gmem0_awburst(),
        .m_axi_gmem0_awvalid(), .m_axi_gmem0_awready(1'b1), .m_axi_gmem0_wdata(), .m_axi_gmem0_wstrb(), .m_axi_gmem0_wlast(),
        .m_axi_gmem0_wvalid(), .m_axi_gmem0_wready(1'b1), .m_axi_gmem0_bresp(2'b00), .m_axi_gmem0_bvalid(1'b0), .m_axi_gmem0_bready(),
        .m_axi_gmem1_araddr(g1_araddr), .m_axi_gmem1_arlen(g1_arlen), .m_axi_gmem1_arsize(), .m_axi_gmem1_arburst(),
        .m_axi_gmem1_arvalid(), .m_axi_gmem1_arready(1'b1), .m_axi_gmem1_rdata({DW{1'b0}}), .m_axi_gmem1_rresp(2'b00),
        .m_axi_gmem1_rlast(1'b0), .m_axi_gmem1_rvalid(1'b0), .m_axi_gmem1_rready(),
        .m_axi_gmem1_awaddr(g1_awaddr), .m_axi_gmem1_awlen(g1_awlen), .m_axi_gmem1_awsize(), .m_axi_gmem1_awburst(),
        .m_axi_gmem1_awvalid(g1_awvalid), .m_axi_gmem1_awready(g1_awready), .m_axi_gmem1_wdata(g1_wdata),
        .m_axi_gmem1_wstrb(g1_wstrb), .m_axi_gmem1_wlast(g1_wlast), .m_axi_gmem1_wvalid(g1_wvalid), .m_axi_gmem1_wready(g1_wready),
        .m_axi_gmem1_bresp(2'b00), .m_axi_gmem1_bvalid(g1_bvalid), .m_axi_gmem1_bready(g1_bready),
        .m_axi_gmem2_araddr(g2_araddr), .m_axi_gmem2_arlen(g2_arlen), .m_axi_gmem2_arsize(), .m_axi_gmem2_arburst(),
        .m_axi_gmem2_arvalid(g2_arvalid), .m_axi_gmem2_arready(g2_arready), .m_axi_gmem2_rdata(g2_rdata),
        .m_axi_gmem2_rresp(2'b00), .m_axi_gmem2_rlast(g2_rlast), .m_axi_gmem2_rvalid(g2_rvalid), .m_axi_gmem2_rready(g2_rready),
        .m_axi_gmem2_awaddr(g2_awaddr), .m_axi_gmem2_awlen(g2_awlen), .m_axi_gmem2_awsize(), .m_axi_gmem2_awburst(),
        .m_axi_gmem2_awvalid(g2_awvalid), .m_axi_gmem2_awready(g2_awready), .m_axi_gmem2_wdata(g2_wdata),
        .m_axi_gmem2_wstrb(g2_wstrb), .m_axi_gmem2_wlast(g2_wlast), .m_axi_gmem2_wvalid(g2_wvalid), .m_axi_gmem2_wready(g2_wready),
        .m_axi_gmem2_bresp(2'b00), .m_axi_gmem2_bvalid(g2_bvalid), .m_axi_gmem2_bready(g2_bready),
        .m_axi_gmem6_araddr(g6_araddr), .m_axi_gmem6_arlen(g6_arlen), .m_axi_gmem6_arsize(), .m_axi_gmem6_arburst(),
        .m_axi_gmem6_arvalid(g6_arvalid), .m_axi_gmem6_arready(g6_arready), .m_axi_gmem6_rdata(g6_rdata),
        .m_axi_gmem6_rresp(2'b00), .m_axi_gmem6_rlast(g6_rlast), .m_axi_gmem6_rvalid(g6_rvalid), .m_axi_gmem6_rready(g6_rready),
        .m_axi_gmem6_awaddr(g6_awaddr), .m_axi_gmem6_awlen(g6_awlen), .m_axi_gmem6_awsize(), .m_axi_gmem6_awburst(),
        .m_axi_gmem6_awvalid(g6_awvalid), .m_axi_gmem6_awready(g6_awready), .m_axi_gmem6_wdata(g6_wdata),
        .m_axi_gmem6_wstrb(g6_wstrb), .m_axi_gmem6_wlast(g6_wlast), .m_axi_gmem6_wvalid(g6_wvalid), .m_axi_gmem6_wready(g6_wready),
        .m_axi_gmem6_bresp(2'b00), .m_axi_gmem6_bvalid(g6_bvalid), .m_axi_gmem6_bready(g6_bready),
        .m_axi_gmem3_araddr(g3_araddr), .m_axi_gmem3_arlen(g3_arlen), .m_axi_gmem3_arsize(), .m_axi_gmem3_arburst(),
        .m_axi_gmem3_arvalid(g3_arvalid), .m_axi_gmem3_arready(g3_arready), .m_axi_gmem3_rdata(g3_rdata), .m_axi_gmem3_rresp(2'b00),
        .m_axi_gmem3_rlast(g3_rlast), .m_axi_gmem3_rvalid(g3_rvalid), .m_axi_gmem3_rready(g3_rready),
        .m_axi_gmem3_awaddr(g3_awaddr), .m_axi_gmem3_awlen(g3_awlen), .m_axi_gmem3_awsize(), .m_axi_gmem3_awburst(),
        .m_axi_gmem3_awvalid(g3_awvalid), .m_axi_gmem3_awready(g3_awready), .m_axi_gmem3_wdata(g3_wdata), .m_axi_gmem3_wstrb(g3_wstrb),
        .m_axi_gmem3_wlast(g3_wlast), .m_axi_gmem3_wvalid(g3_wvalid), .m_axi_gmem3_wready(g3_wready),
        .m_axi_gmem3_bresp(2'b00), .m_axi_gmem3_bvalid(g3_bvalid), .m_axi_gmem3_bready(g3_bready),
        .m_axi_gmem4_araddr(g4_araddr), .m_axi_gmem4_arlen(g4_arlen), .m_axi_gmem4_arsize(), .m_axi_gmem4_arburst(),
        .m_axi_gmem4_arvalid(g4_arvalid), .m_axi_gmem4_arready(g4_arready), .m_axi_gmem4_rdata(g4_rdata), .m_axi_gmem4_rresp(2'b00),
        .m_axi_gmem4_rlast(g4_rlast), .m_axi_gmem4_rvalid(g4_rvalid), .m_axi_gmem4_rready(g4_rready),
        .m_axi_gmem4_awaddr(g4_awaddr), .m_axi_gmem4_awlen(g4_awlen), .m_axi_gmem4_awsize(), .m_axi_gmem4_awburst(),
        .m_axi_gmem4_awvalid(g4_awvalid), .m_axi_gmem4_awready(g4_awready), .m_axi_gmem4_wdata(g4_wdata), .m_axi_gmem4_wstrb(g4_wstrb),
        .m_axi_gmem4_wlast(g4_wlast), .m_axi_gmem4_wvalid(g4_wvalid), .m_axi_gmem4_wready(g4_wready),
        .m_axi_gmem4_bresp(2'b00), .m_axi_gmem4_bvalid(g4_bvalid), .m_axi_gmem4_bready(g4_bready),
        .m_axi_gmem5_araddr(g5_araddr), .m_axi_gmem5_arlen(g5_arlen), .m_axi_gmem5_arsize(), .m_axi_gmem5_arburst(),
        .m_axi_gmem5_arvalid(g5_arvalid), .m_axi_gmem5_arready(g5_arready), .m_axi_gmem5_rdata(g5_rdata), .m_axi_gmem5_rresp(2'b00),
        .m_axi_gmem5_rlast(g5_rlast), .m_axi_gmem5_rvalid(g5_rvalid), .m_axi_gmem5_rready(g5_rready),
        .m_axi_gmem5_awaddr(g5_awaddr), .m_axi_gmem5_awlen(g5_awlen), .m_axi_gmem5_awsize(), .m_axi_gmem5_awburst(),
        .m_axi_gmem5_awvalid(g5_awvalid), .m_axi_gmem5_awready(g5_awready), .m_axi_gmem5_wdata(g5_wdata), .m_axi_gmem5_wstrb(g5_wstrb),
        .m_axi_gmem5_wlast(g5_wlast), .m_axi_gmem5_wvalid(g5_wvalid), .m_axi_gmem5_wready(g5_wready),
        .m_axi_gmem5_bresp(2'b00), .m_axi_gmem5_bvalid(g5_bvalid), .m_axi_gmem5_bready(g5_bready)
    );
    // HBM buffers for commands and responses; host memory (PCIe) for the buckets
    axi_mem_model #(.DW(DW), .WORDS(CMD_WORDS), .BASE(CMD_BASE), .RLAT(40)) u_cmd (
        .clk(clk), .rst_n(rst_n), .araddr(g0_araddr), .arlen(g0_arlen), .arvalid(g0_arvalid), .arready(g0_arready),
        .rdata(g0_rdata), .rresp(), .rlast(g0_rlast), .rvalid(g0_rvalid), .rready(g0_rready),
        .awaddr(64'd0), .awlen(8'd0), .awvalid(1'b0), .awready(), .wdata({DW{1'b0}}), .wstrb({(DW/8){1'b0}}),
        .wlast(1'b0), .wvalid(1'b0), .wready(), .bresp(), .bvalid(), .bready(1'b1));
    axi_mem_model #(.DW(DW), .WORDS(CMD_WORDS), .BASE(RESP_BASE), .RLAT(40)) u_resp (
        .clk(clk), .rst_n(rst_n), .araddr(64'd0), .arlen(8'd0), .arvalid(1'b0), .arready(), .rdata(), .rresp(), .rlast(), .rvalid(), .rready(1'b1),
        .awaddr(g1_awaddr), .awlen(g1_awlen), .awvalid(g1_awvalid), .awready(g1_awready), .wdata(g1_wdata), .wstrb(g1_wstrb),
        .wlast(g1_wlast), .wvalid(g1_wvalid), .wready(g1_wready), .bresp(), .bvalid(g1_bvalid), .bready(g1_bready));
    // bucket records in HBM (metadata + per-position IV/tag), same measured HBM profile as the position map;
    // +brec_lat=N +brec_slow_pct=N +brec_slow_extra=N +brec_wlat=N change it.
    wire [63:0] g4_araddr, g4_awaddr; wire [7:0] g4_arlen, g4_awlen;
    wire g4_arvalid, g4_arready, g4_rvalid, g4_rlast, g4_rready, g4_awvalid, g4_awready;
    wire g4_wvalid, g4_wready, g4_wlast, g4_bvalid, g4_bready;
    wire [DW-1:0] g4_rdata, g4_wdata; wire [DW/8-1:0] g4_wstrb;
    // the stash in HBM (per-bucket lists + block pool), same measured HBM profile as the position map;
    // +stash_lat=N +stash_slow_pct=N +stash_slow_extra=N +stash_wlat=N change it.
    wire [63:0] g5_araddr, g5_awaddr; wire [7:0] g5_arlen, g5_awlen;
    wire g5_arvalid, g5_arready, g5_rvalid, g5_rlast, g5_rready, g5_awvalid, g5_awready;
    wire g5_wvalid, g5_wready, g5_wlast, g5_bvalid, g5_bready;
    wire [DW-1:0] g5_rdata, g5_wdata; wire [DW/8-1:0] g5_wstrb;
    axi_mem_model #(.DW(DW), .WORDS(1 << 16), .BASE(BREC_BASE), .RLAT(53)) u_brec (
        .clk(clk), .rst_n(rst_n), .araddr(g4_araddr), .arlen(g4_arlen), .arvalid(g4_arvalid), .arready(g4_arready),
        .rdata(g4_rdata), .rresp(), .rlast(g4_rlast), .rvalid(g4_rvalid), .rready(g4_rready),
        .awaddr(g4_awaddr), .awlen(g4_awlen), .awvalid(g4_awvalid), .awready(g4_awready), .wdata(g4_wdata), .wstrb(g4_wstrb),
        .wlast(g4_wlast), .wvalid(g4_wvalid), .wready(g4_wready), .bresp(), .bvalid(g4_bvalid), .bready(g4_bready));
    initial begin : brec_profile
        integer v;
        u_brec.slow_pct = 2; u_brec.slow_extra = 105; u_brec.wlat = 26;
        if ($value$plusargs("brec_lat=%d", v))        u_brec.lat = v;
        if ($value$plusargs("brec_slow_pct=%d", v))   u_brec.slow_pct = v;
        if ($value$plusargs("brec_slow_extra=%d", v)) u_brec.slow_extra = v;
        if ($value$plusargs("brec_wlat=%d", v))       u_brec.wlat = v;
    end
    axi_mem_model #(.DW(DW), .WORDS(STASH_WORDS), .BASE(STASH_BASE), .RLAT(53)) u_stmem (
        .clk(clk), .rst_n(rst_n), .araddr(g5_araddr), .arlen(g5_arlen), .arvalid(g5_arvalid), .arready(g5_arready),
        .rdata(g5_rdata), .rresp(), .rlast(g5_rlast), .rvalid(g5_rvalid), .rready(g5_rready),
        .awaddr(g5_awaddr), .awlen(g5_awlen), .awvalid(g5_awvalid), .awready(g5_awready), .wdata(g5_wdata), .wstrb(g5_wstrb),
        .wlast(g5_wlast), .wvalid(g5_wvalid), .wready(g5_wready), .bresp(), .bvalid(g5_bvalid), .bready(g5_bready));
    initial begin : stash_profile
        integer v;
        u_stmem.slow_pct = 2; u_stmem.slow_extra = 105; u_stmem.wlat = 26;
        if ($value$plusargs("stash_lat=%d", v))        u_stmem.lat = v;
        if ($value$plusargs("stash_slow_pct=%d", v))   u_stmem.slow_pct = v;
        if ($value$plusargs("stash_slow_extra=%d", v)) u_stmem.slow_extra = v;
        if ($value$plusargs("stash_wlat=%d", v))       u_stmem.wlat = v;
    end
    // DOMA's metadata (position map) in HBM, with the U55C's measured latency profile:
    // reads 53 cycles, 2% of them 105 slower; writes acknowledged after 26. +meta_lat=N +meta_slow_pct=N
    // +meta_slow_extra=N +meta_wlat=N change it.
    wire [63:0] g3_araddr, g3_awaddr; wire [7:0] g3_arlen, g3_awlen;
    wire g3_arvalid, g3_arready, g3_rvalid, g3_rlast, g3_rready, g3_awvalid, g3_awready, g3_wvalid, g3_wready, g3_wlast, g3_bvalid, g3_bready;
    wire [DW-1:0] g3_rdata, g3_wdata; wire [DW/8-1:0] g3_wstrb;
    axi_mem_model #(.DW(DW), .WORDS(1 << 16), .BASE(META_BASE), .RLAT(53)) u_meta (
        .clk(clk), .rst_n(rst_n), .araddr(g3_araddr), .arlen(g3_arlen), .arvalid(g3_arvalid), .arready(g3_arready),
        .rdata(g3_rdata), .rresp(), .rlast(g3_rlast), .rvalid(g3_rvalid), .rready(g3_rready),
        .awaddr(g3_awaddr), .awlen(g3_awlen), .awvalid(g3_awvalid), .awready(g3_awready), .wdata(g3_wdata), .wstrb(g3_wstrb),
        .wlast(g3_wlast), .wvalid(g3_wvalid), .wready(g3_wready), .bresp(), .bvalid(g3_bvalid), .bready(g3_bready));
    initial begin : meta_profile
        integer v;
        u_meta.slow_pct = 2; u_meta.slow_extra = 105; u_meta.wlat = 26;
        if ($value$plusargs("meta_lat=%d", v))        u_meta.lat = v;
        if ($value$plusargs("meta_slow_pct=%d", v))   u_meta.slow_pct = v;
        if ($value$plusargs("meta_slow_extra=%d", v)) u_meta.slow_extra = v;
        if ($value$plusargs("meta_wlat=%d", v))       u_meta.wlat = v;
    end
    // host memory: 8 KB per slot (the same as 32 KB per bucket at lambda = 4; independent of lambda), room for the
    // re-boot test's moved bucket area
    axi_mem_model #(.DW(DW), .WORDS((`ORAM_N > 4096) ? (1 << 20) : ((`ORAM_N << 13) / 32)), .BASE(HOST_BASE), .RLAT(100), .WF_DEPTH(8192)) u_host (
        .clk(clk), .rst_n(rst_n), .araddr(g2_araddr), .arlen(g2_arlen), .arvalid(g2_arvalid), .arready(g2_arready),
        .rdata(g2_rdata), .rresp(), .rlast(g2_rlast), .rvalid(g2_rvalid), .rready(g2_rready),
        .awaddr(g2_awaddr), .awlen(g2_awlen), .awvalid(g2_awvalid), .awready(g2_awready), .wdata(g2_wdata), .wstrb(g2_wstrb),
        .wlast(g2_wlast), .wvalid(g2_wvalid), .wready(g2_wready), .bresp(), .bvalid(g2_bvalid), .bready(g2_bready));
    // buckets kept in HBM (gmem6, fixed boundary: buckets 0 .. hbm_bkts-1), HBM-like latency
    axi_mem_model #(.DW(DW), .WORDS((`ORAM_B * `BUCKET_BYTES) / 32 + 64), .BASE(HBMB_BASE), .RLAT(53)) u_hbmb (
        .clk(clk), .rst_n(rst_n), .araddr(g6_araddr), .arlen(g6_arlen), .arvalid(g6_arvalid), .arready(g6_arready),
        .rdata(g6_rdata), .rresp(), .rlast(g6_rlast), .rvalid(g6_rvalid), .rready(g6_rready),
        .awaddr(g6_awaddr), .awlen(g6_awlen), .awvalid(g6_awvalid), .awready(g6_awready), .wdata(g6_wdata), .wstrb(g6_wstrb),
        .wlast(g6_wlast), .wvalid(g6_wvalid), .wready(g6_wready), .bresp(), .bvalid(g6_bvalid), .bready(g6_bready));

    // ---------------- AXI-Lite tasks (what XRT does) ----------------
    // Driven on the falling edge, half a cycle from where the kernel samples. Each task waits for
    // the registered consequence of its handshake (bvalid / rvalid), never for a combinational
    // ready: the kernel holds awready/arready low while a response is pending, so the request
    // cannot be taken twice, and nothing depends on when combinational logic is re-evaluated.
    task axil_wr; input [11:0] a; input [31:0] d; begin
        @(negedge clk); awaddr = a; wdata = d; awvalid = 1; wvalid = 1;
        while (!bvalid) @(negedge clk);
        awvalid = 0; wvalid = 0; bready = 1;               // response taken on the next rising edge
        @(negedge clk); bready = 0;
    end endtask
    task axil_rd; input [11:0] a; output [31:0] d; begin
        @(negedge clk); araddr = a; arvalid = 1;
        while (!rvalid) @(negedge clk);
        d = rdata; arvalid = 0; rready = 1;
        @(negedge clk); rready = 0;
    end endtask

    // ---------------- host-side state ----------------
    integer last_put [0:N-1];            // command id of the last PUT to each key, -1 = never written
    integer cmd_key [0:4095], cmd_type [0:4095], cmd_id [0:4095];
    integer gid = 0, fails = 0, seed, ncmd1, ncmd2, hl, hg;
    // +packed=R: R-byte records packed into each block (offset and length in the command header).
    // Every GET is checked against a byte-exact image of the block, so the record's neighbours and
    // never-written bytes (zeros) are checked too; PUT data carries junk outside its record.
    integer rec_len = 0;
    integer cmd_off [0:4095], cmd_len [0:4095];
    reg [DW-1:0] refimg [0:N*BEATS-1];
    function [DW-1:0] pat; input integer id, beat, key; begin
        pat = {8{id[15:0], beat[7:0], key[7:0]}};
    end endfunction

    // +put_pct=P: P% of the commands are PUTs (one random draw per command, as without it, so the keys are the
    // same for every P). Bucket-port timing: a hash of the gaps between consecutive read and write-back requests
    // on the host bucket port; equal hashes for different P mean the GET/PUT mix is invisible in the timing.
    integer put_pct, kseed;
    reg  [63:0] bus_h, key_h; integer bus_n; reg [63:0] bus_last;
    initial begin if (!$value$plusargs("put_pct=%d", put_pct)) put_pct = -1; bus_h = 0; bus_n = 0; bus_last = 0; end
    always @(posedge clk) if ((g2_arvalid && g2_arready) || (g2_awvalid && g2_awready)) begin
        bus_h    <= (bus_h * 64'd1000003) ^ (cyc_tb - bus_last) ^ ((g2_awvalid && g2_awready) ? 64'h8000_0000_0000_0000 : 64'd0);
        bus_last <= cyc_tb; bus_n <= bus_n + 1;
    end
    // Deterministic pseudo-random draws (xorshift32): identical on every simulator version. Verilator's $random sequence
    // changed between releases, which changed the stimulus and with it the calibrated timing budgets.
    function [31:0] xs32; input [31:0] x; reg [31:0] y; begin
        y = (x == 32'd0) ? 32'h2545F491 : x; y = y ^ (y << 13); y = y ^ (y >> 17); xs32 = y ^ (y << 5);
    end endfunction
    // prepare a run: headers at cmd word i, PUT data from word HC/32 + i*BEATS
    task prepare; input integer size; input integer bad_at; integer i, j, hcw; begin
        bus_h = 64'd0; bus_n = 0; bus_last = cyc_tb;                 // the bucket-port timing hash restarts per run
        key_h = 64'd0;
        hcw = (((size * 32) + 4095) / 4096) * 4096 / 32;
        for (i = 0; i < size; i = i + 1) begin
            if (put_pct < 0) begin seed = xs32(seed); cmd_type[i] = seed[0] ? 2 : 1; end
            else begin kseed = xs32(kseed); cmd_type[i] = (($unsigned(kseed) % 100) < put_pct) ? 2 : 1; end  // own stream: same keys for every P
            if (put_pct < 0) begin seed = xs32(seed); cmd_key[i] = $unsigned(seed) % NK; end
            else begin kseed = xs32(kseed); cmd_key[i] = $unsigned(kseed) % NK; end
            cmd_off[i] = 0; cmd_len[i] = 0;                         // whole block
            if (rec_len > 0) begin                                   // one record of the block
                seed = xs32(seed); cmd_off[i] = ($unsigned(seed) % (BEATS*32/rec_len)) * rec_len;
                cmd_len[i] = rec_len;
            end
            if (i == bad_at) begin
                if (rec_len > 0) begin cmd_type[i] = 2; cmd_off[i] = BEATS*32 - rec_len + 4; end   // runs past the block end
                else cmd_key[i] = NK + 5;                           // outside the ORAM's n blocks: must be rejected
            end
            cmd_id[i] = gid; gid = gid + 1;
            key_h = (key_h * 64'd31) ^ cmd_key[i];                   // the run's key sequence (diagnostic)
            u_cmd.mem[i] = {{(DW-128){1'b0}}, cmd_len[i][31:0], cmd_off[i][31:0], cmd_key[i][31:0], 24'd0, cmd_type[i][7:0]};
            if (cmd_type[i] == 2) for (j = 0; j < BEATS; j = j + 1) begin
                if (rec_len > 0) seed = xs32(seed);
                u_cmd.mem[hcw + i*BEATS + j] = pat(cmd_id[i], j, cmd_key[i]) ^ ((rec_len > 0) ? {DW/32{seed[31:0]}} : {DW{1'b0}});
            end
        end
    end endtask

    // +preload: like host_doma's initialization, PUT every key once, in order 0..n-1 (n = +nblk, else N)
    task prepare_seq; input integer size; integer i, j, hcw; begin
        hcw = (((size * 32) + 4095) / 4096) * 4096 / 32;
        for (i = 0; i < size; i = i + 1) begin
            cmd_type[i] = 2; cmd_key[i] = i % NK; cmd_id[i] = gid; gid = gid + 1; cmd_off[i] = 0; cmd_len[i] = 0;
            u_cmd.mem[i] = {{(DW-64){1'b0}}, cmd_key[i][31:0], 24'd0, cmd_type[i][7:0]};
            for (j = 0; j < BEATS; j = j + 1) u_cmd.mem[hcw + i*BEATS + j] = pat(cmd_id[i], j, cmd_key[i]);
        end
    end endtask

    // start a run like xrt::run, wait for ap_done, then check every response
    // the testbench's own count of handshaked beats on gmem2, per launch (checked against record [size+1])
    reg [63:0] tb_rd = 0, tb_wr = 0;
    always @(posedge clk) begin
        if (g2_rvalid && g2_rready) tb_rd <= tb_rd + 1;
        if (g2_wvalid && g2_wready) tb_wr <= tb_wr + 1;
    end
    task run; input integer size; input integer bad_at; input [8*8-1:0] name;
        integer i, j, b, hcw, hrw, t0, t1, bad, gets, puts, rej; reg [31:0] v; reg [DW-1:0] exp, got, sum, nd, trf; begin
        hcw = (((size * 32) + 4095) / 4096) * 4096 / 32;
        hrw = ((((size + 2) * 32) + 4095) / 4096) * 4096 / 32;              // after records [size], [size+1]
        for (i = 0; i <= size; i = i + 1) u_resp.mem[i] = {DW{1'b1}};          // poison the headers
        axil_wr(12'h010, CMD_BASE[31:0]);  axil_wr(12'h014, CMD_BASE[63:32]);
        axil_wr(12'h01C, RESP_BASE[31:0]); axil_wr(12'h020, RESP_BASE[63:32]);
        axil_wr(12'h028, HOST_BASE[31:0] + PAGES_OFF[31:0]); axil_wr(12'h02C, HOST_BASE[63:32]);
        axil_wr(12'h03C, META_BASE[31:0]); axil_wr(12'h040, META_BASE[63:32]);
        axil_wr(12'h048, BREC_BASE[31:0]); axil_wr(12'h04C, BREC_BASE[63:32]);
        axil_wr(12'h054, STASH_BASE[31:0]); axil_wr(12'h058, STASH_BASE[63:32]);
        axil_wr(12'h060, NBLK);                                             // run-time blocks
        axil_wr(12'h068, HBMB_BASE[31:0]); axil_wr(12'h06C, HBMB_BASE[63:32]);
        axil_wr(12'h074, (((NK + `ORAM_C - 1) / `ORAM_C) * HBM_PCT) / 100);   // buckets in HBM
        axil_wr(12'h07C, POOL);                                             // stash pool entries
        axil_wr(12'h034, size);
        axil_wr(12'h004, 32'h1); axil_wr(12'h008, 32'h1);                      // interrupts on
        t0 = u_cmd.cyc;
        tb_rd = 0; tb_wr = 0;                                                   // this launch's gmem2 beats
        axil_wr(12'h000, 32'h1);                                                // ap_start
        v = 0;
        while (!v[1]) begin repeat (200) @(posedge clk); axil_rd(12'h000, v); end
        t1 = u_cmd.cyc;
        if (!irq) begin $display("FAIL %0s: interrupt not raised", name); fails = fails + 1; end
        axil_wr(12'h00C, 32'h1);                                                // clear ISR
        @(posedge clk); @(posedge clk);
        if (irq) begin $display("FAIL %0s: interrupt not cleared", name); fails = fails + 1; end
        axil_rd(12'h000, v);
        if (!v[2] || v[1] || v[0]) begin $display("FAIL %0s: CTRL after done = %h (want idle, done cleared)", name, v); fails = fails + 1; end
        bad = 0; gets = 0; puts = 0; rej = 0;
        for (i = 0; i < size; i = i + 1) begin
            got = u_resp.mem[i];
            if (i == bad_at) begin
                if (got[7:0] !== 8'h11 || got[127:96] !== ((rec_len > 0) ? 32'h40 : 32'h4)) begin bad = bad + 1;
                    $display("FAIL %0s: cmd %0d (key %0d outside the ORAM) not rejected: type %h status %h", name, i, cmd_key[i], got[7:0], got[127:96]); end
                else rej = rej + 1;
            end else if (got[7:0] !== 8'h10 || got[63:32] !== cmd_key[i]) begin
                bad = bad + 1;
                if (bad < 4) $display("FAIL %0s: cmd %0d header type %h key %0d status %h", name, i, got[7:0], got[63:32], got[127:96]);
            end else if (cmd_type[i] == 2) begin
                last_put[cmd_key[i]] = cmd_id[i]; puts = puts + 1;
                if (rec_len > 0) for (j = 0; j < BEATS; j = j + 1) begin      // the record's bytes land, nothing else
                    nd = u_cmd.mem[hcw + i*BEATS + j];
                    for (b = 0; b < DW/8; b = b + 1)
                        if (cmd_len[i] == 0 || (j*32 + b >= cmd_off[i] && j*32 + b < cmd_off[i] + cmd_len[i]))   // 0 = whole block
                            refimg[cmd_key[i]*BEATS + j][8*b +: 8] = nd[8*b +: 8];
                end
            end else if (rec_len > 0) begin
                gets = gets + 1;
                for (j = 0; j < BEATS; j = j + 1)
                    if (u_resp.mem[hrw + i*BEATS + j] !== refimg[cmd_key[i]*BEATS + j]) begin
                        if (bad < 4) $display("FAIL %0s: GET cmd %0d key %0d beat %0d differs from the block image (record or neighbour)", name, i, cmd_key[i], j);
                        bad = bad + 1; j = BEATS;
                    end
            end else begin
                gets = gets + 1;
                for (j = 0; j < BEATS; j = j + 1) begin
                    exp = (last_put[cmd_key[i]] < 0) ? {DW{1'b0}} : pat(last_put[cmd_key[i]], j, cmd_key[i]);
                    if (u_resp.mem[hrw + i*BEATS + j] !== exp) begin
                        if (bad < 4) $display("FAIL %0s: GET cmd %0d key %0d beat %0d data mismatch", name, i, cmd_key[i], j);
                        bad = bad + 1; j = BEATS;
                    end
                end
            end
        end
        sum = u_resp.mem[size];
        $display("%0s: size=%0d  host cycles=%0d  device total=%0d  completed=%0d  latency min/max=%0d/%0d  errors=%h  gets=%0d puts=%0d rejected=%0d  bad=%0d",
                 name, size, t1 - t0, sum[127:64], sum[255:224], sum[159:128], sum[191:160], sum[223:192], gets, puts, rej, bad);
        if (sum[7:0] !== 8'h5A || sum[63:32] !== `BEATS_PER_BLOCK ||        // bytes 4-7: block size in beats
            sum[255:224] !== size - (bad_at >= 0 ? 1 : 0) || sum[223:192] !== 0) begin
            $display("FAIL %0s: summary record wrong", name); fails = fails + 1; end
        trf = u_resp.mem[size + 1];                                             // traffic record [size+1]
        $display("%0s: bucket-port timing hash %h over %0d requests (keys %h)", name, bus_h, bus_n, key_h);
        $display("%0s: traffic record: read beats %0d, write beats %0d on the bucket port (testbench saw %0d / %0d)",
                 name, trf[127:64], trf[191:128], tb_rd, tb_wr);
        if (trf[7:0] !== 8'h5B || trf[127:64] !== tb_rd || trf[191:128] !== tb_wr || trf[255:192] !== 0) begin
            $display("FAIL %0s: traffic record wrong", name); fails = fails + 1; end
        fails = fails + bad;
    end endtask

    initial begin : main
        integer k; reg [31:0] v;
        if (!$value$plusargs("seed=%d", seed)) seed = 7;
        kseed = seed + 1000;                                   // +put_pct: operations and keys only
        if ($value$plusargs("nblk=%d", NBLK)) NK = (NBLK == 0 || NBLK > N) ? N : NBLK;
        if (!$value$plusargs("cmds=%d", ncmd1)) ncmd1 = 120;
        if (!$value$plusargs("cmds2=%d", ncmd2)) ncmd2 = 40;
        if ($value$plusargs("host_lat=%d", hl)) u_host.lat = hl;
        if ($value$plusargs("hbm_pct=%d", hl)) HBM_PCT = hl;
        if ($value$plusargs("pool=%d", hl)) POOL = hl;
        if ($value$plusargs("hbmb_lat=%d", hl)) u_hbmb.lat = hl;
        if ($value$plusargs("host_gap=%d", hg)) u_host.gap_pct = hg;
        if ($value$plusargs("host_wlat=%d", hg)) u_host.wlat = hg;   // writes land late: reads can overtake them
        if ($value$plusargs("host_rdy_gap=%d", hg)) begin u_host.rdy_gap = hg; u_cmd.rdy_gap = hg; u_resp.rdy_gap = hg; end
        for (k = 0; k < N; k = k + 1) last_put[k] = -1;
        if ($value$plusargs("packed=%d", rec_len)) begin
            if (rec_len <= 0 || rec_len > BEATS*32 || (BEATS*32) % rec_len != 0) begin
                $display("FAIL: +packed=%0d must divide the %0d-byte block", rec_len, BEATS*32); fails = fails + 1; rec_len = 0; end
            for (k = 0; k < N*BEATS; k = k + 1) refimg[k] = {DW{1'b0}};
            $display("packed records: %0d bytes, %0d per block", rec_len, (rec_len > 0) ? BEATS*32/rec_len : 0);
        end
        $display("tb_doma_kernel | %0s | N=%0d block=%0d B | host read latency %0d cycles, gaps %0d%%, writes land after %0d cycles",
                 `ORAM_PKG_REV, N, BEATS*32, u_host.lat, u_host.gap_pct, u_host.wlat);
        $fflush;
        repeat (20) @(posedge clk); rst_n = 1;
        axil_rd(12'h000, v);
        if (!v[2]) begin $display("FAIL: kernel not idle after reset (CTRL=%h)", v); fails = fails + 1; end
        // +start_delay=N: the host launches the kernel only N cycles after reset (XRT and emulation
        // take far longer than this testbench); the kernel must not touch memory before that
        if ($value$plusargs("start_delay=%d", k)) repeat (k) @(posedge clk);
        run(0, -1, "init");                                         // boot + key + lease, like init_kernel
        if ($test$plusargs("preload")) begin prepare_seq(NK); run(NK, -1, "preload"); end   // every key of the n blocks once
        prepare(ncmd1, -1); run(ncmd1, -1, "run1");
        prepare(ncmd2, ncmd2 / 2); run(ncmd2, ncmd2 / 2, "run2");     // second launch, lease reused, one bad key (packed: one bad record range)
        // +reboot: an init launch on the booted kernel re-boots DOMA with new arguments (+nblk2, +pagesoff),
        // as a new host process does. Every block then reads as zeros, and commands must run without 0x20.
        if ($test$plusargs("reboot")) begin
            if ($value$plusargs("nblk2=%d", v)) begin NBLK = v; NK = (NBLK == 0 || NBLK > N) ? N : NBLK; end
            if ($value$plusargs("pagesoff=%d", v)) PAGES_OFF = v;
            for (k = 0; k < N*BEATS; k = k + 1) refimg[k] = {DW{1'b0}};
            run(0, -1, "reinit");
            prepare(ncmd1, -1); run(ncmd1, -1, "run3");
        end
        if (u_hbmb.errors) begin $display("FAIL: memory errors on the HBM bucket port: %0d", u_hbmb.errors); fails = fails + 1; end
        if (u_cmd.errors || u_resp.errors || u_host.errors || u_meta.errors || u_brec.errors || u_stmem.errors) begin
            $display("FAIL: memory errors (out of range or AXI protocol): cmd %0d resp %0d host %0d meta %0d brec %0d stash %0d (protocol %0d/%0d/%0d/%0d/%0d/%0d)", u_cmd.errors, u_resp.errors, u_host.errors, u_meta.errors, u_brec.errors, u_stmem.errors, u_cmd.perr, u_resp.perr, u_host.perr, u_meta.perr, u_brec.perr, u_stmem.perr);
            fails = fails + 1; end
        $display("calib: ar_max_wb=%0d ar_max_wb_h=%0d ct_max_wb=%0d ct_max_done=%0d", dut.u_doma.u_oram.ar_max_wb, dut.u_doma.u_oram.ar_max_wb_h, dut.u_doma.u_oram.ct_max_wb, dut.u_doma.u_oram.ct_max_done);   // worst encryption end after the arrival, from the start; worst completion
        if (fails == 0) $display("*** DOMA KERNEL: ALL CHECKS PASSED ***");
        else            $display("*** DOMA KERNEL: %0d FAILURE(S) ***", fails);
        $finish;
    end
    // heartbeat (+hb=N cycles, default 50000) and a global limit (+limit=N cycles, default 20M)
    integer hb_n, lim, cyc_tb = 0, ar_host = 0, aw_host = 0;
    // +trace_ctl: every AXI-Lite cycle in the first 600 cycles
    always @(posedge clk) if ($test$plusargs("trace_ctl") && cyc_tb < 600 && (awvalid || wvalid || bvalid || arvalid || rvalid || dut.ap_start_r))
        $display("CTL cyc=%0d aw=%0d/%0d w=%0d/%0d b=%0d/%0d ar=%0d/%0d r=%0d/%0d awaddr=%h araddr=%h start=%0d kst=%0d", cyc_tb,
                 awvalid, awready, wvalid, wready, bvalid, bready, arvalid, arready, rvalid, rready, awaddr, araddr, dut.ap_start_r, dut.kst);
    always @(posedge clk) begin
        cyc_tb <= cyc_tb + 1;
        if (g2_arvalid && g2_arready) ar_host <= ar_host + 1;
        if (g2_awvalid && g2_awready) aw_host <= aw_host + 1;
        if (hb_n > 0 && cyc_tb % hb_n == 0 && cyc_tb > 0) begin
            $display("HB cyc=%0d kst=%0d key_ready=%0d oram_ready=%0d lease=%0d idx=%0d host AR=%0d AW=%0d",
                     cyc_tb, dut.kst, dut.key_ready, dut.oram_ready, dut.lease_ok, dut.idx, ar_host, aw_host);
            $fflush;
        end
        if (cyc_tb == lim) begin $display("FAIL: global limit of %0d cycles reached (kst=%0d)", lim, dut.kst); $fflush; $finish; end
    end
    initial begin
        if (!$value$plusargs("hb=%d", hb_n)) hb_n = 50000;
        if (!$value$plusargs("limit=%d", lim)) lim = 200000000;   // the boot touch pass: n accesses (4 KB, n = 4,096: ~31M cycles)
    end
endmodule
