# v14b: calibrating the on-package budgets on the card

DOMA keeps on-package buckets in plaintext in arrival builds (v14). Such an access has two deadlines, both relative to
its bucket's arrival `t_arr`:

- **(1) Write-back start:** by `t_arr + AR_WB_H`, every eviction decision is made and the write-back has started. This is an early check.
- **(2) Hand-off:** by the release time `t_arr + AR_REL_H`, the write is handed off (its last W beat accepted) and the release gate is reached.

A miss of either is a timing overrun (0x108), raised at the release time. v14 set both budgets in simulation (the
cycle model, every metadata read at 200 cycles, plus a margin). On the U55C at 4 KB, λ = 7, they were too tight.
This document covers:

- the cause;
- what v14b records;
- how to set the budgets from the card's own accesses.

## 1. What happened on the card, and why

| Share on package | Halt record (decoded) | What it means |
|---|---|---|
| 100% | state 24 (S_RES_STREAM), access cycle 3,311 | At the release time the write had been handed off, so the overrun came from deadline (1): the write-back started after `t_arr + 855` |
| 20% | state 22 (S_DDR_WRITE), access cycle 3,417 | Deadline (2): the write was still being sent at `t_arr + 1938` |

Both access cycles are `t_arr + AR_REL_H + 1`. The record is latched one cycle after the release check.

On the plaintext path, the eviction decisions start only when the stash open is complete (`S_SCAN` waits for
`st_ready`). The open is issued at the position lookup, about 1,300 cycles before a 4 KB bucket arrives.

- **What it reads:** up to a window of 4 KB blocks from the stash port (HBM[12]). That is roughly as many beats as the bucket read itself.
- **In the memory models:** the stash is ready a few cycles after the arrival. The worst write-back start is about 290 cycles after the arrival, and about 730 with every metadata and stash read at 200 cycles. v14's AR_WB_H = 855 rests on that.
- **In v11g and v13:** the same wait was hidden behind decryption and re-encryption (AR_WB_H = 2,025), which is why v13 runs on the card.

With a slower stash port, the production RTL halts exactly as the card did (`sim/repro_card_halt.sh`, 4 KB, λ = 7, preload, 100% on package unless noted):

| Stash port in the model | Halt (production build) |
|---|---|
| reads 53 cycles (the model as before) | none |
| every read 350 cycles | state 24, deadline (1), write-back started 882 after the arrival: missed by 27 |
| every read 450 cycles | state 22, deadline (2), release gate 1,968: missed by 30 |
| read beats on 60% of cycles | state 22, deadline (2), release gate 2,069: missed by 131 |
| 20% on package, every read 600 cycles | state 22, deadline (2), write-back issued 977, release gate 2,006: missed by 68 |

What does **not** reproduce it:

- **HBM-like coupling** (`+hbm_like=W` on every HBM port): writes acknowledged when queued and landing `W` cycles later, reads held behind the writes accepted before them, no W beat before its address. At `W = 300` the worst write-back start (295) and release gate (1,324) are what they are without it. The stash's commit writes land long before the next access opens the stash.
- **The bucket port** (W held, reads behind writes): the write itself is handed off in time at 100%.
- **The bank-conflict path:** never seen in any simulation. v14b's halt record now tells a conflict (code 11) from deadline (1) (code 01).

The fix is to budget for the card's real stash and HBM timing. Measure it there with the debug build, then set
AR_WB_H and AR_REL_H from the card's worst case plus margin.

## 2. What v14b records

### Halt record (every build)

A halted launch's summary carries it in place of the latency fields. `host_doma` and `host_phases` decode it for the
first halted launch and the last.

| Bits | Field |
|---|---|
| 63:40 | bucket |
| 39:35 | FSM state |
| 34 | HBM (on-package) bucket |
| 33:32 | **v14b:** on-package deadline: 01 write-back start (1), 10 hand-off by the release (2), 11 scratch bank conflict, 00 another cause |
| 31:20 | **v14b:** cycles missed by (saturates at 4095) |
| 19:17 | memory-unit errors (position map, bucket records, stash) |
| 16 | **v14b:** the missed time is a lower bound (the late event had not happened when this summary was written; a later launch's summary has the final value) |
| 15:0 | access cycle |

### Debug build (`build.sh DEBUG=1`, with `TRACE=1 SCHED=arrival`)

For calibration only. Never measure performance with it and never deploy it.

- **No halt on package:** an on-package overrun is recorded and counted, and does not halt. The access runs on, the release waits for the hand-off, and the access's times are the card's own. Off-package overruns and every other error still halt.
- **Summary records:** after the summary and the traffic record, three more records (the response data then starts at `roundup4k((n + 5) * 32)`; summary byte 2 = 0x03 marks the bitstream). All counts are since boot.

  - **[n+2], counters (0x5C):**
    - the build's AR_WB_H and AR_REL_H;
    - on-package accesses;
    - deadline (1) misses and deadline (2) misses, each with its worst miss;
    - scratch bank conflicts;
    - worst write-back start, release gate and stash ready after the arrival.
  - **[n+3], the first on-package overrun (0x5D), latched as it happens:**
    - which deadline (or a bank conflict);
    - FSM state, access number since boot, access cycle, cycles since the arrival;
    - missed by (final once that access ends);
    - copy beats landed, copies done and queued, the pending-copy mask, positions sendable, bucket beats written;
    - on the bucket port and on the stash port: addresses waiting for data (AW − WLAST), bursts waiting for B, reads outstanding (AR − RLAST), and the AW/W/B/AR/R valid-ready levels;
    - flags: arrived, write-back issued, writing, stash ready, stash quiet, record in, copy running.
  - **[n+4], the first deadline (2) miss (0x5E):** the same layout.
- **Per-access trace records:** with size bit 31 set, each trace record is 64 bytes. First the 16 phase timestamps, then the controller's own record of the access. It holds raw access cycles (0xFFFF = did not happen), so the host recomputes each deadline exactly as the RTL checks it:

| Word | Field |
|---|---|
| 0 | `t_arr` (bucket read done) |
| 1 | flags: [0] on package, [1] plaintext path, [2] deadline (1) missed, [3] deadline (2) missed, [4] bank conflict, [5] arrival seen, [6] PUT, [11:8] eviction copies |
| 2 | write-back issued (`S_EA_START`) |
| 3 | release gate reached (`S_DONE_GATE`: the write handed off) |
| 4, 5 | last, first W accepted |
| 6 | bucket record in |
| 7 | stash open issued |
| 8 | stash ready (`S_SCAN` left: the decisions start) |
| 9 | `S_SCAN` entered |
| 10 | last eviction copy landed |
| 11 | cycles with W held by the memory |
| 12 | cycles writing with no W offered (waiting for copies) |
| 13, 14 | bucket read AR, first R |
| 15 | access end |

The deadline checks are: write-back start `w2 − w0 ≤ AR_WB_H`, and release gate `w3 − w0 ≤ AR_REL_H`.

In simulation (`sim/run_verilator.sh onpkg`, test (g)), every record equals the testbench's own timestamps of the same
events. The flags follow from them, and the counters and snapshots match the records' tally. The same flow ran end to
end through the mock XRT (`sim/xrt_mock`, `DEBUG=1`).

## 3. Interim budgets until the card calibration (`build.sh INTERIM=1`, 4 KB, λ = 7)

To run on the card before the calibration, `INTERIM=1` replaces the on-package budgets with values that cover every
stash and bucket-record read taking 500 cycles. The position map stays at 200 cycles, the card's lookups meet CT_RD.

| | AR_WB_H | AR_REL_H | AR_DONE_H | release vs v11g |
|---|---|---|---|---|
| v11g (encrypted path) | 2,025 | 3,141 | 3,575 | — |
| v14 (default, simulation-calibrated) | 855 | 1,938 | 2,372 | 1,203 earlier |
| v14b `INTERIM=1` | 1,455 | 2,538 | 2,972 | 603 earlier (half the saving) |

How the interim budgets are derived: the cycle model (`sim/worst_case.py`, part 4) on the directed worst cases (full
stash windows) at that profile.

- The write-back start comes at 1 + 1,084 + 296 = 1,381 cycles after the arrival, and the release gate at 1 + 1,084 + 1,325 = 2,410. The stash wait is 1,084 against 484 at 200 cycles: two dependent stash reads.
- Budgets as `sim/budgets_v14.py` sets them: AR_WB_H = 1,381 + 74, AR_REL_H = 2,410 + bp(128) 54 + 74, AR_DONE_H = AR_REL_H + 434.
- Off-package budgets are unchanged. The option builds only at 4 KB with λ = 7; any other size or λ stops the build.
- The summary's byte 2 bit 2 marks the bitstream, and the hosts print "on-package budgets: INTERIM".

Checked in simulation (4 KB, λ = 7, `-DORAM_ONPKG_INTERIM`, production build):

- **Directed worst cases:** with every stash and record read at 500 cycles, they run without an overrun. Worst write-back start 1,378, worst release gate 2,407.
- **Kernel with 500-cycle stash reads:** at 100% and at 20% on package, every GET is correct and nothing halts.
- **History and speed:** the release (3,892 cycles after the access start) and the end (4,023) are the same in every access across stash histories and speeds. The runs: preloaded, empty with other keys, metadata at 200 cycles, stash at 500.
- **A write held beyond the budget:** halts at exactly `t_arr + 2,538`, the halt record naming deadline (2), missed by 1,175 cycles.
- **A stash at 900 cycles a read:** halts at the same point, deadline (2), missed by 172.
- **0% on package:** identical to the default build on every line.

With these budgets an on-package access at 100% takes 4,157 cycles in simulation, against 3,557 with v14's.

It is still an assumption about the card: a stash slower than 500 cycles a read halts it too, with a halt record
that says by how much. The calibration below replaces it.

## 4. Calibration on the card

**Build** (in its own folder; same `NMAX` as the production 4 KB build):

```bash
TARGET=hw LAMBDA=7 SCHED=arrival TRACE=1 DEBUG=1 NMAX=<n> bash build.sh
g++ -std=c++17 -O2 host_phases.cpp -I$XILINX_XRT/include -L$XILINX_XRT/lib -lxrt_coreutil -pthread -o host_phases
```

Note the kernel clock v++ achieves (`check_timing.sh`). Memory latencies are fixed in time, so a slower debug
bitstream sees fewer cycles. Pass the clock to the script with `--mhz`, and the card's worst values are scaled up to 300 MHz.

**Run** at least 1M accesses at 100% on package, and a run at 20% (same `DOMA_N` / `DOMA_POOL` as production):

```bash
DOMA_LAMBDA=7 DOMA_HBM_PCT=100 DOMA_PHASE_TRACE=1 DOMA_ONPKG_CSV=onpkg100.csv DOMA_PHASES=mix:1048576 \
  ./host_phases doma_hw.xclbin 65536 | tee onpkg100.log
DOMA_LAMBDA=7 DOMA_HBM_PCT=20  DOMA_PHASE_TRACE=1 DOMA_ONPKG_CSV=onpkg20.csv  DOMA_PHASES=mix:1048576 \
  ./host_phases doma_hw.xclbin 65536 | tee onpkg20.log
```

The preload's accesses are recorded too. For each phase and for the whole run, the log shows:

- the counters and the first-overrun snapshots;
- p50 / p99 / p99.9 / p99.99 / max of every phase after the arrival;
- the misses against the bitstream's budgets.

**Set the budgets:**

```bash
python3 sim/card_budgets.py --mhz <MHz> onpkg100.csv onpkg20.csv            # report
python3 sim/card_budgets.py --mhz <MHz> --write onpkg100.csv onpkg20.csv    # writes ORAM_AR_{WB,REL,DONE}_H_L7_B128
```

Rule, with the margin `M(x) = ceil(x · s · (1 + pct)) + abs`. Defaults: `abs = 74` (the λ = 7 margin used since
v11a), `pct = 5%`, and `s = max(1, 300 / MHz)`.

- `AR_WB_H(card) = M(worst write-back start)`
- `AR_REL_H(card) = max(M(worst release gate), AR_WB_H(card) + worst (release gate − write-back start) · s)`. A write that starts at the last allowed cycle and then takes its worst observed time still makes the release.
- `AR_WB_H = max(current, card)` and `AR_REL_H = max(current, card)`. Never below the simulation's cycle-model worst case: the directed adverse cases may not occur in 1M random accesses.
- `AR_DONE_H = AR_REL_H + (AR_DONE_H − AR_REL_H as before)`: the acknowledgement allowance is unchanged.

The script also prints:

- the budgets for pct = 0%, 5% and 10%;
- the worst accesses broken down (record in, stash open, stash ready, write-back start, last copy, hand-off, W held / starved), so it is clear what was late;
- how much of v14's saving over v11g remains. At 4 KB, v11g releases at `t_arr + 3,141` and v14 at `t_arr + 1,938`, a saving of 1,203 cycles per on-package access.

For example, on the simulation with every stash read at 350 cycles (`sim/repro_card_halt.sh`, 716 accesses), the
script gives AR_WB_H 1,001 and AR_REL_H 2,157. That releases 984 cycles earlier than v11g, so 82% of v14's saving
remains. The card's numbers decide the real values.

**Then:**

1. Rebuild the production bitstream with the new `oram_params.vh` (no DEBUG, no TRACE).
2. Rerun the `arrival` and `onpkg` groups at 4 KB (`ORAM_LAMBDA=7 bash sim/run_verilator.sh onpkg`). The budget checks there read the params file.
3. Run on the card.

The release time stays a fixed offset from the arrival, so the observable behaviour (release and end fixed across
histories) is unchanged. Only the offset moves.
