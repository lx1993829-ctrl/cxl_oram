# ZCU208 ORAM: security fixes

The ZCU208 set is a smaller, earlier architecture than the gem5 RTL:
- on-chip BRAM stash, position map, IV table and bucket metadata;
- one AXI master to DDR4;
- 512 slots × 4 KB, 8 slots per bucket, 64 buckets.

The crypto engine, AXI master, bucket metadata and lease table are byte-identical to the gem5
originals. The controller and top level are different code. So the gem5 fixes are ported here, not
patched in.

Work proceeds in phases. Each phase is verified with your `tb_onboard_test_top` (53 tests) under
Icarus. The baseline (unmodified) passes all 53.

## Security audit

**Critical: crypto and integrity**

| # | Finding | Status |
|---|---|---|
| F1 | Public NIST test key `2b7e1516…09cf4f3c` hard-coded in `onboard_test_top`, plus a fixed IV seed. The GCM engine derives every IV from the seed (internal LFSR), so every boot replays the same IV sequence. | **Phase 1:** key/seed now enter through `key_load` (latched once per boot; nothing runs before it). Per your decision, LFSRs stand in for a TRNG for now, so the seed stays deterministic and the cross-boot IV repeat remains a known limitation of the evaluation build (see below). |
| F2 | GHASH pending-FIFO overflow (same engine as gem5): most of each 4 KB block is left out of the tag, so tags are not standard GCM and most of each block is unauthenticated. | **Phase 1: fixed** |
| F3 | Decrypted plaintext is streamed to the client and the stash before the tag is checked. | **Phase 2: fixed** (results buffered; released only after all 8 positions verify, at a fixed time) |
| F4 | `err_tag_mismatch` is cleared at the start of every access, and the controller keeps running. | **Phase 1: fixed** (sticky, fail-stop) |
| F5 | Only the target slot is verified: tampered holes or other slots go unnoticed (occupancy oracle). | **Phase 2: fixed** (all 8 positions verified every access) |
| F6 | Only changed slots are re-encrypted, so the ciphertext diff reveals what changed. | **Phase 2: fixed** (all 8 positions re-encrypted with fresh IVs; whole bucket written back) |
| F7 | DDR is initialized with a plaintext counter pattern, not ciphertext. | **Phase 2: fixed** (boot-time encrypted format pass) |
| F8 | Latency differs per access path (read/write × bucket/stash hit). | **Phase 2: fixed** (every path 10,232 cycles in simulation) |

**Medium**

| # | Finding | Status |
|---|---|---|
| F9 | Fixed-priority client arbiter: starvation and a cross-client timing channel. | **Phase 3: fixed** (time-division arbiter + dummies; non-interference verified) |
| F10 | No lease lock-out. | **Phase 1: fixed**; the lock-out was **removed in v11a** (a rejected request is served as a dummy every time; `client_lockout` stays 0) |
| F11 | Per-path perf counters, live FSM state, and PRNG override inputs exposed. | **Phase 1: fixed** (secure-build switch) |
| F12 | 9-bit slot IDs with N = 512: possible top-slot / empty-marker aliasing. | **Phase 2: verified not an issue** (slot list is compacted by fill count; no zero marker; 9 bits cover 0–511) |
| F13 | LFSR for remaps and 32-bit LFSR lease tokens. | Deferred, as on gem5 (needs a CSPRNG/TRNG) |

**Test integrity**
- The testbench forced `val_valid = client_req`, so lease validation never ran in simulation.
- T46 (wrong token) and T47 (revoked lease) were auto-passed without running.
- **Phase 1: fixed.** Both now run against the real lease table.

## Phase 1 changes

| File | Change |
|---|---|
| `aes_gcm_pipelined.v`, new `ghash_lane3.v` | The fixed engine from gem5 Rev 4 (GHASH FIFO fix with input backpressure, 3-lane GHASH, cached H). Same ports. |
| `flat_oram_gcm.v` | Tag mismatch sets a sticky error and enters `S_HALT` (code 28): no completion, no data, until reset. Stash overflow is sticky too, and no access is accepted after either error. |
| `secure_oram_top.v` | **F1:** new `key_load` input and `key_ready` output. Key and seed are latched once per boot; an all-zero key is refused; nothing is accepted until loaded. **F10:** new `client_lockout` output; lock-out after 4 rejected requests, cleared by GRANT/RENEW (removed in v11a: the output stays 0). **F11:** without `ORAM_DEBUG_PORTS`, all `perf_*` outputs, `dbg_oram_state` and `dbg_gcm_tag_*` read 0, and `dbg_prng_override` / `dbg_force_same_bucket` are ignored. |
| `onboard_test_top.v` | Pulses `key_load` after reset. Refuses to compile with `ORAM_SECURE_BUILD` (it carries the public test key). T46 and T47 are real tests. A new re-grant step restores client 0's lease after T47 so later tests can use it. |
| `tb_onboard_test_top.v` | The lease-bypass force now exists only under `XSIM_FORCE_LEASE_VALID`. That define disables lease checking, so prefer fixing the XSim issue to using it. |

## Build defines

- **Self-test / simulation:** `SIMULATION ORAM_DEBUG_PORTS`. The self-test steers remaps with
  `dbg_prng_override` and reports perf counters, so it needs the debug ports.
- **Production:** `ORAM_SECURE_BUILD`, without `ORAM_DEBUG_PORTS`, and a production top in place of
  `onboard_test_top`.

## Verification (Icarus, `-DSIMULATION -DORAM_DEBUG_PORTS`)

- **Baseline:** 53/53.
- **Phase 1:** 53/53, now including real lease validation and the real T46/T47.
- **Production configuration** (`ORAM_SECURE_BUILD`, ORAM only): compiles with Icarus and Verilator
  lint (0 errors).
- **The onboard test top in secure mode fails to compile, by design.**

Not done here: Vivado synthesis and timing. The new GHASH lanes and the key latch add logic, so
re-check timing at your target clock.

## Key and IV seed (F1): LFSR stand-in

There is no entropy source on this platform, so (as decided for the gem5 work) LFSRs stand in for a
TRNG for now: for the remap bucket choice, for lease tokens, and for the key/IV seed.

- **Within a boot:** IVs are unique. The engine's 96-bit IV LFSR advances once per encryption.
- **Across boots:** the seed is deterministic, so the same IV sequence repeats under the same key. This
  is a known limitation of the evaluation build. It matters only to an adversary who keeps ciphertext
  from an earlier boot. State it in the paper alongside the LFSR stand-in.
- **What Phase 1 changed:** the key and seed now enter through one place (`key_load`, latched once per
  boot). A real TRNG, or a persistent boot counter mixed into the seed, can later replace the stand-in
  there without touching the controller.
- **The `ORAM_SECURE_BUILD` guard** only stops the onboard test top, with its public key, from being
  built as a production image. It does not affect the self-test build.

## Next phases

- **Phase 2: done**, including the random initial layout (see below).
- **Phase 3:** the time-division arbiter with dummy accesses, plus the non-interference test (gem5 Rev 9).

## Phase 2: controller restructure (F3, F5–F8)

`flat_oram_gcm.v` has a new FSM, modeled on gem5 Revs 1–2. The module ports are unchanged apart from
two new outputs, and the submodules are reused as they are.

### Access flow

1. **Accept** the request and start the cycle counter.
2. **Position lookup.**
3. **At `CT_RD`:** read bucket metadata and the whole bucket (8 × 4 KB) into the scratch buffer.
4. **Decrypt and verify all 8 positions in place.** The IV and tag come from the IV table, now keyed
   per (bucket, position) through the pseudo-address `(b·8 + pos) << 12`, so holes are covered too.
   Any mismatch sets `err_tag_mismatch` and halts.
5. **Operation on plaintext.**
   - The target always moves to the stash, remapped; the vacated position is filled by moving the last
     valid entry into it.
   - Reads copy the data into a 4 KB result buffer; writes take client data into the stash.
6. **Evict** stash entries that target this bucket into the free positions.
7. **Re-encrypt all 8 positions** with fresh engine IVs and record each IV and tag.
8. **At `CT_WB`:** write back the whole bucket.
9. **At `CT_DONE`:** stream the result buffer (a silent window of the same length for writes), then
   signal completion.

### Boot-time format pass (F7)

Once a key is loaded, every position of every bucket gets an encrypted zero block and an IV/tag entry,
replacing the plaintext DDR pattern. The new output `oram_ready` (= key loaded and formatted) gates
client accesses. It takes a few milliseconds at boot.

### Fail-stop

Tag mismatch, stash overflow and timing-gate overrun are all sticky and all halt the controller
(`S_HALT`). Overrun is reported on the new output `err_ct_overrun`.

### Timing budgets (`oram_params.vh`, override with `-D`)

| Gate | Value | Basis |
|---|---|---|
| `ORAM_CT_RD` | 16 | Arrival 2 |
| `ORAM_CT_WB` | 8,500 | Analytic worst case ~7,690 with 8 evictions, plus margin |
| `ORAM_CT_DONE` | 10,100 | `CT_WB` + write-back ~1,387, plus margin |

**These are calibrated on the testbench's DDR model. Recalibrate on the board:** build with all three
set to 0, run a stress workload, and read the internal maxima `ct_max_rd`, `ct_max_wb` and
`ct_max_done` (for example via ILA). An undersized budget halts with `err_ct_overrun` instead of leaking
timing.

### Cost

| Design | Per-access latency (simulation cycles) |
|---|---|
| Original | 2,946 to 3,515, depending on path (the leak) |
| Phase 2 | 10,232 on every path |

About 3× slower: every access now does 16 full-block GCM operations instead of 1–2, plus padding.

### Self-test and testbench changes

- `onboard_test_top` waits for `oram_ready` before its first test. Its first request used to arrive
  during the format pass and be dropped; real clients must wait for `oram_ready` the same way.
- The testbench prints gate arrivals and error flags at the end of a run.
- New tamper modes: `+tamper_hole` (flip one bit in bucket 0, position 5, a hole) and `+tamper_target`
  (bucket 0, position 0).
- Waveform dumping now requires `+define+DUMP_VCD`. Each run otherwise wrote a ~700 MB VCD.
- The long timeout delay is now 64-bit, so the testbench also runs under Verilator.

**Use Verilator for the full suite.** With 16 crypto operations per access, Icarus is now too slow
(hours). The command:

```
verilator --binary --timing -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY \
  -Wno-INITIALDLY -DSIMULATION -DORAM_DEBUG_PORTS --top-module tb_onboard_test_top -I. *.v -Mdir vobj -o Vtb
./vobj/Vtb                   # 53 tests
./vobj/Vtb +tamper_hole      # must print TAMPER RESULT: DETECTED
./vobj/Vtb +tamper_target    # must print TAMPER RESULT: DETECTED
```

### Phase 2 verification (Verilator)

- **Original design:** 53/53 under Verilator as well, confirming Verilator as a reference.
- **Phase 2, gates off:** 53/53. No tag errors, no stash overflow, format complete.
- **Phase 2, gates on:** 53/53, no overrun, and every access path takes 10,232 cycles.
- **`+tamper_hole`:** detected, halted. **`+tamper_target`:** detected, halted.
- **Production configuration** (`ORAM_SECURE_BUILD`): Verilator lint 0 errors; Icarus compiles.
- **Not done:** Vivado synthesis and timing. The new 4 KB result buffer is written in its own clocked
  block so it can map to BRAM.

### Still open (after Phase 2)

Superseded: the random layout and Phase 3 are both done; see the sections below.

### Files

- `rtl/`: the full set, with CRLF line endings.
- `fpga_phase2.patch`: on top of Phase 1.
- `fpga_cumulative.patch`: against your originals.

All patches use LF line endings and were apply-tested.

## Phase 2b: random initial layout

The controller now owns the layout. After the format pass, a new state `S_LAYOUT` gives every slot an
independent random bucket in the position map, with status "never written", and clears all bucket
metadata. This is **lazy placement**:
- a slot occupies a real position only once it is written (through the stash and eviction);
- utilization starts at zero;
- no permutation table is needed;
- every slot's first access reads a random, secret bucket.

Whatever a top wrote through `init_mode` beforehand is overwritten. In secure builds `init_mode` is
ignored altogether.

Fixed along the way:
- **Read-miss linkability (a bug in my Phase 2).** A read of a never-written slot returned zeros but
  did not remap the slot, so a second read touched the same bucket and revealed the repeat. It now
  remaps.
- **PRNG decorrelation.** The 12-bit LFSR (the agreed TRNG stand-in) is stepped 6 extra times after
  every use, so consecutive bucket choices don't share bits. 512 slots × 6 steps stays within its
  period of 4,095.

Self-test: the 33 test slots land in 29 distinct buckets (a uniform random assignment gives ≈ 27);
53/53 pass. The tamper modes now locate the bucket of the first test's slot in the position map.

## Phase 3: static time-division arbiter with dummy accesses (F9)

This is gem5 Rev 9, including its audit fixes, ported to the ZCU208 top.

**Top level**
- The fixed-priority arbiter is replaced.
- **Frame configuration** (`cfg_tdm_slot_cycles`, `cfg_tdm_frame_len`, `cfg_tdm_owner`,
  `cfg_tdm_owner_valid`) is latched once, on the first cycle after reset.
- **Slots start automatically when `oram_ready` rises** and never stop.
- **Per-client intake.** The lease check and lock-out happen on arrival. Each client has its own 4 KB
  write buffer with its own write port, and a write becomes eligible only once its buffer is full.
- **Slot-start decision:** the owner's request runs if, and only if, that owner has one complete;
  otherwise a dummy runs. The decision reads nothing else.
- `err_slot_overrun` (sticky): the controller was busy at a slot start.

**Controller:** a new `client_dummy` request type.
- It picks a random bucket at accept.
- It then runs the identical path: read gate, verify all 8, evict, re-encrypt all 8, write-back and
  completion gates.
- It returns no data, no completion and no performance counts.

**New outputs**
- `client_ready[i]`, `client_wbeat_req[i]`.
- `oram_beat_cnt` keeps its single-client meaning: the beat the filling client should present.
- `oram_busy` now means "a client request is pending".
- `dbg_slot_*` and the real/dummy counters exist only in debug builds.

**Slot length:** default `ORAM_TDM_SLOT` = `CT_DONE` + 2·128 + 48 = 10,404 cycles. With K = 2, an
unloaded client waits about T on average for its slot, plus about T of service.

**Self-test fix (important):** in simulation, `onboard_test_top` took its write-data beat from a
hierarchical reference to the controller's internal `beat_cnt`, while hardware used the
`oram_beat_cnt` port. **The simulation was exercising a different path from the hardware.** Both now
use the port, which under Phase 3 is the only correct source.

### Non-interference test (`tb_ni.v`, new)

Two clients drive `secure_oram_top` directly through an in-order AXI memory model.
- Client 1 replays a fixed trace: each request is issued a fixed, seeded gap after its own previous
  completion.
- Client 0 is idle (`+ni=0`), saturating (`+ni=1`), random (`+ni=2`) or bursty (`+ni=3`).
- Every read is checked against the last value written. Client 1's request and completion cycles,
  relative to `oram_ready`, are hashed.

| Client 0 | Phase 2 (fixed priority, `-DOLD_ARBITER`): client-1 latency min/mean/max | Phase 3 |
|---|---|---|
| idle | 10,234 / 10,234 / 10,234, hash `29873036…` | 17,749 / 19,018 / 20,420, hash `4e88d80d…` |
| saturating | **starved**: 0 ops in 2M cycles while client 0 did 195 | identical |
| random | 10,234 / 14,654 / 20,429, hash `91b3247d…` | identical |
| bursty | 10,234 / 17,089 / 50,973, hash `e745541a…` | identical |

Phase 3 gives the same hash for all four behaviors, with 0 data errors for both clients.

```
verilator --binary --timing -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY \
  -Wno-INITIALDLY -DORAM_DEBUG_PORTS --top-module tb_ni -I. tb_ni.v <synthesizable .v files> -Mdir vni -o Vni
for v in 0 1 2 3; do ./vni/Vni +ni=$v +ops=10; done      # identical trace-hash = pass
```

### Phase 3 verification (Verilator)

- **Self-test:** 53/53. 86 real and 87 dummy slots, no slot overrun, every path 10,232 cycles of
  service.
- **Tamper:** both modes detected and halted, with dummies running.
- **Non-interference:** as above, with the negative control showing both the starvation and the
  timing channel on the old arbiter.
- **Production configuration** (`ORAM_SECURE_BUILD`): Verilator lint 0 errors; Icarus compiles.
- **Not done:** Vivado synthesis and timing. The two 4 KB intake buffers read combinationally, so they
  map to LUT-RAM.

### Integration checklist for a production top

1. Provision the key and IV seed and pulse `key_load` once per boot (LFSR stand-in for now).
2. Drive the frame configuration before reset is released. Do not drive `init_mode`; the controller
   owns the layout.
3. Wait for `oram_ready` (format and layout take a few ms), then let clients issue requests.
4. Each client: one outstanding request; check `client_ready[i]` before pulsing `client_req[i]`;
   present write data for beat `client_wbeat_req[i]` while holding `client_wdata_valid[i]`.
5. Treat `err_tag_mismatch`, `err_stash_overflow`, `err_ct_overrun` and `err_slot_overrun` as fatal.
6. Recalibrate `ORAM_CT_*` on the board (and with them `ORAM_TDM_SLOT`).
7. The deferred limitation stays: LFSR stand-ins for the PRNG, tokens and seed.

### Files (final)

- `rtl/`: full set, CRLF, now including `tb_ni.v`.
- Patches: `fpga_phase1.patch`, `fpga_phase2.patch`, `fpga_phase2b_layout.patch`,
  `fpga_phase3.patch`, and `fpga_cumulative.patch` (against your originals). All use LF line endings;
  the chain and the cumulative patch were both apply-tested to reproduce the tested files.

## Audit (after Phase 3)

Method:
- Full-warning lint of the lines changed from your originals, in debug, production and 3-client builds.
- A check that every register feeding a submodule is still driven by the new FSM.
- New dynamic tests: AXI backpressure, a forced 8-eviction worst case, and a functional run of the
  production configuration.

### Bugs found and fixed (`fpga_audit.patch`)

1. **Stash data addressing (pre-existing in your `stash.v`; corrupts data on hardware).**
   - The data address was `{entry, beat}` with the beat field `BEAT_W = BEAT_CNT_W` = 10 bits, so the
     address was `entry × 1024 + beat`. The memory is `DEPTH × BEATS` = 8,192 beats.
   - For entries 8 and up, the address runs off the end and wraps: entry 8 aliased entry 0, entry 9
     entry 1, and so on. **The stash could hold the data of only 8 blocks, although its metadata tracks
     64.** A 9th block silently overwrote another block's data.
   - Your original self-test never had more than 8 blocks in the stash, so it never showed. Found with
     the new stress test: a read of slot 1 returned slot 9's data.
   - Fixed: the address uses only the low `$clog2(BEATS)` = 7 beat bits.
2. **Eviction stopped after one block (my Phase 2 code).**
   - After each eviction the stash masks the evicted entry for one cycle (`cam_bkt_inhibit_busy`). My
     loop took that as "no more candidates" and stopped.
   - So at most one block was evicted per access. The stash drained far too slowly and, over time,
     could overflow, which is fail-stop.
   - Fixed: the loop waits out the inhibit cycle. The stress test now sees 8 evictions in one access.
3. **Testbench memory model (my `tb_ni.v`).** It applied write data to the oldest pending address.
   Under backpressure, data can be accepted before its address, and the model then wrote to the wrong
   place, producing a false tag mismatch. It now buffers write data as a real controller does.

With both RTL fixes, the worst-case write-back arrival (8 evictions) is **7,239 cycles**, within the
8,500 budget (the analytic estimate was about 7,690).

### Verified clean

- **Lint:** only benign warnings on changed lines (implicit widenings, intentional blocking
  temporaries). The 3-client build elaborates.
- **Submodule inputs:** none is left wired to a register only the old FSM drove. The slot CAM is fed
  directly by `req_slot_addr`.
- **Backpressure:** 30% ready-low plus read gaps, with both clients active: no data or integrity errors.
- **Production configuration:** behaves identically to the debug build (same non-interference hash).

### Parameter limits to keep in mind

- The layout pass's slot counter is 10 bits (N ≤ 1024).
- The stash data address assumes `BEATS` is a power of two.

Both hold for this configuration (N = 512, 128 beats per block).

## Simulation kit (`sim/`)

`sim/README_SIM.md` describes every check. In short:

```
cd sim
bash run_verilator.sh      # full regression, PASS/FAIL per check, exit code (about 5-10 min)
bash run_icarus.sh         # compile check (Icarus is too slow to run the suite)
bash run_xsim.sh           # Vivado XSim flow (not run here; first run is a bring-up)
```

Final regression on the shipped files (CRLF RTL, run through `run_verilator.sh`): **ALL CHECKS
PASSED.** That covers:
- self-test 53/53;
- both tamper modes;
- non-interference (identical hash `4e88d80d…` across four client-0 behaviors);
- the worst case, gated and calibrated;
- backpressure;
- the production configuration.

## Crypto streaming (after the audit)

Each access used to wait for the whole 32 KB bucket before decrypting, and for all 8 positions to
be encrypted before writing back. Both now overlap.

**Read side.** Decryption starts at the read gate. Position *p* is verified as soon as its 128
beats have landed (`landed_beats`), while the rest of the bucket is still arriving. This is purely
on-chip, so the DDR trace is unchanged.

**Write side.** The write-back starts at exactly `CT_WB` while later positions are still being
encrypted. Safety does not depend on the budget being right:
- **No plaintext can reach DDR.** The AXI master has a new `wdata_hold` input and never issues a
  scratch read for a position that isn't fully re-encrypted (`enc_pos_done`). This holds by
  construction, even with a wrong budget.
- **A budget that is too early fails loudly.** If the write-back ever has to wait for the
  encryption, the master reports `wdata_stall`, which sets `err_ct_overrun` (fail-stop), because a
  gap would make the W-channel timing depend on hidden work.
- **Scratch banking.** The scratch buffer is now 8 per-position banks, each with its own read and
  write port, so the DDR stream, the crypto engine and the write-back can use different positions in
  the same cycle. A bank conflict is impossible by design; if one ever happened it would also be
  fail-stop (`bank_conflict`).
- **Simulation safety monitor.** It reports any write-back read of a position that isn't yet
  encrypted. The regression fails on any such report.

**Budget rule for `CT_WB`.** The write-back may start up to 7 × 128 = 896 cycles before the worst
encryption end, because the master needs that long to reach the last position:

    CT_WB >= worst encryption end - 896  (+ margin)

**Results (simulation DDR model, 300 MHz):**

| | Before | Streaming |
|---|---|---|
| Worst encryption end (8 evictions, gates off) | 7,239 | 6,188 |
| `CT_WB` / `CT_DONE` | 8,500 / 10,100 | 5,650 / 7,250 |
| Every access path | 10,232 cycles | **7,382 cycles (-28%)** |
| Slot length (`ORAM_TDM_SLOT`) | 10,404 (34.7 µs) | 7,554 (25.2 µs) |

All regression checks pass. That includes a **negative control**: a write-back budget 1,500 cycles
too early is caught as an overrun, and the write-back never reads an unencrypted position.

**Cost.** The banked scratch uses about 32 BRAM36 instead of about 8, because 128-deep banks
underuse each BRAM.

The **gem5 RTL does not have this change yet.**

## Eviction overlap

Each eviction used to copy its 4 KB block from the stash into the bucket (~135 cycles) before the
next eviction, and encryption waited for all of them. Now:

- **The eviction loop only decides**: which stash entry goes to which position, plus the slot-list,
  position-map and stash updates. That takes about 4 cycles per eviction.
- **A background engine performs the copies**, one beat per cycle, through a new eviction write port
  on the scratch buffer.
- **Encryption of a position waits only for that position's own copy** (`ev_pending`). Copies (~135
  cycles each) are faster than encryption (~302 per position), so after the first position
  encryption effectively never waits.
- **Reading freed stash entries is safe.** The engine reads entries the eviction loop already marked
  free. Nothing is inserted into the stash between eviction and the end of the access, and the access
  cannot finish before every copy has.

This is on-chip only. DDR traffic and the fixed timing gates are unchanged.

**The worst case moved.** With copies hidden, the 8-eviction access is no longer the slowest. The
slowest accesses now do two data copies before eviction can start (for example, a bucket-hit write
with compaction). So the regression now calibrates against the worse of the 8-eviction stress test
and the full self-test.

| Worst encryption end (gates off) | Streaming only | + eviction overlap |
|---|---|---|
| 8-eviction stress | 6,188 | 5,245 |
| All paths (self-test) | below stress | **5,300** (now the worst) |

**Results (simulation DDR model, 300 MHz):**

| | Before streaming | Streaming | + Eviction overlap |
|---|---|---|---|
| `CT_WB` / `CT_DONE` | 8,500 / 10,100 | 5,650 / 7,250 | **4,700 / 6,300** |
| Every access path | 10,232 cycles | 7,382 | **6,432** |
| Slot length | 10,404 (34.7 µs) | 7,554 (25.2 µs) | **6,604 (22.0 µs)** |

All regression checks pass, including the early-budget negative control and the safety scan.

## Performance phase = the paper's FPGA workload

The self-test's performance phase (T49–T53) now runs the workload of the paper's Section IV-B and
Table IV:
- **100 random slot writes, then 100 reads of the same slots,** through client 0.
- **Slots are 100 distinct indices in 1–255**, inside client 0's lease. They come from an 8-bit
  maximal-length LFSR with seed `0xA5`, so the run is reproducible.
- **`PERF_N` in `onboard_test_top.v`** sets the count.

It replaces the earlier 40-operation phase (20 reads, then 20 writes over 10 fixed slots).

**Result (simulation DDR model, 300 MHz):**
- **All 200 operations take 6,432 cycles (21.4 µs)**, identical on every path. The original design
  averaged 2,899 cycles (9.7 µs) on hardware (Table IV).
- **Split, by where each block was found:** reads 100 (97 in a bucket, 3 in the stash); writes 100
  (3 in a bucket: slots 7, 9 and 11, written earlier by tests T1–T48; 97 to never-written slots).
- **Categories now distinguish never-written slots** (WRITE/NEW, READ/NEW). Earlier reports counted
  them under "stash", which made "WRITE/STASH 97" look like 97 stash hits. In the original design
  never-written slots were pre-placed in buckets, so the same writes appeared as Wr/Bkt (86 in
  Table IV).
- **Why only 3 reads find the block in the stash:** a block leaves the stash when any access (real
  or dummy) touches its target bucket. With about 200 accesses between a write and its read, about
  (63/64)^200 ≈ 4% are expected to still be in the stash.

**For the paper:**
- **Report one per-access number,** since every path now takes the same time. The per-phase rows
  attribute overlapped work to the controller state it happens in, so they no longer mean what their
  labels say.
- **Crypto counts:** every access now decrypts and encrypts all 8 positions, so 1,600 of each over
  200 operations, plus the dummies' (the paper's text says 76 encryptions and 40 decryptions).

**Configuration differs from Table II:** `oram_params.vh` has N = 512 and stash depth 64; the paper
lists N = 256 and stash 128. The workload stays within 256 slots.

## Derived worst case for the timing budgets

The budgets are now justified by a derivation, not by the slowest access seen in some test.

**Method (`sim/worst_case.py`, `sim/oram_timing_monitor.v`).** Every access is cut into segments
at fixed milestones. A cycle model states that each on-chip segment depends only on the access's
path features, and it is **checked against every traced access**: 912 accesses from the self-test
(the paper workload) and from directed constructions of every candidate worst path. Then every
feature combination the controller allows is enumerated.

**The validated cycle model** (cycles from access start):

| Segment | Cycles | Determined by |
|---|---|---|
| read issued | 17 | gate (`CT_RD`) |
| first position landed | memory-dependent (`tb_ni` model 153, self-test model 151–240) | memory |
| rest of verification | 2,416 | fixed: crypto-bound, 8 × ~302 |
| operation phase | 2 (dummy, read of a never-written slot), 132–136 (1 copy), 265–267 (2 copies) | path, copies |
| eviction decisions | 2 + 4 × evictions | eviction count |
| wait for the first eviction copy | 133 − 4 × evictions if position 0 receives an eviction, else 2 | fill, evictions |
| encryption | 2,399 | fixed |

**Worst on-chip combination: 299 cycles.** It is a read (or write) that finds its block at
position 0 of a bucket holding 2 blocks (compaction, so 2 copies), followed by 7 evictions. This
beats the bucket-left-empty cases (1 copy + 8 evictions + the first-copy wait = 271).

**Derived worst encryption end:**

| Memory model | Derived bound | Slowest traced access | Deadline (`CT_WB` + 896) | Margin |
|---|---|---|---|---|
| `tb_ni` model | **5,284** | 5,284 (directed test reaches the bound) | 5,596 | 312 |
| self-test DDR model | **5,371** | 5,343 | 5,596 | 225 |

On the self-test's model the bound is 28 cycles above anything a single run produced: the slowest
memory timing and the slowest on-chip path never coincided. A purely empirical calibration would
have missed this.

**On the board**, only the memory terms change; the on-chip model does not depend on memory.
Measure the worst first-position landing time and the write-back duration (ILA), then:

    CT_WB   >= 17 + (max first-position landing) + 2,416 + 299 + 2,399 - 896  (+ margin)
    CT_DONE >= CT_WB + (max write-back duration)                               (+ margin)

The verification term (2,416) assumes DDR delivers each 4 KB position within one position's
decryption time (~302 cycles), which the ZCU208's DDR4 does with large headroom.

## Paper configuration and random boot layout

**Configuration.** The RTL now uses the configuration of the paper's Table II and of the board build
that produced Table IV:
- N = 256 slots, 64 buckets of Z = 8 positions;
- `ORAM_C` = 4 real slots per bucket (4 slack), `SLOT_ID_W` = 8;
- stash depth 64.

`ORAM_C` now means real slots per bucket; it used to mean total capacity.

**Random boot layout.** After the format pass, the controller places every slot at a uniformly
random position, 4 per bucket, using an inside-out Fisher–Yates shuffle (`S_SHUFFLE`, then
`S_LAYOUT`). The random numbers come from a 16-bit LFSR seeded from the per-boot IV seed, a stand-in
for the TRNG like the other generators. This replaces the lazy layout, which kept never-written
slots out of the buckets. Now:
- every slot starts valid, and its data reads as zeros until written;
- the starting occupancy matches the paper's configuration (4 slots + 4 slack);
- the initialization is the same as the gem5 version (Fisher–Yates);
- the categories mean the same as in Table IV (a first write finds its slot in a bucket).

**Bug fixed along the way: IV table sizing.** Since Phase 2 the IV table is indexed by
`{bucket, position}` (B × Z = 512 entries), but its depth came from `ORAM_N`. The two were equal only
when N was 512. With N = 256, buckets 32–63 aliased onto 0–31, and the first access failed
authentication and halted. The table is now sized `B * Z`, independent of N.

**Self-test order.** The self-test no longer writes its own layout through `init_mode`, which would
overwrite the random layout. It runs **the paper's Table IV workload first, from the fresh boot
state**, then T1–T48:
- 100 writes to random slots (16-bit LFSR, seed `0xA5C3`, repeats allowed), then 100 reads replaying
  them;
- the counter outputs are latched when the performance phase ends, so the board reports only those
  200 operations.

The same workload on your original board RTL reproduces Table IV exactly in simulation
(40/60/86/14, 40 decryptions, 76 encryptions).

**Result on the secured design.** Every operation takes 6,432 cycles (21.4 µs at 300 MHz). The split
is Rd/Bkt 90, Rd/Stash 10, Wr/Bkt 96, Wr/Stash 4. Dummy accesses in idle windows move waiting blocks
out of the stash faster than in the original design, so fewer accesses find their block there.

**Tests.** `tb_ni`'s stress and directed worst-case scenarios first empty their target bucket
(`drain`). The worst-case analysis treats dummy accesses as having no data operation: with every slot
placed, a dummy's lookup of slot 0 can report a bucket hit, which the controller never acts on. The
derived worst case is unchanged (299 on-chip cycles; bounds 5,284 and 5,371 against 5,596).

## Two clients, one ORAM each (Z = 6, λ = 4)

**Configuration** (`oram_params.vh`):
- each client has its own ORAM: 256 slots, 64 buckets and its own 128-entry stash;
- every bucket has 6 positions: λ = 4 real slots plus 2 slack;
- **the clients never share a bucket**.

| | Client 0 | Client 1 |
|---|---|---|
| Slots (lease range) | 0–255 | 256–511 |
| Buckets | 0–63 | 64–127 |
| Stash | 128 entries | 128 entries |

`ORAM_PART_W = 1` selects two partitions. The access's partition comes from the top bit of its slot
number, which the leases already restrict.

**What the controller does per partition:**
- The boot layout shuffles each client's slots into that client's own buckets.
- Remap targets, and the debug remap override, stay inside the partition.
- Each partition has its own stash instance. The access's partition selects it for every lookup,
  insert, remap, eviction and data transfer.
- **Dummy accesses stay in the window owner's partition.** The top level gives a dummy window the
  first slot of its owner's range. A dummy that touched any bucket would be distinguishable from a
  real access by its bucket number; inside the owner's partition, every window, real or dummy, reads
  a random bucket of its owner. The owner itself is public from the fixed schedule.

**Bugs fixed for Z = 6 and B = 128:**
- **IV table:** it is indexed by the concatenation {bucket, position}, so it needs B × 2^POS_W =
  1,024 entries, not B × Z.
- **Simulated DDR (both testbenches):** sized by the 32 KB bucket stride, not the 24 KB bucket size.
- **Hard-coded 8-position constants** in the monitors, the report, the regression and the stress
  check.
- **`tb_ni`'s bucket-emptying helper** now issues each slot through its owning client.

**Timing (derived worst case, the cycle model checked on every traced access):**
- worst on-chip path 291 cycles; bounds 4,072 (reached) and 4,160;
- `CT_WB` = 3,820, `CT_DONE` = 5,160;
- **every access takes 5,292 cycles (17.6 µs at 300 MHz)**; a window is 5,464 cycles (18.2 µs);
- with two clients, a client gets one access per frame of 10,928 cycles (36.4 µs).

**The paper's workload on client 0's ORAM** (client 1 idle, its windows running dummies in its own
partition):
- Rd/Bkt 67, Rd/Stash 33, Wr/Bkt 92, Wr/Stash 8;
- every operation takes 5,292 cycles.

**Regression:** every check passes. The bus-timing check now also requires each window, real or
dummy, to read a bucket in its owner's partition.

**Resources:** two 128-entry stashes are 1 MB, about 32 of the ZU48DR's 80 UltraRAMs. The IV table
has 1,024 entries; the DDR footprint is 4 MB.

## Longer performance phase (200 writes, then 200 reads)

The self-test's performance phase length is now `SELFTEST_PERF_N` writes then the same number of
reads, defaulting to **200 + 200**. Set `SELFTEST_PERF_N=100` to reproduce the paper's original
workload.

Result on client 0's ORAM (Z = 6, λ = 4, client 1 idle):
- **the workload:** 200 writes to 133 distinct slots, so 67 writes repeat a slot;
- **reads** 149 in a bucket, 51 in the stash; **writes** 169 in a bucket, 31 in the stash;
- **every operation** 5,292 cycles.

**Eviction is complete.** In all 894 eviction loops of the run, none stopped while a block bound for
the bucket was waiting and the bucket had room. The 58 loops that left blocks behind did so because
the bucket was full.

**Stash occupancy.** Client 0's stash peaked at **60 of 128**, against 57 with 100 + 100. Occupancy
settles near (buckets) × (fraction of accesses that take a block out of a bucket) ≈ 64 × 0.8 ≈ 51,
instead of growing with run length. A 128-entry stash is therefore about 2.5× the typical level.
This measured peak is evidence, not a bound on the overflow probability.

## Audit after the two-client partitioning

**1. Cross-client access through an over-granted lease (security, fixed).**
- **The hole:** a client's partition was derived from the slot address, and the only admission check
  was the lease. Leases are created at the host's request, and the host is untrusted. So a host that
  granted client 0 a lease over client 1's slots let client 0 read and write client 1's ORAM.
  Demonstrated on the previous RTL: client 0 read client 1's slot 300 and got all 128 beats of
  client 1's data.
- **Also closed:** slot addresses beyond N aliased onto other slots (slot 512 onto slot 0).
- **The fix:** `secure_oram_top` admits a request from client c only if its slot is below N and in
  partition c, independent of the lease. A failing request counts as a violation, so repeated
  attempts lock the client out. A simulation check also requires NUM_CLIENTS = 2^`ORAM_PART_W`.
- **Regression:** `tb_ni +xpart` repeats the attack and must end with the request rejected.

**2. Boot layout assumed λ = 4 (latent, fixed).** The bucket index was a 2-bit shift
(`lay_i[BL_W+1:2]`), so any other λ would have placed slots in the wrong buckets. It is now `lay_i / C`.

**3. Write-back position decode used fixed bit positions (latent, fixed).** `[9:7]` assumed 128-beat
blocks and at most 8 positions. It now uses `[BEAT_AW +: POS_W]` from the parameters.

**Verified clean.** Lint shows nothing new in the changed code. The review covered:
- dummy addressing per partition;
- the two stashes (selection, overflow);
- eviction-copy completion within each access;
- the per-client slot ranges of every test.

The full regression passes.

## Single-client build (default)

The paper now claims one client, so the default build is one client with one ORAM:
- 256 slots in 64 buckets of Z = 6 positions (λ = 4);
- one 128-entry stash;
- **no arbiter, no window schedule, no dummy accesses.**

`-DORAM_TWO_CLIENTS` (in Vivado: a Verilog define on the project) restores the two-client build described
in the earlier sections.

**How accesses are issued.** An access starts as soon as a request is admitted and the previous access's
window has ended. Each access still occupies a fixed-length window (5,464 cycles), so its result returns a
fixed 5,292 cycles after it starts. A request's response time is therefore its wait for the previous window
plus that fixed time. The wait depends only on when the client's own requests arrive, which the host
already sees.

**What changed in the RTL:**
- **`oram_params.vh`:** the client configuration block (`ORAM_NUM_CLIENTS`, N, B, `ORAM_PART_W`, widths).
- **`secure_oram_top.v`:** with one client a window starts only when a request is ready, with no dummies.
  The client-ID ports are sized safely for one client. The admission check keeps slots inside the ORAM.
  A build whose client count does not match its partitions now stops the simulation.
- **`flat_oram_gcm.v`:** partition arithmetic in base-plus-offset form, which also works with no partitions.
- **`lease_token_table.v`:** the client-ID width is safe for one client.
- **`onboard_test_top.v`:** the client count follows the hardware; leases are granted only to existing
  clients; asking for more active clients than the hardware has stops the simulation.

**Results (single client, simulation):**
- **Self-test:** 50 tests pass, and the 3 that need a second client are skipped. 0 dummy accesses. Every
  access takes 5,292 cycles.
- **Performance phase (200 writes, then 200 reads):** reads 149 in a bucket, 51 in the stash; writes 174 in
  a bucket, 26 in the stash.
- **Full regression** (`bash run_verilator.sh`, single configuration): every check passes.
  - stress: 6 evictions in one access;
  - calibration: worst encryption end 4,124 against 4,460;
  - negative control caught;
  - backpressure clean;
  - production build identical;
  - bus timing: all 240 windows at offsets 20 and 3,824 with 0 dummies;
  - derived worst case 4,072 and 4,160 against 4,460.

## Read-after-write ordering fix (found through hardware emulation)

**The bug.** The AXI master treated a write as finished once its last data beat was accepted, and
drained the write responses in the background ("Opt 2"). The controller then completed the access,
and the next access could issue its bucket read while the previous write-back was unacknowledged.
AXI does not order a read against an unacknowledged write, so that read could return the old
ciphertext. Its tag check would then fail and the controller would halt (kernel error 0x8).

**Why no simulation caught it.** Every testbench memory model applied writes instantly. In hardware
emulation it surfaced as a halt after a few accesses. With writes landing 700 cycles after their
data, the old design reproduces it: 2 accesses complete, then an integrity failure.

**The fix:**
- `flat_oram_gcm.v`: an access reaches its done gate only when the write-back is complete **and**
  every write response has returned (`wr_quiet`). A slow acknowledgement is therefore a late arrival
  at `G_done`, detected as an overrun, so timing stays constant.
- `axi_master.v`: a read request that arrives while write responses are outstanding is held until
  they return. This covers the boot-time format pass.

With normal memory nothing changes: the timing hashes are identical to before the fix.

**Diagnostics.** In simulation and emulation only (excluded from synthesis), the controller prints
`DOMA HALT: <cause>` when it halts: timing overrun (with state, access cycle, budgets and pending
write responses), integrity failure (with bucket), or stash overflow.

**Tests.**
- `axi_mem_model.v` now respects reset, and `+host_wlat=N` makes writes land N cycles after their
  last data beat, so reads can overtake them.
- The kernel regression checks that writes landing 200 cycles late still give correct results, and
  that acknowledgements slower than the budget become an overrun, never stale data.
- Both configurations pass the full regression.

## Kernel boot fix: DOMA boots at the first ap_start (found through hardware emulation)

**The bug.** The wrapper loaded the AES key 8 cycles after reset, and DOMA then wrote its whole
bucket layout to `pages + offset`. That happens right after the xclbin loads, long before the host's
first launch sets the `pages` argument, which still reads 0. The first buckets therefore went to
device address 0 + offset: the wrong memory, possibly another buffer. Every access then worked until
one first read one of those buckets, which failed its tag check.

In emulation that was bucket 3 after 15 accesses. With the host's first launch delayed 20,000 cycles,
the testbench reproduces it exactly (old wrapper): 15 accesses, then an integrity failure on
bucket 3, with 6,144 beats written outside the buffer.

**The fix** (`doma_kernel.v`):
- DOMA's key is loaded, and its boot layout written, only at the **first ap_start**.
- The `pages` address is latched at that first start and used for the kernel's lifetime.
- A later launch naming a different `pages` buffer sets summary error `0x20`; the original buffer is
  kept.

**Why the testbench missed it, now fixed:**
- It launched the kernel about 60 cycles after reset. `+start_delay=N` now delays the first launch,
  and the regression checks a 20,000-cycle delay with 256 sequential PUTs.
- Its memory model truncated addresses before range-checking, so address 0 + offset aliased onto the
  buffer. It now checks the full 64-bit address, on every beat.
- `+host_rdy_gap=P` adds random pauses on the address and write-data channels, and the model now
  checks `wlast` framing and 4 KB crossings. DOMA passes all of them.

## Scratch-buffer banks as block RAM (found through the first U55C build)

The first board build failed timing badly: WNS = −8 ns at 300 MHz. Synthesis reported
`Infeasible attribute ram_style = "block"` for every `u_scratch/g_bank[*].mem`. Each bank was written
from three branches with different addresses and read from two. Synthesis therefore inferred three
write ports and two read ports, which no block RAM has, and built each bank (128 × 256 bits) from
registers with wide multiplexers. Each bank is now one write port and one registered read port (the
simple dual-port template), with the same priorities and the same read-before-write behavior.

The rewrite is behavior-identical: both regressions pass, with unchanged timing hashes, bus offsets
and derived worst case. The other RAMs were already single-write, single-read templates: the IV/tag
table, position map, bucket metadata, result buffer, and the stash data in UltraRAM.

## AES key schedule, one round per clock (second U55C timing run)

With the scratch banks fixed, the worst paths were all `key_reg -> aes_core/rk10_reg`: 37 logic
levels, 7.7 ns, slack −4.3 ns at 300 MHz. The AES core expanded all ten round keys from the key in one
cycle and registered only the outputs.
- **The key schedule is now a chain:** `rk(i)` is computed from the **register** `rk(i-1)`
  (`aes128_key_round`: one SubWord plus XORs per stage). After a key change, `rk10` is correct 11 cycles
  later.
- **The AES core expands the GCM module's stable `key` input,** not `key_reg`, which changes only when
  an operation starts.
- **The controller starts its boot layout only once the key has been stable for 16 cycles.** The key is
  loaded once per boot.

The old and new cores both match FIPS-197 (Appendix B and C.1) and are bit-identical on random inputs.
Both regressions pass with unchanged timing hashes.

## Boot shuffle swap over three cycles (third U55C timing run)

With the key schedule chained, the only failing register group was `u_doma/u_oram/perm_reg`: slack
−0.667 ns, 16 levels, from `shuf_i`. The boot-time Fisher–Yates swap computed
`j = floor(r·(i+1)/2^16)`, read `perm[j]` and wrote `perm[i]` and `perm[j]`, all in one cycle. It now
takes three registered steps once the LFSR has settled: `j`, then the read, then the writes. The LFSR
does not advance during them, so the permutation is bit-identical: the self-test's layout-dependent
counts stay 149/51 and 174/26, and the timing hashes are unchanged. The cost is 2 cycles per slot,
once at boot. Both regressions pass.

## Stash free index registered (first routed U55C build: 279 MHz)

The first complete board build routed with WNS = −0.257 ns, so `v++` scaled the kernel clock to
279 MHz. That bitstream was still valid for functional tests: 105,000 operations, all correct, no
errors, 49.2 K operations per second at 279 MHz. Most failing paths ran from the stash's
`valid_r[*]` to the write enables of `target_r[*]`/`valid_r[*]`: 8 levels, three quarters of the
delay in routing. The 128-entry free-entry priority encoder and the write decode ran in one cycle.
- **The free index is now computed one cycle ahead and registered.** This is exact: inserts come at
  most once per access, so only an eviction can intervene, and it only frees an entry. If the stash
  was full when the index was computed, the entry evicted in that cycle is used.
- **A simulation check flags any insert into an occupied entry** (as `SAFETY VIOLATION`), and the
  regression's safety scan includes it.
- **Behavior is identical:** the self-test counts (149/51, 174/26), timing hashes, bus offsets and
  derived worst case are unchanged.

One GHASH path (`loaded_reg -> prod_q`, −0.255 ns) also failed. If it still fails after this build,
the next step is an operand register in front of the multiplier, verified against AES-GCM test
vectors.

## GHASH operand register (second routed U55C build: 272 MHz)

After the stash fix, TNS fell from −144 ns to −30 ns, but WNS was −0.341 ns (clock scaled to 272 MHz).
All remaining failing endpoints were `ghash_unit/prod_q_reg`: 9–11 levels, from the lane and combine
control registers (`cmb_step`, `l_last`) through operand selection and the 128×128 multiply.
- **`ghash_lane3.v`:** the selected operands are registered before the multiplier (operands, then
  multiply, then reduce). A lane's next product lands exactly when the three-lane round-robin reuses
  the lane, and the combine already waits for its products by count. `start` also drops anything in
  flight; none can be, by protocol.
- **Verification:**
  - The new `crypto` regression group checks the AES pipeline against the FIPS-197 known answers.
  - It checks the GHASH unit against an independent Python reference (`sim/ghash_ref.py`, NIST SP
    800-38D Algorithm 1, self-checked on GCM test case 2): 300 random messages of 1 to 300 blocks,
    back-to-back and with gaps.
  - A deliberately mis-timed variant (one cycle late) fails 226 of 300 messages, so the test does
    detect lane-timing errors.
- **Effect:** the worst encryption end rises by about 12 cycles (derived worst case 4,084 and 4,172
  against the 4,460 deadline). Timing hashes and bus offsets are unchanged, and both regressions pass.

## Block size as a build parameter (32 bytes to 4 KB)

DOMA's block (slot) size is now one build option, `ORAM_BLOCK_BEATS` (32-byte beats). The values are
1, 2, 4 and 8 for 32–256-byte records (the value sizes of BOLT's experiments), and 128 for 4 KB, the
default, which is unchanged. Everything else is derived from it:
- beats per bucket;
- counter widths;
- bucket spacing: the smallest power of two that holds Z blocks.

When a whole bucket fits in 4 KB (blocks up to 512 bytes), it moves as **one AXI burst**; 4 KB blocks
keep one burst per position.

**Timing budgets per block size.** Each size's budgets come from the regression's derived worst case,
with the same margins as 4 KB:
- write-back point = worst encryption end + 300 − (Z−1)·BEATS;
- completion point = write-back point + longest write-back + 250.

| Block | Worst encryption end | Write-back point | Completion point | Access window | At 300 MHz |
|---|---|---|---|---|---|
| 32 B | 655 | 950 | 1,220 | 1,270 cycles | 4.2 µs |
| 64 B | 682 | 980 | 1,270 | 1,322 | 4.4 µs |
| 128 B | 736 | 1,020 | 1,320 | 1,376 | 4.6 µs |
| 256 B | 846 | 1,110 | 1,450 | 1,514 | 5.0 µs |
| 4 KB | 4,172 | 3,820 | 5,160 | 5,464 | 18.2 µs |

`oram_params.vh` holds them as `ORAM_CT_WB_B<beats>` / `ORAM_CT_DONE_B<beats>` and selects by block
size; unlisted sizes fall back to the 4 KB budgets. **These come from the testbench memory model**:
for small blocks the first position lands 10–35 cycles after the read. Real HBM or PCIe is slower, and
small blocks leave little work to hide that behind, so calibrate on the card before relying on them.

**Bugs found while doing this:**
- **`scr_addr` hard-coded a 7-bit beat field** (right only for 128 beats). With smaller blocks,
  encrypted data landed in the wrong scratch locations, and the first read failed its integrity check.
- **The eviction-copy counters were fixed at 8 bits** (a negative replication count for small blocks).
- **Boot declared DOMA ready before its last writes were acknowledged.** A latent deadlock, present at
  4 KB too: the first access's read would be held while its fixed write-back point still arrived. Boot
  now waits for every acknowledgement.
- **1-beat blocks needed masked in-block addresses** in the kernel wrapper, scratch buffer and stash.

**Test infrastructure:**
- the memory model now pipelines late-landing writes per burst (it serialized them);
- the self-test's data pattern, the timing monitor and the tamper target no longer assume 4 KB;
- the negative control's too-early budget scales with the measured encryption time.

**Results:** the full single-client regression passes all 20 checks at every size (32, 64, 128, 256
bytes and 4 KB).

**Configurations:** DOMA serves **one client** (see the next section).

**Usage:**
- simulation: `ORAM_BEATS=8 bash run_verilator.sh all`;
- card: `BEATS=8 TARGET=hw bash build.sh`;
- the kernel reports its block size in its summary record (bytes 4–7), and `host_doma` lays out its
  data accordingly. It prints `block: N bytes per slot` after boot.


## One client: schedule and dummy accesses removed

DOMA serves one client, so everything that existed only for several clients is gone.
- **The two-client build option** (`ORAM_TWO_CLIENTS`). `run_verilator.sh` refuses `ORAM_CONFIG=two`.
- **The window schedule:** the owner table, frame index and frame length, with their configuration
  ports (`cfg_tdm_frame_len`, `cfg_tdm_owner`, `cfg_tdm_owner_valid`).
- **The dummy-access path:**
  - the top level's dummy flag and counter (`dbg_dummy_cnt`);
  - the window debug outputs `dbg_slot_real` and `dbg_slot_owner`;
  - the controller's `client_dummy` input, its dummy branch and data-operation skip;
  - completion is no longer gated on "not a dummy".
- **Two-client tests:** the two-client self-test variant, cross-client non-interference and partition
  isolation.

**Kept:**
- A window starts when the client's request is ready, and lasts the fixed window length
  (`cfg_tdm_slot_cycles`, 0 = `ORAM_TDM_SLOT`), so a result returns a fixed time after its request.
- The client-count and partition-width parameters remain, fixed at 1 and 0; their logic collapses to one
  client in synthesis.
- The self-test's three two-client tests remain in its sequence, reported as skipped, so its timing
  trace is unchanged.
- The timing monitor's trace keeps its `dummy` column, always 0.

**Verification:** single-client behavior is bit-identical. At 4 KB the regression reproduces the timing
hashes (`afa088624bd8ad5f`, `b35c7b2c840d4fbb`), calibration (4,136), bus offsets (20, 3,824) and derived
worst case (4,084/4,172), and all 20 checks pass. At 32 bytes, all 20 checks pass.

**Note:** `run_verilator.sh` reuses compiled testbenches. After editing a testbench or the monitor, run
with `REBUILD=1`.


## Packed small records: masked writes (step 2)

Records smaller than a block are packed into it: with R-byte records, P = block ÷ R share a block, and
key k is record k mod P of block k ÷ P. Every access already reads its block, so a PUT of one record
**merges** into the block within the same single access.
- **Command header:**
  - bytes 8–11: the record's byte offset in the block;
  - bytes 12–15: its length.
  Length 0 means the whole block, so older headers (zeros there) behave as before. A range running past
  the block is answered with status **`0x40`**, without an access.
- **Byte strobes:**
  - the kernel gives each PUT data beat a strobe covering the record's bytes;
  - the top level buffers it beside the data (`client_wstrb`);
  - the controller's copy engine writes `(old & ~strobe) | (new & strobe)`.
  "Old" is the block's copy in the scratch buffer (found in a bucket) or in the stash (merged in place),
  or zeros (never written). Every PUT takes this merge path; a full strobe gives exactly the client's
  data.
- **GET** returns the whole block; the host takes the record's bytes.
- **Host:** `DOMA_PACK=1 ./host_doma ...` packs `block ÷ VALUE_SIZE` records per block (8-byte values:
  4 per 32-byte block, so 1,024 keys at N = 256). The preload runs in batches; initialization is not
  measured.

**Verification:**
- **Kernel testbench, `+packed=R`:** each PUT carries junk outside its record, and every GET is compared
  with a byte-exact image of the **whole** block, so neighbouring records and never-written bytes are
  checked. Two regression tests:
  - packed 8-byte records over preloaded blocks, with a bad range rejected;
  - packed 16-byte records with late writes and read pauses.
  Both pass at 32-byte and 4 KB blocks.
- **Full regressions:**
  - 32 bytes: 20/20;
  - 4 KB: 22/22 with the tests above.
  Timing is unchanged: the timing hashes and derived worst cases are identical at both sizes, and 4 KB
  calibration moved by 1 cycle (4,137).
- **Host program:** run against a software model of the kernel protocol (`STUB_BEATS`, real buffers),
  it reports all responses correct, unpacked and packed, at 32 bytes to 4 KB. With the model
  deliberately ignoring record ranges, it reports the wrong data.


## Out-of-range part-selects at small block sizes (found by Vivado)

Vivado synthesis of the 32-byte build failed: `part-select [6:0] out of range of prefix 'cfill'`. Fixed
`[6:0]` slices (sized for 128-beat blocks) indexed the write buffer (`secure_oram_top.v`: `cfill`,
`ctrl_beat_req`) and the result buffer (`flat_oram_gcm.v`: `cp_wr_beat`, `res_beat`). For smaller blocks
those counters are narrower. Verilator reports this only as a warning, and the earlier lint runs
suppressed warnings. The indexes are now masked (`counter & (BEATS-1)`), the same bits as `[6:0]` at 128
beats.
- **Lint:** with `-Wall`, there are zero out-of-range selects at 1, 2, 4, 8 and 128 beats. The
  regression's new `lint` group fails on any.
- **Kernel tests** pass at 32 bytes (whole blocks, packed over preloaded blocks, packed under stress)
  and at 4 KB.

## Memory latency benchmark (`latency/`)

`latency/hbm_lat_kernel.v` is a small Vitis RTL kernel. It measures, on the card:
- dependent 32-byte reads (a position-map lookup);
- write acknowledgements;
- dependent 4 KB bursts (a bucket read).

It reports min/avg/max and percentiles from a histogram. The chain lives in HBM[8], the bank DOMA's
buckets use, or in host memory with `lat_host.cfg`. Its results fix the HBM latency in the scaled
design's performance bound, and the off-package latency for the final budgets. In simulation, every
sample equals the memory model's latency plus 2 cycles. See `latency/README.md`.


## Step 3.1: the position map in HBM

DOMA's trusted metadata moves from on-chip memory to on-package HBM, starting with the position map
(`rtl/pos_map_hbm.v`, which replaces `pos_map.v`).
- **Layout:** one 32-bit entry per slot at `meta + 4k` (bucket in the low bits, then the 2-bit
  status), so 8 entries per 32-byte line.
- **Reads:** a lookup reads one beat.
- **Writes:** one beat with a 4-byte strobe (no read-modify-write), posted through a 16-entry FIFO.
  `wr_quiet` reports when every write is acknowledged. A read is held until the map is quiet, since
  AXI does not order a read after an unacknowledged write. The unit test shows the hold matters: with
  writes landing 200 cycles late, 0 mismatches in 3,600 reads with it, 126 stale reads without it.
- **Controller:**
  - the lookup at the start of each access waits for the HBM read;
  - completion and the end of boot also wait for the map's acknowledgements;
  - the boot layout pauses while the write FIFO is full;
  - a FIFO overflow is a fail-stop error;
  - the legacy `init_pm_*` inputs no longer write the map (nothing drove them).
- **Budgets:** `ORAM_PM_LAT` (250 cycles) budgets the lookup. HBM measured on the U55C: dependent
  32-byte reads averaged 64 cycles, at most 179 in 2M samples. The read gate is
  `ORAM_CT_RD_BASE + ORAM_PM_LAT` = 266, and the write-back and completion points move out by the
  same 250 (the per-size table keeps its on-chip values; the selection adds `ORAM_PM_LAT`).
- **Kernel:** a fourth master, `m_axi_gmem3`, and argument `meta` (0x3C/0x40), latched at the first
  launch like `pages` (error `0x20` if a later launch names another buffer). The connectivity files map
  `meta` to **HBM[10]**, also in `doma.cfg`, where the buckets are in host memory: the metadata is
  trusted state and stays on-package.
- **Testbenches:** a metadata memory with the measured HBM profile (reads 53 cycles, 2% of them 105
  slower, writes acknowledged after 26), adjustable with `+meta_lat`, `+meta_slow_pct`,
  `+meta_slow_extra` and `+meta_wlat`.

**Constant time with variable HBM latency:** at 32-byte blocks, per-command latency rose by exactly
the 250-cycle budget (1,479–1,522 cycles). The query's device cycles were identical (184,796) with the
normal profile, with late bucket writes, and with five times the measured share of slow metadata
reads. Only boot time changes with slow metadata writes, and boot is not measured.


## Step 3.2: the bucket metadata and the IV/tag table in HBM

With step 3.1, all of DOMA's trusted metadata is in on-package HBM. `rtl/bucket_rec_hbm.v` replaces
`bucket_meta.v` and `iv_slot_table.v` behind the same two interfaces.
- **Records:** each bucket has a 256-byte record at `brec + 256b`. Beat 0 holds the metadata
  `{slot list, fill}`, and beat 1+p holds position p's `{tag, IV}`.
- **Opening a bucket** fetches its whole record in **one burst** into an on-chip buffer. The metadata
  is answered when beat 0 lands; an IV/tag read is answered once its beat has landed.
- **Writes** update the buffer and are posted through a FIFO that takes two pushes per cycle.
  `wr_quiet` reports when all are acknowledged, and HBM reads are issued only while quiet.
- **Fallback:** an IV/tag read of a bucket that isn't open is fetched individually (the controller
  never does this).
- **Unit test:** 13,628 checks, 0 mismatches, including rounds that reopen the bucket just written while
  writes land late. Without the read hold, 586 stale reads.
- **Early fetch:** the controller opens the bucket's record as soon as the position-map lookup returns
  the bucket, not at the fixed read gate. HBM is on-package and its accesses are not observable, so only
  the bucket's own, off-package read waits for the gate. Fetched at the gate, a slow record read could
  delay position 0's verification: the derived worst case at 32 bytes rose from 905 to 1,046 (deadline
  1,205). Fetched early, it is 911/895.
- **Controller:** completion and the end of boot also wait for the record writes. The boot layout pauses
  while either metadata FIFO is full. An overflow is fail-stop, and the legacy `init_bm_*` inputs no
  longer write the metadata.
- **Kernel:** a fifth master, `m_axi_gmem4`, and argument `brec` (0x48/0x4C), latched at the first
  launch (error `0x20` on a different buffer later). It is mapped to **HBM[11]** in every connectivity
  file, and `host_doma` allocates 256 bytes per bucket.
- **Testbenches:** a record memory with the measured HBM profile (`+brec_*` options). `tb_ni`'s bucket
  drain reads metadata from the records.

**Cost: none.** At 32-byte blocks, the timing hashes, bus offsets (270 and 1,204), per-command latency
(1,479–1,522) and query device cycles (184,796) are identical to step 3.1, including with five times
the measured share of slow reads on both metadata memories.


### Step 3.2 revision: record storage as LUT-RAM (routing congestion)

The first card build of step 3.2 routed very slowly: about 40 minutes per routing iteration, against
well under 30 minutes for all of routing before. In the record module, the write FIFO
(16 × 256 bits) accepted two writes per cycle, and the open-record buffer (8 × 256 bits) had three write
sources. Neither could be a RAM, so they became about 6,000 registers. The FIFO's 16-to-1, 256-bit output
multiplexer also drove the AXI write channel directly, all in SLR0 next to the HBM interfaces.
- **Both now have one write port:** metadata, IV/tag and fetched-beat writes never coincide. If they
  did, or if a write hit the record while it was still arriving, `err` stops DOMA. Both are therefore
  distributed RAM.
- **The FIFO's head is registered** before it drives the AXI write channel.
- **Behavior is identical:** the unit test gives the same 13,628 checks, and the mutant without the read
  hold the same 586 stale reads. The regressions reproduce the same timing hashes, bus offsets and
  derived worst cases.

**Unit tests:** `sim/tb_pmh.v` and `sim/tb_brec.v` check the two HBM metadata modules against reference
models, with the measured HBM profile and a late-landing write phase. They run in the new `units`
regression group (part of `all`).


## Step 4: the stash in HBM

`rtl/stash_hbm.v` replaces the on-chip stash (`stash.v`, with its 128-entry parallel search) behind
the same interface, plus open/ready/commit and an AXI master. The organization is BOLT's: per-bucket lists
of pointers into a pool of stash blocks.
- **HBM layout:** bucket b's list at `b * 512`: 64 entries of 64 bits `{valid, slot, pool index}`. Pool
  block i follows at `POOL_BASE + i * block size`.
- **Pool size:** `ORAM_STASH_DEPTH` blocks, max(N/4, 128); 128 at N = 256.
- **List size:** `ORAM_STASH_SLOTS` (64) per bucket. DOMA places each block in one random bucket, so the
  most blocks waiting for a bucket has a geometric tail (simulated: P(at least 8) is about 4e-4 for any N);
  64 makes overflow negligible up to N = 10M.

**Per access.** A stashed block is in the list of its target bucket, and an access reads exactly that
bucket. So the controller opens two buckets at the position lookup, together with the record fetch: the
bucket read (b) and the new random target (b').
1. **Reads, pipelined:** both lists go out back to back. As soon as b's list lands, the requested block
   (if stashed) and the lowest-indexed Z other entries go out back to back into an on-chip staging buffer.
   A tag queue routes the in-order returns.
2. **The eviction loop** takes candidates in the same order, so every eviction of an access (at most Z)
   finds its block staged.
3. **`S_SCAN` waits for `ready`.** Every stash operation after that (slot search, candidates, insert,
   remap, evict, data reads and writes) is served on chip, with the old stash's one-cycle read latency,
   so the copy engines are unchanged.
4. **`S_EA_START` commits:** both lists and the staged blocks written during the access go back to HBM.
   Completion waits for their acknowledgements.
5. **Boot** zeroes every list. It starts at the controller's boot (`init_go`), because the kernel learns
   the stash buffer's address only at the first launch.
6. **Fail-stop errors:** a full list or pool, an entry missing where it must be, or unstaged data.

Free pool indices come from an on-chip free stack plus a never-used counter.

**Kernel:** a sixth master, `m_axi_gmem5`, and argument `stash` (0x54/0x58), latched at the first launch.
It is mapped to **HBM[12]** in every connectivity file. `host_doma` allocates the lists plus a pool sized
for 4 KB blocks.

**Cost: none.** At 32-byte blocks, the timing hashes, bus offsets (270/1,204), per-command latency
(1,479–1,522) and query device cycles (184,796) are identical to step 3.2, including with slow or late
stash memory. The derived worst case is 906/890 against 1,205, slightly better than with the on-chip stash,
since evictions no longer wait out its one-cycle masking.

**Timing analysis.** The monitor now records `t_op`, the cycle the stash became ready. `worst_case.py`
treats the stash wait W = `t_op − t_scan` as a memory-dependent segment, like the bucket's read latency,
and adds its maximum to the bound. That is conservative, since the stash is fetched during verification.
With pipelined reads, W is 1 cycle (the state change) in every traced access. A first version fetched one
burst at a time; there W reached 72 cycles, and the operation segment stopped being deterministic.

**Unit test (`sim/tb_stash.v`, in `units`).** It drives the module like the controller and checks against a
reference model, with exact list contents after every open:
- 4,600 accesses with the HBM profile;
- a growth phase that fills the pool (116 of 128 blocks, up to 47 waiting for one bucket);
- a phase where writes land late and each access opens as soon as the previous commit has issued them.

All block sizes pass with 0 mismatches; without the read hold, stale lists are caught. The test found
three bugs: an unsized mask in the staging address, a write-back reading its first beat from the wrong slot,
and a stale beat counter, plus staging sized for half its address range at 32-byte blocks. The unit tests
now use an xorshift generator, because Verilator's `$random(seed)` produced a degenerate sequence there.


### Step 4 revision: stash timing (no 64-entry search in a single cycle)

The first card build of step 4 spent 25 minutes in "Post Placement Timing Optimization" (a few minutes
in builds that met timing). The stash's single-cycle searches over its 64-entry lists were feeding
decisions and writes in the same cycle, the same kind of path that failed in the old stash's free-index
search. The module is restructured; its behavior at the interface is unchanged apart from two points.
- **Handles:** the index the stash hands the controller is the block's **staging slot**. The controller
  never keeps a stash index beyond the access. Data reads and writes address staging directly, and remap and
  evict use the list position recorded per staging slot, so these paths have no search.
- **Registered searches:** the slot search, the first waiting block and the first free list entries are
  registered from stable lists.
  - In the cycle right after any change to b's list, `cam_bkt_inhibit_busy` is high: the registered
    candidate is stale then. The eviction loop already honored this signal for the old stash, so an
    eviction decision now takes 4 cycles instead of 3.
  - `ready` follows the last list change by two cycles.
- **Two-stage prefetch:** selection is registered, and the burst is issued the next cycle.
- **Registered list write-back data**, like the staging write-back.

A first version raised busy one cycle late (a registered copy of the change flag). The controller then
saw the stale candidate in the cycle after an eviction and evicted the same block twice, which the gated
stress test, the directed worst cases and the kernel tests caught. The unit test missed it because it paused
between evictions. Its eviction loop now matches the controller exactly: it asks again the very next cycle,
honors busy, and reads the evicted blocks afterwards. A mutant with the late busy fails it.

**Result:** 26/26 at both block sizes, with identical timing hashes and bus offsets. At 32 bytes the derived
worst case is 911/895 against 1,205 (C grows by one cycle per eviction).

**Synthesis check and the next free index.** `worst_paths.tcl` on the restructured stash (32-byte blocks,
U55C, 300 MHz, before placement) found no failing path. The worst, at +0.660 ns slack and 9 logic levels,
was the insert path: free-stack pointer, read the free stack, choose it or the never-used counter, then
write the list entry, fanning out to all 64 entries. The next free pool index is now computed one cycle
ahead into a register, which shortens that path to a few levels. Inserts happen long after the free stack
last changed, so the register is always current. It is stale only in the cycle right after an eviction or
insert, and an insert in that cycle raises the error, so DOMA would stop rather than hand out a stale
index. Behavior is identical: the same unit-test counts, regressions, timing hashes and worst case. Step 5
needs the same register anyway: at large N the free stack moves to block RAM, which only reads synchronously.


### GHASH pending queue as LUT-RAM (timing and area)

The placement log of the step-4 build (WNS -0.025 ns after placement) showed the placer replicating
`u_aes_gcm/ghash_pending_rd_ptr` about 48 times. The GHASH pending queue (256 x 128 bits) was written
inside the AES-GCM FSM's asynchronous-reset block, which no RAM can implement. So it was about 32,000
flip-flops plus a 256-to-1, 128-bit read multiplexer driven by that pointer.
- The FSM now registers a write request (enable, address, data), and the queue, marked
  `ram_style = "distributed"`, is written one cycle later in a reset-free block.
- Reads stay asynchronous, so GHASH is fed with the same registered read as before.
- While the head of the queue is the entry being written, it is not read for that cycle
  (`ghash_pending_head_ok`). Push/pop count adjustments use the same condition.

**Behavior:** at 32-byte blocks the kernel tests give identical device cycles (184,796; packed 185,129),
latency and data. Calibration's worst encryption end moved from 828 to 840 cycles (the one-cycle hold), against
a 1,205 deadline. Every authentication tag and data check passes; any error in GHASH's input would break them.


### Step 4 revision: routing congestion (stash lists in LUT-RAM)

The step-4 card build (restructured stash, GHASH queue still in registers) placed at WNS -0.025 ns, then
stalled in routing:
- congestion **level 6** (64 x 64 tiles), in all directions, on long and short wires;
- "Congestion is preventing the router from routing all nets";
- WNS -0.491 ns, TNS -211 ns.

The congested windows (tiles X40-105, Y124-190) are DOMA's own logic cluster in the middle of SLR0, not the
HBM interfaces at the SLR's bottom edge. Yosys estimates (UltraScale+ mapping, 32-byte blocks) located the
growth:

| Stash version | LUTs | Flip-flops |
|---|---|---|
| on-chip stash (step 3.2) | ~8,300 | ~5,000 (+4 URAM) |
| HBM stash, register lists | ~14,200 | ~5,100 |
| **HBM stash, LUT-RAM list fields** | **~3,200** | **~1,500** |

As registers, every list field had several write sources (landing, insert, remap) and 64-way read
multiplexers.

**The change:** the fields `{slot, pool index}` now live in LUT-RAM, one memory per entry position in a
256-bit beat (entry k at column k % 4, row k / 4).
- Landing a list beat writes one row of all four columns, and the write-back reads one row. Insert, remap,
  the eviction candidate and the prefetch selection access one column through a registered index.
- The requested slot is found while b's list lands: 4 comparisons per beat replace 64 comparators.
- Only the valid, staged and staging-slot bits stay in registers.
- An insert and a remap in the same cycle (never in DOMA's flow) is an error, since each column has one
  write port.

The unit test gives identical results at all block sizes (the same check counts), and both mutants still
fail. Together with the GHASH queue in LUT-RAM (~32,000 flip-flops and ~6,000 LUTs removed), the dense
cluster should largely disappear.

**Build hook:** for hardware builds, `build.sh` runs `vitis/post_place.tcl` right after placement. Each
command is wrapped in `catch`, so it can never fail the build. It writes the placed checkpoint
(`post_place.dcp`) and reports on congestion with the cells in each window
(`post_place_congestion.rpt`), utilization per module (`post_place_util_hier.rpt`) and post-placement
timing (`post_place_timing.rpt`), in `_x/link/vivado/vpl/prj/prj.runs/impl_1/`. A stopped build still
leaves this evidence; the v++ flow otherwise keeps no implementation checkpoint until it finishes.


### Traffic record (byte counters) in the kernel

`doma_kernel.v` counts handshaked read and write beats on `gmem2` per launch and writes them as record
`[size+1]` (`0x5B`; bytes 8–15 read, 16–23 write). GET data moves to `roundup((size+2)·32, 4 KB)`. The
format is the one agreed with the Tiny ORAM kernel (its plan item B2); details are in
`vitis/README_VITIS.md`. Device cycles, latency and every other result are unchanged. At 32-byte blocks a
query reads and writes 6 beats (192 B) per command, one bucket each way.


## Step 5.1: target generator and boot layout that scale

**Assumption, as in BOLT and other ORAM hardware:** DOMA's security assumes a cryptographically secure random
source (for example, AES in counter mode seeded from a true random number generator). The prototype uses
statistical generators in its place. They affect security, not performance: random values are drawn
ahead of use, so the timing is the same with any generator. The AES key and IV seed stay fixed across
boots in this prototype. GCM's IVs come from a maximal-length 96-bit LFSR, verified from the RTL's own
update rule: its step map has order exactly 2^96 - 1, and the IV sequence, taking every 96th state, has
period (2^96 - 1)/3. IVs are therefore unique within a boot, but they repeat across boots under the fixed
key. A deployment must load a fresh key per boot.

**Target buckets (`rtl/rng_bucket.v`, replaces `prng_lfsr.v`):**
- The generator is a 64-bit xorshift (Marsaglia's 13/7/17 triple, period 2^64 - 1). The old 12-bit LFSR's
  4,095 states could not cover hundreds of thousands of buckets.
- Draws map onto any number of buckets as (r · B) >> 40, with r the top 40 bits (bias at most B/2^40).
- The generator advances only when an access takes a value, so the sequence of targets does not depend
  on the requests. The output is pipelined: it is valid 3 cycles after a take.
- Checked against a Python model: 2,000 draws match exactly for B = 64 and B = 6,250, with chi-square
  values consistent with uniformity.

**Boot layout (`rtl/slot_perm.v`, replaces the Fisher-Yates array and shuffle):**
- The layout streams P(k) for k = 0..n-1, where f is a keyed bijection of M-bit values (xor a key,
  multiply by an odd constant, xor-shift, add a key, multiply, xor-shift). Cycle-walking makes it a
  bijection of [0, n) for any n.
- The layout places slot P(k) in bucket k/λ. It uses no N-entry array and no shuffle pass, and boot scales
  to millions of slots (about 4 cycles per slot).
- Checked against the Python model for n = 256, 200, 1,000 and 6,250: exactly n values, all distinct, all in
  range.
- The `perm` array (about 2,000 registers plus two 256-to-1 read multiplexers) is gone.

**Regressions:** all checks pass at both block sizes. The bus offsets and the derived worst case are
unchanged, and the kernel tests' device cycles are identical (184,796 and 185,129 at 32 bytes): the random
targets change which buckets are touched, never when.


## Step 5.2: the number of blocks at run time

**One bitstream serves every size up to its maximum.**
- `ORAM_N` is now the build's **maximum** number of blocks. The bucket count ⌈N/λ⌉, the slot and bucket
  widths and the slot-address width derive from it, with identical values at the default N = 256.
- `build.sh NMAX=4194304` builds for 2²² blocks: 10M 8-byte records packed four to a 32-byte block are
  2.5M blocks. That build has 22-bit slots, 20-bit buckets and a 35-bit slot-address width, which also
  holds the IV/tag interface's {bucket, position} encoding.
- The host chooses the actual n through a new kernel argument, **`nblk`** (0x60, latched at the first
  launch; a different value later is error 0x20; 0 means the maximum; above the maximum is error 0x80).

**What uses n:**
- the target generator's range (⌈n/λ⌉ buckets) and the format loop;
- the layout: `slot_perm` now picks its domain width m = ⌈log₂ n⌉ at run time, so cycle-walking stays
  under two applications per slot at any n. Measured in a 22-bit build: exact bijections at n = 1, 2, 3,
  200, 256, 1,000, 6,250, 65,537, 100,001 and 131,072, at 4–7 cycles per slot;
- the stash's list initialization and pool base;
- the key check: an explicit `key < n` in the kernel (status 0x4), plus the lease, now
  `{n, 12'b0}` at the slot-address width. It was a 32-bit `ORAM_N << 12`, which overflows above 2²⁰ slots.

**The stash pool now has one entry per slot** (pool index = slot number), replacing the allocated pool
of `ORAM_STASH_DEPTH` blocks and its free list. There is no allocation and no free stack, and **the pool
can no longer overflow**: only the per-bucket list bound (64) remains. It costs n blocks of HBM, 80 MB at
10M records. HBM accesses are not observable, so addressing by slot leaks nothing.

**Fixes found on the way:**
- the layout counters were 10 bits wide (`lay_i`, `lay_div`), which broke above 1,023 slots and 4,096
  slots respectively;
- a final partial bucket (n not a multiple of λ) got no metadata; it is now written with its true fill,
  and each bucket's slot list starts clean;
- the IV/tag address needed one more bit than the slot address at 2²² (lint at that size found a negative
  replication).

**Host:**
- `DOMA_N=<records>` and `DOMA_BLOCK=<bytes>` (default 4,096): with `DOMA_PACK=1`, n = ⌈records /
  (block/8)⌉ blocks. Every buffer is sized from n and the block size, and `nblk` is passed on every launch.
- The host stops with a clear message if the kernel's block size differs from `DOMA_BLOCK`. Buffers are
  allocated before the boot launch, when the kernel's block size is not yet known.
- Without `DOMA_N` the host uses 256 blocks, as before.

**Verification:**
- The kernel testbench's command, response and stash memories are now sized from the build (a 4,096-slot
  pool of 4 KB blocks is 16 MB), and its preload writes each of the n blocks once. At 4 KB the first
  run of the new test lost slot 4,095's stashed copy beyond a 2 MB model, which the model itself
  flagged as out-of-range accesses.
- A new kernel test: a 4,096-block build run at n = 1,000 (250 buckets, packed records, a bad key inside
  the build's range) and at n = 4,096. All checks pass, with **the same device cycles as the default
  build**: per-access cost does not depend on n.
- The default build's timing hashes are unchanged. The host runs correctly against the protocol model at
  1,000 and 100,000 blocks.

**Sweep build and runs (32-byte blocks, buckets in HBM):**

    NMAX=4194304 BEATS=1 TARGET=hw CFG=doma_hw.cfg ./build.sh
    DOMA_PAGES_HBM=1 DOMA_PACK=1 DOMA_BLOCK=32 DOMA_N=100000   ./host_doma doma_hw.xclbin 5000
    DOMA_PAGES_HBM=1 DOMA_PACK=1 DOMA_BLOCK=32 DOMA_N=1000000  ./host_doma doma_hw.xclbin 5000
    DOMA_PAGES_HBM=1 DOMA_PACK=1 DOMA_BLOCK=32 DOMA_N=10000000 ./host_doma doma_hw.xclbin 5000

The preload writes every record once (as BOLT's initialization does) and is not measured.


### Step 5.2 revision: timing at the sweep build's widths

The first sweep build (`NMAX=4194304`, 32-byte blocks) routed at WNS -0.348 ns, and v++ scaled the kernel
clock to 271 MHz. `worst_paths.tcl` on its routed checkpoint found exactly two paths, both long only at
these widths:
1. **`slot_perm`, s1 -> s2** (20 failing endpoints, worst -0.348 ns, 12–13 levels): a variable shift, xor
   and add feeding a 22 x 22 multiply in one cycle. One application of f now takes **five stages**, so no
   multiply shares a cycle with a variable shift or an add. Bijections are re-verified in a 22-bit build at
   n = 1, 2, 3, 200, 256, 1,000, 6,250, 65,537, 100,001 and 131,072, at 6–11 cycles per slot (about 65 ms
   of boot at 2.5M blocks).
2. **The lease table, `found_slot` -> `lease_token_r` write enables** (-0.022 ns, 7 levels; the lease
   addresses are 35 bits wide in this build): the found region's token and owner are now registered during
   the search, so the operation states compare registers instead of a 16-way, 32-bit multiplexer. This is
   behavior-identical: nothing writes that region's token or owner between the search and the operation.

The target generator's 40 x 21-bit multiply was not among the failing paths.


### Every init launch re-boots DOMA

**The problem.** The first sweep on the card ran 100K records correctly, then failed at 1M and 10M with
summary error 0x20. DOMA booted only at the first launch after the card was programmed, and latched its
buffers and `nblk` until the card was reprogrammed. XRT does not reprogram the card when the same xclbin
is already loaded, so the next host process, with larger buffers and a larger n, was talking to the DOMA
the previous process had booted.

**The fix.** Now **every launch with size 0 (the host's init launch) boots DOMA with the arguments it
brings**. On an already-booted kernel, a new state, `K_RST`, first holds the DOMA core in reset for 16
cycles (its `rst_n` also takes a registered `doma_srst`) and clears the kernel's boot state (`key_sent`,
the lease). The rest is the normal first boot: key, format, layout, lease. Error 0x20 now applies only to
launches with commands that name a different buffer.
- Between launches DOMA is idle: an access completes only after its writes are acknowledged, and a
  launch always runs to completion. So the reset never interrupts an AXI transaction.
- Every run starts from a fresh boot (fresh layout, blocks reading as zeros), whatever ran before, as
  BOLT's host initializes its kernel at the start of each run.
- Per-access cost is unchanged; the boot is part of the unmeasured init.

**Test (`kernel` group):** a 4,096-block build boots at n = 4,096 and runs two launches; then an init launch
re-boots it at n = 1,000 with the pages buffer moved by 16 MB, and a third launch runs.
- All checks pass at 32 bytes and 4 KB: no 0x20, and every GET is correct against a reference image cleared
  at the re-boot.
- The third launch costs the same cycles as the first (61,663 against 61,626 at 32 bytes).
- Boot takes 78,240 cycles at n = 1,000 and 319,575 at n = 4,096 (32 bytes), about 0.65 s at 300 MHz for
  2.5M blocks.


## Arrival-relative scheduling (build option `SCHED=arrival`, buckets in host memory)

**Why.** Host-memory latency measured on the U55C (`latency/`, chain in HOST[0], 2M samples):

| | Average | p99.99 | Maximum |
|---|---|---|---|
| Dependent 32-byte reads | 263 cycles (869 ns) | 343 | **947** (3.15 us) |
| Write acknowledgements | 98 (constant, 97–99) | 99 | 99 |
| 4 KB bursts, to the last beat | 523 | 655 | 1,215 |

Strict fixed windows would have to cover the rare 947-cycle read on every access (about 2,500 cycles per access
at 32-byte blocks). But the attacker snoops that very bus and sees the read's latency anyway.

**What changes.** With `SCHED=arrival` (`ORAM_SCHED_ARRIVAL`), an access's write-back and end follow the bucket
read's last beat by fixed times, `AR_WB` and `AR_DONE`, instead of fixed offsets from the access start. The top
level's window ends when its access has finished, instead of after a fixed length.

**What stays padded (everything the attacker cannot see):**
- the position-map lookup: the read still issues at `CT_RD`;
- all work after the data arrives (verification, stash hits, evictions, re-encryption), padded to its worst case
  by `AR_WB`.

**Why it is safe.** The four conditions this relies on hold by construction:
1. The bucket master never back-pressures a read (`rready` stays high for the whole read), so the arrival time
   reflects only the memory and the bus.
2. The hidden metadata (the record and the stash) is fetched from the lookup on and always arrives before the
   bucket data.
3. DOMA's only off-package traffic is the buckets (commands, responses and metadata are in HBM).
4. The mode is only for buckets off-package: `build.sh` refuses `SCHED=arrival` unless `CFG=doma.cfg`. With
   buckets in HBM the arrival would be hidden.

Every observable time is then a function of observable memory behavior plus constants. That is stricter than BOLT,
which pads neither its on-package lookups nor work that varies with history.

**Budgets** (`rtl/oram_params.vh`):
- **32 B:** `AR_WB` = 670. The worst work after arrival is 306 (rest of verification) + 1 (stash wait) + 36 (stash
  work, 6 evictions) + 287 (re-encryption) = 630 from the worst-case group, plus 40. `AR_DONE` = 910 (write-back
  plus the 98-cycle acknowledgement, with margin).
- **4 KB:** `AR_WB` = 4,020 (bound 3,920 + 100), `AR_DONE` = 5,430.
- A late acknowledgement or encryption is still a fail-stop overrun (a 200-cycle acknowledgement trips
  `AR_DONE`; the measured one is 98).

**Results in simulation (32 B, kernel testbench):** at PCIe-like latencies (263-cycle reads, 98-cycle
acknowledgements) each command takes 1,457–1,500 cycles; a 950-cycle read stretches only that access
(2,104–2,147). All data checks pass, including packed records and slow metadata.

**Regression group `arrival`** (in `all`): the kernel tests in arrival mode, plus a check that the worst work
after arrival, both measured (`ar_max_wb`) and derived, fits `AR_WB`. Strict mode is unchanged: its timing hashes
and every strict check are identical.

**Build (32-byte blocks, sweep size, buckets in host memory):**

    NMAX=4194304 BEATS=1 SCHED=arrival TARGET=hw CFG=doma.cfg ./build.sh
    DOMA_PACK=1 DOMA_BLOCK=32 DOMA_N=1000000 ./host_doma doma_hw.xclbin 5000   # no DOMA_PAGES_HBM: buckets in host memory


## Buckets split between host memory and HBM (`DOMA_HBM_PCT`), and calibrated strict budgets

**Fixed boundary.** `DOMA_HBM_PCT=<0..100>`, chosen at each boot, keeps buckets 0 .. H-1 in HBM, with
H = floor(B x pct / 100). The rest stay in `pages` (host memory in `doma.cfg`).
- The kernel has a second bucket port, `gmem6` (argument `pages_hbm`, 0x68/0x6C; count `hbm_bkts`, 0x74;
  10 arguments in all). Its switch sends each bucket transaction to its memory, with both buffers compact:
  `pages_hbm + b x stride` for HBM buckets, `pages + (b - H) x stride` for the rest.
- DOMA never has transactions to two buckets in flight at once (a read waits for earlier write
  acknowledgements, and an access ends when its writes are acknowledged), so the R and B channels follow a
  select recorded when the address is issued.
- Every access targets a random bucket, so about pct% of accesses use HBM. Which memory an access uses is
  visible, but it is independent of the request.
- `doma.cfg` connects `pages_hbm` to HBM[16:31] (until v11b HBM[8]; `pages` stays HOST[0]); `doma_hw.cfg` and `doma_emu.cfg` to
  HBM[9]. `doma.cfg` now also has the SLR0 placement and the implementation directives of `doma_hw.cfg`
  (they were missing; every earlier board build used `doma_hw.cfg`).
- The traffic record counts the `pages` port only: bytes over PCIe per command.

**What is padded (agreed rule).** Everything that depends on secrets:
- the position-map lookup (the bucket read issues at `CT_RD`);
- the requested block's own path (stash hit or not, compaction);
- all eviction work and its writes and acknowledgements.

A bucket's own read latency is not padded in arrival mode, in host memory or in HBM: the bucket is random, and
the bucket bank serves only buckets. The condition for HBM is that DOMA's eviction-related metadata traffic must
not interfere with the bucket bank; on the U55C, the bucket banks HBM[16:31] are on the other HBM stack from the position
map, records and stash (HBM[10]-[15]): another controller, switch segment and physical interface (v11c). A card measurement (HBM bucket latency under a repeated-key pattern
against a scan) can confirm it. `build.sh SCHED=arrival` is therefore allowed with any configuration.

**Arrival budgets for HBM buckets:** the same `AR_WB`; completion `AR_DONE_H = AR_WB + 100` (32 B; 4 KB:
+1,340), since HBM acknowledges writes in 28 cycles against PCIe's 98.

**Strict budgets at 32 B, calibrated to the measured HBM worst case** (U55C, 2M samples: 32-byte read max 179,
write acknowledgement 28):
- write-back at 1,120 (was 1,200): encryption ends at worst at 267 + 179 + 306 + 1 + 36 + 287 = 1,076,
  within the deadline of 1,125;
- completion at 1,220 (was 1,470); window 1,270 (was 1,520).

The worst-case analysis now uses the measured read latency (`MEM_L0_MAX`: 179 at 32 B, 307 at 4 KB) as a floor
for its first-position latency, so the budgets are checked against the hardware and not just the model. Strict
timing hashes at 32 B change with the new offsets (4 KB budgets are unchanged). The strict late-write kernel
tests use 60-cycle acknowledgements (HBM: 28).

**Simulation (32 B, kernel testbench, 120 commands):**

| Configuration | Device cycles | Per command |
|---|---|---|
| Strict, all buckets in HBM | 154,796 (was 184,796) | 1,229–1,272 |
| Arrival, 0% HBM (PCIe-like host memory) | 182,156 | 1,457–1,500 |
| Arrival, 20% HBM | 175,156 (-3.8%) | 1,107–1,500 |
| Arrival, 50% HBM | 159,756 (-12.3%) | 1,107–1,500 |
| Arrival, 100% HBM | 140,156 (-23%) | 1,107–1,150 |

**Verification:** both full regressions pass. 32 B: 32 of 32 checks in one run. 4 KB: an interrupted full run
(26 checks through the worst-case group), then the kernel group (12) and arrival plus crypto (7), all passing.
- New 32-byte strict timing hashes: `edecf3d57a9f7222` / `2fceafbb492ee1ea` (offsets moved: write-back 1,124).
- 4 KB hashes are unchanged: `11f8bfc8e4d73473` / `61fc9e15ed9aea5b`.

**Board build for the comparison** (buckets in host memory, HBM share chosen per run):

    NMAX=4194304 BEATS=1 SCHED=arrival TARGET=hw CFG=doma.cfg ./build.sh
    for p in 0 20 50; do DOMA_HBM_PCT=$p DOMA_PACK=1 DOMA_BLOCK=32 DOMA_N=1000000 ./host_doma doma_hw.xclbin 5000; done


## Per-bucket authentication (one AES-GCM message per bucket) and 64-byte records

**What changed.** Each bucket is now one AES-GCM message spanning its Z positions, with one IV and one tag,
instead of one message per position.
- Only position 0 reads the IV and tag and starts the message. Later positions continue it: the counter runs on
  across positions and GHASH accumulates.
- `data_last` comes only after the last position, and the single tag is checked (or stored) once.
- DOMA always reads, verifies, edits on chip, re-encrypts and writes back the whole bucket, so per-bucket
  authentication fits every access: removals (compaction) and insertions (evictions) happen on the plaintext,
  between a full decryption and a full re-encryption under a fresh IV.

**Security.**
- Any change to any position, any swap or reordering of positions, or any replay of an older bucket fails the
  bucket's tag. The IV is fresh from the 96-bit sequence on every write-back and is kept, with the tag, in trusted
  HBM.
- The whole bucket must verify before anything visible depends on it: the controller reaches its decisions
  (`S_SCAN`) only after the tag has checked, and a failure halts DOMA before any write-back, as tampering did
  before. `security_analysis.tex` needs the corresponding update (one tag per bucket instead of per position).

**Records** (`bucket_rec_hbm`): 64 bytes per bucket, 2 beats: beat 0 holds the metadata {slot list, fill
count}, beat 1 holds the bucket's {tag, IV}.
- They were 256 bytes, with one IV/tag beat per position. At 1M records (62,500 buckets) that is 16 MB -> 4 MB
  of HBM.
- The size is defined once, as `ORAM_REC_BEATS` in `oram_params.vh`; `tb_ni`'s direct metadata reads use it too
  (a hard-coded 256-byte stride there made the stress scenario miss its full bucket).
- The host allocates 64 bytes per bucket.

**Crypto work per access roughly halves** (worst-case cycle model):

| | Rest of verification | Re-encryption | Work after arrival | Strict worst encryption end |
|---|---|---|---|---|
| 32 B, per position | 306 | 287 | 630 | 1,076 |
| **32 B, per bucket** | **151** | **147** | **335** | **781** |
| 4 KB, per position | 1,824 | 1,805 | 3,920 | 4,506 |
| **4 KB, per bucket** | **1,675** | **1,671** | **3,637** | **4,211** |

**Recalibrated budgets** (strict totals include the 250-cycle position-map budget):

| | Strict write-back | Strict completion | Window | `AR_WB` | `AR_DONE` | `AR_DONE_H` |
|---|---|---|---|---|---|---|
| 32 B | 825 (deadline 830 vs 781) | 925 | 975 | 375 | 615 | 475 |
| 4 KB | 3,620 (deadline 4,260 vs 4,211) | 4,960 | 5,264 | 3,690 | 5,100 | 5,030 |

**Simulation, 32 B, kernel testbench, 120 commands:**

| Configuration | Device cycles | Per command |
|---|---|---|
| Strict, all buckets in HBM | 119,396 (was 154,796) | 934–977 |
| Arrival, 0% HBM (PCIe-like host memory) | 146,756 (was 182,156) | 1,162–1,205 |
| Arrival, 20% HBM | 139,756 | 812–1,205 |
| Arrival, 50% HBM | 124,356 | 812–1,205 |
| Arrival, a 950-cycle read | 229,196 | 1,849–1,892 (no overrun) |

**Fail-safe fix found while verifying this change:** a write-back gate that opens while the access's bucket read
is still in flight is now an overrun (fail-stop), and the write is not issued. Before, the write command went into
the still-busy bucket master and DOMA hung instead of halting. Calibrated budgets never come close to this case;
the negative control (a write-back budget at half the calibrated worst case, now 270 cycles, just after the read
issues at 267) exposed it once per-bucket authentication shrank the worst case.

The integrity argument for the paper is in `docs/security_per_bucket_gcm.md`.

**Verification:** both full regressions pass: 32 B, 32 of 32; 4 KB, all checks.
- New strict timing hashes: 32 B `810cdee71f603f30` / `9ee89360a15a31ee` (write-back at 829); 4 KB
  `0e50a1c3449c2ecf` / `620742c1d18fbbdb` (write-back at 3,624).
- Arrival mode per command at PCIe-like latency: 32 B 1,162–1,205 cycles; 4 KB 6,541–6,711.
- Post-arrival work against `AR_WB`: 32 B measured 326 / derived 335 / budget 375; 4 KB 2,988 / 3,637 / 3,690.
- Negative controls caught at 270 (32 B) and 1,988 (4 KB).


## Stash: per-bucket windows + chains through a bounded pool (the pool is the only possible overflow)

> **Superseded pool sizing.** The pool numbers in this section and in the Z = 8, lambda = 8 section below were computed with the Poisson(lambda) term and the provisional margin (1% of n + 64), for earlier parameters. Current sizing: see *Stash pool: n a multiple of lambda, Binomial(n, 1/B), pool = ceil(bound) + 1* at the end of this file.

The fixed per-bucket stash lists (64 entries, 512 B per bucket) are replaced: a list could fill up, which was a
second, separate overflow. Now the stash pool is the only capacity that can run out. Design, layout and per-access
work: `docs/stash_chain_design.md`. Summary:
- each bucket has a 32-byte head: a 7-entry window (its eviction candidates) and a chain head;
- further waiting blocks are chained through the pool (doubly linked), and free entries form a free list there;
- every access does a fixed set of HBM reads and one chain step;
- the position map's entries widen to 64 bits, carrying a stashed block's pool index.

**Pool size P** is the kernel's 11th argument, `pool_n` (0x7C; 0 or above n means n, which cannot run out). The
host computes it from Claim 1 at 2^-64 per access for the run's n, plus a provisional window margin (1% of n + 64);
`DOMA_POOL` overrides it.

| Blocks n | Claim 1 bound | Pool (host) |
|---|---|---|
| 4,096 | 1,894 (46.2%) | 1,999 |
| 25,000 | 8,945 (35.8%) | 9,259 |
| 250,000 (1M records) | 78,437 (31.4%) | 81,001 |
| 2,500,000 (10M records) | 750,973 (30.0%) | 776,038 |

**Trusted memory, 1M records (250K blocks of 32 B, lambda 4, Z 6):**

| Structure | Size |
|---|---|
| Position map (8 B per block) | 2.0 MB |
| Records (64 B per bucket) | 4.0 MB |
| Stash heads (32 B per bucket) | 2.0 MB |
| Pool links (16 B per pool entry) | 1.3 MB |
| Pool blocks (81,001 x 32 B) | 2.6 MB |
| **Total** | **~11.9 MB** (was ~45 MB with fixed lists and one pool entry per slot) |

That fits BOLT's trusted memory at its default (Claim 5.2: 12.5 MB) and at alpha = 0.5 (14.8 MB), with room left
for HBM buckets at 0.5. For alpha = 0.01 (10.9 MB), a slightly larger lambda is needed.

**Verification:**
- `tb_stash.v` (4 regression runs) checks against an exact reference model of windows, chains and the free list.
- `tb_pmh.v` checks pool indexes through the position map.
- The kernel group runs with bounded pools of 1,999 and 600 entries for 4,096 blocks.


## Z = 8, lambda = 8 (8 blocks per bucket, as BOLT's c = 8), packed stash heads, 6-byte position-map entries

> **Superseded pool sizing.** The pool numbers in this section and in the Z = 8, lambda = 8 section below were computed with the Poisson(lambda) term and the provisional margin (1% of n + 64), for earlier parameters. Current sizing: see *Stash pool: n a multiple of lambda, Binomial(n, 1/B), pool = ceil(bound) + 1* at the end of this file.

**Configuration.** Buckets now have Z = 8 positions for lambda = 8 blocks on average (`ORAM_Z`, `ORAM_C`), with no slack:
the stash pool absorbs the overflow, and is sized for it by Claim 1. Within lambda = 8, Z = 8 is the fastest choice and
also the smallest in total trusted memory, and within Z = 8, lambda = 8 is the smallest (lambda = 7 ties at 1-4 KB
values). The default test build has 512 slots (64 buckets, as the test scenarios assume); production sizes are set at
run time.

**Trusted-memory reductions:**
- **Stash heads stay one 32-byte beat:** the window grows to 8 entries (W >= Z, so a full bucket's evictions are always
  in the window). Entries are packed at PW + 1 bits ({valid, pool index}, 23 bits at the 2^22 build) instead of 32-bit
  words.
- **The position map uses 48-bit entries, 5 per beat** (6.4 bytes per block instead of 8). Entry k is in beat k / 5,
  lane k mod 5. The division is an exact multiply-and-shift (M = ceil(2^22 / 5), exact for every index below 2^22),
  pipelined over two registered stages on both the read and the write path. Reads still never overtake writes: the
  "quiet" signal counts the write pipeline.

**Stash pool (host, Claim 1 at 2^-64 per access + the provisional margin of 1% of n + 64):**

| Blocks n | Claim 1 bound | Pool |
|---|---|---|
| 4,096 | 1,858 (45.4%) | 1,963 |
| 25,000 | 8,395 (33.6%) | 8,709 |
| 250,000 (1M 8-byte records) | 71,571 (28.6%) | 74,135 |
| 2,500,000 | 678,463 (27.1%) | 703,527 |

**Trusted memory, 1M 8-byte records (250K blocks of 32 B):**

| Structure | Size |
|---|---|
| Position map (6.4 B per block) | 1.60 MB |
| Records (64 B per bucket) | 2.00 MB |
| Stash heads (32 B per bucket) | 1.00 MB |
| Pool (74,135 x (32 B block + 16 B links)) | 3.56 MB |
| **Total** | **8.16 MB** |
| With 20% of the buckets in HBM | 9.76 MB |

**Timing budgets, recalibrated for Z = 8** (same method and margins as before; the stash wait is 1 cycle at both sizes):

| | Derived worst (Z = 8) | Budget | Margin | (Z = 6) |
|---|---|---|---|---|
| 32 B, strict: encryption end | 267 + 179 + 191 + 1 + 44 + 187 = 869 | deadline 922 (`CT_WB` 665 + 250 + 7) | 53 | 781 |
| 32 B, arrival: work after arrival | 191 + 1 + 44 + 187 = 423 (measured 408) | `AR_WB` 465 | 42 | 335 |
| 4 KB, strict: encryption end | 267 + 307 + 2,223 + 1 + 298 + 2,219 = 5,315 | deadline 5,366 (`CT_WB` 4,220 + 250 + 896) | 51 | 4,211 |
| 4 KB, arrival: work after arrival | 2,223 + 1 + 298 + 2,219 = 4,741 (measured 3,830) | `AR_WB` 4,795 | 54 | 3,637 |

Done gaps: 32 B unchanged (+100 strict and HBM buckets, +240 arrival); 4 KB +256 for the 1,024-beat write-back (+1,600
strict and HBM buckets, +1,670 arrival). An off-package 32-byte access (PCIe-like latencies, simulation) takes
1,254-1,297 cycles, against 1,162-1,205 at Z = 6.

**New strict timing hashes:** 32 B `28bf4bb94fd40bb4` / `05eb4d24fb630266`; 4 KB `2c2bc645ff3541d3` / `6f7b946af2d5246b`.

**Other fixes in this round:**
- **Slot-address width:** it now reserves the bit for a size of N x 4096 at n = N. With lambda = 4 the bucket term
  happened to provide it; with lambda = 8 the 2^22 build would have been one bit short. The width is unchanged at 35.
- **Testbench leftovers from the removed two-client build:** `tb_ni` routed slots >= 256 to a second client and
  leased each client 256 slots. Both are now derived from N and the number of clients.
- **Test sizing:** the kernel testbench sized host memory per bucket (now per slot); the smaller-pool stash test uses
  40% of N (`+poolpct`); the position-map test's slot addresses are now as wide as the design's, so it is valid
  above 2^20 slots (it now runs at 2^22).


## Multi-channel HBM latency, and a separate write-back point for HBM buckets (`AR_WB_H`)

**Latency on the proposed mapping** (`latency/lat_multi.cfg`: stash over HBM[12:14], HBM buckets over HBM[16:23]; one
million samples per run; cycles at 299 MHz, about 0.3% below 300 MHz figures):

| | 32-byte read: avg / max | 4 KB burst: avg / max | Write ack |
|---|---|---|---|
| Earlier measurement (HBM[8], one channel) | 64 / 179 | - / 307 | 28 |
| Stash range, whole 1.5 GB / per channel | 62 / 182; 63-65 / 183-185 | 196 / 317; 191 / 282-306 | 28-29 |
| Bucket range, whole 4 GB / per channel | 62 / 183; 63-66 / 169-191 | 197 / 317; 191 / 230-315 | 27-29 |

Channels in the second switch group (20-23) behave like the first (16-19). Spreading a chain over many channels raises
the 4 KB p99 (about 290 against 220) but not the maximum. The worst cases are about 10 cycles above the earlier ones;
the strict-mode budgets still hold (32 B: about 881 against 922; 4 KB: about 5,325 against 5,366).

**The stash can finish after verification when the bucket is in HBM.** The stash opens only after the position-map
lookup, then needs two dependent HBM reads (its head, then the candidates). With a fast HBM bucket read (52 cycles) and
slow metadata, it can be ready after the bucket is verified. Simulation of that combination (32 B, arrival mode, all
buckets in HBM):

| Latencies | Worst work after arrival |
|---|---|
| Testbench defaults | 392 |
| Slow stash only, or slow position map only (191) | 392 |
| Slow position map and stash (191), bucket 52 | 471 (`AR_WB` 465 + the 7-cycle write-back lead: 1 cycle to spare) |
| Every HBM metadata read at 200 (the design worst), bucket 52 | **498** |

Each extra cycle of lookup latency adds 1 to the work, each extra cycle of stash latency 2. Off-package buckets are not
affected (PCIe's minimum latency exceeds the stash's worst readiness), nor is 4 KB (verification takes 2,223 cycles).

**Fix:** HBM buckets have their own write-back point, `AR_WB_H` (as they already had their own done point,
`AR_DONE_H`): 32 B `AR_WB_H` = 540 (498 + 42), `AR_DONE_H` = 640; 4 KB unchanged (= `AR_WB`). Off-package accesses keep
`AR_WB` = 465. The controller keeps separate maxima (`ar_max_wb`, `ar_max_wb_h`), and the regression's arrival group
now includes the adverse-latency run (`hbmadverse`) and checks it against `AR_WB_H`. Strict mode is unchanged (it does
not use the arrival budgets), and so are its timing hashes.


## Stash candidates: Z + 1 = 9, so every read moves in every waiting slot that fits

Each bucket's head now lists **9 candidates** (was 8 = Z). With Z candidates, a read could move in fewer slots than
fit (an empty bucket, a full candidate list plus overflow, and a candidate requested away), which breaks F_t <= O_t
in the stash analysis. With Z + 1, a short invariant proves that every read moves in exactly
min(free positions, slots waiting): the same counts as the analysis's model, so Claim 1 applies unchanged
(`docs/stash_chain_design.md`, "Why W = Z + 1").

- **RTL:** `stash_hbm.v` W = 9; the candidate index and count widths now derive from W (they were hard-wired to 3 bits,
  so a 9th entry would have wrapped to 0); a generate-time check fails elaboration if the head does not fit one beat
  or W < Z + 1. The head still fits one 32-byte beat (10 x 23 = 230 bits at 2^22). Each access prefetches at most one
  more candidate.
- **Tests:** `tb_stash.v` counts every read that moves in fewer slots than fit, as a failure. A directed scenario
  (`+directed`) builds the counterexample: with the previous 8 candidates it is one slot short (the negative control);
  with 9, every waiting slot that fits moves in. All stash runs, including hot traffic with overflow lists over 170
  long and a 20,000-access hot run, show zero shortfalls.
- Independent check (the analysis's simulator, Z = 8, 1M accesses each, uniform, scan and hot traffic): 0 shortfalls
  with 9 candidates, 33 to 1,301 with 8.

**32-byte budgets recalibrated for the ninth candidate.** At 32 bytes the extra candidate prefetch shows up as up to
20 cycles of stash wait in the worst-case trace (4 KB: unchanged, verification outlasts it). The derived strict worst
case became 267 + 179 + 191 + 20 + 44 + 187 = 888 (deadline 922, margin 34) and the arrival-mode bound 442 (`AR_WB` 465,
margin 23). The card has shown HBM tails about 12 cycles above the model's, so the usual margins are restored:

| 32 B | Derived worst | Budget | Margin |
|---|---|---|---|
| Strict: encryption end | 888 | deadline 942 (`CT_WB` 685 + 250 + 7), `CT_DONE` 785 | 54 |
| Arrival, off-package buckets | 442 (measured 408) | `AR_WB` 485, `AR_DONE` 725 | 43 |
| Arrival, HBM buckets, adverse latencies | 498 | `AR_WB_H` 540, `AR_DONE_H` 640 (unchanged) | 42 |

About 20 cycles more per 32-byte access (about 1.6%). **New 32-byte strict timing hashes:** `5b5383ffd8785a8c` /
`72ee425d58ea2ece` (write-back at offset 939). 4 KB budgets and timing hashes are unchanged
(`2c2bc645ff3541d3` / `6f7b946af2d5246b`).

## Z = 10 with the compact bucket layout (lambda = 8)

**Why.** With 20% of the buckets in on-package memory (HBM), the on-package total (metadata + stash + HBM buckets) is
lowest at Z = 10: 44.5% of the data, against 48.2% at Z = 8 (4 KB blocks; Z = 11 ties at 44.7%). That holds only with
**compact buckets** (exactly Z blocks each): the previous power-of-two stride stored a 40 KB bucket in 64 KB, which made
any Z between 9 and 15 cost 16 slots. Cost: each access moves and encrypts 10 blocks instead of 8 (about 20% lower
throughput at 4 KB). Z = 9 is the balanced alternative (45.6%, about half the throughput cost).

**Changes.**
- `oram_params.vh`: `ORAM_Z` 10, `POS_IN_BKT_W` 4; `BUCKET_SHIFT` removed; `BUCKET_BYTES` = Z x block (compact) and
  `SCR_AW` = position bits + beat bits (11 at 4 KB: a bucket is 1,280 beats).
- `axi_master.v`: bucket address by a constant multiply. Large buckets (1 KB blocks and up) still move one block per
  burst (blocks are block-aligned powers of two, never across 4 KB). A small bucket that straddles a 4 KB boundary now
  moves as two bursts split there (320-byte buckets: about 8% of them). Which buckets split depends only on the bucket
  index, which is public. One rule decides every WLAST.
- `flat_oram_gcm.v`, `scratch_buf.v`: bucket-beat addresses follow `SCR_AW` (they were hard-wired to 10 bits); the
  eviction queue holds 16 (was 8) and the pending flags 16 positions; the fill count is zero-extended by assignment
  (a fixed slice overflowed with 4-bit positions; lint caught it).
- `stash_hbm.v`: 11 candidates (W = Z + 1, now derived) and multi-beat heads (see `stash_chain_design.md`).
- `doma_kernel.v`: the HBM boundary is H x `BUCKET_BYTES`; host-memory buckets are rebased by that boundary **rounded
  down to 4 KB**, so every address keeps its place within its 4 KB page (rebasing by H x 320 bytes moved the
  boundaries the master split at: 63 protocol violations in the 25%-HBM test before the fix). The first host bucket
  sits up to 4 KB into the pages buffer.
- `host_doma.cpp`: `ZPOS` 10, stride Z x block, pages buffer 4 KB larger.
- Testbenches: memory sizes and address checks at the compact size; the stress run now writes a timing trace, which
  the worst-case analysis needs (with slack, only the forced stress produces a full 10-eviction access); the
  slow-acknowledgement test uses 1,200 cycles (beyond the larger completion gap).

**Timing budgets, recalibrated for Z = 10** (same method and margins as Z = 8):

| | Derived worst | Budget | Margin | (Z = 8) |
|---|---|---|---|---|
| 32 B strict CT_WB (deadline CT_WB + 250 + 9) | 957 | 752 (deadline 1,011) | 54 | 685 |
| 32 B CT_DONE | write-back done at most 36 after CT_WB | 854 | 66 | 785 |
| 4 KB strict CT_WB (deadline CT_WB + 250 + 9 x 128) | 6,419 | 5,070 (deadline 6,472) | 53 | 4,220 |
| 4 KB CT_DONE | at most 1,795 after CT_WB (backpressure) | 7,070 | 205 | 5,820 |
| 32 B AR_WB / AR_DONE | 511 (measured 486) | 554 / 796 | 43 | 485 / 725 |
| 32 B AR_WB_H / AR_DONE_H | measured 556 (adverse) | 598 / 700 | 42 | 540 / 640 |
| 4 KB AR_WB / AR_DONE | 5,845 (measured 4,668) | 5,899 / 7,825 | 54 | 4,795 / 6,465 |
| 4 KB AR_WB_H / AR_DONE_H | measured 4,668 (adverse) | 5,899 / 7,755 | | 4,795 / 6,395 |

The 64-256-byte budgets are still the Z = 8 values and must be recalibrated before those sizes are used (too small
causes an overrun and fail-stop, never a leak).

**Verification.** Lint clean (no out-of-range selects) at 32 B and 4 KB, also with two-beat heads forced. Final full
regressions, every simulation rebuilt with the final budgets: **34/34 at 32 B and
34/34 at 4 KB**. Timing hashes (secure build): 32 B `fc899eb5aae696a2` / `c9fbaacc72ad716a` (write-back at offset
1,006); 4 KB `05a12e803b18dc9f` / `e99b1b2a7b33c7bb` (write-back at offset 5,324). Every bucket is read at offset 270.

## Timing closure at 300 MHz (Z = 10 builds)

The first Z = 10 bitstreams closed only at 165 MHz (32 B) and 163 MHz (4 KB): kernel-clock WNS -2.71 / -2.79 ns at
300 MHz; every platform clock and all hold timing met. `worst_paths.tcl` showed two problem areas:

- **Kernel (both sizes):** paths from `nblk_q` (22-29 logic levels) into the AXI master and the HBM interconnect.
  In one cycle: clamp the block count, count the buckets, clamp the HBM bucket count, multiply by the bucket size
  (`hb_lim`), compare with the bucket address, and choose which memory port's handshake to use. Fix: the sizes
  derived from the boot arguments (`nblk_eff`, `pool_eff`, `nb_full`, `hbm_eff`, `hb_lim`) are registered; they are
  constant during a run, and `K_BOOT` waits 7 cycles for them to settle before booting the core.
- **Stash (4 KB build, 2,362 endpoints):** the window popcounts (11 candidates) chose which metadata writes to emit,
  which were then scattered into the 16 x 96-bit queue at variable positions, all in one cycle. Fixes: the windows'
  valid flags are always prefixes, so "full" is the top flag and the next free slot a one-hot (a simulation check
  stops the run if a window is ever not a prefix); each cycle's metadata writes are staged in registers and join the
  queue the next cycle (the drain waits for the stage to empty).

Both are cycle-exact on the bus: the full regressions pass at 32 B and 4 KB with **the same timing hashes as before**
(32 B `fc899eb5aae696a2` / `c9fbaacc72ad716a`; 4 KB `05a12e803b18dc9f` / `e99b1b2a7b33c7bb`), so the calibrated
budgets stand. `worst_paths.tcl` now lists every failing group (it stopped at 30), and `check_timing.sh` reads the
final post-route report and shows each clock's slack.

**Second round.** With those fixes the builds reached 285 MHz (32 B) and 278 MHz (4 KB); the complete report then
listed only three small groups (worst -0.19 ns at 300 MHz):

- **Stash allocation (-0.19 ns):** `fresh < pool size`, a 23-bit comparison, sat in front of the allocation choice
  and the staged metadata writes. It is now a register flag kept in step at reset, at setup and on each fresh
  allocation (a simulation check stops the run if it is ever out of step).
- **AXI master next burst address (-0.17 ns):** Vivado had mapped the compact-address multiply into a DSP block,
  whose unregistered output is slow. It is now an explicit shift-and-add over Z's set bits (Z = 10: x8 + x2, one
  adder), marked `use_dsp = "no"`.
- **Kernel state from the command address (-0.007 ns):** left as is (within placement variation).

Both are cycle-exact: full regressions 44/44 at 32 B and at 4 KB, with the same timing hashes as above.

## Throughput, step 1: command prefetch and a 20% end-of-access margin

- **Command prefetch (`doma_kernel.v`):** while DOMA serves command k (`K_WAIT`), the kernel reads command k+1's
  header from the command buffer into its own registers; `K_NEXT` then issues the request directly (falling back to
  the normal read when no prefetch is there). Response writes are posted: their acknowledgements are counted and all
  awaited once, before the summary. The command and response buffers are the client's own, in on-card memory, so
  nothing changes on the bus. A prefetched header is cleared at every run start.
- **End-of-access gate (32 B):** `AR_DONE_B1` 796 -> 692 (write-back + PCIe acknowledgement ~115 cycles measured,
  + 20%), `AR_DONE_H_B1` 700 -> 644 (HBM acknowledgement 28, + 20%). The 4 KB gates are unchanged until the 10-burst
  write-back acknowledgement is measured on the card.

Simulation at PCIe-like latencies, cycles per command (32 B): 1,408 -> 1,364 (prefetch) -> 1,260 (gate), -10.5%; at
100% HBM 1,228 -> 1,128. Full regressions 44/44 at 32 B and at 4 KB, timing hashes unchanged.

**Third round (4 KB build at 277 MHz, worst -0.281 ns).** The remaining groups were in the stash and the kernel:

- **Stash read address (-0.281 ns):** the issue logic chose the next read by priority, selected a window entry's pool
  index from 11, and computed its address (base + index x 4 KB) in one cycle. Every read address is now precomputed in a
  register (heads, metadata, data, free list, chain head); each window entry gets a preparation cycle that registers
  its two addresses and its "is this the requested block?" check; the chain-head read waits a cycle after the head lands.
- **Staging RAM writes (-0.102 ns):** the landing read's tag was selected from the 32-entry tag queue every cycle; the
  queue's head is now kept in registers (a simulation check stops the run if it ever differs).
- **Kernel state (-0.068 ns):** the core's key-range verdict is registered and the kernel decides a cycle later.

Cycle-exact on the bus: full regressions 44/44 at 32 B and 4 KB with the same timing hashes, worst cases and arrival
maxima (32 B 486 / 556, 4 KB 4,668): the stash's extra preparation cycles fit within existing slack.

## Throughput, step 2: end the access at the write-back handoff (arrival mode)

In arrival-relative scheduling an access now ends (result released, next request accepted) once its write-back data
has been handed to the AXI master, at the fixed time `t_arr + AR_REL`, instead of after every write acknowledgement
(`AR_DONE`). The acknowledgements drain during the next access's lookup; every later read stays ordered after them by
safeguards the design already had: `axi_master` holds a read until all earlier writes are acknowledged,
`pos_map_hbm` and `bucket_rec_hbm` never let a read overtake a write, and the stash opens the next access only once
quiet (`st_open_req`, otherwise unchanged). The position map is updated before the write-back, so no forwarding is
needed. Strict mode is unchanged (bit-identical timing hashes).

| Budget | 32 B | 4 KB |
|---|---|---|
| `AR_REL` (host bucket) | 590 (AR_WB + 36) | 7,459 (AR_WB + 1,560) |
| `AR_REL_H` (HBM bucket) | 634 (AR_WB_H + 36) | 7,459 |

Simulation at PCIe-like latencies, cycles per command (32 B): 1,408 originally -> 1,260 (step 1) -> 1,158 (step 2),
-17.8% in all (~+22% throughput); at 100% HBM 1,228 -> 1,118.

## 40-bit bucket addresses (4 KB blocks at N = 1M)

`AXI_ADDR_W` was 32: the core's bucket byte offsets wrapped at 4 GB. At 4 KB blocks and N = 1M the buckets take
5 GiB (131,072 x 40 KiB), so every bucket past 4 GB was written over the buckets at the start of the buffer; the next
read of one failed authentication and DOMA halted (error 0x8) on the card. It is now 40 bits (1 TB); the kernel's
HBM/host split and rebase follow it. `sim/tb_addr_wide.v` (unit step) issues full reads and write-backs of chosen
buckets at N = 1M, including bucket 104,857, which straddles 4 GB, and checks every burst: exact start, contiguous,
no 4 KB page crossed. It fails with 32 bits (bursts land at 0x0, 0x1000, ...) and passes with 40 (48 bursts above
4 GB at 4 KB). The 32 B build never reached 4 GB (N = 4M uses 168 MB).

Capacity at 4 KB: the current layout (`doma_big.cfg`) gives HBM buckets 4 GiB (HBM[16:23]); at N = 1M that is
exactly 80% of the buckets, so keep scans at or below 70%. N = 10M needs ~48 GiB of host memory for the card.

## Uniform commands: GET and PUT take the same time

The front end starts an access only when its request is ready, and a PUT's data had to be fetched first while a
GET's result was copied out afterwards: the gap between accesses, visible on the bus, showed the GET/PUT sequence
(not keys or blocks). Now every command is handled alike (`doma_kernel.v`, `secure_oram_top #(.UNIFORM_FILL(1))`):

- command k+1's data slot (a PUT's data, or a GET's unused slot) is prefetched during command k, after its header;
- every command streams its slot into DOMA (`K_DAT_P`, `K_DAT_S`; GET data ignored, `UNIFORM_FILL`);
- every command writes its response data slot (a PUT with all byte strobes off: nothing changes).

`tb_doma_kernel.v +put_pct=P` keeps the same keys for every P (operations and keys on their own random stream) and
hashes the bucket port's timing. The regression's arrival step runs the same 300 keys as all GETs and all PUTs, in
arrival and strict mode: the hashes and cycle counts must be identical. Before the change (same keys): 345,827 /
348,857 / 357,543 cycles at 0 / 30 / 100% PUTs, three hashes; after: 346,605 cycles and one hash for every mix.
Cost: +3 cycles per command at 32 B (and PUTs no longer wait for their data: a 50/50 mix is ~1.5% faster in
simulation); at 4 KB the minimum per command rises from 9,416 to 9,546 cycles.

The slow-acknowledgement test (`wlat_slow`) uses 1,500 cycles at 32 B and 2,500 at 4 KB (acknowledgements after the
next read, so `axi_master` must hold it); the host bucket model buffers 8,192 write beats (`WF_DEPTH`, default 1,024).

**Vivado declaration order.** The first build with uniform commands failed in Vivado synthesis: `'K_DAT_S' is already
declared`. The data mux was written inside the core instance's port connection, above the state constants; Vivado
treats an unknown name in a port connection as an implicit wire and then rejects the later `localparam` of that name
(a later `reg` it accepts). Verilator accepts both, so lint and every simulation passed. The mux is now a wire
`c_wdata` declared before the instance and assigned after the declarations (identical behaviour: same per-command
cycles and GET/PUT hashes). The lint step now runs `iverilog -Wimplicit` and fails if a constant is used before its
declaration; it flags exactly `K_DAT_S` on the broken kernel and nothing on the fixed one or on earlier builds.

**The slot buffer as a block RAM.** `pdbuf` (1 entry at 32 B, 128 x 256 bits at 4 KB) was written inside the
kernel's state machine and read at two addresses (`pdbuf[0]`, `pdbuf[pcnt + 1]`): Vivado would build it from ~32,000
flip-flops and a 128-to-1, 256-bit multiplexer at 4 KB, a timing risk. It is now a simple dual-port RAM in its own
clocked block without reset: one write port (the prefetch) and one registered read port whose address the state
chooses (0 in `K_DAT_P`, the next beat in `K_DAT_S`), the standard pattern Vivado maps to block RAM. Cycle-identical:
same per-command cycles and GET/PUT hashes at 32 B (1,144/1,185; 7621426a..., 212379596b...) and 4 KB
(9,546/9,587; dce92a27..., a9e4fdfe...); kernel and arrival steps 13/13 and 7/7 at both sizes.

## Z = 8, lambda = 6 (comparison setting)

For the comparison with BOLT the bucket has BOLT's page capacity, **Z = 8** slots, and **lambda = 6** blocks on
average: at Z = 8 that gives the smallest stash bound (Claim 1, N = 1M: 22.8% of N, against 27.6% at lambda = 8).
The bytes per access do not depend on lambda (one bucket of Z blocks: 256 B at 32-byte blocks).

**lambda need not be a power of two.** It entered three divisions that were shifts at lambda = 8: the bucket count
in the kernel (`nb_full`) and in the controller (`nb_q`) are now computed bit-serially (about 26 cycles, only
when n changes; the kernel's boot and the controller's format wait for them: `kdv_idle`, `nb_ok`), and the boot
layout keeps a running (bucket, position) pair instead of `k / C` and `k mod C`. The host sets `LAMBDA = 6`,
`ZPOS = 8`; `POS_IN_BKT_W` is 3.

**Budgets (`oram_params.vh`), recalibrated with the same rules and margins as at Z = 10:**

| | 32 B | 4 KB |
|---|---|---|
| derived worst (strict) | 267 + 179 + 191 + 1 + 44 + 187 = 869 | 267 + 307 + 2,223 + 1 + 298 + 2,219 = 5,315 |
| CT_WB / CT_DONE | 666 / 766 (deadline 923) | 4,223 / 5,967 (deadline 5,369) |
| AR_WB (derived, measured) | 466 (423, 404) | 4,795 (4,741, 3,826) |
| AR_WB_H (adverse measured) | 538 (496) | 4,795 (3,826) |
| AR_REL / AR_REL_H | 502 / 574 | 6,043 / 6,043 |
| AR_DONE / AR_DONE_H | 614 / 582 | 6,415 / 6,345 |

Simulation at PCIe-like latencies, cycles per command: 32 B 1,054/1,095 (Z = 10: 1,144/1,185), 4 KB 7,872/7,913
(Z = 10: 9,546/9,587). Timing hashes: 32 B 7fc5e92e6c646952 / e6d3813244dbc5da, 4 KB 51c6213b1147687d /
c537d46b5491598f.

**Two testbench assumptions that only held when lambda divides N:** the directed stash scenario emptied a bucket
with N / B accesses (it now walks every block of it), and the self-test harness forced target buckets with fixed
numbers (`seq_idx + 85`, 450 ...) that wrapped into range at 64 buckets but pointed past the last of 86 (DOMA
halted on the unformatted bucket, as it should); they are now reduced modulo `ORAM_B`, the old values whenever the
bucket count is a power of two.

**4 KB at N = 1M:** 174,763 buckets x 32 KB = 5.3 GiB of host memory at 0% HBM; `doma_big.cfg` gives HBM buckets
4 GiB (about 75% of the buckets); `doma_big8.cfg` (`CFG=doma_big8.cfg`) is the same layout with the HBM buckets on `HBM[16:31]`, 8 GiB, for experiments up to 100% (banks 24-31 are otherwise unused).

## Phase trace (TRACE=1)

A build option that times every major phase of every ORAM access on the card. `TRACE=1 bash build.sh` adds
`` `define ORAM_PHASE_TRACE `` to `rtl/oram_build_cfg.vh`; without it the RTL is exactly the untraced design
(preprocessed `flat_oram_gcm.v`, `secure_oram_top.v` and `doma_kernel.v` are line-for-line identical to the version
before the option), so keep the untraced bitstream for performance numbers and build the traced one in its own folder.
The traced variant's bucket-port timing hashes are identical to the untraced design's: the instrumentation observes, it
does not change when DOMA touches memory.

**What it adds.** The core exports `phase_ent[10:0]`, a one-cycle pulse when its state machine enters a phase (computed
from its own state names). The kernel records, per command, on a counter that equals the command's latency counter
(cycles since the request) and keeps counting until the record is written:

* in every response header, bytes 16-31: first bucket read request, last bucket read beat, first and last write-back
  beat (32 bits each);
* when the host sets bit 31 of `size`: a 32-byte trace record per command at `resp + hr + n*BLOCK + i*32` (after the
  launch's response data), 16 timestamps of 16 bits (saturating at 65535): 0 lookup, 1 read gate, 2 bucket read request,
  3 first bucket beat, 4 last bucket beat, 5 crypto (the decryption pass), 6 block operation, 7 eviction, 8 re-encryption,
  9 write-back gate state (not entered in arrival mode: the wait is inside the write-back state), 10 write-back state,
  11 first write-back beat, 12 last write-back beat, 13 release gate, 14 result, 15 idle.

**Hosts.** `host_ycsb.cpp` and `host_phases.cpp` with `DOMA_PHASE_TRACE=1` allocate the trace region, set bit 31 (only on
launches with commands: an init launch must pass size 0 exactly, or the kernel treats it as a command launch and, on a
kernel booted by an earlier run, reports error 0x20, buffers differ from the init launch), check
every record's order and report 12 phases that add up to the measured E2E: handoff (0-s0), lookup (s0-s1), read gate
(s1-s2), bucket read (s2-s4), decryption/verification after the last beat (s4-s6), block operation (s6-s7), eviction
(s7-s8), re-encryption (s8-s10), write-back wait (s10-s11), bucket write (s11-s12), release gate (s12-s14), result
(s14-done), plus how much of the decryption overlaps the bucket read (s4 - s5). Out-of-order records fail the run.
Without `DOMA_PHASE_TRACE`, both hosts still print the four bucket-port phases from the header; on an untraced bitstream
they report that no phases are available.

**Checks.** The kernel's simulation-only attribution check confirms, for every command of the kernel tests, exactly one
bucket read and one write-back (Z x beats each) within the command. The mock-XRT runs (`sim/xrt_mock`, `TRACE=1 bash
build_model.sh`) verify every record against the RTL, that the phases add up to E2E, and that the records stay inside
the response buffer. In the mock, the block operation varies by workload and the write-back wait absorbs exactly that
variation, so the write-back starts at its scheduled time.

**Build** (in its own folder, next to the untraced build):
```
cp -r ~/pkg/fpga_zcu208 ~/doma_trace_b128 && cd ~/doma_trace_b128/vitis
TRACE=1 NMAX=1048576 SCHED=arrival CFG=doma_big.cfg TARGET=hw nohup bash build.sh > build.log 2>&1 &
```

**YCSB.** `vitis/host_ycsb.cpp` (gem5's `oram_ycsb.c` generator against the card), `vitis/run_ycsb.sh`,
`vitis/doma_big_hbm.cfg`, `sim/xrt_mock/` and `docs/YCSB_CARD_RUNBOOK.md` are part of the package, so their DOMA
constants stay in step with the RTL (`host_ycsb.cpp` has lambda = 6, Z = 8).

## Baseline (PLAIN=1)

The non-oblivious, non-private baseline used to report slowdown (a design's time per query divided by the baseline's,
same workload, same clock), following BOLT's description of its FPGA baseline: a key-value store using only HBM.
`PLAIN=1 bash build.sh` defines `ORAM_PLAIN`, which makes `doma_kernel` instantiate `rtl/plain_oram_top.v` instead of
DOMA's core under the same instance name and ports (its header is generated from `secure_oram_top.v`'s). The
kernel's command, data-slot and response path is unchanged, so per-command overhead is the same as DOMA's.

**What it does.** Record k lives at bucket-port address k * BLOCK. A request takes the command's data slot (BEATS
beats, as the kernel streams it), then a GET reads the record's slot and returns its beats, a PUT writes the record's
bytes with the kernel's byte strobes (packed neighbours untouched). A PUT completes when its data is handed off; a
read waits until every earlier write is acknowledged. No ORAM, no encryption or integrity, no padding. Records are
addressed by index, like DOMA and Tiny ORAM; BOLT, a map with arbitrary keys, keeps its own baseline.

**Running it.** The host programs are unchanged: run them with `DOMA_HBM_PCT=75 DOMA_POOL=64`. At 75% the HBM page
buffer is (N/8 buckets) x Z x BLOCK = exactly N x BLOCK (Z = 8, lambda = 6; N a multiple of 8), and the kernel routes
every record address below that limit to HBM; `DOMA_POOL=64` shrinks the unused stash buffer. 8- and 16-byte values use
the 32-byte build with `DOMA_PACK=1`, as DOMA does.

**Clocks.** One build per block size, closed at 300 MHz. For Tiny ORAM (230 MHz), the same bitstream with its
recorded kernel clock lowered (`xclbinutil --dump-section CLOCK_FREQ_TOPOLOGY:JSON:clk.json`, edit, `--replace-section`),
so both designs are normalized by identical hardware; check the clock a run reports (device cycles / wall time).

**Checks.** With PLAIN off, the preprocessed `doma_kernel.v` is identical to the version before the option (default
and TRACE builds, 32 B and 4 KB). In the mock (`PLAIN=1 bash build_model.sh`): 300 mixed accesses on packed 8-byte
records at 32 B and 120 at 4 KB, every GET correct, no access outside a buffer.

## Block sizes 64 B to 2 KB, and 2M records

**Budgets per size.** `oram_params.vh` selects every timing budget explicitly for the eight supported block sizes (BEATS
1, 2, 4, ..., 128 = 32 B .. 4 KB); any other size stops the build (`flat_oram_gcm.v` instantiates a missing module,
`ORAM_BLOCK_BEATS_has_no_timing_budgets`). 32 B and 4 KB are calibrated (above). **64 B to 2 KB ship with placeholders,
the 4 KB budgets** (safe, but every access padded to the 4 KB access time): calibrate them before building those sizes.

**Calibrating** (needs Verilator 5, Icarus Verilog, python3; a laptop: about 2-3 hours):

    bash sim/calibrate_sizes.sh 2>&1 | tee calibrate_sizes.log

For every size (32 B..4 KB) it sets the arrival budgets to the 4 KB placeholders, then runs: worst (the bound on the
work after the bucket's LAST beat, from a gap-free trace with fixed metadata latencies: `derived after arrival` in
build/worst_case.txt), combined (HBM buckets, every metadata read at 200 cycles, a full stash window), hostwait (host
buckets at 240 cycles, below the U55C's fastest observed read, with slow metadata: no access may wait for the stash,
or do more work after the last beat than derived) and arrival. `sim/budgets.py` then writes AR_WB = max(derived,
measured host) + 54; AR_WB_H = max(derived + 32 + 54, HBM worst of the adverse and combined runs + 42 + 32); the host
release and acknowledgement allowances as before; AR_REL_H = AR_WB_H + max(36, 5% of the write-back). Strict budgets
of 32 B and 4 KB are unchanged; 64 B..2 KB use the strict derivation with the 4 KB-burst HBM worst (307). At 4 KB the
derived bound must be 3,845. Then the full regression at every size. The stimulus is deterministic (xorshift32, no
$random), so every Verilator version gives the same budgets and hashes. `SIZES=` and `REG=` restrict the sizes.

**2M records.** Every size from 64 B to 2 KB fits 2,097,152 records at 20% HBM in the default large layout
(`doma_big.cfg`) and the card's 8 GB of host memory (2 KB: 1.07 GiB of HBM buckets, 0.94 GiB stash, 4.27 GiB in host
memory): build with `NMAX=2097152 CFG=doma_big.cfg`. 4 KB at 2M needs a 1.88 GiB stash (more than HBM[12:14]) and
8.53 GiB in host memory: build with `NMAX=2097152 CFG=doma_big2m.cfg` (stash on HBM[12:15], 2 GiB; buckets on
HBM[16:31], 8 GiB), and run it with the card's host memory set to 16 GB. 32 B needs no new build (NMAX 4,194,304).

## Arrival budgets counted from the last beat (revision of the calibration)

The arrival-mode budgets count from the bucket's last beat, so their derivation now does too: the timing trace records
the last beat (t_ln, oram_timing_monitor.v), and worst_case.py reports "derived after arrival" = verification left at the
last beat + stash wait + worst (B+C+D) + Ec, from the worst group's gap-free trace with fixed metadata latencies (the old
derivation counted verification from position 0, so it also counted positions 1..7 arriving: 7 x BEATS cycles). Every
memory-dependent effect is measured instead: `combined` (HBM buckets, every metadata read at 200 cycles, a full stash
window: the stash can finish after verification at small blocks) and `hostwait` (host buckets at 240 cycles, below the
U55C's lowest observed read, 815 ns: no access may wait for the stash or exceed the derived bound). The testbenches draw
no $random: xorshift32 throughout, so every Verilator version produces the same stimulus and budgets.

Rules (sim/budgets.py): AR_WB = max(derived, measured host) + 54; AR_WB_H = max(derived + 32 + 54, measured HBM + 42 + 32)
(the stash margin only where the stash can be late); AR_REL keeps its allowance; AR_REL_H = AR_WB_H + max(36, 5% of the
hand-off); acknowledgement allowances and strict budgets unchanged; PM_LAT unchanged. `bash sim/calibrate_sizes.sh`
calibrates every size (placeholders first, then worst, combined, hostwait, arrival), checks that the 4 KB derived bound
is 3,845, writes the budgets and runs the full regression; SIZES= and REG= select sizes.

## Lease tokens: never returned to the management caller

The management port may be driven by the untrusted host, so `lease_token_table.v` never returns a token on it:
GRANT and TRANSFER put the new token only on the owning client's lane (`client_token_out`, lane c = client c), QUERY
reports only whether the lease exists, and REVOKE needs both the owner ID and the lease's token (as RENEW and TRANSFER
already did), so the host can no longer revoke another client's lease by naming its ID. The kernel's boot sequence and
the self-test read their tokens from their client lanes. `sim/tb_lease.v` (units group) drives the management port as
the host would and checks each point; against the previous module it fails exactly those checks. Timing is unchanged:
the regression's timing hashes are identical before and after.

## Boot touch pass: independent uniform buckets before any request

(Through v11a. v11b removes the pass: the boot places every block at an independent uniform bucket itself, in a
fixed time; see "Random placement at boot and a fixed-time boot (v11b)".)

The boot layout places exactly C slots per bucket (a keyed bijection, `slot_perm`). A slot's first access reads that
boot bucket, so a run of first accesses reads buckets sampled without replacement (no bucket more than C times) and
can be told apart from repeated accesses, and the stash bound's independence assumption would not hold. So right after
the lease, before it accepts any host command, the kernel GETs every slot once in slot order (`K_TCH`, `K_TCH_D`,
`K_TCH_W` in `doma_kernel.v`). Each access remaps its block to an independent uniform bucket, so afterwards every block
sits where the security argument and the stash bound assume. The pass runs once per DOMA boot (it is redone on a
re-boot), cannot be skipped by the host, and its own fixed-order accesses reveal only the boot layout, which no block
occupies afterwards. The baseline build (`PLAIN=1`) has no ORAM and skips it. The stash reaches its steady state during
the pass, so a pool smaller than the bound now fails at boot (the regression's 600-entry pool for 4,096 blocks halts
there) instead of later. Cost: the first launch takes N more accesses (about 3.5 s at 32 B and 24 s at 4 KB for 1M
slots, 47 s at 4 KB for 2M). The host programs wait without a time limit. Timing of host commands is unchanged: the
regression's timing hashes are identical.

## Stash pool: n a multiple of lambda, Binomial(n, 1/B), pool = ceil(bound) + 1

The stash analysis takes B = n / lambda buckets and per-bucket counts Binomial(n, 1/B). That is proven in every phase
only when lambda divides n: the untouched boot slots in a bucket are hypergeometric, <=cx Binomial(n - r, 1/B), and with
the independent Binomial(r, 1/B) of the r slots touched so far they give Binomial(n, 1/B). With a partial last bucket,
full buckets hold lambda/n > 1/B of the boot slots and that chain breaks. So the host programs round n up to a multiple
of lambda (at most lambda - 1 extra blocks, never requested; printed when it happens). The kernel clamps n to its
build's maximum, which is a power of two: run with DOMA_NMAX=<that maximum> to make a rounding past it an error.

`stash_xO()` uses the Binomial(n, 1/B) probabilities, so the provisioned pool is the paper's number:
pool = ceil(x_R + x_O) + 1 (never more than n; DOMA_POOL overrides). The provisional "1% of n + 64" margin is gone.
At lambda = 6, Z = 8, gamma = 2^-64: n = 4,096 -> 4,098: bound 1,556.1, pool 1,558; 250,000 -> 250,002: 59,207.1,
59,209; 1,048,576 -> 1,048,578: 238,519.2, 238,521; 1,000,000 -> 1,000,002 and 2,000,000 -> 2,000,004 need no other
change. The regression's pool test runs a 4,096-block build at n = 4,092 with the host's 1,556 entries.

## Lambda 7 (Z = 8): build setting, host check, budgets pending measurement

`LAMBDA=7 bash build.sh` builds lambda = 7 (`ORAM_C`; default 6). The kernel reports lambda in its summary's byte 1
when it is not 6 (a lambda = 6 build keeps the constant 0 it always had), and the host programs take `DOMA_LAMBDA`
(default 6) and stop right after the init launch, before any other check, if it differs: "set DOMA_LAMBDA=7". The
regression takes `ORAM_LAMBDA=7`; its pool test then runs n = 4,095 (bound 1,678.8, pool 1,680). Memory: at 4 KB the
lambda = 7 stash is 967 MiB at 1M records and 1,912 MiB at 2M, within doma_big's 1.5 GiB and doma_big2m's 2 GiB.

Padding at lambda = 7 (32 B): the derivation and the directed cases are unchanged (derived 416 after the last beat,
combined 583, hostwait 416 <= 416), but back-to-back accesses leave more stash writes draining into the next access,
and the kernel's slow-metadata run (hbmadverse) measures 714 cycles of work after an HBM bucket arrives (lambda 6: 536)
against AR_WB_H = 657. The combined case does not reproduce that drain. `sim/measure_lambda.sh` measures it at every
size (all arrival budgets of the size raised by 5,000 cycles, arrival group at the given lambda); the lambda = 7 budgets
will take the larger of the combined case and this measurement, with the same margins as today.

### Lambda 7 budgets (measured, all sizes)

`sim/measure_lambda.sh` at lambda = 7 (all arrival budgets of the size raised by 5,000 cycles), worst work after the last
beat, host / HBM buckets: 32 B 412 / 714, 64 B 439 / 726, 128 B 493 / 750, 256 B 601 / 798, 512 B 817 / 817,
1 KB 1,242 / 1,294, 2 KB 2,106 / 2,126, 4 KB 3,834 / 3,834. Host buckets stay within the lambda = 6 derived bound at every
size, so AR_WB / AR_REL are unchanged. HBM buckets: AR_WB_H(7) = max(AR_WB_H(6), measured + 74): 788, 800, 824, 872 for
32-256 B (+131, +126, +116, +82), unchanged from 512 B up; AR_REL_H and AR_DONE_H move by the same amounts. They are the
`ORAM_AR_*_H_L7_B*` defines, selected by `ORAM_C == 7`; lambda = 6 selects exactly the previous values. At 32 B the
lambda = 7 arrival group then passes (HBM 714 <= 788, host 412 <= 470). Consequence: at lambda = 7 with small blocks, HBM
buckets wait for the stash, so placing buckets in HBM no longer pays (32 B, 50% HBM vs 0%: 134,200 vs 128,368 cycles;
lambda 6: 127,126 vs 128,368); the regression reports that comparison at lambda 7 instead of checking it. The arrival
group now checks every size against its own budgets (it used to check only 32 B and 4 KB).

## Halt cause in the summary (diagnosing the boot halt on the card)

Every lambda = 6 and lambda = 7 bitstream with the boot touch pass halts during the boot launch on the card (error
0x8), at any n and any share of HBM buckets, while a faithful simulation of the card's configuration (64 B, NMAX =
2^21, PCIe-like latencies) passes at realistic metadata latencies. To locate it, a halt now reports its cause with it:
0x8 halted, plus 0x100 timing overrun, 0x200 integrity failure, 0x400 stash overflow (`HALT_BITS` in doma_kernel.v);
a boot launch that halts reports in "completed" how many boot-pass accesses it finished. The host programs print the
boot launch as `boot: <cycles> device cycles, errors 0x... (halted after N boot-pass accesses: <cause>)`. The
regression's undersized-pool and 600-cycle PCIe tests now check the specific causes (0x408, 0x108). The kernel
testbench's host-memory model no longer overflows 32 bits at a 2^21-slot build (capped at 2^20 words above 4,096
slots), so the card's configuration can be simulated (`-DORAM_N=2097152`, runs up to 4,096 slots).

The controller also latches a halt record at the first error (`dbg_halt_info`, through secure_oram_top to the
kernel): the bucket, the controller state, whether the bucket is in HBM, the position-map / bucket-record / stash
units' error flags (these errors are otherwise reported as a timing overrun), and the access cycle. A halted launch
reports it in its summary in place of the latency min/max, and the host programs print it as `halt record: state N
(S_...), access cycle C, bucket B (HBM|host), memory-unit errors: ...`. In the card-like simulation at 200-cycle
metadata it reads state 2 (S_RD_GATE), access cycle 312, bucket 131 (host), no unit errors, after 35 boot-pass
accesses: exactly the simulator's own halt message.

### The boot halt: cause and fix

The halt record on the card (64 B, lambda = 6): every boot halts at the FIRST boot-pass access, a timing overrun at
the read gate (S_RD_GATE): the first position-map lookup took 2,426 cycles (n = 1,024) and 1,120 cycles (n = 100,000)
against CT_RD = 266, with no memory-unit error. Lookups normally take about 72 cycles on the card. Every boot write
was acknowledged before the first access (boot_drain), but the HBM controllers acknowledge a write when they queue
it, so the first read after boot can wait microseconds behind the queued writes. Host commands never met it (the first
one came milliseconds after boot); the boot pass starts at once. The simulation's memory model has no such queues.
Fix: the controller waits a fixed BOOT_SETTLE = 2^18 cycles (~0.9 ms; `ORAM_BOOT_SETTLE`) after the boot writes are
acknowledged before it accepts the first access, and the boot pass leaves a fixed 256-cycle gap between its accesses
(about the spacing host commands have). Both are constant, so they reveal nothing. In simulation the card-like boot
then takes 1,175,125 + 262,144 + 1,026 x 256 = 1,699,925 cycles, as designed; lint, kernel and arrival groups pass.

## Stash fix: the chain step after the head's successor is remapped (v10)

YCSB workload E at lambda 7 halted on the card with a stash overflow (0x408) after about 2.08M commands, with the pool
correctly sized. The stash unit's own test (`tb_stash.v`, an exact reference model) reproduces the cause in long runs,
at both lambdas: with skewed targets it failed at 31,827 accesses (lambda 6) and 60,440 (lambda 7), with same-bucket
targets at 90,745, with the default pool at 158,922 (peak occupancy 118 of 512: not a capacity problem; the regression's
runs were 2,000-6,000 accesses). Cause: when the requested block sat directly behind its bucket's chain head and was
remapped away, the commit's chain step still used the head's next as read at open (`cs_ni`), so it moved the head into
the window and made the REMOVED block the chain's new head, leaving the real successor's prev pointing at the moved head.
Once that entry was evicted and freed, unlinking the successor wrote into the freed entry's record and corrupted the
free list: wrong allocations, entries handed out twice, and, on the card after millions of accesses, an apparently
empty pool. Fix (`stash_hbm.v`, the remap's unlink): if the block leaving b's chain is `cs_i`'s next, the chain step's
next becomes the block after it. `cs_n*` has always landed by then (`ready` needs `pre_done`). With the fix, seven
300,000-access configurations pass at lambda 7 and the failing ones at lambda 6; the regression now runs three long
stash tests (150,000-200,000 accesses). Every bitstream built before v10 carries the bug; runs that reported all
responses correct are unaffected. After any halt, load another bitstream before the next run: an init launch does not
yet reset the kernel's bucket-port state that a halt can leave behind.

## host_doma: 1M requests at every value size (v10b, host only)

`host_doma` puts a run's requests and their values in the command and response buffers (HBM[6] and HBM[7], 512 MiB
each). When they fit, the run is one launch, as before (1M requests up to 256-byte blocks, or any size at 20,000).
Otherwise it runs batches of the largest count that keeps each buffer below 448 MiB (1M requests: 2 launches at
512 B, 3 at 1 KB, 5 at 2 KB, 9 at 4 KB): each batch is staged before its timer starts, the reported time is the sum
of the batches' launch + wait, the device summary is combined (cycles and completions summed, latency min and max
over all), every response is checked against the same reference, and a batch that reports an error ends the run.
A run prints `batches: <k> launches of up to <n> commands` when it splits. `DOMA_BATCH=<n>` sets the batch (testing).
Checked on the mock XRT: 600 requests as one launch and as five batches of 128 give the same requests, latencies
and verdicts, with device totals within 0.08%.

## Regression: retry a Verilator crash (v10c)

Verilator's own multithreading (`-j 0`) occasionally aborts with "Internal Error: attempted to destroy locked Thread
Pool" (seen building `pmh` and `early`). `run_verilator.sh` now retries a build up to three times when, and only
when, its log shows a Verilator internal error; any other build failure still stops the group. With v10's RTL,
every check passes at all eight sizes for lambda 6 and 7 (single-threaded reruns of the crashed builds included).

## Rejected requests make a dummy access (v10d)

A rejected request used to be answered at once, with no bucket access, so the memory bus and the response time showed
that it was rejected. Now every rejection makes a dummy access in its place, a GET of slot 0, whose bucket is uniformly
random and re-randomized like any slot's:
* secure_oram_top.v: a request that violates its client's lease is served as a dummy below the lease check: its write
  beats are taken as the request's would be, its returned data is zeroed (cdmy), and access_violation still flags it
  (the lock-out counter is unchanged).
* doma_kernel.v: a command the kernel rejects itself (unknown opcode 0x2, record range outside the block 0x40, key
  outside the ORAM 0x4) issues the dummy GET under the kernel's own lease. A rejected command streams its data slot,
  waits for the access, writes its data slot (zeros for a GET; a PUT's slot stays untouched, as an admitted PUT's
  does, since PUT data-slot writes carry no strobes) and returns its status; it is not counted as completed.
Tests: tb_doma_kernel checks that every command, rejected or not, makes exactly one DOMA access, and the rejected
command's data slot; tb_ni +viol1 (in the ni group) checks that a request outside the client's lease is flagged and
takes the same time and bucket traffic as an admitted one (1,065 cycles, 8/8 beats at 32 B) and returns zeros; against
the previous top it made no bucket traffic and never completed. Admitted requests are unchanged: the kernel test's
bucket-port timing hashes of the boot pass and of a launch without rejections are identical before and after.
The kernel's own reaction to a lease violation (viol_q in K_REQ_V) cannot be reached from host commands, since the
kernel presents its own token under one lease over every slot. The kernel group's `kernel_badtok` run reaches it: the
testbench corrupts the kernel's token for one valid command of run 2, from its request until the verdict is registered,
so the core flags a violation. Required: status 4, one DOMA access per command, zero data for a GET or an untouched
slot for a PUT, and later GETs of that key unchanged (nothing written). Against the previous kernel (an immediate
reply while the core's dummy still runs), the next command times out and the run fails; the kernel and secure-top
changes belong together (v10e: tests only, RTL as v10d).

## Two-lane AES-GCM: two blocks per cycle (v11a)

AES-GCM ran at one 16-byte block per cycle while the memory delivers 32 bytes, so decryption fell behind the bucket
read and re-encryption took two cycles per beat. v11a adds a second lane: the GCM core now takes and returns one whole
256-bit beat per cycle. The ciphertext does not change: every bucket written to memory is bit-identical to v10e's
under the same stimulus (checked end to end, below); only the timing differs. The padding logic is unchanged; only the
budget values move (Phase A of the plan; streaming encrypted beats straight into the write-back, Phase B, is not
done). Also in v11a: a bucket-master fix found on the way (`axi_master.v`) and the lease lock-out removed
(`secure_oram_top.v`).

### The core: `rtl/aes_gcm_2lane.v`

* Interface: as `aes_gcm_pipelined` (start, encrypt, key, iv, tag_in, tag_out, tag_valid, tag_match, iv_out,
  iv_updated, input_ready, counter_overflow, ready, busy, enable), with 256-bit `data_in` / `data_out` and a 2-bit
  lane mask (`data_mask`, `data_out_mask`): 2'b11 = two blocks (block 2k in [127:0], 2k+1 in [255:128], the order the
  controller fed the old core), 2'b01 = one block in [127:0]. Any length works, odd or even, and the empty message
  (data_last before any beat) as in the old core. Blocks are whole (the old core's `data_bytes_valid` was tied to 0
  and is gone). `tag_in` is sampled with `start` (the controller sets both in the same cycle).
* CTR: two `aes128_encrypt_pipeline_rk_fpga` share one `aes128_key_sched_fpga` (`rtl/aes128_pipe2_fpga.v`: the
  registered key schedule and the ten-round pipeline of `aes128_round_fpga.v`, split so that the schedule exists
  once). A two-block beat encrypts counters c and c+1 and advances by 2. `counter_overflow` is set when any block uses
  0xFFFFFFFF, as before (lane 0 or lane 1).
* GHASH: `rtl/ghash_lane6.v`, the extension of `ghash_lane3`: six Horner chains with H^6, blocks dealt by their index
  in the message, two Karatsuba multipliers (`gf_pmul_128` / `gf_reduce_128` of `ghash_single_cycle_fpga.v`); a chain
  is reused at the earliest three cycles later, exactly when its next product is ready, so two blocks enter every
  cycle with no back-pressure. After the last block the six chains are combined with H^1..H^6 by their distance from
  it (three cycles of two multiplies). H^2..H^6 are computed once per key by five one-block GHASH runs (the old
  hp_step sequencer, extended). The length block len(A) || len(C) (no AAD, as before) follows the last data beat in a
  one-block cycle; it is never padded with a zero block.
* IV: the 96-bit LFSR, its seeding (the first encryption after reset or a key change) and its 96 steps per encryption
  are the old core's, line for line.
* Constant time: start to tag_valid takes 23 + beats cycles for every message of a given length, whatever the data,
  key, IV or direction; the first message after reset or a key change adds a fixed 75 (schedule settle 12, H 13, five
  GHASH runs 50). E(IV||1) is computed on lane 0 in the cycle before the first beat, every message: the old core kept
  E(Y0) when a decryption repeated the previous decryption's IV, a timing difference that depended on the IV.
* `input_ready` stays high from the first cycle the core takes a beat until it takes the one flagged `data_last`; the
  producer may keep reads in flight.

### The controller: `rtl/flat_oram_gcm.v`

The aes_half / aes_beat_buf split on input and the aes_out_half split on output are gone: one scratch read per cycle
feeds one beat to the core (two cycles of read latency, tracked by `fd_v`), and every returned beat is written back in
place. The message boundaries are unchanged: `gcm_start` per bucket at position 0, `gcm_data_last` on the last beat of
position Z-1, the boot format's zero beats (`cr_zero`), one tag checked or stored after the last position. S_CR_IV,
S_CR_IVW and S_CR_START now run once per message (position 0) and S_CR_FEED streams every position; the states and
the phase-trace points (ORAM_PHASE_TRACE) are the same, so the breakdown stays comparable.

* Decryption keeps pace with the bucket read. The message starts at once (the IV and tag are read from the bucket's
  record without waiting for position 0), and each beat is read as soon as it has landed. Its plaintext goes back into
  the same scratch bank, whose single write port the landing beats hold until the position has fully landed, so the
  core's output beats pass through a 32-beat queue (LUT-RAM) that writes a beat once its position has landed; reads
  stop while 32 beats are read and not yet written back, so the queue cannot overflow. The last position's plaintext
  can be written only once it has fully landed, one beat per cycle, so decryption ends about one position after the
  bucket's last beat: BEATS + 2 cycles with gap-free delivery (verification left at the last beat, worst group: 27
  cycles from 32 B to 512 B, 34 at 1 KB, 66 at 2 KB, 130 at 4 KB; v10e: 184 at 32 B, 1,327 at 4 KB). That is the floor
  while plaintext is written in place; going lower would need a second bucket buffer (out of scope).
* Re-encryption: a position starts once its eviction copy is done and the previous position is written back, about
  BEATS + 18 cycles per position. Without that wait the encryption (BEATS per position) would overtake the
  eviction-copy engine (BEATS + 4 per copy) and its time would depend on the number of evictions; worst_case.py's
  cycle model requires it constant, and it is (Ec, every traced access).

**What it buys (simulation, the plan's measurement).** The traced kernel (`TRACE=1`), lambda = 7, 4 KB, buckets in
host memory at 263-cycle reads (PCIe-like), 100 PUTs and 100 GETs through `vitis/host_phases.cpp` on the mock XRT
(`sim/xrt_mock`, now with `LAMBDA=7`), v10e and v11a under the same stimulus; mean cycles per command, from the trace
records (the 12 phases add up to E2E):

| Phase | v10e | v11a |
|---|---|---|
| handoff, lookup, read gate | 134 + 61 + 207 | 134 + 61 + 207 |
| bucket read (first request to last beat) | 1,286 | 1,286 |
| **decryption / verification after the last beat** | **1,329** | **132** |
| block operation, eviction | 233 + 6 | 233 + 6 |
| **re-encryption** | **2,221** | **1,174** |
| write-back wait, bucket write, release gate, result | 116 + 1,023 + 222 + 131 | 116 + 1,023 + 222 + 131 |
| **end to end** | **6,968** | **4,724** (-32%) |

(GET phase: operation 223 and write-back wait 125, the same in both.) v10e's mock run reproduces the card's breakdown
(re-encryption 2,221 exactly, decryption after the last beat 1,329 against 1,279, E2E 6,968 against 7,081), so the
card should show about 4,700 cycles per 4 KB access at lambda = 7 with host buckets (the plan estimated about 4,800).
Every response was correct in both. Logs: `docs/v11a_phases_lambda7_4k.txt`.

### Found on the way: a write could lose its address (`rtl/axi_master.v`)

The bucket master finished a write command once its W beats were sent, even when the slave had not yet accepted the
command's AW (AXI lets the data go first). The next write command then overwrote the AW still waiting for AWREADY, and
that bucket's write was lost. v10e never had enough writes outstanding for a slave to hold AWREADY low; the two-lane
boot format writes a 32 B bucket every 52 cycles instead of 186, so with acknowledgements 1,200 cycles late
(`kernel_wlat_slow`) the memory model's 16-entry write queue filled, 16 bucket writes of the format were lost, and the
kernel hung waiting for their responses. Fix: a write command completes only when every AW is accepted too (`w_sent`,
`aw_all_done`); the outstanding-response counter is 8 bits instead of 5. Timing is unchanged whenever AWREADY is not
held low past the last data beat (every other run: the bucket digests and the strict-mode trace hashes are unchanged).

### Lease lock-out removed (`rtl/secure_oram_top.v`)

The F10 lock-out (after 4 rejected requests a client's requests, valid or not, were all served as dummies until its
lease was granted or renewed again) is removed: every rejected request is served as a dummy, each time, and
`client_lockout` stays 0 (the port is kept). No test reaches 4 rejections (the most is one, `kernel_badtok` and
`ni_viol1`), so nothing else changes: the lint group passes at every size, and the ni, secure and kernel groups at 4
KB, lambda = 7, rerun on the new RTL, produce the same 20 run logs, byte for byte, as before the change (bucket
digests, timing hashes and cycle counts included); every check passes. The full regressions below ran before the
removal (at 4 KB, lambda = 6, the kernel and arrival groups ran again on the final RTL and pass).

### Host buckets can now wait for the stash (`hostwait`)

With the one-lane core a bucket in host memory never waited for the stash: its verification outlasted the stash's two
dependent HBM reads even when every metadata read took 200 cycles (the adverse case). Small buckets are now verified
sooner, so in that case they can wait (worst stash wait: 107 cycles from 32 B to 512 B, 100 at 1 KB, 68 at 2 KB, 4 at
4 KB). Nothing in the design changes: the budget rule already takes the larger of the derived bound and the measured
host worst (AR_WB = max(derived, measured host) + 54), and the hostwait run is one of the measurements. The hostwait
check used to require no wait; it now requires that the worst work after the last beat, waits included, fits AR_WB,
and reports the wait.

### Tests

* `sim/tb_gcm2.v` (units and crypto groups): both cores run the same 351 operations (`sim/gcm2_ref.py` writes them)
  and are compared block by block with each other and with an independent model, `gcm2_ref.py`: pure-Python AES-128
  (FIPS-197) and GCM (SP 800-38D), self-checked on FIPS-197 C.1, the GCM spec's test cases 2-3 and every NIST vector
  it uses (and against the `cryptography` package when installed; nothing depends on it). Sections: the 90 NIST CAVP
  AES-128 vectors with 96-bit IV, no AAD and whole blocks (`sim/gcm_nist_vectors.txt`, extracted unchanged from
  gcmEncryptExtIV128.rsp and gcmDecrypt128.rsp; 45 encryptions, 45 decryptions of which 23 must fail); random messages
  of 1 to 2,100 blocks (2,049 included), odd and even, under changing keys, each decrypted crosswise (the new core's
  output by the old core and the old core's by the new); one flipped ciphertext or tag bit (tag_match = 0); a
  back-to-back group (each message started the cycle the core is ready, a beat every cycle, key changes inside); the
  counter-overflow flag (two more instances whose counter starts at 0xFFFFFFF0 / 0xFFFFFFF1, so 0xFFFFFFFF falls in
  lane 1 / lane 0, checked against the model with the counter wrapping); constant time (each length one cycle count, =
  23 + beats). Some messages mix one-block beats into the stream or have idle cycles, to cover every chain rotation.
  Mutation check (once, not in the regression): a wrong lane-1 counter, a 95-step LFSR, a wrong combine power, a wrong
  length block, a data-dependent extra cycle, a tag_match stuck at 1, a lane-1 keystream error and a lane-0-only
  overflow test each fail it.
* `sim/tb_ghash6.v`: `ghash_lane6` against the reference for 300 messages of 1 to 400 blocks, two- and one-block beats
  mixed, back to back and with gaps.
* End to end: `bucket_write_digest` (in `sim/oram_timing_monitor.v`) folds every beat written on a bucket port, in
  order, with its strobes, and every write burst's address and length, into digests that `tb_ni` and `tb_doma_kernel`
  print before they finish. `sim/golden_digests.sh <v10e package>` runs v10e's RTL with these testbenches (kernel and
  ni groups, every size, both lambdas) and writes `sim/golden_bucket_digests.txt`; `run_verilator.sh` compares every
  run that has a reference and passes only if all are equal. Runs that halt on purpose (budget overrun, undersized
  pool) have no reference: where they stop depends on timing. Result: every full regression compares 15 runs (`ni0`,
  `ni1`, `ni_viol1` and 12 kernel runs), at eight sizes and two lambdas: all 240 runs write exactly v10e's buckets.
* Timing hashes: no golden timing hash is stored in the package. Strict mode keeps v10e's budgets at every size (see
  Budgets), and the strict-mode trace hashes of `tb_ni` at 32 B are unchanged (7fc5e92e6c646952 / e6d3813244dbc5da);
  every arrival-mode hash changes, as expected.
* Changed checks: the hostwait check (above); the INFO line "50% of the buckets in HBM vs 0%" is reported, not
  checked, at both lambdas (at 32 B lambda = 6 HBM is no longer faster: 119,908 vs 118,288 cycles, since a host
  bucket's work after its arrival is now short); the kernel abort path now uses a host read latency equal to the
  strict write-back gate (CT_WB + PM_LAT, at least 600) instead of a fixed 600 cycles. With the two-lane core a
  600-cycle read fits the strict budgets from 128 B up, so the overrun the test expects did not happen (every command
  completed correctly); at the gate the read cannot have landed when the write-back must start, at every size.

### Budgets (A4)

Only values changed; the padding logic is v10e's. Lambda = 6: `sim/calibrate_sizes.sh` for the eight sizes, then
`sim/budgets.py --write` (v10e's rules unchanged: AR_WB = max(derived, measured host) + 54, AR_WB_H = max(derived + 32
+ 54, measured HBM + 42 + 32), AR_REL and AR_DONE keep their allowances over AR_WB). The derived bound is
`sim/worst_case.py`'s (unchanged), from the terms it measures: verification left at the last beat, stash wait, B + C +
D (path, copies, evictions) and Ec, the re-encryption of all positions, which now runs a beat per cycle (1,172 cycles
at 4 KB). v10e -> v11a, cycles:

| Block | derived after the last beat: v10e → v11a (verification + stash + B+C+D + Ec) | AR_WB | AR_REL | AR_DONE | AR_WB_H | AR_REL_H | AR_DONE_H |
|---|---|---|---|---|---|---|---|
| 32 B | 416 → 228 (27 + 1 + 44 + 156) | 470 → 386 | 506 → 422 | 618 → 534 | 657 → 626 | 693 → 662 | 701 → 670 |
| 64 B | 443 → 238 (27 + 1 + 46 + 164) | 497 → 395 | 545 → 443 | 657 → 555 | 674 → 635 | 716 → 677 | 730 → 691 |
| 128 B | 497 → 258 (27 + 1 + 50 + 180) | 551 → 413 | 619 → 481 | 734 → 596 | 708 → 653 | 767 → 712 | 788 → 733 |
| 256 B | 605 → 298 (27 + 1 + 58 + 212) | 659 → 449 | 765 → 555 | 888 → 678 | 790 → 689 | 883 → 782 | 917 → 816 |
| 512 B | 821 → 378 (27 + 1 + 74 + 276) | 875 → 521 | 1,058 → 704 | 1,197 → 843 | 998 → 761 | 1,158 → 921 | 1,220 → 983 |
| 1 KB | 1,253 → 545 (34 + 1 + 106 + 404) | 1,307 → 668 | 1,646 → 1,007 | 1,814 → 1,175 | 1,414 → 908 | 1,711 → 1,205 | 1,826 → 1,320 |
| 2 KB | 2,117 → 897 (66 + 1 + 170 + 660) | 2,171 → 988 | 2,822 → 1,639 | 3,049 → 1,866 | 2,246 → 1,228 | 2,816 → 1,798 | 3,037 → 2,019 |
| 4 KB | 3,845 → 1,601 (130 + 1 + 298 + 1,172) | 3,899 → 1,655 | 5,147 → 2,903 | 5,519 → 3,275 | 3,931 → 1,868 | 5,047 → 2,984 | 5,481 → 3,418 |

The strict budgets CT_WB / CT_DONE (the default build, `SCHED=strict`) stay v10e's at every size. `budgets.py`
derived them at 64 B to 2 KB from the gap-free trace with the HBM read worst (307) for the first position; that held
while verification was crypto-bound (two cycles per beat hid any slower delivery). With two lanes it is memory-bound,
and the values that rule now gives (2 KB: CT_WB 2,495 -> 1,275) failed two checks in the first regression: the
self-test's memory delivers more slowly than the trace (worst_case.py: bound 2,265 against a deadline of 1,973 at
2 KB, and 3 to 292 cycles over at 64 B to 2 KB), and the strict kernel test with 30% host-read gaps overran at 2 KB.
`budgets.py` now keeps the strict budgets (as it already did at 32 B and 4 KB); every strict-mode check is as in v10e,
and strict mode keeps v10e's offsets. Lowering them would need a strict derivation that covers the memory's delivery
rate, not only its first latency (left for later; the arrival mode, which the card runs use, has its own budgets).

Measured worst work after the last beat (calibration, adverse combined case): host 332, 341, 359, 395, 467, 614, 934,
1,601; HBM 552, 561, 579, 615, 687, 834, 1,154, 1,794 (32 B to 4 KB). Report: `docs/v11a_calibration_lambda6.txt`.

Lambda = 7: `sim/measure_lambda.sh` at lambda = 7 for the eight sizes (back-to-back accesses on the kernel, slow
metadata), then `sim/budgets_l7.py --write` (new; it applies the plan's rule): AR_WB_H(7) = max(AR_WB_H(6), measured
HBM worst + 74), and AR_REL_H(7), AR_DONE_H(7) move by the same amount over their lambda = 6 values (v10e's rule for
the allowances). Host buckets have no lambda = 7 budgets; the script stops if a measured host worst exceeded AR_WB
(none does). The ORAM_AR_*_H_L7_B<beats> defines, v10e -> v11a, cycles:

| Block | measured worst after the last beat: host / HBM (v10e HBM) | AR_WB_H(7) | AR_REL_H(7) | AR_DONE_H(7) |
|---|---|---|---|---|
| 32 B | 224 / 683 (714) | 788 → 757 | 824 → 793 | 832 → 801 |
| 64 B | 234 / 687 (726) | 800 → 761 | 842 → 803 | 856 → 817 |
| 128 B | 254 / 695 (750) | 824 → 769 | 883 → 828 | 904 → 849 |
| 256 B | 294 / 711 (798) | 872 → 785 | 965 → 878 | 999 → 912 |
| 512 B | 374 / 743 (817) | 998 → 817 | 1,158 → 977 | 1,220 → 1,039 |
| 1 KB | 541 / 847 (1,294) | 1,414 → 921 | 1,711 → 1,218 | 1,826 → 1,333 |
| 2 KB | 893 / 1,199 (2,126) | 2,246 → 1,273 | 2,816 → 1,843 | 3,037 → 2,064 |
| 4 KB | 1,597 / 1,903 (3,834) | 3,931 → 1,977 | 5,047 → 3,093 | 5,481 → 3,527 |

Over lambda = 6's AR_WB_H the lambda = 7 budgets add 13 (1 KB) to 131 (32 B) cycles: the back-to-back stash drain,
which the calibration's combined case does not reproduce. Every host worst fits AR_WB, with 58 (4 KB) to 162 (32 B)
cycles to spare. Report: `docs/v11a_measure_lambda7.txt`.

### Regression (A5)

Every size passes the full regression at both lambdas (13 groups; a full run is 46 PASS and 1 INFO, the HBM-share
comparison, which is not checked). The runs were split between the user's laptop (WSL) and a cloud machine, and, as
fixes came in, between release candidates of this package (rc2: strict budgets restored; rc3: the abort-path test's
latency; rc4: the last lambda = 7 budgets). Where a run predates the abort-path fix, its kernel group was run again
with rc3's `run_verilator.sh`:

| Block | lambda = 6 | lambda = 7 |
|---|---|---|
| 32 B | laptop rc1, kernel group again (rc3) | laptop rc4 |
| 64 B | laptop rc2, kernel group again (rc3) | laptop rc4 |
| 128 B | laptop rc2 (1 FAIL: the old abort test), kernel group again (rc3) | cloud, 13 groups |
| 256 B | laptop rc3 | laptop rc3 |
| 512 B | laptop rc3 | laptop rc3 |
| 1 KB | laptop rc3 | laptop rc2 (1 FAIL: the old abort test), kernel group again (rc3) |
| 2 KB | laptop rc3 | cloud, 13 groups |
| 4 KB | laptop rc3; cloud, 11 groups (rc4) and kernel + arrival (final RTL) | cloud, 13 groups; lint, ni, secure, kernel again on the final RTL (identical logs) |

In every run, the measured worst work after the last beat fits its budget (host AR_WB; HBM AR_WB_H, at lambda = 7
the new AR_WB_H(7)), the derived worst case fits the strict deadline, GETs and PUTs give identical bucket-port timing
in both modes, and no safety-monitor violation or scratch bank conflict occurs. Verilator crashed with an internal
error while building four times on the laptop (`cal`, `sec` twice, `kern`); the script's retry rebuilt and the
checks passed. The full outputs, with a summary per size: `docs/v11a_regression_lambda6.txt`,
`docs/v11a_regression_lambda7.txt`.

### On the card (A6, A7)

* Builds (A6): the flow is unchanged. `vivado/add_sources.tcl`, `vitis/package_kernel.tcl` and the OOC scripts take
  every file in `rtl/`, the three new ones included; the one-lane core stays in `rtl/`, unreferenced, and synthesis
  drops it. Area, a rough Yosys estimate (synth_xilinx for UltraScale+, the cores alone, flattened): one-lane core
  21.7K LUTs and 8.6K flip-flops, two-lane core 39.5K LUTs, 256 SRLs and 10.4K flip-flops, so about +18K LUTs, inside
  the plan's +15-25K (Vivado maps the S-boxes differently; take its number for Table II). The controller adds a
  32-beat LUT-RAM queue (about 300 LUTs) and loses the half-beat registers.
* Timing at 300 MHz: the new paths are the GHASH operand select into the multipliers' operand registers (a 6:1 chain
  mux and an XOR, or the combine's 6:1 accumulator mux), the lane-1 counter (its own register: no adder in front of
  the AES input), and the write-back queue (a LUT-RAM read into the scratch write register; its gates compare
  registers). If timing fails, first register the combine's operand select (one cycle more per message, constant),
  then the lane outputs, as the plan says, before considering a lower clock.
* Card (A7): expect at 4 KB, lambda = 7, host buckets: decryption about 130 cycles after the last beat (plus any gaps
  inside the last position's PCIe stream), re-encryption 1,174, about 4,700 cycles per access. host_doma at 64 B and 4
  KB, then YCSB A-F on the traced 4 KB bitstream, as planned. The memory report does not change (no new buffers).
* Not done (Phase B): streaming encrypted beats straight into the write-back.
* Unchanged stand-ins (as in v10e, README "Step 5.1"): the remap target b' still comes from a 64-bit xorshift with a
  fixed seed (`rng_bucket.v`), and the AES key and IV seed are fixed. They do not affect timing (values are drawn
  ahead), but they are not secure. Replacing the generator (for example AES-128-CTR under a per-boot key) changes
  every b', and with it the measured worst cases: it would need the measurements and regressions again, and buckets
  could no longer be compared with v10e's, so v11a leaves it.

## Random placement at boot and a fixed-time boot (v11b)

v11b replaces the boot layout and the kernel's touch pass (README "Boot touch pass") with random direct placement:
the boot places every block at an independent uniform bucket itself, so the state the security argument and the
stash analysis start from (Claim 1: R_0 = 0, the excess over Z in the stash, O_0) holds from the first request, and
the first launch no longer makes n accesses. The boot is padded to a fixed length, so that its duration does not
reveal how many blocks the placement put in the stash. Every access is unchanged (the same padding, budgets
re-measured for the new workload, below), but every bucket's contents differ from v11a's, so the regression's
bucket-digest reference is now this package itself.

### Placement (`rtl/flat_oram_gcm.v`, `S_LAYOUT`)

After the format (every bucket encrypted as zeros, its record empty), the controller places the slots one at a time,
in slot order. For each it draws a bucket from the same generator as the remap targets (`rng_bucket.v`, still the
xorshift stand-in) and reads that bucket's record. If the bucket holds fewer than Z slots, the slot is appended to it
(record and position-map writes); its data is the bucket's formatted zeros. Otherwise the slot goes into the stash
with that bucket as its target, exactly as a remapped block waits (list open, a zero block in the pool, commit; the
position map says "in the stash"). The result: per-bucket counts Binomial(n, 1/B), the first Z of each bucket in it,
nothing in the stash that a bucket could take, and O_0 = sum over buckets of (count - Z)+ in the stash: expected 5.2%
of n at lambda = 6 and 9.2% at lambda = 7 (at 1M blocks 54,872 ± 265 and 96,096 ± 280). Placement touches only the
on-package state (position map, records, stash); no bucket is read or written after the format. If the pool cannot
hold the excess, the boot halts with a stash overflow (0x408), before any command.

Removed: `rtl/slot_perm.v` (the keyed permutation), the kernel's touch-pass states `K_TCH`, `K_TCH_D`, `K_TCH_W`,
`K_TCH_G` and their counters (`doma_kernel.v`). The kernel goes from the lease straight to the first command (or to
the summary of an init launch); a boot that halts now ends the init launch with the halt's cause (it used to wait for
a ready that never came). The host programs print a boot halt as "(halted at boot: <cause>)".

Since the counts are Binomial(n, 1/B) for any n, the host's rounding of n up to a multiple of lambda (README "Stash
pool") is no longer needed for that claim; it stays, so that B = n / lambda exactly, the analysis's parameter.

### Fixed-time boot

Placing a slot in its bucket costs one record read (behind the previous slot's writes) and two writes; placing it in
the stash costs a list open, a pool block and a commit as well, several HBM round trips. Unpadded, the boot would last
a + b * O_0 cycles: O_0, a function of the initial positions, would show in the init launch's duration. With the
spread of O_0 (about ± 280 blocks at 1M) and several hundred cycles per stash placement, that is a fraction of a
millisecond, which the host can time. A workload whose first accesses touch many distinct blocks reveals their initial
buckets, from which O_0 can be recomputed and compared with the boot's length; repeated accesses show fresh buckets
that do not match. The old boot had no such term: its layout put lambda < Z slots in every bucket and its touch pass
ran n padded accesses in a fixed order.

So the placement is padded like an access. The layout and all its writes must be done exactly

    LAY_BUDGET = n * ORAM_LAY_TB + (n / 4) * (ORAM_LAY_TS0 + (Z + 3) * beats per block) + ORAM_LAY_BASE

cycles after the layout starts (n is the run-time number of blocks). At that cycle the controller checks that the
placement is done and every write acknowledged; it then waits BOOT_SETTLE as before and becomes ready, so it is ready
at the same cycle whatever the placement and whatever the memory's latency. If anything is still outstanding, it
halts with a timing overrun (0x108). ORAM_LAY_TB = 300 bounds one slot placed in its bucket. ORAM_LAY_TS0 + (Z + 3)
* beats = 840 + 11 * beats bounds one slot placed in the stash: its list open also reads the data of the target's
window entries (up to W = Z + 1 blocks, as an access's open does), then the zero block goes in and the commit writes
it back. n / 4 bounds O_0 (5.2% or 9.2% of n expected; at the regression's n = 4,092, 4.7 to 5.8% across five
placements). The budget depends only on n and the build, never on a host-chosen value such as the pool size. Measured
worst per slot (n = 4,092): in the bucket 192 with the U55C's HBM profile and 234 with every metadata read at 200 cycles
(the arrival group's adverse case); in the stash 336 / 669 at 32 B and 1,252 / 1,535 at 4 KB (bounds 851 and 2,248).
With every write acknowledged after 200 cycles as well, 32 B slots cost up to 366 / 510 cycles, beyond the bucket
bound, and the placement still finishes at half the budget (1,060,882 of 2,102,269 cycles), because n / 4 is far above
O_0.

Boot length: the format (unchanged) plus LAY_BUDGET plus BOOT_SETTLE. At 300 MHz, LAY_BUDGET is 1.8 s at 1M blocks of
32 B and 3.0 s at 4 KB, 3.6 s and 6.0 s at 2M (touch pass: 3.5 s at 32 B and 24 s at 4 KB for 1M, 47 s at 4 KB for
2M). On the card the placement itself should take far less (record reads about 72 cycles); the first reads after the
format may wait behind its queued writes (README "The boot halt"), which the budget's slack absorbs. A debug build can
read the layout's end (`lay_end`), its stash count (`lay_nst`) and the worst slot costs (`lay_max_b`, `lay_max_s`)
through the ILA; the host never sees them.

### Tests

* `ni` group: the boot layout of the network-interface testbench is checked by `sim/layout_check.py` (every slot
  placed once, the first Z of each bucket in it and the rest in the stash, per-bucket counts against Binomial(n, 1/B)
  by chi-square, the stash count against its expectation), from the testbench's `+layout_log`.
* `kernel` group: the bounded-pool test (n = 4,092 or 4,095 with the host's pool) serves every access, the boot
  included, and its layout is checked the same way; a 100-entry pool halts at boot (stash overflow, 0x408).
* `boot` group (new): the 4,096-block build at that n boots with five placements (the testbench starts the generator
  from five states, `+rng_seed`) and four HBM latency profiles. Every boot must be ready at the same cycle after the
  layout's start, with different stash counts, every slot within the per-slot bounds (except the 200-cycle-write
  profile, which must fit the total), and every command correct; bucket-record reads at ORAM_LAY_TB + LAY_TS cycles
  must halt the boot with a timing overrun, the launch still ending.
* `arrival` group: every kernel run first PUTs all n blocks back to back (`+preload`). Through v11a the touch pass
  gave every kernel run these n accesses; without them the measured worst work after the arrival fell (4 KB, lambda
  7, HBM: 1,629 against v11a's 1,903) by sampling fewer back-to-back accesses, not by doing less work. With the
  preload the measurement is back at v11a's (1,903; 32 B, lambda 6: host 224, HBM 509 against 226, 505).
* End to end: `sim/golden_bucket_digests.txt` holds v11b's own bucket-write digests (`sim/golden_from_logs.py`, from
  the regression's `DIGEST` lines); later versions compare with them.

### Budgets: the directed cases now reach full stash windows

Only the arrival budgets change (the strict budgets CT_WB / CT_DONE are v11a's, and the padding logic is unchanged).
Lambda = 6: `sim/calibrate_sizes.sh` at the eight sizes, then `sim/budgets.py --write` with v11a's rules. Lambda = 7:
`sim/measure_lambda.sh` now runs the directed cases (worst, combined, hostwait) as well as the kernel runs, every
arrival budget raised by 5,000 cycles, and `sim/budgets_l7.py` sets lambda = 7 budgets for host buckets too (new:
`ORAM_AR_WB_L7_B*`, `ORAM_AR_REL_L7_B*`, `ORAM_AR_DONE_L7_B*`, selected by ORAM_C == 7 like the HBM ones), by the HBM
rule: AR_WB(7) = max(AR_WB(6), measured host worst + 54), AR_WB_H(7) = max(AR_WB_H(6), measured HBM worst + 74), the
release and acknowledgement deadlines moved by the same amounts.

Why they rise. The directed cases boot the network-interface testbench, which never had a touch pass: through v11a it
started from the fixed layout (lambda blocks per bucket, an empty stash) and built every full stash window with the
requested block inside it. With the random placement, its bucket drains leave fuller waiting lists, and the case
appears where a bucket's window is full (W = Z + 1 = 9 blocks waiting) and the requested block is in the bucket, not
among them. The stash's open then issues 19 reads (9 metadata entries, 9 blocks, the chain head) where the memory keeps
16 in flight (`axi_mem_model.v`; the card's HBM port has such a limit too, not measured here), so the last three wait one more
HBM read latency (200 cycles in the adverse profile). Measured stash wait (hostwait, every metadata read at 200 cycles):
v11a 107 cycles at 32 B to 512 B, 68 at 2 KB, 4 at 4 KB; v11b 281 at 32 B, 275 at 64 B, 263 at 128 B, 239 at 256 B,
191 at 512 B, 135 at 1 KB to 4 KB. The case is reachable on the card (waiting lists have geometric tails), so v11a's
budgets could have overrun there under slow HBM: a fail-stop halt, but one correlated with the stash's state. The
kernel runs measure v11a's worsts (at lambda 7 exactly, at every size; at 32 B, lambda 6, host 224 and HBM 509
against 226 and 505): they reach this case less often.

| Block | lambda 6: measured host / HBM worst, v11a → v11b | AR_WB | AR_WB_H | lambda 7: measured host / HBM | AR_WB(7) | AR_WB_H(7) |
|---|---|---|---|---|---|---|
| 32 B | 332 / 552 → 484 / 704 | 386 → 538 | 626 → 778 | 504 / 724 | 558 | 757 → 798 |
| 64 B | 341 / 561 → 488 / 708 | 395 → 542 | 635 → 782 | 508 / 728 | 562 | 761 → 802 |
| 128 B | 359 / 579 → 496 / 716 | 413 → 550 | 653 → 790 | 516 / 736 | 570 | 769 → 810 |
| 256 B | 395 / 615 → 512 / 732 | 449 → 566 | 689 → 806 | 532 / 752 | 586 | 785 → 826 |
| 512 B | 467 / 687 → 544 / 764 | 521 → 598 | 761 → 838 | 564 / 784 | 618 | 817 → 858 |
| 1 KB | 614 / 834 → 655 / 875 | 668 → 709 | 908 → 949 | 675 / 895 | 729 | 921 → 969 |
| 2 KB | 934 / 1,154 → 1,007 / 1,227 | 988 → 1,061 | 1,228 → 1,301 | 1,027 / 1,247 | 1,081 | 1,273 → 1,321 |
| 4 KB | 1,601 / 1,794 → 1,711 / 1,931 | 1,655 → 1,765 | 1,868 → 2,005 | 1,731 / 1,951 | 1,785 | 1,977 → 2,025 |

(Lambda 7 host budgets did not exist through v11a: host buckets used lambda 6's AR_WB.) The derived bound after the
last beat is unchanged at every size (228 .. 1,601): the increase is all stash wait, which the derivation counts as one
cycle and the measurement takes over. Cost: an access in arrival mode at 32 B (about 974 cycles per command at PCIe-like
latencies) grows by about 150 cycles at lambda 6 and 170 at lambda 7, about 15%; at 4 KB (about 4,700) by 110 to 130,
under 3%.

Removing the cost needs either the platform's real outstanding-read limit on the stash's HBM port (if it is 20 or
more, the case costs nothing and the budgets fall back to about v11a's; set the testbench model to it), or an open that
needs no metadata reads (each window entry's slot number kept in the 64-byte head, 10 reads instead of 19: a change of
the stash's HBM layout, not of any bucket). Neither is in v11b.

### Regression

Every size passes at both lambdas. The runs were split between the user's laptop (WSL) and a cloud machine. Lambda = 6,
all 14 groups (a full run: 49 PASS and the INFO line on the HBM share): 4 KB, 2 KB, 1 KB and 512 B on the laptop
(rc4), 256 B to 32 B in the cloud (rc4). Lambda = 7: the 11 groups that do not read the arrival budgets (lint, units,
crypto, selftest, ni, stress, bp, secure, worst, kernel, boot) on rc3 in the cloud at every size, and the 4 that do or
that report against them (worst, combined, hostwait, arrival) on rc4: 1 KB and 512 B on the laptop, the other six
sizes in the cloud. rc3 and rc4 differ only in the arrival budgets' values (rtl/oram_params.vh) and the lambda = 7
host-budget selectors, which no strict-mode build reads.

In every run the measured worst work after the last beat fits its budget (lambda 7: the new host and HBM budgets),
the derived worst case fits the strict deadline, GETs and PUTs give identical bucket-port timing in both modes, every
boot is ready at the same cycle whatever the placement, and no safety-monitor violation or scratch bank conflict
occurs. Bucket-write digests are identical wherever a run was repeated (across machines and release candidates);
they are this package's reference (`sim/golden_bucket_digests.txt`), and a confirmation run checks them end to end.

`sim/run_verilator.sh` now rebuilds when lambda changes, not only the configuration or the block size: through v11a a
lambda = 7 run in a tree last used at lambda = 6 with the same block size reused lambda 6's builds. Every run above
used a tree of a single lambda.

Reports: `docs/v11b_budgets.txt` (the calibration's budget lines, the lambda = 7 measurements, budgets_l7.py's
derivation), `docs/v11b_regression_lambda6.txt` and `docs/v11b_regression_lambda7.txt` (per size, the runs that make
up the evidence with a summary each, then every output in full).

### Not changed

* The generator: the placement and every remap still draw from the 64-bit xorshift stand-in with a fixed seed
  (`rng_bucket.v`), so every boot places the blocks the same way. A deployment needs a secure source (a TRNG, or a
  DRBG seeded from one); a TRNG must supply the placement's draws (one per block) at the layout's pace, or the layout
  waits for it and ORAM_LAY_TB must cover the wait.
* The pool size is still the host's kernel argument. A pool below the stash's certified bound fails at boot or later
  (fail-stop); since whether a boot succeeds depends on O_0, a host that chose a pool near O_0's typical value would
  learn whether O_0 exceeded it. The security argument assumes the host provisions the certified pool (README
  "Stash pool"); enforcing a floor in the RTL is possible but not done.

## On-package buckets on the second HBM stack in every build (v11c)

`doma.cfg`, the configuration of the builds without a CFG (the 32 B builds), connected the on-package buckets to
HBM[8], in the same 4x4 switch segment (HBM[8]-[11]) as the position map (HBM[10]) and the bucket records (HBM[11]).
AMD does not document whether traffic on one path through a segment can delay another, and the padding leaves a
bucket's own read latency open on the condition that nothing request-dependent shares hardware with the bucket bank.
`doma.cfg` now connects `pages_hbm` to HBM[16:31], as `doma_big.cfg` and `doma_big2m.cfg` already do: the other
stack, with its own controllers, switch segments and physical interface. Every build now keeps buckets and metadata
on separate stacks. No RTL, budget or host change: the kernel and the hosts take the bank from the buffer the host
allocates on the port, and a bucket read's latency is not padded. It takes effect in the 32 B bitstreams.

## Boot fix: the placement waits for a whole bucket record (v11d)

On the card, every v11b/v11c run halted at boot: state 29 (S_LAYOUT), access cycle 0, memory-unit error "bucket
records", errors 0x108, at every size and HBM share. The record unit (bucket_rec_hbm.v) raises bm_rd_valid with a
record's first beat (slot list and fill), while its second beat (IV and tag) may still be arriving; writing the record
then is one of its fail-stop conditions ("a write into the record while it is still arriving"). Normal accesses write
a record only at their end, but the placement wrote it in the cycle after bm_rd_valid. The simulation's memory model
returned the two beats back to back, so the second had always landed; the card's HBM returns them with a gap, so the
write met the second beat. Fix: the record unit has a new output, bm_rd_busy (a fetch pending or arriving); the
placement takes the first beat in phase 1 and writes only in a new phase 7, once bm_rd_busy is clear. The boot is
padded to its fixed length, so the extra cycle or two per slot is invisible; the boot's and the accesses' bucket-port
timing hashes are unchanged (c28b65a1e1418f0d and 9bef2bebd95f4cad in the 32 B kernel test, as in v11c).
Reproduced in simulation with read gaps on the record memory (tb_doma_kernel +brec_gap=P, new): v11c halts exactly as
on the card; v11d passes at 0, 25, 50 and 75 % gaps, and with gaps on every HBM memory (+hbm_gap=P, new) together
with host-memory gaps, with the buckets in host memory, 25 % in HBM or all in HBM. The kernel group runs the case
(kernel_brec_gap) at every size, so a write into an arriving record can no longer pass simulation.

## The card's memory behavior in every regression (v11e: tests only, RTL as v11d)

v11b/v11c's boot bug passed simulation because the memory models returned read beats back to back and never held
their ready signals low, while the card's memories do both. tb_doma_kernel now exposes both behaviors for every memory:
+hbm_gap=P and +hbm_rdy=P (read-data gaps and ready held low on P % of cycles, on the record, position-map, stash,
HBM-bucket, command and response memories), +host_gap=P and +host_rdy=P (host memory), and +brec_gap=P (records
only). The kernel group runs kernel_card_profile (+hb=25, 20 % gaps and 20 % backpressure on every memory) at every
size, next to kernel_brec_gap. With v11d's RTL, beyond the regression: all checks pass at 32 B with 30 % and 60 % gaps
and backpressure on every memory at once, and at 4 KB with 10 % and 30 %, with the buckets in host memory, 25 % in HBM
or all in HBM; the boot budget's products are 40-bit (1.8e9 cycles at 2M slots x 4 KB, 5.9 s).

## Host programs: re-encryption may end after the write-back starts (v11f: hosts only, RTL as v11d)

On the card, host_phases reported "ERRORS FOUND" with correct data: 94 of 1M trace records (4 KB, all buckets off
package) had re-encryption ending (trace slot 10) after the write-back started (slot 11), by 30-50 cycles. With two AES
lanes, re-encryption runs at the write-back's rate (32 B per cycle), so the write-back, issued at its fixed time after
the bucket's last beat, can start before the last encrypted beat; it never catches up (that would halt with
axim_wdata_stall, and the runs report errors 0x0). With one lane, encryption ran at half the write's rate, so the
hosts assumed slot 10 <= slot 11 and dropped such a record as out of order; host_ycsb also failed the workload.
host_phases and host_ycsb now end re-encryption at the write-back's start for such a record, count it, and report the
overlap ("re-encryption ends after the write-back start in N records, by X cycles on average"); the phases still add
up to E2E. No RTL change: the v11d/v11e bitstreams stay valid; rebuild only the host programs.

## Host programs: how late re-encryption ends (v11g: hosts only, RTL as v11d)

The write-back budget AR_WB is calibrated from the worst (encryption end - t_arr) in simulation, so the write-back is
meant to start after re-encryption ends. On the card (v13, 4 KB, all buckets off package), 94 of 1M accesses ended
re-encryption 30-50 cycles after the write-back started: the card's worst case exceeds the simulation's plus margin.
Before the budgets are raised and the order is enforced, host_phases reports the card's distribution per run:
"re-encryption ends after the last beat by: p50, p99, p99.9, p99.99, max cycles; the write-back starts after it at
min..max cycles" (trace slot 10 - slot 4, and slot 11 - slot 4).

## On-package buckets in plaintext (v14)

Buckets in HBM (on package, trusted memory) are kept in plaintext in arrival-mode builds (the bitstreams: build.sh
SCHED=arrival). Their accesses skip the GCM passes; everything off package is as in v11g, cycle for cycle. Strict-mode
builds are unchanged (flat_oram_gcm.v BYP = 0).

**Per access, by the bucket's location** (rtl/flat_oram_gcm.v, `v14` comments). An off-package bucket takes v11g's path.
An on-package bucket's read lands in scratch as plaintext (the same 32 B per cycle, beat order unchanged); once its last
beat and its record are in (S_DDR_READ), the block operation starts: no decryption, no tag check. At S_EA_START (every
eviction decision made) its write-back is issued at once and streams behind the eviction copies: the master may send
the leading positions whose copies have landed (enc_pos_done counts those), so position p waits only for its own copy.
Blocks cross between locations through the stash, which holds plaintext (as before): a block read from an off-package
bucket is decrypted and verified before it moves; one written to an off-package bucket is encrypted with it.

**Boot.** An on-package bucket is formatted with zeros written straight to it (fmt_zero forces the master's write data to
zero at its output); an off-package one as before. The boot is shorter by the skipped encryptions, an amount set only by
the number of on-package buckets (a host setting): boot time still depends only on the configuration. At 0% on package
the boot is v11g's, cycle for cycle.

**IVs.** Wherever an encryption is skipped (an on-package write-back or format), the GCM core's IV advances as that
encryption would have (aes_gcm_2lane.v iv_advance: a one-cycle register update with the same first-use seeding, no GCM
pass, no cycles on the on-package path). Every off-package bucket therefore gets the IV, ciphertext and tag it had in
v11g; the regression checks its host-memory bucket writes against v11g's in every run.

**Records.** An on-package bucket's record keeps only its first beat (fill count, slot list); its IV/tag beat is never
written or read (the format and the write-back skip it). Choice: the record layout and fetch stay as in v11g (one
two-beat burst per bucket), so the record unit and every off-package record are unchanged.

**Padding.** CT_RD and every off-package fixed time are v11g's. On package (lambda 7, rtl/oram_params.vh,
sim/budgets_v14.py), from the cycle model (sim/worst_case.py part 4) on the directed worst cases with every metadata read
at 200 cycles, and the measured worst of the calibration runs (docs/v14_budgets.txt):
  AR_WB_H(7)   = max(derived, measured) write-back start after the arrival + 74: an early check
  AR_REL_H(7)  = max(derived release gate + bp(b), measured) + 74: the release time
  AR_DONE_H(7) = AR_REL_H(7) + the acknowledgement allowance as before
bp(b) = ceil(0.05 (8 b + 2 bursts + 22)): the HBM bucket port may take the write 5% slower (v11g's HBM write allowance).
Overruns, on package: (1) the write-back not started by t_arr + AR_WB_H, or (2) the write not handed off (its last beat
accepted, the release gate reached) by t_arr + AR_REL_H. Either is a timing overrun (0x108, the same halt as off package),
raised at the release time itself, never earlier; the release never moves. A write beat held for its copy is no overrun
on package (by design); off package it still is (axim_wdata_stall).

**Phase trace.** On package, the decryption (slots 5 to 6) and re-encryption (slots 8 to 10) phases take zero cycles; the
16 slots stay in order (host_phases and host_ycsb read them unchanged).

**Tests** (sim/run_verilator.sh): onpkg group (contents at 100% and 20% on package with every GET checked and every bucket
inspected, sim/inspect_check.py; release and end fixed across stash histories and stash speed; slow HBM within the bound
and beyond it; the phase trace), the on-package cycle model in the worst and combined groups, AR_REL_H in the arrival
group, the IV advance in the crypto group (sim/tb_ivadv.v), and sim/compare_v11g.py: every run against v11g's RTL under
the same testbenches (RTL_DIR, TB_DEFS=-DTB_V11G_REF): at 0% on package identical on every line, otherwise identical in
everything off package.

On-package budgets, lambda 7 (cycles at 300 MHz; v11g in parentheses): AR_REL_H 32 B 659 (834), 64 B 663 (844), 128 B 672
(869), 256 B 690 (919), 512 B 725 (1018), 1 KB 843 (1266), 2 KB 1208 (1891), 4 KB 1938 (3141); an on-package access's
release and end come that much earlier (175 to 1,203 cycles). AR_WB_H 644, 640, 632, 616, 584, 567, 663, 855 (v11g 798 ..
2025). Lambda 6 is not recalibrated (its v11g budgets stay, larger than the plaintext path needs).

Regression, lambda 7, every size (docs/v14_regression_lambda7.txt): 736 checks pass, none fails. Against v11g's RTL under
the same testbenches (sim/compare_v11g.py), per size: every run with no bucket on package is identical on every line
(boot, cycles, latencies, timing hashes, per-access shapes, digests); every run with buckets on package (20, 25, 50, 100%)
is identical in all an off-package observer and the host memory see (host-memory bucket writes, off-package access
shapes, host traffic, results). Measured, 120 commands, every bucket on package (HBM reads at 179 cycles): per command
32 B 1,302 -> 1,127 cycles, 512 B 1,636 -> 1,343, 4 KB 4,886 -> 3,683 (-13% to -24% in device cycles); with half the
buckets on package, -9% to -14%. Resources (Yosys estimate, docs/v14_resources_timing.txt): +1.0% LUTs, +1.5%
registers, no block RAM; the deepest logic path stays at v11g's 7 levels.

## On-package budgets on the card: halt record, debug build, calibration (v14b)

On the U55C (4 KB, λ = 7), v14 halted with 0x108 during the preload at 100% and 20% on package: deadline (1) at 100%
(state 24), deadline (2) at 20% (state 22). On package, the eviction decisions wait for the stash open. v14's budgets
assumed every stash read within 200 cycles; with a slower stash port (350-cycle reads, or 60% of the read throughput)
the simulation reproduces both halt records (`sim/repro_card_halt.sh`): state 24 with deadline (1) at 100% on package, and state 22 with deadline (2) at 20%. v14b keeps v14's datapath and budgets, and adds:

- **Halt record:** the halt record names the on-package deadline (01 write-back start, 10 hand-off, 11 bank conflict) and the cycles it was missed by, in every build. `host_doma` and `host_phases` decode it from any halted launch.
- **Debug build:** `build.sh DEBUG=1 TRACE=1`, calibration only. An on-package overrun is recorded, not halted, and the first-overrun snapshot is latched. Each 64-byte trace record carries the controller's own per-access timestamps. `host_phases` prints the distributions and writes them as CSV (`DOMA_ONPKG_CSV`).
- **Budget script:** `sim/card_budgets.py` sets AR_WB_H / AR_REL_H from the card's worst case plus margin, never below the simulation's, and reports how much of the saving over v11g remains.
- **Timing:** the IV LFSR's 96-step advance is registered and written as one XOR per bit, and the stash's free-entry search is registered. Both are cycle-neutral, checked at every use.
- **Interim budgets:** `build.sh INTERIM=1` (4 KB, λ = 7) sets AR_WB_H 1,455 and AR_REL_H 2,538, which cover every stash and record read taking up to 500 cycles. These are for running on the card until the calibration replaces them, and they keep half of the saving over v11g.

The full method is in docs/v14b_card_calibration.md.
