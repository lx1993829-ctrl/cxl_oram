#!/usr/bin/env python3
"""compare_v14.py -- v14b against v14, run by run, under the same testbench runs.

    python3 compare_v14.py V14B_BUILD_DIR V14_BUILD_DIR

Both directories hold run_<tag>.log of sim/run_verilator.sh at one block size (v14's from its own regression). v14b
changes no cycle of a normal (non-debug) build: the IV advance and the stash's free-entry search are registered one
cycle ahead of their use (checked at every use), the halt record gains fields, and the debug build is a separate
define. So every result line must be identical: boot, every launch's cycles, latencies, timing hashes, per-access
shapes, on-package release/end hashes, traffic and bucket-write digests, calibration maxima; a halted launch's halt
record in v14's fields (v14b's new fields masked). Skipped: banners and the
revision string, simulator lines, and the lines v14b adds (the halt record and the halting access's times, the
debug build's lines). Runs only v14b has (its new tests) are listed. Prints one line per class and every difference;
exit status 0 if there is none.
"""
import glob, os, re, sys

SKIP = re.compile(r"^(tb_doma_kernel \||tb_onboard_test_top \||.*ORAM_PKG_REV|.*Verilog \$finish|.*S i m u l a t i o n|.*Walltime|"
                  r".*wall time|%Warning|%Info|- |\s*$|\w+: halt record:|HALTING-ACCESS:|\w+: debug |\[.*\] DOMA HALT:)")


HALT = re.compile(r"latency min/max=(\d+)/(\d+)(\s+errors=([0-9a-fA-F]+))")


def mask_halt(l):
    """a halted launch's latency fields carry the halt record: v14b adds the deadline code (bits 33:32), the cycles
    missed (31:20) and the lower-bound flag (16); compare v14's fields only (bucket, state, HBM, unit errors, cycle)"""
    m = HALT.search(l)
    if not m or not (int(m.group(4), 16) & 0x8): return l
    lo, hi = int(m.group(1)) & 0x000EFFFF, int(m.group(2)) & ~0x3
    return l[:m.start()] + f"halt record {hi:#x}/{lo:#x}{m.group(3)}" + l[m.end():]


def lines(p):
    return [mask_halt(l.rstrip("\r\n")) for l in open(p, errors="replace") if not SKIP.match(l)]


def main(a, b):
    same = 0; diff = []; only = []
    for p in sorted(glob.glob(os.path.join(a, "run_*.log"))):
        q = os.path.join(b, os.path.basename(p))
        tag = os.path.basename(p)[4:-4]
        if not os.path.exists(q): only.append(tag); continue
        la, lb = lines(p), lines(q)
        if la == lb: same += 1
        else:
            d = [f"    v14:  {y}\n    v14b: {x}" for x, y in zip(la, lb) if x != y][:3]
            if len(la) != len(lb): d.append(f"    {len(lb)} vs {len(la)} lines")
            diff.append(f"{tag}: differs\n" + "\n".join(d))
    print(f"v14 comparison: {same} runs identical on every result line; {len(diff)} differ; {len(only)} runs new in v14b"
          + (f" ({' '.join(only)})" if only else ""))
    for x in diff: print("  DIFF " + x)
    return 1 if diff else 0


if __name__ == "__main__":
    if len(sys.argv) != 3: sys.exit(__doc__)
    sys.exit(main(sys.argv[1], sys.argv[2]))
