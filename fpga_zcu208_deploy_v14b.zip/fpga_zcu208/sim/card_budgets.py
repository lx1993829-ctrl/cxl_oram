#!/usr/bin/env python3
"""card_budgets.py -- v14b: DOMA's on-package budgets (AR_WB_H, AR_REL_H) from the card's own per-access records.

    python3 card_budgets.py [options] RECORDS.csv [RECORDS.csv ...]

RECORDS.csv: the per-access records of a debug bitstream (build.sh DEBUG=1 TRACE=1), as host_phases writes them with
DOMA_PHASE_TRACE=1 DOMA_ONPKG_CSV=<file> (the testbench writes the same format with +dbg_csv=<file>). One line per
access: launch, cmd, flags, then the core's raw access-cycle timestamps (16 bits, 65535 = did not happen):
tarr (bucket read done), ea (write-back issued), dg (release gate reached: the write handed off), wl / wf (last / first
W accepted), bm (bucket record in), so (stash open issued), sx (stash ready: the decisions start), se (S_SCAN entered),
cl (last eviction copy landed), wst (cycles W held by the memory), wsv (cycles writing with no W offered), ar / r1
(bucket read address, first beat), end. Flags: [0] on package, [1] plaintext path, [2] deadline (1) missed,
[3] deadline (2) missed, [4] scratch bank conflict.

The deadline checks the controller makes, recomputed per access exactly as the RTL does them:
  write-back start   ws = ea - tarr   must be <= AR_WB_H    (deadline (1), the early check)
  release gate       rg = dg - tarr   must be <= AR_REL_H   (deadline (2): the write handed off by the release time)

Rule (per block size, lambda 7), with M(x) = ceil(x * (1 + pct/100)) + abs cycles:
  AR_WB_H(card)  = M(card worst ws)
  AR_REL_H(card) = max(M(card worst rg), AR_WB_H(card) + worst (rg - ws))   a write that starts at the last allowed cycle
                                                                            and then takes its worst observed time still
                                                                            makes the release
  AR_WB_H  = max(AR_WB_H in oram_params.vh, AR_WB_H(card))      never below the simulation's cycle-model worst case
  AR_REL_H = max(AR_REL_H in oram_params.vh, AR_REL_H(card))
  AR_DONE_H = AR_REL_H + (AR_DONE_H - AR_REL_H in oram_params.vh) the acknowledgement allowance, unchanged
Defaults: abs = 74 (the lambda = 7 margin of sim/budgets_l7.py and sim/budgets_v14.py), pct = 5.

Options:
  --params FILE   rtl/oram_params.vh (default: ../rtl/oram_params.vh next to this script)
  --beats B       block size in 32-byte beats (default 128 = 4 KB)
  --abs N --pct P margins (defaults 74, 5)
  --mhz F         the debug bitstream's achieved kernel clock (v++ may lower it; default 300). Memory latencies are fixed
                  in time, so a debug bitstream slower than the production clock (--target-mhz, default 300) sees fewer
                  cycles: the card's worst values are scaled by target/F (when above 1) before the margins
  --write         write the three defines ORAM_AR_{WB,REL,DONE}_H_L7_B<B> into --params (CRLF kept)
Prints the distributions (p50 .. max) of every phase relative to the arrival, the misses against the bitstream's
budgets, the worst accesses broken down (which part was late), the new budgets for three margins, and how much of
v14's saving over v11g remains.
"""
import csv, math, os, re, sys

# v11g's lambda = 7 on-package budgets (the encrypted path), for the saving that remains
V11G = {1: (798, 834, 842), 2: (802, 844, 858), 4: (810, 869, 890), 8: (826, 919, 953), 16: (858, 1018, 1080),
        32: (969, 1266, 1381), 64: (1321, 1891, 2112), 128: (2025, 3141, 3575)}
NONE = 65535
FIELDS = "tarr ea dg wl wf bm so sx se cl wst wsv ar r1 end".split()


def pct(sorted_v, p):
    """nearest rank"""
    if not sorted_v: return None
    k = max(1, math.ceil(p * len(sorted_v)))
    return sorted_v[k - 1]


def get(s, name):
    m = re.search(r"^`define %s +(\d+)" % name, s, re.M)
    if not m: sys.exit(f"card_budgets.py: {name} not found in the params file")
    return int(m.group(1))


def main(a):
    opt = {"params": os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "rtl", "oram_params.vh"),
           "beats": 128, "abs": 74, "pct": 5.0, "write": False, "mhz": 300.0, "target-mhz": 300.0}
    files = []
    i = 0
    while i < len(a):
        if a[i] == "--write": opt["write"] = True
        elif a[i] in ("--params", "--beats", "--abs", "--pct", "--mhz", "--target-mhz"):
            opt[a[i][2:]] = a[i + 1] if a[i] == "--params" else (float(a[i + 1]) if a[i] in ("--pct", "--mhz", "--target-mhz") else int(a[i + 1])); i += 1
        elif a[i].startswith("-"): sys.exit(__doc__)
        else: files.append(a[i])
        i += 1
    if not files: sys.exit(__doc__)
    b = opt["beats"]
    raw = open(opt["params"], newline="").read(); crlf = "\r\n" in raw; s = raw.replace("\r\n", "\n")
    wb0, rel0, done0 = (get(s, f"ORAM_AR_{k}_H_L7_B{b}") for k in ("WB", "REL", "DONE"))

    # ---- the records
    acc = []; n_all = n_rec_bad = 0
    for f in files:
        with open(f) as fh:
            for row in csv.DictReader(fh):
                n_all += 1
                fl = int(row["flags"])
                if not (fl & 2): continue                                   # off package: not this calibration
                r = {k: int(row[k]) for k in FIELDS}
                if r["tarr"] == NONE or r["ea"] == NONE or r["dg"] == NONE: n_rec_bad += 1; continue
                r["flags"] = fl; r["src"] = f"{os.path.basename(f)}:{row['launch']}/{row['cmd']}"
                acc.append(r)
    if not acc: sys.exit("card_budgets.py: no on-package (plaintext-path) records in the input")
    rel = lambda r, k: (r[k] - r["tarr"]) if r[k] != NONE else None
    Q = [("write-back start (ws)", lambda r: rel(r, "ea")),
         ("release gate (rg, handed off)", lambda r: rel(r, "dg")),
         ("write: start to hand-off (rg - ws)", lambda r: r["dg"] - r["ea"]),
         ("last W accepted", lambda r: rel(r, "wl")),
         ("first W accepted", lambda r: rel(r, "wf")),
         ("bucket record in", lambda r: rel(r, "bm")),
         ("stash open issued", lambda r: rel(r, "so")),
         ("stash ready (decisions start)", lambda r: rel(r, "sx")),
         ("decisions (stash ready to write-back)", lambda r: (r["ea"] - r["sx"]) if r["sx"] != NONE else None),
         ("last eviction copy landed", lambda r: rel(r, "cl")),
         ("W held by the memory (cycles)", lambda r: r["wst"]),
         ("W not offered while writing (cycles)", lambda r: r["wsv"]),
         ("bucket read latency (AR to first R)", lambda r: (r["r1"] - r["ar"]) if NONE not in (r["r1"], r["ar"]) else None),
         ("bucket read done (t_arr, access cycle)", lambda r: r["tarr"]),
         ("access end after the release gate", lambda r: (r["end"] - r["dg"]) if r["end"] != NONE else None)]
    print(f"card_budgets.py: {len(acc)} on-package accesses ({n_all} records in {len(files)} file(s); {n_rec_bad} incomplete)"
          f", block {b * 32} B ({b} beats), lambda 7")
    print(f"  {'cycles after the arrival unless noted':40s} {'p50':>7s} {'p90':>7s} {'p99':>7s} {'p99.9':>7s} {'p99.99':>7s} {'max':>7s} {'min':>7s}")
    D = {}
    for name, fn in Q:
        v = sorted(x for x in (fn(r) for r in acc) if x is not None)
        D[name] = v
        if v: print(f"  {name:40s} " + " ".join(f"{pct(v, p):7d}" for p in (0.5, 0.9, 0.99, 0.999, 0.9999)) + f" {v[-1]:7d} {v[0]:7d}")
    ws = D["write-back start (ws)"]; rg = D["release gate (rg, handed off)"]; wr = D["write: start to hand-off (rg - ws)"]
    m1 = sum(1 for x in ws if x > wb0); m2 = sum(1 for x in rg if x > rel0)
    print(f"against the current budgets (AR_WB_H {wb0}, AR_REL_H {rel0}): deadline (1) missed by {m1} accesses "
          f"({100.0 * m1 / len(acc):.4f}%), deadline (2) by {m2} ({100.0 * m2 / len(acc):.4f}%)"
          + ("" if m1 + m2 == 0 else "  <- the production bitstream would halt"))
    # the worst accesses, broken down
    print("worst accesses (cycles after the arrival: record in, stash open, stash ready, write-back start, last copy, hand-off; W held / starved):")
    worst = sorted(acc, key=lambda r: -(r["dg"] - r["tarr"]))[:5]
    seen = {id(r) for r in worst}
    worst += [r for r in sorted(acc, key=lambda r: -(r["ea"] - r["tarr"]))[:5] if id(r) not in seen]
    for r in worst:
        f = lambda k: "-" if r[k] == NONE else str(r[k] - r["tarr"])
        print(f"  {r['src']:24s} rec {f('bm'):>6s}  open {f('so'):>6s}  ready {f('sx'):>6s}  ws {f('ea'):>6s}  copy {f('cl'):>6s}"
              f"  rg {f('dg'):>6s}; held {r['wst']}, starved {r['wsv']}{'  [d1]' if r['flags'] & 4 else ''}{'  [d2]' if r['flags'] & 8 else ''}")

    # ---- budgets
    sc = max(1.0, opt["target-mhz"] / opt["mhz"])
    if sc > 1.0: print(f"the debug bitstream ran at {opt['mhz']} MHz: worst values scaled by {sc:.4f} to {opt['target-mhz']} MHz")
    def budgets(ab, pc):
        mm = lambda x: math.ceil(x * sc * (1 + pc / 100.0)) + ab
        wbc = mm(ws[-1]); relc = max(mm(rg[-1]), wbc + math.ceil(wr[-1] * sc))
        return wbc, relc, max(wb0, wbc), max(rel0, relc)
    v11 = V11G.get(b)
    print(f"budgets (margin: ceil(worst x (1 + pct)) + abs; never below the current, simulation-derived values; "
          f"v11g's REL {v11[1] if v11 else '?'}, v14's {rel0}):")
    rows = []
    for ab, pc in ((opt["abs"], 0.0), (opt["abs"], opt["pct"]), (opt["abs"], 10.0)):
        wbc, relc, wbn, reln = budgets(ab, pc)
        donen = reln + (done0 - rel0)
        save = (v11[1] - reln) if v11 else None
        frac = (100.0 * save / (v11[1] - rel0)) if v11 and v11[1] != rel0 else None
        rows.append((ab, pc, wbn, reln, donen))
        print(f"  abs {ab}, pct {pc:4.1f}: card AR_WB_H {wbc}, AR_REL_H {relc} -> AR_WB_H {wbn}, AR_REL_H {reln}, AR_DONE_H {donen}"
              + (f"; release {save} cycles earlier than v11g per on-package access ({frac:.0f}% of v14's {v11[1] - rel0} remains)"
                 if v11 else ""))
    ab, pc, wbn, reln, donen = rows[1]
    print(f"chosen (abs {ab}, pct {pc}): ORAM_AR_WB_H_L7_B{b} {wbn}, ORAM_AR_REL_H_L7_B{b} {reln}, ORAM_AR_DONE_H_L7_B{b} {donen}")
    if opt["write"]:
        for k, v in (("WB", wbn), ("REL", reln), ("DONE", donen)):
            pat = re.compile(r"^(`define ORAM_AR_%s_H_L7_B%d +)\d+" % (k, b), re.M)
            if len(pat.findall(s)) != 1: sys.exit(f"card_budgets.py: ORAM_AR_{k}_H_L7_B{b} not found exactly once")
            s = pat.sub(lambda m: m.group(1) + str(v), s)
        open(opt["params"], "w", newline="").write(s.replace("\n", "\r\n") if crlf else s)
        print(f"written {opt['params']}")


if __name__ == "__main__":
    main(sys.argv[1:])
