#!/bin/bash
# Full regression with Verilator (5.x, --timing). Run from anywhere:
#   bash run_verilator.sh            # everything (~10 min on a laptop)
#   bash run_verilator.sh selftest   # one group: lint | units | selftest | arrival | ni | stress | bp | secure | worst | kernel | crypto | onpkg
#   ORAM_BEATS=8 bash run_verilator.sh      # block size in beats (default 128 = 4 KB)
# Exit code 0 = every check passed. Logs: build/*.log, build/run_*.log
set -u
cd "$(dirname "$0")"
RTL=${RTL_DIR:-../rtl}     # (v14: RTL_DIR=<v11g rtl> TB_DEFS=-DTB_V11G_REF runs the same tests against v11g, for sim/compare_v11g.py)
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
# DOMA serves one client: one ORAM, accesses on demand, no schedule, no dummy accesses.
if [ "${ORAM_CONFIG:-single}" != single ]; then
    echo "only the single-client build exists (the two-client build and its schedule were removed)"; exit 2
fi
ORAM_CONFIG=single; CFG=""; PIDX=1
# block size in 32-byte beats (128 = 4 KB; 1, 2, 4, 8 = 32-256-byte records)
ORAM_BEATS=${ORAM_BEATS:-128}; export ORAM_BEATS
# measured U55C HBM worst-case read latency to the first position (2M samples): 32-byte read 179, 4 KB burst 307
export MEM_L0_MAX=$( [ "${ORAM_BEATS:-128}" = 1 ] && echo 179 || echo 307 )   # 64 B..4 KB: the 4 KB burst worst (budgets.py)
VFLAGS="--binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -I$RTL $CFG -DORAM_BLOCK_BEATS=$ORAM_BEATS"
[ -n "${ORAM_LAMBDA:-}" ] && VFLAGS="$VFLAGS -DORAM_C=$ORAM_LAMBDA"   # lambda (default 6, rtl/oram_params.vh)
VFLAGS="$VFLAGS ${TB_DEFS:-}"
# v14: the on-package budgets of this size and lambda (rtl/oram_params.vh), the HBM write allowance bp(b) of
# sim/budgets_v14.py, and a size's write-back bursts
lamv() { local v; v=$(pval $1_B$ORAM_BEATS); [ "${ORAM_LAMBDA:-6}" = 7 ] && v=$(pval $1_L7_B$ORAM_BEATS); echo $v; }
ZPOS0=$(grep -E '^`define ORAM_Z ' $RTL/oram_params.vh | tr -d '\r' | awk '{print $3}')
BURSTS=$( [ $((ZPOS0 * ORAM_BEATS * 32)) -le 4096 ] && echo 1 || echo $ZPOS0 )   # write bursts of a bucket (axi_master: one, or a block each)
BPB=$(python3 -c "import math; z=$ZPOS0; b=$ORAM_BEATS; n=math.ceil(z*b*32/4096); print(math.ceil(0.05*(z*b+2*n+22)))")
# a value from oram_params.vh
pval() { grep -E "^\`define $1 " $RTL/oram_params.vh | tr -d '\r' | awk '{print $3}' | sed -n "${PIDX}p"; }
CT_WB_BUDGET=$(grep -E "^\`define ORAM_CT_WB_B$ORAM_BEATS " $RTL/oram_params.vh | tr -d '\r' | awk '{print $3}')
CT_WB_BUDGET=${CT_WB_BUDGET:-$(grep -E '^`define ORAM_CT_WB_B128 ' $RTL/oram_params.vh | tr -d '\r' | awk '{print $3}')}   # unlisted size: 4 KB budgets
PM_LAT=$(grep -E '^`define ORAM_PM_LAT ' $RTL/oram_params.vh | tr -d '\r' | awk '{print $3}')   # position-map lookup budget (HBM)
CT_WB_BUDGET=$((CT_WB_BUDGET + PM_LAT))
ZPOS=$(grep -E '^`define ORAM_Z ' $RTL/oram_params.vh | awk '{print $3}')
LEAD=$(( (ZPOS - 1) * ORAM_BEATS ))   # the write-back reaches the last position this many cycles after it starts
GROUP=${1:-all}
mkdir -p build
# cached builds belong to one configuration: start clean when it changes
# the builds depend on the configuration, the block size and lambda: a tree reused at another lambda rebuilds (v11b;
# the check used to omit lambda, so a lambda = 7 run in a lambda = 6 tree of the same size reused lambda 6's builds)
if [ "$(cat build/.config 2>/dev/null)" != "$ORAM_CONFIG beats=$ORAM_BEATS lambda=${ORAM_LAMBDA:-6}" ]; then rm -rf build; mkdir -p build; echo "$ORAM_CONFIG beats=$ORAM_BEATS lambda=${ORAM_LAMBDA:-6}" > build/.config; fi
echo "configuration: $ORAM_CONFIG, block = $ORAM_BEATS beats ($((ORAM_BEATS * 32)) bytes)"
FAILS=0
pass() { echo "  PASS  $1"; }
fail() { echo "  FAIL  $1"; FAILS=$((FAILS+1)); }
want() { [ "$GROUP" = all ] || [ "$GROUP" = "$1" ]; }
build() {   # build <name> <top> <tb file> <extra flags...>
    local name=$1 top=$2 tb=$3; shift 3
    [ -x build/$name/V$name ] && [ -z "${REBUILD:-}" ] && return 0
    echo "  building $name ..."
    local try
    for try in 1 2 3; do
        rm -rf build/$name
        verilator $VFLAGS "$@" --top-module $top ./$tb ./oram_timing_monitor.v ./axi_mem_model.v $SRCS -Mdir build/$name -o V$name \
            > build/$name.build.log 2>&1 && return 0
        # Verilator's own multithreading (-j 0) crashes now and then ("Internal Error: attempted to destroy locked
        # Thread Pool"): retry such a crash; any other build failure is real and stops at once
        grep -q "Internal Error" build/$name.build.log || break
        echo "  verilator crashed building $name (internal error), retry $try"
    done
    echo "  BUILD FAILED: $name (build/$name.build.log)"; exit 2
}
run() { local name=$1 tag=$2; shift 2; ./build/$name/V$name "$@" > build/run_$tag.log 2>&1; }

if want lint; then
    # Vivado rejects out-of-range part-selects that Verilator only warns about (SELRANGE), e.g. a
    # fixed [6:0] slice of a counter that is narrower for small blocks. Fail on any of them.
    echo "== lint: no out-of-range part-selects at this block size"
    n=$(verilator --lint-only -Wno-fatal -Wall -DORAM_SECURE_BUILD -DORAM_BLOCK_BEATS=$ORAM_BEATS -I$RTL \
          --top-module doma_kernel $SRCS $RTL/doma_kernel.v 2>&1 | tee build/lint.log | grep -c "%Warning-SELRANGE")
    e=$(grep -c "^%Error" build/lint.log)
    [ "$n" = 0 ] && [ "$e" = 0 ] && pass "lint: no out-of-range part-selects or errors ($ORAM_BEATS-beat blocks)" \
        || fail "lint: $n out-of-range part-selects, $e errors (build/lint.log)"
    # v14b: the debug build (DEBUG=1) as well
    n=$(verilator --lint-only -Wno-fatal -Wall -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -DORAM_PHASE_TRACE -DORAM_ONPKG_DEBUG -DORAM_BLOCK_BEATS=$ORAM_BEATS -I$RTL \
          --top-module doma_kernel $SRCS $RTL/doma_kernel.v 2>&1 | tee build/lint_dbg.log | grep -c "%Warning-SELRANGE")
    e=$(grep -c "^%Error" build/lint_dbg.log)
    [ "$n" = 0 ] && [ "$e" = 0 ] && pass "lint: the debug build (DEBUG=1) has no out-of-range part-selects or errors" \
        || fail "lint (debug build): $n out-of-range part-selects, $e errors (build/lint_dbg.log)"
    # Vivado treats a name used before its declaration in an instance's port connection as an implicit wire, and
    # then rejects a later constant (localparam) of that name: "already declared" (a later reg it accepts).
    # Verilator accepts both. iverilog -Wimplicit lists the implicit names.
    if command -v iverilog > /dev/null; then
        bad=""
        while IFS= read -r m; do
            f=$(echo "$m" | cut -d: -f1); n=$(echo "$m" | grep -oE "wire '[A-Za-z_0-9]+'" | cut -d"'" -f2)
            # a constant: on a localparam/parameter line, or "NAME = <sized number>" inside a multi-line list
            [ -n "$n" ] && grep -qE "((localparam|parameter)\b[^;]*\b$n\b[[:space:]]*=)|(^[[:space:]]*$n[[:space:]]*=[[:space:]]*[0-9]+'[bdh])|([,(][[:space:]]*$n[[:space:]]*=[[:space:]]*[0-9]+'[bdh])" "$f" && bad="$bad $(basename $f):$n"
        done < <(iverilog -g2012 -Wimplicit -I$RTL -DORAM_BLOCK_BEATS=$ORAM_BEATS -DORAM_SCHED_ARRIVAL -s doma_kernel -o /dev/null $RTL/*.v 2>&1 | grep "implicit definition")
        bad=$(echo $bad | tr " " "\n" | sort -u | tr "\n" " ")
        [ -z "${bad// /}" ] && pass "lint: no constant is used before its declaration (Vivado would reject it)" \
                           || fail "lint: constant used before its declaration (Vivado: already declared): $bad"
    fi
fi
if want units; then
    # the HBM metadata modules alone, against reference models, with the measured HBM latency profile
    # (including a phase where writes land late: a read that overtook a write would be caught)
    echo "== units: HBM position map, bucket records and stash"
    build pmh tb_pmh tb_pmh.v
    run pmh pmh
    grep -q "POS_MAP_HBM: ALL CHECKS PASSED" build/run_pmh.log \
        && pass "pos_map_hbm: $(grep -oE '[0-9]+ reads checked' build/run_pmh.log), reads never overtake writes" \
        || fail "pos_map_hbm unit test (build/run_pmh.log)"
    # lease table, seen from the (untrusted) management port: GRANT and TRANSFER give the caller no token (only the
    # owner's client lane carries it), QUERY returns no token, REVOKE needs both the owner ID and the token
    build lease tb_lease tb_lease.v
    run lease lease
    grep -q "LEASE: PASS" build/run_lease.log \
        && pass "lease table: $(grep -oE '[0-9]+ checks' build/run_lease.log): no token to the management caller, REVOKE needs owner and token" \
        || fail "lease table unit test (build/run_lease.log)"
    build brec tb_brec tb_brec.v
    run brec brec
    grep -q "BUCKET_REC_HBM: ALL CHECKS PASSED" build/run_brec.log \
        && pass "bucket_rec_hbm: $(grep -oE '[0-9]+ checks' build/run_brec.log), record fetches never overtake writes" \
        || fail "bucket_rec_hbm unit test (build/run_brec.log)"
    # stash: windows + chains through a bounded pool, against an exact reference model (eviction order, data,
    # allocated pool indexes, the chain step). Uniform traffic; hot traffic (long chains); a pool smaller than N
    # (free-list recycling); and exhaustion, which must be the ONLY failure and happen exactly when the pool is empty.
    build stash tb_stash tb_stash.v
    run stash stash +acc=3000
    run stash stash_hot +hot=60 +acc=4000
    run stash stash_pool +poolpct=40 +acc=6000
    run stash stash_ovf +pool=60 +hot=60 +acc=4000 +overflow
    run stash stash_dir +directed +acc=2000       # the counterexample for Z candidates: must move in every slot that fits
    # long runs: a chain step after the head's successor was remapped away once re-headed the chain on that block and
    # left a dangling prev link, which corrupted the free list after tens of thousands of accesses (first failures at
    # 31,827 accesses with skewed targets at lambda 6, 90,745 with same-bucket targets, 158,922 with the default pool)
    run stash stash_long_hot  +hot=60  +acc=150000 +seed=13
    run stash stash_long_same +same=50 +acc=150000 +seed=14
    run stash stash_long_def  +acc=200000 +seed=11
    st_ok=1; for v in stash stash_hot stash_pool stash_ovf stash_dir stash_long_hot stash_long_same stash_long_def; do grep -q "STASH_HBM: ALL CHECKS PASSED" build/run_$v.log || st_ok=0; done
    if [ $st_ok = 1 ] && grep -q "fail-stop exactly there" build/run_stash_ovf.log && grep -q "every waiting slot that fits moved in" build/run_stash_dir.log; then
        pass "stash_hbm: $(grep -oE '[0-9]+ accesses, [0-9]+ evictions' build/run_stash.log), long runs of 150,000-200,000 accesses with $(grep -oE '[0-9]+ chain steps' build/run_stash_long_hot.log); hot: longest chain $(grep -oE 'longest chain [0-9]+' build/run_stash_hot.log | grep -oE '[0-9]+'); pool < N recycles; exhaustion is the only failure, exactly when the pool is empty; no read moves in fewer slots than fit (directed counterexample included)"
    else fail "stash_hbm unit tests (build/run_stash*.log)"; fi
    # bucket addresses past 4 GB (4 KB blocks at N = 1M need 5 GB of buckets): every burst of chosen buckets checked
    build addrw tb_addr_wide tb_addr_wide.v -DORAM_N=1048576
    run addrw addrw
    if grep -q "ALL CHECKS PASSED" build/run_addrw.log; then
        pass "axi_master: bucket addresses at N = 1M exact and page-aligned, $(grep -oE '[0-9]+ bursts above 4 GB checked' build/run_addrw.log)"
    else fail "axi_master: bucket addresses at N = 1M (build/run_addrw.log)"; fi
fi
if want units || want crypto; then
    # the two-lane GCM core (aes_gcm_2lane) against the unchanged one-lane core and an independent Python model
    # (gcm2_ref.py: pure-Python AES-128-GCM, self-checked on FIPS-197, the GCM spec and the NIST CAVP vectors)
    echo "== two-lane GCM core: NIST CAVP vectors, bit-exact against the one-lane core, tags, back-to-back, overflow, constant time"
    if python3 gcm2_ref.py gcm gcm_nist_vectors.txt build/gcm2_vec.hex > build/gcm2_ref.log 2>&1 \
       && python3 gcm2_ref.py ghash6 build/ghash6_vec.hex >> build/gcm2_ref.log 2>&1; then
        build gcm2 tb_gcm2 tb_gcm2.v
        build ghash6 tb_ghash6 tb_ghash6.v
        (cd build && ./gcm2/Vgcm2 > run_gcm2.log 2>&1; ./ghash6/Vghash6 +gaps=0 > run_ghash6_0.log 2>&1; ./ghash6/Vghash6 +gaps=1 > run_ghash6_1.log 2>&1)
        if grep -q "GCM2: ALL CHECKS PASSED" build/run_gcm2.log && grep -q "section 1: 45 operations, 0 mismatches" build/run_gcm2.log \
           && grep -q "section 2: 45 operations, 0 mismatches" build/run_gcm2.log; then
            pass "two-lane GCM core: $(grep -oE '[0-9]+ NIST CAVP vectors \([^)]*\)' build/gcm2_ref.log) and $(grep -oE '^GCM2: [0-9]+ operations' build/run_gcm2.log | grep -oE '[0-9]+ operations' | grep -oE '^[0-9]+') operations bit-exact against the one-lane core and the model (messages of 1 to 2,100 blocks, decrypted crosswise), wrong tags rejected, back-to-back, counter overflow in both lanes"
        else fail "two-lane GCM core (build/run_gcm2.log, build/gcm2_ref.log)"; fi
        grep -q "every length one cycle count: yes; start to tag = 23 + beats: yes" build/run_gcm2.log \
            && pass "two-lane GCM core: constant time, $(grep -oE '[0-9]+ timed operations, [0-9]+ lengths' build/run_gcm2.log): start to tag = 23 + beats for any data, key, IV and direction (key setup +$(grep -oE 'key setup adds [0-9]+' build/run_gcm2.log | grep -oE '[0-9]+$'), once per key)" \
            || fail "two-lane GCM core: timing depends on more than the length (build/run_gcm2.log)"
        grep -q "0 mismatches (gaps=0) PASS" build/run_ghash6_0.log && grep -q "0 mismatches (gaps=1) PASS" build/run_ghash6_1.log \
            && pass "GHASH6 unit: 300 random messages match the reference, two- and one-block beats mixed, back-to-back and with gaps" \
            || fail "GHASH6 unit (build/run_ghash6_*.log)"
    else fail "two-lane GCM core: reference self-check or vector generation (build/gcm2_ref.log)"; fi
    # v14: the core's IV advance, which replaces an on-package bucket's encryption, must move the IV exactly as that
    # encryption would have (the first one after reset or a key change seeds): every later encryption identical
    if [ -z "${TB_DEFS:-}" ]; then
        if iverilog -g2012 -I$RTL -o build/ivadv.vvp tb_ivadv.v $RTL/aes_gcm_2lane.v $RTL/aes128_pipe2_fpga.v $RTL/aes128_key_expansion_fpga.v \
             $RTL/aes128_round_fpga.v $RTL/aes_func.v $RTL/ghash_lane6.v $RTL/ghash_lane3.v $RTL/ghash_single_cycle_fpga.v > build/ivadv.build.log 2>&1; then
            vvp -n build/ivadv.vvp > build/run_ivadv.log 2>&1
            grep -q "IVADV: ALL CHECKS PASSED" build/run_ivadv.log \
                && pass "GCM core IV advance (v14): $(grep -oE '[0-9]+ encryptions compared, [0-9]+ replaced by an IV advance' build/run_ivadv.log), seeding after reset and after a key change included: every later IV, ciphertext and tag as if each had been an encryption" \
                || fail "GCM core IV advance (build/run_ivadv.log)"
        else fail "IV advance test build (build/ivadv.build.log)"; fi
        # v14b: the advance written as one XOR mask per output bit (timing) equals the 96-step loop it replaced
        if iverilog -g2012 -I$RTL -o build/lfsr96.vvp tb_lfsr96.v $RTL/aes_gcm_2lane.v $RTL/aes128_pipe2_fpga.v $RTL/aes128_key_expansion_fpga.v \
             $RTL/aes128_round_fpga.v $RTL/aes_func.v $RTL/ghash_lane6.v $RTL/ghash_lane3.v $RTL/ghash_single_cycle_fpga.v > build/lfsr96.build.log 2>&1; then
            vvp -n build/lfsr96.vvp > build/run_lfsr96.log 2>&1
            grep -qE "LFSR96: .* 100096 states, 0 mismatches" build/run_lfsr96.log \
                && pass "GCM core IV LFSR (v14b): the flattened 96-step advance equals the loop on 100,096 states" \
                || fail "GCM core IV LFSR (build/run_lfsr96.log)"
        else fail "IV LFSR test build (build/lfsr96.build.log)"; fi
    fi
fi
if want selftest; then
    build selftest tb_onboard_test_top tb_onboard_test_top.v -DSIMULATION -DORAM_DEBUG_PORTS $RTL/onboard_test_top.v
    run selftest selftest +timing_log=build/timing_selftest.csv
    echo "== onboard self-test (one client) and tamper detection"
    grep -q "ALL 50 RUN TESTS PASSED (3 skipped" build/run_selftest.log \
        && pass "self-test, one client: 50 tests passed (3 two-client tests skipped)" \
        || fail "self-test, one client (build/run_selftest.log)"
    for m in tamper_hole tamper_target; do
        run selftest $m +$m
        grep -q "TAMPER RESULT: DETECTED" build/run_$m.log && pass "$m: detected, controller halted" || fail "$m (build/run_$m.log)"
    done
fi
if want ni || want secure; then
    build ni tb_ni tb_ni.v -DORAM_DEBUG_PORTS
fi
if want ni; then
    echo "== one client: two traffic patterns with correct data"
    ok=1
    for v in 0 1; do      # the variant seeds the client's request pattern
        run ni ni$v +ni=$v +ops=10 $( [ $v = 0 ] && echo +layout_log=build/layout_ni.txt )
        L=$(grep "NI:" build/run_ni$v.log); echo "        $L" | cut -c1-150
        echo "$L" | grep -q "errors=0 .*errors=0 " || ok=0
    done
    [ $ok = 1 ] && pass "one client: data correct in both traffic patterns" || fail "one-client traffic (build/run_ni*.log)"
    # the boot layout of the first run (random direct placement, v11b): see sim/layout_check.py
    NNL=$(pval ORAM_N); CCL=${ORAM_LAMBDA:-$(pval ORAM_C)}
    LCK=$(python3 layout_check.py build/layout_ni.txt $NNL $(( (NNL + CCL - 1) / CCL )) $ZPOS 2>&1) \
        && pass "boot layout (random direct placement): $LCK" || fail "boot layout: $LCK (build/layout_ni.txt)"
    # a request outside the client's lease: flagged, then a dummy access with the same timing and bucket traffic
    # as an admitted one, returning zeros (before the dummy access it made no bucket traffic and never completed)
    run ni ni_viol1 +viol1
    grep -q "VIOL1: PASS" build/run_ni_viol1.log && pass "one client: a rejected request is indistinguishable from an admitted one (timing, bucket traffic), returns zeros" \
        || fail "rejected request differs from an admitted one (build/run_ni_viol1.log)"
fi
if want stress; then
    echo "== worst case: $ZPOS evictions in one access"
    build ni tb_ni tb_ni.v -DORAM_DEBUG_PORTS
    build cal tb_ni tb_ni.v -DORAM_DEBUG_PORTS -DORAM_CT_RD=0 -DORAM_CT_WB=0 -DORAM_CT_DONE=0 -DORAM_TDM_SLOT=20000
    run ni stress +stress +timing_log=build/timing_stress.csv   # its full-bucket evictions complete the worst-case model
    grep -q "evictions in one access=$ZPOS .*ct_overrun=0  data_errors=0" build/run_stress.log \
        && pass "gated: $ZPOS evictions (a full bucket) in one access, no overrun, data correct" || fail "gated stress (build/run_stress.log)"
    run cal stress_cal +stress
    # Streaming write-back: it starts at CT_WB while encryption finishes, so the
    # worst encryption end may exceed CT_WB by up to 7*128 beats (the master
    # needs that long to reach the last position).
    # The worst case is the max over ALL paths, not just the 8-eviction stress:
    # with eviction overlap, two-copy paths (e.g. bucket-hit write + compaction)
    # are slower. So the full self-test is calibrated too.
    build selfcal tb_onboard_test_top tb_onboard_test_top.v -DSIMULATION -DORAM_DEBUG_PORTS \
          -DORAM_CT_RD=0 -DORAM_CT_WB=0 -DORAM_CT_DONE=0 -DORAM_TDM_SLOT=20000 $RTL/onboard_test_top.v
    run selfcal selftest_cal
    a1=$(grep -oE "ct_max_wb=[0-9]+" build/run_stress_cal.log | cut -d= -f2)
    a2=$(grep -oE "CT arrivals: rd=[0-9]+ wb=[0-9]+" build/run_selftest_cal.log | grep -oE "wb=[0-9]+" | cut -d= -f2)
    arr=$(( ${a1:-999999} > ${a2:-999999} ? ${a1:-999999} : ${a2:-999999} ))
    lim=$((CT_WB_BUDGET + LEAD))
    if [ -n "$a1" ] && [ -n "$a2" ] && [ "$arr" -le "$lim" ] && grep -q "data_errors=0" build/run_stress_cal.log \
       && grep -qE "ALL 53 TESTS PASSED|ALL 50 RUN TESTS PASSED" build/run_selftest_cal.log; then
        pass "calibration: worst encryption end $arr (stress $a1, all paths $a2) <= CT_WB + $LEAD = $lim"
    else fail "calibration: encryption end stress=${a1:-?} all-paths=${a2:-?} vs limit $lim (build/run_*_cal.log)"; fi
    # Negative control: a write-back budget far too early (half the calibrated worst
    # encryption end, before re-encryption even starts, for any block size) must be caught
    # (overrun, fail-stop) without the write-back ever reading an unencrypted position.
    EARLY=$(( ${arr:-$CT_WB_BUDGET} / 2 ))
    build early tb_ni tb_ni.v -DORAM_DEBUG_PORTS -DORAM_CT_WB=$EARLY
    run early stress_early +stress
    if grep -q "ct_overrun=1" build/run_stress_early.log && ! grep -q "SAFETY" build/run_stress_early.log; then
        pass "negative control: write-back at $EARLY (too early) caught, no plaintext read"
    else fail "negative control (build/run_stress_early.log)"; fi
fi
if want bp; then
    echo "== AXI backpressure (30% ready-low and read-data gaps, gates off)"
    build cal tb_ni tb_ni.v -DORAM_DEBUG_PORTS -DORAM_CT_RD=0 -DORAM_CT_WB=0 -DORAM_CT_DONE=0 -DORAM_TDM_SLOT=20000
    ok=1
    for v in 1 2; do
        run cal bp$v +ni=$v +ops=8 +bp=30
        grep -qE "NI: variant=$v client[01] ops=8 errors=0 .*client0 ops=[0-9]* errors=0" build/run_bp$v.log || ok=0
    done
    [ $ok = 1 ] && pass "the client active under backpressure: data correct, no integrity error" || fail "backpressure (build/run_bp*.log)"
fi
if want secure; then
    echo "== production configuration (ORAM_SECURE_BUILD, no debug ports)"
    build sec tb_ni tb_ni.v -DORAM_SECURE_BUILD
    # each run of the production build must match the debug build's run of the same variant
    ok=1; refs=""
    for v in 0 1; do
        [ -f build/run_ni$v.log ] || run ni ni$v +ni=$v +ops=10
        ref=$(grep -oE "trace-hash=[0-9a-f]+" build/run_ni$v.log)
        run sec sec$v +ni=$v +ops=10
        [ -n "$ref" ] && grep -q "$ref" build/run_sec$v.log && grep -q "errors=0 .*errors=0" build/run_sec$v.log || ok=0
        refs="$refs ${ref#trace-hash=}"
    done
    [ $ok = 1 ] && pass "secure build behaves identically (trace-hashes$refs) with debug ports removed" || fail "secure build (build/run_sec*.log)"
fi
if want worst; then
    echo "== derived worst case: cycle model validated on every traced access"
    build ni tb_ni tb_ni.v -DORAM_DEBUG_PORTS
    # gap-free bucket delivery and fixed metadata latencies: the derivation is the on-chip worst case; every
    # memory-dependent effect is measured separately (arrival, combined, hostwait)
    run ni worst +worst +timing_log=build/timing_worst.csv +bus_log=build/bus_worst.csv +meta_slow_pct=0 +brec_slow_pct=0 +stash_slow_pct=0
    # Every window must present the bucket read and the write-back on the AXI bus at the
    # same offset from the window start, and read a bucket inside DOMA's bucket range.
    # BUCKET_ID_W is derived in oram_params.vh ($clog2 of ceil(N / lambda)); compute it the same way here
    NNP=$(pval ORAM_N); CCP=$(pval ORAM_C); NBKP=$(( (NNP + CCP - 1) / CCP ))
    BUCKW=0; while [ $(( 1 << BUCKW )) -lt "$NBKP" ]; do BUCKW=$((BUCKW + 1)); done
    PARTW=$(pval ORAM_PART_W)
    if out=$(python3 - "$BUCKW" "$PARTW" <<'PYEOF'
import csv, sys
bw, pw = int(sys.argv[1]), int(sys.argv[2])
r=[x for x in csv.DictReader(open('build/bus_worst.csv')) if None not in x.values() and int(x['ar_offset'])>=0 and int(x['aw_offset'])>=0]
a={x['ar_offset'] for x in r}; w={x['aw_offset'] for x in r}
bad=[x for x in r if (int(x['bucket']) >> bw) != 0]
if r and len(a)==1 and len(w)==1 and not bad: print(len(r), a.pop(), w.pop())
else: print("FAIL", len(a), len(w), len(bad)); sys.exit(1)
PYEOF
    ); then
        set -- $out; pass "bus timing: all $1 windows read at offset $2, write back at offset $3, every bucket in range"
    else fail "bus timing differs between windows or a bucket is out of range ($out; build/bus_worst.csv)"; fi
    grep -q "data_errors=0, ct_overrun=0" build/run_worst.log || fail "directed worst-case scenarios (build/run_worst.log)"
    if [ ! -f build/timing_selftest.csv ]; then
        build selftest tb_onboard_test_top tb_onboard_test_top.v -DSIMULATION -DORAM_DEBUG_PORTS $RTL/onboard_test_top.v
        run selftest selftest +timing_log=build/timing_selftest.csv
    fi
    if python3 worst_case.py --params $RTL/oram_params.vh build/timing_worst.csv build/timing_selftest.csv $( [ -f build/timing_stress.csv ] && echo build/timing_stress.csv ) > build/worst_case.txt 2>&1; then
        pass "derived worst case fits the budget: $(grep -oE 'derived worst encryption end = [^)]*= [0-9]+' build/worst_case.txt | sed -E 's/.*= //' | tr '\n' ' ')vs deadline $(grep -oE 'deadline [0-9]+' build/worst_case.txt | head -1 | cut -d' ' -f2) (build/worst_case.txt)"
    else fail "worst-case analysis (build/worst_case.txt)"; fi
    # v14: the same directed worst cases with every bucket on package (plaintext path, arrival build): its cycle model
    # (sim/worst_case.py, part 4) must explain every access, gap-free
    if [ -z "${TB_DEFS:-}" ]; then
        build ni_ar tb_ni tb_ni.v -DORAM_DEBUG_PORTS -DORAM_SCHED_ARRIVAL
        run ni_ar worst_byp +worst +hbm_bkts=255 +timing_log=build/timing_worst_byp.csv +meta_slow_pct=0 +brec_slow_pct=0 +stash_slow_pct=0
        if grep -q "data_errors=0, ct_overrun=0" build/run_worst_byp.log && \
           python3 worst_case.py --params $RTL/oram_params.vh build/timing_worst_byp.csv > build/worst_case_byp.txt 2>&1; then
            pass "on-package path (v14): cycle model explains every access; $(grep -oE 'derived write-back start after arrival = [^;]*; observed [0-9]+' build/worst_case_byp.txt | head -1); $(grep -oE 'derived release gate after arrival = [^;]*; observed [0-9]+' build/worst_case_byp.txt | head -1) (build/worst_case_byp.txt)"
        else fail "on-package path: directed worst cases or cycle model (build/run_worst_byp.log, build/worst_case_byp.txt)"; fi
    fi
fi
if want combined; then
    # B.3: HBM buckets (fast bucket read), every position-map / stash / record read slow, and tb_ni's directed
    # worst cases, which include a full stash window (9 waiting blocks, one of them requested): the stash can then
    # finish after verification. Arrival mode; reports the worst work after the last beat (ar_max_wb_h).
    echo "== combined adverse case: HBM buckets, slow metadata, full stash window (arrival mode)"
    build ni_ar tb_ni tb_ni.v -DORAM_DEBUG_PORTS -DORAM_SCHED_ARRIVAL
    MEM_L0_MAX=0 run ni_ar combined +worst +hbm_bkts=255 +meta_lat=200 +stash_lat=200 +brec_lat=200 +meta_slow_pct=0 +stash_slow_pct=0 +brec_slow_pct=0 +timing_log=build/timing_combined.csv
    l=$(grep -aoE "ar_max_wb=[0-9]+ ar_max_wb_h=[0-9]+" build/run_combined.log)
    grep -q "data_errors=0, ct_overrun=0" build/run_combined.log && pass "combined adverse case: $l" || fail "combined adverse case (build/run_combined.log)"
    # v14: every bucket is on package here (plaintext path). The cycle model on this trace (every metadata read at 200
    # cycles: the stash's worst) gives the on-package bounds the budgets must cover: AR_WB_H >= the derived write-back
    # start (the early check), AR_REL_H >= the derived release gate plus the HBM write allowance bp(b) (sim/budgets_v14.py)
    if [ -z "${TB_DEFS:-}" ]; then
        AWBH=$(lamv ORAM_AR_WB_H); ARLH=$(lamv ORAM_AR_REL_H)
        if python3 worst_case.py --params $RTL/oram_params.vh build/timing_combined.csv > build/worst_case_combined.txt 2>&1; then
            dwb=$(grep -oE "derived write-back start after arrival = [0-9 +]+= [0-9]+" build/worst_case_combined.txt | grep -oE "[0-9]+$")
            drl=$(grep -oE "derived release gate after arrival = [0-9 +]+= [0-9]+" build/worst_case_combined.txt | grep -oE "[0-9]+$")
            mrl=$(grep -aoE "ar_max_rel_h=[0-9]+" build/run_combined.log | grep -oE "[0-9]+$")
            if [ -n "$dwb" ] && [ -n "$drl" ] && [ "$dwb" -le "$AWBH" ] && [ $((drl + BPB)) -le "$ARLH" ]; then
                pass "on-package budgets cover the derived worst case at 200-cycle metadata reads: write-back start $dwb <= AR_WB_H $AWBH; release gate $drl + bp $BPB <= AR_REL_H $ARLH (measured ${mrl:-?}; build/worst_case_combined.txt)"
            else fail "on-package budgets vs the derived worst case (write-back start ${dwb:-?} vs AR_WB_H $AWBH, release gate ${drl:-?} + $BPB vs AR_REL_H $ARLH; build/worst_case_combined.txt)"; fi
        else fail "on-package cycle model on the combined adverse case (build/worst_case_combined.txt)"; fi
    fi
fi
if want hostwait; then
    # B.5: host buckets with every metadata read slow. Worst case all at once: every bucket in host memory at 240
    # cycles (below the U55C's lowest observed read, 815 ns = 244 cycles at 300 MHz), every metadata read at 200
    # cycles, and tb_ni's directed worst cases including a full stash window. Stash wait = scan start - stash ready.
    # With the one-lane core a host bucket never waited for the stash (its verification outlasted the stash's two
    # dependent HBM reads). With two lanes a small bucket is verified sooner, so at small blocks it can wait; the host
    # budget takes this run's worst (budgets.py: AR_WB = max(derived, measured host) + 54), which must fit AR_WB.
    echo "== host buckets with slow metadata (240-cycle host reads, every metadata read at 200 cycles, full stash window)"
    build ni_ar tb_ni tb_ni.v -DORAM_DEBUG_PORTS -DORAM_SCHED_ARRIVAL
    MEM_L0_MAX=0 run ni_ar hostwait +worst +hbm_bkts=0 +bkt_lat=240 +meta_lat=200 +stash_lat=200 +brec_lat=200 +meta_slow_pct=0 +stash_slow_pct=0 +brec_slow_pct=0 +timing_log=build/timing_hostwait.csv
    hw=$(python3 -c "
import csv
rows=[r for r in csv.DictReader(open('build/timing_hostwait.csv')) if int(r['t_scan'])>=0]
w=[(int(r['t_op']) if int(r['t_op'])>=0 else int(r['t_scan']))-int(r['t_scan']) for r in rows]
print(len(rows), max(w))" 2>/dev/null)
    n=${hw% *}; w=${hw#* }
    arw=$(grep -aoE "ar_max_wb=[0-9]+" build/run_hostwait.log | grep -oE "[0-9]+$")
    dar=""; [ -f build/worst_case.txt ] && dar=$(sed -n "/^timing_worst.csv/,/^timing_selftest.csv/p" build/worst_case.txt | grep -oE "derived after arrival = [0-9 +]+= [0-9]+" | grep -oE "[0-9]+$")
    HWB=$(pval ORAM_AR_WB_B$ORAM_BEATS); [ "${ORAM_LAMBDA:-6}" = 7 ] && HWB=$(pval ORAM_AR_WB_L7_B$ORAM_BEATS)
    grep -q "data_errors=0, ct_overrun=0" build/run_hostwait.log && [ -n "$hw" ] && [ -n "$arw" ] && [ -n "$HWB" ] && [ "$arw" -le "$HWB" ] \
        && pass "host buckets with slow metadata: $n accesses, worst stash wait $w cycles; work after the last beat $arw (derived ${dar:-n/a: run the worst group first}) fits AR_WB = $HWB" \
        || fail "host buckets with slow metadata: stash wait ${w:-?} cycles, work after the last beat ${arw:-?} vs AR_WB ${HWB:-?} (derived ${dar:-?}; build/run_hostwait.log)"
fi
if want kernel && [ $ORAM_CONFIG = single ]; then
    echo "== Vitis kernel wrapper (doma_kernel): the testbench plays XRT"
    build kern tb_doma_kernel tb_doma_kernel.v -DORAM_SECURE_BUILD -Wno-BLKANDNBLK $RTL/doma_kernel.v
    run kern kernel +hb=0
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel.log \
        && pass "kernel: init launch, two command launches, every GET correct, bad key rejected, interrupt and CTRL as XRT expects" \
        || fail "kernel end-to-end (build/run_kernel.log)"
    run kern kernel_gap +hb=0 +cmds=40 +cmds2=10 +host_gap=30
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_gap.log && pass "kernel: 30% host read gaps, correct and unchanged latency" \
        || fail "kernel with host read gaps (build/run_kernel_gap.log)"
    # a lease violation flagged by the core (the kernel's token corrupted for one valid command; host commands
    # cannot cause one): status 4, one dummy access, zero data or an untouched PUT slot, nothing written
    run kern kernel_badtok +hb=0 +cmds=40 +cmds2=10 +badtok
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_badtok.log && grep -q "rejected=1" build/run_kernel_badtok.log \
        && pass "kernel: a lease violation makes a dummy access like any command, returns status 4, writes nothing" \
        || fail "kernel lease violation (build/run_kernel_badtok.log)"
    # The card's HBM returns a record's two beats with a gap. v11b/v11c wrote a record while its second beat was still
    # arriving, at the first placement step: a fail-stop at boot in every card run, never in simulation, whose memory
    # returned the beats back to back. Gaps on the record reads make that ordering visible here.
    run kern kernel_brec_gap +hb=25 +cmds=40 +cmds2=10 +brec_gap=50
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_brec_gap.log \
        && pass "kernel: record reads with gaps between beats, as on the card: boot and accesses correct" \
        || fail "kernel with record read gaps (build/run_kernel_brec_gap.log)"
    # The card's memories return read beats with gaps and hold their ready signals low (backpressure); the simulation's
    # did neither by default, which is how v11b/v11c's boot bug passed. Both at once, on every memory, at every size.
    run kern kernel_card_profile +hb=25 +cmds=40 +cmds2=10 +hbm_gap=20 +hbm_rdy=20 +host_gap=20 +host_rdy=20
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_card_profile.log \
        && pass "kernel: read gaps and backpressure on every memory, as on the card: boot and accesses correct" \
        || fail "kernel under the card-like memory profile (build/run_kernel_card_profile.log)"
    # XRT launches the kernel long after reset. DOMA must boot only at the first ap_start, into
    # the pages buffer given then (booting earlier lays the buckets out at address 0).
    run kern kernel_late +hb=0 +start_delay=20000 +preload +cmds=20 +cmds2=4
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_late.log \
        && pass "kernel: first launch 20,000 cycles after reset, DOMA boots into the right buffer; 256 sequential PUTs correct" \
        || fail "kernel boot before the first launch (build/run_kernel_late.log)"
    # AXI does not order a read against an unacknowledged write. With writes landing 200 cycles
    # after their data the results must be correct; with 700 the slow acknowledgements must be
    # caught as a timing overrun, never returned as stale data (an integrity failure).
    run kern kernel_wlat +hb=0 +cmds=40 +cmds2=4 +host_wlat=60
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_wlat.log && pass "kernel: writes landing 60 cycles after their data (HBM acknowledges in 28), results correct" \
        || fail "kernel with late-landing writes (build/run_kernel_wlat.log)"
    run kern kernel_wlat_slow +hb=0 +cmds=10 +cmds2=4 +host_wlat=1200   # beyond the completion gap at every size (Z = 10, 4 KB: 1,280 beats + 1,200 > 2,000)
    if grep -q "DOMA HALT: timing overrun" build/run_kernel_wlat_slow.log && ! grep -q "DOMA HALT: integrity" build/run_kernel_wlat_slow.log; then
        pass "kernel: write acknowledgements slower than the budget are an overrun, never stale data"
    else fail "read-after-write ordering (build/run_kernel_wlat_slow.log)"; fi
    # Packed records: R-byte records inside each block, written with byte strobes (a masked write
    # merges into the block in the same access); every GET is compared with a byte-exact image of
    # the whole block, so neighbouring records and untouched bytes are checked too.
    run kern kernel_packed +packed=8 +preload +hb=0
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_packed.log \
        && pass "kernel: packed 8-byte records over preloaded blocks match the block image; bad record range rejected" \
        || fail "kernel packed records (build/run_kernel_packed.log)"
    # (late writes and read-side pauses load separate margins; pausing every channel as well
    #  stretches a 4 KB write-back past its completion budget, an overrun regardless of packing)
    run kern kernel_packed_late +packed=16 +host_wlat=60 +host_gap=30 +hb=0
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_packed_late.log \
        && pass "kernel: packed 16-byte records with late writes and read pauses, correct" \
        || fail "kernel packed records under stress (build/run_kernel_packed_late.log)"
    # run-time size (kernel argument nblk): a build with a 4,096-block maximum, run at n = 1,000 (250
    # buckets, packed records, a bad key inside the build's range) and at its maximum. Per-access cost
    # must not depend on n: the device cycles must equal the default build's.
    build kern_rt tb_doma_kernel tb_doma_kernel.v -DORAM_SECURE_BUILD -Wno-BLKANDNBLK -DORAM_N=4096 $RTL/doma_kernel.v
    run kern_rt kernel_rt1000 +hb=0 +nblk=1000 +packed=8 +preload
    run kern_rt kernel_rt4096 +hb=0 +nblk=4096
    c_def=$(grep -oE "^run1: .*device total=[0-9]+" build/run_kernel.log | grep -oE "[0-9]+$")
    c_rt=$(grep -oE "^run1: .*device total=[0-9]+" build/run_kernel_rt4096.log | grep -oE "[0-9]+$")
    if grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_rt1000.log && grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_rt4096.log \
       && [ -n "$c_def" ] && [ "$c_def" = "$c_rt" ]; then
        pass "kernel: run-time size (4,096-block build at n = 1,000 packed and n = 4,096), correct, same cycles as the default ($c_rt)"
    else fail "kernel run-time size (build/run_kernel_rt1000.log, build/run_kernel_rt4096.log; cycles $c_def vs $c_rt)"; fi
    # buckets split between host memory and HBM (fixed boundary, DOMA_HBM_PCT): 25% in HBM (gmem6), packed records
    run kern kernel_hbm25 +hb=0 +hbm_pct=25 +packed=8 +preload
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_hbm25.log \
        && pass "kernel: 25% of the buckets in HBM (second bucket port), packed records, correct" \
        || fail "kernel with 25% of the buckets in HBM (build/run_kernel_hbm25.log)"
    # bounded stash pool (windows + chains): a 4,096-block build at n = 4,092 (the largest multiple of lambda it
    # holds) with the host's sizing for that n, ceil(Claim 1 bound) + 1 = 1,556 entries, and with a much smaller pool
    # (100), which must halt at boot: the random placement (v11b) leaves the excess over Z in the stash (about 5% of n
    # at lambda 6, 9% at lambda 7), so 100 entries cannot hold it.
    PK=""; [ "$ORAM_BEATS" = 1 ] && PK="+packed=8 +preload"      # packed preload: 32-byte blocks only (4 KB exceeds the cycle limit)
    # the host's pool for the largest multiple of lambda <= 4,096 (host_doma.cpp stash_bound, 2^-64): lambda 6: n = 4,092,
    # bound 1,554.4, pool 1,556; lambda 7: n = 4,095, bound 1,678.8, pool 1,680
    if [ "${ORAM_LAMBDA:-6}" = 7 ]; then PNB=4095; PPOOL=1680; PBND=1,678.8; else PNB=4092; PPOOL=1556; PBND=1,554.4; fi
    run kern_rt kernel_pool +hb=0 +nblk=$PNB +pool=$PPOOL +layout_log=build/layout_pool.txt $PK
    run kern_rt kernel_pool_small +hb=0 +nblk=$PNB +pool=100
    # the host's pool must serve everything, the boot included; a pool below the initial excess halts cleanly at boot
    # (stash overflow), before any command
    if grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_pool.log && grep -q "DOMA HALT: stash overflow" build/run_kernel_pool_small.log \
       && grep -qE "^init: .*errors=00000408" build/run_kernel_pool_small.log; then   # 0x408: halted, stash overflow
        pass "kernel: bounded stash pool (lambda ${ORAM_LAMBDA:-6}): the host's $PPOOL entries (bound $PBND, rounded up, + 1) for $PNB blocks serve every access, the boot included; 100 entries halt at boot (stash overflow)"
    else fail "kernel with a bounded stash pool (build/run_kernel_pool*.log)"; fi
    # the boot layout of that run: random direct placement (every slot once, the first Z of a bucket in it, the rest
    # in the stash; per-bucket counts Binomial(n, 1/B))
    LCK=$(python3 layout_check.py build/layout_pool.txt $PNB $(( (PNB + ${ORAM_LAMBDA:-6} - 1) / ${ORAM_LAMBDA:-6} )) $ZPOS 2>&1) \
        && pass "boot layout (random direct placement): $LCK" || fail "boot layout: $LCK (build/layout_pool.txt)"
    # re-boot: an init launch on a booted kernel resets DOMA and boots it with new arguments (n 4,096 ->
    # 1,000, pages buffer moved 16 MB), as a new host process does; no 0x20, every block reads as zeros
    run kern_rt kernel_reboot +hb=0 +nblk=4096 +reboot +nblk2=1000 +pagesoff=16777216 +cmds=40 +cmds2=10
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_reboot.log && grep -q "^reinit: " build/run_kernel_reboot.log \
        && pass "kernel: an init launch re-boots DOMA with new arguments (n 4,096 -> 1,000, pages moved), correct" \
        || fail "kernel re-boot on an init launch (build/run_kernel_reboot.log)"
    # PCIe-like latency beyond the budgets: DOMA must halt and the kernel must still finish the run. The latency is
    # the strict write-back gate (CT_WB + PM_LAT, at least 600 cycles): the bucket has not landed when the write-back
    # must start. (v10e used 600 cycles at every size; with the two-lane core the work at 600 cycles fits the strict
    # budgets of the larger sizes, and nothing overruns.)
    PCIE_LAT=$((CT_WB_BUDGET + PM_LAT)); [ $PCIE_LAT -lt 600 ] && PCIE_LAT=600
    run kern kernel_pcie +hb=0 +cmds=10 +cmds2=4 +host_lat=$PCIE_LAT
    if grep -qE "^run1: size=10 .*errors=00000108" build/run_kernel_pcie.log && grep -qE "^run2: size=4 " build/run_kernel_pcie.log; then   # 0x108: halted, timing overrun
        pass "kernel: budget overrun at $PCIE_LAT-cycle host latency (the strict write-back gate) ends the run with error 0x108 (halted: timing overrun), no hang (budgets need PCIe recalibration)"
    else fail "kernel abort path (build/run_kernel_pcie.log)"; fi
fi
if want boot && [ $ORAM_CONFIG = single ]; then
    # Fixed-time boot (v11b): the random placement is padded to a budget, LAY_BUDGET = n * LAY_TB + (n / 4) * LAY_TS
    # + LAY_BASE cycles from the layout's start (rtl/flat_oram_gcm.v), so the controller is ready at the same cycle
    # whatever the placement: the boot's length must not reveal O_0, the blocks the placement put in the stash. The
    # 4,096-block build at the bounded-pool test's n boots with five placements (the generator started from five
    # states) and four HBM latency profiles (the U55C's; every metadata read at 200 cycles, as the arrival group's
    # adverse case; every read slow; every write acknowledged after 200 cycles). Every boot must be ready at the same
    # cycle after the layout's start, with different stash counts; every slot's placement must fit the per-slot
    # bounds the budget assumes (the write-slow profile, beyond them, must still fit the total). Record reads slower
    # than the budget allows must halt at boot with a timing overrun.
    echo "== boot: fixed-time boot (random placement padded to a budget)"
    build kern_rt tb_doma_kernel tb_doma_kernel.v -DORAM_SECURE_BUILD -Wno-BLKANDNBLK -DORAM_N=4096 $RTL/doma_kernel.v
    if [ "${ORAM_LAMBDA:-6}" = 7 ]; then PNB=4095; PPOOL=1680; else PNB=4092; PPOOL=1556; fi
    LTB=$(pval ORAM_LAY_TB); LTS=$(( $(pval ORAM_LAY_TS0) + (ZPOS + 3) * ORAM_BEATS ))
    ADV="+meta_lat=200 +stash_lat=200 +brec_lat=200 +meta_slow_pct=0 +stash_slow_pct=0 +brec_slow_pct=0"
    SLOW="+meta_slow_pct=100 +stash_slow_pct=100 +brec_slow_pct=100"
    WSLOW="+meta_wlat=200 +stash_wlat=200 +brec_wlat=200"
    bt_ok=1; rdys=""; nsts=""; mb=0; ms=0; wl=""
    for v in "s0:" "s1:+rng_seed=0123456789abcdef" "s2:+rng_seed=fedcba9876543210" "s3:+rng_seed=00000000deadbeef" "s4:+rng_seed=5555aaaa5555aaaa" \
             "adv:+rng_seed=0123456789abcdef $ADV" "slow:+rng_seed=fedcba9876543210 $SLOW" "wslow:+rng_seed=00000000deadbeef $WSLOW"; do
        nm=${v%%:*}; args=${v#*:}
        run kern_rt boot_$nm +hb=0 +nblk=$PNB +pool=$PPOOL +cmds=8 +cmds2=4 $args
        bl=$(grep -a "^BOOT: ready" build/run_boot_$nm.log | head -1)
        grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_boot_$nm.log && [ -n "$bl" ] || { bt_ok=0; echo "   boot_$nm failed (build/run_boot_$nm.log)"; continue; }
        rdys="$rdys $(echo "$bl" | grep -oE "ready [0-9]+" | grep -oE "[0-9]+")"
        nsts="$nsts $(echo "$bl" | grep -oE "[0-9]+ slots placed in the stash" | grep -oE "^[0-9]+")"
        b=$(echo "$bl" | grep -oE "worst slot [0-9]+" | grep -oE "[0-9]+$"); s=$(echo "$bl" | grep -oE "[0-9]+ in the stash$" | grep -oE "^[0-9]+")
        if [ $nm = wslow ]; then wl="$b/$s, done after $(echo "$bl" | grep -oE "done after [0-9]+" | grep -oE "[0-9]+$") of $(echo "$bl" | grep -oE "budget [0-9]+" | grep -oE "[0-9]+$")"
        else [ "$b" -gt $mb ] && mb=$b; [ "$s" -gt $ms ] && ms=$s; fi
    done
    nr=$(echo $rdys | tr ' ' '\n' | sort -u | wc -l); ns=$(echo $nsts | tr ' ' '\n' | sort -u | wc -l)
    if [ $bt_ok = 1 ] && [ "$nr" = 1 ] && [ "$ns" -gt 1 ] && [ $mb -le $LTB ] && [ $ms -le $LTS ]; then
        pass "boot: ready $(echo $rdys | cut -d' ' -f1) cycles after the layout's start in all 8 boots (5 placements, 4 latency profiles; stash at boot:$nsts of $PNB); worst slot placement $mb cycles in its bucket (LAY_TB $LTB), $ms in the stash (LAY_TS $LTS); writes at 200 cycles: $wl"
    else fail "boot: fixed-time boot (ready after:$rdys; stash at boot:$nsts; worst slot $mb/$ms vs LAY_TB $LTB, LAY_TS $LTS; build/run_boot_*.log)"; fi
    # record reads slower than the budget's per-slot bound: the placement overruns, DOMA halts at boot (0x108), the
    # kernel still ends the launch
    run kern_rt boot_over +hb=0 +nblk=$PNB +pool=$PPOOL +cmds=4 +cmds2=4 +brec_lat=$((LTB + LTS))
    if grep -qE "^init: .*errors=00000108" build/run_boot_over.log && grep -q "^BOOT: halted .*timing overrun" build/run_boot_over.log; then
        pass "boot: bucket-record reads at $((LTB + LTS)) cycles overrun the boot budget: halted at boot with error 0x108 (timing overrun), no hang"
    else fail "boot overrun (build/run_boot_over.log)"; fi
fi
if want arrival; then
    # acknowledgements later than the next read, so the read-behind-write guard must hold it: 1,500 cycles at 32 B,
    # 2,500 at 4 KB (its write-back is 1,280 beats; the host model buffers 8,192 beats until they land)
    WSLOW=$([ "${ORAM_BEATS:-1}" = 128 ] && echo 2500 || echo 1500)
    # arrival-relative scheduling (build option ORAM_SCHED_ARRIVAL, for buckets in host memory): the kernel tests
    # at PCIe-like latencies (reads 263 cycles on average, acknowledgements 98, both measured on the U55C), a read
    # at the measured maximum (950), packed records and slow metadata. The worst on-chip work after the arrival
    # (from the worst group's cycle model, and as measured) must fit AR_WB.
    # Every variant first PUTs all n blocks back to back (+preload, as host_doma's initialization does): through
    # v11a the boot's touch pass gave every kernel run these n accesses, and the worst work after the arrival comes
    # from long back-to-back streams like it (v11b has no touch pass; without the preload the measured worst at
    # 4 KB, lambda 7, dropped from 1,903 to 1,629 cycles, by sampling fewer accesses, not by doing less work).
    echo "== arrival: arrival-relative scheduling"
    build kern_ar tb_doma_kernel tb_doma_kernel.v -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -Wno-BLKANDNBLK $RTL/doma_kernel.v
    ar_ok=1; ar_meas=0; ar_meas_h=0; ar_meas_rh=0
    for v in "pcie:+host_lat=263 +host_wlat=98" "pcie_max:+host_lat=950 +host_wlat=98" "packed:+packed=8 +host_lat=263 +host_wlat=98" \
             "slowmeta:+meta_slow_pct=10 +brec_slow_pct=10 +stash_slow_pct=10 +host_lat=263 +host_wlat=98" \
             "hbm20:+hbm_pct=20 +host_lat=263 +host_wlat=98" "hbm50:+hbm_pct=50 +packed=8 +host_lat=263 +host_wlat=98" \
             "hbm50u:+hbm_pct=50 +host_lat=263 +host_wlat=98" "hbm100max:+hbm_pct=100 +hbmb_lat=179 +host_lat=263 +host_wlat=98" \
             "wlat_slow:+nblk=64 +cmds=300 +host_lat=263 +host_wlat=$WSLOW" \
             "hbmadverse:+hbm_pct=100 +hbmb_lat=52 +meta_lat=200 +stash_lat=200 +brec_lat=200 +meta_slow_pct=0 +stash_slow_pct=0 +brec_slow_pct=0"; do
        nm=${v%%:*}; args=${v#*:}
        run kern_ar kernel_ar_$nm +hb=0 +preload $args
        grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_ar_$nm.log || { ar_ok=0; echo "   $nm failed (build/run_kernel_ar_$nm.log)"; }
        m=$(grep -oE "ar_max_wb=[0-9]+" build/run_kernel_ar_$nm.log | head -1 | cut -d= -f2); [ -n "$m" ] && [ "$m" -gt "$ar_meas" ] && ar_meas=$m
        m=$(grep -oE "ar_max_wb_h=[0-9]+" build/run_kernel_ar_$nm.log | head -1 | cut -d= -f2); [ -n "$m" ] && [ "$m" -gt "${ar_meas_h:-0}" ] && ar_meas_h=$m
        m=$(grep -oE "ar_max_rel_h=[0-9]+" build/run_kernel_ar_$nm.log | head -1 | cut -d= -f2); [ -n "$m" ] && [ "$m" -gt "${ar_meas_rh:-0}" ] && ar_meas_rh=$m
    done
    lat=$(grep -oE "^run1: .*latency min/max=[0-9/]+" build/run_kernel_ar_pcie.log | grep -oE "[0-9]+/[0-9]+$")
    [ $ar_ok = 1 ] && pass "arrival: kernel tests correct at PCIe-like latencies (per command $lat cycles), at a 950-cycle read, packed, slow metadata, 20/50/100% of the buckets in HBM" \
                   || fail "arrival-relative kernel tests"
    # GET or PUT must not show in the timing: the same 300 keys as all GETs and as all PUTs, identical bucket-port timing
    for k in kern_ar kern; do
        [ -x build/$k/V$k ] || continue
        la=$([ $k = kern_ar ] && echo "+host_lat=263 +host_wlat=98")     # strict mode: its own (non-PCIe) budgets, default latencies
        run $k uni0_$k   +hb=0 +preload +cmds=300 +cmds2=4 $la +seed=3 +put_pct=0
        run $k uni100_$k +hb=0 +preload +cmds=300 +cmds2=4 $la +seed=3 +put_pct=100
        u0=$(grep -E "^run1: bucket-port" build/run_uni0_$k.log); u1=$(grep -E "^run1: bucket-port" build/run_uni100_$k.log)
        d0=$(grep -oE "^run1: size.*device total=[0-9]+" build/run_uni0_$k.log | grep -oE "[0-9]+$")
        d1=$(grep -oE "^run1: size.*device total=[0-9]+" build/run_uni100_$k.log | grep -oE "[0-9]+$")
        md=$([ $k = kern ] && echo strict || echo arrival)
        if [ -n "$u0" ] && [ "$u0" = "$u1" ] && [ "$d0" = "$d1" ] && grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_uni0_$k.log \
           && grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_uni100_$k.log; then
            pass "$md: GETs and PUTs indistinguishable: same keys, all GETs vs all PUTs, identical bucket-port timing ($(echo "$u0" | grep -oE 'hash [0-9a-f]+'), $d0 cycles)"
        else fail "$md: bucket-port timing differs between all-GET and all-PUT streams (build/run_uni*_$k.log)"; fi
    done
    c0=$(grep -oE "^run1: .*device total=[0-9]+" build/run_kernel_ar_pcie.log | grep -oE "[0-9]+$")
    c50=$(grep -oE "^run1: .*device total=[0-9]+" build/run_kernel_ar_hbm50u.log | grep -oE "[0-9]+$")
    # A performance property, reported, not checked: an HBM bucket's write-back point is set by the stash (every metadata
    # read at 200 cycles), a host bucket's by its own work after the last beat. With the two-lane core the host's work
    # shrank and the stash's did not, so at small blocks HBM buckets no longer pay (they did with one lane at lambda 6).
    [ -n "$c0" ] && [ -n "$c50" ] && echo "  INFO  arrival (lambda ${ORAM_LAMBDA:-6}): 50% of the buckets in HBM vs 0%: $c50 vs $c0 cycles ($( [ "$c50" -lt "$c0" ] && echo "HBM faster" || echo "HBM not faster"); a performance property, not checked)"
    ARWB=$(pval ORAM_AR_WB_B$ORAM_BEATS)      # every size has its own budgets (was: only 32 B and 4 KB were checked)
    [ "${ORAM_LAMBDA:-6}" = 7 ] && ARWB=$(pval ORAM_AR_WB_L7_B$ORAM_BEATS)   # lambda 7: its own host budgets (v11b)
    der=""   # the derived after-arrival bound (worst group, gap-free trace), counted from the last beat
    [ -f build/worst_case.txt ] && der=$(sed -n "/^timing_worst.csv/,/^timing_selftest.csv/p" build/worst_case.txt | grep -oE "derived after arrival = [0-9 +]+= [0-9]+" | grep -oE "[0-9]+$")
    if [ -n "$ARWB" ]; then
        if [ "$ar_meas" -le "$ARWB" ] && { [ -z "$der" ] || [ "$der" -le "$ARWB" ]; }; then
            pass "arrival: worst work after the arrival fits AR_WB = $ARWB (measured $ar_meas, derived ${der:-n/a: run the worst group first})"
        else fail "arrival: worst work after the arrival exceeds AR_WB = $ARWB (measured $ar_meas, derived ${der:-n/a})"; fi
    fi
    ARWBH=$(pval ORAM_AR_WB_H_B$ORAM_BEATS); [ "${ORAM_LAMBDA:-6}" = 7 ] && ARWBH=$(pval ORAM_AR_WB_H_L7_B$ORAM_BEATS)
    if [ -n "$ARWBH" ]; then
        if [ "${ar_meas_h:-0}" -gt 0 ] && [ "${ar_meas_h:-0}" -le "$ARWBH" ]; then
            pass "arrival: HBM buckets' worst work after the arrival fits AR_WB_H = $ARWBH (measured ${ar_meas_h}, every HBM metadata read at 200 cycles)"
        else fail "arrival: HBM buckets' worst work after the arrival vs AR_WB_H = $ARWBH (measured ${ar_meas_h:-none})"; fi
    fi
    # v14: on package, the write handed off and the release gate reached: the worst must fit AR_REL_H
    if [ -z "${TB_DEFS:-}" ]; then
        ARLH=$(lamv ORAM_AR_REL_H)
        if [ "${ar_meas_rh:-0}" -gt 0 ] && [ "$ar_meas_rh" -le "$ARLH" ]; then
            pass "arrival (v14): on package, the release gate is reached at worst $ar_meas_rh cycles after the arrival, within AR_REL_H = $ARLH"
        else fail "arrival: on-package release gate ${ar_meas_rh:-none} vs AR_REL_H = $ARLH"; fi
    fi
fi
if want onpkg && [ -n "${TB_DEFS:-}" ]; then
    # reference mode (v11g's RTL, sim/compare_v11g.py): the on-package group's runs with an off-package side, unchecked
    build kern_ar tb_doma_kernel tb_doma_kernel.v -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -Wno-BLKANDNBLK $RTL/doma_kernel.v
    run kern_ar onpkg20 +hb=0 +junk_mem +host_lat=263 +host_wlat=98 +hbm_pct=20 +preload
    build kern_ar_tr tb_doma_kernel tb_doma_kernel.v -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -DORAM_PHASE_TRACE -Wno-BLKANDNBLK $RTL/doma_kernel.v
    run kern_ar_tr onpkg_trace +hb=0 +hbm_pct=50 +phase_trace +cmds=200 +cmds2=10 +host_lat=263 +host_wlat=98
fi
if want onpkg && [ -z "${TB_DEFS:-}" ]; then
    # v14: on-package buckets in plaintext (arrival build).
    echo "== on package (v14): plaintext buckets, fixed observable times, slow HBM"
    build kern_ar tb_doma_kernel tb_doma_kernel.v -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -Wno-BLKANDNBLK $RTL/doma_kernel.v
    ARLH=$(lamv ORAM_AR_REL_H); ADVM="+meta_lat=200 +stash_lat=200 +brec_lat=200 +meta_slow_pct=0 +stash_slow_pct=0 +brec_slow_pct=0"
    # (a) contents: every bucket on package, and 20%: every GET checked, then every bucket's memory: on-package buckets
    #     hold their blocks in plaintext; off-package ones ciphertext that verifies under the record's IV and tag
    #     (independent GCM model, sim/gcm2_ref.py) and decrypts to the blocks, no position in plaintext
    ok=1; il=""
    # (+junk_mem: the bucket memories start with junk, so never-written blocks read and inspect as zeros only if the
    #  boot wrote every bucket, the on-package ones with zeros)
    for v in "onpkg100:+hbm_pct=100" "onpkg20:+hbm_pct=20 +preload"; do
        nm=${v%%:*}; a=${v#*:}
        run kern_ar $nm +hb=0 +junk_mem +host_lat=263 +host_wlat=98 $a +inspect=build/inspect_$nm.txt
        if grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_$nm.log && python3 inspect_check.py build/inspect_$nm.txt > build/inspect_$nm.out 2>&1; then
            il="$il; ${nm#onpkg}%: $(grep -oE 'PASS: .*' build/inspect_$nm.out | cut -c7-)"
        else ok=0; echo "   $nm failed (build/run_$nm.log, build/inspect_$nm.out)"; fi
        rm -f build/inspect_$nm.txt
    done
    [ $ok = 1 ] && pass "on package: every GET correct at 100% and 20% on package$il" || fail "on-package contents (build/run_onpkg*.log, build/inspect_*.out)"
    # (b) the observable times of an on-package access (release, end) do not depend on the stash's history or speed:
    #     two histories (after a preload of every block; from the empty boot state, other keys), and the stash and all
    #     metadata at 200 cycles a read; each launch's 200 accesses must all release and end at one offset, the same
    opl() { grep -E "^run1: on-package release/end" build/run_$1.log; }
    run kern_ar onpkg_hist_a +hb=0 +hbm_pct=100 +preload +seed=3 +cmds=200 +cmds2=4
    run kern_ar onpkg_hist_b +hb=0 +hbm_pct=100 +seed=11 +put_pct=70 +cmds=200 +cmds2=4
    run kern_ar onpkg_hist_adv +hb=0 +hbm_pct=100 +preload +seed=3 +cmds=200 +cmds2=4 $ADVM
    la=$(opl onpkg_hist_a); lb=$(opl onpkg_hist_b); lc=$(opl onpkg_hist_adv)
    one() { echo "$1" | grep -qE "release ([0-9]+)\.\.\1, end ([0-9]+)\.\.\2 "; }
    if [ -n "$la" ] && [ "$la" = "$lb" ] && [ "$la" = "$lc" ] && one "$la" && grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_onpkg_hist_a.log \
       && grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_onpkg_hist_b.log && grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_onpkg_hist_adv.log; then
        pass "on package: release and end fixed across stash histories and stash speed (preloaded, empty with other keys, metadata at 200 cycles): $(echo "$la" | grep -oE 'hash [0-9a-f]+ over [0-9]+ accesses \(release [0-9.]+, end [0-9.]+')"
    else fail "on-package observable times differ between histories (build/run_onpkg_hist_*.log)"; fi
    # (c) slow HBM within the bound: the stash and metadata at 200 cycles a read and the HBM bucket port holding each write
    #     burst's data for H cycles (H x bursts ~ bp(b) + 60, inside the allowance and the margin): nothing moves
    H=$(( (BPB + 60) / BURSTS ))
    run kern_ar onpkg_slow +hb=0 +hbm_pct=100 +preload +seed=3 +cmds=200 +cmds2=4 $ADVM +hbmb_whold=$H
    ls_=$(opl onpkg_slow)
    if [ -n "$ls_" ] && [ "$ls_" = "$la" ] && grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_onpkg_slow.log; then
        pass "on package, slow HBM within the bound (metadata at 200 cycles, every write burst held $H cycles): release and end unchanged, no overrun"
    else fail "on-package slow HBM within the bound (build/run_onpkg_slow.log)"; fi
    # (e) the phase trace (ORAM_PHASE_TRACE builds, host_phases): an on-package access's crypto phases take zero cycles,
    #     its 16 slots stay in order; an off-package access's take time
    build kern_ar_tr tb_doma_kernel tb_doma_kernel.v -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -DORAM_PHASE_TRACE -Wno-BLKANDNBLK $RTL/doma_kernel.v
    run kern_ar_tr onpkg_trace +hb=0 +hbm_pct=50 +phase_trace +cmds=200 +cmds2=10 +host_lat=263 +host_wlat=98
    pt=$(grep -E "^run1: phase trace:" build/run_onpkg_trace.log)
    if grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_onpkg_trace.log && echo "$pt" | grep -q "; 0 bad"; then
        pass "phase trace: $(echo "$pt" | sed -E 's/^run1: phase trace: //; s/; 0 bad//')"
    else fail "phase trace on package (build/run_onpkg_trace.log)"; fi
    # (d) beyond it: from the 51st access on, every write burst held AR_REL_H cycles. The write is not handed off by the
    #     release time: a timing overrun (0x108, as on the host path) raised at exactly t_arr + AR_REL_H; every access
    #     before it released at the usual offset; the kernel ends the launch (no hang) and the next launch reports the halt
    run kern_ar onpkg_over +hb=0 +hbm_pct=100 +seed=3 +cmds=200 +cmds2=4 +hbmb_whold=$ARLH +hbmb_whold_at=50
    lo=$(grep -E "^run1: on-package release/end" build/run_onpkg_over.log)
    rel_a=$(echo "$la" | grep -oE "release [0-9]+" | grep -oE "[0-9]+")
    if grep -qE "^run1: size=200 .*errors=00000108" build/run_onpkg_over.log && grep -qE "^run2: size=4 " build/run_onpkg_over.log \
       && grep -qE "^OVERRUN-AT: state [0-9]+, raised in access cycle [0-9]+, $ARLH cycles after the bucket's last beat \(arrival seen 1\), on-package 1" build/run_onpkg_over.log \
       && echo "$lo" | grep -qE "over 50 accesses \(release $rel_a\.\.$rel_a,"; then
        pass "on package, slow HBM beyond the bound: halted with 0x108 (timing overrun) raised at the release time itself, $ARLH cycles after the arrival; the 50 accesses before released at the usual offset ($rel_a); no hang"
    else fail "on-package overrun (build/run_onpkg_over.log)"; fi
    # (f) v14b, the halt record names the deadline and the cycles missed: the same slow HBM, with the next launch only
    #     after the halting access has ended (+halt_wait, as on the card), then a slow stash from the 20th access (the
    #     decisions, so the write-back start, late as well). The first launch's record may be a lower bound ("at least",
    #     the access still running); the next one's must be final and equal the testbench's own measure.
    hr_ok=1; hr_l=""
    for v in "onpkg_hr_w:+hbmb_whold=$ARLH +hbmb_whold_at=50" "onpkg_hr_s:+stash_slow=600 +stash_slow_at=20"; do
        nm=${v%%:*}; a=${v#*:}
        run kern_ar $nm +hb=0 +hbm_pct=100 +seed=3 +cmds=200 +cmds2=4 +halt_wait=60000 $a
        hz=$(grep -oE "^HALTING-ACCESS: write-back issued -?[0-9]+ and release gate reached [0-9]+" build/run_$nm.log | grep -oE "[0-9]+$")
        if [ -n "$hz" ] && grep -qE "^run1: halt record: state [0-9]+, .*\(HBM\), on-package deadline \(2\) hand-off by the release, missed by (at least )?[0-9]+ cycles" build/run_$nm.log \
           && grep -qE "^run2: halt record: .*on-package deadline \(2\) hand-off by the release, missed by $((hz - ARLH)) cycles, memory-unit errors 000" build/run_$nm.log; then
            hr_l="$hr_l; slow ${nm#onpkg_hr_}: state $(grep -oE '^run2: halt record: state [0-9]+' build/run_$nm.log | grep -oE '[0-9]+$'), missed by $((hz - ARLH))"
        else hr_ok=0; echo "   $nm: halt record not as expected (build/run_$nm.log)"; fi
    done
    [ $hr_ok = 1 ] && pass "halt record (v14b): the deadline named, the cycles missed final in the next launch and equal to the testbench's (${hr_l#; }; w = write, s = stash)" \
                   || fail "halt record (build/run_onpkg_hr_*.log)"
    # (g) v14b debug build (DEBUG=1: ORAM_ONPKG_DEBUG with the phase trace): an on-package overrun is recorded and
    #     counted, never halts; every access's record (64-byte trace records) equals the testbench's own timestamps,
    #     its deadline flags follow from them, and the counters and the first-overrun records match the tallies.
    #     Slow writes from the 51st access (deadline (2) only); a slow stash from the 21st (deadline (1), on the accesses
    #     whose stash open reads the most).
    build kern_dbg tb_doma_kernel tb_doma_kernel.v -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -DORAM_PHASE_TRACE -DORAM_ONPKG_DEBUG -Wno-BLKANDNBLK $RTL/doma_kernel.v
    run kern_dbg onpkg_dbg_w +hb=0 +hbm_pct=100 +seed=3 +cmds=200 +cmds2=4 +phase_trace +hbmb_whold=$ARLH +hbmb_whold_at=50
    run kern_dbg onpkg_dbg_s +hb=0 +hbm_pct=100 +seed=3 +cmds=200 +cmds2=4 +phase_trace +stash_slow=600 +stash_slow_at=20
    dw=$(grep -E "^run2: debug counters" build/run_onpkg_dbg_w.log); ds=$(grep -E "^run2: debug counters" build/run_onpkg_dbg_s.log)
    if grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_onpkg_dbg_w.log && grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_onpkg_dbg_s.log \
       && [ "$(grep -cE '^run[12]: debug records: .*; 0 bad' build/run_onpkg_dbg_w.log)" = 2 ] && [ "$(grep -cE '^run[12]: debug records: .*; 0 bad' build/run_onpkg_dbg_s.log)" = 2 ] \
       && echo "$dw" | grep -qE "deadline \(1\) missed 0 .*deadline \(2\) missed 154 " && grep -qE "^run1: debug first overrun: deadline 2, state 22, access 50," build/run_onpkg_dbg_w.log \
       && echo "$ds" | grep -qE "deadline \(1\) missed [1-9][0-9]* " && grep -qE "^run1: debug first overrun: deadline 1, state [0-9]+, access [0-9]+," build/run_onpkg_dbg_s.log \
       && ! grep -qE "errors=0000010|errors=00000008" build/run_onpkg_dbg_w.log build/run_onpkg_dbg_s.log; then
        pass "debug build (v14b): overruns recorded, not halted, every GET correct; 408 per-access records equal to the testbench's own timestamps; counters and first-overrun records match (slow write: $(echo "$dw" | grep -oE 'deadline \(2\) missed [0-9]+ \(worst by [0-9]+\)'); slow stash: $(echo "$ds" | grep -oE 'deadline \(1\) missed [0-9]+ \(worst by [0-9]+\)'))"
    else fail "debug build (build/run_onpkg_dbg_*.log)"; fi
    # (h) v14b interim budgets (build.sh INTERIM=1: ORAM_ONPKG_INTERIM; 4 KB, lambda 7 only): every stash and record read
    #     at 500 cycles fits, the release and end stay fixed across that speed and the stash's history, and beyond the
    #     bound the controller halts at exactly the interim release time with deadline (2) named
    if [ "$ORAM_BEATS" = 128 ] && [ "${ORAM_LAMBDA:-6}" = 7 ]; then
        build kern_int tb_doma_kernel tb_doma_kernel.v -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -DORAM_ONPKG_INTERIM -Wno-BLKANDNBLK $RTL/doma_kernel.v
        ILH=$(pval ORAM_AR_REL_H_L7I_B128)
        run kern_int onpkg_int_a +hb=0 +hbm_pct=100 +preload +seed=3 +cmds=200 +cmds2=4
        run kern_int onpkg_int_s +hb=0 +hbm_pct=100 +preload +seed=3 +cmds=200 +cmds2=4 +stash_slow=500 +stash_slow_at=1 +brec_lat=500 +brec_slow_pct=0
        run kern_int onpkg_int_o +hb=0 +hbm_pct=100 +seed=3 +cmds=200 +cmds2=4 +hbmb_whold=$ILH +hbmb_whold_at=50 +halt_wait=60000
        ia=$(opl onpkg_int_a); is=$(opl onpkg_int_s)
        if [ -n "$ia" ] && [ "$ia" = "$is" ] && one "$ia" && grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_onpkg_int_a.log \
           && grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_onpkg_int_s.log \
           && grep -qE "^OVERRUN-AT: state [0-9]+, raised in access cycle [0-9]+, $ILH cycles after the bucket's last beat \(arrival seen 1\), on-package 1" build/run_onpkg_int_o.log \
           && grep -qE "^run2: halt record: .*on-package deadline \(2\) hand-off by the release, missed by [0-9]+ cycles" build/run_onpkg_int_o.log; then
            pass "interim budgets (v14b, INTERIM=1, AR_REL_H $ILH): stash and records at 500 cycles fit; release and end fixed ($(echo "$ia" | grep -oE 'release [0-9.]+, end [0-9.]+')); beyond the bound a halt at t_arr + $ILH, deadline (2) named"
        else fail "interim budgets (build/run_onpkg_int_*.log)"; fi
    fi
fi
if want crypto; then
    echo "== crypto units: AES-128 known answers, GHASH against an independent reference"
    if iverilog -g2001 -s tb_kat -o build/kat.vvp tb_aes_kat.v $RTL/aes128_round_fpga.v $RTL/aes128_key_expansion_fpga.v $RTL/aes_func.v > build/kat.build.log 2>&1; then
        vvp -n build/kat.vvp > build/run_kat.log 2>&1
        [ "$(grep -c 'MATCHES FIPS-197' build/run_kat.log)" = 2 ] && pass "AES-128 pipeline: FIPS-197 Appendix B and C.1 known answers" || fail "AES known answers (build/run_kat.log)"
    else fail "AES known-answer build (build/kat.build.log)"; fi
    if python3 ghash_ref.py build/vec.hex > build/ghash_ref.log 2>&1 && iverilog -g2001 -s tb_ghash -o build/ghash.vvp tb_ghash.v $RTL/ghash_lane3.v $RTL/ghash_single_cycle_fpga.v > build/ghash.build.log 2>&1; then
        (cd build && vvp -n ghash.vvp +gaps=0 > run_ghash0.log 2>&1; vvp -n ghash.vvp +gaps=1 > run_ghash1.log 2>&1)
        grep -q "0 mismatches (gaps=0) PASS" build/run_ghash0.log && grep -q "0 mismatches (gaps=1) PASS" build/run_ghash1.log \
            && pass "GHASH unit: 300 random messages match the reference (self-checked on GCM test case 2), back-to-back and with gaps" \
            || fail "GHASH unit (build/run_ghash*.log)"
    else fail "GHASH test build (build/ghash_ref.log, build/ghash.build.log)"; fi
fi
# End to end: every bucket written must match the reference's bit for bit. sim/golden_bucket_digests.txt holds the
# digests of the reference RTL (its "# Reference:" line; v11b: v11b itself) under these testbenches and the same
# stimulus (sim/golden_digests.sh); only timing may differ.
GOLD=golden_bucket_digests.txt
if [ -f $GOLD ]; then
    ng=0; nh=0; badg=""
    for f in build/run_*.log; do
        [ -f "$f" ] || continue
        tag=$(basename "$f" .log); tag=${tag#run_}
        g=$(awk -v l="${ORAM_LAMBDA:-6}" -v b="$ORAM_BEATS" -v t="$tag" '$1 == l && $2 == b && $3 == t { $1 = $2 = $3 = ""; sub(/^ +/, ""); print; exit }' $GOLD)
        [ -n "$g" ] || continue
        d=$(grep -a "^bucket writes:" "$f" | tail -1)
        # v14: an arrival build keeps on-package buckets in plaintext, so there only the host-memory (off-package)
        # part must match the reference; tb_ni's single-port runs with every bucket on package have none
        case "$tag" in
            combined|worst_byp) continue ;;
            kernel_ar_*|uni*_kern_ar|onpkg*) case "$d" in *"; HBM 0 beats"*) ;; *) d=${d%%; HBM *}; g=${g%%; HBM *}; nh=$((nh + 1)) ;; esac ;;
        esac
        ng=$((ng + 1)); [ "$d" = "$g" ] || badg="$badg $tag"
    done
    GREF=$(grep -m1 "^# Reference:" $GOLD | sed -E 's/^# Reference: ([^ ]+ [^ ]+).*/\1/'); GREF=${GREF:-v10e}
    if [ -n "$badg" ]; then fail "bucket writes differ from the reference's ($GREF) in:$badg ($GOLD)"
    elif [ $ng -gt 0 ]; then pass "end to end: every bucket written is bit-identical to the reference's ($GREF) in all $ng kernel/ni runs that have a reference ($GOLD); of them $nh arrival runs with buckets on package: every host-memory bucket (on-package ones are plaintext by design)"; fi
fi
# every run's bucket-write digest, for a reference made from this package's own outputs (sim/golden_from_logs.py);
# runs that halt on purpose are left out (where they stop depends on timing)
for f in build/run_*.log; do
    [ -f "$f" ] || continue
    d=$(grep -a "^bucket writes:" "$f" | tail -1); [ -n "$d" ] || continue
    grep -aq "DOMA HALT" "$f" && continue
    tag=$(basename "$f" .log); echo "  DIGEST ${ORAM_LAMBDA:-6} $ORAM_BEATS ${tag#run_} $d"
done
# no run may report a safety-monitor violation or a scratch bank conflict
if grep -lE "SAFETY VIOLATION|SCRATCH: bank conflict" build/run_*.log 2>/dev/null | grep -q .; then
    fail "safety monitor / bank conflict reported in: $(grep -lE 'SAFETY VIOLATION|SCRATCH: bank conflict' build/run_*.log | tr '\n' ' ')"
else pass "no safety-monitor violations or scratch bank conflicts in any run"; fi
echo
if [ $FAILS = 0 ]; then echo "ALL CHECKS PASSED"; exit 0; else echo "$FAILS CHECK(S) FAILED"; exit 1; fi
