#!/bin/bash
# run_tinyoram_sizes.sh -- the block sizes added on 2026-10-19 (512 B, 1 KB, 2 KB; README §21), each as a native
# build of depth L = 6 and as a run-time-depth build of L_max = 18, merged adapter (the configuration of queue entries
# q13/q14; SZS="128 256 4k" checks q10-q12 the same way). With 2 cores, about 1.5 hours; SIZES_SET=lint runs only stages 1-2 (a few minutes).
#   1. The every-module lint (lint_tinyoram.sh) of all six geometries; 8, 16 and 32 B refused by the fetch.
#   2. TinyRTGeo (patch 08) against each new size's native constants at L = 6..22 (tb_rtgeo_probe.v).
#   3. Per size, the native L = 6 build and the L_max = 18 build started at L = 6 run the regression's tests (e2e,
#      preload, gaps, late writes, packed 8-byte records, record ranges, a tree-top split, slow acknowledgements,
#      32 keys); both must pass, with the same per-launch lines, the same tree bursts in the same cycles and the same
#      block bytes (run_tinyoram_rteq.sh's equivalence). 1 KB and 2 KB also at L = 10 on L_max = 18 against a native
#      L = 10 build: PosMap recursion depth 2, with a preload of all 4,096 blocks.
#   4. The L_max = 18 builds alone: a re-boot from one depth to another, both sessions correct. (An unsupported depth is
#      size-independent wrapper logic, checked by run_tinyoram_rteq.sh; here it would run a 6.9 GB tree at L_max.)
# The testbench's reference arrays are capped at 4,096 blocks (-DTB_NMAX): every run here is at L <= 10.
# At 2 KB the command and response buffers are 16 MB (-DTB_CMD_WORDS), for the L = 10 preload's 4,096 PUTs of 2 KB.
# Exit 0 = every check passed; last line "ALL n CHECKS PASSED". Logs: build_tinyoram/sizes/
set -u
cd "$(dirname "$0")"
TOR=../tinyoram
B=build_tinyoram/sizes; mkdir -p $B
[ -f $TOR/upstream/TinyORAMCore.v ] || bash $TOR/fetch_tinyoram.sh 4k > /dev/null || exit 2
VFLAGS="--binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-WIDTH -Wno-ZERODLY -Wno-BLKANDNBLK"
SZS=${SZS:-"512 1k 2k"}
FAILS=0; NCHK=0
pass() { echo "  PASS  $1"; NCHK=$((NCHK+1)); }
fail() { echo "  FAIL  $1"; FAILS=$((FAILS+1)); NCHK=$((NCHK+1)); }
fetch_geo() {   # fetch_geo <dir> <fetch args...>: a private fetch (the shared ../tinyoram/build is left alone)
    local d=$1; shift; rm -rf $d; mkdir -p $d
    cp $TOR/fetch_tinyoram.sh $d/ && cp -r $TOR/config $TOR/patches $d/ && ln -s $(cd $TOR && pwd)/upstream $d/upstream
    bash $d/fetch_tinyoram.sh "$@" > $d/fetch.log 2>&1
}
mk() {   # mk <name> <tree buffer words> <fetch args...>: a private fetch and a Verilator build (kept between runs)
    local name=$1 words=$2; shift 2; local g=$B/$name
    local cw=$((1 << 18)); [ "$1" = 2k ] && cw=$((1 << 19)); [ "$1" = 4k ] && cw=$((1 << 20))   # command/response buffers: 4,096 PUTs of 2 KB need 16 MB, of 4 KB 32 MB
    [ -x $g/obj/Vtb ] && [ -z "${REBUILD:-}" ] && return 0
    fetch_geo $g "$@" || { echo "  FETCH FAILED: $name ($g/fetch.log)"; exit 2; }
    echo "  building $name ($(tail -1 $g/fetch.log | sed -E 's/.*configuration //')) ..."
    verilator $VFLAGS -I$g/build/src -DSIMULATION -DTB_HOST_WORDS=$words -DTB_NMAX=4096 -DTB_CMD_WORDS=$cw --top-module tb_tinyoram_kernel ./tb_tinyoram_kernel.v ./axi_mem_model.v \
        $TOR/rtl/tinyoram_kernel.v $TOR/rtl/tinyoram_axi_adapter.v $(sed "s#^#$g/build/src/#" $g/build/src/files.f | tr '\n' ' ') \
        -Mdir $g/obj -o Vtb > $g/build.log 2>&1 || { echo "  BUILD FAILED: $name ($g/build.log)"; exit 2; }
}
run() { local name=$1 tag=$2; shift 2; ( ulimit -s unlimited 2>/dev/null; ./$B/$name/obj/Vtb +hb=0 "$@" > $B/$tag.log 2>&1 ); }
ok() { grep -q "TINYORAM KERNEL: ALL CHECKS PASSED" $B/$1.log && ! grep -qE "ERROR|Error:" $B/$1.log; }
lines() { grep -E "^[a-z0-9]+: (size=|latency to|traffic record|tree data hash)|^read-behind-write hold|^NOTE" $B/$1.log; }
eqpair() {   # eqpair <native build> <rt build> <L> <label> <tb args...>  (as run_tinyoram_rteq.sh)
    local nb=$1 rb=$2 L=$3 lab=$4; shift 4; local t=${lab// /_}; t=${t//=/}
    run $nb n_$t +axitrace "$@" & run $rb r_$t +axitrace +rtl=$L "$@" & wait
    grep "^T " $B/n_$t.log > $B/n_$t.trace; grep "^T " $B/r_$t.log > $B/r_$t.trace
    local why=""
    ok n_$t || why="native fails ($B/n_$t.log)"
    [ -z "$why" ] && { ok r_$t || why="run-time build fails ($B/r_$t.log)"; }
    [ -z "$why" ] && { cmp -s <(lines n_$t) <(lines r_$t) || why="per-launch lines differ (diff $B/n_$t.log $B/r_$t.log)"; }
    [ -z "$why" ] && { cmp -s $B/n_$t.trace $B/r_$t.trace || why="tree bursts differ: $(diff $B/n_$t.trace $B/r_$t.trace | head -2 | tr '\n' ' ')"; }
    if [ -z "$why" ]; then pass "$lab: both correct and identical ($(wc -l < $B/n_$t.trace) bursts; $(grep -oE 'run1: size=[0-9]+ .*latency min/max=[0-9/]+' $B/n_$t.log | grep -oE 'latency min/max=[0-9/]+'))"
        rm -f $B/n_$t.log $B/r_$t.log
    else fail "$lab: $why"; fi
}
bytes() { case $1 in 1k) echo 1024 ;; 2k) echo 2048 ;; 4k) echo 4096 ;; *) echo $1 ;; esac; }

echo "== 1. every-module lint: native L = 6 and run-time L_max = 18, merged"
for sz in $SZS; do for v in "6:merge" "18:merge rtdepth"; do
    L=${v%%:*}; o=${v#*:}; t=${sz}_L$L; [ $L = 18 ] && t=${t}_rt; g=$B/geo_$t
    if ! fetch_geo $g $sz $L $o; then fail "$sz B L=$L ($o): fetch ($g/fetch.log)"; continue; fi
    conf=$(tail -1 $g/fetch.log | sed -E 's/.*configuration //')
    bash ./lint_tinyoram.sh $g/build/src $g/build/src/tinyoram_config.vh $B/lint_$t > $B/lint_$t.out 2>&1 \
        && pass "$sz B, L=$L$([ $L = 18 ] && echo ' (run-time depth, L_max)'), merged: lint, every module, no undeclared names or zero replications ($conf)" \
        || { fail "$sz B L=$L: lint ($B/lint_$t.out)"; sed 's/^/        /' $B/lint_$t.out | head -8; }
done; done
for s in 8 16 32; do
    fetch_geo $B/geo_$s $s 6 merge && fail "$s B: the fetch accepted it" \
        || { grep -q "not a Tiny ORAM block size" $B/geo_$s/fetch.log && pass "$s B: the fetch refuses it and names packing (README §21)" || fail "$s B: unexpected fetch message ($B/geo_$s/fetch.log)"; }
done

echo "== 2. TinyRTGeo against the native constants"
g=$B/geo_probe; np=0; nbad=""
for sz in $SZS; do for L in $(seq 6 22); do
    fetch_geo $g $sz $L || { nbad="$nbad $sz/$L(fetch)"; continue; }
    iverilog -g2012 -I$g/build/src -o $g/a.out -s probe ./tb_rtgeo_probe.v $g/build/src/TinyRTGeo.v > $g/c.log 2>&1 || { nbad="$nbad $sz/$L(compile)"; continue; }
    vvp -n $g/a.out > $g/p_${sz}_$L.log 2>&1; np=$((np+1)); cp $g/p_${sz}_$L.log $B/
    grep -q " 0 mismatches" $g/p_${sz}_$L.log || nbad="$nbad $sz/$L"
done; done
[ -z "$nbad" ] && pass "TinyRTGeo equals the native constants at $np geometries ($SZS; L = 6..22)" || fail "TinyRTGeo differs at:$nbad ($B/p_*.log)"
[ "${SIZES_SET:-full}" = lint ] && { [ $FAILS = 0 ] && { echo "ALL $NCHK CHECKS PASSED"; exit 0; } || { echo "$FAILS OF $NCHK CHECKS FAILED"; exit 1; }; }

echo "== 3. native against run-time depth (L_max = 18), merged"
for sz in $SZS; do
    bb=$(bytes $sz)
    # the tree buffer, the same for every build of a size (the testbench's random stream depends on it): 32 MB, or
    # 64 MB at 4 KB (its L = 10 tree is 56 MB)
    W=1048576; [ $bb = 4096 ] && W=2097152
    mk n${sz}_6 $W $sz 6 merge; mk r${sz}_18 $W $sz 18 merge rtdepth
    big=0; [ $bb -ge 1024 ] && big=1
    c="+cmds=120 +cmds2=40"; c2="+cmds=40 +cmds2=10"; sa=2000; [ $big = 1 ] && { c="+cmds=60 +cmds2=20"; c2="+cmds=20 +cmds2=6"; sa=4000; }
    [ $bb = 4096 ] && { c="+cmds=40 +cmds2=12"; c2="+cmds=12 +cmds2=4"; sa=6000; }   # as run_tinyoram_rteq.sh at 4 KB
    top=$(( bb * 256 )); [ $top -lt 16384 ] && top=16384     # a tree-top split inside the L = 6 tree, a multiple of 4 KB
    p="$sz B, L=6 on L_max=18"
    eqpair n${sz}_6 r${sz}_18 6 "$p e2e"      $c
    eqpair n${sz}_6 r${sz}_18 6 "$p preload"  +preload $c2
    eqpair n${sz}_6 r${sz}_18 6 "$p gaps"     +host_rdy_gap=30 +host_gap=30 $c2
    eqpair n${sz}_6 r${sz}_18 6 "$p wlat"     +host_wlat=200 +preload $c2
    eqpair n${sz}_6 r${sz}_18 6 "$p packed8"  +packed=8 +preload $c2
    eqpair n${sz}_6 r${sz}_18 6 "$p ranges"   +ranges +preload +host_gap=30 $c2
    eqpair n${sz}_6 r${sz}_18 6 "$p split"    +top=$top +packed=8 +preload +host_gap=30 +host_rdy_gap=30 $c2
    eqpair n${sz}_6 r${sz}_18 6 "$p slowack"  +preload +host_wlat_after=$sa $c2
    eqpair n${sz}_6 r${sz}_18 6 "$p keys"     +keys=32 +packed=8 $c
    if [ $big = 1 ]; then   # PosMap recursion depth 2 (L = 10: 4,096 blocks, final PosMap 32 / 16 entries)
        mk n${sz}_10 $W $sz 10 merge
        p="$sz B, L=10 on L_max=18"
        eqpair n${sz}_10 r${sz}_18 10 "$p preload" +preload +cmds=20 +cmds2=6
        eqpair n${sz}_10 r${sz}_18 10 "$p keys"    +keys=64 +packed=8 +cmds=60 +cmds2=20
        t10=$(( bb * 2048 )); [ $t10 -gt 4194304 ] && t10=4194304       # the testbench's top buffer is 4 MB
        eqpair n${sz}_10 r${sz}_18 10 "$p split"   +top=$t10 +keys=64 +host_gap=30 +cmds=40 +cmds2=10
    fi
done

echo "== 4. the L_max = 18 builds alone"
for sz in $SZS; do
    run r${sz}_18 reb_$sz +rtl=8 +reboot +rtl2=6 +packed=8 +preload +cmds=20 +cmds2=6
    ok reb_$sz && pass "$sz B L_max=18: re-boot from L=8 to L=6, both sessions correct" || fail "$sz B re-boot ($B/reb_$sz.log)"
done
[ $FAILS = 0 ] && { echo "ALL $NCHK CHECKS PASSED"; exit 0; }
echo "$FAILS OF $NCHK CHECKS FAILED"; exit 1
