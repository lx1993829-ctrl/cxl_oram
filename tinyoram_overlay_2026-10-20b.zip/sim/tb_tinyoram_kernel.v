// tb_tinyoram_kernel.v -- end-to-end test of the tinyoram_kernel Vitis wrapper, the testbench
// playing XRT (same structure as tb_doma_kernel.v):
//   run 0: size = 0      (init launch: latches pages, reports geometry, touches no memory)
//   [+preload: N sequential PUTs, keys 0..N-1, like host_doma's initialization; the first launch
//    with size > 0 zero-fills the tree and starts Tiny ORAM]
//   run "one": a single command (a prefetch left from it must not leak into the next run)
//   run 1: +cmds commands (random GET/PUT over keys 0..N-1), every GET checked
//   run 2: +cmds2 commands, one of them an out-of-range key that must come back rejected
//   +packed=R: R-byte records packed into each block (offset and length in the command header), as in
//          tb_doma_kernel.v. A PUT carries junk outside its record; every GET returns only its record
//          (checked byte-exact against an image of the block) and must leave the rest of its response
//          slot untouched. Run 2's bad command is a PUT whose range runs past the block (status 0x40).
//          A final "verify" launch GETs whole blocks (length 0), checking every byte of the image, and
//          ends with four bad ranges (past the end, offset beyond the block, a wrapping length, longer
//          than the block): each must come back 0x40 with its data slot untouched; then the check order
//          of doma_kernel: bad range and bad key is 0x40 for a PUT, 0x4 for a GET.
//   +reboot: after the runs above, a second init launch with the tree buffer moved (as a new host process
//          gets when XRT keeps the xclbin loaded): the init must touch no memory; the next launches must be
//          correct against a fresh reference (never-written blocks, so in packed mode the first record of a
//          block must come back with zeros around it); then a command launch naming yet another buffer
//          must report 0x20, keep using the latched one, and still be correct. No tree access may fall
//          outside the latched buffer at any time. In packed mode the second session starts with a probe:
//          one record into each of blocks 0..7, then whole-block GETs of them (zeros around the record).
//          +reboot_same: the same with the tree buffer at the same address.
//   +berr=K: after init (and +preload), the K-th write response on the tree port in the next run is SLVERR:
//          the run must end without hanging, with error 0x8 in the summary and on the affected command's
//          header; then an init launch re-boots (tree buffer moved) and a fresh run must be correct
//   +ranges (implies +packed=8 if no +packed): records at random byte offsets and lengths (crossing beat
//          boundaries anywhere, up to the whole block), with one command in eight a whole-block command.
//   +keys=K: commands use only K keys, N/K apart (keys repeat, so GETs check earlier PUTs; with N/K at least the
//          leaves per PosMap block, every key is in its own PosMap block and the PLB keeps missing)
// The tree memory starts full of garbage (stale HBM); the kernel must zero it before use.
// No gmem2 access may happen before the first ap_start.
// Options: +cmds=N +cmds2=N +seed=N +host_lat=N +host_gap=P +host_rdy_gap=P +host_wlat=N
//          (+host_wlat: every write burst lands N cycles after its own last beat)
//          +start_delay=N +preload +packed=R +ranges +reboot +hb=N +limit=N
// Build configuration: tinyoram_config.vh on the include path (tinyoram/config/tinyoram_config_<size>.vh);
// -DTB_HOST_WORDS=<32-byte words> enlarges the tree buffer for large-N builds (default 4 MB).
// -DTB_NMAX=<blocks> sizes the reference arrays for at most that many blocks instead of the build's N (a run-time-depth
// build with a large L_max run at a small depth: 2 KB blocks at L_max = 18 would need 2.4 GB); a run at more blocks fails.
`timescale 1ns/1ps
`include "tinyoram_config.vh"   // TINYORAM_ORAMB / TINYORAM_ORAML of this build
module tb_tinyoram_kernel;
    localparam integer DW = 256, NMAX = 4 << `TINYORAM_ORAML, REC = `TINYORAM_ORAMB / 256, SLOTW = REC, BLK = REC * 32;   // block-sized slots
    // N: the build's blocks, or (TINYORAM_RTDEPTH, +rtl=L) the active depth's, 4 << L; arrays are sized for NMAX
    integer N = NMAX, tb_rtl = 0, tb_rtl2 = 0;
`ifdef TB_NMAX
    localparam integer NARR = (`TB_NMAX < NMAX) ? `TB_NMAX : NMAX;  // reference arrays: at most this many blocks
`else
    localparam integer NARR = NMAX;
`endif
    task chk_n; input [8*8-1:0] where; begin
        if (N > NARR) begin $display("FAIL: %0s: %0d blocks, but the reference arrays hold %0d (-DTB_NMAX)", where, N, NARR); $finish; end
    end endtask
// -DTB_WF_DEPTH=<beats>, -DTB_AW_DEPTH=<bursts>: write beats and bursts the tree models hold until they land
// (axi_mem_model WF_DEPTH, AW_DEPTH; defaults 8192 and 4096, a whole 4 KB path write-back), so late
// acknowledgements are not throttled by the model: every write of a path can still be unacknowledged when the
// next path's reads want to start, as with posted writes to host memory
`ifndef TB_WF_DEPTH
`define TB_WF_DEPTH 8192
`endif
`ifndef TB_AW_DEPTH
`define TB_AW_DEPTH 4096
`endif
// -DTB_CMD_WORDS=<32-byte words> enlarges the command and response buffers (default 8 MB: 4,096 commands of up to
// 1 KB data each; 4,096 commands of 2 KB need 1 << 19). A launch whose data does not fit fails.
`ifdef TB_CMD_WORDS
    localparam integer CMD_WORDS = `TB_CMD_WORDS;
`else
    localparam integer CMD_WORDS = 1 << 18;
`endif
`ifdef TB_HOST_WORDS
    localparam integer HOST_WORDS = `TB_HOST_WORDS;           // tree buffer in 32-byte words (large-N builds)
`else
    localparam integer HOST_WORDS = 1 << 18;                  // 8 MB: two L = 6 trees at any block size (+reboot moves it)
`endif
    // The tree and tree-top buffers start 16 KB below a 4 GB boundary, so every tree crosses one: the adapter's and
    // the zero-fill's base + offset must carry into bit 32 (a 32-bit sum wraps, and the address monitor catches it)
    localparam [63:0] TOP_BASE = 64'h0000_0040_ffff_c000;     // the tree top's buffer (on-package HBM)
    localparam [63:0] CMD_BASE = 64'h0000_0040_0000_0000, RESP_BASE = 64'h0000_0040_1000_0000,
                      HOST_BASE = 64'h0000_7eff_ffff_c000;
    reg clk = 0, rst_n = 0;
    always #1.667 clk = ~clk;                                  // ~300 MHz

    // ---------------- AXI-Lite master ----------------
    reg  [11:0] awaddr = 0, araddr = 0; reg awvalid = 0, wvalid = 0, bready = 0, arvalid = 0, rready = 0;
    reg  [31:0] wdata = 0; wire awready, wready, bvalid, arready, rvalid; wire [31:0] rdata; wire [1:0] bresp, rresp;
    wire irq;
    // ---------------- AXI masters ----------------
    wire [63:0] g0_araddr, g1_awaddr, g2_araddr, g2_awaddr, g0_awaddr, g1_araddr;
    wire [7:0]  g0_arlen, g1_awlen, g2_arlen, g2_awlen, g0_awlen, g1_arlen;
    wire g0_arvalid, g0_arready, g0_rlast, g0_rvalid, g0_rready, g1_awvalid, g1_awready, g1_wlast, g1_wvalid, g1_wready,
         g1_bvalid, g1_bready, g2_arvalid, g2_arready, g2_rlast, g2_rvalid, g2_rready, g2_awvalid, g2_awready,
         g2_wlast, g2_wvalid, g2_wready, g2_bvalid, g2_bready, g2_bv, g1_gate, g1_awready_m, g1_wready_m;
    wire [DW-1:0] g0_rdata, g1_wdata, g2_rdata, g2_wdata; wire [DW/8-1:0] g1_wstrb, g2_wstrb;
    wire [63:0] g3_araddr, g3_awaddr; wire [7:0] g3_arlen, g3_awlen;
    wire g3_arvalid, g3_arready, g3_rlast, g3_rvalid, g3_rready, g3_awvalid, g3_awready, g3_wlast, g3_wvalid, g3_wready, g3_bvalid, g3_bready;
    wire [DW-1:0] g3_rdata, g3_wdata; wire [DW/8-1:0] g3_wstrb;

    tinyoram_kernel dut (
        .ap_clk(clk), .ap_rst_n(rst_n),
        .s_axi_control_awaddr(awaddr), .s_axi_control_awvalid(awvalid), .s_axi_control_awready(awready),
        .s_axi_control_wdata(wdata), .s_axi_control_wstrb(4'hF), .s_axi_control_wvalid(wvalid), .s_axi_control_wready(wready),
        .s_axi_control_bresp(bresp), .s_axi_control_bvalid(bvalid), .s_axi_control_bready(bready),
        .s_axi_control_araddr(araddr), .s_axi_control_arvalid(arvalid), .s_axi_control_arready(arready),
        .s_axi_control_rdata(rdata), .s_axi_control_rresp(rresp), .s_axi_control_rvalid(rvalid), .s_axi_control_rready(rready),
        .interrupt(irq),
        .m_axi_gmem0_araddr(g0_araddr), .m_axi_gmem0_arlen(g0_arlen), .m_axi_gmem0_arsize(), .m_axi_gmem0_arburst(),
        .m_axi_gmem0_arvalid(g0_arvalid), .m_axi_gmem0_arready(g0_arready), .m_axi_gmem0_rdata(g0_rdata),
        .m_axi_gmem0_rresp(2'b00), .m_axi_gmem0_rlast(g0_rlast), .m_axi_gmem0_rvalid(g0_rvalid), .m_axi_gmem0_rready(g0_rready),
        .m_axi_gmem0_awaddr(g0_awaddr), .m_axi_gmem0_awlen(g0_awlen), .m_axi_gmem0_awsize(), .m_axi_gmem0_awburst(),
        .m_axi_gmem0_awvalid(), .m_axi_gmem0_awready(1'b1), .m_axi_gmem0_wdata(), .m_axi_gmem0_wstrb(), .m_axi_gmem0_wlast(),
        .m_axi_gmem0_wvalid(), .m_axi_gmem0_wready(1'b1), .m_axi_gmem0_bresp(2'b00), .m_axi_gmem0_bvalid(1'b0), .m_axi_gmem0_bready(),
        .m_axi_gmem1_araddr(g1_araddr), .m_axi_gmem1_arlen(g1_arlen), .m_axi_gmem1_arsize(), .m_axi_gmem1_arburst(),
        .m_axi_gmem1_arvalid(), .m_axi_gmem1_arready(1'b1), .m_axi_gmem1_rdata({DW{1'b0}}), .m_axi_gmem1_rresp(2'b00),
        .m_axi_gmem1_rlast(1'b0), .m_axi_gmem1_rvalid(1'b0), .m_axi_gmem1_rready(),
        .m_axi_gmem1_awaddr(g1_awaddr), .m_axi_gmem1_awlen(g1_awlen), .m_axi_gmem1_awsize(), .m_axi_gmem1_awburst(),
        .m_axi_gmem1_awvalid(g1_awvalid), .m_axi_gmem1_awready(g1_awready_m && !g1_gate), .m_axi_gmem1_wdata(g1_wdata),
        .m_axi_gmem1_wstrb(g1_wstrb), .m_axi_gmem1_wlast(g1_wlast), .m_axi_gmem1_wvalid(g1_wvalid), .m_axi_gmem1_wready(g1_wready_m && !g1_gate),
        .m_axi_gmem1_bresp(2'b00), .m_axi_gmem1_bvalid(g1_bvalid), .m_axi_gmem1_bready(g1_bready),
        .m_axi_gmem2_araddr(g2_araddr), .m_axi_gmem2_arlen(g2_arlen), .m_axi_gmem2_arsize(), .m_axi_gmem2_arburst(),
        .m_axi_gmem2_arvalid(g2_arvalid), .m_axi_gmem2_arready(g2_arready), .m_axi_gmem2_rdata(g2_rdata),
        .m_axi_gmem2_rresp(2'b00), .m_axi_gmem2_rlast(g2_rlast), .m_axi_gmem2_rvalid(g2_rvalid), .m_axi_gmem2_rready(g2_rready),
        .m_axi_gmem2_awaddr(g2_awaddr), .m_axi_gmem2_awlen(g2_awlen), .m_axi_gmem2_awsize(), .m_axi_gmem2_awburst(),
        .m_axi_gmem2_awvalid(g2_awvalid), .m_axi_gmem2_awready(g2_awready), .m_axi_gmem2_wdata(g2_wdata),
        .m_axi_gmem2_wstrb(g2_wstrb), .m_axi_gmem2_wlast(g2_wlast), .m_axi_gmem2_wvalid(g2_wvalid), .m_axi_gmem2_wready(g2_wready),
        .m_axi_gmem2_bresp(berr_now ? 2'b10 : 2'b00), .m_axi_gmem2_bvalid(g2_bv), .m_axi_gmem2_bready(g2_bready),
        .m_axi_gmem3_araddr(g3_araddr), .m_axi_gmem3_arlen(g3_arlen), .m_axi_gmem3_arsize(), .m_axi_gmem3_arburst(),
        .m_axi_gmem3_arvalid(g3_arvalid), .m_axi_gmem3_arready(g3_arready), .m_axi_gmem3_rdata(g3_rdata),
        .m_axi_gmem3_rresp(2'b00), .m_axi_gmem3_rlast(g3_rlast), .m_axi_gmem3_rvalid(g3_rvalid), .m_axi_gmem3_rready(g3_rready),
        .m_axi_gmem3_awaddr(g3_awaddr), .m_axi_gmem3_awlen(g3_awlen), .m_axi_gmem3_awsize(), .m_axi_gmem3_awburst(),
        .m_axi_gmem3_awvalid(g3_awvalid), .m_axi_gmem3_awready(g3_awready), .m_axi_gmem3_wdata(g3_wdata),
        .m_axi_gmem3_wstrb(g3_wstrb), .m_axi_gmem3_wlast(g3_wlast), .m_axi_gmem3_wvalid(g3_wvalid), .m_axi_gmem3_wready(g3_wready),
        .m_axi_gmem3_bresp(2'b00), .m_axi_gmem3_bvalid(g3_bvalid), .m_axi_gmem3_bready(g3_bready)
    );
    // the tree top in on-package memory: shorter latency than the tree buffer (host memory)
    axi_mem_model #(.WF_DEPTH(`TB_WF_DEPTH), .AW_DEPTH(`TB_AW_DEPTH), .DW(DW), .WORDS(1 << 17), .BASE(TOP_BASE), .RLAT(40)) u_top (
        .clk(clk), .rst_n(rst_n), .araddr(g3_araddr), .arlen(g3_arlen), .arvalid(g3_arvalid), .arready(g3_arready),
        .rdata(g3_rdata), .rresp(), .rlast(g3_rlast), .rvalid(g3_rvalid), .rready(g3_rready),
        .awaddr(g3_awaddr), .awlen(g3_awlen), .awvalid(g3_awvalid), .awready(g3_awready), .wdata(g3_wdata), .wstrb(g3_wstrb),
        .wlast(g3_wlast), .wvalid(g3_wvalid), .wready(g3_wready), .bresp(), .bvalid(g3_bvalid), .bready(g3_bready));
    // HBM buffers for commands and responses, and the tree region (4 MB)
    axi_mem_model #(.DW(DW), .WORDS(CMD_WORDS), .BASE(CMD_BASE), .RLAT(40)) u_cmd (
        .clk(clk), .rst_n(rst_n), .araddr(g0_araddr), .arlen(g0_arlen), .arvalid(g0_arvalid), .arready(g0_arready),
        .rdata(g0_rdata), .rresp(), .rlast(g0_rlast), .rvalid(g0_rvalid), .rready(g0_rready),
        .awaddr(64'd0), .awlen(8'd0), .awvalid(1'b0), .awready(), .wdata({DW{1'b0}}), .wstrb({(DW/8){1'b0}}),
        .wlast(1'b0), .wvalid(1'b0), .wready(), .bresp(), .bvalid(), .bready(1'b1));
    axi_mem_model #(.DW(DW), .WORDS(CMD_WORDS), .BASE(RESP_BASE), .RLAT(40)) u_resp (
        .clk(clk), .rst_n(rst_n), .araddr(64'd0), .arlen(8'd0), .arvalid(1'b0), .arready(), .rdata(), .rresp(), .rlast(), .rvalid(), .rready(1'b1),
        .awaddr(g1_awaddr), .awlen(g1_awlen), .awvalid(g1_awvalid && !g1_gate), .awready(g1_awready_m), .wdata(g1_wdata), .wstrb(g1_wstrb),
        .wlast(g1_wlast), .wvalid(g1_wvalid && !g1_gate), .wready(g1_wready_m), .bresp(), .bvalid(g1_bvalid), .bready(g1_bready));
    assign g1_awready = g1_awready_m && !g1_gate;                   // the response port as the kernel sees it
    assign g1_wready  = g1_wready_m && !g1_gate;
    axi_mem_model #(.WF_DEPTH(`TB_WF_DEPTH), .AW_DEPTH(`TB_AW_DEPTH), .DW(DW), .WORDS(HOST_WORDS), .BASE(HOST_BASE), .RLAT(100)) u_host (
        .clk(clk), .rst_n(rst_n), .araddr(g2_araddr), .arlen(g2_arlen), .arvalid(g2_arvalid), .arready(g2_arready),
        .rdata(g2_rdata), .rresp(), .rlast(g2_rlast), .rvalid(g2_rvalid), .rready(g2_rready),
        .awaddr(g2_awaddr), .awlen(g2_awlen), .awvalid(g2_awvalid), .awready(g2_awready), .wdata(g2_wdata), .wstrb(g2_wstrb),
        .wlast(g2_wlast), .wvalid(g2_wvalid), .wready(g2_wready), .bresp(), .bvalid(g2_bvalid), .bready(g2_bready));

    // ---------------- AXI-Lite tasks (what XRT does), as in tb_doma_kernel ----------------
    task axil_wr; input [11:0] a; input [31:0] d; begin
        @(negedge clk); awaddr = a; wdata = d; awvalid = 1; wvalid = 1;
        while (!bvalid) @(negedge clk);
        awvalid = 0; wvalid = 0; bready = 1;
        @(negedge clk); bready = 0;
    end endtask
    task axil_rd; input [11:0] a; output [31:0] d; begin
        @(negedge clk); araddr = a; arvalid = 1;
        while (!rvalid) @(negedge clk);
        d = rdata; arvalid = 0; rready = 1;
        @(negedge clk); rready = 0;
    end endtask

    // ---------------- host-side state ----------------
    integer last_put [0:NARR-1];            // command id of the last PUT to each key, -1 = never written
    integer cmd_key [0:4095], cmd_type [0:4095], cmd_id [0:4095];
    integer gid = 0, fails = 0, seed, ncmd1, ncmd2, hl, hg, uninit_gets = 0;
    reg     started = 0;
    reg     axitrace; initial axitrace = $test$plusargs("axitrace");   // +axitrace (see below)
    integer rec_len = 0, bad_stat = 4;
    integer kset = 0;   // +keys=K (0 = any key): repeated keys, each in its own PosMap block when N/K >= the leaves per block
    // xorshift32 generators (as in tb_stash.v): Verilator's $random(seed) gives degenerate, shifting-bit
    // sequences that touch few distinct values. rs: commands and the stale tree contents; ps: packed mode's
    // own stream (record offsets and lengths, junk around records), so unpacked runs draw the same commands
    reg [31:0] rs = 32'h2545F491, ps = 32'h9E3779B9;
    function [31:0] rnd;  input dummy; begin rs = rs ^ (rs << 13); rs = rs ^ (rs >> 17); rs = rs ^ (rs << 5); rnd = rs; end endfunction
    function [31:0] prnd; input dummy; begin ps = ps ^ (ps << 13); ps = ps ^ (ps >> 17); ps = ps ^ (ps << 5); prnd = ps; end endfunction
    reg [63:0] pages_arg = HOST_BASE;    // the pages argument of the next launch
    reg [63:0] latched   = HOST_BASE;    // the buffer the kernel should be using (set by init launches)
    reg [31:0] exp_errs  = 32'h0;        // expected summary error flags of the next launch
    reg        relaxed   = 1'b0;         // a run with an injected fault: only the summary and traffic are checked
    reg        berr_arm  = 1'b0;         // +berr=K: SLVERR on the K-th write response on gmem2 after arming
    integer    berr_k = -1, bcnt = 0, berr_cmd = -1;   // berr_cmd: the command whose write got the error
    // after a release, instead of the K-th response (berr_mode; the error must still reach that command):
    //   +berr_rel    the first write response while a released command's header waits for its acknowledgements
    //   +berr_last   the same, but the last one outstanding (its B and the error show in the same cycle)
    //   +berr_early  a released GET's data write is stalled (the response port holds AWREADY/WREADY low, as a
    //                slave may) while one of its tree writes is unacknowledged; that response is SLVERR, so the
    //                error shows after the release and before the GET's header is queued
    reg        berr_rel = 1'b0, berr_done = 1'b0, berr_hold = 1'b0;
    integer    berr_mode = 0;                                       // 1 rel, 2 last, 3 early
    wire       hq_wait = dut.hq_v && dut.hq_ackw;
    wire       berr_pick = !berr_rel ? (bcnt == berr_k) : berr_done ? 1'b0 :
                           (berr_mode == 1) ? hq_wait :
                           (berr_mode == 2) ? (hq_wait && dut.u_adapt.b_out == 16'd1 && dut.a_quiet_w) :
                                              (dut.released && !dut.ack_seen && !hq_wait && !dut.cput);
    assign     g1_gate = berr_arm && berr_mode == 3 && !berr_done && dut.released && !dut.cput && !hq_wait &&
                         dut.u_adapt.b_out != 16'd0;
    assign     g2_bv   = g2_bvalid;
    wire       berr_now = berr_arm && g2_bv && (berr_hold || berr_pick);
    reg [31:0] top_bytes = 32'h0;        // +top=<bytes>: the tree top in the gmem3 buffer (a multiple of 4 KB)
                                                     // so unpacked runs draw exactly the commands they always did
    integer cmd_off [0:4095], cmd_len [0:4095], cmd_bad [0:4095];
    integer cmd_bst [0:4095];              // expected status of a bad command (0: the run's bad_stat)
    integer rmode = 0;
    reg [DW-1:0] refimg [0:NARR*REC-1];    // byte image of every block (packed mode)
    reg [31:0]   refknown [0:NARR*REC-1];  // which bytes of the image are defined: a GET of a never-written block
                                        // leaves it undefined (Tiny ORAM then treats it as written, with
                                        // whatever its buffers held), until PUTs overwrite those bytes
    reg          written [0:NARR-1];       // block written at least once
    localparam [DW-1:0] POISON = {DW/32{32'hA5C3_0F1E}};
    function in_rec; input integer i, j, b; begin   // byte b of beat j is in command i's record
        in_rec = (cmd_len[i] == 0) || (j*32 + b >= cmd_off[i] && j*32 + b < cmd_off[i] + cmd_len[i]);
    end endfunction
    function [DW-1:0] pat; input integer id, beat, key; begin
        pat = {8{id[15:0], beat[7:0], key[7:0]}};
    end endfunction

    task prepare; input integer size; input integer bad_at; integer i, j, hcw; reg [31:0] jk; begin
        hcw = (((size * 32) + 4095) / 4096) * 4096 / 32;
        for (i = 0; i < size; i = i + 1) begin
            cmd_type[i] = (rnd(0) & 1) ? 2 : 1;
            cmd_key[i]  = rnd(0) % N;
            if (kset > 0) cmd_key[i] = (cmd_key[i] % kset) * (N / kset);   // +keys=K: K keys spread over the key space
            cmd_off[i] = 0; cmd_len[i] = 0;                         // whole block
            cmd_bad[i] = (i == bad_at); cmd_bst[i] = 0;
            if (rec_len > 0) begin                                   // one record of the block
                cmd_off[i] = (prnd(0) % (BLK/rec_len)) * rec_len;
                cmd_len[i] = rec_len;
            end
            if (rmode) begin                                         // any byte range, or (1 in 8) the whole block
                cmd_off[i] = prnd(0) % BLK;
                cmd_len[i] = 1 + prnd(0) % (BLK - cmd_off[i]);
                if (prnd(0) % 8 == 0) begin cmd_off[i] = 0; cmd_len[i] = 0; end
            end
            if (i == bad_at) begin
                if (rec_len > 0) begin cmd_type[i] = 2; cmd_off[i] = BLK - rec_len + 4; cmd_len[i] = rec_len; end   // runs past the block end
                else cmd_key[i] = N + 5;                            // outside the ORAM: must be rejected
            end
            cmd_id[i] = gid; gid = gid + 1;
            u_cmd.mem[i] = {{(DW-128){1'b0}}, cmd_len[i][31:0], cmd_off[i][31:0], cmd_key[i][31:0], 24'd0, cmd_type[i][7:0]};
            if (cmd_type[i] == 2) for (j = 0; j < SLOTW; j = j + 1) begin
                u_cmd.mem[hcw + i*SLOTW + j] = pat(cmd_id[i], j, cmd_key[i]);
                if (rec_len > 0) begin jk = prnd(0); u_cmd.mem[hcw + i*SLOTW + j] = u_cmd.mem[hcw + i*SLOTW + j] ^ {DW/32{jk}}; end   // junk around the record
            end
        end
    end endtask
    task prepare_seq; input integer size; integer i, j, hcw; begin
        hcw = (((size * 32) + 4095) / 4096) * 4096 / 32;
        for (i = 0; i < size; i = i + 1) begin
            cmd_type[i] = 2; cmd_key[i] = i % N; cmd_id[i] = gid; gid = gid + 1; cmd_off[i] = 0; cmd_len[i] = 0; cmd_bad[i] = 0; cmd_bst[i] = 0;
            u_cmd.mem[i] = {{(DW-64){1'b0}}, cmd_key[i][31:0], 24'd0, cmd_type[i][7:0]};
            for (j = 0; j < SLOTW; j = j + 1) u_cmd.mem[hcw + i*SLOTW + j] = pat(cmd_id[i], j, cmd_key[i]);
        end
    end endtask

    // packed mode, last launch: whole-block GETs of keys 0..size-7, then four bad ranges (status 0x40):
    // GET past the end, PUT with the offset beyond the block, GET with a wrapping length, PUT longer than the
    // block; then the check order (as doma_kernel): a PUT with a bad range and a bad key is 0x40, a GET with
    // both is 0x4
    task prepare_verify; input integer size; integer i, j, hcw; begin
        hcw = (((size * 32) + 4095) / 4096) * 4096 / 32;
        for (i = 0; i < size; i = i + 1) begin
            cmd_type[i] = 1; cmd_key[i] = i % N; cmd_id[i] = gid; gid = gid + 1; cmd_off[i] = 0; cmd_len[i] = 0; cmd_bad[i] = 0; cmd_bst[i] = 0;
            if (i >= size - 6) begin
                cmd_bad[i] = 1; cmd_key[i] = i % N;
                case (size - 1 - i)
                    5: begin cmd_type[i] = 1; cmd_off[i] = BLK - 4;  cmd_len[i] = 8; end
                    4: begin cmd_type[i] = 2; cmd_off[i] = BLK + 100; cmd_len[i] = 8; end
                    3: begin cmd_type[i] = 1; cmd_off[i] = 8;        cmd_len[i] = 32'hFFFF_FFF8; end
                    2: begin cmd_type[i] = 2; cmd_off[i] = 0;        cmd_len[i] = BLK + 1; end
                    1: begin cmd_type[i] = 2; cmd_off[i] = BLK;      cmd_len[i] = 8; cmd_key[i] = N + 3; cmd_bst[i] = 32'h40; end
                    0: begin cmd_type[i] = 1; cmd_off[i] = BLK;      cmd_len[i] = 8; cmd_key[i] = N + 3; cmd_bst[i] = 32'h4;  end
                endcase
                if (cmd_type[i] == 2) for (j = 0; j < SLOTW; j = j + 1) u_cmd.mem[hcw + i*SLOTW + j] = pat(cmd_id[i], j, cmd_key[i]);
            end
            u_cmd.mem[i] = {{(DW-128){1'b0}}, cmd_len[i][31:0], cmd_off[i][31:0], cmd_key[i][31:0], 24'd0, cmd_type[i][7:0]};
        end
    end endtask

    // after a re-boot (packed mode): one record into each of blocks 0..n-1, which the first session had filled,
    // then whole-block GETs of the same blocks; a fresh ORAM returns the record with zeros around it
    task prepare_probe; input integer n; integer i, j, hcw; begin
        hcw = (((2 * n * 32) + 4095) / 4096) * 4096 / 32;
        for (i = 0; i < 2 * n; i = i + 1) begin
            cmd_key[i] = i % n; cmd_id[i] = gid; gid = gid + 1; cmd_bad[i] = 0; cmd_bst[i] = 0;
            if (i < n) begin cmd_type[i] = 2; cmd_off[i] = rec_len; cmd_len[i] = rec_len; end
            else       begin cmd_type[i] = 1; cmd_off[i] = 0;       cmd_len[i] = 0; end
            u_cmd.mem[i] = {{(DW-128){1'b0}}, cmd_len[i][31:0], cmd_off[i][31:0], cmd_key[i][31:0], 24'd0, cmd_type[i][7:0]};
            if (cmd_type[i] == 2) for (j = 0; j < SLOTW; j = j + 1) u_cmd.mem[hcw + i*SLOTW + j] = pat(cmd_id[i], j, cmd_key[i]);
        end
    end endtask

    task run; input integer size; input integer bad_at; input [8*8-1:0] name;
        integer rt0, wt0, br0, bb0, nsz_r, nack;
        integer i, j, b, hcw, hrw, t0, t1, bad, nd_ok, nbad, gets, puts, rej, ar0, aw0, rb0, wb0, ord, dmin, dmax, wmin, wmax; reg [31:0] v; reg [DW-1:0] exp, got, sum, byt; begin
        nsz_r = size;
        if (size > 4096) begin $display("FAIL %0s: %0d commands, more than the testbench's 4096 (a preload of N > 4096 blocks)", name, size); fails = fails + 1; end
        hcw = (((size * 32) + 4095) / 4096) * 4096 / 32;
        hrw = ((((size + 2) * 32) + 4095) / 4096) * 4096 / 32;              // after records [size], [size+1]
        if (hrw + size * SLOTW > CMD_WORDS) begin
            $display("FAIL %0s: %0d commands of %0d B need %0d words of command/response buffer, the testbench has %0d (-DTB_CMD_WORDS)",
                     name, size, BLK, hrw + size * SLOTW, CMD_WORDS); fails = fails + 1; end
        for (i = 0; i <= size + 1; i = i + 1) u_resp.mem[i] = {DW{1'b1}};      // poison the headers and both records
        for (i = 0; i < size; i = i + 1) for (j = 0; j < SLOTW; j = j + 1) u_resp.mem[hrw + i*SLOTW + j] = POISON;   // and the data slots
        axil_wr(12'h010, CMD_BASE[31:0]);  axil_wr(12'h014, CMD_BASE[63:32]);
        axil_wr(12'h01C, RESP_BASE[31:0]); axil_wr(12'h020, RESP_BASE[63:32]);
        axil_wr(12'h028, pages_arg[31:0]); axil_wr(12'h02C, pages_arg[63:32]);
        axil_wr(12'h03C, TOP_BASE[31:0]);  axil_wr(12'h040, TOP_BASE[63:32]); axil_wr(12'h048, top_bytes);
        if (size == 0) latched = pages_arg;                                    // an init launch re-latches the buffer
        cur_size = size;
        axil_wr(12'h034, (size == 0 && tb_rtl != 0) ? (32'h8000_0000 | tb_rtl) : size);   // +rtl=L: the init selects depth L
        axil_wr(12'h004, 32'h1); axil_wr(12'h008, 32'h1);
        t0 = u_cmd.cyc; ar0 = ar_host; aw0 = aw_host; rb0 = rbeat_host; wb0 = wbeat_host; ord = 0;
        rt0 = rbeat_top; wt0 = wbeat_top; br0 = bursts_rd; bb0 = beats_rdb;
        started = 1;
        axil_wr(12'h000, 32'h1);                                                // ap_start
        v = 0;
        while (!v[1]) begin repeat (200) @(posedge clk); axil_rd(12'h000, v); end
        t1 = u_cmd.cyc;
        if (size == 0 && (ar_host != ar0 || aw_host != aw0)) begin
            $display("FAIL %0s: the init launch touched the tree (AR %0d AW %0d)", name, ar_host - ar0, aw_host - aw0); fails = fails + 1; end
        if (!irq) begin $display("FAIL %0s: interrupt not raised", name); fails = fails + 1; end
        axil_wr(12'h00C, 32'h1);
        @(posedge clk); @(posedge clk);
        if (irq) begin $display("FAIL %0s: interrupt not cleared", name); fails = fails + 1; end
        axil_rd(12'h000, v);
        if (!v[2] || v[1] || v[0]) begin $display("FAIL %0s: CTRL after done = %h (want idle, done cleared)", name, v); fails = fails + 1; end
        bad = 0; gets = 0; puts = 0; rej = 0; nbad = 0;
        if (relaxed) begin                                                  // fault run: count the error headers only
            for (i = 0; i < size; i = i + 1) if (u_resp.mem[i][7:0] === 8'h11 && (u_resp.mem[i][127:96] & 32'h8)) rej = rej + 1;
            size = 0;                                                       // skip the per-command checks below
        end dmin = 32'h7fffffff; dmax = 0; wmin = 32'h7fffffff; wmax = 0;
        for (i = 0; i < size; i = i + 1) begin
            got = u_resp.mem[i];
            if (got[7:0] === 8'h10) begin
                if (got[159:128] < dmin) dmin = got[159:128]; if (got[159:128] > dmax) dmax = got[159:128];
                if (got[191:160] < wmin) wmin = got[191:160]; if (got[191:160] > wmax) wmax = got[191:160];
            end
            if (cmd_bad[i]) begin
                nbad = nbad + 1;
                if (got[7:0] !== 8'h11 || got[127:96] !== ((cmd_bst[i] != 0) ? cmd_bst[i] : bad_stat)) begin bad = bad + 1;
                    $display("FAIL %0s: cmd %0d (key %0d off %0d len %0d) not rejected: type %h status %h", name, i, cmd_key[i], cmd_off[i], cmd_len[i], got[7:0], got[127:96]); end
                else rej = rej + 1;
                for (j = 0; j < SLOTW; j = j + 1) if (u_resp.mem[hrw + i*SLOTW + j] !== POISON) begin
                    $display("FAIL %0s: rejected cmd %0d wrote its data slot", name, i); bad = bad + 1; j = SLOTW; end
            end else if (got[7:0] === 8'h10 && !(got[159:128] <= got[95:64] && got[95:64] <= got[191:160])) begin
                bad = bad + 1;   // latencies must be ordered: data ready <= last write beat <= acknowledged
                if (ord < 3) $display("FAIL %0s: cmd %0d latencies out of order: data %0d, write beat %0d, ack %0d", name, i, got[159:128], got[95:64], got[191:160]);
                ord = ord + 1;
            end else if (got[7:0] !== 8'h10 || got[63:32] !== cmd_key[i]) begin
                bad = bad + 1;
                if (bad < 4) $display("FAIL %0s: cmd %0d header type %h key %0d status %h", name, i, got[7:0], got[63:32], got[127:96]);
            end else if (cmd_type[i] == 2) begin
                last_put[cmd_key[i]] = cmd_id[i]; puts = puts + 1;
                if (rec_len > 0) begin                                   // the record's bytes land, nothing else
                    if (!written[cmd_key[i]]) for (j = 0; j < REC; j = j + 1) begin
                        refimg[cmd_key[i]*REC + j] = {DW{1'b0}}; refknown[cmd_key[i]*REC + j] = 32'hFFFF_FFFF; end   // zeros around it
                    for (j = 0; j < REC; j = j + 1) begin
                        exp = u_cmd.mem[hcw + i*SLOTW + j];
                        for (b = 0; b < DW/8; b = b + 1) if (in_rec(i, j, b)) begin
                            refimg[cmd_key[i]*REC + j][8*b +: 8] = exp[8*b +: 8]; refknown[cmd_key[i]*REC + j][b] = 1'b1; end
                    end
                end
                written[cmd_key[i]] = 1'b1;
            end else if (rec_len > 0) begin                              // packed: only the record comes back
                gets = gets + 1; nd_ok = 1;
                for (j = 0; j < REC; j = j + 1) begin
                    got = u_resp.mem[hrw + i*SLOTW + j];
                    for (b = 0; b < DW/8; b = b + 1)
                        if (!in_rec(i, j, b)) begin if (got[8*b +: 8] !== POISON[8*b +: 8]) nd_ok = 0; end
                        else if (written[cmd_key[i]] && refknown[cmd_key[i]*REC + j][b] && got[8*b +: 8] !== refimg[cmd_key[i]*REC + j][8*b +: 8]) nd_ok = 0;
                end
                if (!written[cmd_key[i]]) begin                         // its record: Tiny ORAM's own behaviour, not checked
                    uninit_gets = uninit_gets + 1; written[cmd_key[i]] = 1'b1;
                    for (j = 0; j < REC; j = j + 1) refknown[cmd_key[i]*REC + j] = 32'd0;
                end
                if (!nd_ok) begin
                    if (bad < 4) $display("FAIL %0s: GET cmd %0d key %0d off %0d len %0d differs from the block image, or wrote outside its record",
                                          name, i, cmd_key[i], cmd_off[i], cmd_len[i]);
                    bad = bad + 1;
                end
            end else begin
                gets = gets + 1;
                if (last_put[cmd_key[i]] < 0) begin
                    // GET of a never-written key: Tiny ORAM's own behaviour, reported, not checked
                    if (uninit_gets == 0) $display("NOTE %0s: GET of never-written key %0d returned %h...", name, cmd_key[i], u_resp.mem[hrw + i*SLOTW][63:0]);
                    uninit_gets = uninit_gets + 1;
                end else for (j = 0; j < REC; j = j + 1) begin
                    exp = pat(last_put[cmd_key[i]], j, cmd_key[i]);
                    if (u_resp.mem[hrw + i*SLOTW + j] !== exp) begin
                        if (bad < 4) $display("FAIL %0s: GET cmd %0d key %0d beat %0d data mismatch: got %h exp %h", name, i, cmd_key[i], j,
                                              u_resp.mem[hrw + i*SLOTW + j][63:0], exp[63:0]);
                        bad = bad + 1; j = REC;
                    end
                end
            end
        end
        if (relaxed) size = nsz_r;
        sum = u_resp.mem[size];
        $display("%0s: size=%0d  host cycles=%0d  device total=%0d  completed=%0d  latency min/max=%0d/%0d  errors=%h  gets=%0d puts=%0d rejected=%0d  bad=%0d  tree AR=%0d AW=%0d",
                 name, size, t1 - t0, sum[127:64], sum[255:224], sum[159:128], sum[191:160], sum[223:192], gets, puts, rej, bad,
                 ar_host - ar0, aw_host - aw0);
        if (relaxed) begin
            nack = 0; for (i = 0; i < size; i = i + 1) if (u_resp.mem[i][7:0] === 8'h10) nack = nack + 1;
            if (sum[255:224] !== nack) begin
                $display("FAIL %0s: summary says %0d completed, %0d headers carry no error", name, sum[255:224], nack); fails = fails + 1; end
            if (berr_rel && !berr_done) begin
                $display("FAIL %0s: no write response arrived after a release (needs late writes, +host_wlat)", name); fails = fails + 1; end
            if (berr_cmd < 0 || u_resp.mem[berr_cmd][7:0] !== 8'h11 || !(u_resp.mem[berr_cmd][127:96] & 32'h8)) begin
                $display("FAIL %0s: the write error was not charged to command %0d (header %h)", name, berr_cmd, u_resp.mem[berr_cmd][127:0]);
                fails = fails + 1; end
            if (sum[7:0] !== 8'h5A || !(sum[223:192] & 32'h8) || rej == 0) begin
                $display("FAIL %0s: the injected write error is not reported (summary errors %h, %0d header(s) with 0x8)", name, sum[223:192], rej);
                fails = fails + 1; end
            else $display("%0s: injected write error reported: summary errors %h, %0d header(s) with 0x8", name, sum[223:192], rej);
        end else
        if (sum[7:0] !== 8'h5A || sum[63:32] !== REC ||                    // bytes 4-7: block size in beats
            sum[255:224] !== size - nbad || sum[223:192] !== exp_errs) begin
            $display("FAIL %0s: summary record wrong", name); fails = fails + 1; end
        // header bytes 8-11 (and the summary): last write-back beat handed off; 16-19 data ready; 20-23 acknowledged
        if (size > 0) $display("%0s: latency to data ready %0d..%0d, to last write beat %0d..%0d, to write-back acknowledged %0d..%0d",
                               name, dmin, dmax, sum[159:128], sum[191:160], wmin, wmax);
        byt = u_resp.mem[size + 1];
        $display("%0s: traffic record: read beats %0d, write beats %0d on the tree port (testbench saw %0d / %0d; %0d / %0d on the top port; %0d beats per read burst)",
                 name, byt[127:64], byt[191:128], rbeat_host - rb0, wbeat_host - wb0, rbeat_top - rt0, wbeat_top - wt0,
                 (bursts_rd - br0 > 0) ? (beats_rdb - bb0) / (bursts_rd - br0) : 0);
        if (byt[7:0] !== 8'h5B || byt[127:64] !== rbeat_host - rb0 || byt[191:128] !== wbeat_host - wb0 ||
            byt[223:192] !== N || byt[255:224] !== dut.tree_bursts_rt[31:0] ||
            byt[35:8] !== ((rbeat_top - rt0) / 2) || byt[63:36] !== ((wbeat_top - wt0) / 2)) begin   // the top port, 64-byte units
            $display("FAIL %0s: traffic record [size+1] wrong", name); fails = fails + 1; end
        if (axitrace) $display("%0s: tree data hash: blocks written %h / %h (pages / top)", name, hw2, hw3);
        fails = fails + bad;
    end endtask

    initial begin : main
        integer k; reg [31:0] v;
        if (!$value$plusargs("seed=%d", seed)) seed = 7;
        if ($value$plusargs("rtl=%d", tb_rtl)) N = 4 << tb_rtl;          // TINYORAM_RTDEPTH builds: run at depth L
        if (!$value$plusargs("rtl2=%d", tb_rtl2)) tb_rtl2 = 0;           // and re-boot (+reboot) at depth L2
        chk_n("start");
        // +rtlbad=K: the first init asks for depth K outside 6..L_max (expects 0x100 and L_max)
        if ($value$plusargs("top=%d", k)) top_bytes = k;
        if ($value$plusargs("keys=%d", k)) kset = k;
        if ($test$plusargs("top_all")) top_bytes = 32'hFFFF_FFFF;      // the whole tree on gmem3
        rs = 32'h2545F491 ^ seed; if (rs == 0) rs = 32'h2545F491;
        if (!$value$plusargs("cmds=%d", ncmd1)) ncmd1 = 120;
        if (!$value$plusargs("cmds2=%d", ncmd2)) ncmd2 = 40;
        if ($value$plusargs("host_lat=%d", hl)) u_host.lat = hl;
        if ($value$plusargs("host_gap=%d", hg)) u_host.gap_pct = hg;
        if ($value$plusargs("host_wlat=%d", hg)) u_host.wlat = hg;
        if ($value$plusargs("host_rdy_gap=%d", hg)) begin u_host.rdy_gap = hg; u_cmd.rdy_gap = hg; u_resp.rdy_gap = hg; end
        if ($value$plusargs("resp_rdy_gap=%d", hg)) u_resp.rdy_gap = hg;   // the response port only (stretches a GET's data write)
        for (k = 0; k < N; k = k + 1) begin last_put[k] = -1; written[k] = 1'b0; end
        rmode = $test$plusargs("ranges");
        if (rmode && !$test$plusargs("packed")) rec_len = 8;
        if ($value$plusargs("packed=%d", rec_len) || rmode) begin
            if (rec_len <= 0 || rec_len > BLK || BLK % rec_len != 0) begin
                $display("FAIL: +packed=%0d must divide the %0d-byte block", rec_len, BLK); fails = fails + 1; rec_len = 0; end
            for (k = 0; k < N*REC; k = k + 1) begin refimg[k] = {DW{1'b0}}; refknown[k] = 32'd0; end
            $display("packed records: %0d bytes, %0d per block", rec_len, (rec_len > 0) ? BLK/rec_len : 0);
        end
        bad_stat = (rec_len > 0) ? 32'h40 : 32'h4;
        for (k = 0; k < HOST_WORDS; k = k + 1) begin v = rnd(0); u_host.mem[k] = {8{v}}; end   // stale contents of the tree buffer
        for (k = 0; k < (1 << 17); k = k + 1) begin v = prnd(0); u_top.mem[k] = {8{v}}; end      // and of the top buffer
        $display("tb_tinyoram_kernel | N=%0d record=%0d B | tree read latency %0d cycles, gaps %0d%%, ready gaps %0d%%, writes land after %0d cycles",
                 N, REC * 32, u_host.lat, u_host.gap_pct, u_host.rdy_gap, u_host.wlat);
        $fflush;
        repeat (20) @(posedge clk); rst_n = 1;
        axil_rd(12'h000, v);
        if (!v[2]) begin $display("FAIL: kernel not idle after reset (CTRL=%h)", v); fails = fails + 1; end
        if ($value$plusargs("start_delay=%d", k)) repeat (k) @(posedge clk);
        if ($value$plusargs("rtlbad=%d", k)) begin                    // an unsupported depth: 0x100, L_max kept
            tb_rtl = k; exp_errs = 32'h100; run(0, -1, "init"); exp_errs = 32'h0; tb_rtl = 0; N = NMAX; chk_n("rtlbad");
        end else
        run(0, -1, "init");
        if ($test$plusargs("preload")) begin prepare_seq(N); run(N, -1, "preload"); end   // whole blocks (the image follows them)
        // +host_wlat_after=N: tree writes land (and are acknowledged) N cycles after their data from here on
        if ($value$plusargs("host_wlat_after=%d", hg)) begin u_host.wlat = hg; u_top.wlat = hg; end
        if ($test$plusargs("berr_rel"))   berr_mode = 1;
        if ($test$plusargs("berr_last"))  berr_mode = 2;
        if ($test$plusargs("berr_early")) berr_mode = 3;
        if (berr_mode != 0) begin berr_rel = 1; berr_k = -1; end
        if (berr_rel || $value$plusargs("berr=%d", berr_k)) begin    // fault injection, then a re-boot
            bcnt = 0; berr_arm = 1; relaxed = 1;
            prepare(ncmd1, -1); run(ncmd1, -1, "fault");
            berr_arm = 0; relaxed = 0;
            pages_arg = HOST_BASE + HOST_WORDS * 16;
            run(0, -1, "init2");
            for (k = 0; k < N; k = k + 1) begin last_put[k] = -1; written[k] = 1'b0; end
            for (k = 0; k < N*REC; k = k + 1) begin refimg[k] = {DW{1'b0}}; refknown[k] = 32'd0; end
            ncmd2 = -1;                                                  // no second run in this flow
        end
        prepare(1, -1); run(1, -1, "one");
        prepare(ncmd1, -1); run(ncmd1, -1, "run1");
        if (ncmd2 < 0) ;
        else if ($test$plusargs("nobad")) begin prepare(ncmd2, -1); run(ncmd2, -1, "run2"); end
        else begin prepare(ncmd2, ncmd2 / 2); run(ncmd2, ncmd2 / 2, "run2"); end
        if (rec_len > 0) begin k = (N < 64) ? N : 64; prepare_verify(k + 6); run(k + 6, -1, "verify"); end
        if ($test$plusargs("reboot")) begin
            if (2 * dut.tree_bytes_rt > HOST_WORDS * 32) begin
                $display("FAIL: +reboot needs room for two trees (%0d bytes); build with -DTB_HOST_WORDS", 2 * dut.tree_bytes_rt); fails = fails + 1; end
            else begin
                if (!$test$plusargs("reboot_same")) pages_arg = HOST_BASE + HOST_WORDS * 16;   // the second half of the memory
                if (tb_rtl2 != 0) begin tb_rtl = tb_rtl2; N = 4 << tb_rtl2; chk_n("rtl2"); end   // +rtl2: the re-boot selects another depth
                run(0, -1, "init2");                                         // re-boot: fresh ORAM in the (moved) buffer
                for (k = 0; k < N; k = k + 1) begin last_put[k] = -1; written[k] = 1'b0; end
                for (k = 0; k < N*REC; k = k + 1) begin refimg[k] = {DW{1'b0}}; refknown[k] = 32'd0; end
                if (rec_len > 0) begin prepare_probe(8); run(16, -1, "probe"); end   // first records of blocks the first session filled
                prepare(ncmd1, -1); run(ncmd1, -1, "run3");                  // zero-fills the moved tree, then commands
                if (rec_len > 0) begin k = (N < 64) ? N : 64; prepare_verify(k + 6); run(k + 6, -1, "verify2"); end
                pages_arg = (latched == HOST_BASE) ? HOST_BASE + HOST_WORDS * 16 : HOST_BASE;   // another buffer than the latched one:
                exp_errs = 32'h20;                                           // a command launch naming it reports 0x20
                prepare(ncmd2, -1); run(ncmd2, -1, "moved");
                exp_errs = 32'h0;
            end
        end
        $display("read-behind-write hold: %0d holds, %0d cycles in all, longest %0d cycles", hold_n, hold_cyc, hold_max);
        if (raw_hits) begin $display("FAIL: %0d tree read(s) overlapped a write not yet acknowledged", raw_hits); fails = fails + 1; end
        if ($value$plusargs("need_hold=%d", need_hold) && hold_max < need_hold) begin
            $display("FAIL: the longest read-behind-write hold was %0d cycles, below %0d: the hold was not exercised", hold_max, need_hold);
            fails = fails + 1; end
        if (oob_access) begin $display("FAIL: %0d tree access(es) outside the latched buffer", oob_access); fails = fails + 1; end
        if (oob_cmd) begin $display("FAIL: %0d command read(s) outside the launch's commands", oob_cmd); fails = fails + 1; end
        if (early_access) begin $display("FAIL: the tree buffer was accessed before the first ap_start"); fails = fails + 1; end
        if (uninit_gets) $display("NOTE: %0d GET(s) of never-written keys (not checked)", uninit_gets);
        if (u_cmd.errors || u_resp.errors || u_host.errors) begin
            $display("FAIL: memory errors (out of range or AXI protocol): cmd %0d resp %0d host %0d (protocol %0d/%0d/%0d)", u_cmd.errors, u_resp.errors, u_host.errors, u_cmd.perr, u_resp.perr, u_host.perr);
            fails = fails + 1; end
        if (fails == 0) $display("*** TINYORAM KERNEL: ALL CHECKS PASSED ***");
        else            $display("*** TINYORAM KERNEL: %0d FAILURE(S) ***", fails);
        $finish;
    end
    integer hb_n, lim, cyc_tb = 0, ar_host = 0, aw_host = 0, rbeat_host = 0, wbeat_host = 0, rbeat_top = 0, wbeat_top = 0;
    reg early_access = 0;
    integer oob_access = 0, bursts_rd = 0, beats_rdb = 0, oob_cmd = 0;
    integer cur_size = 0;                // commands in the current launch (gmem0 reads must stay within them)
    wire [63:0] top_eff = ({32'd0, top_bytes} >= dut.tree_bytes_rt) ? dut.tree_bytes_rt : ({32'd0, top_bytes} & ~64'd4095);
    reg trace_cmd = 0;
    initial trace_cmd = $test$plusargs("trace_cmd");
    // +axitrace: every tree burst (port, cycle, offset in its buffer, beats - 1),
    // for comparing a run-time-depth build with the native build of the same depth cycle by cycle
    always @(posedge clk) if (axitrace && started) begin
        if (g2_arvalid && g2_arready) $display("T %0d AR2 %h %0d", cyc_tb, g2_araddr - latched, g2_arlen);
        if (g2_awvalid && g2_awready) $display("T %0d AW2 %h %0d", cyc_tb, g2_awaddr - latched, g2_awlen);
        if (g3_arvalid && g3_arready) $display("T %0d AR3 %h %0d", cyc_tb, g3_araddr - TOP_BASE, g3_arlen);
        if (g3_awvalid && g3_awready) $display("T %0d AW3 %h %0d", cyc_tb, g3_awaddr - TOP_BASE, g3_awlen);
    end
    // with +axitrace, also an order-sensitive hash of every data beat Tiny ORAM writes to the tree outside the
    // bucket headers (blocks and their ciphertext; tree offset within its bucket at or above the header's bursts),
    // printed per launch: the same bytes, not only the same bursts. The headers are left out: a run-time-depth
    // build keeps L_max-wide leaf fields in them (the same size, a different layout; README §18).
    reg  [63:0] hw2 = 64'd0, hw3 = 64'd0, wa2 = 64'd0, wa3 = 64'd0;   // hashes; the next write beat's tree offset
    reg  [63:0] wq2 [0:4095]; reg [7:0] wl2 [0:4095]; integer wqh2 = 0, wqt2 = 0, wb2 = 0;   // AW queue of each port
    reg  [63:0] wq3 [0:4095]; reg [7:0] wl3 [0:4095]; integer wqh3 = 0, wqt3 = 0, wb3 = 0;
    // a bucket: a 2-burst header (at every depth these builds use) and Z = 4 blocks of 64-byte bursts
    localparam integer HDR_B = 128, BKT_B = HDR_B + 4 * 64 * ((`TINYORAM_ORAMB + 511) / 512);
    function [63:0] fold; input [DW-1:0] d; integer q; begin fold = 64'd0; for (q = 0; q < DW / 64; q = q + 1) fold = fold ^ d[q*64 +: 64]; end endfunction
    always @(posedge clk) if (axitrace) begin : DHASH
        reg [63:0] o2, o3;
        if (g2_awvalid && g2_awready) begin wq2[wqt2 % 4096] = g2_awaddr - latched; wl2[wqt2 % 4096] = g2_awlen; wqt2 = wqt2 + 1; end
        if (g3_awvalid && g3_awready) begin wq3[wqt3 % 4096] = g3_awaddr - TOP_BASE; wl3[wqt3 % 4096] = g3_awlen; wqt3 = wqt3 + 1; end
        if (g2_wvalid && g2_wready) begin
            o2 = wq2[wqh2 % 4096] + 32 * wb2;
            if ((o2 % BKT_B) >= HDR_B) hw2 <= (hw2 * 64'h0000_0100_0000_01b3) ^ fold(g2_wdata) ^ {32'd0, g2_wstrb} ^ o2;
            if (wb2 == wl2[wqh2 % 4096]) begin wb2 = 0; wqh2 = wqh2 + 1; end else wb2 = wb2 + 1;
        end
        if (g3_wvalid && g3_wready) begin
            o3 = wq3[wqh3 % 4096] + 32 * wb3;
            if ((o3 % BKT_B) >= HDR_B) hw3 <= (hw3 * 64'h0000_0100_0000_01b3) ^ fold(g3_wdata) ^ {32'd0, g3_wstrb} ^ o3;
            if (wb3 == wl3[wqh3 % 4096]) begin wb3 = 0; wqh3 = wqh3 + 1; end else wb3 = wb3 + 1;
        end
    end
    // The adapter's read-behind-write hold, exercised: a read at the head of the adapter's queue that would open
    // a new burst while a tree write is unacknowledged (b_out != 0). +need_hold=N: the longest such hold must
    // reach N cycles, i.e. acknowledgements arrived after the next path read wanted to start.
    integer hold_n = 0, hold_cyc = 0, hold_cur = 0, hold_max = 0, need_hold = 0;
    // Read-after-write hazard on the bus: a tree read whose range overlaps a write not yet acknowledged would
    // return the old data. Each port's writes are acknowledged in order: a FIFO of their ranges per port; a
    // read on either port is checked against both (the two ports are separate memories, so only the same port
    // can alias, but the check is cheap). Every overlap is a failure.
    localparam integer RAWQ = 8192;
    reg [63:0] raw_lo [0:1][0:RAWQ-1]; reg [63:0] raw_hi [0:1][0:RAWQ-1];
    integer raw_wp [0:1], raw_rp [0:1], raw_n [0:1], raw_hits = 0, raw_q;
    initial begin raw_wp[0] = 0; raw_wp[1] = 0; raw_rp[0] = 0; raw_rp[1] = 0; raw_n[0] = 0; raw_n[1] = 0; end
    task raw_check; input integer pt; input [63:0] a; input [7:0] len; integer q, i; reg [63:0] e; begin
        e = a + (len + 1) * 32;
        for (q = 0; q < raw_n[pt]; q = q + 1) begin
            i = (raw_rp[pt] + q) % RAWQ;
            if (a < raw_hi[pt][i] && raw_lo[pt][i] < e) begin
                if (raw_hits < 4) $display("FAIL: read at %h (%0d beats, port %0d) overlaps a write at %h not yet acknowledged: it would see stale data",
                                           a, len + 1, pt + 2, raw_lo[pt][i]);
                raw_hits = raw_hits + 1; q = raw_n[pt];
            end
        end
    end endtask
    always @(posedge clk) begin
        if (started) begin
            if (g2_arvalid && g2_arready) raw_check(0, g2_araddr, g2_arlen);
            if (g3_arvalid && g3_arready) raw_check(1, g3_araddr, g3_arlen);
            if (g2_awvalid && g2_awready) begin raw_lo[0][raw_wp[0]] = g2_awaddr; raw_hi[0][raw_wp[0]] = g2_awaddr + (g2_awlen + 1) * 32;
                                                raw_wp[0] = (raw_wp[0] + 1) % RAWQ; raw_n[0] = raw_n[0] + 1; end
            if (g3_awvalid && g3_awready) begin raw_lo[1][raw_wp[1]] = g3_awaddr; raw_hi[1][raw_wp[1]] = g3_awaddr + (g3_awlen + 1) * 32;
                                                raw_wp[1] = (raw_wp[1] + 1) % RAWQ; raw_n[1] = raw_n[1] + 1; end
            if (g2_bv && g2_bready && raw_n[0] > 0) begin raw_rp[0] = (raw_rp[0] + 1) % RAWQ; raw_n[0] = raw_n[0] - 1; end
            if (g3_bvalid && g3_bready && raw_n[1] > 0) begin raw_rp[1] = (raw_rp[1] + 1) % RAWQ; raw_n[1] = raw_n[1] - 1; end
        end
    end
    wire    hold_now = dut.u_adapt.h_val && dut.u_adapt.h_rd && !dut.u_adapt.merge_ok && (dut.u_adapt.b_out != 16'd0);
    always @(posedge clk) begin
        if (hold_now) begin hold_cyc <= hold_cyc + 1; hold_cur <= hold_cur + 1; if (hold_cur == 0) hold_n <= hold_n + 1;
                            if (hold_cur + 1 > hold_max) hold_max <= hold_cur + 1; end
        else hold_cur <= 0;
    end
    always @(posedge clk) begin
        cyc_tb <= cyc_tb + 1;
        ar_host <= ar_host + ((g2_arvalid && g2_arready) ? 1 : 0) + ((g3_arvalid && g3_arready) ? 1 : 0);   // both tree ports
        aw_host <= aw_host + ((g2_awvalid && g2_awready) ? 1 : 0) + ((g3_awvalid && g3_awready) ? 1 : 0);
        rbeat_host <= rbeat_host + ((g2_rvalid && g2_rready) ? 1 : 0) + ((g3_rvalid && g3_rready) ? 1 : 0);
        wbeat_host <= wbeat_host + ((g2_wvalid && g2_wready) ? 1 : 0) + ((g3_wvalid && g3_wready) ? 1 : 0);
        if (g3_rvalid && g3_rready) rbeat_top <= rbeat_top + 1;
        if (berr_arm && g2_bv && g2_bready) bcnt <= bcnt + 1;
        // the error belongs to the released command whose header waits for its acknowledgements, if any,
        // otherwise to the command in progress
        if (berr_now && g2_bready) berr_cmd <= (dut.hq_v && dut.hq_ackw) ? dut.hq_idx : dut.idx;
        if (berr_now && g2_bready) berr_done <= 1'b1;
        berr_hold <= berr_now && !g2_bready;                         // keep BRESP stable until the handshake
        if (g3_wvalid && g3_wready) wbeat_top <= wbeat_top + 1;
        if (!started && rst_n && (g2_arvalid || g2_awvalid || g2_wvalid || g3_arvalid || g3_awvalid || g3_wvalid)) early_access <= 1;
        // every tree burst must lie inside its buffer: offsets [top, tree) in the one latched by the last init
        // launch (gmem2), offsets [0, top) in the top buffer (gmem3); no burst crosses 4 KB
        if (g2_arvalid && g2_arready && (g2_araddr < latched + top_eff || g2_araddr + (g2_arlen + 1) * 32 > latched + dut.tree_bytes_rt ||
            (g2_araddr % 4096) + (g2_arlen + 1) * 32 > 4096)) oob_access <= oob_access + 1;
        if (g2_awvalid && g2_awready && (g2_awaddr < latched + top_eff || g2_awaddr + (g2_awlen + 1) * 32 > latched + dut.tree_bytes_rt ||
            (g2_awaddr % 4096) + (g2_awlen + 1) * 32 > 4096)) oob_access <= oob_access + 1;
        if (g3_arvalid && g3_arready && (g3_araddr < TOP_BASE || g3_araddr + (g3_arlen + 1) * 32 > TOP_BASE + top_eff ||
            (g3_araddr % 4096) + (g3_arlen + 1) * 32 > 4096)) oob_access <= oob_access + 1;
        if (g3_awvalid && g3_awready && (g3_awaddr < TOP_BASE || g3_awaddr + (g3_awlen + 1) * 32 > TOP_BASE + top_eff ||
            (g3_awaddr % 4096) + (g3_awlen + 1) * 32 > 4096)) oob_access <= oob_access + 1;
        // command reads: a header of this launch's commands, or a data slot of one of them
        if (g0_arvalid && g0_arready &&
            !((g0_araddr >= CMD_BASE && g0_araddr + 32 * (g0_arlen + 1) <= CMD_BASE + cur_size * 32) ||
              (g0_araddr >= CMD_BASE + ((cur_size * 32 + 4095) / 4096) * 4096 &&
               g0_araddr + 32 * (g0_arlen + 1) <= CMD_BASE + ((cur_size * 32 + 4095) / 4096) * 4096 + cur_size * BLK)))
            oob_cmd <= oob_cmd + 1;
        if (g2_arvalid && g2_arready) begin bursts_rd <= bursts_rd + 1; beats_rdb <= beats_rdb + g2_arlen + 1; end
        if (g3_arvalid && g3_arready) begin bursts_rd <= bursts_rd + 1; beats_rdb <= beats_rdb + g3_arlen + 1; end
        if (trace_cmd && dut.t_cmd_valid && dut.t_cmd_ready)
            $display("CMD cyc=%0d idx=%0d %s key=%0d", cyc_tb, dut.idx, dut.t_cmd == 0 ? "PUT" : "GET", dut.t_paddr);
        if (trace_cmd && dut.kst == 5'd18) $display("NEXT cyc=%0d idx=%0d stat=%h lat=%0d", cyc_tb, dut.idx, dut.stat, dut.lat);
        if (hb_n > 0 && cyc_tb % hb_n == 0 && cyc_tb > 0) begin
            $display("HB cyc=%0d kst=%0d core_run=%0d tiny_idle=%0d idx=%0d tree AR=%0d AW=%0d",
                     cyc_tb, dut.kst, dut.core_run, dut.t_idle, dut.idx, ar_host, aw_host);
            $fflush;
        end
        if (cyc_tb == lim) begin $display("FAIL: global limit of %0d cycles reached (kst=%0d)", lim, dut.kst); $fflush; $finish; end
    end
    initial begin
        if (!$value$plusargs("hb=%d", hb_n)) hb_n = 50000;
        if (!$value$plusargs("limit=%d", lim)) lim = 40000000;
    end
endmodule
