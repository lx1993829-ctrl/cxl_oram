#!/usr/bin/env python3
"""merge_results.py -- one comparison table per configuration from sweep_tiny.sh's and sweep_doma.sh's results.

    python3 merge_results.py [DEST/results]        (default: the results folder next to this package copy)

Reads tiny_q<id>_<name>.csv/.log, doma_32B.csv/.log, doma_4k.csv/.log and clocks.txt, and writes
comparison.md (one table per configuration) and comparison.csv (every row) into the same folder.

A configuration is a record count with a block-size class: the 8-byte records packed (Tiny ORAM 8 per 64-byte
block, DOMA 4 per 32-byte block), or 4 KB blocks. Its rows: DOMA at each HBM share, and each Tiny ORAM bitstream
of that size at each tree-top setting (0 = whole tree in host memory; doma:<p> = DOMA's on-package bytes at p%).

Columns (all from the logs; nothing is estimated except where marked):
  KQPS                        host-timed, as BOLT measures it
  latency p50 / p99 / max     the primary latency (DOMA: arrival-mode release; Tiny ORAM: last write-back beat
                              handed off), in cycles from the latency spread; max also in microseconds at the clock
  off-package B/cmd           read + written per command on the host-memory port (both designs measure it)
  on-package B/cmd            Tiny ORAM: measured on its top port. DOMA: 2 x Z x block - off-package, with Z = 10
                              (DOMA moves one whole bucket each way per access; its HBM bucket port is not counted
                              in its traffic record, so this column is computed: marked *)
  on-pkg B/rec, host B/rec    the placement line (DOMA: position map, bucket records, stash, HBM buckets)
  clock MHz                   the bitstream's kernel clock
"""
import csv, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
RES = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(HERE)))), 'results')
DOMA_Z = 10

def num(x):
    try: return float(x)
    except (TypeError, ValueError): return None

def parse_log(path):
    """{(N, setting): fields} from a scan.sh log (blocks start with '==== N=<n> DOMA_TINY_TOP=<t>' or '... DOMA_HBM_PCT=<p>')."""
    runs, cur = {}, None
    if not os.path.exists(path): return runs
    for line in open(path, errors='replace'):
        m = re.match(r'==== N=(\d+) DOMA_(TINY_TOP|HBM_PCT)=(\S+)', line)
        if m: cur = runs.setdefault((int(m.group(1)), m.group(3)), {}); continue
        if cur is None: continue
        if (m := re.match(r'block: (\d+) bytes per slot', line)): cur['block'] = int(m.group(1))
        elif (m := re.search(r'= ([\d.]+) KQPS', line)): cur['kqps'] = float(m.group(1))
        elif (m := re.match(r'latency spread: min (\d+), p50 (\d+), p90 (\d+), p99 (\d+), p99\.9 (\d+), max (\d+), mean ([\d.]+)', line)):
            cur.update(lat_min=int(m.group(1)), p50=int(m.group(2)), p99=int(m.group(4)), lat_max=int(m.group(6)), mean=float(m.group(7)))
        elif (m := re.match(r'device: \d+ cycles total, per-command latency (\d+)\.\.(\d+) cycles, completed (\d+), errors (\S+)', line)):
            cur.setdefault('lat_min', int(m.group(1))); cur.setdefault('lat_max', int(m.group(2))); cur['errors'] = m.group(4)
        elif (m := re.match(r'traffic: .* = (\d+) B read, (\d+) B written per command', line)):
            cur['traffic_rw'] = int(m.group(1)) + int(m.group(2)); cur['traffic_label'] = line.split(':')[1].strip()
        elif (m := re.match(r'traffic split: pages \(off-package\) (\d+) B read, (\d+) B written per command; top \(on-package\) (\d+) B read, (\d+) B written', line)):
            cur['off_rw'] = int(m.group(1)) + int(m.group(2)); cur['on_rw'] = int(m.group(3)) + int(m.group(4))
        elif (m := re.search(r'per record ([\d.]+) B on-package, ([\d.]+) B in pages', line)):
            cur['on_rec'] = float(m.group(1)); cur['host_rec'] = float(m.group(2))
        elif (m := re.match(r'placement: tree (\d+) B = (\d+) B on-package', line)): cur['top_bytes'] = int(m.group(2))
        elif (m := re.match(r'matched budget: doma_kernel keeps (\d+) B', line)): cur['matched'] = int(m.group(1))
        elif line.startswith('ALL RESPONSES CORRECT'): cur['correct'] = 'yes'
        elif line.startswith('ERRORS FOUND'): cur['correct'] = 'NO'
    return runs

def clocks():
    c = {}
    p = os.path.join(RES, 'clocks.txt')
    if os.path.exists(p):
        for line in open(p):
            f = line.split()
            if len(f) >= 3 and f[0] == 'tiny': c[('tiny', f[1])] = num(f[3]) if len(f) > 3 else None
            if len(f) >= 3 and f[0] == 'doma': c[('doma', f[1])] = num(f[-1])
    return c

def queue():
    q = {}
    for line in open(os.path.join(HERE, 'queue.txt')):
        f = line.split()
        if not f or f[0].startswith('#') or len(f) < 9: continue
        q['q%s' % f[0]] = dict(name=f[1], size=f[2], n=int(f[3]), merge=f[6] == '1', flatpm=f[7] == '1', rt=f[7] == 'rt')
    return q

BYTES = {'1k': 1024, '2k': 2048, '4k': 4096}
def size_bytes(s): return BYTES.get(s) or int(s)
def size_class(s):   # 8-byte records packed into 32 or 64 B blocks (against DOMA's 32 B blocks), else one class per block size
    b = size_bytes(s); return 'rec8' if b <= 64 else 'blk4k' if b == 4096 else 'blk%d' % b

def main():
    clk, q, rows = clocks(), queue(), []
    for tag, tiny_class in (('32B', 'rec8'), ('4k', 'blk4k')):
        runs = parse_log(os.path.join(RES, 'doma_%s.log' % tag))
        for (n, h), r in sorted(runs.items(), key=lambda kv: (kv[0][0], num(kv[0][1]) or 0)):
            b = r.get('block', 32 if tag == '32B' else 4096)
            off = r.get('traffic_rw')
            on = None if off is None else max(0, 2 * DOMA_Z * b - off)
            rows.append(dict(cls=tiny_class, n=n, design='DOMA', config='%d B blocks%s' % (b, ', 4 per block' if tag == '32B' else ''),
                             setting='%s%% HBM' % h, sort=(0, num(h) or 0), clock=clk.get(('doma', tag)), off=off, on=on, on_star=True, **r))
    for key, e in q.items():
        runs = parse_log(os.path.join(RES, 'tiny_%s_%s.log' % (key, e['name'])))
        cls = size_class(e['size'])
        cfg = '%s B blocks, %s, %s' % (size_bytes(e['size']), 'merged bursts' if e['merge'] else '1:1 adapter',
                                         'flat position map' if e['flatpm'] else 'position map as published') + (', run-time depth' if e['rt'] else '')
        for (n, t), r in runs.items():
            s = 'whole tree in host memory' if t == '0' else ('top = DOMA at %s%%' % t[5:] if t.startswith('doma:') else 'top = %s' % t)
            rows.append(dict(cls=cls, n=n, design='Tiny ORAM', config=cfg, setting=s,
                             sort=(1 + (0 if e['merge'] and not e['flatpm'] else 1 if e['flatpm'] else 2) + (0.5 if e['rt'] else 0), -1 if t == '0' else num(t[5:]) if t.startswith('doma:') else 999),
                             clock=clk.get(('tiny', key)), off=r.get('off_rw', r.get('traffic_rw')), on=r.get('on_rw', 0), on_star=False,
                             rt=e['rt'], merge=e['merge'], flatpm=e['flatpm'], **r))
    if not rows: print('no results in %s' % RES); return 1
    cols = ['design', 'config', 'setting', 'KQPS', 'lat p50', 'lat p99', 'lat max', 'max us', 'off-pkg B/cmd', 'on-pkg B/cmd',
            'on-pkg B/rec', 'host B/rec', 'clock MHz', 'correct']
    def cells(r):
        us = '%.2f' % (r['lat_max'] / r['clock']) if r.get('lat_max') and r.get('clock') else ''
        f = lambda v, d=0: '' if v is None else ('%.*f' % (d, v))
        return [r['design'], r['config'], r['setting'], f(r.get('kqps'), 1), f(r.get('p50')), f(r.get('p99')), f(r.get('lat_max')), us,
                f(r.get('off')), (f(r.get('on')) + ('*' if r['on_star'] and r.get('on') is not None else '')),
                f(r.get('on_rec'), 1), f(r.get('host_rec'), 1), f(r.get('clock')), r.get('correct', '?')]
    md = ['# DOMA vs Tiny ORAM on the U55C', '',
          'Primary latency: DOMA ends an access at its arrival-mode release, which includes its timing padding '
          '(every access padded to fixed budgets; GETs and PUTs handled identically, so they look alike on the bus); '
          'Tiny ORAM ends it when the last write-back beat is handed off, with no timing protection (and it prefetches '
          'only PUT data). In the flat position map rows, Tiny ORAM\'s position map is on chip, which saves it an HBM '
          'round trip per access compared with DOMA. At DOMA\'s 0% point DOMA still keeps about 8 MB on-package (per '
          '1M records): "whole tree in host memory" gives Tiny ORAM nothing on-package, "top = DOMA at 0%" the same bytes.',
          '', '`*` computed: 2 x Z x block minus the measured off-package traffic (Z = 10).', '']
    out = open(os.path.join(RES, 'comparison.csv'), 'w', newline=''); w = csv.writer(out); w.writerow(['class', 'N'] + cols)
    extra = sorted({r['cls'] for r in rows} - {'rec8', 'blk4k'}, key=lambda c: int(c[3:]))
    for cls, title in [('rec8', '8-byte records'), ('blk4k', '4 KB blocks')] + [(c, '%s B blocks' % c[3:]) for c in extra]:
        for n in sorted({r['n'] for r in rows if r['cls'] == cls}):
            sel = sorted([r for r in rows if r['cls'] == cls and r['n'] == n], key=lambda r: r['sort'])
            md += ['## %s, N = %s' % (title, format(n, ',')), '', '| ' + ' | '.join(cols) + ' |', '|' + '---|' * len(cols)]
            for r in sel:
                c = cells(r); md.append('| ' + ' | '.join(c) + ' |'); w.writerow([cls, n] + c)
            md.append('')
    out.close()
    # the run-time depth's acceptance: every run-time-depth row against the native build's row of the same class, N,
    # adapter and setting (README §18: within run-to-run noise, at the same clock)
    acc = []
    for r in rows:
        if not r.get('rt'): continue
        nat = [x for x in rows if x['design'] == 'Tiny ORAM' and not x.get('rt') and x['cls'] == r['cls'] and x['n'] == r['n']
               and x.get('merge') == r.get('merge') and not x.get('flatpm') and x['setting'] == r['setting']]
        if not nat: continue
        x = nat[0]
        rel = lambda a, b: '' if a is None or not b else '%+.1f%%' % (100.0 * (a - b) / b)
        acc.append('| %s | %s | %s | %s | %s | %s | %s | %s |' % (format(r['n'], ','), r['setting'], '%.1f / %.1f' % (r.get('kqps') or 0, x.get('kqps') or 0),
                   rel(r.get('kqps'), x.get('kqps')), rel(r.get('p50'), x.get('p50')), rel(r.get('p99'), x.get('p99')),
                   '%s / %s' % (r.get('clock') or '?', x.get('clock') or '?'), rel(r.get('off'), x.get('off'))))
    if acc:
        md += ['## Run-time depth against the native build', '',
               'Each run-time-depth row against the native build of the same depth (same N, adapter and setting). Acceptance: '
               'KQPS and latency within run-to-run noise, the same clock, the same traffic per command.', '',
               '| N | setting | KQPS run-time / native | KQPS | p50 | p99 | clock MHz | off-pkg B/cmd |', '|---|---|---|---|---|---|---|---|'] + acc + ['']
    open(os.path.join(RES, 'comparison.md'), 'w').write('\n'.join(md) + '\n')
    print('wrote %s and %s (%d rows)' % (os.path.join(RES, 'comparison.md'), os.path.join(RES, 'comparison.csv'), len(rows)))
    return 0

if __name__ == '__main__':
    sys.exit(main())
