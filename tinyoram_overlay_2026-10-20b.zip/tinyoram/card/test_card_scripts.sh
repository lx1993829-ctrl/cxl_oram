#!/bin/bash
# test_card_scripts.sh -- dry run of the card scripts against the functional XRT mock (mock_xrt/): no card, no XRT,
# no Vivado; about a minute. It is part of run_tinyoram.sh's regression and of install_tinyoram.sh --check.
#
#   bash test_card_scripts.sh [work dir]          default: a fresh temporary directory, removed on a pass
#
# 1. host_doma.cpp is compiled against mock_xrt/ (g++ only).
# 2. A stand-in DEST is made as queue.sh leaves it: queue/<id>.status (stage DONE, xclbin, clock) and, per entry, a
#    copy's vitis/ with the xclbin's name, scan.sh, and a host_doma that answers as that bitstream (native depth, or
#    run-time depth with L_max) and records every call. Entries: q1 and q6 (native, 64 B and 4 KB), q8 and q9 (run-time
#    depth), from this package's queue.txt.
# 3. sweep_tiny.sh 1 6 8 9 must, per entry: pass its own check; call host_doma with the entry's own xclbin on every run;
#    run exactly the expected N (q1 1000000, q6 16384, q8 100000 1000000 10000000, q9 16384 65536) times TOPS; and
#    on q8/q9 run each N at the depth it needs (L = 12, 15, 19 and 12, 14). RT_NS="1000000" must run q8 at 1M only;
#    RT_NS="16384 65536" runs q10-q14 (128 B, 256 B, 4 KB, 1 KB, 2 KB blocks, L_max = 18) at L = 12 and 14, with matched
#    budgets for their blocks.
# 4. accept_rt.sh 1 8 (REPS=3, 2,000 commands) must end ACCEPT PASS: the mock answers both bitstreams alike. Its KQPS is
#    the host's wall clock around the mock, not a kernel's, so NOISE_PCT=50 here (it widens the latency check too, but the
#    mock's latencies are equal to the cycle, and p50/p99 must agree exactly); traffic, depth, correctness and clock are
#    compared as on the card.
# 5. Self-check: sweep_tiny.sh with the 2026-10-19 bug put back (the RT_NS loop reusing x, the xclbin path) must be
#    caught by step 3.
# Last line: "CARD SCRIPTS TEST PASS" (exit 0) or "CARD SCRIPTS TEST FAIL: ..." (exit 1).
set -u
CARD=$(cd "$(dirname "$0")" && pwd)
PKG=$(cd "$CARD/../.." && pwd)
T=${1:-$(mktemp -d "${TMPDIR:-/tmp}/tiny_cardtest.XXXXXX")}; KEEP=${1:+1}
mkdir -p "$T"; T=$(cd "$T" && pwd)
nfail=0; why=""
bad() { echo "  FAIL  $*"; nfail=$((nfail + 1)); why="$why $*;"; }
ok()  { echo "  ok    $*"; }

echo "== 1. host_doma.cpp against the XRT mock"
g++ -std=c++17 -O2 -I"$CARD/mock_xrt" "$PKG/vitis/host_doma.cpp" -pthread -o "$T/host_mock" > "$T/compile.log" 2>&1 \
    || { echo "CARD SCRIPTS TEST FAIL: compile ($T/compile.log)"; exit 1; }
ok "compiled"

# make_dest <dest>: the stand-in queue result for entries 1, 6, 8, 9 and 10-14
make_dest() {
    local D=$1 id name sz n pack cfg merge pm freq purpose
    rm -rf "$D"; mkdir -p "$D/queue" "$D/results"
    while read -r id name sz n pack cfg merge pm freq purpose; do
        case " 1 6 8 9 10 11 12 13 14 " in *" $id "*) ;; *) continue ;; esac
        local bb=$sz; case "$sz" in 1k) bb=1024 ;; 2k) bb=2048 ;; 4k) bb=4096 ;; esac
        local nb=$n; [ "$pack" = 1 ] && nb=$(( (n + bb / 8 - 1) / (bb / 8) ))
        local L=6; while [ $((4 << L)) -lt $nb ]; do L=$((L + 1)); done
        local V=$D/q${id}_$name/fpga_zcu208/vitis; mkdir -p "$V"
        local X=$V/tinyoram_${sz}_q${id}_hw.xclbin; : > "$X"
        cp "$PKG/vitis/scan.sh" "$V/"
        local menv="MOCK_BLOCK=$bb MOCK_L=$L"; [ "$pm" = rt ] && menv="MOCK_BLOCK=$bb MOCK_RTLMAX=$L"
        cat > "$V/host_doma" <<EOF
#!/bin/bash
# stand-in for q$id's host_doma: records its xclbin argument and DOMA_N, answers through the XRT mock
echo "xclbin=\$1 N=\${DOMA_N:-} top=\${DOMA_TINY_TOP:-}" >> "$V/calls.txt"
[ -f "\$1" ] || { echo "No such file '\$1'"; exit 1; }
$menv exec "$T/host_mock" "\$@"
EOF
        chmod +x "$V/host_doma"
        printf 'stage=DONE\nxclbin=%s\nclock_mhz=%s\n' "$X" "$freq" > "$D/queue/$id.status"
    done < <(awk '!/^#/ && NF >= 9' "$CARD/queue.txt")
}

# check_sweep <dest> <id> <expected N list> [expected L list]
check_sweep() {
    local D=$1 id=$2 ens=$3 els=${4:-} V X nt got gl c
    V=$(ls -d "$D"/q${id}_*/fpga_zcu208/vitis); X=$(awk -F= '$1 == "xclbin" {print $2}' "$D/queue/$id.status")
    nt=$(echo $TOPS | wc -w)
    [ -f "$V/calls.txt" ] || { bad "q$id: host_doma never called"; return; }
    c=$(grep -vc "^xclbin=$(basename "$X") " "$V/calls.txt"); [ "$c" = 0 ] || { bad "q$id: $c host_doma call(s) without the entry's xclbin ($(grep -v "^xclbin=$(basename "$X") " "$V/calls.txt" | head -1))"; return; }
    got=$(grep -oE " N=[0-9]+" "$V/calls.txt" | cut -d= -f2 | awk '!s[$0]++' | tr '\n' ' '); got=${got% }
    [ "$got" = "$ens" ] || { bad "q$id: N swept '$got', expected '$ens'"; return; }
    c=$(wc -l < "$V/calls.txt"); [ "$c" = $(( $(echo $ens | wc -w) * nt )) ] || { bad "q$id: $c runs, expected $(( $(echo $ens | wc -w) * nt ))"; return; }
    local csv; csv=$(ls "$D"/results/tiny_q${id}_*.csv)
    c=$(awk -F, 'NR > 1 && $4 != "" && $9 == "0x0" && $10 == "0"' "$csv" | wc -l)
    [ "$c" = $(( $(echo $ens | wc -w) * nt )) ] || { bad "q$id: $c measured CSV rows, expected $(( $(echo $ens | wc -w) * nt ))"; return; }
    if [ -n "$els" ]; then
        gl=$(grep -oE "running at L=[0-9]+" "${csv%.csv}.log" | cut -d= -f2 | awk '!s[$0]++' | tr '\n' ' '); gl=${gl% }
        [ "$gl" = "$els" ] || { bad "q$id: depths '$gl', expected '$els'"; return; }
    fi
    ok "q$id: N = $ens${els:+ at L = $els}, $nt settings each, entry's xclbin on every run, every row measured"
}

TOPS="0 doma:0 doma:20 doma:50 doma:100"   # sweep_tiny.sh's default, for the run counts
echo "== 2-3. sweep_tiny.sh on native and run-time-depth entries"
make_dest "$T/dest"
DEST=$T/dest CMDS=200 XRT_SETUP=/dev/null bash "$CARD/sweep_tiny.sh" 1 6 8 9 > "$T/sweep.log" 2>&1; rc=$?
[ $rc = 0 ] && ok "sweep_tiny.sh exit 0" || bad "sweep_tiny.sh exit $rc ($T/sweep.log)"
[ "$(grep -c '   PASS: every row measured' "$T/sweep.log")" = 4 ] && ok "4 entries PASS in sweep_tiny.sh's own check" || bad "sweep_tiny.sh's own check: $(grep -c '   PASS' "$T/sweep.log")/4 PASS ($T/sweep.log)"
grep -q "No such file" "$T/sweep.log" "$T"/dest/results/*.log && bad "'No such file' in the sweep output"
check_sweep "$T/dest" 1 "1000000"
check_sweep "$T/dest" 6 "16384"
check_sweep "$T/dest" 8 "100000 1000000 10000000" "12 15 19"
check_sweep "$T/dest" 9 "16384 65536" "12 14"
make_dest "$T/dest_rtns"
DEST=$T/dest_rtns CMDS=200 RT_NS=1000000 XRT_SETUP=/dev/null bash "$CARD/sweep_tiny.sh" 8 > "$T/sweep_rtns.log" 2>&1 || bad "RT_NS=1000000: sweep_tiny.sh failed ($T/sweep_rtns.log)"
check_sweep "$T/dest_rtns" 8 "1000000" "15"
# 128 B, 256 B, 4 KB, 1 KB and 2 KB blocks, run-time depth L_max = 18 (q10-q14), at two small N (their 1M-block trees
# are up to 13 GB)
DEST=$T/dest_rtns CMDS=200 RT_NS="16384 65536" XRT_SETUP=/dev/null bash "$CARD/sweep_tiny.sh" 10 11 12 13 14 > "$T/sweep_big.log" 2>&1 || bad "q10-q14: sweep_tiny.sh failed ($T/sweep_big.log)"
for i in 10 11 12 13 14; do check_sweep "$T/dest_rtns" $i "16384 65536" "12 14"; done
c=$(grep -c "for 16384 records in 1024-byte blocks\|for 65536 records in 1024-byte blocks" "$T"/dest_rtns/results/tiny_q13_*.log); [ "$c" -gt 0 ] && ok "q13: matched budgets computed for 1,024-byte blocks (DOMA_MATCH_BLOCK)" || bad "q13: no matched budget for 1,024-byte blocks"

echo "== 4. accept_rt.sh 1 8"
DEST=$T/dest CMDS=2000 REPS=3 NOISE_PCT=50 XRT_SETUP=/dev/null bash "$CARD/accept_rt.sh" 1 8 > "$T/accept.log" 2>&1
[ "$(tail -1 "$T/accept.log")" = "ACCEPT PASS" ] && [ "$(grep -c "p50 +0.00%, p99 +0.00%" "$T/accept.log")" = 2 ] && ok "ACCEPT PASS ($(grep -c "^   PASS" "$T/accept.log") settings: traffic identical, depth 15 on both, all correct)" || bad "accept_rt.sh: $(tail -1 "$T/accept.log") ($T/accept.log)"

echo "== 5. self-check: the RT_NS loop reusing x (the xclbin path) must be caught"
mkdir -p "$T/mut"; cp "$CARD/queue.txt" "$T/mut/"
sed -E 's/for v in (\$\{RT_NS)/for x in \1/; s/\[ \$v -le \$n \] && ns="\$ns \$v"/[ $x -le $n ] \&\& ns="$ns $x"/' "$CARD/sweep_tiny.sh" > "$T/mut/sweep_tiny.sh"
if cmp -s "$CARD/sweep_tiny.sh" "$T/mut/sweep_tiny.sh"; then bad "self-check: could not put the bug back (sweep_tiny.sh's loop changed?)"
else
    make_dest "$T/dest_mut"
    DEST=$T/dest_mut CMDS=200 XRT_SETUP=/dev/null bash "$T/mut/sweep_tiny.sh" 8 > "$T/sweep_mut.log" 2>&1
    n0=$nfail; w0=$why; check_sweep "$T/dest_mut" 8 "100000 1000000 10000000" "12 15 19" > "$T/mut_check.log"
    if [ $nfail -gt $n0 ]; then nfail=$n0; why=$w0; ok "caught: $(sed 's/^ *FAIL *//' "$T/mut_check.log" | head -1)"
    else bad "self-check: the bug was not caught"; fi
fi

if [ $nfail = 0 ]; then [ -z "$KEEP" ] && rm -rf "$T"; echo "CARD SCRIPTS TEST PASS"; exit 0; fi
echo "CARD SCRIPTS TEST FAIL:$why (work dir $T)"; exit 1
