#!/bin/bash
# queue.sh -- build the Tiny ORAM comparison bitstreams one at a time (tinyoram/card/queue.txt), each in its own copy.
#
#   bash queue.sh start [id ...]   start the worker in the background (all pending entries, or only these ids, in order)
#   bash queue.sh status           one line per entry: stage, out-of-context WNS, post-place WNS, final clock, xclbin
#   bash queue.sh pause            the worker stops after the current entry (a running build is not interrupted)
#   bash queue.sh stop             stop the worker and the running build now (the entry is marked STOPPED)
#   bash queue.sh reset <id>       forget an entry's result, so start runs it again (after editing FREQ, say)
#   bash queue.sh log <id>         follow the running entry's log
#
# Per entry, in its copy DEST/q<id>_<name>/fpga_zcu208/vitis (made by install_tinyoram.sh):
#   1. fetch_tinyoram.sh for its geometry, a one-minute Vivado elaboration of those sources (elab_tinyoram.tcl; a
#      failure stops the entry at FAILED_ELAB), then the out-of-context place and route at FREQ (synth_ooc_tinyoram.tcl,
#      about an hour). Pass: WNS >= 0 and WHS >= 0. On a fail the entry stops at FAILED_OOC with the estimated
#      reachable clock; the board build is not started, and the worker goes on to the next entry.
#      OOC=0 skips this step.
#   2. the board build (build_tinyoram.sh TARGET=hw, several hours). When placement finishes, the post-placement WNS
#      is read: below -0.5 ns the build is stopped (FAILED_PLACE), as the runbook says.
#   3. check_timing.sh's verdict: DONE (timing closed at FREQ), DONE_LOWER (v++ lowered the clock: usable, report it),
#      FAILED_TIMING or FAILED_BUILD.
# State and logs: DEST/queue/ (<id>.status, worker.log); each entry's logs in its copy's vitis/ (queue_*.log).
# DEST is the folder install_tinyoram.sh made (default: two levels above this package copy).
set -u
CARD=$(cd "$(dirname "$0")" && pwd)
PKG=$(cd "$CARD/../.." && pwd)
DEST=${DEST:-$(dirname "$(dirname "$PKG")")}
Q=$DEST/queue; mkdir -p "$Q"
LIST=$CARD/queue.txt
VITIS_SETTINGS=${VITIS_SETTINGS:-/tools/Xilinx/Vitis/2024.1/settings64.sh}
XRT_SETUP=${XRT_SETUP:-/opt/xilinx/xrt/setup.sh}

entries() { awk '!/^#/ && NF >= 9 {print}' "$LIST"; }
entry() { entries | awk -v i="$1" '$1 == i'; }
st_get() { [ -f "$Q/$1.status" ] && awk -F= -v k="$2" '$1 == k {v = substr($0, length(k) + 2)} END {print v}' "$Q/$1.status"; }
st_set() { touch "$Q/$1.status"; grep -v "^$2=" "$Q/$1.status" > "$Q/$1.tmp"; echo "$2=$3" >> "$Q/$1.tmp"; mv "$Q/$1.tmp" "$Q/$1.status"; }
geom() {   # geom SIZE N PACK -> "BB BLOCKS L", as build_tinyoram.sh computes them
    local bb=$1 blocks=$2 L=6; case "$1" in 1k) bb=1024 ;; 2k) bb=2048 ;; 4k) bb=4096 ;; esac; [ "$3" = 1 ] && blocks=$(( ($2 + bb / 8 - 1) / (bb / 8) ))
    while [ $((4 << L)) -lt $blocks ]; do L=$((L + 1)); done; echo "$bb $blocks $L"; }
tag() {    # tag SIZE N PACK CFG MERGE FLATPM FREQ -> build_tinyoram.sh's tag (FLATPM: 0, 1, or rt = run-time depth)
    local t=tinyoram_$1; { [ "$2" = 256 ] && [ "$3" = 0 ]; } || t=${t}_n$2; [ "$3" = 1 ] && t=${t}_p8
    [ "$7" = 300 ] || t=${t}_${7}mhz; [ "$4" = tinyoram_host.cfg ] && t=${t}_host; [ "$5" = 1 ] && t=${t}_merge; [ "$6" = 1 ] && t=${t}_flatpm
    [ "$6" = rt ] && t=${t}_rt; echo $t; }

run_entry() {
    local id name sz n pack cfg merge flatpm freq purpose; read -r id name sz n pack cfg merge flatpm freq purpose <<< "$(entry $1)"
    local dir=$DEST/q${id}_$name/fpga_zcu208/vitis
    [ -d "$dir" ] || { st_set $id stage "FAILED_NOCOPY ($dir missing: run install_tinyoram.sh)"; return; }
    read -r bb blocks L <<< "$(geom $sz $n $pack)"
    local t; t=$(tag $sz $n $pack $cfg $merge $flatpm $freq)
    st_set $id tag $t; st_set $id geometry "$sz B blocks, $n records, $blocks blocks, L=$L"; st_set $id started "$(date '+%F %T')"
    cd "$dir" || return
    # 1. out-of-context timing at this geometry
    if [ "${OOC:-1}" = 1 ] && [ "$(st_get $id ooc)" != PASS ]; then
        st_set $id stage RUNNING_OOC
        bash ../tinyoram/fetch_tinyoram.sh $sz $L $([ $merge = 1 ] && echo merge) $([ $flatpm = 1 ] && echo flatpm) $([ $flatpm = rt ] && echo rtdepth) > queue_fetch.log 2>&1 \
            || { st_set $id stage "FAILED_FETCH (vitis/queue_fetch.log)"; return; }
        # a one-minute Vivado elaboration of exactly these sources first
        vivado -mode batch -nojournal -nolog -source elab_tinyoram.tcl > queue_elab.log 2>&1
        grep -q "^ELAB PASS" queue_elab.log && ! grep -q "^ERROR:" queue_elab.log \
            || { st_set $id stage "FAILED_ELAB ($(grep -m1 -E '^ERROR:|^ELAB FAIL' queue_elab.log | cut -c1-100); vitis/queue_elab.log)"; return; }
        vivado -mode batch -nojournal -nolog -source synth_ooc_tinyoram.tcl -tclargs route $freq > queue_ooc.log 2>&1
        local line wns whs; line=$(grep -E "^WNS: " queue_ooc.log | tail -1)
        wns=$(echo "$line" | awk '{print $2}'); whs=$(echo "$line" | awk '{print $5}')
        [ -z "$wns" ] && { st_set $id stage "FAILED_OOC (no WNS line: vitis/queue_ooc.log)"; return; }
        st_set $id ooc_wns "$wns"; st_set $id ooc_whs "$whs"
        if awk -v w="$wns" -v h="$whs" 'BEGIN{exit !(w >= 0 && h >= 0)}'; then st_set $id ooc PASS
        else local f; f=$(awk -v w="$wns" -v m="$freq" 'BEGIN{f = 1000 / (1000 / m - w); printf "%d", int(f / 5) * 5}')
             st_set $id ooc FAIL; st_set $id stage "FAILED_OOC (WNS $wns ns at $freq MHz: about $f MHz reachable; set FREQ=$f for id $id in queue.txt, reset $id, start)"
             return; fi
    fi
    # 2. the board build, with the post-placement check
    st_set $id stage RUNNING_HW
    local R=_x_$t/link/vivado/vpl/prj/prj.runs/impl_1
    rm -f $R/post_place_timing.rpt 2>/dev/null
    [ -f ${t}_hw.xclbin ] && mv -f ${t}_hw.xclbin ${t}_hw.xclbin.prev   # an earlier attempt's: never taken for this one
    setsid env TARGET=hw SIZE=$sz N=$n PACK=$pack CFG=$cfg MERGE=$merge FLATPM=$([ $flatpm = 1 ] && echo 1 || echo 0) RTDEPTH=$([ $flatpm = rt ] && echo 1 || echo 0) FREQ=$freq bash build_tinyoram.sh > queue_build.log 2>&1 &
    local pid=$! pp=""
    echo $pid > "$Q/build.pid"
    while kill -0 $pid 2>/dev/null; do
        sleep ${QPOLL:-60}
        if [ -z "$pp" ] && [ -f $R/post_place_timing.rpt ]; then
            pp=$(awk '/WNS\(ns\)/{getline; getline; print $1; exit}' $R/post_place_timing.rpt)
            [ -n "$pp" ] || continue
            st_set $id place_wns "$pp"
            if awk -v w="$pp" 'BEGIN{exit !(w < -0.5)}'; then
                kill -- -$pid 2>/dev/null; sleep 5; kill -9 -- -$pid 2>/dev/null
                st_set $id stage "FAILED_PLACE (post-place WNS $pp ns < -0.5: lower FREQ for id $id, reset $id, start)"; rm -f "$Q/build.pid"; return
            fi
        fi
    done
    wait $pid 2>/dev/null; rm -f "$Q/build.pid"
    # 3. the verdict
    local mhz; mhz=$(grep -oE "kernel clock in [^ ]+: [0-9]+ MHz" queue_build.log | tail -1 | grep -oE "[0-9]+ MHz$" | cut -d' ' -f1)
    st_set $id clock_mhz "${mhz:-}"; st_set $id run "$(grep -E '^run: ' queue_build.log | tail -1 | cut -c6-)"
    st_set $id finished "$(date '+%F %T')"
    if [ ! -f ${t}_hw.xclbin ]; then st_set $id stage "FAILED_BUILD (vitis/queue_build.log)"
    elif grep -q "^PASS: timing closed" queue_build.log; then st_set $id stage DONE; st_set $id xclbin "$dir/${t}_hw.xclbin"
    elif grep -q "^NOT AT " queue_build.log; then st_set $id stage "DONE_LOWER ($mhz MHz)"; st_set $id xclbin "$dir/${t}_hw.xclbin"
    else st_set $id stage "FAILED_TIMING (vitis/queue_build.log; do not use the xclbin)"; fi
}

worker() {
    exec >> "$Q/worker.log" 2>&1
    echo "== worker $$ started $(date '+%F %T'), entries: ${*:-all}"
    if ! command -v vivado > /dev/null; then source "$VITIS_SETTINGS" > /dev/null 2>&1; source "$XRT_SETUP" > /dev/null 2>&1; fi
    command -v vivado > /dev/null && command -v v++ > /dev/null || { echo "vivado/v++ not found (VITIS_SETTINGS=$VITIS_SETTINGS)"; exit 1; }
    for id in $(entries | awk '{print $1}'); do
        [ $# -gt 0 ] && ! printf '%s\n' "$@" | grep -qx "$id" && continue
        case "$(st_get $id stage)" in DONE*|FAILED*|STOPPED*) continue ;; esac
        [ -f "$Q/PAUSE" ] && { echo "paused before entry $id"; break; }
        echo "-- entry $id $(date '+%F %T')"; run_entry $id; echo "   $(st_get $id stage)"
    done
    echo "== worker $$ ended $(date '+%F %T')"; rm -f "$Q/worker.pid"
}

case "${1:-status}" in
  start|resume)
    shift
    if [ -f "$Q/worker.pid" ] && kill -0 "$(cat "$Q/worker.pid")" 2>/dev/null; then echo "a worker is already running (pid $(cat "$Q/worker.pid"))"; exit 1; fi
    rm -f "$Q/PAUSE"; nohup bash "$0" _worker "$@" > /dev/null 2>&1 &
    echo $! > "$Q/worker.pid"; echo "worker started (pid $!); bash $0 status   to follow it" ;;
  _worker) shift; worker "$@" ;;
  pause) touch "$Q/PAUSE"; echo "the worker stops after the current entry" ;;
  stop)
    touch "$Q/PAUSE"
    [ -f "$Q/build.pid" ] && kill -- -"$(cat "$Q/build.pid")" 2>/dev/null
    [ -f "$Q/worker.pid" ] && kill "$(cat "$Q/worker.pid")" 2>/dev/null
    for id in $(entries | awk '{print $1}'); do case "$(st_get $id stage)" in RUNNING*) st_set $id stage STOPPED ;; esac; done
    rm -f "$Q/worker.pid" "$Q/build.pid"; echo "stopped" ;;
  reset) [ -n "${2:-}" ] && rm -f "$Q/$2.status" && echo "entry $2 will run again" ;;
  log)
    read -r id name rest <<< "$(entry ${2:?usage: queue.sh log <id>})"
    d=$DEST/q${id}_$name/fpga_zcu208/vitis; f=$d/queue_build.log; [ "$(st_get $id stage)" = RUNNING_OOC ] && f=$d/queue_ooc.log
    tail -f "$f" ;;
  status)
    w="no worker running"; [ -f "$Q/worker.pid" ] && kill -0 "$(cat "$Q/worker.pid")" 2>/dev/null && w="worker running (pid $(cat "$Q/worker.pid"))"
    [ -f "$Q/PAUSE" ] && w="$w, pause requested"
    echo "$w; state in $Q"
    printf "%-3s %-16s %-11s %-9s %-9s %-6s %s\n" id name geometry ooc_WNS place_WNS clock stage
    entries | while read -r id name sz n pack cfg merge flatpm freq purpose; do
        read -r bb blocks L <<< "$(geom $sz $n $pack)"
        printf "%-3s %-16s %-11s %-9s %-9s %-6s %s\n" $id $name "${sz}B L=$L" "$(st_get $id ooc_wns)" "$(st_get $id place_wns)" "$(st_get $id clock_mhz)" "$(st_get $id stage)"
    done ;;
  *) sed -n '2,12p' "$0"; exit 1 ;;
esac
