#pragma once
#include <vector>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
enum xclBOSyncDirection { XCL_BO_SYNC_BO_TO_DEVICE, XCL_BO_SYNC_BO_FROM_DEVICE };
namespace xrt { struct bo { enum class flags { normal, host_only }; std::vector<uint8_t>* m = nullptr;
  bo() {} bo(const struct device&, size_t n, int g) { m = new std::vector<uint8_t>(n); if (std::getenv("MOCK_BO")) std::printf("[mock] bo group %d: %zu bytes\n", g, n); }
  bo(const struct device&, size_t n, flags, int g) { m = new std::vector<uint8_t>(n); if (std::getenv("MOCK_BO")) std::printf("[mock] bo group %d (host): %zu bytes\n", g, n); }
  template <class T> T map() { return reinterpret_cast<T>(m->data()); }
  size_t size() const { return m ? m->size() : 0; }
  void sync(xclBOSyncDirection, size_t, size_t) {} }; }
