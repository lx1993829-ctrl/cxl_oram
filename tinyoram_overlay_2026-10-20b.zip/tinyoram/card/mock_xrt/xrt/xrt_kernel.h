#pragma once
// Functional XRT mock for dry runs of host_doma.cpp and the card scripts (tinyoram/card/test_card_scripts.sh): no card,
// no XRT. Each kernel launch is answered as a key-value store in the kernels' response layout, with fixed latencies.
// Environment: MOCK_BLOCK (block bytes, default 4096); Tiny ORAM: MOCK_L (native depth, default 6), MOCK_RTLMAX (a
// run-time-depth bitstream of that L_max: depth-selecting inits answered, summary bytes 1-3), MOCK_TREE (the tree bytes
// the summary reports; default: host_doma.cpp's own formula for the depth), MOCK_BEATS (traffic beats per command).
// A native Tiny ORAM bitstream sent a depth-selecting init, or a kernel launched with the wrong argument count, exits 9.
#include <string>
#include <map>
#include <vector>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <tuple>
#include <algorithm>
#include "xrt_bo.h"
namespace xrt {
struct run { void wait() {} };
struct kernel {
  std::string name; std::map<uint32_t, std::vector<uint8_t>> kv; uint8_t* pages0 = nullptr; int nargs_seen = 0;
  kernel(const struct device&, const struct uuid&, const std::string& n) : name(n) { std::printf("[mock] kernel %s\n", n.c_str()); }
  int group_id(int i) { return i; }
  static size_t r4k(size_t x) { return (x + 4095) & ~size_t(4095); }
  unsigned actL = 0;
  static size_t ttree(size_t block, unsigned L) {   // host_doma.cpp's tinyoram_tree_bytes
    const unsigned Z = 4, U = 32, E = 64, H = 128;
    unsigned hdr = E + 8 * ((Z + 7) / 8) + U * Z + L * Z + H * Z;
    size_t bkt = (hdr + 511) / 512 + Z * ((block * 8 + 511) / 512);
    size_t words = bkt * 8, x = 8192 / words + 1;
    unsigned lst = 0; while ((size_t(2) << lst) <= x) lst++;
    if (lst == 0) lst = 1;
    unsigned nst = (L + 1 + lst - 1) / lst;
    size_t tot = ((size_t(1) << (nst * lst)) - 1) / ((size_t(1) << lst) - 1);
    return 64 * ((size_t(1) << (L + 1)) + tot) * bkt; }
  static uint64_t treeb(size_t blk, unsigned L) { const char* e = std::getenv("MOCK_TREE"); return e ? std::atoll(e) : ttree(blk, L); }
  void body(bo& c, bo& r, bo& p, uint32_t n, uint32_t nblk_arg, int nargs) {
    bool tiny = (name == "tinyoram_kernel");
    unsigned rtmax = std::getenv("MOCK_RTLMAX") ? std::atoi(std::getenv("MOCK_RTLMAX")) : 0; uint32_t rterr = 0;
    if (tiny && rtmax) {
      if (!actL) actL = rtmax;
      if (n & 0x80000000u) { unsigned q = n & 31; if (q >= 6 && q <= rtmax) actL = q; else { actL = rtmax; rterr = 0x100; } n = 0;
                             std::printf("[mock] run-time depth init: L=%u%s\n", actL, rterr ? " (refused)" : ""); }
      else if (n == 0) actL = rtmax;
    } else if (n & 0x80000000u) { std::printf("[mock] FAIL: depth-select init sent to a native bitstream\n"); std::exit(9); }
    if (tiny != (nargs == 6)) { std::printf("[mock] FAIL: %s launched with %d args\n", name.c_str(), nargs); std::exit(9); }
    unsigned L = std::getenv("MOCK_L") ? std::atoi(std::getenv("MOCK_L")) : 6;
    if (tiny && rtmax) L = actL;
    size_t blk = std::getenv("MOCK_BLOCK") ? std::atoi(std::getenv("MOCK_BLOCK")) : 4096;
    uint32_t N = tiny ? (4u << L) : nblk_arg;
    if (!pages0) pages0 = p.map<uint8_t*>(); else if (pages0 != p.map<uint8_t*>()) { std::printf("[mock] FAIL pages moved\n"); std::exit(9); }
    uint8_t* cp = c.map<uint8_t*>(); uint8_t* rp = r.map<uint8_t*>();
    size_t hc = r4k(n * 32), hr = r4k((n + 2) * 32), slot = blk;
    for (uint32_t i = 0; i < n; i++) {
      uint8_t* h = cp + i * 32; uint32_t k; std::memcpy(&k, h + 4, 4);
      uint8_t* o = rp + i * 32; std::memset(o, 0, 32); o[0] = (k < N) ? 0x10 : 0x11; std::memcpy(o + 4, &k, 4);
      uint32_t lat = 100 + i % 7, d = 50 + i % 5, w = 80 + i % 3; std::memcpy(o + 8, &lat, 4);
      if (tiny) { std::memcpy(o + 16, &d, 4); std::memcpy(o + 20, &w, 4); }
      uint32_t off, len; std::memcpy(&off, h + 8, 4); std::memcpy(&len, h + 12, 4);
      if (len == 0) { off = 0; len = blk; }
      if (off >= blk || len > blk - off) { o[0] = 0x11; continue; }
      auto& v = kv[k]; v.resize(blk);
      if (h[0] == 0x02) std::memcpy(v.data() + off, cp + hc + i * slot + off, len);
      else std::memcpy(rp + hr + i * slot + off, v.data() + off, len);
    }
    uint8_t* s = rp + n * 32; std::memset(s, 0, 64); s[0] = 0x5A;
    uint32_t beats = blk / 32; std::memcpy(s + 4, &beats, 4);
    uint64_t tot = 1000 * n + 1; std::memcpy(s + 8, &tot, 8); uint32_t mn = 100, mx = 106; std::memcpy(s + 16, &mn, 4); std::memcpy(s + 20, &mx, 4);
    std::memcpy(s + 28, &n, 4);
    uint64_t bpc = std::getenv("MOCK_BEATS") ? std::atoll(std::getenv("MOCK_BEATS")) : 10;
    s[32] = 0x5B; uint64_t rb = bpc * n, wb = (bpc + 2) * n; std::memcpy(s + 40, &rb, 8); std::memcpy(s + 48, &wb, 8);
    if (tiny) { uint64_t tr = treeb(blk, L);
                double f = (tr && topb) ? std::min(1.0, double(topb) / tr) : 0.0;   // the top's share of the traffic
                uint64_t t64r = uint64_t(f * rb / 2), t64w = uint64_t(f * wb / 2), v = (t64r << 8) | (t64w << 36) | 0x5B;
                std::memcpy(s + 32, &v, 8); }
    if (tiny) { uint64_t tr = treeb(blk, L);
                if (n == 0 && topb < tr && (topb & 4095)) { uint32_t e = 0x80; std::memcpy(s + 24, &e, 4); } }
    if (tiny) { uint32_t tb = uint32_t((rtmax ? ttree(blk, L) : treeb(blk, L)) / 64); std::memcpy(s + 56, &N, 4); std::memcpy(s + 60, &tb, 4); }
    if (tiny && rtmax) { s[1] = uint8_t(actL); s[2] = uint8_t(rtmax); s[3] = 6; uint32_t e; std::memcpy(&e, s + 24, 4); e |= rterr; std::memcpy(s + 24, &e, 4); }
    std::printf("[mock] %s: %u commands, %d args\n", name.c_str(), n, nargs);
  }
  uint32_t topb = 0;
  run operator()(bo& c, bo& r, bo& p, uint32_t n) { body(c, r, p, n, 0, 4); return {}; }
  run operator()(bo& c, bo& r, bo& p, uint32_t n, bo&, uint32_t tb) { topb = tb; body(c, r, p, n, 0, 6); return {}; }
  template <class M, class B, class S> run operator()(bo& c, bo& r, bo& p, uint32_t n, M&, B&, S&, uint32_t nblk) { body(c, r, p, n, nblk, 8); return {}; }
  template <class M, class B, class S, class H> run operator()(bo& c, bo& r, bo& p, uint32_t n, M&, B&, S&, uint32_t nblk, H&, uint32_t, uint32_t) { body(c, r, p, n, nblk, 11); return {}; }
};
}
