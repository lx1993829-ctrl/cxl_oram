#pragma once
#include <string>
namespace xrt { struct uuid {}; struct device { device(int){} uuid load_xclbin(const std::string&){return {};} }; }
