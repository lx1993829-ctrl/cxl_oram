// tinyoram_config_2k.vh -- Tiny ORAM build configuration for 2-KB blocks (records of 2,048 B).
// Copied to tinyoram_config.vh for a build; included by Tiny ORAM's Const.vh and PathORAM.vh (patch 01).
// N = 4 * 2^ORAML blocks (256 here; fetch_tinyoram.sh <size> <L> sets another depth), Z = 4, stash C = 10, AES-128 and PMMAC on
// (Tiny ORAM's defaults), FEDWidth 64, BEDWidth 256 = the AXI data width.
`ifndef TINYORAM_CONFIG_VH
`define TINYORAM_CONFIG_VH
`define FPGA_MEMORY                 // behavioural RAMs (block RAM / URAM), not the ASIC SRAM wrappers
`define TINYORAM_ORAMB      16384    // block size in bits
`define TINYORAM_ORAML      6        // levels - 1: 7 levels, 127 buckets, N = 256
`define TINYORAM_BEDWIDTH   256      // backend data width = AXI data width
`endif
