#!/usr/bin/env python3
"""check_p3.py [options] FIX_DUMP [FIX_DUMP ...] -- overlap step 2, phase 3 (ORAM_OV4_P3): every visible time of every
access is recomputed from public events only, and must match exactly (docs/overlap_rtl_spec.md section 17).

Input: the testbench's +fix_dump lines (step 2): id s rq eq hbm hash a ri wi em rel end (absolute cycles; a: the
bucket read's completion, a memory latency; ri: read issue; wi: write-back issue; em: same-bucket mask by distance).

Public events: the starts, the request times, the read completions (memory latency), the same-bucket masks (bucket
equality). From them, with the build's constants:
  t'(j)   = max(a(j), t'(j-1) + GA)                                         effective arrival
  s(j)    = max(s(j-1) + PMIN, t'(j-4) + L, rq(j), ri(q) for every q in j-3..j-1 reading j-4's bucket)   start
  ri(j)   = max(s(j) + CT_RD, t'(j-d) + LEQ for each d in em(j), ri(j-1) + 2, a(j-2))                   read issue
  wi(j)   = t'(j) + AR_WB                                                   write-back issue, both classes
  rel(j)  = t'(j) + (AR_REL_H on package, AR_REL off package)               release
  end(j)  = max(rel(j), end(j-1) + E) + E'                                  results in order
Each term carries a fixed pipeline offset (a few cycles between the decision and where the testbench sees it), fitted
once over all accesses of all files: one value per term, which must then hold for every access. Exit 0 iff all hold."""
import itertools, sys
P = dict(pmin=1500, ctrd=266, ga=1200, arwb=2485, arrel=3733, arrelh=3784, leq=0, l=0)
args = sys.argv[1:]; files = []
while args:
    a = args.pop(0)
    if a.startswith('--'): P[a[2:]] = int(args.pop(0))
    else: files.append(a)
if not P['leq']: P['leq'] = P['arwb'] + 1024 + 300
if not P['l']: P['l'] = max(max(P['arrelh'], P['arrel']) + 250, P['leq'] + 2)
runs = []
for f in files:
    rows = []
    for line in open(f):
        x = line.split()
        if len(x) < 12: continue
        r = dict(id=int(x[0]), s=int(x[1]), rq=int(x[2]), eq=int(x[3]), hbm=int(x[4]), a=int(x[6]), ri=int(x[7]),
                 wi=int(x[8]), em=int(x[9]), rel=int(x[10]), end=int(x[11]))
        rows.append(r)
    rows.sort(key=lambda r: r['id'])
    # accesses are numbered in start order; a gap in the numbering (another run's lines) starts a new sequence
    seq = []
    for r in rows:
        if seq and r['id'] != seq[-1]['id'] + 1: runs.append(seq); seq = []
        seq.append(r)
    if seq: runs.append(seq)
if not runs: sys.exit("check_p3: no phase 3 lines (12 fields) in " + " ".join(files))
GA, PMIN, L, LEQ, CTRD = P['ga'], P['pmin'], P['l'], P['leq'], P['ctrd']
for seq in runs:
    tp = None
    for r in seq:
        tp = r['a'] if tp is None else max(r['a'], tp + GA)
        r['tp'] = tp
bad = 0; out = []
def fit(name, rows, terms, rng=range(-6, 7)):
    """rows: list of (observed, [term values or None]); find one offset per term so that observed == max(term + off)."""
    global bad
    n = len(terms)
    best = None
    for offs in itertools.product(rng, repeat=n):
        miss = 0
        for obs, vals in rows:
            pred = max(v + o for v, o in zip(vals, offs) if v is not None)
            if pred != obs: miss += 1
            if best is not None and miss >= best[0]: break
        if best is None or miss < best[0]: best = (miss, offs)
        if miss == 0: break
    miss, offs = best
    ok = (miss == 0)
    if not ok: bad += 1
    # how often each term decides the time alone (a term that never does is not tested by these runs)
    alone = [0] * n
    for obs, vals in rows:
        v = [(x + o) if x is not None else None for x, o in zip(vals, offs)]
        m = max(x for x in v if x is not None)
        w = [i for i, x in enumerate(v) if x == m]
        if len(w) == 1: alone[w[0]] += 1
    desc = ", ".join(f"{t} {o:+d} (decides {c})" for t, o, c in zip(terms, offs, alone))
    out.append(f"{'PASS' if ok else 'FAIL'}  {name}: {len(rows)} accesses, "
               f"{'exact' if ok else f'{miss} not matching'}; {desc}")
    return offs
# start rule
rows = []
for seq in runs:
    for j, r in enumerate(seq):
        if j == 0: continue                   # the first access of a sequence: its request alone
        p = seq[j - 1]
        t_ctx = seq[j - 4]['tp'] + L if j >= 4 else None
        hold = None
        if j >= 4:
            for q in range(j - 3, j):
                d = q - (j - 4)
                if seq[q]['em'] >> (d - 1) & 1:
                    hold = seq[q]['ri'] if hold is None else max(hold, seq[q]['ri'])
        rows.append((r['s'], [p['s'] + PMIN, t_ctx, r['rq'], hold]))
fit("start rule  s = max(s_prev + PMIN, t'(j-4) + L, request, same-bucket readers' issue)", rows,
    ['s_prev+PMIN', "t'+L", 'request', 'reader issue'])
# read issue
rows = []
for seq in runs:
    for j, r in enumerate(seq):
        eqt = None
        for d in (1, 2, 3):
            if r['em'] >> (d - 1) & 1 and j - d >= 0:
                v = seq[j - d]['tp'] + LEQ; eqt = v if eqt is None else max(eqt, v)
        prev = seq[j - 1]['ri'] + 2 if j >= 1 else None
        free = seq[j - 2]['a'] if j >= 2 else None
        rows.append((r['ri'], [r['s'] + CTRD, eqt, prev, free]))
fit("read issue  ri = max(s + CT_RD, t'(e) + LEQ, previous issue + 2, completion two reads back)", rows,
    ['s+CT_RD', "t'(e)+LEQ", 'prev+2', 'copy free'])
# write-back, release, end
fit("write-back  wi = t' + AR_WB (both classes)", [(r['wi'], [r['tp'] + P['arwb']]) for seq in runs for r in seq], ["t'+AR_WB"])
fit("release off package  rel = t' + AR_REL", [(r['rel'], [r['tp'] + P['arrel']]) for seq in runs for r in seq if not r['hbm']], ["t'+AR_REL"])
fit("release on package   rel = t' + AR_REL_H", [(r['rel'], [r['tp'] + P['arrelh']]) for seq in runs for r in seq if r['hbm']], ["t'+AR_REL_H"])
d = sorted({r['end'] - r['rel'] for seq in runs for r in seq})
okE = len(d) == 1
if not okE: bad += 1
out.append(f"{'PASS' if okE else 'FAIL'}  end = release + a constant: {d[:6]}{' ...' if len(d) > 6 else ''}")
n = sum(len(s) for s in runs); neq = sum(1 for s in runs for r in s if r['em'])
nb = sum(1 for s in runs for r in s if r['hbm'])
print(f"check_p3: {n} accesses in {len(runs)} sequences ({nb} on package, {neq} same-bucket); "
      f"PMIN {PMIN}, L {L}, LEQ {LEQ}, GA {GA}, CT_RD {CTRD}")
for o in out: print("  " + o)
print("check_p3: " + ("ALL RULES EXACT" if bad == 0 else f"{bad} RULE(S) VIOLATED"))
sys.exit(1 if bad else 0)
