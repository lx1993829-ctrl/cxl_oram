#!/usr/bin/env python3
"""csv_extend.py -- add the slowdown-comparison columns to one Tiny ORAM sweep CSV (sweep_tiny.sh calls it after scan.sh).

    python3 csv_extend.py <csv> <log> <clock MHz> <block bytes> <value bytes>

scan.sh's columns stay as they are, in the same order; these are appended to every row:
  clock_mhz             the kernel clock read from the bitstream (xclbinutil --info, DATA_CLK), passed in by sweep_tiny.sh
  block_bytes           the Tiny ORAM block size of the bitstream
  value_bytes           bytes a command reads or writes: 8 with DOMA_PACK=1 (8-byte records packed in a block), else the
                        whole block (an unpacked PUT writes the whole block; its first 8 bytes are the random value)
  hbm_budget_bytes      the bytes of the tree kept on-package for this run (the `top` buffer, after rounding to 4 KB):
                        the host's "placement:" line; 0 = the whole tree in host memory
  dev_cycles_per_query  the query launch's device cycles (kernel start to done) / commands
  lat_mean_cyc          the mean per-command latency in cycles (the host's "latency spread:" line)
  tree_L                the tree depth the run used (a run-time-depth bitstream: the depth selected for N)
The values come from each run's own output in <log> (scan.sh's "==== N=<n> DOMA_TINY_TOP=<setting>" sections), matched
to the row by N and setting. Run again on an extended CSV, it rewrites the same columns (nothing is duplicated).
"""
import csv, re, sys

EXTRA = ['clock_mhz', 'block_bytes', 'value_bytes', 'hbm_budget_bytes', 'dev_cycles_per_query', 'lat_mean_cyc', 'tree_L']

def runs(log):
    out, key, cur = {}, None, None
    for line in open(log, errors='replace'):
        m = re.match(r'^==== N=(\S+) DOMA_TINY_TOP=(\S*)', line)
        if m:
            key = (m.group(1), m.group(2)); cur = out.setdefault(key, {}); continue
        if cur is None: continue
        m = re.match(r'^placement: tree (\d+) B = (\d+) B on-package', line)
        if m: cur['top'] = int(m.group(2))
        m = re.match(r'^device: (\d+) cycles total', line)
        if m: cur['dev'] = int(m.group(1))
        m = re.match(r'^query: (\d+) commands', line)
        if m: cur['cmds'] = int(m.group(1))
        m = re.match(r'^latency spread: .* mean ([0-9.]+) cycles', line)
        if m: cur['mean'] = m.group(1)
        m = re.search(r'running at L=(\d+)', line) or re.match(r'^Tiny ORAM bitstream: N=\d+ blocks \(L=(\d+)\)', line)
        if m: cur['L'] = m.group(1)
    return out

def main():
    path, log, clk, blk, val = sys.argv[1:6]
    rs = runs(log)
    rows = list(csv.reader(open(path)))
    if not rows: return 1
    head = rows[0]
    base = head.index(EXTRA[0]) if EXTRA[0] in head else len(head)
    head = head[:base] + EXTRA
    out = [head]
    for r in rows[1:]:
        r = r[:base]
        g = rs.get((r[0], r[1]), {})
        cpq = '%.1f' % (g['dev'] / g['cmds']) if g.get('dev') and g.get('cmds') else ''
        out.append(r + [clk, blk, val, str(g['top']) if 'top' in g else '', cpq, g.get('mean', ''), g.get('L', '')])
    with open(path, 'w', newline='') as f: csv.writer(f).writerows(out)
    miss = sum(1 for r in out[1:] if r[-3] == '')
    print('   %s: %d rows, columns %s added%s' % (path.split('/')[-1], len(out) - 1, ', '.join(EXTRA),
          '' if not miss else ' (%d rows without a device cycle count: see the log)' % miss))
    return 0

if __name__ == '__main__':
    sys.exit(main())
