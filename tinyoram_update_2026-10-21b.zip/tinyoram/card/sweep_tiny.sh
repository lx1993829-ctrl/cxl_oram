#!/bin/bash
# sweep_tiny.sh -- Tiny ORAM's card sweeps, one per built bitstream of the queue, through scan.sh.
#
#   bash sweep_tiny.sh [id ...]        every entry queue.sh finished (DONE or DONE_LOWER), or only these
#   TOPS="0 doma:0 doma:20 doma:50 doma:100" (default)   CMDS=20000 (default)
#   RT_NS="100000 1000000 10000000" (64 B: 8-byte records) / "16384 65536 262144 1048576" (512 B, 1 KB, 2 KB) /
#          "16384 65536" (4 KB): the N swept on a run-time-depth entry (PM column rt),
#          those up to the entry's N; the host selects the depth for each at its init
#
# Settings matched to sweep_doma.sh: the same host program, generator, seed and command count. For the 64 B builds
# the matched budgets (doma:<p>) are those of doma_kernel with 32-byte blocks packed 4 per block (DOMA_MATCH_BLOCK=32,
# DOMA_PACK=1: exactly sweep_doma.sh's 32 B configuration); for the 4 KB builds, 4 KB blocks unpacked,
# and likewise 512 B, 1 KB and 2 KB blocks unpacked (DOMA_MATCH_BLOCK = the block size). The flat
# position map's entry (FLATPM=1) also takes its 1 MB on-chip position map off the top (DOMA_TINY_FLATPM=1).
# Output: DEST/results/tiny_q<id>_<name>.csv and .log (every run's full output). The CSV has scan.sh's columns, unchanged,
# then (csv_extend.py) clock_mhz (read from the bitstream: xclbinutil --info, DATA_CLK), block_bytes, value_bytes,
# hbm_budget_bytes (the on-package tree top of that run), dev_cycles_per_query, lat_mean_cyc and tree_L.
# DEST/results/clocks.txt gets each bitstream's kernel clock, from the bitstream too. Pass: every row has a KQPS value,
# errors 0x0, bad 0, and a kernel clock.
set -u
CARD=$(cd "$(dirname "$0")" && pwd)
PKG=$(cd "$CARD/../.." && pwd)
DEST=${DEST:-$(dirname "$(dirname "$PKG")")}
Q=$DEST/queue; RES=$DEST/results; mkdir -p "$RES"
XRT_SETUP=${XRT_SETUP:-/opt/xilinx/xrt/setup.sh}
TOPS=${TOPS:-"0 doma:0 doma:20 doma:50 doma:100"}; CMDS=${CMDS:-20000}
command -v xclbinutil > /dev/null || source "$XRT_SETUP" > /dev/null 2>&1
clk() { xclbinutil --info -i "$1" 2>/dev/null | awk '/Name:.*DATA_CLK/{f=1} f && /Frequency:/{print $2; exit}'; }   # as check_timing.sh
st_get() { [ -f "$Q/$1.status" ] && awk -F= -v k="$2" '$1 == k {v = substr($0, length(k) + 2)} END {print v}' "$Q/$1.status"; }
fail=0
while read -r id name sz n pack cfg merge flatpm freq purpose; do
    [ $# -gt 0 ] && ! printf '%s\n' "$@" | grep -qx "$id" && continue
    stage=$(st_get $id stage); x=$(st_get $id xclbin)
    case "$stage" in DONE*) ;; *) echo "q$id $name: not built ($stage), skipped"; continue ;; esac
    d=$(dirname "$x"); [ -f "$x" ] && [ -x "$d/host_doma" ] || { echo "q$id $name: $x or its host_doma missing"; fail=1; continue; }
    bb=$sz; case "$sz" in 1k) bb=1024 ;; 2k) bb=2048 ;; 4k) bb=4096 ;; esac
    ns=$n
    if [ "$flatpm" = rt ]; then   # one run-time-depth bitstream: every N of RT_NS up to its own
        dn="100000 1000000 10000000"; [ $bb -gt 64 ] && dn="16384 65536 262144 1048576"; [ $bb = 4096 ] && dn="16384 65536"
        ns=""; for v in ${RT_NS:-$dn}; do [ $v -le $n ] && ns="$ns $v"; done
        ns=${ns# }
    fi
    env=(DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=$bb "NS=$ns" "TOPS=$TOPS" OUT=$RES/tiny_q${id}_$name.csv)
    [ "$pack" = 1 ] && env+=(DOMA_PACK=1)
    [ "$bb" -gt 64 ] && env+=(DOMA_MATCH_BLOCK=$bb) || env+=(DOMA_MATCH_BLOCK=32)
    [ "$flatpm" = 1 ] && env+=(DOMA_TINY_FLATPM=1)
    case "$cfg" in tinyoram_host*.cfg) ;; *) env+=(DOMA_PAGES_HBM=1) ;; esac   # tree in HBM: tinyoram_hw.cfg
    echo "== q$id $name: $(basename "$x"), N=$ns, TOPS=$TOPS, $CMDS commands"
    ( cd "$d" && env "${env[@]}" bash scan.sh "$(basename "$x")" $CMDS < /dev/null )
    mhz=$(clk "$x")
    [ -n "$mhz" ] || { echo "   FAIL: cannot read the kernel clock from $(basename "$x") (xclbinutil --info)"; fail=1; }
    echo "tiny q$id $name ${mhz:-unknown}" >> "$RES/clocks.txt"
    vb=$bb; [ "$pack" = 1 ] && vb=8
    python3 "$CARD/csv_extend.py" "$RES/tiny_q${id}_$name.csv" "$RES/tiny_q${id}_$name.log" "${mhz:-}" $bb $vb || fail=1
    awk -F, 'NR > 1 && ($4 == "" || $9 != "0x0" || $10 != "0") {bad = 1} END {exit bad}' "$RES/tiny_q${id}_$name.csv" \
        && echo "   PASS: every row measured, errors 0x0, all responses correct" || { echo "   FAIL: see $RES/tiny_q${id}_$name.log"; fail=1; }
done < <(awk '!/^#/ && NF >= 9' "$CARD/queue.txt")
exit $fail
