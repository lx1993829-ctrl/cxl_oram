#!/usr/bin/env python3
"""traffic_levels.py -- where a Tiny ORAM access's bytes go, per run of a sweep log (README §22).

    python3 traffic_levels.py DEST/results/tiny_q8_64_n10M_merge_rt.log [more logs]

For every run in the log (scan.sh's "==== N=<n> DOMA_TINY_TOP=<setting>" sections) it prints:
  L, R            the tree depth and the position-map recursion depth the run used: R - 1 PosMap levels live in the
                  tree, the last level's leaves on chip (Tiny ORAM's rule "recursive until < 1024 entries", README §17)
  final           the on-chip final PosMap's entries
  path            bytes of one path read (= one path write): (L + 1) buckets of (header + Z blocks) in 64-byte bursts
  rd/cmd, wr/cmd  the kernel's traffic counters per command (both tree ports: host memory and the on-package top)
  B/level         rd/cmd / (L + 1): read bytes per tree level per command
  paths/cmd       rd/cmd / path: path reads per command, measured (data + PosMap fetches + background evictions)
  model           path reads per command without background evictions, from an exact model of Tiny ORAM's lookup
                  (UORAMController.v, PosMapPLB.v: a direct-mapped PLB of 8 KB, PosMap block index mod its lines;
                  keys uniform over the records, as host_doma.cpp generates them), with the share of accesses that
                  fetch each PosMap level (P(fetch level k))
  bg/cmd          paths/cmd - model: background-eviction (dummy) paths per command
The model needs no card; the measured columns need the log of a card run.
"""
import random, re, sys

def geo(blk, L, ddr_bits=512):
    lib = blk * 8 // 64; lg = lib.bit_length() - 1
    x = L + 2 - 10; R = 1 if x <= 0 else (x + lg - 1) // lg + 1
    nvb = 4 << L
    fstart = sum(nvb // lib ** j for j in range(R - 1)); fentry = nvb // lib ** (R - 1)
    hdr = 64 + 8 + 32 * 4 + L * 4 + 128 * 4
    bucket = (-(-hdr // ddr_bits) + 4 * -(-blk * 8 // ddr_bits)) * ddr_bits // 8
    return dict(lib=lib, R=R, nvb=nvb, fstart=fstart, fentry=fentry, path=(L + 1) * bucket)

def model(blk, L, nblocks, ddr_bits=512, plb_bytes=8192, ncmd=100000, warm=100000, seed=1):
    g = geo(blk, L, ddr_bits); lib, nvb, fs = g['lib'], g['nvb'], g['fstart']
    lines = plb_bytes * 8 // (64 * lib); plb = [-1] * lines; rnd = random.Random(seed)
    tot = 0; fetch = [0] * g['R']
    for i in range(warm + ncmd):
        q = [rnd.randrange(nblocks)]; h = 0
        while q[h] < fs and plb[(q[h] // lib) % lines] != q[h] // lib:
            q.append(nvb + q[h] // lib); h += 1
        for k in range(h, 0, -1): plb[(q[k - 1] // lib) % lines] = q[k - 1] // lib
        if i >= warm:
            tot += h + 1
            for k in range(1, h + 1): fetch[k] += 1
    return g, tot / ncmd, [f / ncmd for f in fetch[1:]]

def runs(log):
    out, cur = [], None
    for line in open(log, errors='replace'):
        m = re.match(r'^==== N=(\d+) DOMA_TINY_TOP=(\S*)', line)
        if m: cur = dict(n=int(m.group(1)), top=m.group(2)); out.append(cur); continue
        if cur is None: continue
        m = re.match(r'^size: (\d+) blocks, Tiny ORAM tree for L=(\d+) .* (\d+)-byte blocks', line)
        if m: cur.update(blocks=int(m.group(1)), L=int(m.group(2)), blk=int(m.group(3)))
        m = re.search(r'running at L=(\d+)', line)
        if m: cur['L'] = int(m.group(1))
        m = re.match(r'^traffic: .* = (\d+) B read, (\d+) B written per command', line)
        if m: cur.update(rd=int(m.group(1)), wr=int(m.group(2)))
        m = re.match(r'^query: .* = ([0-9.]+) KQPS', line)
        if m: cur['kqps'] = float(m.group(1))
    return out

def main():
    cache = {}
    for log in sys.argv[1:]:
        print('== %s' % log)
        print('%9s %-9s %3s %2s %6s %6s %7s %7s %7s %8s %6s  %-26s %6s %8s' % ('N', 'top', 'L', 'R', 'final', 'path', 'rd/cmd', 'wr/cmd',
              'B/level', 'paths/cmd', 'model', 'P(fetch level 1..R-1)', 'bg/cmd', 'KQPS'))
        for r in runs(log):
            if 'L' not in r or 'blk' not in r: continue
            key = (r['blk'], r['L'], r['blocks'])
            if key not in cache: cache[key] = model(*key)
            g, p, fetch = cache[key]
            meas = r['rd'] / g['path'] if 'rd' in r else None
            f = lambda v, fmt: (fmt % v) if v is not None else '-'
            print('%9d %-9s %3d %2d %6d %6d %7s %7s %7s %8s %6.3f  %-26s %6s %8s' % (
                r['n'], r['top'], r['L'], g['R'], g['fentry'], g['path'], f(r.get('rd'), '%d'), f(r.get('wr'), '%d'),
                f(r['rd'] / (r['L'] + 1) if 'rd' in r else None, '%.0f'), f(meas, '%.3f'), p,
                ' '.join('%.3f' % x for x in fetch), f(meas - p if meas is not None else None, '%.3f'), f(r.get('kqps'), '%.1f')))
    return 0

if __name__ == '__main__':
    sys.exit(main())
