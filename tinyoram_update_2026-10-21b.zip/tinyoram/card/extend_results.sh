#!/bin/bash
# extend_results.sh -- add the slowdown-comparison columns (csv_extend.py: clock_mhz from the bitstream, block_bytes,
# value_bytes, hbm_budget_bytes, dev_cycles_per_query, lat_mean_cyc, tree_L) to the Tiny ORAM CSVs already in
# DEST/results, from their own logs: no card run. New sweeps (sweep_tiny.sh) add them by themselves.
#   bash extend_results.sh [id ...]        every DEST/results/tiny_q<id>_<name>.csv, or only these entries
# Each CSV is backed up once as <csv>.orig before its first change. Last line: "EXTENDED n CSV(S)" or "FAILED: ...".
set -u
CARD=$(cd "$(dirname "$0")" && pwd)
PKG=$(cd "$CARD/../.." && pwd)
DEST=${DEST:-$(dirname "$(dirname "$PKG")")}
Q=$DEST/queue; RES=$DEST/results
XRT_SETUP=${XRT_SETUP:-/opt/xilinx/xrt/setup.sh}
command -v xclbinutil > /dev/null || source "$XRT_SETUP" > /dev/null 2>&1
clk() { xclbinutil --info -i "$1" 2>/dev/null | awk '/Name:.*DATA_CLK/{f=1} f && /Frequency:/{print $2; exit}'; }
st_get() { [ -f "$Q/$1.status" ] && awk -F= -v k="$2" '$1 == k {v = substr($0, length(k) + 2)} END {print v}' "$Q/$1.status"; }
n=0; bad=""
while read -r id name sz nn pack cfg merge pm freq purpose; do
    [ $# -gt 0 ] && ! printf '%s\n' "$@" | grep -qx "$id" && continue
    csv=$RES/tiny_q${id}_$name.csv; log=${csv%.csv}.log
    [ -f "$csv" ] || continue
    [ -f "$log" ] || { bad="$bad q$id(no log)"; continue; }
    x=$(st_get $id xclbin); mhz=""; [ -f "$x" ] && mhz=$(clk "$x")
    [ -n "$mhz" ] || { bad="$bad q$id(no clock from ${x:-its xclbin})"; continue; }
    bb=$sz; case "$sz" in 1k) bb=1024 ;; 2k) bb=2048 ;; 4k) bb=4096 ;; esac; vb=$bb; [ "$pack" = 1 ] && vb=8
    [ -f "$csv.orig" ] || cp "$csv" "$csv.orig"
    python3 "$CARD/csv_extend.py" "$csv" "$log" "$mhz" $bb $vb && n=$((n + 1)) || bad="$bad q$id"
done < <(awk '!/^#/ && NF >= 9' "$CARD/queue.txt")
[ -z "$bad" ] && echo "EXTENDED $n CSV(S)" || { echo "FAILED:$bad"; exit 1; }
