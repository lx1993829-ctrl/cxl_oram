#!/bin/bash
# accept_rt.sh -- the run-time tree depth's card acceptance (README §18): the run-time-depth bitstream (queue entry 8,
# L_max = 19) at N = 1M records against the native build of that depth (queue entry 1, L = 15). Same host program,
# same command stream and seeds, runs alternating native / run-time, REPS times per setting.
#
#   bash accept_rt.sh [native id] [run-time id]       default: 1 8
#   N=1000000 REPS=5 CMDS=20000 TOPS="0 doma:20"     (defaults)   NOISE_PCT=2
#
# Pass, per setting:
#   (a) traffic per command identical (exact: Tiny ORAM's paths, evictions and PosMap accesses depend only on the
#       command stream and its fixed keys, not on timing);
#   (b) latency p50 and p99 (cycles) within NOISE_PCT of the native build's, averaged over the reps;
#   (c) KQPS (mean of the reps) within the larger of NOISE_PCT and twice the native build's own run-to-run spread;
#   (d) every run correct (ALL RESPONSES CORRECT, errors 0x0), the run-time bitstream running at the requested L;
# and both bitstreams at the same kernel clock (queue status). Report: DEST/results/accept_rt.txt; last line
# "ACCEPT PASS" or "ACCEPT FAIL".
set -u
CARD=$(cd "$(dirname "$0")" && pwd)
PKG=$(cd "$CARD/../.." && pwd)
DEST=${DEST:-$(dirname "$(dirname "$PKG")")}
Q=$DEST/queue; RES=$DEST/results; mkdir -p "$RES"
XRT_SETUP=${XRT_SETUP:-/opt/xilinx/xrt/setup.sh}
command -v xbutil > /dev/null || source "$XRT_SETUP" > /dev/null 2>&1
NID=${1:-1}; RID=${2:-8}
N=${N:-1000000}; REPS=${REPS:-5}; CMDS=${CMDS:-20000}; TOPS=${TOPS:-"0 doma:20"}; NOISE=${NOISE_PCT:-2}
st_get() { [ -f "$Q/$1.status" ] && awk -F= -v k="$2" '$1 == k {v = substr($0, length(k) + 2)} END {print v}' "$Q/$1.status"; }
entry() { awk -v i="$1" '!/^#/ && NF >= 9 && $1 == i' "$CARD/queue.txt"; }
REP=$RES/accept_rt.txt; : > $REP
say() { echo "$*" | tee -a $REP; }
fail=0
for id in $NID $RID; do
    case "$(st_get $id stage)" in DONE*) ;; *) say "queue entry $id is not built ($(st_get $id stage))"; echo "ACCEPT FAIL" | tee -a $REP; exit 1 ;; esac
done
read -r _ nname nsz _ npack ncfg nmerge npm _ _ <<< "$(entry $NID)"
read -r _ rname rsz rn rpack rcfg rmerge rpm _ _ <<< "$(entry $RID)"
[ "$rpm" = rt ] && [ "$npm" = 0 ] && [ "$nsz" = "$rsz" ] && [ "$npack" = "$rpack" ] && [ "$nmerge" = "$rmerge" ] && [ "$ncfg" = "$rcfg" ] \
    || { say "entries $NID and $RID must differ only in the run-time depth (PM 0 against rt)"; echo "ACCEPT FAIL" | tee -a $REP; exit 1; }
nx=$(st_get $NID xclbin); rx=$(st_get $RID xclbin); nclk=$(st_get $NID clock_mhz); rclk=$(st_get $RID clock_mhz)
say "native:   q$NID $nname  $(basename $nx)  clock ${nclk:-?} MHz"
say "run-time: q$RID $rname  $(basename $rx)  clock ${rclk:-?} MHz"
[ -n "$nclk" ] && [ "$nclk" = "$rclk" ] && say "clock: the same ($nclk MHz)" || { say "clock: DIFFERENT (${nclk:-?} / ${rclk:-?} MHz)"; fail=1; }
bb=$nsz; case "$nsz" in 1k) bb=1024 ;; 2k) bb=2048 ;; 4k) bb=4096 ;; esac
env0=(DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=$bb DOMA_N=$N)
[ "$npack" = 1 ] && env0+=(DOMA_PACK=1)
[ "$bb" -gt 64 ] && env0+=(DOMA_MATCH_BLOCK=$bb) || env0+=(DOMA_MATCH_BLOCK=32)
case "$ncfg" in tinyoram_host*.cfg) ;; *) env0+=(DOMA_PAGES_HBM=1) ;; esac
one() {   # one <xclbin> <top> <log>: one run; prints "kqps p50 p99 rdB wrB ok L"
    local x=$1 t=$2 log=$3
    ( cd "$(dirname $x)" && env "${env0[@]}" DOMA_TINY_TOP=$t ./host_doma "$(basename $x)" $CMDS < /dev/null ) > $log 2>&1
    local kq p50 p99 tr ok L
    kq=$(awk '/^query:/{print $(NF-1)}' $log)
    p50=$(grep -m1 '^latency spread:' $log | sed -E 's/.*p50 ([0-9]+).*/\1/'); p99=$(grep -m1 '^latency spread:' $log | sed -E 's/.*p99 ([0-9]+).*/\1/')
    tr=$(grep -m1 '^traffic: ' $log | sed -E 's/.*= ([0-9]+) B read, ([0-9]+) B written per command.*/\1 \2/')
    ok=0; grep -q "ALL RESPONSES CORRECT" $log && ! grep -qE "errors=0x[1-9a-f]" $log && ok=1
    L=$(grep -m1 -oE "Tiny ORAM bitstream: N=[0-9]+ blocks \(L=[0-9]+\)" $log | grep -oE "L=[0-9]+" | cut -d= -f2)
    echo "${kq:-0} ${p50:-0} ${p99:-0} ${tr:-0 0} $ok ${L:-0}"
}
for t in $TOPS; do
    say ""; say "== N=$N, DOMA_TINY_TOP=$t, $REPS reps x $CMDS commands"
    : > $RES/accept_rt_n.dat; : > $RES/accept_rt_r.dat
    for r in $(seq 1 $REPS); do
        a=$(one $nx $t $RES/accept_rt_n_${t/:/_}_$r.log); b=$(one $rx $t $RES/accept_rt_r_${t/:/_}_$r.log)
        echo "$a" >> $RES/accept_rt_n.dat; echo "$b" >> $RES/accept_rt_r.dat
        say "   rep $r  native: $a   run-time: $b   (KQPS p50 p99 rdB wrB ok L)"
    done
    v=$(python3 - $RES/accept_rt_n.dat $RES/accept_rt_r.dat $NOISE <<'PY'
import sys
n = [list(map(float, l.split())) for l in open(sys.argv[1]) if l.strip()]
r = [list(map(float, l.split())) for l in open(sys.argv[2]) if l.strip()]
noise = float(sys.argv[3])
m = lambda xs: sum(xs) / len(xs)
kn, kr = m([x[0] for x in n]), m([x[0] for x in r])
spread = (max(x[0] for x in n) - min(x[0] for x in n)) / kn * 100 if kn else 100
tol = max(noise, 2 * spread)
dk = (kr - kn) / kn * 100 if kn else 100
d50 = (m([x[1] for x in r]) - m([x[1] for x in n])) / max(1, m([x[1] for x in n])) * 100
d99 = (m([x[2] for x in r]) - m([x[2] for x in n])) / max(1, m([x[2] for x in n])) * 100
tr_same = len({(x[3], x[4]) for x in n + r}) == 1
ok = all(x[5] == 1 for x in n + r)
Ls = {int(x[6]) for x in r}; Ln = {int(x[6]) for x in n}
good = tr_same and abs(d50) <= noise and abs(d99) <= noise and abs(dk) <= tol and ok and Ls == Ln
print("%s KQPS %.1f / %.1f (%+.2f%%, tolerance %.2f%%: native spread %.2f%%); p50 %+.2f%%, p99 %+.2f%% (tolerance %.1f%%); "
      "traffic per command %s; correct %s; depth native %s, run-time %s"
      % ("PASS" if good else "FAIL", kr, kn, dk, tol, spread, d50, d99, noise,
         "identical (%d B read, %d B written)" % (n[0][3], n[0][4]) if tr_same else "DIFFERENT", "yes" if ok else "NO",
         sorted(Ln), sorted(Ls)))
PY
)
    say "   $v"
    case "$v" in PASS*) ;; *) fail=1 ;; esac
done
say ""
[ $fail = 0 ] && say "ACCEPT PASS" || say "ACCEPT FAIL"
exit $fail
