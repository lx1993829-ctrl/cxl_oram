# NOCRYPTO phase 3 overlap (evaluation only)

Package `fpga_zcu208_v14c_krt_nocrypto_full.zip` (2026-11-09) = the KRT package (phase 3 overlap, run-time in-flight
cap K) + the serial NOCRYPTO build with its run-time times (docs/nocrypto.md) + this file's build: the phase 3 overlap
with no encryption, for the comparison with BOLT at small values. Not a secure build: no confidentiality, no integrity.

## What changes (all under `ifdef ORAM_NOCRYPTO` with `ORAM_OV4_P3`)

- **Every bucket takes the existing on-package plaintext path** (`f_hbm = 1` in the front stage). The kernel still
  routes each bucket to host memory or HBM by its address (`doma_kernel.v`, `hb_lim`), so placement (20% in HBM) is
  unchanged. There is one class of times.
- **No AES-GCM core.** Neither core D nor core E is instantiated; the AES and GHASH sources stay out of the Vivado
  project (`package_kernel.tcl`). The E stage pops each access without an IV advance (no IV exists). The boot
  format writes zero buckets everywhere, as in the serial NOCRYPTO build.
- **The schedule is phase 3's, unchanged in form** (docs/overlap_rtl_spec.md section 17): starts, read issues,
  write-backs at exactly t' + WB, releases at t' + REL, results in order. Its seven constants are kernel registers,
  written before `ap_start` and fixed for the run (0 = the build's value):

  | Register | Offset | Host variable | Meaning (cycles) | build.sh | 256 B build default |
  |---|---|---|---|---|---|
  | rel | 0x84 | DOMA_REL | release after the effective arrival t' (every bucket) | NC_REL | 600 |
  | ctrd | 0x94 | DOMA_CTRD | read gate after the start (the lookup's budget) | OV_CTRD | 400 |
  | wb | 0x9C | DOMA_WB | write-back issue after t' | NC_WB | 400 |
  | pmin | 0xA4 | DOMA_PMIN | least start spacing | OV_PMIN | 400 |
  | ga | 0xAC | DOMA_GA | least spacing of effective arrivals | OV_GA | 400 |
  | l | 0xB4 | DOMA_L | context free after t' (the access four later may start) | OV_L | 900 |
  | leq | 0xBC | DOMA_LEQ | same-bucket read after t' | OV_LEQ | WB + 64 + 3300 |

  `rel_h` (0x8C) is unused here. K stays in bits [31:29] of `hbm_bkts` (`DOMA_OV_K`). Setting any of DOMA_WB,
  DOMA_PMIN, DOMA_GA, DOMA_L or DOMA_LEQ makes `host_doma` pass 19 arguments. Each time is a public constant of the
  run, so every visible time stays a function of public events.
- **Fail-stop is immediate for late decisions**: an access whose decisions end after its write slot halts then,
  before any write (in the encrypted build an on-package one halted at its release time). Too small a time can only
  halt (error 0x108), never return a wrong value or move a visible event.
- Crypto builds are untouched: 66 preprocessing comparisons (serial, overlap steps 1 and 2, phase 3, fixed K, the
  leak test, PLAIN, debug, with and without SYNTHESIS) give exactly the KRT package's text; the serial NOCRYPTO build
  equals the tested `respfix_nocrypto` tree apart from KRT's K field.

## Build (256 B)

    NOCRYPTO=1 OVERLAP=4 P3=1 BEATS=8 SCHED=arrival CFG=doma_big2m_rama.cfg NMAX=2097152 LAMBDA=7 TARGET=hw \
      OV_CTRD=400 OV_PMIN=400 OV_GA=400 NC_WB=400 NC_REL=600 OV_L=900 bash build.sh

No `RAMA=1` (refused with overlap; its budgets are not used: preprocessing is identical with and without it at
256 B) and no `FIXWB`. `ncov_run.sh` (next to the zip) builds this and measures three settings.

## Regression: `sim/run_nc_overlap.sh` (B=8)

The phase 3 set of `run_overlap.sh OV=5`, at 256 B: correctness and eviction scoreboard in every run, paired
0/50/100% PUT streams with identical visible hashes, the injected leak (a PUT's read one cycle late) caught by the
hashes and by `check_p3.py`, the exact schedule rule over every access at the build times and at run-time times,
K = 3 and 2 at run time, and deliberately small times (GA 150, WB 40, CTRD 60) that must halt without a wrong value.

Simulation sweep (card-like host reads 480 cycles with 15% gaps and 5% of bursts 3,400 slower, RAMA-like stash,
half PUTs): GA is the binding time; below about 350 the main stage cannot keep up and the design halts. Device cycles
per command at 0 / 20 / 100% in HBM: ctrd 266, pmin = ga = 400, wb 300, rel 500, l 750: 607 / 555 / 441; ctrd 266,
pmin = ga = 350, wb 250, rel 450, l 700: 587 / 533 / 396. Worst decisions end 262 cycles after t' (100% in HBM),
so wb 250 can halt there; the regression's card times use wb 300.

Regression 2026-11-09 (`docs/nocrypto_overlap_regression_2026-11-09.txt`): 68 passed, 0 failed. Device cycles per
command, serial NOCRYPTO vs this overlap at the build times: 0% in HBM 1187 vs 465, 20% (RAMA-like stash) 1176 vs 446,
100% 1120 vs 405 (2.5-2.8x). Card times under host read tails: 442 at 20%, 369 at 100%; K = 3: 559, K = 2: 813.
Worst readouts at the card times: lookup 200, decisions 291 after t' (so keep wb at 330 or more on the card), write
handed off 373 after t'. The mock-XRT run of the card's host_doma with all 19 arguments: every response correct.

## Assumption (stated, not covered)

A host write must be readable once acknowledged, or within about L + CTRD - WB - 200 cycles of it (PCIe keeps a read
behind an earlier posted write, so this holds on the card). The same-bucket gate covers the three accesses before;
older ones rely on the context rule (L). The encrypted build's 2,500-cycle late-landing stress test is outside this
when L is small: there it gives wrong GETs (the encrypted build's tag check would halt instead). On the card every
GET is checked by `host_doma`, so a violation shows as ERRORS FOUND, never as a silent result.

## Why the main stage limits throughput

In phase 3 the stash is opened for an access only after the previous access's commit and eviction copies, so the
main stage serves accesses one at a time: with a 120-cycle stash latency about 330 cycles each. That, not the bus
(64 beats per bucket each way), bounds the overlap at small values.
