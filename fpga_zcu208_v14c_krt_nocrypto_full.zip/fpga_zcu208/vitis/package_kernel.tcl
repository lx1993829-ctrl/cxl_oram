# package_kernel.tcl -- package rtl/ as the Vitis RTL kernel doma_kernel.xo  (UNTESTED here)
# Usage: vivado -mode batch -source package_kernel.tcl -tclargs <rtl dir> <output .xo>
# Follows AMD's Vitis RTL-kernel flow (Vitis_Accel_Examples rtl_kernels/*/scripts/package_kernel.tcl).
# Synthesis defines SYNTHESIS, so oram_params.vh builds the production configuration (no debug ports).
set rtl_dir [lindex $argv 0]
set xo_path [lindex $argv 1]
set part    xcu55c-fsvh2892-2L-e
set ip_dir  ./doma_ip

create_project -force doma_pack ./doma_pack -part $part
add_files -norecurse [glob $rtl_dir/*.v $rtl_dir/*.vh]
# the self-test top is for the ZCU208 board, not part of the kernel
remove_files -quiet [get_files -quiet */onboard_test_top.v]
# build.sh NOCRYPTO=1: nothing instantiates the AES-GCM core, so its sources stay out of the project
if {[info exists ::env(NOCRYPTO)] && $::env(NOCRYPTO) eq "1"} {
    remove_files -quiet [get_files -quiet {*/aes_*.v */aes128_*.v */ghash_*.v}]
}
set_property file_type {Verilog Header} [get_files *.vh]
set_property top doma_kernel [current_fileset]
update_compile_order -fileset sources_1

ipx::package_project -root_dir $ip_dir -vendor user.org -library kernel -taxonomy /KernelIP -import_files -set_current false
ipx::unload_core $ip_dir/component.xml
ipx::edit_ip_in_project -upgrade true -name tmp_edit_project -directory $ip_dir $ip_dir/component.xml
set core [ipx::current_core]
set_property core_revision 1 $core
foreach up [ipx::get_user_parameters] { ipx::remove_user_parameter [get_property NAME $up] $core }

foreach bif {s_axi_control m_axi_gmem0 m_axi_gmem1 m_axi_gmem2 m_axi_gmem3 m_axi_gmem4 m_axi_gmem5 m_axi_gmem6} {
    ipx::associate_bus_interfaces -busif $bif -clock ap_clk $core
}
set clkbif [ipx::get_bus_interfaces -of $core ap_clk]
set_property value 300000000 [ipx::add_bus_parameter -quiet FREQ_HZ $clkbif]

# control register map; pointer registers name the AXI master they address
set mm [ipx::add_memory_map -quiet s_axi_control $core]
set ab [ipx::add_address_block -quiet reg0 $mm]
set regs {CTRL 0x000 32 {} GIER 0x004 32 {} IP_IER 0x008 32 {} IP_ISR 0x00C 32 {}
                           cmd_input 0x010 64 m_axi_gmem0 resp_output 0x01C 64 m_axi_gmem1
                           pages 0x028 64 m_axi_gmem2 size 0x034 32 {}
                           meta 0x03C 64 m_axi_gmem3 brec 0x048 64 m_axi_gmem4
                           stash 0x054 64 m_axi_gmem5 nblk 0x060 32 {} pages_hbm 0x068 64 m_axi_gmem6 hbm_bkts 0x074 32 {} pool_n 0x07C 32 {}}
# NOCRYPTO=1: the run-time release times and read gate (docs/nocrypto.md)
set kernel_xml ./kernel.xml
if {[info exists ::env(NOCRYPTO)] && $::env(NOCRYPTO) eq "1"} {
    lappend regs rel 0x084 32 {} rel_h 0x08C 32 {} ctrd 0x094 32 {}
    set kernel_xml ./kernel_nocrypto.xml
    # NOCRYPTO=1 with OVERLAP=4 P3=1 (build.sh sets NC_OV=1; docs/nocrypto_overlap.md): the rest of the phase 3 schedule
    if {[info exists ::env(NC_OV)] && $::env(NC_OV) eq "1"} {
        lappend regs wb 0x09C 32 {} pmin 0x0A4 32 {} ga 0x0AC 32 {} l 0x0B4 32 {} leq 0x0BC 32 {}
        set kernel_xml ./kernel_nocrypto_ov.xml
    }
}
foreach {name off sz bif} $regs {
    set r [ipx::add_register $name $ab]
    set_property address_offset $off $r
    set_property size $sz $r
    if {$bif ne ""} { set_property value $bif [ipx::add_register_parameter ASSOCIATED_BUSIF $r] }
}
set_property slave_memory_map_ref s_axi_control [ipx::get_bus_interfaces -of $core s_axi_control]

set_property xpm_libraries {XPM_CDC XPM_MEMORY XPM_FIFO} $core
set_property sdx_kernel true $core
set_property sdx_kernel_type rtl $core
set_property supported_families { } $core
set_property auto_family_support_level level_2 $core
ipx::create_xgui_files $core
ipx::update_checksums $core
ipx::check_integrity -kernel $core
ipx::save_core $core
close_project -delete

package_xo -force -xo_path $xo_path -kernel_name doma_kernel -ip_directory $ip_dir -kernel_xml $kernel_xml
