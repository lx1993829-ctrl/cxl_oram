#!/usr/bin/env python3
"""check_same_schedule.py A.csv B.csv -- two phase logs of the same run differ only by when each launch started: every
column but 'start' identical, and 'start' shifted by one constant within each stretch (a launch). --max-launches N (default 4)."""
import csv, sys
a = sys.argv[1:]; m = 4
if "--max-launches" in a: i = a.index("--max-launches"); m = int(a[i + 1]); del a[i:i + 2]
x, y = [list(csv.DictReader(open(f))) for f in a]
if not x or len(x) != len(y): sys.exit(f"FAIL: {len(x)} and {len(y)} accesses")
for i, (p, q) in enumerate(zip(x, y)):
    for k in p:
        if k != "start" and p[k] != q[k]: sys.exit(f"FAIL: access {i}, column {k}: {p[k]} and {q[k]}")
s = [int(q["start"]) - int(p["start"]) for p, q in zip(x, y)]
ch = [i for i in range(1, len(s)) if s[i] != s[i - 1]]
if len(ch) + 1 > m: sys.exit(f"FAIL: the start shift changes {len(ch)} times, more than {m} launches: first at {ch[:6]}")
print(f"PASS {len(x)} accesses identical; start shift {sorted(set(s))}, changing at accesses {ch}")
