#!/bin/bash
# run_nocrypto_rel.sh -- the run-time release times of a NOCRYPTO build (kernel registers rel 0x84, rel_h 0x8C; docs/nocrypto.md).
# Per block size, from one production build at its table times (write-back times unchanged):
#   1. registers unset, or written 0: the build's times, the identical schedule access by access;
#   2. other values, for both classes or just one: all responses correct, and every access released at exactly t_arr + the
#      value given (check_nocrypto.py), while the write-back stays at t_arr + WBF;
#   3. visible hashes identical across the GET / PUT mix at a run-time value;
#   4. a value too small for the write: a fail-stop halt, never a wrong answer;
#   5. the read gate (register ctrd 0x94): every read issued at exactly the value given, alone and with release values, all
#      responses correct, visible hashes identical across the GET / PUT mix; a gate too small for the lookup halts, no wrong answer.
# Usage: bash run_nocrypto_rel.sh [BEATS ...]   default 1 2 4 8. Logs: build/nocrypto_rel/b<beats>/. J=<jobs>.
set -u
cd "$(dirname "$0")"
SIM=$(pwd); RTL=$(cd ../rtl && pwd); SIZES=${*:-1 2 4 8}; J=${J:-$(nproc)}
SRCS_NC=$(grep -vE '^(aes|ghash)' files_rtl.lst | sed "s#^#$RTL/#" | tr '\n' ' ')
TOP=$SIM/build/nocrypto_rel; mkdir -p $TOP; pass=0; fail=0
ok() { echo "PASS  $*"; pass=$((pass+1)); }
bad() { echo "FAIL  $*"; fail=$((fail+1)); }
pv() { grep -E "^\`define $1 " $RTL/oram_params.vh | tr -d '\r' | awk '{print $3}'; }
VF="--binary --timing -j 2 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-BLKANDNBLK -I$RTL"
clean() { grep -q "ALL CHECKS PASSED" $1 && grep -q "eviction scoreboard: .* 0 wrong" $1 && ! grep -q "DOMA HALT" $1; }
vis() { grep -E "^[a-z0-9]+: (bucket-port timing hash|folded off-package shape hash|off-package access shape hash|on-package release/end hash|traffic record)|^\*\*\* DOMA" $1; }
for B in $SIZES; do
    O=$TOP/b$B; mkdir -p $O; P="$((B*32)) B"
    W_H=$(pv ORAM_NC_WBF_H_B$B); W=$(pv ORAM_NC_WBF_B$B); R_H=$(pv ORAM_NC_REL_H_B$B); R=$(pv ORAM_NC_REL_B$B)
    echo "== $P: WBF $W_H / $W, table REL $R_H / $R"
    for try in 1 2 3 4; do
        rm -rf $O/nc; verilator $VF -DORAM_C=7 -DORAM_N=4096 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -DORAM_ONPKG_FIXWB -DORAM_ONPKG_RAMA -DORAM_BLOCK_BEATS=$B -DORAM_NOCRYPTO \
            --top-module tb_doma_kernel tb_doma_kernel.v oram_timing_monitor.v axi_mem_model.v $SRCS_NC $RTL/doma_kernel.v -Mdir $O/nc -o V > $O/nc.build.log 2>&1 && break
    done
    [ -x $O/nc/V ] || { bad "$P: build failed ($O/nc.build.log)"; continue; }
    H="+hb=0 +host_lat=480 +host_wlat=98 +hbmb_wlat=26 +host_slow_pct=3 +host_slow_extra=1500 +hbmb_slow_pct=3 +hbmb_slow_extra=300 +preload +cmds2=4"
    HQ="+hb=0 +host_lat=480 +host_wlat=98 +hbmb_wlat=26 +cmds=200 +cmds2=4 +seed=3 +halt_wait=60000 +preload"
    UP="+nc_rel=$((R+40)) +nc_rel_h=$((R_H+40))"
    cat > $O/jobs.txt <<EOJ
off $H +hbm_pct=20 +cmds=1000 +put_pct=50 +seed=11
zero $H +hbm_pct=20 +cmds=1000 +put_pct=50 +seed=11 +nc_rel=0 +nc_rel_h=0
up0 $H +hbm_pct=20 +cmds=1000 +put_pct=0 +seed=11 $UP
up50 $H +hbm_pct=20 +cmds=1000 +put_pct=50 +seed=11 $UP
up100 $H +hbm_pct=20 +cmds=1000 +put_pct=100 +seed=11 $UP
uph0 $H +hbm_pct=0 +cmds=800 +seed=23 $UP
uph100 $H +hbm_pct=100 +cmds=800 +seed=37 $UP
hostonly $H +hbm_pct=50 +cmds=800 +seed=23 +nc_rel=$((R+25))
hbmonly $H +hbm_pct=50 +cmds=800 +seed=23 +nc_rel_h=$((R_H+25))
down $H +hbm_pct=20 +cmds=800 +seed=29 +nc_rel=$((R-2)) +nc_rel_h=$((R_H-2))
g0 $H +hbm_pct=20 +cmds=1000 +put_pct=0 +seed=11 +nc_ctrd=300
g50 $H +hbm_pct=20 +cmds=1000 +put_pct=50 +seed=11 +nc_ctrd=300
g100 $H +hbm_pct=20 +cmds=1000 +put_pct=100 +seed=11 +nc_ctrd=300
gh100 $H +hbm_pct=100 +cmds=800 +seed=37 +nc_ctrd=300
gup $H +hbm_pct=20 +cmds=800 +seed=29 +nc_ctrd=340 $UP
gtiny $HQ +hbm_pct=20 +nc_ctrd=5
tiny0 $HQ +hbm_pct=0 +nc_rel=$((W+1))
tinyh $HQ +hbm_pct=100 +nc_rel_h=$((W_H+1))
EOJ
    ( cd $O; xargs -P $J -L 1 bash -c 't=$0; timeout 7200 ./nc/V "$@" +phase_log=pl_$t.csv > $t.log 2>&1' < jobs.txt )
    chk() {  # chk <name> <rel_h> <rel> [--bp]
        local t=$1 rh=$2 r=$3 g=${4:-266} out
        clean $O/$t.log || { bad "$P $t: not clean ($O/$t.log)"; return; }
        out=$(python3 check_nocrypto.py --beats $B --times $W_H $W $rh $r --ctrd $g $O/pl_$t.csv 2>&1) \
            && ok "$P $t (REL $rh / $r): all correct, write at WBF, release exact; $(echo "$out" | sed 's/^PASS //' | cut -c1-110)" \
            || { bad "$P $t: schedule at REL $rh / $r"; echo "$out" | head -5 | sed 's/^/      /'; }
    }
    chk off $R_H $R; chk zero $R_H $R
    # (writing the registers delays the testbench's ap_start by a few cycles, so compare each access relative to the launch)
    python3 check_same_schedule.py $O/pl_off.csv $O/pl_zero.csv > $O/same.txt 2>&1 && ok "$P unset and 0 give the identical schedule: $(cut -c6-110 $O/same.txt)" || bad "$P unset and 0 differ"
    chk up0 $((R_H+40)) $((R+40)); chk up50 $((R_H+40)) $((R+40)); chk up100 $((R_H+40)) $((R+40))
    chk uph0 $((R_H+40)) $((R+40)); chk uph100 $((R_H+40)) $((R+40))
    chk hostonly $R_H $((R+25)); chk hbmonly $((R_H+25)) $R
    chk down $((R_H-2)) $((R-2))
    va=$(vis $O/up0.log)
    [ -n "$va" ] && [ "$va" = "$(vis $O/up50.log)" ] && [ "$va" = "$(vis $O/up100.log)" ] && ok "$P visible hashes identical across GET / PUT mix at a run-time value" || bad "$P visible hashes differ across the mix"
    chk g0 $R_H $R 300; chk g50 $R_H $R 300; chk g100 $R_H $R 300; chk gh100 $R_H $R 300; chk gup $((R_H+40)) $((R+40)) 340
    for x in "g50 301" "gh100 301" "gup 341"; do set -- $x; [ "$(awk -F, 'NR==1{for(i=1;i<=NF;i++)if($i=="rd_issue")c=i} NR>1{print $c}' $O/pl_$1.csv | sort -u)" = "$2" ] && ok "$P $1: every read issued at $2 (the gate + the usual offset)" || bad "$P $1: reads not all at $2"; done
    va=$(vis $O/g0.log)
    [ -n "$va" ] && [ "$va" = "$(vis $O/g50.log)" ] && [ "$va" = "$(vis $O/g100.log)" ] && ok "$P visible hashes identical across GET / PUT mix at a run-time gate" || bad "$P visible hashes differ across the mix at a run-time gate"
    for t in tiny0 tinyh gtiny; do
        l=$O/$t.log
        if grep -q "DOMA HALT" $l && ! grep -qiE "ALL CHECKS PASSED|[1-9][0-9]* wrong|WRONG (GET|data|value)" $l; then ok "$P $t: too small a value halts, no wrong answer"; else bad "$P $t: expected a fail-stop halt ($l)"; fi
    done
done
echo "run-time release: $pass passed, $fail failed"
[ $fail = 0 ]
