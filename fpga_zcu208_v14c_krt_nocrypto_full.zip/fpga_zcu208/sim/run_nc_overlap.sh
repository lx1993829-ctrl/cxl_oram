#!/bin/bash
# run_nc_overlap.sh -- regression of the NOCRYPTO phase 3 overlap (docs/nocrypto_overlap.md): ORAM_NOCRYPTO with
# ORAM_OVERLAP4 + ORAM_OV4_P3, every bucket on the plaintext path, the schedule's times as run-time registers.
# The set follows run_overlap.sh OV=5 (phase 3), at one block size (default 256 B), lambda 7:
#   - every run: all responses correct, eviction scoreboard 0 wrong, no halt;
#   - paired streams (same keys and arrivals, different GET/PUT mix): identical visible hashes;
#   - the injected leak (TB_OV_LEAK, a PUT's read one cycle late) changes them, and fails the exact schedule check;
#   - check_p3.py: every start, read issue, write-back, release and end recomputed exactly from public events, at the
#     build's times (registers 0) and at the card times given at run time (registers set), K = 4, 3, 2 (run-time K);
#   - the run-time registers really take effect: the same run at two settings gives different, each exact, schedules;
#   - a too small time fail-stops (halt), never a wrong result or a schedule outside the rule;
#   - throughput against the serial NOCRYPTO build (Option A + RAMA) of the same size.
# Usage: bash run_nc_overlap.sh [jobs]      B=8 (beats per block; 8 = 256 B). Logs: build/ncov<B>/.
# Build times (the package's 256 B defaults, docs/nocrypto_overlap.md): CTRD 400, PMIN 400, GA 400, WB 400, REL 600,
# L 900, LEQ 0 (WB + bucket beats + 3300). Card times (run time): CTRD 300, PMIN 350, GA 350, WB 300, REL 500, L 750.
# Assumption (as PCIe orders a read after an earlier posted write): a host write is readable once acknowledged, or
# within about L + CTRD - WB - 200 cycles of it (hbe, hbe0: 400 cycles, must pass). The 2,500-cycle stress of the
# encrypted build (hbx) is outside it: there the same-bucket gate covers only the three accesses before (it is reported,
# not counted; the encrypted build's tag check would halt on it, this build has no tag).
set -u
cd "$(dirname "$0")"
RTL=$(cd "${RTL_DIR:-../rtl}" && pwd); J=${1:-$(nproc)}; B=${B:-8}
O=build/ncov$B; mkdir -p $O
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
SRCS_NC=$(grep -vE '^(aes|ghash)' files_rtl.lst | sed "s#^#$RTL/#" | tr '\n' ' ')   # what package_kernel.tcl keeps with NOCRYPTO=1
# build times
BC=${BC:-400}; BP=${BP:-400}; BG=${BG:-400}; BW=${BW:-400}; BR=${BR:-600}; BL=${BL:-900}
# card times, given at run time
CC=${CC:-300}; CP=${CP:-350}; CG=${CG:-350}; CW=${CW:-300}; CR=${CR:-500}; CL=${CL:-750}
RT="+nc_ctrd=$CC +nc_pmin=$CP +nc_ga=$CG +nc_wb=$CW +nc_rel=$CR +nc_l=$CL"
VF="--binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-BLKANDNBLK -I$RTL"
build() {   # build <dir> <sources> [defines]
    local d=$1 src=$2; shift 2
    [ "${REUSE:-0}" = 1 ] && [ -x $O/$d/V ] && { echo "reused $d"; return 0; }
    rm -rf $O/$d
    verilator $VF -DORAM_BLOCK_BEATS=$B -DORAM_C=7 -DORAM_N=4096 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL "$@" \
      --top-module tb_doma_kernel tb_doma_kernel.v oram_timing_monitor.v axi_mem_model.v $src $RTL/doma_kernel.v \
      -Mdir $O/$d -o V > $O/build_$d.log 2>&1 && echo "built $d" || { echo "BUILD FAILED $d ($O/build_$d.log)"; exit 1; }
}
XD="-DORAM_NOCRYPTO -DORAM_OVERLAP2 -DORAM_OVERLAP4 -DORAM_OV4_P3 -DORAM_OV_CT_RD=$BC -DORAM_OV_PMIN=$BP -DORAM_OV4_GA=$BG -DORAM_NC_OV_WB=$BW -DORAM_NC_OV_REL=$BR -DORAM_OV4_L=$BL -DORAM_OV4_LEQ=0"
echo "== Vivado generate-scope check (check_gen_decl.sh)"
GD=$(bash check_gen_decl.sh $RTL 2>&1); echo "$GD" | tail -1
echo "== building ($((B * 32)) B blocks)"
build ncf "$SRCS_NC" $XD; build ncl "$SRCS_NC" $XD -DTB_OV_LEAK
build base "$SRCS_NC" -DORAM_NOCRYPTO -DORAM_ONPKG_FIXWB -DORAM_ONPKG_RAMA     # the serial NOCRYPTO build of this size
H="+hb=0 +host_lat=401 +host_wlat=98"
T="+hb=0 +host_lat=480 +host_wlat=98 +host_slow_pct=3 +host_slow_extra=1500 +host_gap=15 +seed=11"
RS="+stash_gap=40 +stash_pcs=390 +stash_idblk=0 +stash_lat=120 +stash_slow_pct=0"     # RAMA-like stash
cat > $O/jobs.txt <<EOF
ncf p0 $H +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=0
ncf p50 $H +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=50
ncf p100 $H +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=100
ncl l0 $H +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=0
ncl l100 $H +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=100
ncf sk0 $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +same_key=120 +put_pct=0
ncf sk100 $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +same_key=120 +put_pct=100
ncf ab0 $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +abab_key=120 +put_pct=0
ncf ab50 $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +abab_key=120 +put_pct=50
ncf k3a $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +cyc_key=120 +cyc_n=3 +put_pct=0
ncf k3b $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +cyc_key=120 +cyc_n=3 +put_pct=100
ncf k4a $H +hbm_pct=50 +preload +cmds=120 +cmds2=4 +cyc_key=120 +cyc_n=4 +put_pct=30
ncf c0 $H +hbm_pct=0 +preload +cmds=200 +cmds2=4 +seed=5
base c0 $H +hbm_pct=0 +preload +cmds=200 +cmds2=4 +seed=5
ncf c1 +hb=0 +hbm_pct=100 +preload +seed=3 +cmds=200 +cmds2=4
base c1 +hb=0 +hbm_pct=100 +preload +seed=3 +cmds=200 +cmds2=4
ncf cs $H $RS +hbm_pct=20 +preload +cmds=200 +cmds2=4
base cs $H $RS +hbm_pct=20 +preload +cmds=200 +cmds2=4
ncf j2 +hb=0 +junk_mem +host_lat=263 +host_wlat=98 +hbm_pct=20 +preload
ncf c3 +hb=0 +hbm_pct=50 +cmds=200 +cmds2=10 +host_lat=263 +host_wlat=98 +seed=7
ncf nb64 $H +nblk=64 +hbm_pct=20 +preload +cmds=200 +cmds2=4 +put_pct=50
ncf nb32 $H +nblk=32 +hbm_pct=50 +preload +cmds=200 +cmds2=4 +put_pct=50 +seed=4
ncf t0 $T $RS $RT +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=0
ncf t50 $T $RS $RT +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=50
ncf t100 $T $RS $RT +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=100
ncf tsk $T $RS $RT +hbm_pct=20 +preload +cmds=150 +cmds2=4 +same_key=150 +put_pct=50
ncf tab $T $RS $RT +hbm_pct=50 +preload +cmds=150 +cmds2=4 +abab_key=150 +put_pct=50
ncf tc100 +hb=0 $RS $RT +hbm_pct=100 +preload +seed=3 +cmds=200 +cmds2=4 +put_pct=50
ncl tl0 $T $RS $RT +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=0
ncl tl100 $T $RS $RT +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=100
ncf rw100 +hb=0 $RS $RT +hbm_pct=100 +preload +seed=3 +cmds=300 +cmds2=4 +put_pct=50 +resp_whold=1800
ncf rw20 $T $RS $RT +hbm_pct=20 +preload +seed=5 +cmds=300 +cmds2=4 +put_pct=50 +resp_whold=2500 +hbmb_slow_pct=3 +hbmb_slow_extra=1200 +cmd_slow_pct=2 +cmd_slow_extra=800
ncf hbe $T $RS $RT +nblk=48 +hbm_pct=20 +preload +seed=5 +cmds=300 +cmds2=4 +put_pct=50 +host_bearly=400
ncf hbe0 $T $RS $RT +nblk=32 +hbm_pct=0 +preload +seed=6 +cmds=300 +cmds2=4 +put_pct=50 +host_bearly=400
ncf hbx $T $RS $RT +nblk=32 +hbm_pct=0 +preload +seed=6 +cmds=300 +cmds2=4 +put_pct=50 +host_bearly=2500
ncf lmix $T $RS $RT +hbm_pct=20 +preload +seed=21 +cmds=900 +launches=4 +cmds2=4 +put_pct=50 +resp_rdy=20 +hbmb_slow_pct=3 +hbmb_slow_extra=1200 +cmd_slow_pct=2 +cmd_slow_extra=800 +hbm_gap=10
ncf tnb $T $RS $RT +nblk=48 +hbm_pct=30 +preload +cmds=300 +cmds2=4 +put_pct=50
ncf tnb0 $T $RS $RT +nblk=32 +hbm_pct=0 +preload +cmds=200 +cmds2=4 +put_pct=0
ncf tnb100 $T $RS $RT +nblk=32 +hbm_pct=0 +preload +cmds=200 +cmds2=4 +put_pct=100
ncf tnp $T $RS $RT +hbm_pct=20 +cmds=300 +cmds2=4 +put_pct=0
ncl tlnp $T $RS $RT +hbm_pct=20 +cmds=300 +cmds2=4 +put_pct=0
ncf kt3 $T $RS $RT +ov_k=3 +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=50
ncf kt2 $T $RS $RT +ov_k=2 +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=50
ncf kt3n $T $RS $RT +ov_k=3 +nblk=32 +hbm_pct=20 +preload +cmds=200 +cmds2=4 +put_pct=50
ncf kt2n $T $RS $RT +ov_k=2 +nblk=32 +hbm_pct=20 +preload +cmds=200 +cmds2=4 +put_pct=50
ncf hga $T $RS $RT +nc_ga=150 +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=50
ncf hwb $T $RS $RT +nc_wb=40 +nc_rel=200 +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=50
ncf hrd $T $RS $RT +nc_ctrd=60 +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=50
ncf heq $T $RS $RT +nc_leq=320 +nblk=48 +hbm_pct=20 +preload +seed=5 +cmds=300 +cmds2=4 +put_pct=50 +host_bearly=2500
EOF
# $value$plusargs returns the first match: put the deliberately small values of hga/hwb/hrd/heq in front of the card times
sed -i -E 's/^(ncf (hga|hwb|hrd|heq) .*)(\+nc_ctrd=[0-9]+ \+nc_pmin=[0-9]+ \+nc_ga=[0-9]+ \+nc_wb=[0-9]+ \+nc_rel=[0-9]+ \+nc_l=[0-9]+)(.*)$/\1\4 \3/' $O/jobs.txt
echo "== running $(wc -l < $O/jobs.txt) runs, $J at a time"
rm -f "${O:?}"/fx_*.txt
O=$O xargs -P $J -L 1 bash -c 'b=$0; t=$1; shift 1; timeout 7200 ./$O/$b/V "$@" +fix_dump=$O/fx_${b}_$t.txt > $O/${b}_$t.log 2>&1; echo "  done $b $t"' < $O/jobs.txt
pass=0; fail=0
ok() { echo "PASS  $*"; pass=$((pass+1)); }
bad() { echo "FAIL  $*"; fail=$((fail+1)); }
hashes() { grep -E "^run1: (bucket-port timing|folded off-package shape|on-package release/end) hash" $O/$1.log | sed -E 's/ over .*//'; }
cpc() { grep -E "^run1: size=" $O/$1.log | sed -E 's/.*device total=([0-9]+) +completed=([0-9]+).*/\1 \2/' | awk '{if ($2) printf "%.0f", $1/$2}'; }
clean() { grep -q "ALL CHECKS PASSED" $1 && grep -q "eviction scoreboard: .* 0 wrong" $1 && ! grep -q "DOMA HALT" $1; }
echo "== checks"
echo "$GD" | grep -q "^PASS" && ok "no name used in a generate block before its declaration" || bad "generate-scope check: $(echo "$GD" | head -2 | tr '\n' ' ')"
ok "the NOCRYPTO overlap builds compile without any AES or GHASH source (as package_kernel.tcl packages them)"
HALT_EXPECTED="hga hwb hrd"
while read -r b t rest; do
    l=$O/${b}_$t.log
    case " ncl_l100 ncl_tl100 heq hbx $HALT_EXPECTED " in *" ${b}_$t "*|*" $t "*) continue;; esac
    clean $l && ok "$b $t: all responses correct, scoreboard 0 wrong, no halt" || bad "$b $t ($l)"
done < $O/jobs.txt
for t in $HALT_EXPECTED; do
    l=$O/ncf_$t.log
    grep -q "DOMA HALT" $l && ! grep -qE "^FAIL.*(wrong data|bad header)" $l \
        && ok "too small a time ($t: $(grep -E "^ncf $t " $O/jobs.txt | grep -oE '\+nc_[a-z]+=[0-9]+' | head -2 | tr '\n' ' ')): fail-stop halt, no wrong result returned" \
        || bad "too small a time ($t) did not fail-stop cleanly ($l)"
done
# negative control: the same-bucket read gate below the write's landing (host writes readable 2,500 cycles late)
if grep -qE "DOMA HALT|^FAIL" $O/ncf_heq.log; then ok "negative control: a same-bucket gate (LEQ 320) below the late-landing host write is caught (wrong data or halt)"
else echo "NOTE  negative control (LEQ 320, late-landing host writes) ran clean: no same-bucket read hit a late write in this run"; fi
kw=$(for l in $O/*.log; do grep -q "DOMA HALT" $l || cat $l; done | grep -c "KERNEL OVERLAP")   # halted runs end with results lost by design
[ "$kw" = 0 ] && ok "kernel completion side: no result lost or misplaced in any run" || bad "kernel completion side warnings: $kw"
late=$(grep -E "^run1: completion side: [0-9]+" $O/ncf_rw100.log | sed -E 's/^run1: completion side: ([0-9]+).*/\1/')
[ -n "$late" ] && [ "$late" -gt 0 ] && ok "slow response writes: $late results landed during an earlier response write, every GET correct" \
    || echo "NOTE  slow response-write run did not exercise the completion side (late results: '${late}')"
clean $O/ncf_hbe.log && clean $O/ncf_hbe0.log && ok "host writes readable 400 cycles after their acknowledgement: every GET correct, no halt" \
    || bad "late-landing host writes"
same() { [ -n "$(hashes $1)" ] && [ "$(hashes $1)" = "$(hashes $2)" ]; }
same ncf_p0 ncf_p50 && same ncf_p0 ncf_p100 && ok "paired streams 0/50/100% PUTs (build times): identical visible hashes" || bad "paired streams 0/50/100% PUTs differ"
same ncf_sk0 ncf_sk100 && ok "same key x120, 0/100% PUTs: identical visible hashes" || bad "same-key paired hashes differ"
same ncf_ab0 ncf_ab50 && ok "ABAB keys, 0/50% PUTs: identical visible hashes" || bad "ABAB paired hashes differ"
same ncf_k3a ncf_k3b && ok "keys in turns of 3, 0/100% PUTs: identical visible hashes" || bad "period-3 key paired hashes differ"
same ncl_l0 ncf_p0 && ok "injected-leak build without PUTs equals the overlap build" || bad "injected-leak build without PUTs differs"
[ "$(hashes ncl_l0 | grep timing)" != "$(hashes ncl_l100 | grep timing)" ] && ok "injected leak (a PUT's read one cycle late) detected by the paired hashes" || bad "injected leak NOT detected"
same ncf_t0 ncf_t50 && same ncf_t0 ncf_t100 && ok "card times (run time), host read tails: paired streams 0/50/100% PUTs, identical visible hashes" \
    || bad "card times: paired hashes differ"
same ncl_tlnp ncf_tnp && ok "card times, injected-leak build with no PUT at all equals the overlap build" || bad "card times: leak build with no PUT differs"
[ "$(hashes ncl_tl0 | grep timing)" != "$(hashes ncl_tl100 | grep timing)" ] && ok "card times, host read tails: injected leak detected by the paired hashes" || bad "card times: injected leak NOT detected"
same ncf_tnb0 ncf_tnb100 && ok "small tree (frequent same-bucket accesses), host read tails: 0/100% PUTs, identical visible hashes" || bad "small tree: paired hashes differ"
[ "$(hashes ncf_p0 | grep timing)" != "$(hashes ncf_t0 | grep timing)" ] && ok "the run-time registers take effect (build and card times give different schedules)" || bad "run-time registers had no effect"
# exact schedule (check_p3.py), one set of pipeline offsets per build-time setting
LEQB=$(( BW + 8 * B + 3300 )); LEQC=$(( CW + 8 * B + 3300 ))
P3B="--ctrd $BC --pmin $BP --ga $BG --arwb $BW --arrel $BR --arrelh $BR --l $BL --leq $LEQB"
P3C="--ctrd $CC --pmin $CP --ga $CG --arwb $CW --arrel $CR --arrelh $CR --l $CL --leq $LEQC"
FXB="p0 p50 p100 sk0 sk100 ab0 ab50 k3a k3b k4a c0 c1 cs j2 c3 nb64 nb32"
python3 check_p3.py $P3B $(for t in $FXB; do echo $O/fx_ncf_$t.txt; done) > $O/p3_b.out 2>&1 \
    && ok "schedule exact in $(echo $FXB | wc -w) runs at the build times: $(head -1 $O/p3_b.out | sed 's/^check_p3: //; s/;.*//')" \
    || { bad "schedule broken at the build times ($O/p3_b.out)"; grep FAIL $O/p3_b.out | head -3 | sed 's/^/      /'; }
FXC="t0 t50 t100 tsk tab tc100 tnb tnb0 tnb100 rw20 rw100 lmix hbe hbe0 tnp"
python3 check_p3.py $P3C $(for t in $FXC; do echo $O/fx_ncf_$t.txt; done) > $O/p3_c.out 2>&1 \
    && ok "schedule exact in $(echo $FXC | wc -w) runs at the card times (run-time registers): $(head -1 $O/p3_c.out | sed 's/^check_p3: //; s/;.*//')" \
    || { bad "schedule broken at the card times ($O/p3_c.out)"; grep FAIL $O/p3_c.out | head -3 | sed 's/^/      /'; }
for k in 3 2; do
    python3 check_p3.py $P3C --k $k $O/fx_ncf_kt$k.txt $O/fx_ncf_kt${k}n.txt > $O/p3_k$k.out 2>&1 \
        && ok "run-time K = $k: schedule exact (start also waits for the access $k back): $(head -1 $O/p3_k$k.out | sed 's/^check_p3: //; s/;.*//')" \
        || { bad "run-time K = $k: schedule broken ($O/p3_k$k.out)"; grep FAIL $O/p3_k$k.out | head -2 | sed 's/^/      /'; }
done
python3 check_p3.py $P3B $O/fx_ncl_l100.txt > $O/p3_l.out 2>&1 && bad "injected leak NOT detected by the schedule check" \
    || ok "injected leak detected by the schedule check ($(grep FAIL $O/p3_l.out | head -1 | sed 's/^ *FAIL  //; s/:.*//'))"
python3 check_p3.py $P3C $O/fx_ncl_tl100.txt > $O/p3_tl.out 2>&1 && bad "card times: injected leak NOT detected by the schedule check" \
    || ok "card times: injected leak detected by the schedule check"
clean $O/ncf_hbx.log && echo "NOTE  hbx (host writes readable 2,500 cycles after the acknowledgement): clean in this run" \
    || echo "NOTE  hbx (host writes readable 2,500 cycles after the acknowledgement, outside the assumption): $(grep -cE '^FAIL.*GET.*mismatch' $O/ncf_hbx.log) wrong GETs$(grep -q 'DOMA HALT' $O/ncf_hbx.log && echo ', halt'), as expected"
echo "== throughput (device cycles per command, run1)"
for t in c0 cs c1; do echo "  $t: serial NOCRYPTO $(cpc base_$t), overlap (build times) $(cpc ncf_$t)"; done
for t in t50 tc100 lmix kt3 kt2; do echo "  $t (card times, host read tails, RAMA-like stash): $(cpc ncf_$t)"; done
echo "== worst readouts (card times): $(grep -h -oE 'worst lookup ct_max_rd=[0-9]+, decisions after t. ar_max_wb_h=[0-9]+, write handed off after t. ar_max_rel_h=[0-9]+' $O/ncf_t*.log $O/ncf_lmix.log | awk -F'[=,]' '{if($2>a)a=$2; if($4>b)b=$4; if($6>c)c=$6} END {print "lookup " a ", decisions after the arrival " b ", write handed off " c}')"
echo "== $pass passed, $fail failed"
[ $fail = 0 ]
