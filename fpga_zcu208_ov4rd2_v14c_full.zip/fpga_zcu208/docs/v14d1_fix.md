# v14d1: wrong GET results on the card, and the fix

## What the card showed (v14d, every build, every size, every on-package share, both clocks)

- **No halts, but wrong GET responses.** First failures at 4,096 records, 20% on package, host_doma's seed: command 8 (GET 3664) and command 10 (GET 3923).
- **Your data dump:** every wrong GET returned another key's current value, always a block a PUT had just written. The same wrong block came back for consecutive wrong GETs until another PUT replaced it, and the requested keys still held their preload values.

## Where it happens

A GET whose block is in the stash takes its result from staging slot 0:
- At the open, the stash reads the block's 4 KB from the pool into slot 0. This is the requested block's level-1 read.
- S_CP then copies slot 0 into the result.
- A PUT to a stashed block merges its record into slot 0 the same way, then commits slot 0 back to the pool.

On the card, the open's write of the block into slot 0 was lost, so slot 0 kept the last block a PUT had merged there. That reproduces every feature of the dump:
- another key's current value, intact, never garbage, zero or an old version;
- always a PUT's block;
- the same block repeated until the next PUT-in-stash;
- no `st_err`: the landed flag is set by the burst's last beat, which arrived, even though its data never reached the memory.

## Why only on the card (inferred, not yet proven)

v14d replaced v14c's single staging memory `stg` (16 slots, one write port, two registered reads) with two memories:
- `stg_w`: 9 window slots, written by landing window data.
- `stg_o`: 7 slots for slot 0 and the inserts, written by slot 0's landing and by the controller (a muxed write).

Both have non-power-of-two depths and a 2:1 select on each read. This is the only structural hardware change in design A.

Every simulation of that RTL is correct on this path:
- the kernel testbench;
- host_doma's exact sequence in the XRT mock, at 0% and 20% on package, traced, NMAX 2,097,152;
- tb_stash against a Yosys gate netlist of v14d's `stash_hbm` (`docs/v14d1_netlist_yosys.txt`).

So the fault lies in how Vivado mapped the split memories (your log: both inferred as true dual-port RAM templates), which only a Vivado netlist or the card can show. **This is not proven here: there is no Vivado in this environment.** The check that proves it is below; run it on v14d first.

## The fix (`rtl/stash_hbm.v`)

- **Staging memory:** back to v14c's single `stg`, coded exactly as v14c had it. This is the template the card already runs correctly in v14c.
- **The conflict the split avoided:** window data can land after `ready` while the controller writes a staged block (a PUT's merge, an insert). It is removed by holding the stash port's read channel during any controller write: `m_rready = !dwr_en`. A landing beat waits that cycle. Every landing action now uses the handshake (`r_hs = m_rvalid && m_rready`).
- **Effect on traffic:** it can delay window data only, never metadata. Controller writes come after `ready`, which waits for all metadata and the requested block.
- **Unchanged:** everything else in design A (metadata first, decisions from metadata, copies waiting for their own block) and design B's per-channel IDs.

## Verification

| Check | v14d (card build) | v14d1 |
|---|---|---|
| tb_stash, RTL (6 tests incl. slow data, directed case, exhaustion), A and B | pass | pass |
| tb_stash against a **Yosys** gate netlist, 4 tests | pass (does not reproduce) | pass, A and B |
| tb_stash against a **Vivado** funcsim netlist | **run on your server** | **run on your server** |
| Negative control: slot 0's landing removed (`TB_FAULT_SLOT0_LANDING`) | — | tb_stash fails at once; the kernel testbench's GETs fail (92 wrong) |
| host_doma's sequence, XRT mock, 4,096 records, 20% on package, NMAX 2,097,152 | all correct (does not reproduce) | design A: all correct (5,000 commands); B: see the regression |
| Kernel testbench with the eviction scoreboard (every copied beat against the key's latest value), 100 / 20 / 0% and card-like stash | — | 111,104 beats (868 blocks) per run, 0 wrong |
| Visible timing hashes vs v14c1, 4 KB and 2 KB (and 4 KB design B) | identical | identical |
| Card-rate directed worst cases (`tb_ni +worst`, 0.44 beats per cycle) | write-back start 299, release gate 1,551 | 299, **1,621** (+70 from the held read channel); with 10% + 74: 1,857 ≤ AR_REL_H 2,384 |
| Same at 0.36 beats per cycle | 2,134 | 2,134 |

## Why the regression missed it

Every regression check simulates the RTL, and the RTL was correct; the fault is in what Vivado built. Even host_doma's own sequence at 4,096 records passes in RTL simulation, so adding it alone would not have caught this.

The new `netlist` group closes that gap:
- tb_stash against the synthesized `stash_hbm`, Yosys always and Vivado whenever it is on the PATH;
- a negative control proving the test detects exactly this fault.

The `hostseq` group adds host_doma's sequence, as asked.

## Running the netlist check (on the build server)

```bash
cd sim
bash run_stash_netlist.sh vivado <v14d rtl dir>     # expect FAIL on block data if the split memories are the cause
bash run_stash_netlist.sh vivado ../rtl             # v14d1: expect 4 x PASS
STASH_DEF=ORAM_STASH_PC_IDS bash run_stash_netlist.sh vivado ../rtl   # design B
bash run_stash_netlist.sh yosys ../rtl              # the generic gate-level check (runs anywhere with yosys)
```

- `vitis/stash_netlist.tcl` synthesizes `stash_hbm` out of context for the U55C part, with the card build's defines and ORAM_N 4,096. It writes `stash_hbm_funcsim.v` and a RAM utilization report.
- The script then compiles `tb_stash.v` against the netlist with UNISIM and runs four tests.

**If the v14d netlist passes,** the split memories are not the cause. In that case send me `build/netlist_vivado/ram_utilization.rpt` and the synthesis log, and v14d1 should not be deployed until the cause is found.

## New regression groups

- `netlist`, 4 KB: Yosys netlist tests for A and B; Vivado netlist tests when Vivado is present (otherwise SKIP, never PASS); the negative control.
- `hostseq`, 4 KB, λ = 7: host_doma's sequence through the XRT mock at 4,096 records, 20% on package, NMAX 2,097,152, for design A (also the RAMA build's RTL) and design B. About 12 minutes each.
- `onpkg`: the kernel testbench's eviction scoreboard runs in every whole-block kernel run. `+tail_get=K` makes a run start with GETs of the last-written keys.
