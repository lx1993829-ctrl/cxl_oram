#!/bin/bash
# hashcmp.sh <tag> <rtl dir> <beats> [defines...]: production arrival kernel build, three runs, the visible-timing hashes
tag=$1; RTL=$2; b=$3; shift 3
SIM=/home/claude/work/fpga_zcu208/sim
SRCS=$(sed "s#^#$RTL/#" $SIM/files_rtl.lst | tr '\n' ' ')
cd /home/claude/hc; d=b_${tag}_$b
verilator --binary --timing -j 2 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -I$RTL \
  -DORAM_BLOCK_BEATS=$b -DORAM_C=7 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -Wno-BLKANDNBLK "$@" \
  --top-module tb_doma_kernel $SIM/tb_doma_kernel.v $SIM/oram_timing_monitor.v $SIM/axi_mem_model.v $SRCS $RTL/doma_kernel.v \
  -Mdir $d -o V > $d.build.log 2>&1 || { echo "BUILD FAILED $tag $b"; exit 1; }
out=h_${tag}_$b.txt; : > $out
i=0
for c in "+hb=0 +hbm_pct=100 +preload +seed=3 +cmds=200 +cmds2=4" \
         "+hb=0 +junk_mem +host_lat=263 +host_wlat=98 +hbm_pct=20 +preload" \
         "+hb=0 +hbm_pct=50 +cmds=200 +cmds2=10 +host_lat=263 +host_wlat=98 +seed=7"; do
    i=$((i+1)); ./$d/V $c ${EXTRA:-} > r_${tag}_${b}_$i.log 2>&1
    { echo "config $i: $c"; grep -E "hash|^(preload|run[0-9]): size=|ALL CHECKS PASSED|FAILURE" r_${tag}_${b}_$i.log | sed -E 's/host cycles=[0-9]+  //'; } >> $out
done
rm -rf $d
echo "done $tag $b"
