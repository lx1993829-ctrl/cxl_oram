# Option A: a fixed on-package write-back start (`FIXWB=1`, `ORAM_ONPKG_FIXWB`)

**Purpose.** In v14d1, an on-package bucket's write-back starts as soon as the access's decisions end. It then streams
behind the eviction copies. Both its start and its beat timing therefore depend on the stash.

The write-back and the next on-package bucket read share HBM[16:31]. The next read issues only after every write
acknowledgement, at least 535 cycles later, so no write is still queued in the memory controller. DRAM state can still
remain: open rows, and when a refresh lands. Through that state, the write's stash-dependent timing could reach the
next read's latency, and through it the next access's arrival-relative visible times.

Option A removes the dependence at its source. Everything HBM[16:31] sees becomes a function of the arrival, the
public bucket addresses and the memory's own back-pressure.

**Rule.** For every on-package access:
- **Fixed start:** its write-back is issued at exactly `t_arr + AR_WBF_H`.
- **Hold-free:** it streams without a hold, so 1,024 beats leave in 1,024 cycles, apart from the memory's own
  back-pressure (WREADY).
- **Deadline (1):** either of these is a deadline (1) miss:
  - the decisions not done by then (S_EA_START not reached);
  - a beat held for an eviction copy that has not landed.
- **How a miss is handled:** it is recorded exactly as today's on-package misses are (`byp_ov`, `ov_d1`, `ov_by1`), and
  raised as a fail-stop overrun at the release time `t_arr + AR_REL_H`, which never moves. The debug build records and
  counts it instead.
- **Unchanged:** the release and end times, every off-package access, and the read gate.

**`AR_WBF_H` = 440 at 4 KB, λ = 7.** It comes from the v14d1 debug build on the card (design A, 2M records, 20% on
package, 798,650 on-package accesses):

| Quantity on the card | Value |
|---|---|
| First write beat after `t_arr` | max 305 (AW start max 300) |
| Hold (last W − first W + 1 − 1,024) | max 28, median 0 |

**Why the hold is stash-induced, not memory back-pressure.** In simulation, every held cycle is a beat waiting for an
eviction copy, and WVALID with WREADY low never occurs. The 28 is structural:
- each eviction copy takes 132 cycles for 128 beats, and the write 128;
- so the write gains 4 cycles on every copy it follows, and the hold is exactly 4 × (evictions − 1);
- the card's 28 is the 8-eviction case.

**The arithmetic.**
- 305 + 28 = 333; with the calibration rule (+10% + 74) that gives 440.
- In simulation the first write beat comes at `t_arr` + 444 and the hand-off at `t_arr` + 1,469 (the calibration
  maximum `ar_max_rel_h`, against v14d1's 1,328 in the same run). Against `AR_REL_H` 2,384 that leaves a margin of 915;
  v14d1's card margin is 1,054.
- Throughput is unchanged: the release time is the same.
- Other sizes or λ need `WBF=<cycles>`, and the RTL stops elaboration without it.

**Trade-off.** v14d1 absorbs late decisions up to `AR_WB_H` (1,228) and late copies up to the release; Option A halts on
them beyond 440. On the card at 2M the worst was 305 + 28, so the headroom above that is 107 cycles. A larger `WBF`
gives tolerance back at one cycle of release margin per cycle; the largest that keeps any margin is about 1,350.

**RTL.**
- `rtl/flat_oram_gcm.v`, serial design only. It is patched by `patch_fixwb.py`; everything sits behind
  `ifdef ORAM_ONPKG_FIXWB`.
- **The write gate:** on package it issues at `t_arr + AR_WBF_H` once the decisions are done.
- **S_EA_START:** on package it no longer issues the write.
- **Deadline (1):** checked at `t_arr + AR_WBF_H`.
- **A held beat on package:** a deadline (1) miss, with `ov_by1` counting the held cycles.
- **Guards:** `FIXWB` with `OVERLAP` and `FIXWB` without arrival scheduling both stop elaboration.
- **Without the switch:** all three RTL files preprocess to exactly v14d1's text (`verilator -E -P`, 768 cases: 3 files ×
  256 configurations). The overlap builds preprocess to exactly the delivered overlap package's text.

**Build commands** (in `vitis/`, design A, 4 KB, 2M records):

    # production
    FIXWB=1 SCHED=arrival BEATS=128 CFG=doma_big2m.cfg NMAX=2097152 LAMBDA=7 TARGET=hw bash build.sh
    # traced (phase-trace records), in its own folder
    FIXWB=1 TRACE=1 SCHED=arrival BEATS=128 CFG=doma_big2m.cfg NMAX=2097152 LAMBDA=7 TARGET=hw bash build.sh
    # debug (on-package misses recorded and counted, never halting), in its own folder; calibration only
    FIXWB=1 TRACE=1 DEBUG=1 SCHED=arrival BEATS=128 CFG=doma_big2m.cfg NMAX=2097152 LAMBDA=7 TARGET=hw bash build.sh

`build.sh` prints the `rtl/oram_build_cfg.vh` it wrote. For production it contains `ORAM_ONPKG_FIXWB`, and no
`ORAM_AR_WBF_H` line, so the default 440 applies. Run the host programs as for v14d1. In the debug build's per-access
records:
- the write-back word is still the decisions' end (S_EA_START), so the margin to 440 can be read directly;
- a deadline (1) count above 0 means some access missed the fixed start or held a beat.

**Regression: `sim/run_fixwb.sh`.** It builds v14d1 and Option A from the same RTL (4,096 records) and runs the same cases
on both:
- GET / PUT mixes;
- 0 / 20 / 50 / 100% on package;
- the card-like stash at 20 and 50%;
- one key repeated 600 times.

It checks access by access (`check_fixwb.py`) that these are identical to v14d1:
- the start;
- the bucket read issue;
- the first beat and the arrival;
- the off-package write-back start and completion;
- the release and the end.

It also checks:
- that every on-package write-back of Option A is issued at exactly `t_arr + 440` and streams 1,024 beats with no hold;
- that the testbench's visible hashes and the bucket-write digests are identical to v14d1;
- that a late eviction copy and decisions slowed past 440 both stop Option A with deadline (1) and no wrong answer,
  where v14d1 absorbs them;
- that the traced and debug variants run clean.

**Results, 2026-11-04** (`docs/fixwb_regression_2026-11-04.txt`): **33 passed, 0 failed.**
- **Nine cases** (49,000 accesses on each build, 17,820 of them on package): v14d1 and Option A both returned every
  response correctly, with 0 wrong evicted beats and no halt.
  - Access by access, these are identical to v14d1: the start, the read issue, the first beat and the arrival, the
    off-package write-back start and completion, the release and the end.
  - The visible hashes and the bucket-write digests are identical.
  - Every on-package write-back of Option A was issued at exactly `t_arr + 440` (logged one cycle later, as every
    off-package write is), with its first beat at most 444 after the arrival, and 1,024 beats with no hold.
- **Late eviction copy** (a stash slower than the card's): Option A stopped with on-package deadline (1), missed by 59
  held cycles, with no wrong answer. v14d1 absorbed it.
- **Decisions slowed past 440** (stash reads of 900 cycles from one access on): Option A stopped with deadline (1),
  missed by 357 cycles, with no wrong answer. v14d1 absorbed it.
- **Traced Option A:** clean.
- **Debug Option A:** clean, with 0 deadline (1) misses recorded.

After an interruption, `REUSE=1 bash run_fixwb.sh` keeps the builds and the finished runs.
