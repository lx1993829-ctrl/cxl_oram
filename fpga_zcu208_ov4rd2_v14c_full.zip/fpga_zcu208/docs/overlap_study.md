# Overlapping consecutive accesses in DOMA: design study, 4 KB blocks (v14c + v14d1, design A)

No RTL yet. The numbers come from v14d1's simulation (per-command cycles, λ = 7, host read latency 401 cycles, which
is the card's: 1,425 − 1,024 at 4 KB), the calibrated budgets in `rtl/oram_params.vh`, and your card breakdown at
4 KB / 20%. They are a resource model (±15%), not measurements. §6 says how to firm them up before any RTL.

## 0. Today, and what each access occupies

One access at a time. Cycles from the access start (300 MHz):

| | Off package | On package |
|---|---|---|
| Bucket read issued (CT_RD) | 266 | 266 |
| Last beat (t_arr) | ≈ 1,691 | ≈ 1,354 |
| Release | t_arr + 3,033 | t_arr + 2,384 |
| Cycles per command (sim) | 5,000 | 4,003 |
| Card | 4,863 at 20% (≈ 0.8 × 5,080 + 0.2 × 4,003) | |

What one access occupies on each shared resource (beats at 32 B per cycle):

| Resource | Off package | On package |
|---|---|---|
| Host port R / W (`pages`) | 1,024 / 1,024 | – |
| HBM bucket port R / W (`pages_hbm`) | – | 1,024 / 1,024 |
| AES-GCM core (one message at a time, 1 beat per cycle) | decrypt 1,047 + encrypt 1,047; **span** from decrypt start to encrypt end ≈ 2,400 | – |
| Stash port (window data + requested block + commit) | typically 300–500; worst ≈ 1,450 beats | same |
| Controller FSM, busy (excluding padding) | ≈ 600 | ≈ 600 |
| Scratch (one bucket image) | from first beat to the end of the write | same |

## 1. What overlap buys

Access i+1 can run its **front half** (lookup, bucket read, decryption) during access i's **back half** (decisions,
re-encryption, write-back, release padding). Most of today's latency is fixed waiting: PCIe latency, padding, the
on-package release budget. That overlaps for free. The bound is the busiest shared resource:

- **4 KB off package: the single GCM core.** Access i+1's decryption cannot start until access i's encryption ends,
  so the spacing is P ≥ (decrypt start → encrypt end) ≈ 2,400. A second GCM core (one for decryption, one for
  encryption) moves the bound to the host port: 1,024 beats each way, P ≈ 1,150.
- **4 KB on package: the bucket port and the stash.**
  - Read and write are separate channels, so P ≈ 1,024 + gaps.
  - Same pseudo-channel for i and i+1 (probability 1/16, public): R + W share 14.4 GB/s, so 1,365.
  - The stash's worst case (a full window, ≈ 1,450 beats) has to fit in P. At the card's 2M rate under design A
    (0.44 beats per cycle) that is ≈ 3,300 cycles. With design B or RAMA, or the stash on one channel, it is ≈ 1,450.

Cycles per request, and the gain over today:

| | 0% on package | 20% | 100% |
|---|---|---|---|
| Today | 5,000 | 4,863 (card) | 4,003 |
| **2 in flight**, one GCM core | 2,500 (2.0×) | 2,430 (2.0×) | 2,000 (2.0×) |
| **k in flight**, one GCM core | 2,400 (2.1×), k = 3: AES-bound | 2,210 (2.2×) | 1,450 (2.8×), k = 3 |
| **k in flight**, two GCM cores | 1,150 (4.3×), k = 5 | 1,210 (4.0×), k = 4–5 | 1,450 (2.8×) |
| KQPS at 300 MHz, 20% (today 61.7; card 59.9 at 2M) | | 123 / 136 / 248 | |

Notes on the table:
- **The 100% on-package column assumes a stash rate ≥ 1 beat per cycle.** Design A at 2M on the card (0.44 beats
  per cycle in its worst open) holds 4 KB on package at ≈ 3,300 (1.2×) unless the stash rate improves or its
  metadata gets its own path (§1.1).
- **k ≥ 3** needs each access's release done by its own timer, with the FSM freed after its last write; today the
  FSM is held through the release padding.
- **k beyond these values buys nothing.** Each row is resource-bound.

### 1.1 Do we need more AXI ports?

Not for 2 in flight. For k in flight, one new port earns its place, and two don't:

- **Stash metadata port: yes, the useful one.** Heads and pool metadata go on their own port (HBM[8], free today);
  data stays on the stash port. With one in-order ID, access i+1's metadata reads queue behind access i's window
  data. That puts the previous access's stash tail on the next access's decisions, and the deadlines would have to
  cover it twice. A separate metadata port removes this by construction.
  - Design B's per-channel IDs only partly help: blocks on HBM[12] share the metadata's ID.
  - At 2M records, the data side still needs B, RAMA, or the earlier two-port striping, or the on-package rate
    stays stash-bound (≈ 3,300 cycles).
- **Host port: no.** At 256 bits and 300 MHz it carries 9.6 GB/s per direction; PCIe Gen3 x16 tops out near
  12–13 GB/s. A second port (or 512 bits) gains at most ≈ 25%, and only once two GCM cores make the host port the
  bound. Not worth it before then.
- **HBM bucket port: no.** Read and write are separate channels. Contention is per pseudo-channel, not per port.
- **Position map, bucket records: no.** They are latency-bound and small. Overlap needs forwarding there, not
  bandwidth.

### 1.2 Measured model (supersedes the estimates in the table above)

`sim/overlap/schedule_model.py` replays per-access stage times through a fixed schedule with resource constraints.
- **Stage times:** measured per access in the v14d1 kernel simulation (`tb_doma_kernel +phase_log`, 4 KB, λ 7,
  production arrival build, host read latency 401, 500 commands plus preload, 0 / 20 / 100% on package and a
  card-like stash). Summaries: `stage_stats.py`.
- **Budgets:** worst measured × 1.10.
- **Stash slot:** fixed at its worst case, a full window of 1,165 beats. How much an access really uses depends on
  the stash state, so the slot cannot shrink to the typical case. The earlier 4.2× figure at k = 5 used typical stash
  times and is withdrawn.

Cycles per request (today: 5,000 / 4,863 / 4,003 at 0 / 20 / 100%):

| Stash configuration | 0% on package | 20% | 50% | 100% | In flight needed |
|---|---|---|---|---|---|
| Metadata and data on one port, design A at 2M on the card (0.44 beats per cycle) | 2,849 (1.8×) | 2,849 (1.7×) | 2,849 | 2,849 (1.4×) | 2 |
| Metadata port, data at 0.44 beats per cycle | 2,912 (1.7×) | 2,912 (1.7×) | 2,912 | 2,912 (1.4×) | 2 |
| **Metadata port, data at 1 beat per cycle** (design B or RAMA, card rate to be measured) | **1,287 (3.9×)** | **1,285 (3.8×, 233 KQPS)** | 1,283 | 1,282 (3.1×) | **4** |
| Same, at most 2 in flight | 2,480 (2.0×) | 2,360 (2.1×) | 2,166 | 1,660 (2.4×) | 2 |

What the model shows:
- **Bounds.** With fast stash data, off-package spacing is bound by the encryption core (1,170 × 1.1 = 1,287).
  On-package spacing is bound by the stash data slot (1,165 beats) and the HBM write (1,154).
- **k.** k = 4 reaches the bound; k = 5 adds nothing measurable. Scratch buffers in use equal the in-flight count.
- **Latency of one access** under the schedule: off package 4,960, on package 3,321. Both are about today's.
- **The stash data rate is the deciding number.** At 0.44 beats per cycle, neither a second GCM core nor k > 2
  helps. The card's rate under design B or RAMA at 2M has to be measured before the RTL target is final.

## 2. Dependencies between overlapping accesses

**Principle.** Every read and write of access j happens, whole, at the same offset from s_j (or from its own t_arr)
as today. A dependency changes only which on-chip copy of the data is used: a multiplexer select inside a fixed slot,
never a stall. The only stalls allowed are on public events: bucket-index equality, which pseudo-channel a bucket
lives on, or a memory's latency.

| # | Dependency | Detected by | Resolved by | Why no visible timing changes |
|---|---|---|---|---|
| D1 | **Same bucket**: b(i+1) = b(i), or any in-flight access's b, while that write-back is unacknowledged | Comparing the bucket indices (public) at i+1's lookup | i+1 still issues its whole read at s(i+1) + CT_RD and still decrypts it in its AES slot, then **discards** it. Its bucket image comes from i's post-eviction scratch (plaintext, its record: fill, slot list, IV and tag as i wrote them). With k in flight, the newest in-flight image of that bucket. i+1's write-back follows i's on the same port and ID, so the writes stay ordered. | The read, the decryption (with its tag check suppressed: the stale ciphertext may fail it), the write and every gate keep their times. Alternative: stall i+1's read until i's write is acknowledged; that is allowed (the equality is public) but adds a schedule class. |
| D2 | **Same key, position map**: i+1 requests a key some in-flight access requested or evicted | Key comparison (secret) against an in-flight table: per access its requested key, its new bucket b′ (drawn at its start), status and pool index, and the ≤ Z keys it evicted with their new bucket | i+1's lookup result is replaced by the newest matching entry. b′ is known at i's start, so i+1's bucket read goes to the right bucket at its fixed time. | A multiplexer on the lookup's result inside the fixed lookup latency (PM_LAT is padded today). The read address is b′, a fresh uniform bucket: the same distribution as an unrelated key. |
| D3 | **Same key, data**: the block is in i's staging (inserted or merged) or in i's commit | The stash itself, once its state is serialized (D4) | Data comes from the pool after i's commit, or is forwarded from i's staging slot if i+1's open precedes the commit's acknowledgement (k ≥ 3). | Same as D2: a source select, no wait. |
| D4 | **Stash state**: windows, chains, the chain step, inserts, frees, the free list, and i+1's eviction candidates including blocks i remapped to b(i+1) | Always applies: the stash is a single sequential structure | **Decisions stay strictly in order.** i+1's stash open runs in a fixed slot after i's commit has been acknowledged: today's rule, kept inside the stash. A second staging set lets i+1's open load while i's copies still read the first. At 4 KB the commit-to-open loop (≈ 450 cycles) fits well inside P, so no commit overlay is needed. | The stash slot is fixed. The stash's own reads and writes are on-package and unobservable; only its deadlines matter, and they are checked (fail-stop). |
| D5 | **Stash bound** | – | The sequence of stash states is exactly the sequential one: decisions are in order, and D1–D3 make every access see its predecessors' results. Extra occupancy at any instant: at most k − 1 inserted blocks of accesses whose evictions are still copying. **Pool = Claim 1's bound + k.** The 2⁻⁶⁴ bound holds unchanged. | – |
| D6 | **Bucket records** (IV, tag, fill, slot list) | Covered by D1 (same bucket only) | Forwarded with the bucket image | As D1 |
| D7 | **IV counter** (global LFSR) | Always | IVs are taken in encryption-slot order, which is fixed by the schedule. The 96-step advance per encryption is unchanged. | Unique IVs. Ciphertexts depend only on the slot order. |
| D8 | **AES core** | Always | Fixed slots: decryption of i+1 after encryption of i (one core), or a decryption core and an encryption core. The decryption reads its bucket from scratch, so an early PCIe arrival simply waits in scratch. | The slot times are constants. |
| D9 | **Scratch and staging memories** | Always | One scratch per in-flight access and two staging sets, **each a copy of today's exact memory template** (one write port, today's readers), selected by access parity. No new multi-writer memory. **Netlist-level check required** (v14d's lesson). | – |
| D10 | **Ports**: host and HBM bucket ports shared by i and i+1; the stash port | Always | Reads and writes in fixed slots (§3); on the stash port, a metadata port or ID (§1.1). PCIe and HBM latency now include the other access's fixed traffic. | The other access's traffic is fixed in size and time and goes to public addresses, so it is request-independent noise, the same as refresh. |
| D11 | **Halts** | A deadline miss in either access | Halt at that access's release time, as today. The other in-flight access is aborted without a response. | A halt depends only on memory timing and the stash (fail-stop), as today. |

## 3. The fixed schedule and the deadlines

**Start rule.** s(i+1) = max(arrival of request i+1, s(i) + P(c(i), c(i+1))).
- c is the access's public class: on or off package, plus a same-pseudo-channel flag for on-package pairs.
- The simplest variant uses one P per build: the maximum over classes.

**4 KB, off package, one GCM core, P = 2,500** (cycles from s(i); R = host read data, D = decrypt, E = encrypt,
W = host write):

```
            0      266  667        1691    2021        3067   3476         4500  4724  5096
access i    |--lookup--|R..........|D-------|dec.|E-----------|wait|W-----------|rel  |done
                        <---------- D: 667-1714 -->      <---- E: 2021-3067 ---->

            2500   2766 3167       4191    4521        5567   5976         7000  7224  7596
access i+1  |--lookup--|R..........|D-------|dec.|E-----------|wait|W-----------|rel  |done
                                    D(i+1) 3167-4214 starts after E(i) ends at 3067
access i+2  starts at 5000 ...      D(i+2) 5667 after E(i+1) 5567
```

The host R of i+1 (2,766–4,191) overlaps i's W (3,476–4,500). PCIe is full duplex and the two use different AXI
channels.

**4 KB, on package, P = 1,450** (k = 3; read 1,024 beats, write 1,024 beats; S = the stash slot):

```
access i     0 |lookup| R 266-1354 | S-open 61.. | dec 1354-1653 | W 1653-2682 | ... release t_arr+2384 = 3738
access i+1   1450 |lookup| R 1716-2804 | S-open after i's commit ack (~1700) | dec 2804-3103 | W 3103-4132 | rel 5188
access i+2   2900 ...   R 3166-4254 (R channel free after 2804)
```

The release padding of i (until 3,738) no longer holds anything: each access releases on its own timer.

**New deadlines** (each a fail-stop check, reported at the access's release time, as v14b does):

| Deadline | Check | Covers |
|---|---|---|
| Today's CT_RD, AR_WB(_H), AR_REL(_H), AR_DONE(_H) | per access, from its own s or t_arr | Recalibrated **with the neighbours' traffic present**. |
| **AES hand-off (new, one core)** | E(i) done by s(i+1) + 667 | i+1's decryption slot |
| **Stash slot (new)** | i's commit acknowledged by s(i) + P + (i+1's open offset); i+1's metadata ready by t_arr(i+1) | Stash serialization (D4) |
| **Scratch and staging free (new)** | i's write handed off, and its copies read, before the buffer's next use at s(i) + 2P (two buffers) | Buffer reuse |
| **Same channel (on package)** | A pair class with P_same ≥ 1,365 if not budgeted always | HBM pseudo-channel contention |

**Deriving the budgets.** Each deadline is the worst case of its path with both accesses' traffic present, plus the
10% + 74 margin:
- host read latency under a concurrent 32 KB write;
- HBM bucket read and write on one pseudo-channel;
- the stash's worst open behind the previous access's window data;
- AES slots, fixed by construction.

`worst_case.py` gets a two-access mode: segment times as functions of path features, now including the neighbour's
class.

**Card calibration,** as for v14c:
- a debug bitstream that counts overruns without halting, with per-access records;
- runs at 0 / 20 / 100% on package (100% only where it fits in HBM), 1M and 2M records;
- `card_budgets.py` extended to the new deadlines;
- the tail check at 10%; then the 20M-access validation runs and a hot run.

## 4. Claim 1: the timing rule and its proof

**Today:** each access issues its bucket read a fixed time after it starts, once the previous write-back is
acknowledged. Its write-back and release follow at fixed times after its bucket's last beat.

**New:**
- Access i+1 starts at max(its request's arrival, s(i) + P(c(i), c(i+1))). The class c is a function of the
  bucket's public index only: on or off package, same pseudo-channel or same bucket.
- Every memory operation of access j (lookup, whole-bucket read, whole-bucket write, record write) and every
  internal slot (AES, stash) happens at a constant offset from s(j) or from t_arr(j).
- A dependency on an earlier in-flight access is resolved by choosing which on-chip copy of the data to use, never by
  a wait. The one exception is optionally the bucket-equality class, which is public.

**What changes in the proof sketch:**
1. **The schedule is a function of public data only.** It depends on the request arrival times (as today), the
   bucket-index sequence (uniform and independent, as today), and the memory latencies. Today's per-access argument
   becomes an argument over pairs (or k-tuples) of consecutive accesses. Since P depends only on classes of public
   indices, the joint distribution of the trace is still independent of the keys, the data and the stash state.
2. **Correctness no longer rests on read-after-acknowledged-write between accesses.** It rests on forwarding:
   - **(D1)** same bucket: the image after access i;
   - **(D2, D3)** same key: the newest in-flight entry;
   - **(D4)** the stash serialized in order.

   The proof must show that each access computes exactly what it would have computed sequentially. That is a
   refinement argument, by induction over accesses, that the forwarded state equals the sequential state.
3. **The stash bound (D5) carries over unchanged.** The sequence of stash states equals the sequential one. The pool
   adds k entries.

**Assumptions.** I don't have the paper's text of A6 and A7. I'm assuming A6 is "memory timing is independent of the
requests" and A7 is "a read issued after a write is acknowledged sees it"; tell me if your numbering differs.
- **A6 becomes:** a memory's latency may depend on the public trace (addresses, sizes, issue times, including the
  other in-flight accesses' traffic) and on request-independent noise, but not on keys, data or stash state. Today
  each access is alone on the bus. With overlap, its latency depends on its neighbour's traffic, which is itself
  public.
- **A7 becomes local to the stash and to same-bucket pairs.** It is still used inside the stash (D4, unchanged). For
  buckets it is replaced by forwarding (D1). If you choose the stall variant of D1 instead, A7 stays as is but
  applies only to equal bucket indices.

## 5. Verification plan

**Simulation:**
1. **Paired streams, cycle-identical.** Two request streams with the same arrival times and different keys, data and
   GET/PUT mix must produce identical bucket-port and host-port timing hashes, identical response times and
   identical release/end hashes. This is today's check, with k in flight. Cases:
   - repeated keys: the same key k times in a row, and ABAB;
   - the same bucket back to back, forced with debug ports;
   - a scan that fills the stash: keys mapping to few buckets, chains long;
   - 0 / 20 / 100% on package;
   - slow-memory profiles: stash, HBM, host.
2. **Sequential equivalence.** The overlapped design's responses, final memory images and stash states equal the
   sequential v14d1's on the same streams. The eviction scoreboard (v14d1) runs in every run.
3. **Injected leak.** A test-only define that makes the schedule wait on a same-key match (the stall the design
   forbids). The paired-stream check must fail. This proves the check would catch a key-dependent stall.
4. **Directed hazards.**
   - D1 with the write still in flight in host memory (+host_wlat large, b_early);
   - D2 with the key evicted by i and requested by i+1;
   - D4 with i remapping a block into b(i+1)'s window;
   - pool exhaustion at Claim 1's bound + k.

**Netlist level.**
- `run_stash_netlist.sh vivado` (and yosys) on every changed memory: per-access scratch, the second staging set, the
  in-flight tables.
- A new `tb_scratch` unit test against its funcsim netlist.

**Card:**
- all responses correct: `host_doma`, `host_phases` MIX, YCSB;
- leakage Runs A and B;
- the 2M-record calibration (§3), 4 KB at 20% and 50% on package;
- the 20M validation runs plus a hot run;
- the throughput sweep at k = 1, 2, k_max.

## 5a. Chosen target: 4–5 in flight, two AES-GCM cores

The measured model (§1.2) reaches its bound at 4 in flight. The RTL is parameterised by K_MAX; the target build
is K_MAX = 4, and K_MAX = 5 is a rebuild.

| Item | What it takes |
|---|---|
| **Two GCM cores** | A **decryption core** and an **encryption core**, each today's two-lane core (1 beat per cycle). Without the second core, off-package accesses stay at ≈ 2,400 cycles whatever k is. The split is clean: decryption uses the IV and tag stored in the bucket record and never touches the IV LFSR, so the encryption core alone owns the LFSR, and IVs stay one global sequence in encryption order (D7). Each core has its own key schedule and H powers, loaded from the same key. |
| **Scratch** | One 32 KB bucket buffer per access in flight: 5 × 256 Kb ≈ 36 BRAM36, each a copy of today's template. Plus two stash staging sets (2 × 512 Kb). |
| **Per-access contexts** | 5 copies of the request registers, b′, t_arr, the eviction queue, the slot list, the deadline timers and the release timer. One decision stage (in order), one encryption stage, one write stage. |
| **In-flight table** | 5 requested keys and up to 5 × 8 evicted keys, each with its new bucket, status and pool index (D2). Bucket-image forwarding from the newest in-flight copy (D1). |
| **Stash** | Decisions in order. The commit-to-open loop (≈ 450 cycles) fits inside P ≈ 1,150, so no overlay is needed. The stash port must sustain about 1 beat per cycle in its worst open: the **metadata port** (§1.1), plus design B or RAMA at 2M records. Without them, on-package-heavy runs stay near 3,300 cycles per request under design A at 2M. |
| **Host port** | It becomes the bound: 1,024 beats each way per off-package access, so P ≈ 1,150. A wider or second port is not worth it (PCIe is near its limit). |
| **Kernel** | Keeps up to 5 commands in flight and writes responses in order. |
| **Expected** (§1.2, measured model) | At 1 beat per cycle of stash data: ≈ 1,287 cycles per request at 0% on package (3.9×), ≈ 1,285 at 20% (3.8×, ≈ 233 KQPS), ≈ 1,282 at 100% (3.1×), with **k = 4**. At design A's 0.44 beats per cycle: ≈ 2,900 (1.7×) at any k ≥ 2. |
| **Paper** | The second core and the buffers raise the kernel's utilization. The 70% LUT reduction against BOLT must be re-measured. |

**Bring-up:** build the RTL for 5 contexts with k as a run-time parameter. Bring it up and calibrate at k = 2, then raise k
to 3, 4 and 5, each with its own debug-bitstream calibration of the deadlines.

## 6. Effort, risk, and the order of work

**The RTL is large.** The controller is one FSM today. Overlap needs:
- a front-half and a back-half stage, with per-access contexts (request, bucket, b′, t_arr, eviction queue, slot
  list, deadlines);
- per-access scratch and a second staging set;
- the in-flight table and bucket-image forwarding;
- serialized stash slots;
- the new deadlines and their debug records;
- kernel changes (keeping k commands in flight, responses in order).

**Estimate for the chosen target** (4–5 in flight, two GCM cores, metadata port): about 6–8 weeks of RTL plus 3–4 of
verification, then a calibration cycle per k. Timing closure at 300 MHz with two cores and 5 contexts is a further
risk: check it out of context early (`vitis/synth_ooc.tcl`).

**Risk: high.**
- The correctness hazards (D1–D4) are where silent wrong answers would come from, exactly the class that v14d's
  card failure showed simulation can miss.
- The security argument changes shape.

**Recommended order:**
1. **A Python schedule model first (1–2 days).** Measure each stage's time from the v14d1 simulation per access
   (debug records give every timestamp) and replay them through the fixed schedule with the resource constraints
   above. That fixes P and k for each on-package share, replacing this study's estimates.
2. **No gem5.** The study targets the U55C only. The Python model sets P and k. The card's PCIe and HBM contention
   with two accesses in flight is measured directly by the debug-bitstream calibration (§3), which has to run
   anyway to set the deadlines.
3. **RTL:** the §5a target, built for 5 contexts and brought up at k = 2 first.
