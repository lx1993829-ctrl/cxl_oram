`timescale 1ns / 1ps
// axi_rd2.v -- overlap step 2: two bucket reads in flight on one AXI read port (docs/overlap_rtl_spec.md section 14).
// Two copies of axi_master's read path (the module unchanged, its write side tied off). A read command goes to a free
// copy and carries its context. AR: the older command's bursts first (the younger may issue once the older has issued
// all of its addresses). R: every burst address accepted is recorded in order (which copy issued it), and each R burst
// goes to the copy at the head of that record, so a read's data always returns in issue order, and a read never waits
// for anything but earlier reads' memory latency. One AXI ID: the slave returns the bursts in address order.
`include "oram_params.vh"
module axi_rd2 #(
    parameter AXI_AW   = `AXI_ADDR_W,
    parameter AXI_DW   = `AXI_DATA_W,
    parameter AXI_IDW  = `AXI_ID_W,
    parameter AXI_LENW = `AXI_LEN_W,
    parameter BUCKET_W = `BUCKET_ID_W,
    parameter BEAT_AW  = `SCR_AW,
    parameter CW       = 2                       // context index width
)(
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 cmd_read,        // one-cycle pulse; only when free
    input  wire [BUCKET_W-1:0]  cmd_bucket,
    input  wire [CW-1:0]        cmd_ctx,
    output wire                 free,            // a copy can take a command now
    output wire                 busy_any,
    output wire                 busy_all,
    output reg  [AXI_DW-1:0]    rdata_data,      // a landed beat, its address in the bucket and its context
    output reg                  rdata_valid,
    output reg  [BEAT_AW-1:0]   rdata_beat_addr,
    output reg  [CW-1:0]        rdata_ctx,
    output wire                 read_done,       // a read's last beat has landed (its context: done_ctx)
    output wire [CW-1:0]        done_ctx,
    output wire [CW-1:0]        ar_ctx,          // context of the burst address on the bus (with m_axi_arvalid)
    output wire [CW-1:0]        r_ctx,           // context of the R burst being received (head of the record)
    output wire [AXI_IDW-1:0]   m_axi_arid,
    output wire [AXI_AW-1:0]    m_axi_araddr,
    output wire [AXI_LENW-1:0]  m_axi_arlen,
    output wire [2:0]           m_axi_arsize,
    output wire [1:0]           m_axi_arburst,
    output wire                 m_axi_arvalid,
    input  wire                 m_axi_arready,
    input  wire [AXI_IDW-1:0]   m_axi_rid,
    input  wire [AXI_DW-1:0]    m_axi_rdata,
    input  wire [1:0]           m_axi_rresp,
    input  wire                 m_axi_rlast,
    input  wire                 m_axi_rvalid,
    output wire                 m_axi_rready
);
    wire [1:0]          busy, rdone, arv, rrdy, rdv;
    wire [AXI_DW-1:0]   rd [0:1];
    wire [BEAT_AW-1:0]  rb [0:1];
    wire [AXI_AW-1:0]   ara [0:1];
    wire [AXI_LENW-1:0] arl [0:1];
    wire [2:0]          ars [0:1];
    wire [1:0]          arb [0:1];
    wire [AXI_IDW-1:0]  ari [0:1];
    reg  [CW-1:0]       ctx [0:1];
    reg                 older;                    // which copy holds the older command (when both are busy)
    wire [1:0]          start;
    // a command goes to copy 0 if it is free, else to copy 1
    assign start[0] = cmd_read && !busy[0];
    assign start[1] = cmd_read && busy[0] && !busy[1];
    assign free     = !busy[0] || !busy[1];
    assign busy_any = busy[0] || busy[1];
    assign busy_all = busy[0] && busy[1];
    // AR: the older busy copy first; the younger only once the older has no address left to issue
    wire        g    = (arv[0] && arv[1]) ? older : arv[1];
    assign m_axi_arvalid = arv[g];
    assign m_axi_araddr  = ara[g]; assign m_axi_arlen = arl[g]; assign m_axi_arsize = ars[g];
    assign m_axi_arburst = arb[g]; assign m_axi_arid  = ari[g];
    assign ar_ctx        = ctx[g];
    // R: the record of accepted burst addresses, in order (at most 2 x 8 outstanding)
    reg  [0:0] rq [0:31];
    reg  [4:0] rq_wp, rq_rp;
    wire       rq_empty = (rq_wp == rq_rp);
    wire       h        = rq[rq_rp];
    assign r_ctx        = ctx[h];
    assign m_axi_rready = !rq_empty && rrdy[h];
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin rq_wp <= 0; rq_rp <= 0; older <= 1'b0; ctx[0] <= 0; ctx[1] <= 0; end
        else begin
            if (m_axi_arvalid && m_axi_arready) begin rq[rq_wp] <= g; rq_wp <= rq_wp + 5'd1; end
            if (m_axi_rvalid && m_axi_rready && m_axi_rlast) rq_rp <= rq_rp + 5'd1;
            if (start[0]) begin ctx[0] <= cmd_ctx; if (busy[1]) older <= 1'b1; end
            if (start[1]) begin ctx[1] <= cmd_ctx; older <= 1'b0; end
        end
    end
    genvar k;
    generate for (k = 0; k < 2; k = k + 1) begin : g_rd
        axi_master #(.BEAT_AW(BEAT_AW)) u_m (
            .clk(clk), .rst_n(rst_n),
            .cmd_read(start[k]), .cmd_write(1'b0), .cmd_bucket(cmd_bucket),
            .cmd_read_done(rdone[k]), .cmd_write_done(), .cmd_busy(busy[k]), .wr_quiet(),
            .rdata_data(rd[k]), .rdata_valid(rdv[k]), .rdata_beat_addr(rb[k]),
            .wdata_data({AXI_DW{1'b0}}), .wdata_valid(1'b0), .wdata_ready(), .wdata_beat_req(),
            .wdata_hold(1'b0), .wdata_stall(),
            .m_axi_arid(ari[k]), .m_axi_araddr(ara[k]), .m_axi_arlen(arl[k]), .m_axi_arsize(ars[k]),
            .m_axi_arburst(arb[k]), .m_axi_arvalid(arv[k]), .m_axi_arready(m_axi_arready && g == k),
            .m_axi_rid(m_axi_rid), .m_axi_rdata(m_axi_rdata), .m_axi_rresp(m_axi_rresp), .m_axi_rlast(m_axi_rlast),
            .m_axi_rvalid(m_axi_rvalid && !rq_empty && h == k), .m_axi_rready(rrdy[k]),
            .m_axi_awid(), .m_axi_awaddr(), .m_axi_awlen(), .m_axi_awsize(), .m_axi_awburst(), .m_axi_awvalid(),
            .m_axi_awready(1'b0), .m_axi_wdata(), .m_axi_wstrb(), .m_axi_wlast(), .m_axi_wvalid(), .m_axi_wready(1'b0),
            .m_axi_bid({AXI_IDW{1'b0}}), .m_axi_bresp(2'b00), .m_axi_bvalid(1'b0), .m_axi_bready()
        );
    end endgenerate
    // landed beats (a copy registers its beat one cycle after the R handshake; beats arrive one at a time)
    reg [CW-1:0] dctx;
    always @(*) begin
        rdata_valid = rdv[0] || rdv[1];
        rdata_data  = rdv[1] ? rd[1] : rd[0];
        rdata_beat_addr = rdv[1] ? rb[1] : rb[0];
        rdata_ctx   = rdv[1] ? ctx[1] : ctx[0];
        dctx        = rdone[1] ? ctx[1] : ctx[0];
    end
    assign read_done = rdone[0] || rdone[1];
    assign done_ctx  = dctx;
`ifndef SYNTHESIS
    always @(posedge clk) begin
        if (rdv[0] && rdv[1]) $display("[%0t] AXI_RD2: two copies delivered a beat in one cycle", $time);
        if (rdone[0] && rdone[1]) $display("[%0t] AXI_RD2: two reads completed in one cycle", $time);
        if (cmd_read && !free) $display("[%0t] AXI_RD2: command while both copies are busy", $time);
        if (rq_wp - rq_rp > 5'd16) $display("[%0t] AXI_RD2: more than 16 bursts outstanding", $time);
    end
`endif
endmodule
