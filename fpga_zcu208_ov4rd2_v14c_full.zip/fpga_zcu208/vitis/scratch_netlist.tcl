# scratch_netlist.tcl -- overlap builds: synthesize scratch_buf (the bucket scratch buffer, instantiated two or four
# times) out of context with Vivado for the U55C and write its functional-simulation netlist, so sim/tb_scratch.v runs
# against the block-RAM mapping the card gets. Used by sim/run_scratch_netlist.sh. (UNTESTED here: no Vivado.)
#   vivado -mode batch -nojournal -nolog -source scratch_netlist.tcl -tclargs <rtl dir> <out dir>
set rtl [file normalize [lindex $argv 0]]
set out [file normalize [lindex $argv 1]]
file mkdir $out
read_verilog $rtl/scratch_buf.v
set dargs {}; foreach d [list ORAM_BLOCK_BEATS=128 ORAM_C=7 ORAM_SCHED_ARRIVAL] { lappend dargs -verilog_define $d }
synth_design -top scratch_buf -part xcu55c-fsvh2892-2L-e -mode out_of_context -include_dirs $rtl {*}$dargs \
             -flatten_hierarchy rebuilt -directive PerformanceOptimized
report_ram_utilization -file $out/ram_utilization.rpt
report_utilization -file $out/utilization.rpt
write_verilog -mode funcsim -force $out/scratch_buf_funcsim.v
puts "netlist: $out/scratch_buf_funcsim.v"
