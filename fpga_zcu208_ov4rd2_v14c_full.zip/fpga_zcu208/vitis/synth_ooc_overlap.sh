#!/bin/bash
# synth_ooc_overlap.sh -- out-of-context synthesis + place & route of doma_kernel for the overlap builds (U55C,
# 300 MHz): resources and timing before a multi-hour bitstream build. Uses a copy of rtl/ with the build switches
# written into oram_build_cfg.vh, so the working tree is untouched. Needs Vivado 2024.1. (UNTESTED here: no Vivado.)
#   bash synth_ooc_overlap.sh 1        # step 1 (two in flight), P 2900
#   bash synth_ooc_overlap.sh 4        # step 2 (four in flight, two reads in flight, two AES-GCM cores), card parameters (P 2150)
#   bash synth_ooc_overlap.sh 0        # the v14d1 production build, for comparison
# Reports: ooc_ov<step>/ooc_doma_kernel/{util_synth,util_routed,timing_routed,logic_levels}.rpt and a WNS line.
set -eu
cd "$(dirname "$0")"
S=${1:-1}; D=ooc_ov$S
rm -rf $D && mkdir -p $D/rtl && cp ../rtl/*.v ../rtl/*.vh $D/rtl/
{
  printf '// written by synth_ooc_overlap.sh\n`define ORAM_C 7\n`define ORAM_N 2097152\n`define ORAM_SCHED_ARRIVAL\n'
  [ "$S" = 1 ] && printf '`define ORAM_OVERLAP2\n`define ORAM_OV_P 2900\n`define ORAM_OV_DEQ 2700\n'
  [ "$S" = 4 ] && printf '`define ORAM_OVERLAP2\n`define ORAM_OVERLAP4\n`define ORAM_OV_P 2150\n`define ORAM_OV_CT_RD 600\n`define ORAM_OV_DEQ 6000\n`define ORAM_OV4_GA 1500\n'
  true
} > $D/rtl/oram_build_cfg.vh
cd $D && vivado -mode batch -nojournal -log synth.log -source ../synth_ooc.tcl -tclargs rtl > /dev/null 2>&1 || true
grep -E "^WNS" synth.log || echo "no WNS line: see $D/synth.log"
grep -E "^\| (CLB LUTs|CLB Registers|Block RAM Tile|URAM|DSPs)" ooc_doma_kernel/util_routed.rpt 2>/dev/null | head -5
