# rama_utilization.tcl -- v14d: the resources of the RAMA instance(s) a doma_big2m_rama.cfg link added, next to the
# kernel's own, from the routed checkpoint (for the paper's utilization table). Run in the build folder after v++:
#   vivado -mode batch -nojournal -nolog -source rama_utilization.tcl
# (or -tclargs <routed .dcp>). Prints one line per cell: LUT, FF, BRAM tiles, URAM, DSP.
set dcp [lindex $argv 0]
if {$dcp eq ""} { set dcp [lindex [lsort [glob -nocomplain _x/link/vivado/vpl/prj/prj.runs/impl_1/*_routed.dcp]] 0] }
if {$dcp eq ""} { puts "no routed checkpoint under _x/link/vivado/vpl/prj/prj.runs/impl_1/"; exit 1 }
open_checkpoint $dcp
set cells [concat [get_cells -hier -quiet -filter {NAME =~ *rama* && IS_PRIMITIVE == 0}] [get_cells -hier -quiet -filter {REF_NAME =~ *doma_kernel* && IS_PRIMITIVE == 0}]]
# keep the outermost RAMA cells only (their children are counted inside them)
set top {}
foreach c $cells { set inner 0; foreach d $cells { if {$d ne $c && [string first "$d/" $c] == 0} { set inner 1 } }; if {!$inner} { lappend top $c } }
report_utilization -hierarchical -hierarchical_depth 0 -cells $top -file rama_utilization.txt
puts [read [open rama_utilization.txt]]
puts "cells: $top"
