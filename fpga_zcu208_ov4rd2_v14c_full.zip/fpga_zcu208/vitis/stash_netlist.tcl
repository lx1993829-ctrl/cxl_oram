# stash_netlist.tcl -- v14d1: synthesize stash_hbm out of context with Vivado (the same tool and part as the card
# build) and write its functional-simulation netlist, so sim/tb_stash.v can be run against what Vivado actually builds
# (the block-RAM mapping of the staging memory included). Used by sim/run_stash_netlist.sh. (UNTESTED here: no Vivado.)
#   vivado -mode batch -nojournal -nolog -source stash_netlist.tcl -tclargs <rtl dir> <out dir> [ORAM_N] [extra define]
# ORAM_N must match the testbench's (run_stash_netlist.sh passes the same value; default 4096). The staging memory and
# its write paths do not depend on ORAM_N; the pool-index widths do (the card's NMAX 2,097,152 needs an 8 GB model).
set rtl [file normalize [lindex $argv 0]]
set out [file normalize [lindex $argv 1]]
set n   [expr {[llength $argv] > 2 ? [lindex $argv 2] : 4096}]
set ext [expr {[llength $argv] > 3 ? [lindex $argv 3] : ""}]
file mkdir $out
read_verilog $rtl/stash_hbm.v
set defs [list ORAM_BLOCK_BEATS=128 ORAM_C=7 ORAM_N=$n ORAM_SCHED_ARRIVAL]
if {$ext ne ""} { lappend defs $ext }
set dargs {}; foreach d $defs { lappend dargs -verilog_define $d }
synth_design -top stash_hbm -part xcu55c-fsvh2892-2L-e -mode out_of_context -include_dirs $rtl {*}$dargs \
             -flatten_hierarchy rebuilt -directive PerformanceOptimized
report_ram_utilization -file $out/ram_utilization.rpt
report_utilization -file $out/utilization.rpt
write_verilog -mode funcsim -force $out/stash_hbm_funcsim.v
puts "netlist: $out/stash_hbm_funcsim.v (defines: $defs)"
