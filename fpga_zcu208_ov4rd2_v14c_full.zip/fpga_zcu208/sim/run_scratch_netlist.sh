#!/bin/bash
# run_scratch_netlist.sh -- overlap builds: tb_scratch against scratch_buf's RTL and against a synthesized netlist.
#   bash run_scratch_netlist.sh rtl    [rtl dir]   # the RTL (Verilator)
#   bash run_scratch_netlist.sh yosys  [rtl dir]   # Yosys gate netlist (memories kept as arrays) + Verilator
#   bash run_scratch_netlist.sh vivado [rtl dir]   # Vivado OOC synthesis (vitis/scratch_netlist.tcl) + xsim, UNISIM
# Prints NETLIST <tool>: PASS / FAIL per test; exit 0 only if every test passed.
set -u
cd "$(dirname "$0")"
TOOL=${1:-yosys}; RTL=$(cd "${2:-../rtl}" && pwd)
OUT=build/scratch_$TOOL; mkdir -p $OUT
TESTS=("+cyc=200000 +seed=1" "+cyc=200000 +seed=7" "+cyc=200000 +seed=99")
D="-DORAM_BLOCK_BEATS=128 -DORAM_C=7"
rc=0
run_v() {   # Verilator testbench against $1 (the design source)
    verilator --binary --timing -j 0 -O1 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-UNOPTFLAT \
        -I"$RTL" $D --top-module tb_scratch tb_scratch.v "$1" -Mdir $OUT/obj -o V > $OUT/build.log 2>&1 \
        || { echo "NETLIST $TOOL: testbench build failed ($OUT/build.log)"; exit 2; }
    i=0; for t in "${TESTS[@]}"; do i=$((i+1))
        ./$OUT/obj/V $t > $OUT/run_$i.log 2>&1
        if grep -q "SCRATCH: ALL CHECKS PASSED" $OUT/run_$i.log; then echo "NETLIST $TOOL: PASS  $t"
        else echo "NETLIST $TOOL: FAIL  $t ($OUT/run_$i.log: $(grep -m1 -E 'FAIL' $OUT/run_$i.log))"; rc=1; fi
    done
}
if [ "$TOOL" = rtl ]; then
    run_v "$RTL/scratch_buf.v"
elif [ "$TOOL" = yosys ]; then
    command -v yosys > /dev/null || { echo "NETLIST yosys: SKIPPED (yosys not on PATH)"; exit 3; }
    cat > $OUT/synth.ys <<YS
read_verilog -sv -DSYNTHESIS $D -I $RTL $RTL/scratch_buf.v
hierarchy -top scratch_buf
proc; flatten; opt -full; memory -nomap; opt -full; techmap; opt -fast
abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX
opt_clean
write_verilog -noattr $OUT/scratch_buf_netlist.v
YS
    yosys -q -l $OUT/synth.log $OUT/synth.ys > /dev/null 2>&1 || { echo "NETLIST yosys: synthesis failed ($OUT/synth.log)"; exit 2; }
    run_v "$OUT/scratch_buf_netlist.v"
else
    command -v vivado > /dev/null && command -v xvlog > /dev/null || { echo "NETLIST vivado: SKIPPED (vivado/xvlog not on PATH)"; exit 3; }
    ( cd $OUT && vivado -mode batch -nojournal -nolog -source ../../../vitis/scratch_netlist.tcl -tclargs "$RTL" . > synth.log 2>&1 ) \
        || { echo "NETLIST vivado: synthesis failed ($OUT/synth.log)"; exit 2; }
    ( cd $OUT && xvlog -sv -d ORAM_BLOCK_BEATS=128 -d ORAM_C=7 -i "$RTL" ../../tb_scratch.v scratch_buf_funcsim.v \
          "$XILINX_VIVADO/data/verilog/src/glbl.v" > xvlog.log 2>&1 \
      && xelab -L unisims_ver -L unimacro_ver -L secureip -timescale 1ns/1ps tb_scratch glbl -s scr_net > xelab.log 2>&1 ) \
        || { echo "NETLIST vivado: xsim elaboration failed ($OUT/xvlog.log, $OUT/xelab.log)"; exit 2; }
    i=0; for t in "${TESTS[@]}"; do i=$((i+1))
        args=""; for a in $t; do args="$args -testplusarg ${a#+}"; done
        ( cd $OUT && xsim scr_net -R $args > run_$i.log 2>&1 )
        if grep -q "SCRATCH: ALL CHECKS PASSED" $OUT/run_$i.log; then echo "NETLIST vivado: PASS  $t"
        else echo "NETLIST vivado: FAIL  $t ($OUT/run_$i.log: $(grep -m1 -E 'FAIL' $OUT/run_$i.log))"; rc=1; fi
    done
fi
exit $rc
