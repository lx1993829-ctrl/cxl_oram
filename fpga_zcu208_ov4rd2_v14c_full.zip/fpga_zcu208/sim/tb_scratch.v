`timescale 1ns/1ps
`include "oram_params.vh"
// tb_scratch.v -- unit test of scratch_buf (the bucket scratch buffer; overlap builds instantiate it two or four
// times). Random traffic on all five ports every cycle, as the controller can drive them: the arriving read
// (stream_in), the decryption / copy / encryption ports (fsm_rd, fsm_wr), the eviction copies (ev_wr) and the
// write-back (stream_out). Writes go to different banks (positions) in one cycle, as the controller guarantees;
// reads too. Every read is checked against a reference copy (a read in the cycle of a write to the same beat
// returns the old data). Runs against the RTL or a synthesized netlist (run_scratch_netlist.sh).
//   +cyc=N   cycles (default 200000)    +seed=S
module tb_scratch;
    localparam Z = `ORAM_Z, BEATS = `BEATS_PER_BLOCK, DW = `AXI_DATA_W, TOT = Z * BEATS;
    localparam AW = `SCR_AW, BAW = $clog2(BEATS);
    reg clk = 0, rst_n = 0;
    always #2 clk = ~clk;
    reg  [DW-1:0] in_d, fw_d, ev_d;
    reg           in_v, fw_v, ev_v, fr_en, so_en;
    reg  [AW-1:0] in_a, fw_a, ev_a, fr_a, so_a;
    wire [DW-1:0] fr_q, so_q;
    wire          fr_qv, so_qv, bconf, bclash;
    scratch_buf dut (
        .clk(clk), .rst_n(rst_n),
        .stream_in_data(in_d), .stream_in_valid(in_v), .stream_in_beat_addr(in_a), .stream_in_ready(),
        .fsm_rd_addr(fr_a), .fsm_rd_en(fr_en), .fsm_rd_data(fr_q), .fsm_rd_valid(fr_qv),
        .fsm_wr_addr(fw_a), .fsm_wr_data(fw_d), .fsm_wr_en(fw_v),
        .ev_wr_addr(ev_a), .ev_wr_data(ev_d), .ev_wr_en(ev_v),
        .stream_out_beat_addr(so_a), .stream_out_rd_en(so_en), .stream_out_data(so_q), .stream_out_valid(so_qv),
        .bank_conflict(bconf), .bank_clash_now(bclash)
    );
    reg [DW-1:0] ref_m [0:TOT-1];
    reg [DW-1:0] exp_fr, exp_so; reg chk_fr = 0, chk_so = 0;
    reg [31:0] rs;
    integer cyc, ncyc, errs = 0, nrd = 0, i;
    function [31:0] xs; input [31:0] x; reg [31:0] y; begin
        y = (x == 0) ? 32'h2545F491 : x; y = y ^ (y << 13); y = y ^ (y >> 17); xs = y ^ (y << 5); end endfunction
    function [DW-1:0] rnd_data; input integer k; integer j; reg [31:0] t; begin
        t = rs ^ (k * 32'h9E3779B1); rnd_data = 0;
        for (j = 0; j < DW / 32; j = j + 1) begin t = xs(t); rnd_data[32*j +: 32] = t; end end endfunction
    // an address in a given bank (position)
    function [AW-1:0] addr_in; input [2:0] bank; input [31:0] r; begin addr_in = (bank << BAW) | (r % BEATS); end endfunction
    initial begin
        if (!$value$plusargs("cyc=%d", ncyc)) ncyc = 200000;
        if (!$value$plusargs("seed=%d", rs)) rs = 32'h1234567;
        in_v = 0; fw_v = 0; ev_v = 0; fr_en = 0; so_en = 0; in_a = 0; fw_a = 0; ev_a = 0; fr_a = 0; so_a = 0;
        in_d = 0; fw_d = 0; ev_d = 0;
        // every beat written once first (through the stream-in port), so every read has a defined reference
        repeat (4) @(posedge clk); rst_n = 1; @(posedge clk);
        for (i = 0; i < TOT; i = i + 1) begin
            @(negedge clk); in_v = 1; in_a = i; rs = xs(rs); in_d = rnd_data(i); ref_m[i] = in_d;
        end
        @(negedge clk); in_v = 0; @(negedge clk);
        for (cyc = 0; cyc < ncyc; cyc = cyc + 1) begin : one
            reg [2:0] b0, b1, b2, r0, r1; reg [31:0] r;
            @(negedge clk);
            rs = xs(rs); r = rs;
            // three write banks, all different; two read banks, different from each other
            b0 = r[2:0]; b1 = b0 + 3'd1 + (r[5:3] % 3'd7); if (b1 == b0) b1 = b0 + 3'd1;
            b2 = b0 + 3'd2 + (r[8:6] % 3'd5); if (b2 == b0 || b2 == b1) b2 = b1 + 3'd1; if (b2 == b0) b2 = b2 + 3'd1;
            r0 = r[11:9]; r1 = r0 + 3'd1 + (r[14:12] % 3'd7); if (r1 == r0) r1 = r0 + 3'd1;
            rs = xs(rs);
            in_v = rs[0]; fw_v = rs[1]; ev_v = rs[2]; fr_en = rs[3]; so_en = rs[4];
            in_a = addr_in(b0, xs(rs ^ 1)); fw_a = addr_in(b1, xs(rs ^ 2)); ev_a = addr_in(b2, xs(rs ^ 3));
            fr_a = addr_in(r0, xs(rs ^ 4)); so_a = addr_in(r1, xs(rs ^ 5));
            in_d = rnd_data(cyc * 3); fw_d = rnd_data(cyc * 3 + 1); ev_d = rnd_data(cyc * 3 + 2);
            // expected read data: the memory before this cycle's writes
            exp_fr = ref_m[fr_a]; exp_so = ref_m[so_a];
            @(posedge clk); #0.1;
            if (in_v) ref_m[in_a] = in_d;
            if (fw_v) ref_m[fw_a] = fw_d;
            if (ev_v) ref_m[ev_a] = ev_d;
            chk_fr = fr_en; chk_so = so_en;
            @(negedge clk);
            // data of the reads issued last cycle (one-cycle read latency)
            if (chk_fr) begin nrd = nrd + 1;
                if (!fr_qv || fr_q !== exp_fr) begin errs = errs + 1;
                    if (errs <= 5) $display("FAIL cycle %0d: fsm read %0d valid %0d got %h want %h", cyc, fr_a, fr_qv, fr_q, exp_fr); end end
            if (chk_so) begin nrd = nrd + 1;
                if (!so_qv || so_q !== exp_so) begin errs = errs + 1;
                    if (errs <= 5) $display("FAIL cycle %0d: stream-out read %0d valid %0d got %h want %h", cyc, so_a, so_qv, so_q, exp_so); end end
            in_v = 0; fw_v = 0; ev_v = 0; fr_en = 0; so_en = 0;
        end
        if (bconf) begin errs = errs + 1; $display("FAIL: bank conflict flagged (the test never makes one)"); end
        if (errs == 0) $display("SCRATCH: ALL CHECKS PASSED (%0d cycles, %0d reads checked)", ncyc, nrd);
        else $display("SCRATCH: %0d FAILURE(S)", errs);
        $finish;
    end
endmodule
