// tb_ni.v -- traffic, stress and non-interference tests for secure_oram_top (ZCU208 design).
// Two-client build: non-interference between clients. Single-client build (default):
// the same traffic, stress, worst-case and bus checks for client 0.
// Plain Verilog-2001: compiles as Verilog or SystemVerilog.
//   +ni=V    client 0 behaviour: 0 idle, 1 saturating, 2 random gaps, 3 bursty
//   +ops=N   client-1 operations to run (default 12)
//   +bp=P    AXI backpressure: ARREADY/AWREADY/WREADY low and read-data gaps P% of cycles
//   +stress  worst-case eviction test (debug builds: steers remaps with dbg_prng_override)
//   +xpart   a host over-grants client 0 a lease on client 1's slots; the access must be rejected
//   +worst   directed worst-case paths for sim/worst_case.py (with +timing_log=<file>)
//   +limit=N stop after N cycles past oram_ready
// Client 1 replays a fixed trace: its next request is issued a fixed (seeded)
// gap after its OWN previous completion. Its request/completion cycles,
// relative to oram_ready, are hashed: with the time-division arbiter the hash
// must be identical for every client-0 behaviour. Read data is checked too.
// Build with -DOLD_ARBITER against the Phase 2 RTL as the negative control.
`timescale 1ns/1ps
`include "oram_params.vh"
module tb_ni;
    localparam AXI_DW = `AXI_DATA_W, AXI_AW = `AXI_ADDR_W, AXI_IDW = `AXI_ID_W, AXI_LENW = `AXI_LEN_W;
    localparam SLOT_AW = `SLOT_ADDR_W, BEATS = `BEATS_PER_BLOCK, BW = `BEAT_CNT_W;
    localparam MEM_BEATS = `ORAM_B * `BUCKET_BYTES / 32;     // compact layout: Z blocks per bucket
    reg clk = 1'b0, rst_n = 1'b0;
    always #2 clk = ~clk;
    reg [63:0] cyc = 64'd0;
    always @(posedge clk) cyc <= cyc + 64'd1;
    // ---------------- DUT ----------------
    reg         mgmt_req = 0; reg [2:0] mgmt_op = 0; reg [7:0] mgmt_lease_id = 0; reg mgmt_client_id = 0;
    reg [AXI_AW-1:0] mgmt_base = 0, mgmt_size = 0;
    wire        mgmt_ack, mgmt_error; wire [31:0] mgmt_token_out; wire [2*32-1:0] ctok_out;
    reg  [1:0]  creq = 0, cop = 0, cwv = 0;
    reg  [2*SLOT_AW-1:0] caddr = 0; reg [63:0] ctok = 0; reg [15:0] clid = 0;
    reg  [2*AXI_DW-1:0]  cwdata;
    wire [1:0]  cdone, crv, cviol, clock_out, cready_w;
    wire [2*AXI_DW-1:0] crdata;
    wire [2*BW-1:0]     cwbeat_w;
    // Clients the hardware has (one in the default build). The testbench keeps two-client
    // vectors and connects only the hardware's slices; a missing client's outputs read 0.
    // MC is the measured client of the traffic loop: client 1 with two clients, else 0.
    localparam NC = `ORAM_NUM_CLIENTS;
    localparam MC = NC - 1;
    wire [NC-1:0]        cdone_n, crv_n, cviol_n, clock_n, cready_n;
    wire [NC*AXI_DW-1:0] crdata_n;
    wire [NC*BW-1:0]     cwbeat_n;
    assign cdone = cdone_n; assign crv = crv_n; assign cviol = cviol_n; assign clock_out = clock_n;
    assign crdata = crdata_n;
    wire [BW-1:0]       oram_beat;
    reg  key_load = 0; wire key_ready, ct_ovr, oram_ready, err_tag, err_stash;
    wire slot_ovr; wire [31:0] real_cnt;
    wire [AXI_IDW-1:0] arid, awid; wire [AXI_AW-1:0] araddr, awaddr; wire [AXI_LENW-1:0] arlen, awlen;
    wire arvalid, rready, awvalid, wvalid, wlast, bready; wire [AXI_DW-1:0] wdata; wire [AXI_DW/8-1:0] wstrb;
    reg  arready = 1, awready = 1, wready = 1;
    reg  [`BUCKET_ID_W-1:0] prng_ovr = 0;
    // Deterministic pseudo-random draws (xorshift32): identical on every simulator version. Verilator's $random sequence
    // changed between releases, which changed the stimulus and with it the calibrated timing budgets.
    function [31:0] xs32; input [31:0] x; reg [31:0] y; begin
        y = (x == 32'd0) ? 32'h2545F491 : x; y = y ^ (y << 13); y = y ^ (y >> 17); xs32 = y ^ (y << 5);
    end endfunction
    reg  [31:0] bp_rng = 32'h1F123BB5, bp_a, bp_b, bp_c, bp_d;
    reg  [`BUCKET_ID_W:0]   hbm_bkts = 0;     // +hbm_bkts=N: buckets 0..N-1 count as HBM (AR_WB_H budgets)
    integer bp = 0; reg bp_gap = 0;
    reg  [AXI_DW-1:0] rdata = 0; reg rvalid = 0, rlast = 0, bvalid = 0;
    // position map in HBM: a metadata memory with the U55C's measured HBM latency profile
    // (reads 53 cycles, 2% of them 105 slower; writes acknowledged after 26). +meta_lat=N
    // +meta_slow_pct=N +meta_slow_extra=N +meta_wlat=N change it.
    wire [63:0]  mm_araddr, mm_awaddr; wire [7:0] mm_arlen, mm_awlen;
    wire         mm_arvalid, mm_arready, mm_rvalid, mm_rlast, mm_rready, mm_awvalid, mm_awready;
    wire         mm_wvalid, mm_wready, mm_wlast, mm_bvalid, mm_bready;
    wire [`AXI_DATA_W-1:0] mm_rdata, mm_wdata; wire [`AXI_DATA_W/8-1:0] mm_wstrb;
    // bucket records in HBM (metadata + per-position IV/tag), same measured HBM profile as the position map;
    // +brec_lat=N +brec_slow_pct=N +brec_slow_extra=N +brec_wlat=N change it.
    wire [63:0] rm_araddr, rm_awaddr; wire [7:0] rm_arlen, rm_awlen;
    wire rm_arvalid, rm_arready, rm_rvalid, rm_rlast, rm_rready, rm_awvalid, rm_awready;
    wire rm_wvalid, rm_wready, rm_wlast, rm_bvalid, rm_bready;
    wire [`AXI_DATA_W-1:0] rm_rdata, rm_wdata; wire [`AXI_DATA_W/8-1:0] rm_wstrb;
    // the stash in HBM (per-bucket lists + block pool), same measured HBM profile as the position map;
    // +stash_lat=N +stash_slow_pct=N +stash_slow_extra=N +stash_wlat=N change it.
    wire [63:0] sm_araddr, sm_awaddr; wire [7:0] sm_arlen, sm_awlen;
    wire sm_arvalid, sm_arready, sm_rvalid, sm_rlast, sm_rready, sm_awvalid, sm_awready;
    wire sm_wvalid, sm_wready, sm_wlast, sm_bvalid, sm_bready;
    wire [`AXI_DATA_W-1:0] sm_rdata, sm_wdata; wire [`AXI_DATA_W/8-1:0] sm_wstrb;
    secure_oram_top dut (
        .clk(clk), .rst_n(rst_n),
        .mgmt_req(mgmt_req), .mgmt_op(mgmt_op), .mgmt_lease_id(mgmt_lease_id), .mgmt_client_id(mgmt_client_id),
        .mgmt_base_addr(mgmt_base), .mgmt_size(mgmt_size), .mgmt_duration(32'hFFFF_FFFF), .mgmt_token_in(32'd0),
        .mgmt_ack(mgmt_ack), .mgmt_error(mgmt_error), .mgmt_token_out(mgmt_token_out), .client_token_out(ctok_out[NC*32-1:0]),
        .client_req(creq[NC-1:0]), .client_op(cop[NC-1:0]), .client_slot_addr(caddr[NC*SLOT_AW-1:0]),
        .client_wdata(cwdata[NC*AXI_DW-1:0]), .client_wstrb({NC*AXI_DW/8{1'b1}}), .client_wdata_valid(cwv[NC-1:0]),
        .client_token(ctok[NC*32-1:0]), .client_lease_id(clid[NC*8-1:0]),
        .client_done(cdone_n), .client_rdata(crdata_n), .client_rdata_valid(crv_n),
        .access_violation(cviol_n), .client_lockout(clock_n),
        .key_load(key_load), .key_ready(key_ready), .err_ct_overrun(ct_ovr), .oram_ready(oram_ready),
`ifndef OLD_ARBITER
        .cfg_tdm_slot_cycles(16'd0), .client_wbeat_req(cwbeat_n), .client_ready(cready_n),
        .err_slot_overrun(slot_ovr), .dbg_slot_start(),
        .dbg_real_cnt(real_cnt),
`endif
        .init_mode(1'b0), .init_pm_wr_addr(0), .init_pm_wr_bucket(0), .init_pm_wr_status(2'd0), .init_pm_wr_en(1'b0),
        .init_bm_wr_bucket(0), .init_bm_wr_slot_list(0), .init_bm_wr_fill(0), .init_bm_wr_en(1'b0),
        .aes_key(128'h000102030405060708090a0b0c0d0e0f), .aes_iv_seed(96'h0123456789abcdef01234567), .cfg_n({(`SLOT_ID_W+1){1'b0}}), .cfg_hbm_bkts(hbm_bkts),
        .m_axi_arid(arid), .m_axi_araddr(araddr), .m_axi_arlen(arlen), .m_axi_arsize(), .m_axi_arburst(),
        .m_axi_arvalid(arvalid), .m_axi_arready(arready), .m_axi_rid({AXI_IDW{1'b0}}), .m_axi_rdata(rdata),
        .m_axi_rresp(2'b00), .m_axi_rlast(rlast), .m_axi_rvalid(rvalid), .m_axi_rready(rready),
        .m_axi_awid(awid), .m_axi_awaddr(awaddr), .m_axi_awlen(awlen), .m_axi_awsize(), .m_axi_awburst(),
        .m_axi_awvalid(awvalid), .m_axi_awready(awready), .m_axi_wdata(wdata), .m_axi_wstrb(wstrb),
        .m_axi_wlast(wlast), .m_axi_wvalid(wvalid), .m_axi_wready(wready),
        .m_axi_bid({AXI_IDW{1'b0}}), .m_axi_bresp(2'b00), .m_axi_bvalid(bvalid), .m_axi_bready(bready),
        .m_meta_araddr(mm_araddr), .m_meta_arlen(mm_arlen), .m_meta_arvalid(mm_arvalid), .m_meta_arready(mm_arready),
        .m_meta_rdata(mm_rdata), .m_meta_rlast(mm_rlast), .m_meta_rvalid(mm_rvalid), .m_meta_rready(mm_rready),
        .m_meta_awaddr(mm_awaddr), .m_meta_awlen(mm_awlen), .m_meta_awvalid(mm_awvalid), .m_meta_awready(mm_awready),
        .m_meta_wdata(mm_wdata), .m_meta_wstrb(mm_wstrb), .m_meta_wlast(mm_wlast), .m_meta_wvalid(mm_wvalid),
        .m_meta_wready(mm_wready), .m_meta_bvalid(mm_bvalid), .m_meta_bready(mm_bready),
        .m_brec_araddr(rm_araddr), .m_brec_arlen(rm_arlen), .m_brec_arvalid(rm_arvalid), .m_brec_arready(rm_arready),
        .m_brec_rdata(rm_rdata), .m_brec_rlast(rm_rlast), .m_brec_rvalid(rm_rvalid), .m_brec_rready(rm_rready),
        .m_brec_awaddr(rm_awaddr), .m_brec_awlen(rm_awlen), .m_brec_awvalid(rm_awvalid), .m_brec_awready(rm_awready),
        .m_brec_wdata(rm_wdata), .m_brec_wstrb(rm_wstrb), .m_brec_wlast(rm_wlast), .m_brec_wvalid(rm_wvalid),
        .m_brec_wready(rm_wready), .m_brec_bvalid(rm_bvalid), .m_brec_bready(rm_bready),
        .m_stash_araddr(sm_araddr), .m_stash_arlen(sm_arlen), .m_stash_arvalid(sm_arvalid), .m_stash_arready(sm_arready),
        .m_stash_rdata(sm_rdata), .m_stash_rlast(sm_rlast), .m_stash_rvalid(sm_rvalid), .m_stash_rready(sm_rready),
        .m_stash_awaddr(sm_awaddr), .m_stash_awlen(sm_awlen), .m_stash_awvalid(sm_awvalid), .m_stash_awready(sm_awready),
        .m_stash_wdata(sm_wdata), .m_stash_wstrb(sm_wstrb), .m_stash_wlast(sm_wlast), .m_stash_wvalid(sm_wvalid),
        .m_stash_wready(sm_wready), .m_stash_bvalid(sm_bvalid), .m_stash_bready(sm_bready),
        .dbg_oram_state(), .oram_busy(), .err_stash_overflow(err_stash), .err_bucket_overflow(),
        .err_tag_mismatch(err_tag), .oram_beat_cnt(oram_beat), .dbg_gcm_tag_match(), .dbg_gcm_tag_valid(),
        .dbg_force_same_bucket(1'b0), .dbg_prng_override(prng_ovr), .perf_reset(1'b0)
    );
    axi_mem_model #(.DW(`AXI_DATA_W), .WORDS(1 << 16), .BASE(64'd0), .RLAT(53)) u_meta (
        .clk(clk), .rst_n(rst_n), .araddr(mm_araddr), .arlen(mm_arlen), .arvalid(mm_arvalid), .arready(mm_arready),
        .rdata(mm_rdata), .rresp(), .rlast(mm_rlast), .rvalid(mm_rvalid), .rready(mm_rready),
        .awaddr(mm_awaddr), .awlen(mm_awlen), .awvalid(mm_awvalid), .awready(mm_awready), .wdata(mm_wdata), .wstrb(mm_wstrb),
        .wlast(mm_wlast), .wvalid(mm_wvalid), .wready(mm_wready), .bresp(), .bvalid(mm_bvalid), .bready(mm_bready));
    initial begin : meta_profile
        integer v;
        u_meta.slow_pct = 2; u_meta.slow_extra = 105; u_meta.wlat = 26;
        if ($value$plusargs("meta_lat=%d", v))        u_meta.lat = v;
        if ($value$plusargs("hbm_bkts=%d", v))        hbm_bkts = v;
        if ($value$plusargs("bkt_lat=%d", v))         bkt_lat = v;
        if ($value$plusargs("meta_slow_pct=%d", v))   u_meta.slow_pct = v;
        if ($value$plusargs("meta_slow_extra=%d", v)) u_meta.slow_extra = v;
        if ($value$plusargs("meta_wlat=%d", v))       u_meta.wlat = v;
    end
    axi_mem_model #(.DW(`AXI_DATA_W), .WORDS(1 << 16), .BASE(64'd0), .RLAT(53)) u_brec (
        .clk(clk), .rst_n(rst_n), .araddr(rm_araddr), .arlen(rm_arlen), .arvalid(rm_arvalid), .arready(rm_arready),
        .rdata(rm_rdata), .rresp(), .rlast(rm_rlast), .rvalid(rm_rvalid), .rready(rm_rready),
        .awaddr(rm_awaddr), .awlen(rm_awlen), .awvalid(rm_awvalid), .awready(rm_awready), .wdata(rm_wdata), .wstrb(rm_wstrb),
        .wlast(rm_wlast), .wvalid(rm_wvalid), .wready(rm_wready), .bresp(), .bvalid(rm_bvalid), .bready(rm_bready));
    initial begin : brec_profile
        integer v;
        u_brec.slow_pct = 2; u_brec.slow_extra = 105; u_brec.wlat = 26;
        if ($value$plusargs("brec_lat=%d", v))        u_brec.lat = v;
        if ($value$plusargs("brec_slow_pct=%d", v))   u_brec.slow_pct = v;
        if ($value$plusargs("brec_slow_extra=%d", v)) u_brec.slow_extra = v;
        if ($value$plusargs("brec_wlat=%d", v))       u_brec.wlat = v;
    end
    axi_mem_model #(.DW(`AXI_DATA_W), .WORDS(1 << 16), .BASE(64'd0), .RLAT(53)) u_stmem (
        .clk(clk), .rst_n(rst_n), .araddr(sm_araddr), .arlen(sm_arlen), .arvalid(sm_arvalid), .arready(sm_arready),
        .rdata(sm_rdata), .rresp(), .rlast(sm_rlast), .rvalid(sm_rvalid), .rready(sm_rready),
        .awaddr(sm_awaddr), .awlen(sm_awlen), .awvalid(sm_awvalid), .awready(sm_awready), .wdata(sm_wdata), .wstrb(sm_wstrb),
        .wlast(sm_wlast), .wvalid(sm_wvalid), .wready(sm_wready), .bresp(), .bvalid(sm_bvalid), .bready(sm_bready));
    initial begin : stash_profile
        integer v;
        u_stmem.slow_pct = 2; u_stmem.slow_extra = 105; u_stmem.wlat = 26;
        if ($value$plusargs("stash_lat=%d", v))        u_stmem.lat = v;
        if ($value$plusargs("stash_slow_pct=%d", v))   u_stmem.slow_pct = v;
        if ($value$plusargs("stash_slow_extra=%d", v)) u_stmem.slow_extra = v;
        if ($value$plusargs("stash_wlat=%d", v))       u_stmem.wlat = v;
        if ($value$plusargs("stash_gap=%d", v))        u_stmem.gap_pct = v;   // v14d: % of cycles with no stash read beat
        if ($value$plusargs("stash_pc=%d", v))         u_stmem.pc_bytes = v;  // v14d: pseudo-channel size (bytes)
        if ($value$plusargs("stash_idblk=%d", v))      u_stmem.id_block = v;  // v14d: one AXI ID kept in order across channels
    end
`ifndef OLD_ARBITER
    assign cready_w = cready_n; assign cwbeat_w = cwbeat_n;
`endif
`ifdef OLD_ARBITER
    assign cready_w = 2'b11; assign cwbeat_w = {oram_beat, oram_beat};
    assign slot_ovr = 1'b0; assign real_cnt = 0; 
`endif
    // ---------------- in-order AXI memory model ----------------
    reg [AXI_DW-1:0] mem [0:MEM_BEATS-1];
    integer mi; initial for (mi = 0; mi < MEM_BEATS; mi = mi + 1) mem[mi] = 0;
    reg [31:0] rq_addr [0:15]; reg [8:0] rq_len [0:15]; reg [63:0] rq_t [0:15]; reg [3:0] rq_wp = 0, rq_rp = 0; reg [4:0] rq_n = 0;   // rq_t: cycle of each read request
    reg [8:0] r_beat = 0; reg [11:0] r_wait = 0; reg r_act = 0; integer bkt_lat = 20;   // +bkt_lat=N: bucket read latency (default 20)
    reg [31:0] wq_addr [0:15]; reg [8:0] wq_len [0:15]; reg [3:0] wq_wp = 0, wq_rp = 0; reg [8:0] w_beat = 0; reg [4:0] b_pend = 0;
    reg [AXI_DW-1:0] wf [0:2047]; reg [10:0] wf_wp = 0, wf_rp = 0;   // write-data FIFO
    always @(posedge clk) begin
        if (arvalid && arready) begin rq_addr[rq_wp] <= araddr[31:5]; rq_len[rq_wp] <= arlen; rq_t[rq_wp] <= cyc; rq_wp <= rq_wp + 1; end
        if (awvalid && awready) begin wq_addr[wq_wp] <= awaddr[31:5]; wq_len[wq_wp] <= awlen; wq_wp <= wq_wp + 1; end
        // backpressure (+bp=P): ready signals and read-data gaps, re-drawn every cycle
        bp_a = xs32(bp_rng); bp_b = xs32(bp_a); bp_c = xs32(bp_b); bp_d = xs32(bp_c); bp_rng = bp_d;
        arready <= !(bp > 0 && (bp_a % 100) < bp);
        awready <= !(bp > 0 && (bp_b % 100) < bp);
        wready  <= !(bp > 0 && (bp_c % 100) < bp);
        bp_gap  <=  (bp > 0 && (bp_d % 100) < bp);
        // reads: each burst's first beat bkt_lat cycles after its request at the earliest; queued bursts follow each
        // other back to back (the next first beat right after the previous last beat), as real memory delivers
        if (rvalid && rready) begin
            if (rlast && rq_rp + 4'd1 != rq_wp && cyc >= rq_t[rq_rp + 4'd1] + bkt_lat && !bp_gap) begin   // next burst, no gap
                rdata <= mem[rq_addr[rq_rp + 4'd1] % MEM_BEATS]; rlast <= (rq_len[rq_rp + 4'd1] == 0);
                rq_rp <= rq_rp + 1; r_beat <= 0;
            end
            else if (rlast) begin rvalid <= 0; rlast <= 0; r_act <= 0; rq_rp <= rq_rp + 1; r_wait <= 0; end
            else if (bp_gap) begin rvalid <= 0; r_beat <= r_beat + 1; end
            else begin
                rdata <= mem[(rq_addr[rq_rp] + r_beat + 1) % MEM_BEATS];
                rlast <= (r_beat + 1 == rq_len[rq_rp]); r_beat <= r_beat + 1;
            end
        end else if (r_act && !rvalid && !bp_gap) begin
            rdata <= mem[(rq_addr[rq_rp] + r_beat) % MEM_BEATS];
            rlast <= (r_beat == rq_len[rq_rp]); rvalid <= 1;
        end else if (!r_act && !rvalid && rq_rp != rq_wp) begin
            if (cyc >= rq_t[rq_rp] + bkt_lat) begin r_act <= 1; r_beat <= 0; end
        end
        if (wvalid && wready) begin wf[wf_wp] <= wdata; wf_wp <= wf_wp + 1; end
        if (wq_rp != wq_wp && wf_rp != wf_wp) begin       // apply data to its address, in order
            mem[(wq_addr[wq_rp] + w_beat) % MEM_BEATS] <= wf[wf_rp]; wf_rp <= wf_rp + 1;
            if (w_beat == wq_len[wq_rp]) begin w_beat <= 0; wq_rp <= wq_rp + 1; b_pend <= b_pend + 1; end
            else w_beat <= w_beat + 1;
        end
        if (bvalid && bready) bvalid <= 0;
        else if (!bvalid && b_pend != 0) begin bvalid <= 1; b_pend <= b_pend - 1; end
    end
    // ---------------- clients ----------------
    function [31:0] pat; input [31:0] op_id; input [31:0] beat; input [31:0] w;
        pat = (op_id + 32'd1) * 32'h9E3779B1 ^ (beat << 16) ^ (w << 8) ^ 32'h5A000000;
    endfunction
    function [AXI_DW-1:0] lane; input [31:0] op_id; input [31:0] beat;
        integer w; begin for (w = 0; w < 8; w = w + 1) lane[w*32 +: 32] = pat(op_id, beat, w); end
    endfunction
    function [31:0] xs; input [31:0] x; reg [31:0] y;   // xorshift32
        begin y = x; y = y ^ (y << 13); y = y ^ (y >> 17); y = y ^ (y << 5); xs = y; end
    endfunction
    integer variant, nops, c, k; reg [63:0] limit;
    reg [31:0] tok [0:1]; reg [31:0] rng [0:1];
    reg        st [0:1]; reg [63:0] nxt [0:1], rqc [0:1]; reg opq [0:1];
    reg [31:0] slot [0:1], opid [0:1], rbeat [0:1], ndone [0:1], nerr [0:1];
    reg [63:0] hsh, t0, lsum, lmin, lmax;
    integer    lastw [0:511];
    reg [63:0] vrd = 0, vwr = 0;                     // bucket-port beats (+viol1)
    always @(posedge clk) begin if (rvalid && rready) vrd <= vrd + 1; if (wvalid && wready) vwr <= vwr + 1; end
    always @(*) begin
        cwdata[0 +: AXI_DW]      = lane(opid[0], cwbeat_w[0 +: BW]);
        cwdata[AXI_DW +: AXI_DW] = lane(opid[1], cwbeat_w[BW +: BW]);
    end
    task plan; input integer cc; reg [31:0] r; begin
        rng[cc] = xs(rng[cc]); r = rng[cc];
        opq[cc]  = r[0];
        slot[cc] = (cc == 1 ? `ORAM_N / 2 : 0) + 1 + (r[15:8] % 64);
        if (cc == 1)           nxt[cc] = cyc + (r[31:16] % 3000);
        else if (variant == 1) nxt[cc] = cyc;
        else if (variant == 2) nxt[cc] = cyc + (r[31:16] % 40000);
        else                   nxt[cc] = cyc + ((r[31:30] == 2'd0) ? 60000 : 0);
    end endtask



    // one operation with every remap steered to bucket bkt (debug override)
    task w_op; input wr; input integer sidx; input [`BUCKET_ID_W-1:0] bkt; inout integer errs;
        integer nev; begin prng_ovr = bkt; stress_op(wr, sidx, nev, errs); end
    endtask



    // Progress messages: without them, slow simulators (XSim) print nothing for
    // minutes while the ORAM formats its buckets. +heartbeat=N sets the interval in
    // cycles (default 50,000; 0 turns it off).
    integer hb_every, hb_win; reg hb_ready_q;
    initial begin
        hb_win = 0; hb_ready_q = 0;
        $timeformat(-6, 1, " us", 10);           // print times in microseconds
        if (!$value$plusargs("heartbeat=%d", hb_every)) hb_every = 50000;
`ifdef ORAM_PKG_REV
        $display("tb_ni | package %s | formatting all buckets before the first request (about 250,000 cycles)", `ORAM_PKG_REV);
`else
        $display("tb_ni | formatting all buckets before the first request (about 250,000 cycles)");
`endif
    end
    always @(posedge clk) begin
        if (dut.tdm_run && dut.slot_cnt == 16'd0) hb_win = hb_win + 1;
        if (oram_ready && !hb_ready_q)
            $display("[%0t] tb_ni: ORAM ready after %0d cycles (format and layout done), requests start now", $time, cyc);
        hb_ready_q <= oram_ready;
        if (hb_every > 0 && cyc > 0 && (cyc % hb_every) == 0)
            $display("[%0t] tb_ni: cycle %0d, %0s, %0d windows run", $time, cyc,
                     oram_ready ? "serving requests" : "formatting", hb_win);
    end

    // Per-window bus timing (+bus_log=<file>): the cycle, relative to the start of
    // each time window, at which the bucket read address (AR) and the write-back
    // address (AW) are first presented on the AXI bus, plus the window's owner and the
    // bucket read. kind = owning client of a real window, or 9 for a dummy window.
    integer bl_fd, bl_win, bl_start, bl_ar, bl_aw, bl_kind, bl_own, bl_bkt; reg bl_arv_q, bl_awv_q;
    reg [8*256-1:0] bl_name;
    initial begin
        bl_fd = 0; bl_win = -1; bl_arv_q = 0; bl_awv_q = 0;
        if ($value$plusargs("bus_log=%s", bl_name)) begin
            bl_fd = $fopen(bl_name, "w");
            if (bl_fd) $fdisplay(bl_fd, "window,kind,owner,bucket,ar_offset,aw_offset");
        end
    end
    always @(posedge clk) begin
        if (dut.tdm_run && dut.slot_cnt == 16'd0) begin
            if (bl_fd && bl_win >= 0) $fdisplay(bl_fd, "%0d,%0d,%0d,%0d,%0d,%0d", bl_win, bl_kind, bl_own, bl_bkt, bl_ar, bl_aw);
            bl_win = bl_win + 1; bl_start = cyc; bl_ar = -1; bl_aw = -1; bl_kind = -1; bl_own = -1; bl_bkt = -1;
        end
        if (dut.tdm_run && dut.slot_cnt == 16'd3) begin bl_kind = dut.grant_real ? dut.grant_id : 9; bl_own = dut.grant_id; end
        if (arvalid && !bl_arv_q && bl_ar < 0 && bl_win >= 0) begin bl_ar = cyc - bl_start; bl_bkt = araddr / `BUCKET_BYTES; end
        if (awvalid && !bl_awv_q && bl_aw < 0 && bl_win >= 0) bl_aw = cyc - bl_start;
        bl_arv_q <= arvalid; bl_awv_q <= awvalid;
    end


    // Every bucket starts holding C slots (random boot layout). drain(x) empties bucket
    // x: it reads the slot at position 0, steered to a sink bucket, until x is empty,
    // then reads one slot of the sink steered back to the sink, so the moved blocks
    // are evicted there at once and the stash stays small. Each drain uses a fresh
    // sink that no scenario targets (one flush can fill a sink).
    integer sink_ptr;
    initial sink_ptr = 0;
    function is_target; input integer b; begin
        is_target = (b == 37) || (b == 40) || (b == 41) || (b >= 43 && b <= 51) ||
                    (b >= 22 && b <= 30) || (b == 53) || (b == 54) || (b == 56) ||
                    (b == 57) || (b == 58);
    end endfunction
    // bucket b's metadata {slot list, fill}: beat 0 of its record in the HBM bucket-record memory
    // (records of `ORAM_REC_BEATS beats). Read after an access completes, when its writes have landed.
    function [`ORAM_Z*`SLOT_ID_W+`FILL_CNT_W-1:0] bmeta; input integer b;
        begin bmeta = u_brec.mem[b * `ORAM_REC_BEATS]; end
    endfunction
    task drain; input [`BUCKET_ID_W-1:0] x; inout integer errs;
        integer f, sl, guard, sink; begin
            while (is_target(sink_ptr)) sink_ptr = sink_ptr + 1;
            sink = sink_ptr; sink_ptr = sink_ptr + 1;
            guard = 0;
            f = bmeta(x) & ((1 << `FILL_CNT_W) - 1);
            while (f > 0 && guard < 16) begin
                sl = (bmeta(x) >> `FILL_CNT_W) & ((1 << `SLOT_ID_W) - 1);
                w_op(1'b0, sl, sink, errs);
                f = bmeta(x) & ((1 << `FILL_CNT_W) - 1);
                guard = guard + 1;
            end
            if ((bmeta(sink) & ((1 << `FILL_CNT_W) - 1)) > 0) begin
                sl = (bmeta(sink) >> `FILL_CNT_W) & ((1 << `SLOT_ID_W) - 1);
                w_op(1'b0, sl, sink, errs);
            end
            if (f != 0) $display("DRAIN: bucket %0d not empty after %0d reads (fill %0d)", x, guard, f);
        end
    endtask

    // bucket-write digest (end-to-end check against v10e: the same buckets, bit for bit, in the same order)
    wire [63:0] bwd_w, bwd_a; wire [31:0] bwd_nw, bwd_na;
    bucket_write_digest #(.DW(AXI_DW), .AW(AXI_AW)) u_bwd (.clk(clk), .awaddr(awaddr), .awlen(awlen), .awvalid(awvalid),
        .awready(awready), .wdata(wdata), .wstrb(wstrb), .wvalid(wvalid), .wready(wready),
        .dig_w(bwd_w), .dig_a(bwd_a), .n_w(bwd_nw), .n_a(bwd_na));
    task bw_report; begin
        $display("bucket writes: %0d beats digest %016h, %0d bursts address digest %016h", bwd_nw, bwd_w, bwd_na, bwd_a);
    end endtask
    // per-access timing trace for sim/worst_case.py (+timing_log=<file>)
    oram_timing_monitor u_tmon (
        .clk(clk), .state(dut.u_oram.state), .ct_cnt(dut.u_oram.ct_cnt), 
        .req_op(dut.u_oram.req_op), .found_in_bucket(dut.u_oram.found_in_bucket), .found_in_stash(dut.u_oram.found_in_stash),
        .found_pos({5'd0, dut.u_oram.found_pos}), .bkt_fill_count({4'd0, dut.u_oram.bkt_fill_count}),
        .fill({4'd0, dut.u_oram.fill}), .landed_beats({5'd0, dut.u_oram.landed_beats}),
        .enc_pos_done({4'd0, dut.u_oram.enc_pos_done}), .cr_mode(dut.u_oram.cr_mode), .cr_pos({4'd0, dut.u_oram.cr_pos}),
        .write_done(dut.u_oram.axim_write_done), .fmt_done(dut.u_oram.fmt_done_r), 
`ifdef TB_V11G_REF
        .byp(1'b0));
`else
        .byp(dut.u_oram.byp_acc));
`endif

    // one operation by an explicit client (+xpart)
    task xop; input integer c; input wr; input integer sidx; output integer viol; output integer match;
        integer b, done_seen; begin
            viol = 0; match = 1; done_seen = 0;
            @(posedge clk); while (!cready_w[c]) @(posedge clk);
            opid[c] = opid[c] + 1; rbeat[c] = 0;
            creq[c] <= 1'b1; cop[c] <= wr; caddr[c*SLOT_AW +: SLOT_AW] <= sidx << 12; cwv[c] <= wr;
            @(posedge clk);
            if (cviol[c]) viol = 1;              // the violation is flagged in the request cycle
            creq[c] <= 1'b0;
            b = 0;
            while (!done_seen && !viol && b < 200000) begin
                @(posedge clk); b = b + 1;
                if (cdone[c]) done_seen = 1;
                if (crv[c]) begin
                    if (crdata[c*AXI_DW +: AXI_DW] !== lane(lastw[sidx], rbeat[c])) match = 0;
                    rbeat[c] = rbeat[c] + 1;
                end
            end
            if (!viol && !done_seen) viol = 2;                      // no response at all
            if (!wr && done_seen && rbeat[c] != BEATS) match = 0;    // served reads must return every beat
            if (wr && done_seen) lastw[sidx] = opid[c];
            cwv[c] <= 1'b0;
        end
    endtask

    // one client-0 operation, waited for; counts evictions in this access, checks reads
    // One operation, waited for, issued by the client that owns the slot (client 0:
    // slots below N/2, client 1: the rest). Counts evictions in this access, checks reads.
    task stress_op; input wr; input integer sidx; output integer nev; inout integer errs;
        integer c; begin
            c = (NC > 1 && sidx >= `ORAM_N / 2) ? 1 : 0;      // one client: every slot is client 0's
            @(posedge clk); while (!cready_w[c]) @(posedge clk);
            opid[c] = opid[c] + 1; slot[c] = sidx; opq[c] = wr; rbeat[c] = 0; nev = 0;
            creq[c] <= 1'b1; cop[c] <= wr; caddr[c*SLOT_AW +: SLOT_AW] <= sidx << 12; cwv[c] <= wr;
            @(posedge clk); creq[c] <= 1'b0;
            while (!cdone[c]) begin
                @(posedge clk);
                if (dut.u_oram.state == 5'd18) nev = nev + 1;     // S_EVICT_DONE
                if (crv[c]) begin
                    if (crdata[c*AXI_DW +: AXI_DW] !== (lastw[sidx] < 0 ? {AXI_DW{1'b0}} : lane(lastw[sidx], rbeat[c]))) begin
                        if (errs < 4) $display("STRESS: data error slot=%0d beat=%0d expected writer op=%0d got[31:0]=%08h exp[31:0]=%08h",
                            sidx, rbeat[c], lastw[sidx], crdata[c*AXI_DW +: 32], lane(lastw[sidx], rbeat[c]) & 32'hFFFFFFFF);
                        errs = errs + 1;
                    end
                    rbeat[c] = rbeat[c] + 1;
                end
                if (cviol[c]) begin
                    $display("STRESS: ERROR access violation, client %0d slot %0d", c, sidx);
                    bw_report; $finish;
                end
                if (err_tag || err_stash || ct_ovr || slot_ovr) begin
                    $display("STRESS: ERROR tag=%0d stash=%0d ct_overrun=%0d slot_overrun=%0d", err_tag, err_stash, ct_ovr, slot_ovr);
                    bw_report; $finish;
                end
            end
            if (!wr && rbeat[c] != BEATS) errs = errs + 1;
            if (wr) lastw[sidx] = opid[c];
            cwv[c] <= 1'b0;
        end
    endtask
    initial begin
        if (!$value$plusargs("ni=%d", variant)) variant = 0;
        if (!$value$plusargs("ops=%d", nops)) nops = 12;
        if (!$value$plusargs("limit=%d", limit)) limit = 64'd40_000_000;
        if (!$value$plusargs("bp=%d", bp)) bp = 0;
        for (k = 0; k < 512; k = k + 1) lastw[k] = -1;
        for (c = 0; c < 2; c = c + 1) begin st[c] = 0; ndone[c] = 0; nerr[c] = 0; rbeat[c] = 0; opid[c] = 0; end
        rng[0] = 32'hA0000001 + variant; rng[1] = 32'hC1C1C1C1;   // client 1 never depends on the variant
        hsh = 64'hcbf29ce484222325; lsum = 0; lmin = ~64'd0; lmax = 0;
        repeat (20) @(posedge clk); rst_n <= 1;
        repeat (5) @(posedge clk); key_load <= 1; @(posedge clk); key_load <= 0;
        for (c = 0; c < NC; c = c + 1) begin                      // lease c -> client c
            @(posedge clk);
            mgmt_req <= 1; mgmt_op <= 3'd0; mgmt_lease_id <= c; mgmt_client_id <= c;
            mgmt_base <= c * ((`ORAM_N / NC) * 4096);               // client c: slots c*N/NC .. (c+1)*N/NC - 1
            // +xpart: a malicious host over-grants client 0 a lease covering client 1's slots
            mgmt_size <= ($test$plusargs("xpart") && c == 0) ? 2 * ((`ORAM_N / NC) * 4096) : ((`ORAM_N / NC) * 4096);
            @(posedge clk); mgmt_req <= 0;
            while (!mgmt_ack) @(posedge clk);
            tok[c] = ctok_out[c*32 +: 32];
            if (mgmt_error) $display("NI: lease grant %0d failed", c);
        end
        ctok = {tok[1], tok[0]}; clid = {8'd1, 8'd0};
        while (!oram_ready) @(posedge clk);
        t0 = cyc;
                if ($test$plusargs("xpart") && NC < 2) begin
            $display("XPART: SKIPPED (needs a second client; single-client build)");
            bw_report; $finish;
        end
        if ($test$plusargs("xpart")) begin : xpart
            // Partition isolation against a malicious host: client 0 holds a lease covering
            // client 1's slots, yet its request for client 1's slot 300 must be rejected.
            integer v, m;
            xop(1, 1'b1, 300, v, m);
            $display("XPART: client 1 wrote its own slot 300: %0s", v ? "VIOLATION" : "served");
            xop(0, 1'b0, 300, v, m);
            if (v == 1) $display("XPART: client 0 reading client 1's slot 300 -> rejected (access violation)");
            else if (v == 2) $display("XPART: client 0 reading client 1's slot 300 -> NO RESPONSE (test problem)");
            else   $display("XPART: client 0 reading client 1's slot 300 -> SERVED, data %0s client 1's write", m ? "EQUALS" : "differs from");
            bw_report; $finish;
        end
        if ($test$plusargs("viol1")) begin : viol1
            // A request outside its client's lease is served as a dummy access: flagged, and then the same window,
            // bucket traffic and timing as an admitted request, with zeroed data. Client 0's lease is slots 0..N-1.
            integer v, m, k, b, zero, flag, dt0, rb0, wb0, ok;
            reg [63:0] r0, w0, tq;
            ok = 1; dt0 = 0; rb0 = 0; wb0 = 0;
            xop(0, 1'b1, 7, v, m);                                  // slot 7 holds client 0's data
            for (k = 0; k < 2; k = k + 1) begin
                @(posedge clk); while (!cready_w[0]) @(posedge clk);
                rbeat[0] = 0; zero = 1; flag = 0; r0 = vrd; w0 = vwr; tq = cyc;
                creq[0] <= 1'b1; cop[0] <= 1'b0; cwv[0] <= 1'b0;
                caddr[0 +: SLOT_AW] <= ((k == 0) ? 7 : (`ORAM_N + 5)) << 12;
                @(posedge clk); if (cviol[0]) flag = 1; creq[0] <= 1'b0;
                b = 0;
                while (!cdone[0] && b < 200000) begin
                    @(posedge clk); b = b + 1;
                    if (crv[0] && crdata[0 +: AXI_DW] !== {AXI_DW{1'b0}}) zero = 0;
                end
                if (k == 0) begin
                    dt0 = cyc - tq; rb0 = vrd - r0; wb0 = vwr - w0;
                    $display("VIOL1: admitted read of slot 7: %0d cycles, %0d read / %0d write bucket beats, violation flag %0d", dt0, rb0, wb0, flag);
                    if (flag) ok = 0;
                end else begin
                    $display("VIOL1: read outside the lease: %0d cycles, %0d read / %0d write bucket beats, violation flag %0d, data %0s",
                             cyc - tq, vrd - r0, vwr - w0, flag, zero ? "all zero" : "NOT ZERO");
                    if (!flag || !zero || (cyc - tq) != dt0 || (vrd - r0) != rb0 || (vwr - w0) != wb0 || rb0 == 0) ok = 0;
                end
            end
            $display("VIOL1: %0s", ok ? "PASS: a rejected request is flagged, takes the same time and bucket traffic, and returns zeros"
                                        : "FAIL: a rejected request differs from an admitted one");
            bw_report; $finish;
        end
        if ($test$plusargs("worst")) begin : worst
            // Directed constructions of every candidate worst path (cycle model in
            // sim/worst_case.py). Remaps are steered with the debug override; reads
            // are checked against the last write, as in +stress.
            integer ns, j, k, a, errs, fwr, x;
            errs = 0; ns = 11;
            // (A) bucket holding a then b; access a at position 0 -> compaction (2 copies),
            //     with 7 more blocks waiting for that bucket -> 7 evictions.  Read, then write.
            for (fwr = 0; fwr < 2; fwr = fwr + 1) begin
                x = 40 + fwr; a = ns; ns = ns + 2;
                drain(x, errs);
                w_op(1'b1, a, x, errs); w_op(1'b1, a + 1, x, errs);
                w_op(1'b0, a, x, errs);                                // empty bucket: evict a, b
                for (j = 0; j < 7; j = j + 1) begin w_op(1'b1, ns, x, errs); ns = ns + 1; end
                w_op(fwr, a, x, errs);
            end
            // (B) k blocks waiting for an empty bucket, read one: 1 copy + min(k,8)
            //     evictions into position 0 onward -> encryption waits for the first copy.
            // Two passes on different buckets: a dummy access that happens to hit the
            // target bucket evicts the waiting blocks early, so a single pass can miss
            // an eviction count.
            for (k = 1; k <= 18; k = k + 1) begin           // two passes, buckets 43-51 and 22-30
                x = (k <= 9) ? 42 + k : 12 + k; a = ns;
                drain(x, errs);
                for (j = 0; j < (k - 1) % 9 + 1; j = j + 1) begin w_op(1'b1, ns, x, errs); ns = ns + 1; end
                w_op(1'b0, a, x, errs);
            end
            // (C) bucket holding only a; access a (bucket hit, no compaction, bucket left
            //     empty) with 7 more waiting -> 8 evictions from position 0.  Read, then write.
            for (fwr = 0; fwr < 2; fwr = fwr + 1) begin
                x = 53 + fwr; a = ns; ns = ns + 1;
                drain(x, errs);
                w_op(1'b1, a, x, errs); w_op(1'b0, a, x, errs);
                for (j = 0; j < 7; j = j + 1) begin w_op(1'b1, ns, x, errs); ns = ns + 1; end
                w_op(fwr, a, x, errs);
            end
            // (D) write to a block that is in the stash; (E) reads of never-written slots
            x = 56; a = ns; ns = ns + 1;
            w_op(1'b1, a, x, errs); w_op(1'b1, a, x, errs);
            w_op(1'b0, 250, 57, errs); w_op(1'b0, 251, 58, errs);
            prng_ovr = 0;
            $display("WORST: directed episodes done, %0d slots used, data_errors=%0d, ct_overrun=%0d, ar_max_wb=%0d ar_max_wb_h=%0d ar_max_rel_h=%0d",
                     ns - 11, errs, ct_ovr, dut.u_oram.ar_max_wb, dut.u_oram.ar_max_wb_h,
`ifdef TB_V11G_REF
                     0);
`else
                     dut.u_oram.ar_max_rel_h);
`endif
            bw_report; $finish;
        end
        if ($test$plusargs("stress")) begin : stress
            // 10 writes all remapped to bucket 37 (debug override), then reads: the
            // first read of a slot whose bucket is now 37 makes that bucket evict
            // up to Z blocks in one access -- the worst case for the CT_WB budget.
            integer s_i, emax, ecur, errs;
            errs = 0; emax = 0;
            drain(6'd37, errs);                             // every bucket starts with C slots
            prng_ovr = 37;
            for (s_i = 1; s_i <= 10; s_i = s_i + 1) begin
                stress_op(1'b1, s_i, ecur, errs); if (ecur > emax) emax = ecur;
            end
            for (s_i = 1; s_i <= 10; s_i = s_i + 1) begin
                stress_op(1'b0, s_i, ecur, errs); if (ecur > emax) emax = ecur;
            end
            prng_ovr = 0;
            for (s_i = 1; s_i <= 10; s_i = s_i + 1) begin
                stress_op(1'b0, s_i, ecur, errs); if (ecur > emax) emax = ecur;
            end
            $display("STRESS: max evictions in one access=%0d (Z=%0d)  ct_max_wb=%0d (budget %0d)  ct_overrun=%0d  data_errors=%0d",
                     emax, `ORAM_Z, dut.u_oram.ct_max_wb, `ORAM_CT_WB, ct_ovr, errs);
            bw_report; $finish;
        end
        plan(0); plan(1);
        while (ndone[MC] < nops) begin
            @(posedge clk);
            creq <= 2'b00;
            for (c = 0; c < NC; c = c + 1) begin
                if (st[c] == 0 && (c == MC || variant != 0) && cyc >= nxt[c] && cready_w[c]) begin
                    opid[c] = opid[c] + 1 + c * 100000; rqc[c] = cyc; rbeat[c] = 0; st[c] = 1;
                    creq[c] <= 1'b1; cop[c] <= opq[c];
                    caddr[c*SLOT_AW +: SLOT_AW] <= slot[c] << 12;
                    cwv[c] <= opq[c];
                end
`ifdef OLD_ARBITER
                if (st[c] == 1) creq[c] <= 1'b1;      // old arbiter: hold until done
`endif
                if (st[c] == 1 && crv[c]) begin
                    if (crdata[c*AXI_DW +: AXI_DW] !== (lastw[slot[c]] < 0 ? {AXI_DW{1'b0}} : lane(lastw[slot[c]], rbeat[c])))
                        nerr[c] = nerr[c] + 1;
                    rbeat[c] = rbeat[c] + 1;
                end
                if (st[c] == 1 && cdone[c]) begin
                    if (opq[c] == 1'b0 && rbeat[c] != BEATS) nerr[c] = nerr[c] + 1;
                    if (opq[c] == 1'b1) lastw[slot[c]] = opid[c];
                    if (c == MC) begin
                        hsh = (hsh ^ (rqc[c] - t0)) * 64'h100000001b3;
                        hsh = (hsh ^ (cyc - t0)) * 64'h100000001b3;
                        hsh = (hsh ^ {opq[c], slot[c]}) * 64'h100000001b3;
                        lsum = lsum + (cyc - rqc[c]);
                        if (cyc - rqc[c] < lmin) lmin = cyc - rqc[c];
                        if (cyc - rqc[c] > lmax) lmax = cyc - rqc[c];
                    end
                    ndone[c] = ndone[c] + 1; st[c] = 0; cwv[c] <= 1'b0; creq[c] <= 1'b0;
                    plan(c);
                end
            end
            if (err_tag || err_stash || ct_ovr || slot_ovr || (cyc - t0 > limit)) begin
                $display("NI: ERROR tag=%0d stash=%0d ct_overrun=%0d slot_overrun=%0d timeout=%0d",
                         err_tag, err_stash, ct_ovr, slot_ovr, cyc - t0 > limit);
                $display("NI: at stop: client%0d ops=%0d (waiting=%0d) client0 ops=%0d", MC, ndone[MC], st[MC], ndone[0]);
                bw_report; $finish;
            end
        end
        $display("NI: variant=%0d client%0d ops=%0d errors=%0d trace-hash=%016h latency min/mean/max=%0d/%0d/%0d | client0 ops=%0d errors=%0d | access windows=%0d",
                 variant, MC, ndone[MC], nerr[MC], hsh, lmin, lsum / ndone[MC], lmax, ndone[0], nerr[0], real_cnt);
        bw_report; $finish;
    end
    // +layout_log=<file>: every position-map write of the boot layout (before the format completes), one line
    // "slot bucket status" (status 1 = in the bucket, 2 = in the stash, waiting for that bucket); sim/layout_check.py
    // checks the placement (every slot once, the first Z of each bucket in it, the rest in the stash) and its
    // statistics (per-bucket counts against Binomial(n, 1/B)).
`ifndef ORAM_PLAIN
    integer lay_fd = 0, lay_nstash = 0;
    reg lay_open = 0, lay_said = 0;
    reg [1023:0] lay_fn;
    initial if ($value$plusargs("layout_log=%s", lay_fn)) begin lay_fd = $fopen(lay_fn, "w"); lay_open = 1; end
    always @(posedge clk) begin
        if (lay_open && !dut.u_oram.fmt_done_r && dut.u_oram.pm_wr_en) begin
            $fdisplay(lay_fd, "%0d %0d %0d", dut.u_oram.pm_wr_addr >> 12, dut.u_oram.pm_wr_bucket, dut.u_oram.pm_wr_status);
            if (dut.u_oram.pm_wr_status == 2'b10) lay_nstash = lay_nstash + 1;
        end
        if (lay_open && dut.u_oram.fmt_done_r && !lay_said) begin
            $fdisplay(lay_fd, "# done: %0d slots in the stash at boot", lay_nstash); $fflush(lay_fd); lay_said = 1;
            $display("LAYOUT: boot placement put %0d blocks in the stash", lay_nstash);
        end
    end
`endif
`ifndef ORAM_PLAIN
    // Boot report (v11b fixed-time boot): the controller must become ready a fixed number of cycles after the layout
    // starts, whatever the placement. Printed for every boot: the cycles from the layout's start to ready, the budget,
    // when the placement was done, how many slots it put in the stash, and the worst cycles of one slot's placement
    // in its bucket and in the stash (these calibrate ORAM_LAY_TB / ORAM_LAY_TS0).
    // +rng_seed=<hex>: start the position generator from another state (testbench only; at the format's start, before
    // any draw), so that two runs place the slots differently with the same n.
    reg [63:0] rng_seed; reg seed_req = 0, seeded = 0, lay_was = 0, rdy_was = 0; integer lay_s0 = 0, bt_cyc = 0;
    initial if ($value$plusargs("rng_seed=%h", rng_seed)) seed_req = 1;
    always @(posedge clk) begin
        bt_cyc <= bt_cyc + 1;
        if (seed_req && !seeded && dut.u_oram.st_init_go) begin dut.u_oram.u_rng.x <= rng_seed; seeded = 1; end
        lay_was <= dut.u_oram.lay_run;
        if (dut.u_oram.lay_run && !lay_was) lay_s0 = bt_cyc;
        rdy_was <= dut.u_oram.fmt_done_r;
        if (dut.u_oram.fmt_done_r && !rdy_was)
            $display("BOOT: ready %0d cycles after the layout started (budget %0d + settle); placement done after %0d (slack %0d); %0d slots placed in the stash; worst slot %0d cycles in its bucket, %0d in the stash",
                     bt_cyc - lay_s0, dut.u_oram.lay_budget, dut.u_oram.lay_end, dut.u_oram.lay_budget - dut.u_oram.lay_end, dut.u_oram.lay_nst, dut.u_oram.lay_max_b, dut.u_oram.lay_max_s);
        if (lay_was && !dut.u_oram.lay_run && !dut.u_oram.fmt_done_r)
            $display("BOOT: halted %0d cycles after the layout started (budget %0d): %0s; placement %0s", bt_cyc - lay_s0, dut.u_oram.lay_budget,
                     dut.u_oram.err_stash_overflow ? "stash overflow" : "timing overrun", (dut.u_oram.state == 5'd29) ? "not done" : "done");
    end
`endif
endmodule
