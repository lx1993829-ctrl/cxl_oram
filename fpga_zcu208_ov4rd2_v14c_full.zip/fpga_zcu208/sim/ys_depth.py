#!/usr/bin/env python3
"""depth.py <netlist.json> [top_n]: per-endpoint logic depth of a Yosys synth_xilinx netlist (flattened).
Depth in LUT-level units: LUT = 1, MUXF7/F8/F9 = 0.3, CARRY8 entered from a LUT/S/DI = 1, CI->CO/O = 0.15 per CARRY8.
Path starts: flip-flop outputs, black-box / RAM outputs, module inputs. Endpoints: flip-flop inputs (D, CE, R/S),
black-box and RAM inputs, module outputs. Prints the deepest endpoints grouped by register / port name, with the
names of the registers on the deepest path to each."""
import json, sys, re, collections

nl = json.load(open(sys.argv[1]))
TOP = int(sys.argv[2]) if len(sys.argv) > 2 else 60
mods = nl['modules']
top = [m for m in mods if mods[m].get('attributes', {}).get('top')]
top = top[0] if top else 'doma_kernel'
M = mods[top]

# bit -> name (prefer visible names)
bname = {}
for n, d in M['netnames'].items():
    hid = d.get('hide_name', 0)
    for i, b in enumerate(d['bits']):
        if isinstance(b, str): continue
        nm = n if len(d['bits']) == 1 else f"{n}[{i}]"
        if b not in bname or (bname[b][1] and not hid):
            bname[b] = (nm, hid)

FF = re.compile(r'^FD[CPRS]E$|^FD[RS]E_1$|^FD')
drv = {}        # bit -> (cell, port)
loads = collections.defaultdict(list)
cells = M['cells']
for cn, c in cells.items():
    t = c['type']
    for p, bits in c['connections'].items():
        dirn = c.get('port_directions', {}).get(p)
        for b in bits:
            if isinstance(b, str): continue
            if dirn == 'output': drv[b] = (cn, p)
            else: loads[b].append((cn, p))

def is_comb(t):
    return t.startswith('LUT') or t.startswith('MUXF') or t in ('CARRY8', 'CARRY4', 'INV', 'BUF', 'VCC', 'GND', 'DSP48E2') or t.startswith('RAM32M') or t.startswith('RAM64M')

arr = {}          # bit -> (depth, pred bit)
sys.setrecursionlimit(1000000)

def cell_out_depth(cn, port, bitidx):
    c = cells[cn]; t = c['type']
    ins = []
    for p, bits in c['connections'].items():
        if c['port_directions'].get(p) == 'output': continue
        for b in bits:
            if isinstance(b, str): continue
            ins.append((p, b))
    best = (0.0, None)
    if t.startswith('LUT'):
        for p, b in ins:
            d = bit_depth(b)[0] + 1.0
            if d > best[0]: best = (d, b)
    elif t.startswith('MUXF'):
        for p, b in ins:
            d = bit_depth(b)[0] + 0.3
            if d > best[0]: best = (d, b)
    elif t in ('CARRY8', 'CARRY4'):
        # output bit k depends on S[0..k], DI[0..k], CI; approximate: CI -> +0.15, S/DI -> +1 (first entry)
        k = bitidx
        for p, b in ins:
            idx = c['connections'][p].index(b) if b in c['connections'][p] else 0
            if p in ('CI', 'CI_TOP'):
                d = bit_depth(b)[0] + 0.15
            elif p in ('S', 'DI'):
                if idx > k: continue
                d = bit_depth(b)[0] + 1.0
            else:
                d = bit_depth(b)[0] + 1.0
            if d > best[0]: best = (d, b)
    elif t in ('INV', 'BUF'):
        for p, b in ins:
            d = bit_depth(b)[0]
            if d > best[0]: best = (d, b)
    elif t.startswith('RAM32M') or t.startswith('RAM64M'):
        # LUT RAM: the read data follows the read address (ADDRA..ADDRG) through one LUT level
        for p, b in ins:
            if p.startswith('ADDR') and p != 'ADDRH':
                d = bit_depth(b)[0] + 1.0
                if d > best[0]: best = (d, b)
    elif t == 'DSP48E2':
        for p, b in ins:
            if p in ('A', 'B', 'C', 'D'):
                d = bit_depth(b)[0] + 3.0
                if d > best[0]: best = (d, b)
    return best

def bit_depth(b):
    if b in arr: return arr[b]
    if b not in drv:
        arr[b] = (0.0, None); return arr[b]
    cn, p = drv[b]
    t = cells[cn]['type']
    if not is_comb(t):
        arr[b] = (0.0, None); return arr[b]
    arr[b] = (0.0, None)   # guard against loops
    idx = cells[cn]['connections'][p].index(b)
    arr[b] = cell_out_depth(cn, p, idx)
    return arr[b]

def nm(b):
    return bname.get(b, (f"bit{b}", 1))[0]

def start_name(b):
    # walk back along the deepest path to its start
    path = []
    while b is not None:
        path.append(b)
        b = arr.get(b, (0, None))[1]
    return path

# endpoints
ends = []
for cn, c in cells.items():
    t = c['type']
    if is_comb(t) and not (t.startswith('RAM') or t == 'DSP48E2'): continue
    for p, bits in c['connections'].items():
        if c['port_directions'].get(p) == 'output': continue
        for i, b in enumerate(bits):
            if isinstance(b, str): continue
            d, _ = bit_depth(b)
            if FF.match(t):
                qb = c['connections'].get('Q', [None])[0]
                ename = nm(qb) if qb is not None else cn
                ends.append((d, f"{ename} .{p}", b))
            else:
                ends.append((d, f"[{t}] {cn.split('.')[-1] if not cn.startswith('$') else cn}.{p}[{i}]", b))
for p, d in M['ports'].items():
    if d['direction'] == 'output':
        for i, b in enumerate(d['bits']):
            if isinstance(b, str): continue
            ends.append((bit_depth(b)[0], f"<out> {p}[{i}]", b))

def clean(s):
    return re.sub(r'\[\d+\]', '[]', s)

grp = {}
for d, e, b in ends:
    k = clean(e)
    if k not in grp or grp[k][0] < d: grp[k] = (d, e, b)
cnt = collections.Counter(int(d) for d, e, b in ends)
print(f"top {top}: {len(cells)} cells, {len(ends)} endpoint bits; max depth {max(d for d,_,_ in ends):.2f}")
print("depth histogram (endpoint bits):", ' '.join(f"{k}:{cnt[k]}" for k in sorted(cnt)))
for d, e, b in sorted(grp.values(), key=lambda x: -x[0])[:TOP]:
    path = start_name(b)
    named = [nm(x) for x in path if not bname.get(x, ('', 1))[1]]
    st = nm(path[-1])
    print(f"{d:6.2f}  {e}\n        from {st}\n        via {' <- '.join(dict.fromkeys(clean(x) for x in named[1:8]))}")

# full path dump for endpoints matching argv[3..]
for pat in sys.argv[3:]:
    hits = [x for x in ends if pat in x[1]]
    if not hits: print("no endpoint", pat); continue
    d, e, b = max(hits, key=lambda x: x[0])
    print(f"\n== path to {e} ({d:.2f})")
    for x in start_name(b):
        dd = arr.get(x, (0, None))[0]
        c = drv.get(x)
        t = cells[c[0]]['type'] if c else 'start'
        print(f"   {dd:5.2f} {t:9s} {nm(x)}")
