#!/bin/bash
# run_rd2_netlist.sh -- overlap step 2: the read unit (rtl/axi_rd2.v, two bucket reads in flight) against its Yosys gate
# netlist, in lock step (tb_rd2.v): every output equal every cycle, and every read's beats delivered in order to its own
# context with its own bucket's data. Random commands, a random in-order AXI read slave. Exit 0 only if all pass.
set -u
cd "$(dirname "$0")"
RTL=$(cd "${1:-../rtl}" && pwd); O=build/rd2net; mkdir -p $O; rc=0
command -v yosys > /dev/null || { echo "NETLIST rd2: SKIPPED (yosys not on PATH)"; exit 3; }
cat > $O/synth.ys <<YS
read_verilog -sv -DSYNTHESIS -DORAM_BLOCK_BEATS=128 -DORAM_C=7 -I $RTL $RTL/axi_master.v $RTL/axi_rd2.v
hierarchy -top axi_rd2
proc; flatten; opt -full; memory -nomap; opt -full; techmap; opt -fast
abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX
opt_clean
rename axi_rd2 axi_rd2_net
write_verilog -noattr $O/axi_rd2_netlist.v
YS
yosys -q -l $O/synth.log $O/synth.ys > /dev/null 2>&1 || { echo "NETLIST rd2: synthesis failed ($O/synth.log)"; exit 2; }
verilator --binary --timing -j 0 -O1 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-UNOPTFLAT \
    -I$RTL -DORAM_BLOCK_BEATS=128 -DORAM_C=7 --top-module tb_rd2 tb_rd2.v $RTL/axi_rd2.v $RTL/axi_master.v $O/axi_rd2_netlist.v \
    -Mdir $O/obj -o V > $O/build.log 2>&1 || { echo "NETLIST rd2: testbench build failed ($O/build.log)"; exit 2; }
for sd in 1 7 99 1234; do
    ./$O/obj/V +cyc=400000 +seed=$sd +verilator+seed+$sd > $O/run_$sd.log 2>&1
    if grep -q "RD2: ALL CHECKS PASSED" $O/run_$sd.log; then echo "NETLIST rd2: PASS  seed $sd: $(grep tb_rd2: $O/run_$sd.log | sed 's/^tb_rd2: //')"
    else echo "NETLIST rd2: FAIL  seed $sd ($O/run_$sd.log)"; rc=1; fi
done
exit $rc
