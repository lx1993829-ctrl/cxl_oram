#!/usr/bin/env python3
"""check_fixwb.py [--wbf N] base.csv fixwb.csv   (tb_doma_kernel +phase_log=<file> of the same run on two builds)

Option A against v14d1, access by access:
  visible  every access's start (testbench cycle), its bucket read issue, its off-package write-back start (and the
           write's completion), its result release and its end: identical in both builds; the memory's own times
           (first beat, arrival) too, since the memory sees the same requests;
  option A every on-package access of the Option A build issues its write-back at exactly t_arr + WBF (default 440;
           the log shows the command register one cycle later, as for off-package writes)
           and streams it hold-free (first to last W beat = 1,024 beats, no held beat).
Exit 0 only if every check passes."""
import csv, sys
args = sys.argv[1:]; WBF = 440
if args and args[0] == '--wbf': WBF = int(args[1]); args = args[2:]
base, fix = ([{k: int(v) for k, v in r.items()} for r in csv.DictReader(open(f))] for f in args)
ok = True
def bad(msg):
    global ok; ok = False; print("FAIL", msg)
if len(base) != len(fix): bad(f"{len(base)} accesses in v14d1, {len(fix)} with Option A")
VIS = ['start', 'hbm', 'op', 'lookup', 'rd_issue', 'first_beat', 't_arr', 'release', 'end']
nv = non = noff = 0; worst_w = 0
for a, b in zip(base, fix):
    for k in VIS:
        if a[k] != b[k]:
            bad(f"access {a['acc']}: {k} {a[k]} (v14d1) vs {b[k]} (Option A)"); break
    else:
        nv += 1
    if a['hbm'] == 0:
        noff += 1
        for k in ('wb_issue', 'wb_done'):
            if a[k] != b[k]: bad(f"access {a['acc']} (off package): {k} {a[k]} vs {b[k]}")
    else:
        non += 1
        # (the log records the write command one cycle after its gate opens, as for every off-package write: AR_WB 1,785
        #  is logged at t_arr + 1,786)
        if b['wb_issue'] - b['t_arr'] != WBF + 1:
            bad(f"access {a['acc']} (on package): write-back issued {b['wb_issue'] - b['t_arr'] - 1} cycles after the arrival, not {WBF}")
        if b['w_held'] != 0 or b['w_last'] - b['w_first'] + 1 != 1024:
            bad(f"access {a['acc']} (on package): write held {b['w_held']} cycles, W span {b['w_last'] - b['w_first'] + 1}")
        worst_w = max(worst_w, b['w_first'] - b['t_arr'])
    if not ok and nv < 0: break
if ok:
    print(f"PASS {args[1]}: {len(base)} accesses ({noff} off package, {non} on package): start, read issue, off-package "
          f"write-back start and end, release and end identical to v14d1; every on-package write-back issued at "
          f"t_arr + {WBF}, first beat at most {worst_w} after the arrival, 1,024 beats with no hold")
sys.exit(0 if ok else 1)
