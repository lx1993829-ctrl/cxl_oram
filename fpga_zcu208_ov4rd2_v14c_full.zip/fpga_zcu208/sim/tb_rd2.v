`timescale 1ns / 1ps
// tb_rd2.v -- axi_rd2 (two bucket reads in flight) against its synthesized netlist, in lock step.
// Random read commands (whenever free, random gaps), a random AXI read slave (random ARREADY, in-order bursts after a
// random latency, random RVALID gaps). Checks every cycle that the RTL and the netlist outputs are equal, and that the
// RTL delivers every read's beats in order to its own context, each beat's data that of its own bucket and beat.
// +cyc=N +seed=S. Prints "RD2: ALL CHECKS PASSED".
`include "oram_params.vh"
module tb_rd2;
    localparam DW = `AXI_DATA_W, AW = `AXI_ADDR_W, BW = `BUCKET_ID_W, SA = `SCR_AW, NB = `BEATS_PER_BKT;
    reg clk = 0, rst_n = 0; always #1 clk = ~clk;
    integer seed = 1, ncyc = 100000, cyc = 0, errs = 0, nrd = 0, nbeat = 0, nboth = 0;
    reg cmd_read = 0; reg [BW-1:0] cmd_bucket = 0; reg [1:0] cmd_ctx = 0;
    // slave
    wire [AW-1:0] araddr_a, araddr_b; wire [7:0] arlen_a, arlen_b; wire arvalid_a, arvalid_b, rready_a, rready_b;
    reg arready = 0; reg [DW-1:0] rdata = 0; reg rlast = 0, rvalid = 0;
    wire free_a, free_b, ba_a, ba_b, bl_a, bl_b, rv_a, rv_b, rd_a, rd_b;
    wire [DW-1:0] dd_a, dd_b; wire [SA-1:0] ba2_a, ba2_b; wire [1:0] rc_a, rc_b, dc_a, dc_b, ac_a, ac_b, rx_a, rx_b;
    wire [`AXI_ID_W-1:0] id_a, id_b; wire [2:0] sz_a, sz_b; wire [1:0] bu_a, bu_b;
    axi_rd2 u_a (.clk(clk), .rst_n(rst_n), .cmd_read(cmd_read), .cmd_bucket(cmd_bucket), .cmd_ctx(cmd_ctx),
        .free(free_a), .busy_any(ba_a), .busy_all(bl_a), .rdata_data(dd_a), .rdata_valid(rv_a), .rdata_beat_addr(ba2_a),
        .rdata_ctx(rc_a), .read_done(rd_a), .done_ctx(dc_a), .ar_ctx(ac_a), .r_ctx(rx_a),
        .m_axi_arid(id_a), .m_axi_araddr(araddr_a), .m_axi_arlen(arlen_a), .m_axi_arsize(sz_a), .m_axi_arburst(bu_a),
        .m_axi_arvalid(arvalid_a), .m_axi_arready(arready), .m_axi_rid({`AXI_ID_W{1'b0}}), .m_axi_rdata(rdata),
        .m_axi_rresp(2'b00), .m_axi_rlast(rlast), .m_axi_rvalid(rvalid), .m_axi_rready(rready_a));
    axi_rd2_net u_b (.clk(clk), .rst_n(rst_n), .cmd_read(cmd_read), .cmd_bucket(cmd_bucket), .cmd_ctx(cmd_ctx),
        .free(free_b), .busy_any(ba_b), .busy_all(bl_b), .rdata_data(dd_b), .rdata_valid(rv_b), .rdata_beat_addr(ba2_b),
        .rdata_ctx(rc_b), .read_done(rd_b), .done_ctx(dc_b), .ar_ctx(ac_b), .r_ctx(rx_b),
        .m_axi_arid(id_b), .m_axi_araddr(araddr_b), .m_axi_arlen(arlen_b), .m_axi_arsize(sz_b), .m_axi_arburst(bu_b),
        .m_axi_arvalid(arvalid_b), .m_axi_arready(arready), .m_axi_rid({`AXI_ID_W{1'b0}}), .m_axi_rdata(rdata),
        .m_axi_rresp(2'b00), .m_axi_rlast(rlast), .m_axi_rvalid(rvalid), .m_axi_rready(rready_b));
    // the data of a beat: a function of its byte address
    function [DW-1:0] pat; input [AW-1:0] a; integer k; begin
        for (k = 0; k < DW / 64; k = k + 1) pat[k*64 +: 64] = {a, 32'hA5A50000 + k} ^ {32'h0, a[31:0]} * 64'h9E3779B97F4A7C15; end endfunction
    // slave state: accepted bursts in order
    reg [AW-1:0] q_a [0:63]; reg [7:0] q_l [0:63]; integer q_t [0:63]; integer qw = 0, qr = 0, bi = 0;
    // expected per context: bucket, next beat
    reg [BW-1:0] e_b [0:3]; integer e_n [0:3]; reg e_on [0:3];
    integer lat, gap;
    initial begin
        if ($value$plusargs("seed=%d", seed)) begin end
        if ($value$plusargs("cyc=%d", ncyc)) begin end
        lat = 20 + $urandom(seed) % 200;
        repeat (5) @(posedge clk); rst_n = 1;
    end
    // outputs equal, every cycle
    always @(negedge clk) if (rst_n) begin
        if ({free_a, ba_a, bl_a, rv_a, rd_a, arvalid_a, rready_a} !== {free_b, ba_b, bl_b, rv_b, rd_b, arvalid_b, rready_b} ||
            (arvalid_a && ({araddr_a, arlen_a, ac_a, id_a, sz_a, bu_a} !== {araddr_b, arlen_b, ac_b, id_b, sz_b, bu_b})) ||
            (rv_a && ({dd_a, ba2_a, rc_a} !== {dd_b, ba2_b, rc_b})) || (rd_a && dc_a !== dc_b) || (rvalid && rx_a !== rx_b)) begin
            errs = errs + 1; if (errs < 10) $display("FAIL cycle %0d: RTL and netlist outputs differ", cyc); end
    end
    always @(posedge clk) if (rst_n) begin : drive
        integer k; reg [1:0] c;
        cyc <= cyc + 1; if (bl_a) nboth = nboth + 1;
        // commands: when the unit is free, sometimes, with a context not in use
        cmd_read <= 1'b0;
        if (!cmd_read && free_a && ($urandom % 100) < 30) begin
            c = $urandom % 4;
            if (!e_on[c]) begin
                cmd_read <= 1'b1; cmd_ctx <= c; cmd_bucket <= $urandom % (1 << (BW > 16 ? 16 : BW));
                e_on[c] <= 1'b1; e_n[c] <= 0;
            end
        end
        if (cmd_read) e_b[cmd_ctx] <= cmd_bucket;
        // AR
        arready <= ($urandom % 100) < 60;
        if (arvalid_a && arready) begin q_a[qw % 64] = araddr_a; q_l[qw % 64] = arlen_a; q_t[qw % 64] = cyc + lat + ($urandom % 3 == 0 ? $urandom % 400 : 0); qw = qw + 1; end
        // R: one burst at a time, in the order accepted, each beat after the burst's latency, random gaps
        if (rvalid && rready_a) begin if (rlast) begin qr = qr + 1; bi = 0; end else bi = bi + 1; end
        if (!rvalid || rready_a) begin
            if (qr < qw && cyc >= q_t[qr % 64] && ($urandom % 100) >= 20) begin
                rvalid <= 1'b1; rdata <= pat(q_a[qr % 64] + bi * (DW / 8)); rlast <= (bi == q_l[qr % 64]);
            end else rvalid <= 1'b0;
        end
        // the RTL's landed beats: in order, to their own context, with their own bucket's data
        if (rv_a) begin
            nbeat = nbeat + 1;
            if (!e_on[rc_a] || ba2_a !== e_n[rc_a][SA-1:0] ||
                dd_a !== pat(`DDR_BASE + e_b[rc_a] * `BUCKET_BYTES + e_n[rc_a] * (DW / 8))) begin
                errs = errs + 1; if (errs < 10) $display("FAIL cycle %0d: beat for context %0d (beat %0d, expected %0d) wrong", cyc, rc_a, ba2_a, e_n[rc_a]); end
            e_n[rc_a] <= e_n[rc_a] + 1;
        end
        if (rd_a) begin
            if (e_n[dc_a] + (rv_a && rc_a == dc_a ? 1 : 0) != NB) begin errs = errs + 1; if (errs < 10) $display("FAIL cycle %0d: context %0d done after %0d beats", cyc, dc_a, e_n[dc_a]); end
            e_on[dc_a] <= 1'b0; nrd = nrd + 1;
        end
        if (cyc == ncyc) begin
            $display("tb_rd2: %0d cycles, %0d reads, %0d beats, %0d cycles with two reads in flight, %0d errors", cyc, nrd, nbeat, nboth, errs);
            if (errs == 0 && nrd > 10 && nboth > 0) $display("RD2: ALL CHECKS PASSED"); else $display("RD2: FAILED");
            $finish;
        end
    end
    initial begin : init integer k; for (k = 0; k < 4; k = k + 1) begin e_on[k] = 0; e_n[k] = 0; e_b[k] = 0; end end
endmodule
