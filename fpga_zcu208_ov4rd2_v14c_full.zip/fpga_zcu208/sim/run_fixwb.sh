#!/bin/bash
# run_fixwb.sh -- Option A (ORAM_ONPKG_FIXWB, docs/fixwb_option_a.md) against v14d1. 4 KB blocks, lambda 7, arrival
# scheduling, 4,096 records. Builds v14d1 and Option A (production configuration), and Option A's traced and debug
# variants, from the same RTL, then runs the same cases on both and checks:
#   1. every run: all responses correct, eviction scoreboard 0 wrong, no halt;
#   2. visible times, access by access (check_fixwb.py): start, bucket read issue, off-package write-back start and
#      completion, result release and end identical to v14d1; and every on-package write-back of the Option A
#      build issued at exactly t_arr + 440 and streamed hold-free (1,024 beats, no held beat);
#   3. the testbench's visible hashes (bucket-port timing, folded off-package shape, on-package release/end) and the
#      bucket-write digests identical to v14d1;
#   4. Option A enforces its schedule: an eviction copy late for the write (a stash slower than the card's), or
#      decisions not done by t_arr + 440 (stash reads slowed from one access on), stops Option A by a fail-stop halt
#      reporting on-package deadline (1), never a wrong answer; v14d1 absorbs both;
#   5. the traced and debug variants of Option A run clean (debug: 0 deadline misses recorded).
# Usage: bash run_fixwb.sh [jobs]   (default nproc). Logs: build/fixwb/. About 1 hour on 8 cores.
#        REUSE=1 bash run_fixwb.sh   keeps existing builds and finished runs (after an interruption)
set -u
cd "$(dirname "$0")"
RTL=$(cd "${RTL_DIR:-../rtl}" && pwd); J=${1:-$(nproc)}
O=build/fixwb; mkdir -p $O
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
pass=0; fail=0
ok() { echo "PASS  $*"; pass=$((pass+1)); }
bad() { echo "FAIL  $*"; fail=$((fail+1)); }
build() {   # build <dir> [defines]   (one at a time: three parallel C++ builds can exhaust a laptop's memory)
    local d=$1; shift
    [ "${REUSE:-0}" = 1 ] && [ -x $O/$d/V ] && { echo "reused $d"; return 0; }
    verilator --binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -I$RTL \
      -DORAM_BLOCK_BEATS=128 -DORAM_C=7 -DORAM_N=4096 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -Wno-BLKANDNBLK "$@" \
      --top-module tb_doma_kernel tb_doma_kernel.v oram_timing_monitor.v axi_mem_model.v $SRCS $RTL/doma_kernel.v \
      -Mdir $O/$d -o V > $O/build_$d.log 2>&1 && echo "built $d" || { echo "BUILD FAILED $d ($O/build_$d.log)"; exit 1; }
}
echo "== building"
build base; build fix -DORAM_ONPKG_FIXWB; build fixtr -DORAM_ONPKG_FIXWB -DORAM_PHASE_TRACE
build fixdbg -DORAM_ONPKG_FIXWB -DORAM_PHASE_TRACE -DORAM_ONPKG_DEBUG
H="+hb=0 +host_lat=401 +host_wlat=98 +preload +cmds2=4"
CS="+stash_gap=40 +stash_pcs=390 +stash_idblk=1 +stash_lat=120 +stash_slow_pct=0"     # card-like stash
: > $O/jobs.txt
for b in base fix; do
    cat >> $O/jobs.txt <<EOF
$b p0 $H +hbm_pct=20 +cmds=1500 +put_pct=0 +seed=11
$b p50 $H +hbm_pct=20 +cmds=1500 +put_pct=50 +seed=11
$b p100 $H +hbm_pct=20 +cmds=1500 +put_pct=100 +seed=11
$b h0 $H +hbm_pct=0 +cmds=1000 +seed=23
$b h50 $H +hbm_pct=50 +cmds=1500 +seed=23
$b h100 +hb=0 +preload +cmds2=4 +hbm_pct=100 +cmds=1500 +seed=37
$b cs20 $H $CS +hbm_pct=20 +cmds=1500 +seed=5
$b cs50 $H $CS +hbm_pct=50 +cmds=1500 +seed=23
$b sk $H +hbm_pct=50 +cmds=600 +same_key=600 +put_pct=50 +seed=7
$b slowcp $H +hbm_pct=50 +cmds=1500 +seed=29 +stash_gap=56 +stash_lat=120 +stash_slow_pct=0
$b latedec $H +hbm_pct=50 +cmds=1500 +seed=31 +stash_slow=900 +stash_slow_at=4300
EOF
done
echo "fixtr t50 $H +hbm_pct=50 +cmds=1000 +seed=23" >> $O/jobs.txt
echo "fixdbg d50 $H $CS +hbm_pct=50 +cmds=1000 +seed=23" >> $O/jobs.txt
echo "== running $(wc -l < $O/jobs.txt) runs, $J at a time"
O=$O REUSE=${REUSE:-0} xargs -P $J -L 1 bash -c 'b=$0; t=$1; shift 1; [ "$REUSE" = 1 ] && grep -q "Verilog \$finish" $O/${b}_$t.log 2>/dev/null && { echo "  kept $b $t"; exit 0; }; timeout 14400 ./$O/$b/V "$@" +phase_log=$O/pl_${b}_$t.csv > $O/${b}_$t.log 2>&1; echo "  done $b $t"' < $O/jobs.txt
echo "== checks"
clean() { grep -q "ALL CHECKS PASSED" $1 && grep -q "eviction scoreboard: .* 0 wrong" $1 && ! grep -q "DOMA HALT" $1; }
vis() { grep -E "^[a-z0-9]+: (bucket-port timing hash|folded off-package shape hash|off-package access shape hash|on-package release/end hash|traffic record)|^bucket writes:|^\*\*\* DOMA" $1; }
for t in p0 p50 p100 h0 h50 h100 cs20 cs50 sk; do
    clean $O/base_$t.log && clean $O/fix_$t.log && ok "$t: v14d1 and Option A: all responses correct, scoreboard 0 wrong, no halt" \
        || bad "$t: a run failed ($O/base_$t.log, $O/fix_$t.log)"
    out=$(python3 check_fixwb.py $O/pl_base_$t.csv $O/pl_fix_$t.csv 2>&1)
    [ $? = 0 ] && ok "$t: $(echo "$out" | sed 's/^PASS [^:]*: //')" || { bad "$t: visible times differ"; echo "$out" | head -5 | sed 's/^/      /'; }
    [ -n "$(vis $O/base_$t.log)" ] && [ "$(vis $O/base_$t.log)" = "$(vis $O/fix_$t.log)" ] \
        && ok "$t: visible hashes and bucket-write digests identical to v14d1" || bad "$t: visible hashes differ"
done
# 4. enforcement: a late copy and late decisions stop Option A (deadline 1), never a wrong answer; v14d1 absorbs both
for t in slowcp latedec; do
    clean $O/base_$t.log && ok "$t: v14d1 absorbs it (no halt, all correct)" || bad "$t: v14d1 run failed ($O/base_$t.log)"
    l=$O/fix_$t.log
    # wrong data = a mismatch before the halt, or a wrong evicted beat (after a halt every command fails by design)
    if sed -n '1,/DOMA HALT/p' $l | grep -qE "data mismatch|not zero" || ! grep -q "eviction scoreboard: .* 0 wrong" $l; then bad "$t: Option A returned wrong data ($l)"
    elif grep -q "on-package deadline (1)" $l; then ok "$t: Option A stops by a fail-stop halt, on-package deadline (1): $(grep -m1 '^run1: halt record' $l | sed 's/.*halt record: //' | cut -c1-120)"
    else bad "$t: Option A did not stop on deadline (1) ($l)"; fi
done
clean $O/fixtr_t50.log && ok "traced Option A: all responses correct, no halt" || bad "traced Option A ($O/fixtr_t50.log)"
clean $O/fixdbg_d50.log && ok "debug Option A: all responses correct, no halt$(grep -m1 -oE 'deadline \(1\) [^,;]*' $O/fixdbg_d50.log | sed 's/^/, /')" \
    || bad "debug Option A ($O/fixdbg_d50.log)"
echo "== $pass passed, $fail failed"
[ $fail = 0 ]
