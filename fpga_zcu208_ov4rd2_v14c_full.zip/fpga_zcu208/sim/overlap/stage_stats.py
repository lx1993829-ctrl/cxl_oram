#!/usr/bin/env python3
"""Per-access stage times from tb_doma_kernel +phase_log CSVs (overlap study): min / median / max of each stage."""
import csv, sys, statistics as st
def load(fn):
    return [{k: int(v) for k, v in r.items()} for r in csv.DictReader(open(fn))]
STAGES_OFF = [("lookup", None, "lookup"), ("read latency", "rd_issue", "first_beat"), ("read transfer", "first_beat", "t_arr"),
              ("tag after arrival", "t_arr", "dec_tag"), ("to scan", "dec_tag", "scan"), ("decisions", "scan", "ea_start"),
              ("encrypt", "enc_start", "enc_tag"), ("wait to write", "enc_tag", "wb_issue"), ("write", "wb_issue", "wb_done"),
              ("to release", "wb_done", "release"), ("release to end", "release", "end"),
              ("stash open->ready", "st_open", "st_ready"), ("stash commit->quiet", "st_commit", "st_quiet"),
              ("copies (first..last beat)", "copy_first", "copy_last")]
STAGES_ON = [("lookup", None, "lookup"), ("read latency", "rd_issue", "first_beat"), ("read transfer", "first_beat", "t_arr"),
             ("to scan", "t_arr", "scan"), ("decisions", "scan", "ea_start"), ("write", "wb_issue", "wb_done"),
             ("to release", "wb_done", "release"), ("release to end", "release", "end"),
             ("stash open->ready", "st_open", "st_ready"), ("stash commit->quiet", "st_commit", "st_quiet"),
             ("copies (first..last beat)", "copy_first", "copy_last")]
ABS = ["rd_issue", "t_arr", "ea_start", "wb_issue", "wb_done", "release", "end", "st_commit", "st_quiet"]
for fn in sys.argv[1:]:
    rows = load(fn)
    for hbm, name, stages in ((0, "off package", STAGES_OFF), (1, "on package", STAGES_ON)):
        rs = [r for r in rows if r["hbm"] == hbm]
        if not rs: continue
        print(f"{fn}: {name}, {len(rs)} accesses")
        for lab, a, b in stages:
            v = [r[b] - (r[a] if a else 0) for r in rs if r[b] >= 0 and (a is None or r[a] >= 0)]
            if v: print(f"   {lab:28s} min {min(v):6d}  median {int(st.median(v)):6d}  max {max(v):6d}   ({len(v)})")
        print("   absolute (from the access start): " + ", ".join(
            f"{k} {min(r[k] for r in rs if r[k] >= 0)}..{max(r[k] for r in rs if r[k] >= 0)}" for k in ABS if any(r[k] >= 0 for r in rs)))
        sb = [r["st_r_beats"] for r in rs]; wb = [r["st_w_beats"] for r in rs]
        print(f"   stash beats per access: read median {int(st.median(sb))} max {max(sb)}, write median {int(st.median(wb))} max {max(wb)}")
