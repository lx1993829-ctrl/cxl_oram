#!/usr/bin/env python3
"""Fixed-schedule model of overlapped DOMA accesses, 4 KB blocks, two GCM cores (one decrypts, one encrypts).

Every access follows a fixed template for its public class (off or on package): each stage holds one shared resource
over a fixed interval, measured from the access start s. The intervals are padded worst cases (the stage maxima of
tb_doma_kernel +phase_log runs, sim/overlap/stage_stats.py), times (1 + margin). The next access starts at the earliest
s at which none of its intervals overlaps an earlier access's interval on the same resource. That s depends only on
the class sequence (public), so the schedule is request-independent by construction. The stash is held by an access from
its (deferrable) open to its commit's acknowledgement; its open is placed as late as its decisions allow.

Prints, per on-package share: the mean spacing (cycles per request), KQPS at 300 MHz, the accesses in flight (max),
scratch buffers needed, the binding resources, and the spacing for each class pair."""
import random, argparse, collections

def templates(m, so=331, sq=152, dd=0):
    f = lambda x: int(round(x * (1 + m)))
    # off package (host bucket): measured maxima, 4 KB, lambda 7, host read latency 404
    tag = 1701 + f(122)                                   # decryption tag after the last beat
    dec_start = tag + 9                                    # decisions start
    dec_end = dec_start + f(293)
    enc_end = dec_end + f(1170)                            # encryption core (waits for copies inside its slot)
    w_end = enc_end + 3 + f(1027)                          # host write streams after encryption (no AR_WB wait)
    off = dict(cls="off",
               res={"meta": (0, f(165)), "hostR": (267 + 404, 1701), "dec": (671, tag),
                    "fsm": (dec_start, dec_end), "enc": (dec_end, enc_end), "hostW": (enc_end + 3, w_end),
                    "scratch": (671, w_end)},
               stash_need=dec_start, stash_open=f(so), commit=dec_end, quiet=f(sq),
               end=w_end + f(221) + 131)
    # on package (HBM bucket)
    d0 = 1353 + 2; d1 = d0 + f(293); w1 = d1 + 1 + f(1154)
    on = dict(cls="on",
              res={"meta": (0, f(165)), "hbmR": (267 + 56, 1353), "fsm": (d0, d1), "hbmW": (d1 + 1, w1),
                   "scratch": (323, w1)},
              stash_need=d0, stash_open=f(so), commit=d1, quiet=f(sq), end=w1 + f(221) + 131)
    if dd:                                                 # stash data on its own port: busy from the open for dd cycles
        for t in (off, on): t["res"]["stashD"] = (t["stash_need"] - t["stash_open"], t["stash_need"] - t["stash_open"] + f(dd))
    return {"off": off, "on": on}

def run(T, pct, n, seed, kmax=99):
    rnd = random.Random(seed)
    cls = ["on" if rnd.random() < pct / 100 else "off" for _ in range(n)]
    busy = collections.defaultdict(list)                   # resource -> [(start, end)] of earlier accesses
    stash_free = 0                                         # the stash: free from the previous access's quiet
    starts, ends, bind = [], [], collections.Counter()
    s = 0
    for j, c in enumerate(cls):
        t = T[c]
        s = starts[-1] + 1 if starts else 0
        while True:                                        # the earliest s with no overlap on any resource
            need, why = s, None
            for r, (a, b) in t["res"].items():
                if r == "scratch": continue                # buffers: counted, not shared (one per access in flight)
                for (pa, pb) in busy[r][-6:]:
                    if s + a < pb and s + b > pa and pb - a > need: need, why = pb - a, r
            # stash: this access's open (stash_open long) must end by its decisions, and may start only when free
            if stash_free + t["stash_open"] > s + t["stash_need"] and stash_free + t["stash_open"] - t["stash_need"] > need:
                need, why = stash_free + t["stash_open"] - t["stash_need"], "stash"
            if len(ends) >= kmax and ends[-kmax] > need: need, why = ends[-kmax], "k"
            if need == s: break
            s = need; bind[why] += 1
        for r, (a, b) in t["res"].items(): busy[r].append((s + a, s + b))
        stash_free = s + t["commit"] + t["quiet"]
        starts.append(s); ends.append(s + t["end"])
    # steady state over the second half
    h = n // 2
    mean_p = (starts[-1] - starts[h]) / (n - 1 - h)
    inflight = max(sum(1 for k in range(max(0, i - 8), i + 1) if ends[k] > starts[i]) for i in range(h, n))
    bufs = max(sum(1 for k in range(max(0, i - 8), i + 1) if starts[k] + T[cls[k]]["res"]["scratch"][1] > starts[i]) for i in range(h, n))
    return mean_p, inflight, bufs, bind, cls, starts

def pair_spacing(T):
    out = {}
    for a in ("off", "on"):
        for b in ("off", "on"):
            seq_T = {"x": T[a], "y": T[b]}
            # two accesses only
            busy = {r: iv for r, iv in T[a]["res"].items()}
            s, why = 1, None
            while True:
                need, w = s, None
                for r, (x0, x1) in T[b]["res"].items():
                    if r == "scratch" or r not in busy: continue
                    pa, pb = busy[r]
                    if s + x0 < pb and s + x1 > pa and pb - x0 > need: need, w = pb - x0, r
                sf = T[a]["commit"] + T[a]["quiet"]
                if sf + T[b]["stash_open"] - T[b]["stash_need"] > need: need, w = sf + T[b]["stash_open"] - T[b]["stash_need"], "stash"
                if need == s: break
                s, why = need, w
            out[(a, b)] = (s, why)
    return out

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--margin", type=float, nargs="+", default=[0.0, 0.10])
    ap.add_argument("--n", type=int, default=20000); ap.add_argument("--kmax", type=int, nargs="+", default=[2, 3, 4, 5, 99])
    ap.add_argument("--stash", default="fast", choices=["fast", "slow", "meta044", "meta100"]); a = ap.parse_args()
    today = {0: 5000, 20: 4863, 100: 4003}
    for m in a.margin:
        T = {"fast": lambda: templates(m), "slow": lambda: templates(m, so=628, sq=1669),
             # metadata on its own port: state serialized only to the commit's acknowledgement; window data
             # (worst 1,165 beats per open) on the data port at 0.44 or 1.0 beats per cycle
             "meta044": lambda: templates(m, so=628, sq=152, dd=1165 / 0.44),
             "meta100": lambda: templates(m, so=331, sq=152, dd=1165 / 1.0)}[a.stash]()
        print(f"== stage budgets = measured maxima x {1 + m:.2f}")
        for (x, y), (p, w) in pair_spacing(T).items(): print(f"   pair {x:>3s} -> {y:<3s}: spacing {p:5d}  (bound by {w})")
        print(f"   latency of one access: off {T['off']['end']}, on {T['on']['end']} (today ~4,866 / 3,869 incl. padding)")
        for pct in (0, 20, 50, 100):
            for km in a.kmax:
                p, k, bufs, bind, _, _ = run(T, pct, a.n, 1, km)
                ref = today.get(pct)
                print(f"   {pct:3d}% on package, at most {km if km < 99 else 'any'} in flight: {p:6.0f} cycles per request ({300e6 / p / 1e3:6.1f} KQPS)"
                      f"{f', {ref / p:.2f}x today' if ref else ''}; in flight {k}, scratch buffers {bufs}; bound by "
                      + ", ".join(f"{r} {c}" for r, c in bind.most_common(3)))
