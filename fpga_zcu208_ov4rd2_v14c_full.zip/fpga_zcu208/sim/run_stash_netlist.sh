#!/bin/bash
# run_stash_netlist.sh -- v14d1: tb_stash against a synthesized stash_hbm netlist instead of its RTL.
#   bash run_stash_netlist.sh vivado [rtl dir]   # Vivado OOC synthesis (vitis/stash_netlist.tcl) + xsim, UNISIM
#                                                # primitives: the block-RAM mapping the card gets (needs Vivado)
#   bash run_stash_netlist.sh yosys  [rtl dir]   # Yosys gate netlist (memories kept as arrays) + Verilator: catches
#                                                # RTL whose synthesized logic differs from its simulation
# Prints NETLIST <tool>: PASS / FAIL per test, exit 0 only if every test passed. ORAM_N (default 4096) sets both
# the synthesized design and the testbench. Tests: the default mix, same-bucket remaps, slow read data (window data
# landing late), and a small pool (free-list reuse); each checks every block's data after HBM round trips, the
# requested block (staging slot 0) included.
set -u
cd "$(dirname "$0")"
TOOL=${1:-yosys}; RTL=$(cd "${2:-../rtl}" && pwd); N=${ORAM_N:-4096}; EXT=${STASH_DEF:-}
OUT=build/netlist_$TOOL${EXT:+_B}; mkdir -p $OUT
TESTS=("+acc=2000" "+acc=2000 +same=50" "+acc=2000 +rgap=60 +rlat=200" "+acc=3000 +poolpct=40")
rc=0
if [ "$TOOL" = vivado ]; then
    command -v vivado > /dev/null && command -v xvlog > /dev/null || { echo "NETLIST vivado: SKIPPED (vivado/xvlog not on PATH)"; exit 3; }
    ( cd $OUT && vivado -mode batch -nojournal -nolog -source ../../../vitis/stash_netlist.tcl -tclargs "$RTL" . $N $EXT > synth.log 2>&1 ) \
        || { echo "NETLIST vivado: synthesis failed ($OUT/synth.log)"; exit 2; }
    ( cd $OUT && xvlog -sv -d ORAM_BLOCK_BEATS=128 -d ORAM_C=7 -d ORAM_N=$N -d STASH_NETLIST ${EXT:+-d $EXT} -i "$RTL" \
          ../../tb_stash.v ../../axi_mem_model.v stash_hbm_funcsim.v "$XILINX_VIVADO/data/verilog/src/glbl.v" > xvlog.log 2>&1 \
      && xelab -L unisims_ver -L unimacro_ver -L secureip -timescale 1ns/1ps tb_stash glbl -s stash_net > xelab.log 2>&1 ) \
        || { echo "NETLIST vivado: xsim elaboration failed ($OUT/xvlog.log, $OUT/xelab.log)"; exit 2; }
    i=0; for t in "${TESTS[@]}"; do i=$((i+1))
        args=""; for a in $t; do args="$args -testplusarg ${a#+}"; done
        ( cd $OUT && xsim stash_net -R $args > run_$i.log 2>&1 )
        if grep -q "STASH_HBM: ALL CHECKS PASSED" $OUT/run_$i.log; then echo "NETLIST vivado: PASS  $t"
        else echo "NETLIST vivado: FAIL  $t ($OUT/run_$i.log: $(grep -m1 -E 'FAIL' $OUT/run_$i.log))"; rc=1; fi
    done
else
    command -v yosys > /dev/null || { echo "NETLIST yosys: SKIPPED (yosys not on PATH)"; exit 3; }
    cat > $OUT/synth.ys <<YS
read_verilog -sv -DSYNTHESIS -DORAM_BLOCK_BEATS=128 -DORAM_C=7 -DORAM_N=$N ${EXT:+-D$EXT} -I $RTL $RTL/stash_hbm.v
hierarchy -top stash_hbm
proc; flatten; opt -full; memory -nomap; opt -full; techmap; opt -fast
abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX
opt_clean
write_verilog -noattr $OUT/stash_hbm_netlist.v
YS
    yosys -q -l $OUT/synth.log $OUT/synth.ys > /dev/null 2>&1 || { echo "NETLIST yosys: synthesis failed ($OUT/synth.log)"; exit 2; }
    verilator --binary --timing -j 0 -O1 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-UNOPTFLAT \
        -I"$RTL" -DORAM_BLOCK_BEATS=128 -DORAM_C=7 -DORAM_N=$N -DSTASH_NETLIST ${EXT:+-D$EXT} --top-module tb_stash \
        tb_stash.v axi_mem_model.v $OUT/stash_hbm_netlist.v -Mdir $OUT/obj -o V > $OUT/build.log 2>&1 \
        || { echo "NETLIST yosys: testbench build failed ($OUT/build.log)"; exit 2; }
    i=0; for t in "${TESTS[@]}"; do i=$((i+1))
        ./$OUT/obj/V $t > $OUT/run_$i.log 2>&1
        if grep -q "STASH_HBM: ALL CHECKS PASSED" $OUT/run_$i.log; then echo "NETLIST yosys: PASS  $t"
        else echo "NETLIST yosys: FAIL  $t ($OUT/run_$i.log: $(grep -m1 -E 'FAIL' $OUT/run_$i.log))"; rc=1; fi
    done
fi
exit $rc
