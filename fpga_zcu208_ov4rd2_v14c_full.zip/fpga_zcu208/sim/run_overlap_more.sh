#!/bin/bash
# run_overlap_more.sh -- the longer overlap checks before a card build (after run_overlap.sh). 4 KB blocks, lambda 7.
#   bash run_overlap_more.sh [jobs]      (default jobs = nproc). Logs: build/ovm/. Roughly 1-2 hours on 8 cores.
# Groups (each prints PASS / FAIL lines; exit 0 only if all pass):
#   1. scratch_buf netlist check: RTL and Yosys netlist (Vivado: bash run_scratch_netlist.sh vivado on the server)
#   2. host_doma's own sequence through the XRT mock, 4,096 records, 20% on package, NMAX 2,097,152: step 1 and step 2
#   3. 4,096-record kernel runs (same-bucket cases as rare as on the card), several seeds, 0 / 20 / 50% on package,
#      step 1 and step 2: all responses correct, scoreboard 0 wrong, no halt
#   4. step 2 with a stash slower than it can keep up with at P = 1,500 (the card's design A rate): it must stop by a
#      fail-stop halt, never return a wrong response or copy a wrong beat
set -u
cd "$(dirname "$0")"
RTL=$(cd "${RTL_DIR:-../rtl}" && pwd); J=${1:-$(nproc)}   # absolute: group 2 builds from sim/xrt_mock
O=build/ovm; mkdir -p $O
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
pass=0; fail=0
ok() { echo "PASS  $*"; pass=$((pass+1)); }
bad() { echo "FAIL  $*"; fail=$((fail+1)); }

echo "== 1. scratch_buf netlist check"
for t in rtl yosys; do
    out=$(bash run_scratch_netlist.sh $t "$RTL" 2>&1); rc=$?
    [ $rc = 0 ] && ok "scratch_buf $t: $(echo "$out" | grep -c PASS) random runs of 200,000 cycles" || { bad "scratch_buf $t"; echo "$out" | sed 's/^/      /'; }
done

echo "== 2. host_doma's sequence in the XRT mock (4,096 records, 20% on package; about 15 min each, in parallel)"
for v in 2 4; do
    ( d="-DORAM_OVERLAP2"; [ $v = 4 ] && d="-DORAM_OVERLAP2 -DORAM_OVERLAP4"
      cd xrt_mock && rm -rf obj_ov$v hsov$v && LAMBDA=7 ORAM_N=2097152 OUT=$PWD/obj_ov$v EXTRA_DEFS="$d" RTL=$RTL bash build_model.sh > ../$O/hostseq_$v.build.log 2>&1 \
      && OUT=$PWD/obj_ov$v bash build_hosts.sh >> ../$O/hostseq_$v.build.log 2>&1 && mkdir -p hsov$v && mv host_*_sim hsov$v/ \
      && DOMA_LAMBDA=7 DOMA_PAGES_HBM=1 DOMA_N=4096 DOMA_HBM_PCT=20 ./hsov$v/host_doma_sim doma_hw.xclbin > ../$O/hostseq_$v.log 2>&1 ) &
done
wait
for v in 2 4; do
    grep -q "ALL RESPONSES CORRECT" $O/hostseq_$v.log \
        && ok "host_doma sequence, step $([ $v = 2 ] && echo 1 || echo 2): $(grep -oE 'query: [0-9]+ commands' $O/hostseq_$v.log), all responses correct; $(grep -oE 'device: [0-9]+ cycles total' $O/hostseq_$v.log)" \
        || bad "host_doma sequence, step $([ $v = 2 ] && echo 1 || echo 2) ($O/hostseq_$v.log, $O/hostseq_$v.build.log)"
done

echo "== 3/4. 4,096-record kernel runs and the slow-stash fail-stop check"
build() {   # build <dir> [defines]
    local d=$1; shift
    verilator --binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -I$RTL \
      -DORAM_BLOCK_BEATS=128 -DORAM_C=7 -DORAM_N=4096 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -Wno-BLKANDNBLK "$@" \
      --top-module tb_doma_kernel tb_doma_kernel.v oram_timing_monitor.v axi_mem_model.v $SRCS $RTL/doma_kernel.v \
      -Mdir $O/$d -o V > $O/build_$d.log 2>&1 && echo "built $d" || echo "BUILD FAILED $d ($O/build_$d.log)"
}
build k2 -DORAM_OVERLAP2 & build k4 -DORAM_OVERLAP2 -DORAM_OVERLAP4 & wait
H="+hb=0 +host_lat=401 +host_wlat=98"
: > $O/jobs.txt
for k in k2 k4; do for s in 11 23 37; do for pct in 0 20 50; do
    echo "$k s${s}_$pct $H +hbm_pct=$pct +preload +cmds=1500 +cmds2=4 +seed=$s" >> $O/jobs.txt
done; done; done
# the card's design A stash at 2M (0.44 beats per cycle): step 2 at P = 1,500 cannot keep up and must halt cleanly
echo "k4 slow56 $H +hbm_pct=20 +preload +cmds=1500 +cmds2=4 +seed=5 +stash_gap=56 +stash_lat=120" >> $O/jobs.txt
echo "k4 slow78 $H +hbm_pct=20 +preload +cmds=1500 +cmds2=4 +seed=6 +stash_gap=78 +stash_lat=240" >> $O/jobs.txt
O=$O xargs -P $J -L 1 bash -c 'b=$0; t=$1; shift 1; timeout 14400 ./$O/$b/V "$@" > $O/${b}_$t.log 2>&1; echo "  done $b $t"' < $O/jobs.txt
while read -r b t rest; do
    l=$O/${b}_$t.log
    case $t in
    slow*)
        # a halt is allowed (and expected); a wrong answer before it is not: no data mismatch, no wrong eviction beat,
        # every failed command reports the halt status (0x8)
        if grep -qE "data mismatch|not zero" $l || ! grep -q "eviction scoreboard: .* 0 wrong" $l; then bad "$b $t: wrong data under a too-slow stash ($l)"
        elif grep -q "DOMA HALT" $l; then ok "$b $t: halted cleanly (fail-stop), no wrong response or beat before it"
        else ok "$b $t: no halt, all responses correct (the stash kept up)"; fi ;;
    *)
        grep -q "ALL CHECKS PASSED" $l && grep -q "eviction scoreboard: .* 0 wrong" $l \
            && ok "$b $t: all responses correct, scoreboard 0 wrong ($(grep -E '^run1: size=' $l | sed -E 's/.*size=([0-9]+) .*device total=([0-9]+).*/\2 \1/' | awk '{printf "%.0f cycles per command", $1/$2}'))" \
            || bad "$b $t ($l)" ;;
    esac
done < $O/jobs.txt
echo "== $pass passed, $fail failed"
[ $fail = 0 ]
