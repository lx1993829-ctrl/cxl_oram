#!/usr/bin/env python3
"""Design A (v14d) at card scale: decisions wait for metadata only; the bucket write streams behind the copies.
For every recorded open (windows of >= 5 entries, the only ones that can be late) under the single-ID blocking model:
  meta ready vs the arrival (deadline (1) path), and the write's hold: copy k must have landed by
  WB start + k * 128 (fill 0, the earliest any copy is needed). Release gate = WB start + 1,029 + hold."""
import pickle, sys, argparse, collections
from stash_port_model import sim_open
ap = argparse.ArgumentParser(); ap.add_argument('pkl', nargs='+'); ap.add_argument('--f', type=float, default=300)
ap.add_argument('--L', type=float, nargs='+', default=[150, 300]); ap.add_argument('--wb0', type=float, default=400)
a = ap.parse_args()
for p in a.pkl:
    lay, recs = pickle.load(open(p, 'rb'))
    for L in a.L:
        for ph in ('preload', 'mix'):
            arr = 1314 * 300 / a.f
            worst_m = -1e9; worst_hold = 0; nhold = 0; n = 0; worst_old = -1e9; late_old = 0
            for r in recs:
                if r[0] != ph: continue
                n += 1
                mr, alld, dl = sim_open(r[4], r[5], a.f, L, True, 'E')
                worst_m = max(worst_m, mr - arr)
                wb = arr + max(a.wb0, mr - arr + 300)          # decisions ~300 after ready if ready were late
                e = r[2]
                hold = 0
                for k in range(min(e, len(dl))):
                    hold = max(hold, dl[k] - (wb + k * 128))
                if hold > 0: nhold += 1
                worst_hold = max(worst_hold, hold)
                o, _, _ = sim_open(r[4], r[5], a.f, L, True, 'v14c')
                worst_old = max(worst_old, o - arr)
            print('%s n=%d %-7s L=%3.0f ns: %6d opens (>=5 entries) | v14c stash ready worst %+5.0f vs arrival | '
                  'v14d metadata ready worst %+5.0f; write held by a copy in %d opens, worst %4.0f -> release gate <= %.0f (AR_REL_H 2384)' % (
                p.split('_')[1].split('.')[0], lay['n'], ph, L, n, worst_old, worst_m, nhold, worst_hold, a.wb0 + 1029 + worst_hold))
