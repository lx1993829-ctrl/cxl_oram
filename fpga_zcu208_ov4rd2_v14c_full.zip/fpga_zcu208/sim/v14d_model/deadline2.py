#!/usr/bin/env python3
"""Design A's deadline (2) at card scale, at the card's effective stash rate.
1. Fit: the single-ID blocking model's latency L (ns) such that v14c's worst write-back start (stash ready - arrival
   + 304, the card's decisions after a late stash at 1M: 1,098 - 794) matches the card at 2M (preload 1,745, MIX 1,490).
2. Design A on the same opens: decisions from the metadata; copies k = 0..7 run one after another once their block has
   landed (c_k = max(land_k, c_{k-1}) + 128); the write sends position k once its copy is done and position k-1 is
   written (w_k = max(w_{k-1}, c_k) + 128, from the write-back start). Release gate = w_7 + 5 (the sim's 1,029 = 8 x 128 + 5).
   Write-back start = arrival + max(floor, metadata ready - arrival + 304); floor 299 (simulation) and 923 (where the
   card's write-back-start tail began at 1M: a conservative floor)."""
import pickle, collections
from stash_port_model import sim_open
DEC = 304; ARR = 1314
def v14c_wb(r, L): return sim_open(r[4], r[5], 300, L, True, 'v14c')[0] - ARR + DEC
def a_release(r, L, floor):
    mr, alld, dl = sim_open(r[4], r[5], 300, L, True, 'E')
    wb = max(floor, mr - ARR + DEC)          # relative to the arrival
    e = r[2]; c = -1e9; w = wb
    holds = 0
    for k in range(e):
        land = dl[k] - ARR if k < len(dl) else -1e9
        c = max(land, c) + 128 if k else max(land, wb - 400) + 128   # the first copy may start during the decisions
        w = max(w, c) + 128 if True else 0
    for k in range(e, 8): w = w + 128          # positions without a copy
    return wb, w + 5, mr - ARR
recs = {n: pickle.load(open('traffic_%d.pkl' % n, 'rb'))[1] for n in (1048576, 2097152)}
print('fit of L to the card (v14c worst write-back start after the arrival):')
for L in (200, 225, 250, 275, 300):
    out = []
    for n, ph, card in ((2097152, 'preload', 1745), (2097152, 'mix', 1490), (1048576, 'mix', 1098)):
        out.append('%s %s %.0f (card %d)' % ('2M' if n > 2e6 else '1M', ph, max(v14c_wb(r, L) for r in recs[n] if r[0] == ph), card))
    print('  L = %3d ns: %s' % (L, '; '.join(out)))
for L in (250, 275, 500):
    for floor in (299, 923):
        for ph in ('preload', 'mix'):
            rs = [r for r in recs[2097152] if r[0] == ph and r[2] == 8]
            res = [a_release(r, L, floor) for r in rs]
            print('2M %-7s L=%d ns floor %d: %4d accesses with 8 copies | A: metadata ready worst %+5.0f, write-back start worst %4.0f, '
                  'release gate worst %4.0f (AR_REL_H 2384; with 10%% + 74: %.0f) | v14c write-back start worst %.0f' % (
                ph, L, floor, len(rs), max(x[2] for x in res), max(x[0] for x in res), max(x[1] for x in res),
                max(x[1] for x in res) * 1.1 + 74, max(v14c_wb(r, L) for r in rs)))
