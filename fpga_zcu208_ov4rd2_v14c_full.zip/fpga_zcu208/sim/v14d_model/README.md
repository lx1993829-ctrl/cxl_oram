# v14d stash models (card scale)

Python 3, standard library only. Run from this folder.

| Script | What it does | Time |
|---|---|---|
| `stash_traffic.py --n 2097152 --out traffic_2097152.pkl` | Replays the stash unit (windows, chains, fresh-first pool, LIFO free list) on host_phases' command streams (preload of every key, then MIX) at card scale; prints the window and eviction distributions, the data reads per pseudo-channel and the channel switches per open; keeps every open with >= 5 window entries | ~1 min (2M) |
| `stash_port_model.py traffic_*.pkl --L 250` | One single-ID AXI port, same-ID reads held at a channel change until the earlier reads return (PG276), 14.4 GB/s per channel: stash ready per window size for v14c (`--design v14c`) or v14d (`--design E`) | ~1 min |
| `design_e_check.py traffic_*.pkl --L 150 300 600` | v14d: metadata ready vs the arrival, and the write's hold behind the copies (fill 0, the earliest any copy is needed) | ~2 min |
| `deadline2.py` | v14d's deadline (2) at 2M for accesses with 8 copies, and the fit of L to the card's v14c numbers | ~3 min |

`traffic_1048576.txt` and `traffic_2097152.txt` are the outputs quoted in docs/v14d_report.md.
