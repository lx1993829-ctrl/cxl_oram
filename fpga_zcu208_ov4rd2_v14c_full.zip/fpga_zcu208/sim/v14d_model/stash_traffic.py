#!/usr/bin/env python3
"""Flat-Bucket stash traffic model at card scale (1M-2M records, 4 KB, lambda 7, Z 8, W 9).

Replays the stash unit's per-access structure (rtl/stash_hbm.v: windows of W entries, chains with new entries at the
head, the chain step at commit, fresh-then-LIFO free-list pool allocation) on the same command streams as host_phases
(preload: every key once in order, then MIX: uniform keys), and records, for every access, the stash port's read
sequence in issue order with real byte addresses in the XRT buffer. Prints the address pattern per pseudo-channel and
writes per-access read lists for the timing model (stash_port_model.py)."""
import math, random, sys, argparse, pickle, collections

def ln_mgf_A(t, Bk, n):
    p = 1.0 / Bk; lr = math.log1p(-p) + t
    if abs(lr) < 1e-15: return math.log(p * n + 1.0)
    if lr > 0:
        lrn = n * lr
        if lrn > 700: return math.inf
        return math.log(p * math.expm1(lrn) / math.expm1(lr) + math.exp(lrn))
    rn = math.exp(n * lr)
    return math.log(p * (1 - rn) / (-math.expm1(lr)) + rn)
def stash_xR(Bk, n, lg):
    best = math.inf
    for i in range(1, 400):
        u = i * 0.005; v = ln_mgf_A(math.expm1(u) / Bk, Bk, n)
        if not math.isfinite(v): break
        best = min(best, (Bk * v + lg) / u)
    return best
def stash_xO(Bk, n, Z, lg):
    best = math.inf; p = 1.0 / Bk; lp = math.log(p); lq = math.log1p(-p)
    lt0 = [math.lgamma(n + 1) - math.lgamma(k + 1.0) - math.lgamma(n - k + 1) + k * lp + (n - k) * lq for k in range(160)]
    for i in range(1, 400):
        u = i * 0.01; lt = [lt0[k] + u * max(0, k - Z) for k in range(160)]; mx = max(lt)
        s = sum(math.exp(x - mx) for x in lt)
        best = min(best, (Bk * (mx + math.log(s)) + lg) / u)
    return best
def stash_bound(n, lam, Z):
    Bk = math.ceil(n / lam); G = 64 * math.log(2.0)
    return min(stash_xR(Bk, n, G - math.log(f)) + stash_xO(Bk, n, Z, G - math.log(1 - f)) for f in (0.1, 0.3, 0.5, 0.7, 0.9))

PC = 512 << 20          # bytes per HBM pseudo-channel (U55C: 16 GB / 32)

def run(n, lam=7, Z=8, preload=True, mix=None, seed=1, pool=None, keep=None):
    rnd = random.Random(seed)
    n = ((n + lam - 1) // lam) * lam; B = n // lam; W = Z + 1
    P = pool or min(n, math.ceil(stash_bound(n, lam, Z)) + 1)
    PW = max(1, math.ceil(math.log2(n)))
    HB = math.ceil((W + 1) * (PW + 1) / 256)
    meta_base = ((B * 32 * HB + 4095) // 4096) * 4096
    data_base = meta_base + ((P * 16 + 4095) // 4096) * 4096
    head = lambda b: b * 32 * HB
    meta = lambda p: meta_base + (p >> 1) * 32
    data = lambda p: data_base + p * 4096
    cnt = [0] * B; pos = [0] * n; pidx = [-1] * n
    win = {}; chain = {}                  # bucket -> list (window: index 0 first; chain: head at the END)
    slot_of = {}                          # pool index -> block
    fresh = 0; free = []                  # free list: LIFO (head = end)
    used = 0; peak = 0; maxfresh = 0
    def alloc():
        nonlocal fresh
        if fresh < P: fresh += 1; return fresh - 1
        if not free: raise RuntimeError("pool exhausted")
        return free.pop()
    def link(x, bt):                      # into bt's window if room, else onto the head of bt's chain
        w = win.setdefault(bt, [])
        if len(w) < W: w.append(pidx[x])
        else: chain.setdefault(bt, []).append(pidx[x])
    # boot: independent uniform placement, the excess of a full bucket waits in the stash
    for x in range(n):
        b = rnd.randrange(B); pos[x] = b
        if cnt[b] < Z: cnt[b] += 1
        else:
            pidx[x] = alloc(); slot_of[pidx[x]] = x; used += 1; link(x, b)
    boot_used = used
    recs = []                             # per access: (phase, nwin, nevict, [(addr, beats), ...] level1, level2)
    stats = collections.defaultdict(collections.Counter)
    def access(x, phase):
        nonlocal used, peak, maxfresh
        b = pos[x]; bt = rnd.randrange(B); same = (b == bt)
        st = pidx[x] >= 0
        w = win.get(b, []); c = chain.get(b, [])
        # ---- the open's reads, in the RTL's issue order ----
        l1 = [(head(b), HB)]
        if not same: l1.append((head(bt), HB))
        if st: l1 += [(meta(pidx[x]), 1), (data(pidx[x]), 128)]
        if free: l1.append((meta(free[-1]), 1))          # the free head's next (approximation: whenever the list is non-empty)
        l2 = []
        nwin = 0
        for p in w:
            if st and p == pidx[x]: continue
            l2 += [(meta(p), 1), (data(p), 128)]; nwin += 1
        if c: l2.append((meta(c[-1]), 1))
        # ---- the access ----
        if st:
            p = pidx[x]
            if not same:
                if p in w: w.remove(p)
                else: c.remove(p)
                link(x, bt)
        else:
            if cnt[b] > 0 and rnd.random() < cnt[b] / max(1, cnt[b]):  # the block is in its bucket (every non-stashed one is)
                cnt[b] -= 1
                pidx[x] = alloc(); slot_of[pidx[x]] = x; used += 1; link(x, bt)
        pos[x] = bt
        w = win.get(b, [])
        e = min(Z - cnt[b], len(w)); ev = w[:e]; del w[:e]
        for p in ev:
            y = slot_of.pop(p); pidx[y] = -1; free.append(p); used -= 1
        cnt[b] += e
        c = chain.get(b, [])
        if c and len(w) < W: w.append(c.pop())          # the chain step (approximation: always the head read at open)
        if w == [] and b in win: del win[b]
        if c == [] and b in chain: del chain[b]
        peak = max(peak, used); maxfresh = max(maxfresh, fresh)
        stats[phase]['acc'] += 1; stats[phase]['win%d' % nwin] += 1; stats[phase]['ev%d' % e] += 1
        seq = l1 + l2
        for ad, bl in seq:
            if bl == 128: stats[phase]['dpc%d' % ((ad) // PC)] += 1
        k = sum(1 for i in range(1, len(seq)) if seq[i][0] // PC != seq[i - 1][0] // PC)
        stats[phase]['ch%d' % k] += 1
        if nwin >= 7: stats[phase]['bch%d' % k] += 1
        if keep is None or keep(phase, nwin): recs.append((phase, nwin, e, st, l1, l2))
    if preload:
        for x in range(n): access(x, 'preload')
    for i in range(mix or 0): access(rnd.randrange(n), 'mix')
    lay = dict(n=n, B=B, P=P, HB=HB, meta_base=meta_base, data_base=data_base, boot_used=boot_used, peak=peak,
               maxfresh=maxfresh, used_end=used, total=data_base + P * 4096)
    return lay, stats, recs

def pc_of(a, base=0): return (base + a) // PC

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--n', type=int, default=1048576); ap.add_argument('--mix', type=int, default=None)
    ap.add_argument('--seed', type=int, default=1); ap.add_argument('--out', default=None)
    a = ap.parse_args()
    lay, stats, recs = run(a.n, mix=a.mix if a.mix is not None else a.n, seed=a.seed, keep=lambda ph, nw: nw >= 5)
    print('layout:', {k: (v if k in ('n', 'B', 'P', 'HB', 'boot_used', 'peak', 'maxfresh', 'used_end') else '%.1f MiB' % (v / 2**20)) for k, v in lay.items()})
    lastdata = lay['data_base'] + lay['maxfresh'] * 4096
    print('pool entries ever used: %d of %d; their data spans %.1f MiB -> %.1f MiB (PC 12 + %d .. %d)' % (
        lay['maxfresh'], lay['P'], lay['data_base'] / 2**20, lastdata / 2**20, pc_of(lay['data_base']), pc_of(lastdata - 1)))
    for ph, s in stats.items():
        acc = s['acc']
        print('%-8s %d accesses; window entries read: %s' % (ph, acc, ' '.join('%d:%.3f%%' % (k, 100 * s['win%d' % k] / acc) for k in range(10))))
        print('%-8s evictions: %s' % ('', ' '.join('%d:%.3f%%' % (k, 100 * s['ev%d' % k] / acc) for k in range(9))))
        dpc = {k: s['dpc%d' % k] for k in range(8) if s['dpc%d' % k]}; tot = sum(dpc.values()) or 1
        print('%-8s data reads by pseudo-channel (12 + k): %s' % ('', ' '.join('%d:%.1f%%' % (k, 100 * v / tot) for k, v in sorted(dpc.items()))))
        ch = {k: s['ch%d' % k] for k in range(40) if s['ch%d' % k]}; bg = {k: s['bch%d' % k] for k in range(40) if s['bch%d' % k]}
        print('%-8s PC changes per open: all %s' % ('', ' '.join('%d:%d' % kv for kv in sorted(ch.items()))))
        print('%-8s                      >= 7 window entries %s' % ('', ' '.join('%d:%d' % kv for kv in sorted(bg.items()))))
    if a.out:
        with open(a.out, 'wb') as f: pickle.dump((lay, recs), f)
