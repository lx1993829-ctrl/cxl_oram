#!/usr/bin/env python3
"""Timing model of the stash port on the U55C, driven by stash_traffic.py's per-access read lists (card-scale addresses).

The port: one AXI master, 256-bit, one beat per kernel cycle, a single AXI ID (the RTL drives no ID), reads in order.
HBM side, following PG276 ("transactions with the same ID are blocked on a channel level and execute in the order in
which they are received"; each memory controller "processes commands independently") and AMD's RAMA measurements:
  block  a read to a pseudo-channel other than the one the port's outstanding reads go to is held until they have all
         returned (same-ID ordering across channels); off: reads pipeline freely (one channel, or RAMA/ID per channel)
  L      read latency, address to first beat, in ns (the card's idle 4 KB-burst latency is ~1 us at 300 MHz cycles... fit)
  cap    per-pseudo-channel peak 14.4 GB/s: a burst's beats never come faster than that
Designs:
  v14c   ready = every read landed; level 2 (window meta, data, ...) issues when head(b) lands; per entry meta then data
  E      metadata first: ready = metadata + the requested block landed; window data follows, in eviction order; the
         copies need entry k's data only when the bucket write reaches it
Times are in kernel cycles at f MHz from the open's first read."""
import pickle, sys, argparse, math, collections
PC = 512 << 20

def sim_open(l1, l2, f, L, block, design, cap=14.4):
    T = 1000.0 / f                       # ns per cycle
    lat = L / T                          # cycles
    def dur(beats): return max(beats, beats * 32 / cap / T)
    t_issue = 0.0; out = []              # outstanding: (pc, done)
    last_done = 0.0; cur_pc = None; res = {}
    def issue(reads, t0, spacing):
        nonlocal t_issue, last_done, cur_pc
        times = []
        t = max(t_issue, t0)
        for i, (a, b, tag) in enumerate(reads):
            pc = a // PC
            if block and cur_pc is not None and pc != cur_pc and last_done > t: t = last_done      # wait until all returned
            first = max(t + lat, last_done + 1)
            done = first + dur(b) - 1
            last_done = done; cur_pc = pc
            times.append((tag, done))
            t += spacing[i] if isinstance(spacing, list) else spacing
        t_issue = t
        return times
    if design == 'v14c':
        r1 = [(a, b, 'l1') for a, b in l1]
        t1 = issue(r1, 0, 1)
        head_landed = t1[0][1] + 2
        r2 = [(a, b, 'm' if b == 1 else 'd') for a, b in l2]
        sp = [1 if b == 1 else 2 for a, b in l2]           # prep + meta + data: 3 cycles per entry
        t2 = issue(r2, head_landed, sp)
        ready = max(t for _, t in t1 + t2) + 2
        dl = [t for tag, t in t2 if tag == 'd']
        return ready, ready, dl
    else:   # E: level 1 metadata, then the requested block; level 2 metadata, then window data
        m1 = [(a, b, 'm1') for a, b in l1 if b != 128]; d1 = [(a, b, 'rq') for a, b in l1 if b == 128]
        t1 = issue(m1 + d1, 0, 1)
        head_landed = t1[0][1] + 2
        m2 = [(a, b, 'm2') for a, b in l2 if b != 128]; d2 = [(a, b, 'd') for a, b in l2 if b == 128]
        t2 = issue(m2 + d2, head_landed, 1)
        meta_ready = max(t for tag, t in t1 + t2 if tag != 'd') + 2
        dl = [t for tag, t in t2 if tag == 'd']
        return meta_ready, (max(dl) + 2 if dl else meta_ready), dl

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('pkl', nargs='+'); ap.add_argument('--f', type=float, default=300); ap.add_argument('--L', type=float, default=400)
    ap.add_argument('--noblock', action='store_true'); ap.add_argument('--design', default='v14c')
    ap.add_argument('--arr', type=float, default=1314, help='open to arrival, cycles at 300 MHz (scaled to ns)')
    a = ap.parse_args()
    for p in a.pkl:
        lay, recs = pickle.load(open(p, 'rb'))
        for ph in ('preload', 'mix'):
            by = collections.defaultdict(list)
            for r in recs:
                if r[0] != ph: continue
                rdy, alld, dl = sim_open(r[4], r[5], a.f, a.L, not a.noblock, a.design)
                by[r[1]].append(rdy)
            arr = a.arr * 300 / a.f
            print('%s n=%d %s f=%d L=%.0f block=%d %s: ready (cycles from the open), by window entries:' % (
                p, lay['n'], ph, a.f, a.L, not a.noblock, a.design))
            for k in sorted(by):
                v = sorted(by[k]); n = len(v)
                late = sum(1 for x in v if x > arr + 100)
                print('   %d entries: %6d opens  median %5.0f  p99 %5.0f  max %5.0f   late>100 after arrival %.1f%%  worst vs arrival %+.0f' % (
                    k, n, v[n // 2], v[min(n - 1, int(n * 0.99))], v[-1], 100 * late / n, v[-1] - arr))
