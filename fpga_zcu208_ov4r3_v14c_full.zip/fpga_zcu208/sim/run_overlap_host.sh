#!/bin/bash
# run_overlap_host.sh -- the card's own host program (vitis/host_doma.cpp, unmodified) against the Verilated kernel in
# the XRT mock: preload, then GETs and PUTs with every response checked against a reference, as on the card.
#   OV=4 bash run_overlap_host.sh      step 2 at the card parameters (build.sh OVERLAP=4 defaults)
#   OV=2 bash run_overlap_host.sh      step 1;   OV=0: v14d1
# Buckets in host memory (MOCK_CFG=doma) at the card's 467-cycle read latency; 0%, 20% and 100% on package;
# DOMA_DIAG=1 (unwritten response slots read back as A5). Exit 0 only if every run reports ALL RESPONSES CORRECT.
set -u
cd "$(dirname "$0")/xrt_mock"
OV=${OV:-4}; N=${N:-512}; CMDS=${CMDS:-300}
case "$OV" in
    4) X="-DORAM_OVERLAP2 -DORAM_OVERLAP4 -DORAM_OV_P=2150 -DORAM_OV_CT_RD=600 -DORAM_OV_DEQ=6000 -DORAM_OV4_GA=1500" ;;
    2) X="-DORAM_OVERLAP2" ;;
    *) X="" ;;
esac
O=$PWD/obj_host_ov$OV; H=$PWD/hs_host_ov$OV; mkdir -p $H
OUT=$O LAMBDA=7 ORAM_N=2097152 EXTRA_DEFS="$X" bash build_model.sh > $H/build_model.log 2>&1 || { echo "model build failed ($H/build_model.log)"; exit 2; }
OUT=$O bash build_hosts.sh > $H/build_hosts.log 2>&1 || { echo "host build failed ($H/build_hosts.log)"; exit 2; }
mv host_doma_sim host_phases_sim host_ycsb_sim $H/
rc=0
for p in 0 20 100; do
    DOMA_DIAG=1 MOCK_CFG=doma MOCK_HOST_LAT=467 DOMA_LAMBDA=7 DOMA_N=$N DOMA_HBM_PCT=$p timeout 7200 \
        $H/host_doma_sim doma_hw.xclbin $CMDS > $H/run_$p.log 2>&1
    if grep -q "ALL RESPONSES CORRECT" $H/run_$p.log; then
        echo "PASS  OV=$OV host_doma, $p% on package: $(grep -E '^query:' $H/run_$p.log | sed 's/ in .*//'), all responses correct"
    else echo "FAIL  OV=$OV host_doma, $p% on package ($H/run_$p.log)"; grep -m6 -E "wrong|DIAG|halt|error" $H/run_$p.log | sed 's/^/      /'; rc=1; fi
done
exit $rc
