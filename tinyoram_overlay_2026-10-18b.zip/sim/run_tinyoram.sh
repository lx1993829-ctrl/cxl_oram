#!/bin/bash
# run_tinyoram.sh -- regression for the tinyoram_kernel Vitis wrapper with Verilator 5 (--timing).
#   bash run_tinyoram.sh                 # all four block sizes (64, 128, 256 B and 4 KB)
#   SIZES="4k" bash run_tinyoram.sh      # one size
# Needs Tiny ORAM fetched and patched: bash ../tinyoram/fetch_tinyoram.sh (done here if missing).
# Exit code 0 = every check passed. Logs: build_tinyoram/*.log
#
# Per size, first a lint (lint_tinyoram.sh): iverilog -Wimplicit from the top for the 1:1, merged and flat-position-map
# variants (Vivado rejects a name declared after its use in a port connection; Verilator does not), and every module
# of every source file elaborated as its own top (Vivado analyses every file it is given, used or not: a dead file
# with an undeclared name stopped a Vivado run). Then the testbench (tb_tinyoram_kernel.v) plays XRT against strict
# AXI memory models:
#   e2e      init launch (reports the geometry, touches no memory), two command launches (the first
#            zero-fills the tree), every GET checked, an out-of-range key rejected, interrupt and
#            CTRL as XRT expects; stale garbage in the tree buffer before init
#   late     first launch 20,000 cycles after reset, then 256 sequential PUTs (the host's preload)
#   gaps     30% ready-low on every AXI channel and 30% read-data gaps; wlast and 4 KB checked
#   wlat     writes land 200 cycles after their data, after a preload (full paths): reads must never see stale data
#   xinit    random initial values everywhere (Verilator --x-initial unique, +verilator+rand+reset+2),
#            Tiny ORAM built without its simulation self-checks (they fire on the first clock edge,
#            before reset takes effect)
#   packed8  (64 B and 4 KB) 8-byte records packed into preloaded blocks (header offset/length, Tiny ORAM's
#            WMask): byte-exact against an image of every block, GETs return only their record, whole-block
#            GETs at the end; a PUT and a GET whose range runs past the block come back 0x40
#   packed16 (64 B and 4 KB) 16-byte records with writes landing 200 cycles late and 30% read-data gaps,
#            no preload (records written into never-written blocks: zeros around them)
#   reboot   (every size) init, preload, runs; then a second init with the tree buffer moved (a new host
#            process while the xclbin stays loaded): a fresh ORAM, correct, records written into blocks the
#            first session had filled come back with zeros around them; a later launch naming another
#            buffer reports 0x20 and keeps the latched one; no tree access outside the latched buffer
#   split    (every size) a tree-top split: the top TOP bytes of the tree on gmem3 (on-package), the rest on
#            gmem2, packed records with gaps on every channel; every burst inside its own buffer
#   fault    (every size) the 40th (merged: 10th) write response on gmem2 in a run after the preload is SLVERR: the run ends
#            with 0x8 in the summary and on the header of the command whose write got the error, no hang; then a re-boot and a fresh run are correct
#   faultlast (every size) writes land late; the last write response outstanding while a released command's
#            header waits for its acknowledgements is SLVERR (its B and the error show in the same cycle)
#   faultearly (every size) a released GET's data write is stalled until one of its tree write responses
#            arrives, SLVERR (the error shows before the GET's header is queued)
#            In both, that command's header must carry 0x8 and the summary's completed count must equal the
#            headers without an error
#   slowack  (every size) after the preload, writes are acknowledged 2,000 cycles (4 KB: 6,000) after their data,
#            longer than a whole path write-back, with model queues deep enough to hold all of it: the next path's
#            reads must wait (the longest hold must reach 1,000 / 3,000 cycles) and none may overlap an
#            unacknowledged write (a bus monitor, on in every test, fails any such read)
#   merged adapter (TINYORAM_MERGE 1, its own build per size): m_e2e, m_gaps, m_wlat as above; m_split (a
#            split plus a re-boot, packed); m_fault, m_faultlast, m_faultearly (faults with the split); m_slowack; m_topall (the whole tree on gmem3, byte ranges)
#   ranges   (every size) records at random byte offsets and lengths, crossing beats anywhere, mixed with
#            whole-block commands; four differently shaped bad ranges, each rejected with its slot untouched
set -u
cd "$(dirname "$0")"
here=$(pwd)
TOR=../tinyoram
[ -f $TOR/build/src/files.f ] || bash $TOR/fetch_tinyoram.sh 4k || exit 2
SRC=$TOR/build/src
SIZES=${SIZES:-"64 128 256 4k"}
B=build_tinyoram
mkdir -p $B
VFLAGS="--binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-WIDTH -Wno-ZERODLY -Wno-BLKANDNBLK"
FILES="$(sed "s#^#$SRC/#" $SRC/files.f | tr '\n' ' ')"
FAILS=0
pass() { echo "  PASS  $1"; }
fail() { echo "  FAIL  $1"; FAILS=$((FAILS+1)); }
build() {   # build <name> <size> <extra flags...>
    local name=$1 sz=$2; shift 2
    mkdir -p $B/cfg_$sz && cp $TOR/config/tinyoram_config_$sz.vh $B/cfg_$sz/tinyoram_config.vh
    [ -x $B/$name/Vtb ] && [ -z "${REBUILD:-}" ] && return 0
    echo "  building $name ..."
    rm -rf $B/$name
    verilator $VFLAGS -I$B/cfg_$sz -I$SRC "$@" --top-module tb_tinyoram_kernel ./tb_tinyoram_kernel.v ./axi_mem_model.v \
        ../tinyoram/rtl/tinyoram_kernel.v ../tinyoram/rtl/tinyoram_axi_adapter.v $FILES -Mdir $B/$name -o Vtb > $B/$name.build.log 2>&1 \
        || { echo "  BUILD FAILED: $name ($B/$name.build.log)"; exit 2; }
}
run() { local name=$1 tag=$2; shift 2; ( ulimit -s unlimited 2>/dev/null; ./$B/$name/Vtb "$@" > $B/run_$tag.log 2>&1 ); }
ok() { grep -q "TINYORAM KERNEL: ALL CHECKS PASSED" $B/run_$1.log && ! grep -qE "ERROR|Error:" $B/run_$1.log; }
# iverilog checks for what Verilator lets through and Vivado does not (lint_tinyoram.sh): elaboration from the top
# with -Wimplicit (Vivado rejects a name declared after its use in a port connection), and every module of every
# file the builds read elaborated as its own top (Vivado analyses every file, used or not)
lint_iv() {   # lint_iv <tag> <size> <defines...>
    local tag=$1 sz=$2; shift 2
    bash ./lint_tinyoram.sh $SRC $TOR/config/tinyoram_config_$sz.vh $B/lint_$tag "$@" > $B/lint_$tag.out 2>&1
    local rc=$?; cat $B/lint_$tag.out; return $rc
}
summ() { grep -E "^(run1|preload): " $B/run_$1.log | sed -E 's/.*(latency min\/max=[0-9]+\/[0-9]+).*(tree AR=[0-9]+ AW=[0-9]+).*/\1 \2/' | tr '\n' ' '; }

for sz in $SIZES; do
    echo "== tinyoram_kernel, $sz-byte blocks"
    # 4 KB accesses are ~20x longer: fewer commands keep the run time reasonable
    if [ $sz = 4k ]; then C1="+cmds=40 +cmds2=12"; C2="+cmds=12 +cmds2=4"; else C1="+cmds=120 +cmds2=40"; C2="+cmds=40 +cmds2=10"; fi
    # late writes for the fault-after-release checks: a response must still be outstanding at the release
    # (at 4 KB, Tiny ORAM reports idle long after its last write beat)
    if [ $sz = 4k ]; then WLF=2000; else WLF=200; fi
    # slow acknowledgements: longer than a whole path write-back, so the next path's reads must be held
    if [ $sz = 4k ]; then WSA="+host_wlat_after=6000 +need_hold=3000"; else WSA="+host_wlat_after=2000 +need_hold=1000"; fi
    lint_iv $sz $sz && LINT_MODULES=0 lint_iv m_$sz $sz -DTINYORAM_MERGE=1 && LINT_MODULES=0 lint_iv f_$sz $sz -DTINYORAM_MERGE=1 -DTINYORAM_RECURSION=1 \
        && pass "lint: every module of every source file elaborates on its own, no undeclared names, no implicit nets beyond the 8 listed REW-only ones; 1:1, merged, flat position map" \
        || fail "lint: undeclared names, implicit nets or iverilog errors ($B/lint_*_$sz.out)"
    build k_$sz $sz -DSIMULATION
    run k_$sz e2e_$sz +hb=0 $C1
    ok e2e_$sz && pass "e2e: init, two launches, GETs correct, bad key rejected, CTRL/interrupt ($(summ e2e_$sz))" || fail "e2e ($B/run_e2e_$sz.log)"
    run k_$sz late_$sz +hb=0 +start_delay=20000 +preload $C2
    ok late_$sz && pass "late first launch + 256 sequential PUTs ($(summ late_$sz))" || fail "late start / preload ($B/run_late_$sz.log)"
    run k_$sz gaps_$sz +hb=0 +host_rdy_gap=30 +host_gap=30 $C2
    ok gaps_$sz && pass "30% ready and read-data gaps on every channel, wlast/4 KB checked" || fail "AXI gaps ($B/run_gaps_$sz.log)"
    run k_$sz wlat_$sz +hb=0 +host_wlat=200 +preload $C2
    ok wlat_$sz && pass "writes land 200 cycles late: no stale reads" || fail "late writes ($B/run_wlat_$sz.log)"
    build kx_$sz $sz --x-assign unique --x-initial unique
    run kx_$sz xinit_$sz +hb=0 +verilator+rand+reset+2 +verilator+seed+11 $C2
    ok xinit_$sz && pass "random initial values" || fail "random initial values ($B/run_xinit_$sz.log)"
    if [ $sz = 64 ] || [ $sz = 4k ]; then
        run k_$sz packed8_$sz +hb=0 +packed=8 +preload $C2
        ok packed8_$sz && pass "packed 8-byte records over preloaded blocks match the block image; bad record ranges rejected" \
            || fail "packed records ($B/run_packed8_$sz.log)"
        run k_$sz packed16_$sz +hb=0 +packed=16 +host_wlat=200 +host_gap=30 $C2
        ok packed16_$sz && pass "packed 16-byte records with late writes and read pauses, correct" || fail "packed records under stress ($B/run_packed16_$sz.log)"
    fi
    run k_$sz reboot_$sz +hb=0 +reboot +packed=8 +preload $C2
    ok reboot_$sz && pass "re-boot on a second init with the tree buffer moved: fresh ORAM, correct; 0x20 for a launch naming another buffer" || fail "re-boot ($B/run_reboot_$sz.log)"
    if [ $sz = 64 ]; then
        run k_$sz rebootsame_$sz +hb=0 +reboot +reboot_same +packed=8 +preload $C2
        ok rebootsame_$sz && pass "re-boot with the tree buffer at the same address: fresh ORAM, not the previous run's" || fail "re-boot, same buffer ($B/run_rebootsame_$sz.log)"
    fi
    case $sz in 64) TOP=16384 ;; 128) TOP=49152 ;; 256) TOP=65536 ;; 4k) TOP=1048576 ;; esac
    run k_$sz split_$sz +hb=0 +top=$TOP +packed=8 +preload +host_gap=30 +host_rdy_gap=30 $C2
    ok split_$sz && pass "tree-top split ($TOP B of the tree on the top port): correct, every burst in its buffer" || fail "tree-top split ($B/run_split_$sz.log)"
    run k_$sz fault_$sz +hb=0 +berr=40 +preload $C2
    ok fault_$sz && pass "an injected write error is reported (0x8), then re-boot and a correct fresh run" || fail "fault injection ($B/run_fault_$sz.log)"
    run k_$sz faultlast_$sz +hb=0 +berr_last +host_wlat=$WLF +preload $C2
    ok faultlast_$sz && pass "a write error on a released command's last write response is charged to that command" || fail "fault on the last response ($B/run_faultlast_$sz.log)"
    run k_$sz faultearly_$sz +hb=0 +berr_early +host_wlat=$WLF +preload $C2
    ok faultearly_$sz && pass "a write error after a GET's release, before its header is queued, is charged to that GET" || fail "fault before the header ($B/run_faultearly_$sz.log)"
    run k_$sz slowack_$sz +hb=0 +preload $WSA $C2
    ok slowack_$sz && pass "acknowledgements later than a whole path write-back: reads held behind them ($(grep -m1 -oE 'longest [0-9]+ cycles' $B/run_slowack_$sz.log)), no stale read" || fail "slow acknowledgements ($B/run_slowack_$sz.log)"
    run k_$sz ranges_$sz +hb=0 +ranges +preload +host_gap=30 $C2
    ok ranges_$sz && pass "records at any byte offset and length, mixed with whole blocks; four bad range shapes rejected" || fail "byte ranges ($B/run_ranges_$sz.log)"
    # ---- the merged-burst adapter
    build km_$sz $sz -DSIMULATION -DTINYORAM_MERGE=1
    run km_$sz m_e2e_$sz +hb=0 $C1
    ok m_e2e_$sz && pass "merged bursts: e2e ($(summ m_e2e_$sz | sed -E 's/ run1: latency to.*//'), $(grep -E '^run1: traffic' $B/run_m_e2e_$sz.log | grep -oE '[0-9]+ beats per read burst'))" || fail "merged e2e ($B/run_m_e2e_$sz.log)"
    run km_$sz m_gaps_$sz +hb=0 +host_rdy_gap=30 +host_gap=30 $C2
    ok m_gaps_$sz && pass "merged bursts: 30% ready and read-data gaps, wlast/4 KB checked" || fail "merged gaps ($B/run_m_gaps_$sz.log)"
    run km_$sz m_wlat_$sz +hb=0 +host_wlat=200 +preload $C2
    ok m_wlat_$sz && pass "merged bursts: writes land 200 cycles late, no stale reads" || fail "merged late writes ($B/run_m_wlat_$sz.log)"
    run km_$sz m_split_$sz +hb=0 +top=$TOP +reboot +packed=8 +preload $C2
    ok m_split_$sz && pass "merged bursts: tree-top split and re-boot, packed records" || fail "merged split ($B/run_m_split_$sz.log)"
    run km_$sz m_fault_$sz +hb=0 +berr=10 +preload +top=$TOP $C2
    ok m_fault_$sz && pass "merged bursts: an injected write error with the split, then re-boot and a correct fresh run" || fail "merged fault ($B/run_m_fault_$sz.log)"
    run km_$sz m_faultlast_$sz +hb=0 +berr_last +host_wlat=$WLF +preload +top=$TOP $C2
    ok m_faultlast_$sz && pass "merged bursts: a write error on the last response, with the split, is charged to its command" || fail "merged fault on the last response ($B/run_m_faultlast_$sz.log)"
    run km_$sz m_faultearly_$sz +hb=0 +berr_early +host_wlat=$WLF +preload +top=$TOP $C2
    ok m_faultearly_$sz && pass "merged bursts: a write error before a GET's header is queued, with the split, is charged to that GET" || fail "merged fault before the header ($B/run_m_faultearly_$sz.log)"
    run km_$sz m_slowack_$sz +hb=0 +preload $WSA $C2
    ok m_slowack_$sz && pass "merged bursts: acknowledgements later than a path write-back, reads held ($(grep -m1 -oE 'longest [0-9]+ cycles' $B/run_m_slowack_$sz.log)), no stale read" || fail "merged slow acknowledgements ($B/run_m_slowack_$sz.log)"
    run km_$sz m_topall_$sz +hb=0 +top_all +ranges +preload +host_gap=30 $C2
    ok m_topall_$sz && pass "merged bursts: the whole tree on the top port, byte ranges" || fail "merged top-all ($B/run_m_topall_$sz.log)"
done
echo
if [ $FAILS = 0 ]; then echo "ALL CHECKS PASSED"; exit 0; else echo "$FAILS CHECK(S) FAILED"; exit 1; fi
