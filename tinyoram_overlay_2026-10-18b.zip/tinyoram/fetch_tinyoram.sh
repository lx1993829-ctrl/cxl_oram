#!/bin/bash
# fetch_tinyoram.sh -- get Tiny ORAM (Fletcher et al., FCCM 2015) and prepare it for the U55C kernel.
#
#   bash fetch_tinyoram.sh [size] [L] [merge] [flatpm]
#                                        size = 64 | 128 | 256 | 4k   (default 4k)
#                                        L    = tree depth ORAML (default: the size's config, 6);
#                                               N = 4 * 2^L blocks, e.g. L=18 for 1M records
#                                        merge: the adapter merges contiguous commands into one
#                                               burst (TINYORAM_MERGE 1); default the 1:1 adapter
#                                        flatpm: no PosMap recursion, all N PosMap entries on chip
#                                               (TINYORAM_RECURSION 1, patch 07); default as published
#
# 1. downloads github.com/ascend-secure-processor/oram at commit 18ece07 (branch oram_fpga_public;
#    its RTL is identical to master) into tinyoram/upstream/  -- or uses TINYORAM_TARBALL=<file>
#    if the machine cannot reach GitHub (download the same commit's .tar.gz elsewhere)
# 2. applies our patches (tinyoram/patches/0*.diff) to a copy in tinyoram/build/patched/
#      01 build configuration header   02 Idle status output   03 zero-width parameter defaults
#      04 simulation-only check fixes (inside `ifdef SIMULATION; no effect on synthesis)
#      05 PosMapPLB fix (a leaf truncated to ORAML bits: wrong path after 2^ORAML accesses to a block)
#      06 no mark_debug attributes (debug-core markers only; cycle-identical)
#      07 TINYORAM_RECURSION option (default unchanged: Tiny ORAM's own recursion depth)
# 3. writes tinyoram/build/src/: every core source and header in one flat directory (the names
#    are unique), plus tinyoram_config.vh for the chosen size and files.f (the source list)
# Tiny ORAM's sources are not redistributed with this package: the MIT-written files carry no
# license. Cite: C. W. Fletcher et al., "A Low-Latency, Low-Area Hardware Oblivious RAM
# Controller", FCCM 2015.
set -euo pipefail
here=$(cd "$(dirname "$0")" && pwd)
SIZE=${1:-4k}
LV=${2:-}
MG=""; FP=""
for o in "${@:3}"; do
    case "$o" in merge) MG=merge ;; flatpm) FP=flatpm ;; *) echo "unknown option '$o' (merge, flatpm)"; exit 2 ;; esac
done
COMMIT=18ece0764c4feb5b34f568b2bf9e18081a781a06
cfg=$here/config/tinyoram_config_$SIZE.vh
[ -f "$cfg" ] || { echo "unknown size '$SIZE' (want 64, 128, 256 or 4k)"; exit 2; }

up=$here/upstream
if [ ! -f "$up/TinyORAMCore.v" ]; then
    rm -rf "$up"; mkdir -p "$up"
    tb=${TINYORAM_TARBALL:-$here/oram-$COMMIT.tar.gz}
    if [ -f "$tb" ]; then
        tar -xzf "$tb" -C "$up" --strip-components=1
    elif command -v git >/dev/null && git clone -q -b oram_fpga_public https://github.com/ascend-secure-processor/oram.git "$up.git" 2>/dev/null; then
        (cd "$up.git" && git checkout -q $COMMIT && git archive $COMMIT) | tar -x -C "$up"; rm -rf "$up.git"
    else
        echo "downloading Tiny ORAM $COMMIT ..."
        wget -q -O "$tb" "https://github.com/ascend-secure-processor/oram/archive/$COMMIT.tar.gz" \
            || curl -sSL -o "$tb" "https://github.com/ascend-secure-processor/oram/archive/$COMMIT.tar.gz"
        tar -xzf "$tb" -C "$up" --strip-components=1
    fi
    [ -f "$up/TinyORAMCore.v" ] || { echo "download/unpack failed (set TINYORAM_TARBALL to a downloaded .tar.gz)"; exit 1; }
fi

b=$here/build
rm -rf "$b/patched" "$b/src"; mkdir -p "$b"
cp -r "$up" "$b/patched"
for p in "$here"/patches/0*.diff; do
    (cd "$b/patched" && patch -s -p1 < "$p") || { echo "patch $(basename "$p") failed"; exit 1; }
done

# the synthesizable core: no testbenches, no ASIC wrappers/SRAMs, no unused inverse AES,
# no board files; PrioritySelect.v is unused and has a syntax error (unnamed instance).
# Vivado reads every file it is given (synth_design; package_tinyoram.tcl globs build/src/*.v), not only
# the modules the design uses, so a dead file can stop a build: DRAMInitializer.v names an undeclared
# LastBuckerAddr ([Synth 8-36]), and aes_192.v/aes_256.v instantiate their rounds with the wrong number of
# ports. Left out as well: every other file whose modules are named by no other file, in any configuration
# (checked with Verilator's elaborated module list over all four block sizes, 1:1/merged/flat position map,
# with and without SIMULATION; README §16). Files named by an inactive generate branch (the REW-ORAM files,
# Bin2Gray/Gray2Bin, padder1) stay, so every tool still finds the modules those branches name.
DEAD="DRAMInitializer.v aes_192.v aes_256.v ClockSource.v FIFOLinear.v LFSR.v ROISeedGenerator.v SynthesizedRandDRAM.v DRAM2RAM.v SynthesizedDRAM.v"
mkdir -p "$b/src"
(cd "$b/patched" && find . -name '*.v' -not -path '*/test/*' -not -path '*/old/*' -not -path './sram_wrap/*' \
    -not -path '*/bench/*' -not -name 'aes_inv*' -not -name 'test_*' -not -name 'tiny_aes_vc707.v' \
    -not -name 'PrioritySelect.v' -not -name '*ASIC*' | sort) | while read -r f; do
    case " $DEAD " in *" $(basename "$f") "*) ;; *) echo "$f" ;; esac; done > "$b/core.lst"
dups=$(xargs -n1 basename < "$b/core.lst" | sort | uniq -d)
[ -z "$dups" ] || { echo "duplicate file names: $dups"; exit 1; }
while read -r f; do cp "$b/patched/$f" "$b/src/"; done < "$b/core.lst"
cp "$b/patched/include/"*.vh "$b/patched/include/DRAM.constants" "$b/src/"
cp "$cfg" "$b/src/tinyoram_config.vh"
if [ -n "$LV" ]; then
    [[ "$LV" =~ ^[0-9]+$ ]] && [ "$LV" -ge 6 ] && [ "$LV" -le 26 ] || { echo "L must be 6..26"; exit 2; }
    sed -i -E "s/^(\`define TINYORAM_ORAML +)[0-9]+.*/\1$LV        \/\/ set by fetch_tinyoram.sh: N = $((4 << LV)) blocks/" "$b/src/tinyoram_config.vh"
fi
(cd "$b/src" && ls *.v) > "$b/src/files.f"
if [ "$MG" = merge ]; then
    sed -i 's#^`endif#`define TINYORAM_MERGE     1        // set by fetch_tinyoram.sh: merged bursts in the adapter\n`endif#' "$b/src/tinyoram_config.vh"
fi
if [ "$FP" = flatpm ]; then
    sed -i 's#^`endif#`define TINYORAM_RECURSION 1        // set by fetch_tinyoram.sh: flat on-chip PosMap, no recursion\n`endif#' "$b/src/tinyoram_config.vh"
fi
echo "Tiny ORAM ready: $(wc -l < "$b/src/files.f") sources in $b/src, configuration $SIZE ($(grep -oE '(ORAM[BL]|MERGE|RECURSION) +[0-9]+' "$b/src/tinyoram_config.vh" | tr '\n' ' '))"
