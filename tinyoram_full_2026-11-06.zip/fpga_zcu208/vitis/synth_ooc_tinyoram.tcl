# synth_ooc_tinyoram.tcl -- out-of-context synthesis + place & route of tinyoram_kernel on the U55C
# part at 300 MHz: resources, timing, and the worst path of every failing register group.
# No platform, no v++, no card: a quick check of whether Tiny ORAM closes timing before any
# multi-hour build.  (UNTESTED here: no Vivado in the environment this was written in.)
#
#   cd vitis
#   bash ../tinyoram/fetch_tinyoram.sh 4k            # Tiny ORAM + patches + config -> ../tinyoram/build/src
#   vivado -mode batch -nojournal -nolog -source synth_ooc_tinyoram.tcl
#   vivado -mode batch -nojournal -nolog -source synth_ooc_tinyoram.tcl -tclargs synth   ;# stop after synthesis
#   vivado -mode batch -nojournal -nolog -source synth_ooc_tinyoram.tcl -tclargs route 250  ;# another clock (MHz)
#
# Output in ooc_tinyoram_<block>B_L<L>_<MHz>mhz/ (from the fetched configuration, e.g. ooc_tinyoram_64B_L6_300mhz):
# util_synth.rpt, util_routed.rpt, timing_routed.rpt, logic_levels.rpt, worst_groups.txt (one line per
# failing register group: slack, levels, count, endpoint, start), routed.dcp.
set stage  [expr {[llength $argv] > 0 ? [lindex $argv 0] : "route"}]
set part   xcu55c-fsvh2892-2L-e
set mhz    [expr {[llength $argv] > 1 ? [lindex $argv 1] : 300}]
set period [format %.3f [expr {1000.0 / $mhz}]]
set src    ../tinyoram/build/src
set rtl    ../tinyoram/rtl
if {![file exists $src/files.f]} { error "run ../tinyoram/fetch_tinyoram.sh first" }
set fh [open $src/tinyoram_config.vh r]; set cfg [read $fh]; close $fh
regexp {TINYORAM_ORAMB\s+(\d+)} $cfg -> cfg_b
regexp {TINYORAM_ORAML\s+(\d+)} $cfg -> cfg_l
set cfg_m  [expr {[regexp {TINYORAM_MERGE\s+1} $cfg] ? "_merge" : ""}][expr {[regexp {TINYORAM_RECURSION\s+1\s} $cfg] ? "_flatpm" : ""}][expr {[regexp {TINYORAM_RTDEPTH\s+1} $cfg] ? "_rt" : ""}][expr {[regexp {TINYORAM_PM_HBM\s+1} $cfg] ? "_hbmpm" : ""}]
set out    ooc_tinyoram_[expr {$cfg_b / 8}]B_L${cfg_l}${cfg_m}_${mhz}mhz
set cfg_mt [expr {[string match *_merge* $cfg_m] ? "merged bursts" : "1:1 adapter"}][expr {[string match *_flatpm* $cfg_m] ? ", flat PosMap" : ""}][expr {[string match *_rt* $cfg_m] ? ", run-time depth (L_max)" : ""}]
puts "tinyoram_kernel: [expr {$cfg_b / 8}]-byte blocks, L=$cfg_l, $cfg_mt, $mhz MHz -> $out/"
file mkdir $out

# Tiny ORAM (flat, patched) + our wrapper and adapter; headers resolve from the flat directory
set fh [open $src/files.f r]
foreach f [split [string trim [read $fh]] "\n"] { read_verilog $src/$f }
close $fh
read_verilog $rtl/tinyoram_kernel.v $rtl/tinyoram_axi_adapter.v
if {[regexp {TINYORAM_PM_HBM\s+1} $cfg]} { read_verilog $rtl/tinyoram_pm_axi.v }
set x [open $out/clk.xdc w]
puts $x "create_clock -period $period -name ap_clk \[get_ports ap_clk\]"
close $x
read_xdc -mode out_of_context $out/clk.xdc

synth_design -top tinyoram_kernel -part $part -mode out_of_context -include_dirs [list $src] \
             -flatten_hierarchy rebuilt -directive PerformanceOptimized
report_utilization -hierarchical -hierarchical_depth 4 -file $out/util_synth.rpt
report_timing_summary -max_paths 20 -file $out/timing_synth.rpt
write_checkpoint -force $out/synth.dcp

proc worst_groups {fname} {
  set g [open $fname w]
  array set worst {}; array set cnt {}; array set lv {}; array set sp {}
  foreach p [get_timing_paths -setup -max_paths 5000 -nworst 1 -slack_lesser_than 0] {
    set e [get_property ENDPOINT_PIN $p]
    regsub {/[^/]+$} $e {} e
    regsub -all {\[[0-9]+\]} $e {} e
    regsub -all {_rep(__[0-9]+)?} $e {} e
    set s [get_property SLACK $p]
    if {![info exists worst($e)] || $s < $worst($e)} { set worst($e) $s; set lv($e) [get_property LOGIC_LEVELS $p]; set sp($e) [get_property STARTPOINT_PIN $p] }
    if {[info exists cnt($e)]} { incr cnt($e) } else { set cnt($e) 1 }
  }
  set lst {}
  foreach k [array names worst] { lappend lst [list $worst($k) $k] }
  foreach item [lrange [lsort -real -index 0 $lst] 0 39] {
    set s [lindex $item 0]; set k [lindex $item 1]
    puts $g [format "%8.3f slack | %2d levels | %4d failing | %s   (from %s)" $s $lv($k) $cnt($k) $k $sp($k)]
  }
  close $g
  puts "wrote $fname: [llength $lst] failing register groups"
}

if {$stage eq "synth"} {
  worst_groups $out/worst_groups_synth.txt
  puts "WNS after synthesis (estimate): [get_property SLACK [get_timing_paths -max_paths 1 -nworst 1 -setup]] ns at $period ns"
  return
}
opt_design -directive Explore
place_design -directive ExtraNetDelay_high
phys_opt_design -directive AggressiveExplore
route_design -directive AggressiveExplore
phys_opt_design -directive AggressiveExplore
report_utilization -hierarchical -hierarchical_depth 4 -file $out/util_routed.rpt
report_timing_summary -max_paths 40 -file $out/timing_routed.rpt
report_design_analysis -logic_level_distribution -file $out/logic_levels.rpt
worst_groups $out/worst_groups.txt
write_checkpoint -force $out/routed.dcp
puts "WNS: [get_property SLACK [get_timing_paths -max_paths 1 -nworst 1 -setup]] ns, WHS: [get_property SLACK [get_timing_paths -max_paths 1 -nworst 1 -hold]] ns at $period ns (tinyoram_kernel on $part)"
