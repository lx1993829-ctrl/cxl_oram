# elab_tinyoram.tcl -- a one-minute Vivado source check before any long run: read every Verilog file the builds read
# (all of ../tinyoram/build/src/*.v, as package_tinyoram.tcl's glob does, plus the wrapper and the adapter) and
# elaborate tinyoram_kernel (synth_design -rtl). An undeclared name, a syntax error in a file nothing uses, a port
# mismatch or an unsupported construct stops it here, instead of hours into a board build.  (UNTESTED here: no Vivado.)
#
#   cd vitis
#   bash ../tinyoram/fetch_tinyoram.sh 64 [L] [merge] [flatpm]
#   vivado -mode batch -nojournal -nolog -source elab_tinyoram.tcl
#
# Last line: "ELAB PASS: ..." (exit 0) or "ELAB FAIL: ..." (exit 1). Critical warnings are listed, not counted as a fail.
set part xcu55c-fsvh2892-2L-e
set src  ../tinyoram/build/src
set rtl  ../tinyoram/rtl
if {![file exists $src/files.f]} { puts "ELAB FAIL: no $src/files.f: run ../tinyoram/fetch_tinyoram.sh first"; exit 1 }
set fh [open $src/tinyoram_config.vh r]; set cfg [read $fh]; close $fh
regexp {TINYORAM_ORAMB\s+(\d+)} $cfg -> cfg_b
regexp {TINYORAM_ORAML\s+(\d+)} $cfg -> cfg_l
set what "[expr {$cfg_b / 8}]-byte blocks, L=$cfg_l[expr {[regexp {TINYORAM_MERGE\s+1} $cfg] ? ", merged bursts" : ", 1:1 adapter"}][expr {[regexp {TINYORAM_RECURSION\s+1\s} $cfg] ? ", flat PosMap" : ""}][expr {[regexp {TINYORAM_RTDEPTH\s+1} $cfg] ? ", run-time depth (L_max)" : ""}][expr {[regexp {TINYORAM_TOP_PLAINTEXT\s+1} $cfg] ? ", plaintext top" : ""}][expr {[regexp {TINYORAM_PM_HBM\s+1} $cfg] ? ", position map in HBM" : ""}]"
set files [lsort [glob $src/*.v]]
puts "elab_tinyoram: $what; [llength $files] core files + wrapper and adapter"
if {[catch {
    foreach f $files { read_verilog $f }
    read_verilog [list $rtl/tinyoram_kernel.v $rtl/tinyoram_axi_adapter.v]
    if {[regexp {TINYORAM_PM_HBM\s+1} $cfg]} { read_verilog $rtl/tinyoram_pm_axi.v }
    synth_design -rtl -top tinyoram_kernel -part $part -mode out_of_context -include_dirs [list $src]
} msg]} {
    puts "ELAB FAIL: $what: $msg"
    exit 1
}
set n_err 0; set n_cw 0
catch { set n_err [get_msg_config -count -severity ERROR] }
catch { set n_cw  [get_msg_config -count -severity {CRITICAL WARNING}] }
if {$n_err > 0} { puts "ELAB FAIL: $what: $n_err error(s) (see the ERROR lines above)"; exit 1 }
puts "ELAB PASS: $what: tinyoram_kernel elaborates; $n_cw critical warning(s)"
exit 0
