# Tiny ORAM on the U55C: card runbook (Phases 3 and 4)

**Scripts (2026-10-18).** The steps below are scripted in `tinyoram/card/` (README §15), with the pass
criteria built in. In order:
1. `install_tinyoram.sh <fpga_zcu208_deploy.zip> <tinyoram overlay.zip> ~/tiny --check`: the combined
   tree, its manifest, one copy per bitstream, and all regressions. Pass: `INSTALL OK, ALL REGRESSIONS PASSED`.
   The Tiny ORAM regression starts by linting every `queue.txt` geometry (`q1`–`q9` lines). If the queue's
   copies were made before the 2026-10-18 night overlay, re-run the install. Each copy fetches with its own
   `fetch_tinyoram.sh`, and q6/q7 need the new one, which writes `TINYORAM_RECURSION 2` (README §17). Quick
   check in a queue copy after its fetch: `grep RECURSION tinyoram/build/src/tinyoram_config.vh`.
2. In `~/tiny/bringup/fpga_zcu208/tinyoram/card`: `bash bringup_64.sh ooc`, then `link`, `emu`, `hw`, `card`,
   each only after the one before passed. `link` (3.2b) is a v++ link at 230 MHz (`LINK_FREQ=`), or at `FREQ`
   if that is not 300, stopped before synthesis: about 10–20 minutes per link configuration. Send `~/tiny/bringup/bringup_report.txt` after each step.
3. Only after `card` passed: `bash queue.sh start` (in `~/tiny/combined/fpga_zcu208/tinyoram/card`), and
   `bash queue.sh status` to follow it. Builds run one at a time; `pause` lets the current one finish.
4. As builds finish: `bash sweep_tiny.sh` (dry-run first, if in doubt: `bash test_card_scripts.sh`, a minute, no card;
   last line `CARD SCRIPTS TEST PASS`), and once `bash sweep_doma.sh <DOMA 32 B xclbin> [<DOMA 4 KB xclbin>]`.
   Then `python3 merge_results.py` writes `~/tiny/results/comparison.md`.
5. Run-time tree depth (README §18). q8 is one 64 B build at L_max = 19, and q9 one 4 KB build at L_max = 14,
   each for every N up to its own; the host picks the depth from `DOMA_N`. Build q8 after q1:
   `bash queue.sh start 8`. When both are DONE, run `bash accept_rt.sh 1 8`. It compares N = 1M on both,
   alternating, 5 runs each at `DOMA_TINY_TOP` 0 and doma:20.
   * Pass: last line `ACCEPT PASS`. Traffic per command is identical, p50/p99 within 2%, KQPS within noise,
     the same clock. Send `~/tiny/results/accept_rt.txt`.
   * On a pass: `bash sweep_tiny.sh 8` gives 100K, 1M and 10M from q8, and q4 and q5 need not be built
     (`queue.sh start 1 2 3 6 7 8`, say). q9 likewise replaces q6 and q7, after the same check against q6 or
     q7: `accept_rt.sh 6 9` with `N=16384`, or `accept_rt.sh 7 9` with `N=65536`.

6. 1 KB and 2 KB blocks (README §21). Install over the existing `~/tiny` after moving the two shared copies aside
   (`mv ~/tiny/combined ~/tiny/combined_1019; mv ~/tiny/bringup ~/tiny/bringup_1019`): the install refuses to run while
   `combined` exists, keeps every existing `q*` copy and `~/tiny/queue/` as they are, and adds the q13/q14 copies.
   In the new bring-up copy's `tinyoram/card`: `bash check_sizes_vivado.sh` (elaboration
   of 512 B, 1 KB and 2 KB, native L = 6 and run-time L_max = 18; then the short link of 1 KB and 2 KB at 230 MHz).
   Pass: last line `SIZES VIVADO CHECKS PASSED`; send `~/tiny/bringup/sizes_report.txt`. Then `bash queue.sh start 13 14`
   in the combined copy. Before running N near 1M blocks on them, check the card's host-memory size: the trees at
   L = 18 are 2.3 GB (1 KB) and 6.4 GB (2 KB). Sweep: `bash sweep_tiny.sh 13 14`.

The rest of this runbook is the manual version of the same steps, with what to expect at each.

These are the commands, in order, with the output to expect at each step. No step changes the card's
configuration or needs sudo. The tree buffer goes in HBM[8] (`tinyoram_hw.cfg`, host flag
`DOMA_PAGES_HBM=1`), as DOMA's current runs do.

**One copy of the package per bitstream.** `fetch_tinyoram.sh` rewrites `tinyoram/build/src/` in
place, including the tree depth. Fetching L = 15 into a folder whose L = 6 build is still running would
change that build's sources under it. So unzip the package once per configuration:

```bash
unzip -q fpga_zcu208_deploy.zip -d ~/fpga_tiny64        # Phase 3: 64 B, L = 6
unzip -q fpga_zcu208_deploy.zip -d ~/fpga_tiny64_l15    # Phase 4: 64 B, L = 15 (1M records, 8 per block)
```

Before starting, in every shell:

```bash
source /tools/Xilinx/Vitis/2024.1/settings64.sh      # or wherever Vitis 2024.1 is installed
source /opt/xilinx/xrt/setup.sh
cd ~/fpga_tiny64/fpga_zcu208/vitis                    # Phase 4: ~/fpga_tiny64_l15/fpga_zcu208/vitis
```

## Phase 3: bring-up at 64 B

### 3.1 Fetch Tiny ORAM

```bash
bash ../tinyoram/fetch_tinyoram.sh 64
```

Expected, last line:

```
Tiny ORAM ready: 62 sources in .../fpga_zcu208/tinyoram/build/src, configuration 64 (ORAMB      512 ORAML      6 )
```

This needs GitHub (it tries `git clone` first, then `wget`/`curl`). If the machine can't reach GitHub,
download `https://github.com/ascend-secure-processor/oram/archive/18ece0764c4feb5b34f568b2bf9e18081a781a06.tar.gz`
elsewhere, copy it over, and run `TINYORAM_TARBALL=<file> bash ../tinyoram/fetch_tinyoram.sh 64`.
Any `patch ... failed` message means the download is not commit 18ece07.

### 3.2 Out-of-context timing check at 300 MHz (about 30–60 minutes, no card needed)

First a one-minute elaboration of exactly the sources the builds read (README §16):

```bash
vivado -mode batch -nojournal -nolog -source elab_tinyoram.tcl
```

Expected, near the end: `ELAB PASS: 64-byte blocks, L=6, 1:1 adapter: tinyoram_kernel elaborates; <n> critical warning(s)`.
An `ELAB FAIL` line, or any `ERROR:` line, means a source problem: stop and send me the log.
(`build_tinyoram.sh` runs the same check after its fetch.) Then:

```bash
vivado -mode batch -nojournal -nolog -source synth_ooc_tinyoram.tcl
```

Expected:
* first line: `tinyoram_kernel: 64-byte blocks, L=6, 1:1 adapter, 300 MHz -> ooc_tinyoram_64B_L6_300mhz/`
  (fetched with `merge`: `merged bursts` and `..._L6_merge_300mhz/`);
* last line: `WNS: <x> ns, WHS: <y> ns at 3.333 ns (tinyoram_kernel on xcu55c-fsvh2892-2L-e)`.

**Pass:** WNS ≥ 0. Then go to 3.3 at 300 MHz.

**If WNS < 0:**

1. Look at `ooc_tinyoram_64B_L6_300mhz/worst_groups.txt` for the failing paths. The likely ones are
   Keccak's two rounds per cycle, the tiny_aes table rounds and the stash scan.
2. Estimate the reachable clock as f ≈ 1000 / (3.333 − WNS) MHz. For example, WNS = −0.8 ns gives
   about 242 MHz.
3. Round down to a multiple of 5 MHz and confirm it out of context, for example:
   ```bash
   vivado -mode batch -nojournal -nolog -source synth_ooc_tinyoram.tcl -tclargs route 240
   ```
   This writes `ooc_tinyoram_64B_L6_240mhz/`. If WNS is still negative, step down by 10 MHz.
4. Use the highest passing clock as `FREQ=` in every build below. Report results both in cycles and in
   time at that clock.

**Also note for the report:** `ooc_tinyoram_*/util_routed.rpt` gives the resources of the whole kernel
(Tiny ORAM `u_tiny`, adapter `u_adapt`, and the wrapper) out of context.

### 3.2b Short link at a clock other than 300 MHz (about 20–40 minutes, no card needed)

The elaboration and the out-of-context runs do not involve the platform. This step links the kernel into it at
a non-300 clock, for both link configurations, and stops before synthesis (README §19):

```bash
bash ../tinyoram/fetch_tinyoram.sh 64 6 merge
FREQ=230 CFG=tinyoram_host.cfg bash link_check_tinyoram.sh
FREQ=230 CFG=tinyoram_hw.cfg   bash link_check_tinyoram.sh
```

**Pass:** each ends `LINK CHECK PASS: v++ link at --kernel_frequency 230 with <cfg> reaches vpl.generate_target
without errors`. On a FAIL, send me the `ERROR` lines it prints and `link_check_230mhz_<cfg>_link.log`.
`bringup_64.sh link` does both and writes the verdicts to the report.

### 3.3 Hardware emulation with 20 commands (no card needed)

```bash
SIZE=64 TARGET=hw_emu bash build_tinyoram.sh            # add FREQ=<MHz> if 3.2 needed it
```

Expected: it prints
`Tiny ORAM build: 64-byte blocks, 256 records, 256 blocks -> L=6 (N=256 blocks), 300 MHz, tag tinyoram_64`,
builds `tinyoram_64_hw_emu.xclbin` and `host_doma`, and ends with its run line. Run it with a small
`DOMA_N`, so the preload stays short in emulation:

```bash
XCL_EMULATION_MODE=hw_emu DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=64 DOMA_N=32 DOMA_PAGES_HBM=1 \
    ./host_doma tinyoram_64_hw_emu.xclbin 20
```

Expected (`T`, `Q`, the cycle counts and latencies vary):

```
size: 32 blocks, Tiny ORAM tree for L=6 (N=256), 64-byte blocks: 53248 bytes
block: 64 bytes per slot
Tiny ORAM bitstream: N=256 blocks (L=6), tree 49536 bytes
records: 32 keys of 8 bytes, 1 per block
placement: tree 49536 B = 0 B on-package (top buffer) + 49536 B in pages; per record 0.0 B on-package, 1548.0 B in pages
init: T s (boot + preload of 32 keys), preload errors=0x0
query: 20 commands (11 GET, 9 PUT) in T s = Q KQPS
device: ... cycles total, per-command latency A..B cycles, completed 20, errors 0x0, summary ok
latency: to data ready ..., to last write-back beat A..B, to write-back acknowledged ... cycles
latency spread: min A, p50 ..., p90 ..., p99 ..., p99.9 ..., max B, mean ... cycles (20 commands)
latency histogram (...-cycle bins from A): ...
traffic: tree (pages + top, both ports) 53760 B read, 53760 B written = 2688 B read, 2688 B written per command
ALL RESPONSES CORRECT
```

* 2,688 B per command each way is exactly one path: 7 buckets × 6 bursts × 64 B. Slightly more means
  Tiny ORAM inserted background evictions, which is legitimate.
* `DOMA_N=32` works because N ≤ 256 records all use the L=6 tree. The host refuses an N that needs
  another tree, and names the L it needs.
* Packed records on the same xclbin:
  ```bash
  XCL_EMULATION_MODE=hw_emu DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=64 DOMA_N=64 DOMA_PACK=1 DOMA_PAGES_HBM=1 \
      ./host_doma tinyoram_64_hw_emu.xclbin 20
  ```
  Expected: `records: 64 keys of 8 bytes, 8 per block` and `ALL RESPONSES CORRECT`.

If emulation reports `errors 0x8`, Tiny ORAM's integrity check or the adapter flagged an error. The
emulation log is under `.run/*/hw_emu/device0/binary_0/behav_waveform/xsim/simulate.log`.

### 3.4 Board build, with the post-placement check about 45 minutes in

```bash
SIZE=64 TARGET=hw bash build_tinyoram.sh 2>&1 | tee build_tinyoram_64_hw.log    # add FREQ=<MHz> if needed
```

About 45 minutes in, placement finishes and the hook (`post_place.tcl`) writes four files:

```bash
R=_x_tinyoram_64/link/vivado/vpl/prj/prj.runs/impl_1      # _x_tinyoram_64_<F>mhz with FREQ=<F>
ls -la $R/post_place.dcp $R/post_place_*.rpt
awk '/WNS\(ns\)/{getline; getline; print "post-place WNS="$1" ns, TNS="$2" ns, WHS="$5" ns"; exit}' $R/post_place_timing.rpt
grep -E "tinyoram_kernel_1|u_tiny|u_adapt" $R/post_place_util_hier.rpt | head
grep -A12 "Congestion" $R/post_place_congestion.rpt | head -30
```

Decision:
* **Post-place WNS ≥ −0.3 ns:** let it run. Physical optimisation and routing usually recover that much.
* **Post-place WNS < −0.5 ns:** stop the build (Ctrl-C in its terminal). Then go back to 3.2 for the
  clock, and rebuild with `FREQ=`.
* **Congestion level ≥ 5** in any direction: send me the congestion report before rebuilding.

At the end, the script runs `check_timing.sh`. Expected:

```
routed timing: WNS=<≥0> ns  TNS=0.000 ns  WHS=<≥0> ns  THS=0.000 ns
kernel clock in tinyoram_64_hw.xclbin: 300 MHz
PASS: timing closed at 300 MHz
run: DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=64 DOMA_N=256 DOMA_PAGES_HBM=1 ./host_doma tinyoram_64_hw.xclbin 5000
```

A `FAIL` line, followed by `*** TIMING NOT CLOSED ***`, means the xclbin must not be used for
measurements. A common cause is that v++ lowered the clock.

### 3.5 Runs on the card

```bash
DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=64 DOMA_N=256 DOMA_PAGES_HBM=1 ./host_doma tinyoram_64_hw.xclbin 5000
DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=64 DOMA_N=256 DOMA_PAGES_HBM=1 ./host_doma tinyoram_64_hw.xclbin 100000
DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=64 DOMA_N=2048 DOMA_PACK=1 DOMA_PAGES_HBM=1 ./host_doma tinyoram_64_hw.xclbin 5000
```

Expected:

| Run | Lines that must match |
|---|---|
| 5,000 | `records: 256 keys of 8 bytes, 1 per block`, `query: 5000 commands (2546 GET, 2454 PUT)`, `completed 5000, errors 0x0, summary ok`, `ALL RESPONSES CORRECT` |
| 100,000 | `query: 100000 commands (49992 GET, 50008 PUT)`, `completed 100000, errors 0x0`, `ALL RESPONSES CORRECT` |
| packed, 5,000 | `records: 2048 keys of 8 bytes, 8 per block`, `query: 5000 commands (2546 GET, 2454 PUT)`, `ALL RESPONSES CORRECT` |

In all three, the traffic line should read about 2,688 B read and 2,688 B written per command.

**Back-to-back runs on one bitstream are safe.** XRT keeps the xclbin loaded between host processes.
Every `host_doma` run starts with an init launch (`size = 0`), and that launch re-boots the kernel, as
DOMA's does:
* Tiny ORAM and the adapter are reset, which clears its PosMap, PLB and stash;
* the tree buffer of the new process is latched;
* the first preload launch zero-fills the tree again.

So each run starts from a fresh ORAM, wherever its buffer lands. Error `0x20` now means only that a
launch with commands named a different buffer than the run's init launch, which `host_doma` never does.
If it shows up, stop and tell me.

## Phase 4: 1M records at 64 B, 8 per block

1M records at 8 per block is 125,000 blocks, which gives L = 15 (131,072 blocks) and a 31.5 MB tree,
within one HBM bank. Tiny ORAM's PosMap recursion is active at this size: 4 levels, with its PLB.

### 4.1 Timing check of this geometry

In the second copy of the package:

```bash
cd ~/fpga_tiny64_l15/fpga_zcu208/vitis
bash ../tinyoram/fetch_tinyoram.sh 64 15
vivado -mode batch -nojournal -nolog -source synth_ooc_tinyoram.tcl            # -> ooc_tinyoram_64B_L15_300mhz/
```

Expected first line: `tinyoram_kernel: 64-byte blocks, L=15, 1:1 adapter, 300 MHz -> ooc_tinyoram_64B_L15_300mhz/`.
The PosMap and PLB are larger than at L = 6, so check WNS again. Use the same procedure as 3.2 if it
fails.

### 4.2 Board build and runs

```bash
SIZE=64 N=1000000 PACK=1 TARGET=hw bash build_tinyoram.sh 2>&1 | tee build_tinyoram_64_n1M.log
```

Expected: `Tiny ORAM build: 64-byte blocks, 1000000 records, 125000 blocks -> L=15 (N=131072 blocks), 300 MHz, tag tinyoram_64_n1000000_p8`.
Do the post-placement check as in 3.4, under `_x_tinyoram_64_n1000000_p8/`.

```bash
DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=64 DOMA_N=1000000 DOMA_PACK=1 DOMA_PAGES_HBM=1 ./host_doma tinyoram_64_n1000000_p8_hw.xclbin 5000
```

Expected:

```
size: 125000 blocks, Tiny ORAM tree for L=15 (N=131072), 64-byte blocks: 31510528 bytes
block: 64 bytes per slot
Tiny ORAM bitstream: N=131072 blocks (L=15), tree 31506816 bytes
records: 1000000 keys of 8 bytes, 8 per block
init: T s (boot + preload of 1000000 keys), preload errors=0x0
query: 5000 commands (2548 GET, 2452 PUT) in T s = Q KQPS
...
ALL RESPONSES CORRECT
```

* The preload is 1,000,000 PUTs of one record each, in launches of 5,000. It is initialization, as for
  DOMA and BOLT, and is not timed as part of the query.
* Traffic: one data path at L = 15 is 16 buckets × 384 B = 6,144 B each way. With PosMap recursion, a
  command also reads and writes paths of the PosMap ORAMs whenever their blocks miss the PLB, so expect
  roughly 11–18 KB each way per command (about 2–3 paths):
  * The kernel testbench at this geometry (`-DTB_HOST_WORDS=1048576`, `+packed=8`, no preload, 100-cycle
    memory, `docs/tinyoram_l15_sim_2026-10-13.txt`) moved 356 read and 356 write beats per command in
    its second launch. That is 11.4 KB each way, 1.85 paths. Latency to write-back acknowledged was
    91..7,829 cycles. The tree there is mostly empty, so this is a lower bound.
  * The core harness at L = 14, fully preloaded (README §9 D), gave 2.9 paths, which is about 17.8 KB at
    L = 15.
  Full preload of 131,072 blocks is too slow to simulate here (hours), so the card gives the real figure.

Then, if time allows:
* **10M records:** `SIZE=64 N=10000000 PACK=1`, which gives L = 19 and a 409 MB tree (408,994,176 B),
  still within one 512 MB HBM bank.
* **100K records:** `SIZE=64 N=100000 PACK=1`, which gives L = 12 and a 3.2 MB tree.

## The tree in host memory

Host memory is enabled on the server (`HOST[0]`, 8 GB). `CFG=tinyoram_host.cfg` puts the tree there
and the tree top (`DOMA_TINY_TOP`) in HBM[8:15] (4 GiB; one bank, HBM[8], before 2026-10-21). The xclbin tag gets `_host`, and the run has no
`DOMA_PAGES_HBM`, so the host allocates the tree as a `host_only` buffer (`build_tinyoram.sh` prints
the run line). The tree is then not limited to one 512 MB HBM bank. Phase 5 uses this configuration.

## Phase 5: the comparison with DOMA (host memory, matched budgets)

The HBM[8] runs above are for bring-up only. Don't compare them with DOMA's host-memory numbers. For
the comparison, the tree lives in host memory (`HOST[0]`, `tinyoram_host.cfg`), with the same
workload as DOMA: 1M × 8-byte records, packed (8 per 64-byte block, L = 15), 20,000 commands, the
shared host and its generator.

### Bitstreams (one package copy each, 64 B, 1M records packed)

| Tag | Build | What it is |
|---|---|---|
| `tinyoram_64_n1000000_p8_host_merge` | `CFG=tinyoram_host.cfg SIZE=64 N=1000000 PACK=1 MERGE=1 TARGET=hw bash build_tinyoram.sh` | **Headline (a).** Merged bursts; position map as published (recursion and PLB). |
| `..._host_merge_flatpm` | the same with `FLATPM=1` | **(b) DOMA's trust assumption.** Flat position map on chip (1 MB), no recursion. |
| `..._host` | the same with `MERGE=0` | The 1:1 adapter, reported alongside. |

For 4 KB blocks: `SIZE=4k N=16384` and `SIZE=4k N=65536` (L = 12 and 14; trees of 0.23 GB and 0.9 GB),
with `CFG=tinyoram_host.cfg MERGE=1`.

### Runs per bitstream: matched on-package budgets, through `scan.sh`

`DOMA_TINY_TOP` puts the tree's top in HBM (the `top` buffer, HBM[8:15] with `tinyoram_host.cfg`, HBM[9] with `tinyoram_hw.cfg`). `DOMA_TINY_TOP=doma:<p>` makes
it the bytes `doma_kernel` keeps on-package at `<p>`% HBM for the same records. The host computes this
from the sizes it gives DOMA's buffers: position map, bucket records, stash and HBM buckets. DOMA's
blocks are 32 bytes by default (`DOMA_MATCH_BLOCK`), packed as `DOMA_PACK` says. For 1M records:

| DOMA point | DOMA on-package | Tiny ORAM top (rounded down to 4 KB) | Share of the 31.5 MB tree |
|---|---|---|---|
| 0% HBM | 8,076,960 B | 8,073,216 B | 25.6% |
| 20% | 10,076,960 B | 10,076,160 B | 32.0% |
| 100% | 18,076,960 B | 18,075,648 B | 57.4% |

For (b), add `DOMA_TINY_FLATPM=1`: the 1 MB on-chip position map (8 bytes per block, 131,072 blocks)
is trusted on-package storage too, so it comes off the top.

`scan.sh` runs each bitstream at four tree-top settings (`TOPS`, default `0 doma:0 doma:20 doma:100`),
in the CSV's `hbm_pct` column:
* `0`: the whole tree in host memory. This is the note's headline comparison with DOMA at 0% HBM.
* `doma:0`, `doma:20`, `doma:100`: the matched budgets.

```bash
cd ~/fpga_tiny64_host_merge/fpga_zcu208/vitis
DOMA_KERNEL=tinyoram_kernel DOMA_PACK=1 NS=1000000 \
    bash scan.sh tinyoram_64_n1000000_p8_host_merge_hw.xclbin 20000
# (b): the same in the flat position map's copy, with DOMA_TINY_FLATPM=1
```

The CSV has DOMA's columns (KQPS, device cycles, latency min/max, completed, errors). Each run's full
output goes to the `.log` next to it. Beyond the lines of 4.2, expect:
* `matched budget: doma_kernel keeps … B on-package …`;
* `placement: tree 31506816 B = <top> B on-package (top buffer) + <rest> B in pages; per record …`;
* `latency: to data ready …, to last write-back beat A..B, to write-back acknowledged …`. A..B is the
  primary figure and the CSV's latency, the same end point as DOMA's arrival mode;
* `latency spread: min …, p50 …, p90 …, p99 …, p99.9 …, max …` and a 16-bin `latency histogram`;
* `traffic: tree (pages + top, both ports) … B read, … B written = … per command`.

DOMA's side, for the same table: `DOMA_PACK=1 NS=1000000 HBMS="0 20 100" bash scan.sh doma_hw.xclbin 20000`
in DOMA's own copy. `DOMA_LAT_HIST=1` adds the same latency spread to its output, but `scan.sh` keeps only
the CSV for DOMA, so run `host_doma` directly for that.

**State with the results:**
* DOMA pads every access to its calibrated budgets; Tiny ORAM has no timing protection. DOMA's
  latencies include that padding and Tiny ORAM's don't.
* In (b), Tiny ORAM's position map is on chip rather than in HBM. That saves it one HBM round trip
  per access compared with DOMA.
* At DOMA's 0% point, DOMA still keeps 8 MB on-package (position map, bucket records, stash). The
  `0` run gives Tiny ORAM none; `doma:0` gives it the same 8 MB as a tree top.

## What to report, per configuration

| Item | Where it comes from |
|---|---|
| Throughput | `query: ... = Q KQPS` (20,000 commands), the CSV's `kqps` |
| Latency | the `latency:` line: data ready; last write-back beat (primary, the CSV's `lat_*`, DOMA's end point); write-back acknowledged (secondary). In cycles; also µs at the achieved clock. |
| Latency spread | the `latency spread:` and `latency histogram` lines |
| Bytes per command | the `traffic:` line (both tree ports together) |
| Memory per record | the `placement:` line (on-package and host-memory bytes per record); for (b) add the 1 MB on-chip position map |
| Achieved clock | `check_timing.sh` (`kernel clock in ...xclbin`) and its WNS |
| Utilization, core plus adapter | `$R/post_place_util_hier.rpt` rows `u_tiny` and `u_adapt` (and the whole `tinyoram_kernel_1`); the routed equivalent is `_x_<tag>/link/vivado/vpl/prj/prj.runs/impl_1/*utilization*routed*.rpt` |
| Initialization time | `init: T s (boot + preload ...)` |
| Configuration | adapter (1:1 or merged), position map (published or flat), `DOMA_TINY_TOP` |

The 1:1 adapter (`MERGE=0`) is Tiny ORAM as built for its DDR3 controller, so every Tiny ORAM memory
command is one 64-byte AXI burst, and the per-transaction cost of host memory is part of its numbers.
The merged adapter is the headline; report both.

## Plaintext tree top (TOP_PLAINTEXT, README §25, 2026-11-01)

Seven new bitstreams: the value-sweep configurations of q8, q10, q11, q15, q13, q14 and q12, each with the same
geometry, merge and run-time depth, plus the plaintext top, at 220 MHz. Queue ids 31–37
(`tinyoram/card/queue_topplain.txt`). The existing entries and their bitstreams are not touched.

| id | name | as | blocks | L_max |
|---|---|---|---|---|
| 31 | 64_n10M_merge_rt_tp | q8 | 64 B, 8-byte records | 19 |
| 32 | 128_n1M_merge_rt_tp | q10 | 128 B | 18 |
| 33 | 256_n1M_merge_rt_tp | q11 | 256 B | 18 |
| 34 | 512_n1M_merge_rt_tp | q15 | 512 B | 18 |
| 35 | 1k_n1M_merge_rt_tp | q13 | 1 KB | 18 |
| 36 | 2k_n1M_merge_rt_tp | q14 | 2 KB | 18 |
| 37 | 4k_n1M_merge_rt_tp | q12 | 4 KB | 18 |

### Install (in `~/tiny`, with no Tiny ORAM queue worker running)

```bash
cd ~/tiny
bash combined/fpga_zcu208/tinyoram/card/queue.sh status | head -1      # must say: no worker running
wget -q -O tinyoram_update_2026-11-01b.zip \
  https://raw.githubusercontent.com/lx1993829-ctrl/cxl_oram/fpga-u55c/tinyoram_update_2026-11-01b.zip
unzip -o -q tinyoram_update_2026-11-01b.zip -d combined/fpga_zcu208
cd combined/fpga_zcu208/tinyoram/card
grep -qE '^3[1-7] ' queue.txt && echo "STOP: ids 31-37 already in queue.txt" || cat queue_topplain.txt >> queue.txt
for d in $(awk '!/^#/ && $1 >= 31 && $1 <= 37 {print "q"$1"_"$2}' queue.txt); do
  mkdir -p ~/tiny/$d
  tar -C ~/tiny/combined --exclude='_x_*' --exclude='*.xclbin' --exclude='.Xil' --exclude='build_tinyoram' \
      -cf - fpga_zcu208 | tar -C ~/tiny/$d -xf -
done
ls -d ~/tiny/q3[1-7]_*                                                  # seven copies
```

* The zip goes over `combined/` only. Your queue.txt keeps its lines (including q15); the seven are appended.
* Do not unzip while a worker runs: bash reads a running script from its file, and a replaced `queue.sh` would break
  the worker.

### Start the builds, two at a time

```bash
cd ~/tiny/combined/fpga_zcu208/tinyoram/card
bash queue.sh start -j 2 31 32 33 34 35 36 37
bash queue.sh status
```

* **Two workers.** Each takes the next pending entry of the list, so at most two Tiny ORAM builds run at once.
* **Each entry:**
  * the one-minute elaboration;
  * the out-of-context place and route at 220 MHz (about an hour). A failure stops that entry with the reachable
    clock;
  * the board build, with the post-placement check.
* `bash queue.sh pause` lets both finish their current entry; `bash queue.sh stop` stops them now.
* **What to send back:** `bash queue.sh status`, and for any FAILED entry its log (`queue.sh log <id>`).

### Runs (after the entries are DONE), 1M requests

```bash
cd ~/tiny/combined/fpga_zcu208/tinyoram/card
# 64 B: the N sweep, 100K, 1M and 10M records (8-byte records packed 8 per block, as q8); its 1M point is the value
# sweep's 64 B point
CMDS=1000000 bash sweep_tiny.sh 31
# value sweep: 1M records at 128 B to 4 KB
CMDS=1000000 RT_NS=1000000 bash sweep_tiny.sh 32 33 34 35 36
CMDS=1000000 RT_NS=1000000 TOPS="0 doma:0 doma:20 doma:50" bash sweep_tiny.sh 37
python3 merge_results.py
```

* **TOPS:** default `0 doma:0 doma:20 doma:50 doma:100`.
  * `0` puts no tree top, so it must give what q8–q15 give: the same traffic and cycles, within run-to-run noise.
  * At 4 KB `doma:100` is left out: its 5.8 GiB top does not fit the top buffer (`HBM[8:15]`, 4 GiB).
* **Results:** `~/tiny/results/tiny_q3*_*.csv` and `.log`.
  * Each log has `Tiny ORAM bitstream: the tree top (DOMA_TINY_TOP) is stored in plaintext (TOP_PLAINTEXT)`.
  * `merge_results.py` labels these rows "plaintext tree top".
* **Pass:** `sweep_tiny.sh` prints `PASS: every row measured, errors 0x0, all responses correct` per entry.

## Tree ORAM for the reviewer (position map in HBM, README §26, 2026-11-05)

Two new bitstreams: Tiny ORAM at 4 KB with the flat position map in HBM (patch 10) and the plaintext top (patch 09),
merged bursts, native depth, 220 MHz, linked with `tinyoram_host_pm.cfg`. Queue ids 38 and 39
(`tinyoram/card/queue_pmhbm.txt`). Existing entries, copies and bitstreams are not touched.

| id | name | records | L | tree | top at r = 0 … 100% |
|---|---|---|---|---|---|
| 38 | 4k_n1M_merge_hbmpm_tp | 1,048,576 | 18 | 13.4 GiB | 1.00 … 5.57 GiB |
| 39 | 4k_n256K_merge_hbmpm_tp | 262,144 | 16 | 3.4 GiB | 0.26 … 1.40 GiB |

### Install (in `~/tiny`, with no Tiny ORAM queue worker running)

If ids 31–37 are still building, `bash queue.sh pause` lets the two current entries finish and stops there; install
after `queue.sh status` says no worker is running. Ids 38 and 39 can then go first.

```bash
cd ~/tiny
bash combined/fpga_zcu208/tinyoram/card/queue.sh status | head -1      # must say: no worker running
wget -q -O tinyoram_update_2026-11-05.zip \
  https://raw.githubusercontent.com/lx1993829-ctrl/cxl_oram/fpga-u55c/tinyoram_update_2026-11-05.zip
unzip -o -q tinyoram_update_2026-11-05.zip -d combined/fpga_zcu208
cd combined/fpga_zcu208/tinyoram/card
grep -qE '^3[89] ' queue.txt && echo "STOP: ids 38-39 already in queue.txt" || cat queue_pmhbm.txt >> queue.txt
for d in $(awk '!/^#/ && ($1 == 38 || $1 == 39) {print "q"$1"_"$2}' queue.txt); do
  mkdir -p ~/tiny/$d
  tar -C ~/tiny/combined --exclude='_x_*' --exclude='*.xclbin' --exclude='.Xil' --exclude='build_tinyoram' \
      -cf - fpga_zcu208 | tar -C ~/tiny/$d -xf -
done
ls -d ~/tiny/q3[89]_*                                                   # two copies
```

### Build, two at a time

```bash
cd ~/tiny/combined/fpga_zcu208/tinyoram/card
bash queue.sh start -j 2 38 39
bash queue.sh status
```

* Each entry: elaboration, out-of-context place and route at 220 MHz, the board build. A failure stops that entry
  with the reachable clock (`queue.sh log <id>`).
* To continue ids 31–37 afterwards: `bash queue.sh start -j 2 31 32 33 34 35 36 37` (finished ones are skipped).

### Runs (after 38 and 39 are DONE)

```bash
cd ~/tiny/combined/fpga_zcu208/tinyoram/card
bash sweep_tiny.sh 38 39                       # Tiny ORAM: doma:0/20/50/100 (v14c-matched), 20,000 commands
bash compare_pmhbm.sh find                     # lists your DOMA builds; USE marks the v14c FIXWB=1 2M one
bash compare_pmhbm.sh doma                     # DOMA v14c from that build: 256K, 1M, 2M at r = 0/20/50/100
bash compare_pmhbm.sh report | tee ~/tiny/results/report_pmhbm.txt
```

* **DOMA side:** `find` looks under your home folder for every `vitis/doma_hw.xclbin` and reads the
  `rtl/oram_build_cfg.vh` beside it. `USE` marks a build with `FIXWB=1`, `LAMBDA=7`, `NMAX=2097152`, arrival
  scheduling and no overlap, debug, trace, interim or plain-core option, with its `host_doma` built. `doma` takes the
  one marked build; if there are none or several, it stops and asks for `DOMA_VITIS=<that vitis folder>` (and
  `DOMA_XCLBIN=<name>` if the bitstream is not `doma_hw.xclbin`). It runs v14c's own host with `DOMA_LAMBDA=7` at
  N = 256K, 1M and 2M, r = 0/20/50/100, and writes `~/tiny/results/doma_v14c_pmhbm.log`. Nothing is rebuilt.
* **Host memory.** Tiny ORAM's pages hold the tree below the top: 12.4 GiB at 1M and r = 0, 7.9 GiB at r = 100. If
  the `doma:0` run of q38 says `cannot allocate the tree buffer`, the card's host-memory window is smaller than that;
  send the line (do not change the card's settings).
* **Each log** has `Tiny ORAM bitstream: the flat position map in HBM (posmap, ... entries of 8 bytes)`,
  `matched budget: doma_kernel v14c (Z=8, lambda=7) ...`, `less Tiny ORAM's HBM position map`, and
  `pages holds the tree below the top`.
* **Pass:** `sweep_tiny.sh` prints `PASS: every row measured, errors 0x0, all responses correct` for both entries;
  `compare_pmhbm.sh doma` prints `PASS: every DOMA run clean`.
* **What to send back:** `~/tiny/results/report_pmhbm.txt`, `~/tiny/results/tiny_q38_*.log`, `tiny_q39_*.log` and
  `doma_v14c_pmhbm.log`.

## One 64-byte build for the N table (run-time depth with the map in HBM, README §27, 2026-11-06)

Queue id 50 (`tinyoram/card/queue_rthbm.txt`): 64-byte blocks, run-time depth up to L_max = 19, map in HBM, plaintext
top, 200 MHz. `tinyoram/card/sweep64_table.sh` runs the table (N = 100K, 500K, 1M, 2M with their tops) on it. For each
row it prints, and logs, the queue id, the bitstream, its clock, and that the bitstream has the posmap argument. The
host reports the depth it ran ("running at L=...") and "the flat position map in HBM".
