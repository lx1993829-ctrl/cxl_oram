#!/bin/bash
# run_tinyoram_topplain.sh -- regression for the plaintext tree top (TOP_PLAINTEXT, patch 09; README §25).
#   bash run_tinyoram_topplain.sh            all stages, seven block sizes (about 4 hours on 2 cores)
#   SZS="64 4k" STAGES="1 2 3" ...           fewer sizes or stages; logs and the table in build_tinyoram/topplain/
# Needs Verilator 5, iverilog and python3 with the "cryptography" package (the memory inspection decrypts AES).
#  1. Default build unchanged: with patches 01-08 and with 01-09, every core file patch 09 touches preprocesses to the
#     same source when TINYORAM_TOP_PLAINTEXT is not defined: 7 sizes x 1:1/merged x native/run-time depth.
#  2. Lint (lint_tinyoram.sh) of the TOP_PLAINTEXT sources: each size at L = 10 and at the queue's L_max (18; 64 B: 19),
#     merged, the run-time-depth ones as built.
#  3. Per size, native L = 10, merged: the default build (d) and the TOP_PLAINTEXT build (p), the same commands (a
#     preload of all 4,096 blocks at 64-512 B, then 300 commands, 50% PUTs, uniform keys: README §24's runs):
#       nosplit  no tree top: d and p identical (every per-launch line, every bus burst in the same cycle, both buffers'
#                final bytes);
#       d20      the top at doma:20's share of the size's 1M-record tree (as the host sizes it): both correct; memory
#                inspection (sim/topplain/inspect_tree.py): top buckets plaintext and equal to d's decrypted, every
#                other bucket byte-identical to d's and decrypting to a sane bucket, every data block = its last PUT;
#       all      the whole tree on package: the same; and the cycles equal README §24's measurement (d: as shipped;
#                p: every bucket in plaintext with no added latency).
#  4. The queue's configuration: the run-time-depth TOP_PLAINTEXT build (L_max 18; 64 B: 19), run at L = 10 with the
#     doma:20 split, issues the same bursts in the same cycles with the same bytes as the native L = 10 p build.
#  5. Mutants, each must fail stage 3's d20 checks: at 64 B, m1 the IV counter not advanced for top buckets; m2 top
#     buckets encrypted after all (write-back flags lost); at 2 KB, m4 each bucket's flag taken at its last read
#     command (too late: the bucket's data comes back first). The write-back gate has no mutant: in this design the
#     stash never offers a beat past a write-back's end (README §25), so removing the gate changes nothing.
# Exit 0 = every check passed; last line "ALL n CHECKS PASSED".
set -u
cd "$(dirname "$0")"
TOR=$(cd ../tinyoram && pwd)
B=${TP_DIR:-build_tinyoram/topplain}; mkdir -p $B
[ -f $TOR/upstream/TinyORAMCore.v ] || bash $TOR/fetch_tinyoram.sh 4k > /dev/null || exit 2
VFLAGS="--binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-WIDTH -Wno-ZERODLY -Wno-BLKANDNBLK"
SZS=${SZS:-"64 128 256 512 1k 2k 4k"}; STAGES=${STAGES:-"1 2 3 4 5"}; L=10
FAILS=0; NCHK=0
pass() { echo "  PASS  $1"; NCHK=$((NCHK+1)); }
fail() { echo "  FAIL  $1"; FAILS=$((FAILS+1)); NCHK=$((NCHK+1)); }
has() { case " $STAGES " in *" $1 "*) return 0 ;; esac; return 1; }
bytes() { case $1 in 1k) echo 1024 ;; 2k) echo 2048 ;; 4k) echo 4096 ;; *) echo $1 ;; esac; }
# doma:20 share of the Tiny ORAM tree at 1M records (the matched budget of host_doma.cpp over the tree, 1 record per block; 64 B: 8-byte
# records packed 8 per block, q8's 1M point), applied to the L = 10 tree
share() { case $1 in 64) echo 320 ;; 128) echo 164 ;; 256) echo 218 ;; 512) echo 197 ;; 1k) echo 193 ;; 2k) echo 137 ;; 4k) echo 129 ;; esac; }
# README §24's run1 device cycles at the whole tree on package (as shipped / every bucket plaintext, zero latency)
p1() { case $1 in 64) echo "255501 242828" ;; 128) echo "357664 345436" ;; 256) echo "575953 563533" ;; 512) echo "1024482 1011994" ;;
       1k) echo "881978 878394" ;; 2k) echo "1653046 1648347" ;; 4k) echo "3255722 3253423" ;; esac; }
fetch_geo() {   # fetch_geo <dir> <fetch args...>: a private fetch (the shared ../tinyoram/build is left alone)
    local d=$1; shift; rm -rf $d; mkdir -p $d
    cp $TOR/fetch_tinyoram.sh $d/ && cp -r $TOR/config $TOR/patches $d/ && ln -s $(cd $TOR && pwd)/upstream $d/upstream
    bash $d/fetch_tinyoram.sh "$@" > $d/fetch.log 2>&1
}
mk() {   # mk <name> <tree words> <nmax> <fetch args...>   (MUT=<python edit of AESPathORAM.v> for a mutant)
    local name=$1 W=$2 nmax=$3; shift 3; local g=$B/$name sz=$1
    local cw=$((1 << 18)); [ $sz = 2k ] && cw=$((1 << 19)); [ $sz = 4k ] && cw=$((1 << 20))
    [ -x $g/obj/Vtb ] && [ -z "${REBUILD:-}" ] && return 0
    fetch_geo $g "$@" || { echo "  FETCH FAILED: $name ($g/fetch.log)"; exit 2; }
    if [ -n "${MUT:-}" ]; then python3 -c "$MUT" $g/build/src/AESPathORAM.v || { echo "  MUTANT NOT APPLIED: $name"; exit 2; }; fi
    echo "  building $name ..."
    verilator $VFLAGS -I$g/build/src -DSIMULATION -DTB_HOST_WORDS=$W -DTB_TOP_WORDS=$W -DTB_NMAX=$nmax -DTB_CMD_WORDS=$cw \
        --top-module tb_tinyoram_kernel ./tb_tinyoram_kernel.v ./axi_mem_model.v \
        $TOR/rtl/tinyoram_kernel.v $TOR/rtl/tinyoram_axi_adapter.v $(sed "s#^#$g/build/src/#" $g/build/src/files.f | tr '\n' ' ') \
        -Mdir $g/obj -o Vtb > $g/build.log 2>&1 || { echo "  BUILD FAILED: $name ($g/build.log)"; exit 2; }
}
run() { local name=$1 tag=$2; shift 2; ( ulimit -s unlimited 2>/dev/null; ./$B/$name/obj/Vtb +hb=0 +limit=2000000000 "$@" > $B/$tag.log 2>&1 ); }
ok() { grep -q "TINYORAM KERNEL: ALL CHECKS PASSED" $B/$1.log && ! grep -qE "ERROR|Error:" $B/$1.log; }
lines() { grep -E "^[a-z0-9]+: (size=|latency to|traffic record)|^read-behind-write hold" $B/$1.log; }
dev() { grep -E "^$2: size=" $B/$1.log | sed -E 's/.*device total=([0-9]+).*/\1/'; }
words() { [ $1 = 4k ] && echo 2097152 || echo 1048576; }
inspect() {   # inspect <size> <d tag> <p tag>
    python3 ./topplain/inspect_tree.py $(bytes $1) $L $B/$2 $B/$3 > $B/$3.inspect 2>&1
}

if has 1; then
echo "== 1. patch 09 without TINYORAM_TOP_PLAINTEXT: the core preprocesses as before"
W=$(mktemp -d); trap 'rm -rf "$W"' EXIT
for t in p8 p9; do
    cp -rL $TOR/upstream $W/$t
    for p in $TOR/patches/0[1-8]*.diff; do (cd $W/$t && patch -s -p1 < $p) || { echo "patch $p failed"; exit 2; }; done
done
(cd $W/p9 && patch -s -p1 < $TOR/patches/09_top_plaintext.diff) || { echo "patch 09 failed"; exit 2; }
files=$(grep -E '^\+\+\+ b/.*\.v$' $TOR/patches/09_top_plaintext.diff | sed -E 's#^\+\+\+ b/##; s#\t.*##')
norm() { python3 -c '
import re, sys
s = open(sys.argv[1]).read()
s = re.sub(r"/\*.*?\*/", " ", s, flags=re.S); s = re.sub(r"//[^\n]*", " ", s)
s = re.sub(r"\s+", " ", s); s = re.sub(r" ?([()\[\],;{}=:]) ?", r"\1", s); print(s.strip())' "$1"; }
bad=""; n=0
for sz in 64 128 256 512 1k 2k 4k; do for mg in 0 1; do for rt in 0 1; do
    mkdir -p $W/cfg; cp $TOR/config/tinyoram_config_$sz.vh $W/cfg/tinyoram_config.vh
    [ $mg = 1 ] && sed -i 's#^`endif#`define TINYORAM_MERGE 1\n`endif#' $W/cfg/tinyoram_config.vh
    [ $rt = 1 ] && sed -i 's#^`endif#`define TINYORAM_RTDEPTH 1\n`endif#' $W/cfg/tinyoram_config.vh
    for f in $files; do
        n=$((n+1))
        for t in p8 p9; do iverilog -E -I$W/cfg -I$W/$t/include -o $W/$t.E $W/$t/$f 2>/dev/null || bad="$bad $f($t,E)"; norm $W/$t.E > $W/$t.N; done
        cmp -s $W/p8.N $W/p9.N || bad="$bad $f($sz,m$mg,rt$rt)"
    done
done; done; done
[ -z "$bad" ] && pass "patch 09 without the define: $(echo $files | wc -w) core files x 28 configurations ($n comparisons), preprocessed sources identical" \
              || fail "patch 09 changes the default core:$bad"
fi

if has 2; then
echo "== 2. lint of the TOP_PLAINTEXT sources"
for sz in $SZS; do for v in "$L:merge topplain" "18:merge rtdepth topplain"; do
    l=${v%%:*}; o=${v#*:}; [ $sz = 64 ] && [ $l = 18 ] && l=19
    t=${sz}_L${l}; [ $l != $L ] && t=${t}_rt; g=$B/geo_$t
    if ! fetch_geo $g $sz $l $o; then fail "$sz B L=$l ($o): fetch ($g/fetch.log)"; continue; fi
    bash ./lint_tinyoram.sh $g/build/src $g/build/src/tinyoram_config.vh $B/lint_$t > $B/lint_$t.out 2>&1 \
        && pass "$sz B, L=$l, $o: lint, every module ($(tail -1 $g/fetch.log | sed -E 's/.*configuration //'))" \
        || { fail "$sz B L=$l $o: lint ($B/lint_$t.out)"; sed 's/^/        /' $B/lint_$t.out | head -8; }
done; done
fi

if has 3; then
echo "== 3. default against TOP_PLAINTEXT, native L = $L, merged"
for sz in $SZS; do mk d_$sz $(words $sz) $((4 << L)) $sz $L merge & mk p_$sz $(words $sz) $((4 << L)) $sz $L merge topplain & wait; done
echo "size split | d cycles/cmd | p cycles/cmd | saved | % | preload d/p | inspection" > $B/table.txt
for sz in $SZS; do
    pre=""; case "$sz" in 64|128|256|512) pre=+preload ;; esac
    for split in nosplit d20 all; do
        case $split in
            nosplit) sa="" ;;
            all) sa=+top_all ;;
            d20) tree=$(grep -m1 -oE "tree=[0-9]+ bytes" $B/d_${sz}_nosplit.log | grep -oE "[0-9]+"); sa=+top=$(( tree * $(share $sz) / 1000 / 4096 * 4096 )) ;;
        esac
        tr=""; [ $split = nosplit ] && tr=+axitrace
        run d_$sz d_${sz}_$split $sa $pre $tr +cmds=300 +cmds2=0 +dumpmem=$B/d_${sz}_$split &
        run p_$sz p_${sz}_$split $sa $pre $tr +cmds=300 +cmds2=0 +dumpmem=$B/p_${sz}_$split & wait
        lab="$sz B, $split${sa:+ ($sa)}"
        if ! ok d_${sz}_$split || ! ok p_${sz}_$split; then
            fail "$lab: not every response correct ($B/d_${sz}_$split.log, $B/p_${sz}_$split.log)"; continue; fi
        dc=$(dev d_${sz}_$split run1); pc=$(dev p_${sz}_$split run1)
        dp=$(dev d_${sz}_$split preload); pp=$(dev p_${sz}_$split preload)
        if [ $split = nosplit ]; then
            why=""
            cmp -s <(lines d_${sz}_$split) <(lines p_${sz}_$split) || why="per-launch lines differ"
            [ -z "$why" ] && { cmp -s <(grep "^T " $B/d_${sz}_$split.log) <(grep "^T " $B/p_${sz}_$split.log) || why="bus bursts differ"; }
            [ -z "$why" ] && { cmp -s $B/d_${sz}_${split}_host.hex $B/p_${sz}_${split}_host.hex || why="tree bytes differ"; }
            [ -z "$why" ] && pass "$lab: every response correct; TOP_PLAINTEXT identical to the default ($(grep -c '^T ' $B/d_${sz}_$split.log) bursts, same cycles, same tree bytes)" \
                          || fail "$lab: $why"
            echo "$sz $split | $(awk -v c=$dc 'BEGIN{printf "%.1f", c/300}') | $(awk -v c=$pc 'BEGIN{printf "%.1f", c/300}') | 0.0 | 0.00 | ${dp:--}/${pp:--} | identical" >> $B/table.txt
            rm -f $B/*_${sz}_${split}_*.hex
            continue
        fi
        if inspect $sz d_${sz}_$split p_${sz}_$split; then pass "$lab: every response correct; $(tail -1 $B/p_${sz}_$split.inspect | sed -E 's/^inspect [^:]+: //')"
        else fail "$lab: memory inspection ($B/p_${sz}_$split.inspect)"; sed 's/^/        /' $B/p_${sz}_$split.inspect | head -5; fi
        if [ $split = all ]; then
            read -r e_d e_p <<< "$(p1 $sz)"
            [ "$dc" = "$e_d" ] && [ "$pc" = "$e_p" ] && pass "$lab: README §24 reproduced: run1 $dc / $pc device cycles (as shipped / plaintext)" \
                || fail "$lab: run1 $dc / $pc device cycles, README §24 measured $e_d / $e_p"
        fi
        echo "$sz $split | $(awk -v c=$dc 'BEGIN{printf "%.1f", c/300}') | $(awk -v c=$pc 'BEGIN{printf "%.1f", c/300}') | $(awk -v a=$dc -v b=$pc 'BEGIN{printf "%.1f | %.2f", (a-b)/300, 100*(a-b)/a}') | ${dp:--}/${pp:--} | $(tail -1 $B/p_${sz}_$split.inspect | grep -oE '[0-9]+ top buckets plaintext|[0-9]+ off-top buckets' | tr '\n' ' ')" >> $B/table.txt
        rm -f $B/*_${sz}_${split}_*.hex
    done
done
echo; cat $B/table.txt
fi

if has 4; then
echo "== 4. the queue's configuration: run-time depth (L_max 18; 64 B: 19), TOP_PLAINTEXT, against the native L = $L build"
for sz in $SZS; do
    lm=18; [ $sz = 64 ] && lm=19
    mk p_$sz $(words $sz) $((4 << L)) $sz $L merge topplain
    mk r_$sz $(words $sz) $((4 << L)) $sz $lm merge rtdepth topplain
    tree=$(grep -m1 -oE "tree=[0-9]+ bytes" $B/p_${sz}_nosplit.log 2>/dev/null | grep -oE "[0-9]+")
    [ -z "$tree" ] && { run p_$sz p_${sz}_geo +cmds=1 +cmds2=0; tree=$(grep -m1 -oE "tree=[0-9]+ bytes" $B/p_${sz}_geo.log | grep -oE "[0-9]+"); }
    sa=+top=$(( tree * $(share $sz) / 1000 / 4096 * 4096 ))
    c="+cmds=40"; case $sz in 1k|2k|4k) c="+cmds=20" ;; 64) c="+preload +cmds=100" ;; esac   # 64 B: full paths, the write-back gate at L_max's geometry
    run p_$sz pn_$sz $sa +axitrace $c +cmds2=0 & run r_$sz pr_$sz +rtl=$L $sa +axitrace $c +cmds2=0 & wait
    why=""
    ok pn_$sz || why="native fails ($B/pn_$sz.log)"
    [ -z "$why" ] && { ok pr_$sz || why="run-time build fails ($B/pr_$sz.log)"; }
    [ -z "$why" ] && { cmp -s <(lines pn_$sz) <(lines pr_$sz) || why="per-launch lines differ"; }
    [ -z "$why" ] && { cmp -s <(grep "^T " $B/pn_$sz.log) <(grep -E "^T " $B/pr_$sz.log) || why="bus bursts differ"; }
    [ -z "$why" ] && { cmp -s <(grep "tree data hash" $B/pn_$sz.log) <(grep "tree data hash" $B/pr_$sz.log) || why="block bytes differ"; }
    [ -z "$why" ] && pass "$sz B, L=$L on L_max=$lm, TOP_PLAINTEXT, top $sa: both correct and identical ($(grep -c '^T ' $B/pn_$sz.log) bursts)" \
                  || fail "$sz B, L=$L on L_max=$lm, TOP_PLAINTEXT: $why"
done
fi

if has 5; then
echo "== 5. mutants (64 B, the d20 split): each must be caught"
mk d_64 1048576 $((4 << L)) 64 $L merge
tree=$(grep -m1 -oE "tree=[0-9]+ bytes" $B/d_64_nosplit.log 2>/dev/null | grep -oE "[0-9]+"); tree=${tree:-835968}
sa=+top=$(( tree * $(share 64) / 1000 / 4096 * 4096 ))
[ -f $B/d_64_d20_host.hex ] || run d_64 d_64_d20 $sa +preload +cmds=300 +cmds2=0 +dumpmem=$B/d_64_d20
ED='import sys; p = sys.argv[1]; s = open(p).read(); o, n = %s; assert s.count(o) == 1; open(p, "w").write(s.replace(o, n))'
M1=$(printf "$ED" "'.Enable((RW == PATH_WRITE) & IsIV & DataInValid & DataInReady & ~tp_wdone)', '.Enable((RW == PATH_WRITE) & IsIV & DataInValid & DataInReady & ~tp_wdone & ~tp_in)'")
M2=$(printf "$ED" "'if (tp_rq_pop)  tp_wq[tp_wq_wp] <= tp_rq_head;', 'if (tp_rq_pop)  tp_wq[tp_wq_wp] <= 1\\'b0;'")
for m in 1 2; do
    eval "mut=\$M$m"
    MUT="$mut" mk m${m}_64 1048576 $((4 << L)) 64 $L merge topplain
    run m${m}_64 m${m}_64_d20 $sa +preload +cmds=300 +cmds2=0 +dumpmem=$B/m${m}_64_d20
    if ok m${m}_64_d20 && inspect 64 d_64_d20 m${m}_64_d20; then fail "mutant m$m not caught"
    else
        w="responses or checks fail"; ok m${m}_64_d20 && w="inspection: $(grep -m1 FAIL $B/m${m}_64_d20.inspect | sed 's/^ *FAIL *//')"
        ok m${m}_64_d20 || w="$(grep -m1 -E 'FAIL|ERROR' $B/m${m}_64_d20.log | cut -c1-110)"
        pass "mutant m$m caught: $w"
    fi
    rm -f $B/m${m}_64_d20_*.hex
done
rm -f $B/d_64_d20_*.hex
# m4 (2 KB): each bucket's flag taken at its last read command, as first written: a 2 KB bucket's data comes back
# before its last command is issued
M4=$(printf "$ED" "'wire                         tp_rq_push = tp_cmd_rd & tp_cmd_first;', 'wire                         tp_rq_push = tp_cmd_rd & tp_cmd_last;'")
MUT="$M4" mk m4_2k 1048576 $((4 << L)) 2k $L merge topplain
tree=$(grep -m1 -oE "tree=[0-9]+ bytes" $B/d_2k_nosplit.log 2>/dev/null | grep -oE "[0-9]+"); tree=${tree:-21906560}
run m4_2k m4_2k_d20 +top=$(( tree * $(share 2k) / 1000 / 4096 * 4096 )) +cmds=300 +cmds2=0
ok m4_2k_d20 && fail "mutant m4 not caught" || pass "mutant m4 caught: $(grep -m1 -E 'FAIL|ERROR' $B/m4_2k_d20.log | cut -c1-110)"
fi

[ $FAILS = 0 ] && { echo "ALL $NCHK CHECKS PASSED"; exit 0; }
echo "$FAILS OF $NCHK CHECKS FAILED"; exit 1
