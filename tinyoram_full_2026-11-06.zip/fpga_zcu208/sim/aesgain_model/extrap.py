# Card-geometry estimate from the L = 10 runs (numbers from build_tinyoram/aesgain/table.txt of 2026-11-01). README §24.
# Run from this directory: python3 extrap.py
import toppaths as t, budgets as b
# run1 at L = 10, whole tree on the top port (aes / plain cycles, read beats), from summary.txt / table.txt
rows = {64: (255501, 242828, 69432), 128: (357664, 345436, 112640), 256: (575953, 563533, 207108), 512: (1024482, 1011994, 397936)}
X = []; Y = []; S = []
for blk, (ca, cp, rb) in rows.items():
    g = t.geo(blk, 10); pb = 11 * g['bkt'] * 2; paths = rb / pb
    X.append(pb); Y.append(ca / paths); S.append((ca - cp) / paths)
    print(f"{blk:5} B L=10: path {pb} beats, {paths:.0f} paths, {ca/paths:7.1f} cycles/path, saved {(ca-cp)/paths:5.1f}/path = {100*(ca-cp)/ca:4.2f}%/cmd")
n = len(X); mx = sum(X)/n; my = sum(Y)/n
a = sum((x-mx)*(y-my) for x, y in zip(X, Y)) / sum((x-mx)**2 for x in X); c = my - a*mx; s = max(S)
print(f"fit: cycles/path = {a:.3f} * beats + {c:.0f}; saving per path (max) {s:.1f}")
print("\nL=18 (1M records): whole tree | doma:20 top-only | doma:100 top-only")
for blk in (64, 128, 256, 512, 1024, 2048, 4096):
    g = t.geo(blk, 18); pb = 19 * g['bkt'] * 2; T = a*pb + c; w = 100*s/T
    out = f"{blk:5} B: path {pb:5} beats, ~{T:6.0f} cycles/path, whole tree {w:4.2f}%"
    for pct in (20, 100):
        top = min(b.onpkg(1000000, blk, 1, pct) & ~4095, g['tree']); f = t.frac_full(blk, 18, top)
        out += f" | doma:{pct}: {100*f:5.1f}% paths on package -> {f*w:4.2f}%"
    print(out)
