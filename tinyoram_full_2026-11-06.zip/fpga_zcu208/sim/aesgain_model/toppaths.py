# Tiny ORAM bucket address map (AddrGenBktHead.v, PathGen.v, AddrGen.v) and the share of paths entirely in a tree top. README §24.
# python3 toppaths.py check: matches a path of the L = 10, 64 B bus trace.
# Model of Tiny ORAM's bucket address map (AddrGenBktHead.v + PathGen.v + AddrGen.v) and of the matched budgets
import math, sys
Z, U, E, H = 4, 32, 64, 128
def geo(block, L):
    hdr = E + 8 * ((Z + 7) // 8) + U * Z + L * Z + H * Z
    bkt = (hdr + 511) // 512 + Z * ((block * 8 + 511) // 512)        # bursts per bucket
    words = bkt * 8; x = 8192 // words + 1
    lst = 0
    while (2 << lst) <= x: lst += 1
    lst = max(lst, 1)
    nst = (L + 1 + lst - 1) // lst
    tot = ((1 << (nst * lst)) - 1) // ((1 << lst) - 1)
    tree = 64 * ((1 << (L + 1)) + tot) * bkt
    ntall = ((1 << ((nst - 1) * lst)) - 1) // ((1 << lst) - 1)
    return dict(bkt=bkt, lst=lst, nst=nst, ntall=ntall, tree=tree, lpad=nst * lst, lsb=(L + 1) % lst)
def path(leaf, L, g):
    lst, ntall, lpad, lsb = g['lst'], g['ntall'], g['lpad'], g['lsb']
    st = [0, 0, 0]; bk = [0, 0, 0]; lvl = 0; lin = 0; ls = leaf; out = []
    for k in range(L + 1):
        stidx, bin_ = st[0], None
        short = lpad != L + 1 and lvl + lst >= lpad
        idx = bk[0] + (((ntall << lst) + ((stidx - ntall) << lsb)) if short else (stidx << lst))
        out.append(idx * g['bkt'] * 64)
        b = ls & 1; sw = lin >= lst - 1
        if sw: n = (st[1] << 1) + (st[2] << 1) + b + 1; st = [n, n, 0]
        else: st = [st[0], st[1] << 1, (st[2] << 1) + b]
        if sw: bk = [0, 0, 0]
        else: n = (bk[1] << 1) + (bk[2] << 1) + b + 1; bk = [n, n, 0]
        lvl += 1; lin = 0 if sw else lin + 1; ls >>= 1
    return out
def frac_full(block, L, top):
    g = geo(block, L); B = g['bkt'] * 64; n = 1 << L
    import random
    rng = random.Random(1)                                              # uniform leaves (the root takes leaf bit 0)
    leaves = range(n) if n <= 65536 else (rng.randrange(n) for _ in range(65536))
    full = tot = 0
    for leaf in leaves:
        tot += 1; full += max(path(leaf, L, g)) + B <= top
    return full / tot
if __name__ == '__main__' and sys.argv[1:] == ['check']:
    g = geo(64, 10)                                  # a path from the bus trace (64 B, L = 10, top 120 KB)
    want = [0, 0x180, 0x480, 0xa80, 0x1800, 0x3180, 0x6600, 0x1c800, 0x1cb00, 0x1d100, 0x1dd00]
    m = [leaf for leaf in range(1 << 10) if path(leaf, 10, g) == want]
    print("tree", g['tree'], "bytes (kernel: 835968); traced path matches leaf", m)
