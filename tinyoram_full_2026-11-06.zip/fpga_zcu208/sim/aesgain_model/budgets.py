# doma_kernel on-package bytes (a copy of host_doma.cpp doma_onpkg_bytes) and, run alone, the matched tops at L = 18. README §24.
import math, toppaths as t
LAMBDA, ZPOS = 8, 10
def ln_mgf_A(tt, Bk, n):
    p = 1.0 / Bk; lr = math.log1p(-p) + tt
    if abs(lr) < 1e-15: return math.log(p * n + 1.0)
    if lr > 0:
        lrn = n * lr
        if lrn > 700: return math.inf
        return math.log(p * math.expm1(lrn) / math.expm1(lr) + math.exp(lrn))
    rn = math.exp(n * lr); return math.log(p * (1 - rn) / (-math.expm1(lr)) + rn)
def xR(Bk, n, lg):
    best = math.inf
    for i in range(1, 400):
        u = i * 0.005; v = ln_mgf_A(math.expm1(u) / Bk, Bk, n)
        if not math.isfinite(v): break
        best = min(best, (Bk * v + lg) / u)
    return best
def xO(Bk, lam, Z, lg):
    best = math.inf
    for i in range(1, 400):
        u = i * 0.01; lt = [-lam + k * math.log(lam) - math.lgamma(k + 1.0) + u * max(0, k - Z) for k in range(160)]
        mx = max(lt); s = sum(math.exp(x - mx) for x in lt)
        best = min(best, (Bk * (mx + math.log(s)) + lg) / u)
    return best
def stash_bound(n, lam, Z):
    Bk = math.ceil(n / lam); G = 64 * math.log(2.0)
    return min(xR(Bk, n, G - math.log(f)) + xO(Bk, lam, Z, G - math.log(1 - f)) for f in (0.1, 0.3, 0.5, 0.7, 0.9))
def r4k(x): return (x + 4095) & ~4095
def onpkg(nrec, block, pack, pct):
    nblk = (nrec + pack - 1) // pack; nb = (nblk + LAMBDA - 1) // LAMBDA
    pool = int(min(nblk, math.ceil(stash_bound(nblk, LAMBDA, ZPOS)) + math.ceil(0.01 * nblk) + 64))
    hbmk = nb * pct // 100
    meta = max(4096, ((nblk + 4) // 5) * 32); brec = max(4096, nb * 64)
    stash = r4k(nb * 64) + r4k(pool * 16) + pool * block
    return meta + brec + stash + hbmk * ZPOS * block
if __name__ == '__main__':
    print("size  L  tree(MiB)  | doma:20 top  share  full paths | doma:100 top  share  full paths")
    for blk in (64, 128, 256, 512, 1024, 2048, 4096):
        L = 18; g = t.geo(blk, L); tree = g['tree']
        row = f"{blk:5} {L} {tree/2**20:9.1f}  |"
        for pct in (20, 100):
            top = min(onpkg(1000000, blk, 1, pct) & ~4095, tree)
            row += f" {top/2**20:9.1f} {100*top/tree:5.1f}% {100*t.frac_full(blk, L, top):6.2f}% |"
        print(row, f" L_st={g['lst']}")
