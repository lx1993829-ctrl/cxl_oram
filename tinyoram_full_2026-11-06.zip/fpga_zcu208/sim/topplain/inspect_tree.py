#!/usr/bin/env python3
# inspect_tree.py -- memory inspection for the plaintext tree top (README §25).
#   inspect_tree.py <block bytes> <L> <default prefix> <topplain prefix>
# The prefixes are the testbench's +dumpmem files (<p>_host.hex, <p>_top.hex, <p>_exp.txt) of a default build and a
# TOP_PLAINTEXT build that ran the same commands with the same tree-top split. Checks:
#   1. off-top buckets (host buffer): the TOP_PLAINTEXT build's bytes equal the default build's, every bucket;
#   2. every written bucket of either build decodes: in the top, the TOP_PLAINTEXT build's bucket as plaintext and the
#      default build's after AES-CTR decryption are byte-identical; below it, both decrypt;
#   3. every decoded bucket is sane: each valid block's leaf puts the bucket on that leaf's path, and each valid data
#      block holds exactly the last PUT of its key; every off-top bucket is ciphertext (no beat stored as it
#      decrypts), every top bucket of the TOP_PLAINTEXT build is plaintext (it is sane without decryption).
# Exit 0 when everything holds; the last line says what was checked.
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import toppaths as tp
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

Z, U, E, H = 4, 32, 64, 128
blk, L = int(sys.argv[1]), int(sys.argv[2]); pd, pp = sys.argv[3], sys.argv[4]
g = tp.geo(blk, L)
hdr_bursts = (E + 8 * ((Z + 7) // 8) + U * Z + L * Z + H * Z + 511) // 512
BB = g['bkt'] * 2                       # beats (256 bits) per bucket
HB = hdr_bursts * 2                     # header beats
KB = blk // 32                          # beats per block
W = 1
while (1 << W) < BB: W += 1            # `log2 (ceiling) of the AES chunks per bucket
aes = Cipher(algorithms.AES(b'\xff' * 16), modes.ECB()).encryptor()   # Tiny ORAM ties the key to all ones

def load(path, words):
    m = [0] * words; a = 0
    if not os.path.exists(path): return m
    for line in open(path):
        line = line.strip()
        if not line or line.startswith('//'): continue
        if line.startswith('@'): a = int(line[1:], 16); continue
        if a < words: m[a] = int(line, 16)
        a += 1
    return m

meta = open(pd + '_exp.txt').readline().split()   # # N <n> tree <bytes> top <bytes> record <bytes>
N, tree, top = int(meta[2]), int(meta[4]), int(meta[6])
exp = {}
for line in open(pp + '_exp.txt'):
    if line.startswith('#'): continue
    k, i = map(int, line.split()); exp[k] = i
exp_d = {}
for line in open(pd + '_exp.txt'):
    if line.startswith('#'): continue
    k, i = map(int, line.split()); exp_d[k] = i
TW = tree // 32
mem = {}
for tag, p in (('d', pd), ('p', pp)):
    h = load(p + '_host.hex', TW); t = load(p + '_top.hex', top // 32)
    mem[tag] = [t[w] if w * 32 < top else h[w] for w in range(TW)]   # the tree as the core sees it

def pat(i, j, k):
    w = ((i & 0xFFFF) << 16) | ((j & 0xFF) << 8) | (k & 0xFF)
    v = 0
    for _ in range(8): v = (v << 32) | w
    return v

def decrypt(beats):
    iv = beats[0] & ((1 << 64) - 1)
    out = []
    for j, b in enumerate(beats):
        ks = int.from_bytes(aes.update(((iv << W) | j).to_bytes(16, 'big')), 'big')
        out.append(b ^ ((ks << 128) | ks))
    out[0] = (out[0] & ~((1 << 64) - 1)) | iv
    return out

def fields(beats, rev):
    h = 0
    for j in range(HB): h |= beats[j] << (256 * j)
    iv = h & ((1 << 64) - 1)
    vb = (h >> 64) & ((1 << Z) - 1)
    out = []
    for i in range(Z):
        f = (Z - 1 - i) if rev else i      # header field of the i-th payload block
        v = (vb >> f) & 1
        u = (h >> (72 + U * f)) & ((1 << U) - 1)
        lf = (h >> (72 + U * Z + L * f)) & ((1 << L) - 1)
        out.append((v, u, lf, beats[HB + i * KB: HB + (i + 1) * KB]))
    return iv, out

paths = {}
def on_path(leaf, off):
    if leaf not in paths: paths[leaf] = set(tp.path(leaf, L, g))
    return off in paths[leaf]

def sane(beats, off, rev, e):
    iv, bl = fields(beats, rev)
    nv = nd = 0
    for v, u, lf, data in bl:
        if not v: continue
        nv += 1
        if not on_path(lf, off): return False, nv, nd
        if u < N and u in e:
            if any(data[j] != pat(e[u], j, u) for j in range(KB)): return False, nv, nd
            nd += 1
    return True, nv, nd

# which header field belongs to which payload block: the order under which the default build's buckets are sane
rev = None
for r in (False, True):
    ok = 0
    for b in range(0, tree // (BB * 32)):
        w = mem['d'][b * BB:(b + 1) * BB]
        if w[0] & ((1 << 64) - 1): ok += sane(decrypt(w), b * BB * 32, r, exp_d)[0]
    if rev is None or ok > best: rev, best = r, ok

fails = []; st = dict(top_b=0, host_b=0, blocks=0, data=0, same_host=0, empty=0)
for b in range(0, tree // (BB * 32)):
    off = b * BB * 32; intop = off + BB * 32 <= top
    wd, wp = mem['d'][b * BB:(b + 1) * BB], mem['p'][b * BB:(b + 1) * BB]
    ivd, ivp = wd[0] & ((1 << 64) - 1), wp[0] & ((1 << 64) - 1)
    if not intop:
        if wd != wp: fails.append(f"off-top bucket at {off:#x} differs from the default build"); continue
        st['same_host'] += 1
    if ivd == 0 and ivp == 0:
        if any(wd) or any(wp): fails.append(f"bucket at {off:#x}: IV 0 (never written) but not all zeros")
        st['empty'] += 1; continue
    if ivd != ivp: fails.append(f"bucket at {off:#x}: IV {ivd:#x} (default) vs {ivp:#x} (TOP_PLAINTEXT)"); continue
    dd = decrypt(wd)
    if intop:
        if dd != wp: fails.append(f"top bucket at {off:#x}: TOP_PLAINTEXT bytes differ from the default build decrypted"); continue
        ok, nv, nd = sane(wp, off, rev, exp)
        if not ok: fails.append(f"top bucket at {off:#x}: not sane as plaintext"); continue
        st['top_b'] += 1
    else:
        ok, nv, nd = sane(decrypt(wp), off, rev, exp)
        if not ok: fails.append(f"off-top bucket at {off:#x}: does not decrypt to a sane bucket"); continue
        pl = decrypt(wp)                        # ciphertext: no beat stored as it decrypts (the IV field aside)
        if any(wp[j] == pl[j] for j in range(1, BB)) or (wp[0] >> 64) == (pl[0] >> 64):
            fails.append(f"off-top bucket at {off:#x}: a beat is stored in plaintext"); continue
        st['host_b'] += 1
    st['blocks'] += nv; st['data'] += nd
for f in fails[:10]: print("  FAIL", f)
written = st['top_b'] + st['host_b']
print(f"inspect {blk} B L={L} top={top} of {tree} (header fields {'reversed' if rev else 'in order'}): {st['top_b']} top buckets plaintext (= default decrypted), "
      f"{st['host_b']} off-top buckets encrypted and decrypting, all {st['same_host']} off-top bucket slots byte-identical "
      f"to the default build, {st['blocks']} valid blocks on their leaf's path, {st['data']} data blocks = last PUT; "
      f"{st['empty']} never written; {len(fails)} failure(s)")
if written == 0 or (top > 0 and st['top_b'] == 0) or (top < tree and st['host_b'] == 0) or st['data'] == 0:
    print("  FAIL nothing to check on one side"); sys.exit(1)
sys.exit(1 if fails else 0)
