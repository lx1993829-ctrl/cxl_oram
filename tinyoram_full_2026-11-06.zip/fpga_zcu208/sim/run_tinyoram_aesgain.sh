#!/bin/bash
# run_tinyoram_aesgain.sh -- what a plaintext tree top could save Tiny ORAM (README §24). A measurement, not a test of
# the shipped design: nothing here changes the RTL that is built for the card.
#
# Per block size, two native builds of the same geometry (merged adapter, as on the card):
#   aes    the core as shipped (AES-128 CTR on every bucket, PMMAC on)
#   plain  the same core with every bucket in plaintext and no AES latency at all (AES_BYPASS_ALL, a private copy of
#          AESPathORAM.v): payload beats pass straight between memory and the backend; the header IV is still written
#          (the global counter, as with AES) and read back, so the core runs exactly as shipped otherwise (EnableAES
#          stays 1: Tiny ORAM's own EnableAES = 0 branch breaks one of its write-back checks in this snapshot). This
#          is the best any plaintext bypass can do: with +top_all it is the whole tree on package in plaintext, and
#          at a partial split it bounds what a top-only bypass could save.
# Both run the same command stream (same seed) twice: the whole tree on the top port (+top_all, the tree on package),
# and a top of TOP_PCT % of the tree bytes (default 15: doma:20's share of the 1M-record trees, README §22), the rest
# on the host port. The aes build also carries a counter probe (AES_PROBE, private copy of AESPathORAM.v only):
# memory read beats AES refused, cycles in which decrypted or encrypted data waited for keystream, and the tail from
# the last beat into AES to the last beat out of it, per path.
#   SZS="64 128 256 512 1k 2k 4k" (default)  L=10  CMDS=300  PRELOAD="64 128 256 512" (sizes that preload all N blocks;
#   the testbench checks responses only for launches of up to 4,096 commands, so keep L <= 10 with a preload)
# Logs and a table: build_tinyoram/aesgain/  (table.txt)
set -u
cd "$(dirname "$0")"
TOR=../tinyoram
B=${AESGAIN_DIR:-build_tinyoram/aesgain}; mkdir -p $B
[ -f $TOR/upstream/TinyORAMCore.v ] || bash $TOR/fetch_tinyoram.sh 4k > /dev/null || exit 2
VFLAGS="--binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-WIDTH -Wno-ZERODLY -Wno-BLKANDNBLK"
SZS=${SZS:-"64 128 256 512 1k 2k 4k"}; L=${L:-10}; CMDS=${CMDS:-300}; TOP_PCT=${TOP_PCT:-15}
PRELOAD=${PRELOAD-"64 128 256 512"}
probe() {   # the counter probe, appended to the private copy of AESPathORAM.v (inside the module)
python3 - "$1" <<'PY'
import sys
p = sys.argv[1]; s = open(p).read()
code = r'''
`ifdef AES_PROBE
    integer pr_cyc = 0, pr_rref = 0, pr_rwait = 0, pr_wwait = 0, pr_whold = 0, pr_rp = 0, pr_wp = 0;
    integer pr_rlast = 0, pr_wlast = 0, pr_rtail = 0, pr_wtail = 0, pr_rtmax = 0, pr_wtmax = 0;
    always @(posedge Clock) begin
        pr_cyc <= pr_cyc + 1;
        if (DRAMReadDataValid && !DRAMReadDataReady) pr_rref <= pr_rref + 1;                    // read beats refused
        if (RW == PATH_READ && BackendRReady && AESDataOutValid && !AESMaskOutValid) pr_rwait <= pr_rwait + 1;
        if (RW == PATH_WRITE && DRAMWriteDataReady && AESDataOutValid && !AESMaskOutValid) pr_wwait <= pr_wwait + 1;
        if (BackendWValid && !BackendWReady && DRAMWriteDataReady) pr_whold <= pr_whold + 1;     // stash held, memory ready
        if (ReadGood) pr_rlast <= pr_cyc;
        if (WriteGood) pr_wlast <= pr_cyc;
        if (PathTransition && InitDone) begin
            if (RW == PATH_READ) begin pr_rp <= pr_rp + 1; pr_rtail <= pr_rtail + (pr_cyc - pr_rlast);
                if (pr_cyc - pr_rlast > pr_rtmax) pr_rtmax <= pr_cyc - pr_rlast; end
            else begin pr_wp <= pr_wp + 1; pr_wtail <= pr_wtail + (pr_cyc - pr_wlast);
                if (pr_cyc - pr_wlast > pr_wtmax) pr_wtmax <= pr_cyc - pr_wlast; end
        end
    end
    final $display("AESPROBE paths %0d read %0d write | read beats refused %0d | waiting for keystream: read %0d write %0d cycles | stash held with memory ready %0d | tail per path: read %0d (max %0d) write %0d (max %0d) | cycles %0d",
                   pr_rp, pr_wp, pr_rref, pr_rwait, pr_wwait, pr_whold, pr_rp ? pr_rtail / pr_rp : 0, pr_rtmax, pr_wp ? pr_wtail / pr_wp : 0, pr_wtmax, pr_cyc);
`endif
'''
i = s.rindex('endmodule'); open(p, 'w').write(s[:i] + code + s[i:])
PY
}
bypass() {   # AES_BYPASS_ALL: every bucket plaintext, zero latency (private copy of AESPathORAM.v only)
python3 - "$1" <<'PY2'
import sys
p = sys.argv[1]; s = open(p).read()
def rep(old, new):
    global s
    assert s.count(old) == 1, old
    s = s.replace(old, new)
rep("    assign DataInValid = (DRAMReadDataValid ^ BackendWValid);",
    "`ifdef AES_BYPASS_ALL\n    assign DataInValid = 1'b0; // nothing enters the AES pipeline\n`else\n    assign DataInValid = (DRAMReadDataValid ^ BackendWValid);\n`endif")
rep("    assign DRAMReadDataReady = DataInReady & InitDone;",
    "`ifdef AES_BYPASS_ALL\n    assign DRAMReadDataReady = BackendRReady;\n`else\n    assign DRAMReadDataReady = DataInReady & InitDone;\n`endif")
old = s[s.index("    //BackendW related"):s.index("endmodule")]
new = """`ifdef AES_BYPASS_ALL
    // plaintext, zero latency: the IV chunk of every bucket written carries the global counter (as with AES, so
    // DRAMToStash still sees a written bucket); every other beat passes unchanged, in both directions
    // Phases as the AES keeps them (RW): a path read, then its write-back, each PathSize_BEDChunks beats. Write
    // beats are taken only during a write-back: the stash presents one beat past the end of a write-back, which
    // the AES never takes (its IV FIFO is still busy then); a zero-latency pass-through would (Tiny ORAM's own
    // EnableAES = 0 branch does, and fails the backend's write-back check)
    reg [BktSizeBED_Width-1:0]  bp_ctr = 0;
    reg [PathSizeBED_Width:0]   bp_pc  = 0;
    reg                         bp_rw  = PATH_READ;
    reg [AESEntropy-1:0]        bp_gc  = IVINITValue + 1;
    wire bp_wok = (bp_rw == PATH_WRITE);
    wire bp_w = BackendWValid & DRAMWriteDataReady & bp_wok;
    wire bp_r = DRAMReadDataValid & DRAMReadDataReady;
    always @(posedge Clock) begin
        if (bp_w) begin
            bp_ctr <= (bp_ctr == BktSize_BEDChunks - 1) ? 0 : bp_ctr + 1;
            if (bp_ctr == IV_LOC) bp_gc <= bp_gc + 1;
        end
        if (bp_w | bp_r) begin
            if (bp_pc == PathSize_BEDChunks - 1) begin bp_pc <= 0; bp_rw <= ~bp_rw; end
            else bp_pc <= bp_pc + 1;
        end
    end
    generate if (BEDWidth > AESEntropy) begin: BP_IV
        assign DRAMWriteData = (bp_ctr == IV_LOC) ? {BackendWData[BEDWidth-1:AESEntropy], bp_gc} : BackendWData;
    end else begin: BP_IV1
        assign DRAMWriteData = (bp_ctr == IV_LOC) ? bp_gc : BackendWData;
    end endgenerate
    assign DRAMWriteDataValid = BackendWValid & bp_wok;
    assign BackendWReady = DRAMWriteDataReady & bp_wok;
    assign BackendRData = DRAMReadData;
    assign BackendRValid = DRAMReadDataValid;
`else
""" + old + "`endif\n"
s = s.replace(old, new)
open(p, 'w').write(s)
PY2
}
fetch_geo() {   # fetch_geo <dir> <fetch args...>: a private fetch (the shared ../tinyoram/build is left alone)
    local d=$1; shift; rm -rf $d; mkdir -p $d
    cp $TOR/fetch_tinyoram.sh $d/ && cp -r $TOR/config $TOR/patches $d/ && ln -s $(cd $TOR && pwd)/upstream $d/upstream
    bash $d/fetch_tinyoram.sh "$@" > $d/fetch.log 2>&1
}
mk() {   # mk <name> <aes|plain> <size> <tree words>
    local name=$1 v=$2 sz=$3 W=$4; local g=$B/$name
    local cw=$((1 << 18)); [ $sz = 2k ] && cw=$((1 << 19)); [ $sz = 4k ] && cw=$((1 << 20))
    [ -x $g/obj/Vtb ] && [ -z "${REBUILD:-}" ] && return 0
    fetch_geo $g $sz $L merge || { echo "  FETCH FAILED: $name"; exit 2; }
    probe $g/build/src/AESPathORAM.v; [ $v = plain ] && { bypass $g/build/src/AESPathORAM.v || exit 2; }
    local def="-DAES_PROBE"; [ $v = plain ] && def="-DAES_BYPASS_ALL"
    echo "  building $name ..."
    verilator $VFLAGS -I$g/build/src -DSIMULATION $def -DTB_HOST_WORDS=$W -DTB_TOP_WORDS=$W -DTB_NMAX=$((4 << L)) -DTB_CMD_WORDS=$cw \
        --top-module tb_tinyoram_kernel ./tb_tinyoram_kernel.v ./axi_mem_model.v \
        $TOR/rtl/tinyoram_kernel.v $TOR/rtl/tinyoram_axi_adapter.v $(sed "s#^#$g/build/src/#" $g/build/src/files.f | tr '\n' ' ') \
        -Mdir $g/obj -o Vtb > $g/build.log 2>&1 || { echo "  BUILD FAILED: $name ($g/build.log)"; exit 2; }
}
run() { local name=$1 tag=$2; shift 2; ( ulimit -s unlimited 2>/dev/null; ./$B/$name/obj/Vtb +hb=0 +limit=2000000000 "$@" > $B/$tag.log 2>&1 ); }
for sz in $SZS; do
    W=1048576; [ $sz = 4k ] && W=2097152
    mk a_$sz aes $sz $W & mk n_$sz plain $sz $W & wait
done
echo "size split variant | preload: cmds cycles/cmd | run1: cmds cycles/cmd lat-min lat-max | probe" > $B/table.txt
for sz in $SZS; do
    pre=""; for p in $PRELOAD; do [ $p = $sz ] && pre=+preload; done
    for split in all part; do
        if [ $split = all ]; then sa=+top_all; else
            # the tree's bytes from the kernel's own constant (BucketLocal: 64 B x buckets x bursts per bucket)
            tb=$(grep -oE "tree=[0-9]+ bytes" $B/a_${sz}_all.log | head -1 | grep -oE "[0-9]+")
            [ -z "$tb" ] && tb=$(( W * 32 ))
            sa=+top=$(( (tb * TOP_PCT / 100) / 4096 * 4096 ))
        fi
        tr=""; [ $split = part ] && tr=+axitrace       # the bucket order per path, at the split (aes build)
        run a_$sz a_${sz}_$split $sa $pre $tr +cmds=$CMDS +cmds2=0 & run n_$sz n_${sz}_$split $sa $pre +cmds=$CMDS +cmds2=0 & wait
        for v in a n; do
            f=$B/${v}_${sz}_$split.log
            ok=$(grep -c "TINYORAM KERNEL: ALL CHECKS PASSED" $f)
            pl=$(grep -E "^preload: size=" $f | sed -E 's/.*size=([0-9]+).*device total=([0-9]+).*/\1 \2/')
            r1=$(grep -E "^run1: size=" $f | sed -E 's/.*size=([0-9]+).*device total=([0-9]+).*latency min\/max=([0-9]+)\/([0-9]+).*/\1 \2 \3 \4/')
            pr=$(grep -oE "AESPROBE.*" $f | head -1)
            tf=$(grep -E "^(preload|run1): traffic" $f | grep -oE "read beats [0-9]+, write beats [0-9]+" | tr -d ',' | awk '{printf "%s/%s ", $3, $6}')
            echo "$sz $split $v ok=$ok $sa | $pl | $r1 | traffic $tf| $pr" >> $B/table.txt
        done
        tail -2 $B/table.txt
        if [ $split = part ]; then   # every path: its top-port buckets first, then the host-port ones (reads and writes)
            grep -E "^T " $B/a_${sz}_part.log > $B/a_${sz}_part.trace
            python3 - $B/a_${sz}_part.trace >> $B/order.txt <<'PY3'
import sys
runs = []; cur = None
for line in open(sys.argv[1]):
    f = line.split()                      # T <cycle> <AR|AW><port> <offset> <len-1>
    d, port, ln = f[2][:2], f[2][2], int(f[4])
    if d == 'AW' and ln == 127 and cur is None: continue        # the zero-fill before the first path
    if cur is None or cur[0] != d: cur = [d, []]; runs.append(cur)
    cur[1].append(port)
bad = sum(1 for d, ps in runs if '3' in ''.join(ps).split('2', 1)[-1] and '2' in ps)   # a top bucket after a host one
endtop = sum(1 for d, ps in runs if ps[-1] == '3')
print(f"{sys.argv[1].split('/')[-1]}: {sum(d == 'AR' for d, _ in runs)} path reads, {sum(d == 'AW' for d, _ in runs)} write-backs; "
      f"top bucket after a host bucket: {bad}; ending on the top port: {endtop}")
PY3
            tail -1 $B/order.txt
        fi
    done
done
python3 - $B/table.txt <<'PY' | tee $B/summary.txt
import sys, re
rows = {}
for line in open(sys.argv[1]).read().splitlines()[1:]:
    f = [x.strip() for x in line.split('|')]
    sz, split, v = f[0].split()[:3]
    ok = f[0].split()[3]
    pl = f[1].split(); r1 = f[2].split(); tf = f[3]
    rows[(sz, split, v)] = (ok, pl, r1, tf)
print("\nsize  split | run1 cycles/cmd: aes  plain  saved  % | preload cycles/cmd: aes  plain  saved  %")
for (sz, split, v), (ok, pl, r1, tf) in rows.items():
    if v != 'a' or (sz, split, 'n') not in rows: continue
    okn, pln, r1n, tfn = rows[(sz, split, 'n')]
    same = "same accesses" if tfn == rows[(sz, split, 'a')][3] else "TRAFFIC DIFFERS"
    def g(a, b):
        if len(a) < 2 or len(b) < 2: return "      -"
        ca, cb = int(a[1]) / int(a[0]), int(b[1]) / int(b[0])
        return f"{ca:9.1f} {cb:9.1f} {ca-cb:7.1f} {100*(ca-cb)/ca:5.2f}"
    print(f"{sz:5} {split:5} | {g(r1, r1n)} | {g(pl, pln)}   ({ok} {okn}, {same})")
PY
