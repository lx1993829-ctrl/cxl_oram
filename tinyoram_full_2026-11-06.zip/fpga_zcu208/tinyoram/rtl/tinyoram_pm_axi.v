// tinyoram_pm_axi.v -- the flat position map in HBM (TINYORAM_PM_HBM, patch 10; README §26): Tiny ORAM's position-map
// requests to AXI on m_axi_gmem4, and the zeroing of the map before the core leaves reset.
//   * one request at a time from the core (PosMapPLB): a read of one 8-byte entry (one 32-byte beat, the entry's lane
//     returned), or a write of one entry (one beat, 8 byte strobes), answered once its write response arrives;
//   * zeroing: on zero_start, zero bytes [0, nbytes) of the map in 4 KB bursts; zero_done once every burst is
//     acknowledged. The core is in reset meanwhile (the kernel waits for zero_done before releasing it);
//   * a non-OKAY response sets err (sticky until the next zero_start).
`timescale 1ns/1ps
module tinyoram_pm_axi #(
    parameter integer DW = 256
) (
    input  wire          clk,
    input  wire          rst,
    input  wire [63:0]   base,           // the map's buffer (latched by the kernel at init)
    input  wire [63:0]   nbytes,         // the map's size in bytes (a multiple of 32)
    input  wire          zero_start,     // pulse
    output reg           zero_done,
    output reg           err,
    // core side
    input  wire          req_valid,
    output wire          req_ready,
    input  wire          req_write,
    input  wire [31:0]   req_addr,       // entry index
    input  wire [63:0]   req_data,
    output reg           resp_valid,
    output reg  [63:0]   resp_data,
    output reg           wr_done,
    // AXI master
    output reg  [63:0]   araddr,  output wire [7:0] arlen, output wire [2:0] arsize, output wire [1:0] arburst,
    output reg           arvalid, input  wire       arready,
    input  wire [DW-1:0] rdata,   input  wire [1:0] rresp, input wire rlast, input wire rvalid, output wire rready,
    output reg  [63:0]   awaddr,  output reg  [7:0] awlen, output wire [2:0] awsize, output wire [1:0] awburst,
    output reg           awvalid, input  wire       awready,
    output reg  [DW-1:0] wdata,   output reg  [DW/8-1:0] wstrb, output wire wlast, output reg wvalid, input wire wready,
    input  wire [1:0]    bresp,   input  wire       bvalid, output wire bready
);
    localparam integer BB = DW / 8;                   // bytes per beat (32)
    localparam S_IDLE = 3'd0, S_RD = 3'd1, S_WR = 3'd2, S_WB = 3'd3, S_Z = 3'd4, S_ZW = 3'd5, S_ZB = 3'd6;
    reg  [2:0]  st;
    reg  [1:0]  lane;
    reg  [63:0] zoff;
    reg  [7:0]  wcnt;
    reg  [15:0] zout;                                 // zero bursts not yet acknowledged
    assign arlen = 8'd0; assign arsize = $clog2(BB); assign arburst = 2'b01;
    assign awsize = $clog2(BB); assign awburst = 2'b01;
    assign rready = 1'b1; assign bready = 1'b1;
    assign wlast = (wcnt == awlen);
    assign req_ready = (st == S_IDLE) && zero_done && !zero_start;
    wire [63:0] eoff = {29'd0, req_addr, 3'b000};     // the entry's byte offset
    wire        zinc = (st == S_Z) && (zoff < nbytes);  // a zero burst is issued this cycle
    always @(posedge clk) begin
        resp_valid <= 1'b0; wr_done <= 1'b0;
        if (rst) begin
            st <= S_IDLE; arvalid <= 1'b0; awvalid <= 1'b0; wvalid <= 1'b0; zero_done <= 1'b0; err <= 1'b0; zout <= 16'd0;
        end else begin
            if (bvalid && bresp != 2'b00) err <= 1'b1;
            if (rvalid && rresp != 2'b00) err <= 1'b1;
            case (st)
                S_IDLE:
                    if (zero_start) begin st <= S_Z; zoff <= 64'd0; zero_done <= 1'b0; err <= 1'b0; end
                    else if (req_valid && zero_done) begin
                        lane <= req_addr[1:0];
                        if (req_write) begin
                            awaddr <= base + {eoff[63:5], 5'd0}; awlen <= 8'd0; awvalid <= 1'b1;
                            wdata <= {(DW/64){req_data}};
                            wstrb <= {{(BB-8){1'b0}}, 8'hFF} << (8 * req_addr[1:0]);
                            wvalid <= 1'b1; wcnt <= 8'd0; st <= S_WR;
                        end else begin
                            araddr <= base + {eoff[63:5], 5'd0}; arvalid <= 1'b1; st <= S_RD;
                        end
                    end
                S_RD: begin
                    if (arvalid && arready) arvalid <= 1'b0;
                    if (rvalid) begin resp_data <= rdata[64 * lane +: 64]; resp_valid <= 1'b1; st <= S_IDLE; end
                end
                S_WR: begin
                    if (awvalid && awready) awvalid <= 1'b0;
                    if (wvalid && wready) wvalid <= 1'b0;
                    if (!(awvalid && !awready) && !(wvalid && !wready)) st <= S_WB;
                end
                S_WB: if (bvalid) begin wr_done <= 1'b1; st <= S_IDLE; end
                // zeroing: one 4 KB burst at a time (address, then its beats), responses counted
                S_Z:
                    if (zoff >= nbytes) st <= S_ZB;
                    else begin
                        awaddr <= base + zoff;
                        awlen <= ((nbytes - zoff) >= 64'd4096) ? 8'd127 : ((nbytes - zoff) / BB) - 1;
                        awvalid <= 1'b1; wdata <= {DW{1'b0}}; wstrb <= {BB{1'b1}}; wvalid <= 1'b1; wcnt <= 8'd0;
                        st <= S_ZW;
                    end
                S_ZW: begin
                    if (awvalid && awready) awvalid <= 1'b0;
                    if (wvalid && wready) begin
                        if (wcnt == awlen) begin wvalid <= 1'b0; zoff <= zoff + ({56'd0, awlen} + 64'd1) * BB; end
                        else wcnt <= wcnt + 8'd1;
                    end
                    if (!(awvalid && !awready) && !(wvalid && !(wready && wcnt == awlen))) st <= S_Z;
                end
                S_ZB: if (zout == 16'd0 && !zinc) begin zero_done <= 1'b1; st <= S_IDLE; end
                default: st <= S_IDLE;
            endcase
            // zero bursts outstanding: +1 per burst issued, -1 per write response while zeroing (request writes come only
            // after zero_done, and are answered in S_WB)
            if (st == S_Z || st == S_ZW || st == S_ZB) zout <= zout + (zinc ? 16'd1 : 16'd0) - (bvalid ? 16'd1 : 16'd0);
        end
    end
endmodule
