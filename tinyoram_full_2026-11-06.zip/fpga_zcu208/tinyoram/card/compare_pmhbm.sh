#!/bin/bash
# compare_pmhbm.sh -- the DOMA side of the reviewer's comparison at 4 KB (README §26), then the report.
#
#   bash compare_pmhbm.sh find      list the DOMA builds under your home folder (doma_hw.xclbin next to the rtl/oram_build_cfg.vh
#                                   that built it) and mark the one to use: FIXWB=1, LAMBDA=7, NMAX=2097152, arrival,
#                                   no overlap, no debug, trace, interim or plain-core option
#   bash compare_pmhbm.sh doma      DOMA v14c at the same N and r as Tiny ORAM's q38/q39, and at 2M, from the one build
#                                   find marks (or DOMA_VITIS=<its vitis folder>); log DEST/results/doma_v14c_pmhbm.log
#   bash compare_pmhbm.sh report    report_pmhbm.py on DEST/results
#
# DOMA_VITIS is the vitis/ folder of your DOMA v14c build with FIXWB=1 (Option A, non-overlap, SCHED=arrival,
# LAMBDA=7) for 2M records at 4 KB (NMAX=2097152, CFG=doma_big2m.cfg): its host_doma (v14c's own host program) and its
# board bitstream, DOMA_XCLBIN (default doma_hw.xclbin). The script refuses a bitstream that does not report lambda 7.
# NS (default "262144 1048576 2097152"), HBMS (default "0 20 50 100"), CMDS (default 20000, as sweep_tiny.sh):
# the same command stream as Tiny ORAM's runs (BOLT's generator, seed 1). Nothing is built or changed on the card.
set -u
CARD=$(cd "$(dirname "$0")" && pwd)
PKG=$(cd "$CARD/../.." && pwd)
DEST=${DEST:-$(dirname "$(dirname "$PKG")")}
RES=$DEST/results; mkdir -p "$RES"
XRT_SETUP=${XRT_SETUP:-/opt/xilinx/xrt/setup.sh}
NS=${NS:-"262144 1048576 2097152"}; HBMS=${HBMS:-"0 20 50 100"}; CMDS=${CMDS:-20000}
# candidates: <vitis folder> <verdict> <configuration>, one per doma_hw.xclbin under the home folder
find_builds() {
    find "$HOME" -maxdepth 7 -path '*/vitis/doma_hw.xclbin' -not -path "$HOME/tiny/*" 2>/dev/null | sort | while read -r x; do
        v=$(dirname "$x"); c=$v/../rtl/oram_build_cfg.vh; [ -f "$c" ] || continue
        cfg=$(grep -oE '^`define +[A-Z0-9_]+( +[0-9]+)?' "$c" | sed -E 's/^`define +//' | tr '\n' ' ')
        ok=yes
        grep -q '^`define ORAM_ONPKG_FIXWB' "$c" || ok=no
        grep -qE '^`define ORAM_C +7$' "$c" || ok=no
        grep -qE '^`define ORAM_N +2097152$' "$c" || ok=no
        grep -q '^`define ORAM_SCHED_ARRIVAL' "$c" || ok=no
        grep -qE '^`define ORAM_(OVERLAP2|OVERLAP4|ONPKG_DEBUG|PHASE_TRACE|ONPKG_INTERIM|PLAIN)' "$c" && ok=no
        [ -x "$v/host_doma" ] || ok=no
        echo "$(cd "$v" && pwd) $ok $cfg"
    done
}
case "${1:-}" in
find)
    find_builds | awk '{v=$1; ok=$2; $1=""; $2=""; printf "%s %s\n    %s\n", (ok == "yes" ? "USE " : "    "), v, $0}' ;;
doma)
    if [ -z "${DOMA_VITIS:-}" ]; then
        mapfile -t c < <(find_builds | awk '$2 == "yes" {print $1}')
        [ ${#c[@]} = 1 ] || { echo "found ${#c[@]} DOMA v14c FIXWB=1 2M builds ('bash compare_pmhbm.sh find' lists them): set DOMA_VITIS to its vitis folder"; exit 2; }
        DOMA_VITIS=${c[0]}; echo "DOMA build: $DOMA_VITIS"
    fi
    cd "$DOMA_VITIS" || exit 2
    X=${DOMA_XCLBIN:-doma_hw.xclbin}
    [ -f "$X" ] && [ -x ./host_doma ] || { echo "$DOMA_VITIS: $X or host_doma missing"; exit 2; }
    command -v xclbinutil > /dev/null || source "$XRT_SETUP" > /dev/null 2>&1
    mhz=$(xclbinutil --info -i "$X" 2>/dev/null | awk '/Name:.*DATA_CLK/{f=1} f && /Frequency:/{print $2; exit}')
    [ -n "$mhz" ] || { echo "cannot read the kernel clock of $X (xclbinutil --info)"; exit 2; }
    sed -i '/^doma v14c_pmhbm /d' "$RES/clocks.txt" 2>/dev/null; echo "doma v14c_pmhbm $mhz" >> "$RES/clocks.txt"
    LOG=$RES/doma_v14c_pmhbm.log; : > "$LOG"
    echo "DOMA v14c: $(pwd)/$X, $mhz MHz; N = $NS; r = $HBMS %; $CMDS commands" | tee -a "$LOG"
    fail=0
    for n in $NS; do for p in $HBMS; do
        out=$(DOMA_LAMBDA=7 DOMA_N=$n DOMA_HBM_PCT=$p ./host_doma "$X" $CMDS 2>&1)
        { echo "==== N=$n DOMA_HBM_PCT=$p"; echo "$out"; } >> "$LOG"
        q=$(echo "$out" | awk '/^query:/{print $(NF-1)}'); d=$(echo "$out" | grep -m1 '^device:' | cut -c1-100)
        printf "N=%-8s r=%3s%%  %s KQPS  %s\n" $n $p "${q:-FAILED}" "$d"
        echo "$out" | grep -q "^ALL RESPONSES CORRECT" || { fail=1; echo "   not clean: $(echo "$out" | grep -m1 -iE 'error|must|fail|lambda|exceed' | cut -c1-120)"; }
    done; done
    echo "written $LOG"
    [ $fail = 0 ] && echo "PASS: every DOMA run clean" || echo "FAIL: see $LOG"
    exit $fail ;;
report)
    python3 "$CARD/report_pmhbm.py" "$RES" ;;
*)
    sed -n '2,16p' "$0"; exit 2 ;;
esac
