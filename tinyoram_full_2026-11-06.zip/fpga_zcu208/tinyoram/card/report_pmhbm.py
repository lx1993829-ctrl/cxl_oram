#!/usr/bin/env python3
"""report_pmhbm.py -- the reviewer's comparison at 4 KB (README §26): DOMA v14c against Tiny ORAM with the flat
position map in HBM and a tree top matched to DOMA's on-package bytes, at equal r (the share of DOMA's buckets kept
on package). Average and tail latency, and off-package bytes per access.

    python3 report_pmhbm.py [results dir]          default: DEST/results (two levels above this package copy)
    python3 report_pmhbm.py --model                the analytic part alone (off-package bytes, matched tops), no runs

Reads
  tiny_q38_*.log, tiny_q39_*.log   sweep_tiny.sh 38 39 (Tiny ORAM, 1M and 256K records, DOMA_TINY_TOP=doma:<r>)
  doma_v14c_pmhbm.log              compare_pmhbm.sh doma (DOMA v14c, FIXWB=1, at the same N and r, and at 2M)
  clocks.txt                       the kernel clocks, read from the bitstreams
Prints
  1. the measured table: per N and r, both designs' mean and tail latency (cycles and microseconds at each design's
     own clock), off-package bytes per access (read + written), KQPS;
  2. the off-package bytes per access of Tiny ORAM from its tree layout (every path bucket below the matched top,
     sim/topplain/toppaths.py's address map) against the card's traffic counters: the check of the model;
  3. Tiny ORAM at 2M records (L = 19), which does not fit the card's host memory with a top this small: its mean
     latency from a fit of the measured runs, mean = a + b * (top bytes per access) + c * (pages bytes per access),
     fitted on 256K and checked on 1M (the error is printed), then refitted on both; its tail from the 1M runs'
     tail-to-mean ratio at the same r. Off-package bytes at 2M: the layout's off-package share of a path (exact) times
     the paths per command measured at 1M and the same r (Tiny ORAM's background evictions add whole paths).
Definitions. Latency of a command: from its issue to the kernel until its last write-back beat is handed off (both
kernels, arrival mode). DOMA v14c serves one access at a time with fixed phase deadlines, so its mean latency is its
device cycles per command and its tail is the per-command maximum it reports. Tiny ORAM's spread (p50 .. max) comes
from every response header. Off-package bytes: the bytes moved on the host-memory port (DOMA: the bucket port;
Tiny ORAM: the pages port = both tree ports minus the top port).
"""
import math, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', '..', 'sim', 'topplain'))
import toppaths as tp                                                    # Tiny ORAM's bucket address map

BLOCK = 4096
PM_ENTRY = 8                                                            # bytes per position-map entry (Tiny ORAM)

# ---- DOMA v14c's on-package bytes (its vitis/host_doma.cpp; host_doma.cpp's DOMA_MATCH_GEOM=v14c)
def _ln_mgf_A(t, Bk, n):
    p = 1.0 / Bk; lr = math.log1p(-p) + t
    if abs(lr) < 1e-15: return math.log(p * n + 1.0)
    if lr > 0:
        lrn = n * lr
        if lrn > 700: return math.inf
        return math.log(p * math.expm1(lrn) / math.expm1(lr) + math.exp(lrn))
    rn = math.exp(n * lr)
    return math.log(p * (1 - rn) / (-math.expm1(lr)) + rn)
def _xR(Bk, n, lg):
    best = math.inf
    for i in range(1, 400):
        u = i * 0.005; v = _ln_mgf_A(math.expm1(u) / Bk, Bk, n)
        if not math.isfinite(v): break
        best = min(best, (Bk * v + lg) / u)
    return best
def _xO(Bk, lam, Z, lg):
    best = math.inf
    for i in range(1, 400):
        u = i * 0.01
        lt = [-lam + k * math.log(lam) - math.lgamma(k + 1.0) + u * max(0, k - Z) for k in range(160)]
        mx = max(lt); s = sum(math.exp(x - mx) for x in lt)
        best = min(best, (Bk * (mx + math.log(s)) + lg) / u)
    return best
def stash_bound(n, lam, Z):
    Bk = math.ceil(n / lam); G = 64 * math.log(2.0)
    return min(_xR(Bk, n, G - math.log(f)) + _xO(Bk, lam, Z, G - math.log(1 - f)) for f in (0.1, 0.3, 0.5, 0.7, 0.9))
def r4k(x): return (x + 4095) & ~4095
def doma_v14c_onpkg(nrec, pct, lam=7, Z=8, block=BLOCK):
    nblk = ((nrec + lam - 1) // lam) * lam; nb = (nblk + lam - 1) // lam
    pool = int(min(nblk, math.ceil(stash_bound(nblk, lam, Z)) + 1))
    meta = max(4096, ((nblk + 4) // 5) * 32); brec = max(4096, nb * 64)
    stash = r4k(nb * 64) + r4k(pool * 16) + pool * block
    return meta + brec + stash + (nb * pct // 100) * Z * block

def depth(n):
    L = 6
    while (4 << L) < n: L += 1
    return L
def tiny_top(nrec, pct):
    """the host's matched top: DOMA v14c's on-package bytes less Tiny ORAM's position map (N x 8 B), 4 KB multiple"""
    L = depth(nrec); g = tp.geo(BLOCK, L)
    t = max(0, doma_v14c_onpkg(nrec, pct) - (4 << L) * PM_ENTRY)
    return min(t & ~4095, g['tree'])
def offpkg_per_access(nrec, top, nleaves=4096):
    """bytes per access below the top (read + written), over uniform leaves: a bucket straddling the top counts its
    part below it (the adapter splits bursts at the top)"""
    L = depth(nrec); g = tp.geo(BLOCK, L); B = g['bkt'] * 64
    import random
    rng = random.Random(1); tot = 0
    for _ in range(nleaves):
        for o in tp.path(rng.randrange(1 << L), L, g):
            tot += max(0, o + B - max(o, top))
    return 2.0 * tot / nleaves, 2.0 * (L + 1) * B                     # (off-package, whole path both ways)

# ---- logs
def sections(path, key):
    out = {}; cur = None
    if not os.path.exists(path): return out
    for line in open(path, errors='replace'):
        m = re.match(r'^==== N=(\d+) %s=(\S+)' % key, line)
        if m: cur = out.setdefault((int(m.group(1)), m.group(2)), []); continue
        if cur is not None: cur.append(line.rstrip('\n'))
    return out
def num(s): return float(s.replace(',', ''))
def parse(lines):
    r = {}
    for l in lines:
        m = re.match(r'^query: (\d+) commands .* = ([\d.]+) KQPS', l)
        if m: r['cmds'] = int(m.group(1)); r['kqps'] = float(m.group(2))
        m = re.match(r'^device: (\d+) cycles total, per-command latency (\d+)\.\.(\d+) cycles, completed (\d+), errors (0x[0-9a-f]+)', l)
        if m: r['dev'] = int(m.group(1)); r['lmin'] = int(m.group(2)); r['lmax'] = int(m.group(3)); r['done'] = int(m.group(4)); r['err'] = m.group(5)
        m = re.match(r'^latency spread: min (\d+), p50 (\d+), p90 (\d+), p99 (\d+), p99\.9 (\d+), max (\d+), mean ([\d.]+)', l)
        if m: r.update(p50=int(m.group(2)), p99=int(m.group(4)), p999=int(m.group(5)), max=int(m.group(6)), mean=float(m.group(7)))
        m = re.match(r'^traffic split: pages \(off-package\) ([\d.]+) B read, ([\d.]+) B written per command; top \(on-package\) ([\d.]+) B read, ([\d.]+) B written', l)
        if m: r['off'] = num(m.group(1)) + num(m.group(2)); r['on'] = num(m.group(3)) + num(m.group(4))
        m = re.match(r'^traffic: bucket port \(pages, off-package\) \d+ B read, \d+ B written = ([\d.]+) B read, ([\d.]+) B written per command', l)
        if m: r['off'] = num(m.group(1)) + num(m.group(2))
        m = re.match(r'^placement: tree (\d+) B = (\d+) B on-package', l)
        if m: r['top'] = int(m.group(2)); r['tree'] = int(m.group(1))
        if l.startswith('ALL RESPONSES CORRECT'): r['ok'] = True
        if l.startswith('ERRORS FOUND'): r['ok'] = False
    return r
def clocks(res):
    c = {}
    p = os.path.join(res, 'clocks.txt')
    if os.path.exists(p):
        for line in open(p):
            f = line.split()
            if len(f) >= 4 and f[3] not in ('', 'unknown'): c[(f[0], f[1])] = float(f[3])
    return c

def model_table():
    print('Tiny ORAM, 4 KB blocks, Z = 4: matched tops (DOMA v14c on-package bytes less N x 8 B of position map) and off-package')
    print('bytes per access from the tree layout (read + written; uniform leaves). DOMA v14c: 2 x (1 - r) x 8 x 4 KB.')
    print('%-8s %-3s %5s | %12s %12s %7s | %16s %10s' % ('records', 'L', 'r', 'DOMA on-pkg', 'Tiny top', 'of tree', 'Tiny off B/acc', 'DOMA off'))
    for n in (262144, 1048576, 2097152):
        L = depth(n); g = tp.geo(BLOCK, L)
        for p in (0, 20, 50, 100):
            t = tiny_top(n, p); off, path = offpkg_per_access(n, t)
            print('%-8d %-3d %4d%% | %9.3f GiB %9.3f GiB %6.1f%% | %9.0f (%4.1f%%) %10.0f' % (
                n, L, p, doma_v14c_onpkg(n, p) / 2**30, t / 2**30, 100.0 * t / g['tree'], off, 100.0 * off / path, 2 * (1 - p / 100) * 8 * BLOCK))

def fit(pts):
    """least squares mean = a + b * on + c * off over (on, off, mean) points; None if singular"""
    import itertools
    X = [(1.0, on, off) for on, off, _ in pts]; y = [m for _, _, m in pts]
    A = [[sum(X[k][i] * X[k][j] for k in range(len(X))) for j in range(3)] for i in range(3)]
    v = [sum(X[k][i] * y[k] for k in range(len(X))) for i in range(3)]
    n = 3; M = [A[i] + [v[i]] for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(M[r][i]))
        if abs(M[p][i]) < 1e-12: return None
        M[i], M[p] = M[p], M[i]
        for r in range(n):
            if r != i:
                f = M[r][i] / M[i][i]; M[r] = [M[r][k] - f * M[i][k] for k in range(n + 1)]
    return [M[i][n] / M[i][i] for i in range(n)]

def main():
    if sys.argv[1:] == ['--model']: model_table(); return 0
    res = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(HERE)))), 'results')
    clk = clocks(res)
    tiny = {}
    for f in sorted(os.listdir(res)) if os.path.isdir(res) else []:
        m = re.match(r'^tiny_q(38|39)_(.*)\.log$', f)
        if not m: continue
        for (n, t), lines in sections(os.path.join(res, f), 'DOMA_TINY_TOP').items():
            if t.startswith('doma:'):
                r = parse(lines); r['mhz'] = clk.get(('tiny', 'q%s' % m.group(1)), 0) or 220.0; tiny[(n, int(t[5:]))] = r
    doma = {}
    for (n, p), lines in sections(os.path.join(res, 'doma_v14c_pmhbm.log'), 'DOMA_HBM_PCT').items():
        r = parse(lines); r['mhz'] = clk.get(('doma', 'v14c_pmhbm'), 0) or 300.0; doma[(n, int(p))] = r
    if not tiny and not doma: print('no runs in %s (sweep_tiny.sh 38 39; compare_pmhbm.sh doma)' % res); model_table(); return 1
    us = lambda cyc, mhz: cyc / mhz
    print('1. Measured, 4 KB blocks. Latency in cycles (microseconds at the design\'s own clock). DOMA: mean = device cycles per')
    print('   command, tail = per-command maximum. Off-package = bytes per access read + written on the host-memory port.')
    hdr = '%-8s %4s | %-28s %-28s %-15s %8s | %-28s %-15s %10s %8s | %7s' % ('records', 'r', 'Tiny mean', 'Tiny p99 / p99.9', 'Tiny max', 'Tiny off',
                                                                          'DOMA mean', 'DOMA max', 'DOMA off', 'KQPS', 'mean x')
    print(hdr); bad = 0
    for n in sorted(set(k[0] for k in list(tiny) + list(doma))):
        for p in (0, 20, 50, 100):
            t = tiny.get((n, p), {}); d = doma.get((n, p), {})
            if not t and not d: continue
            for x in (t, d):
                if x and (not x.get('ok') or x.get('err', '0x0') != '0x0'): bad += 1
            tm = t.get('mean'); dm = d['dev'] / d['cmds'] if d.get('dev') and d.get('cmds') else None
            s_t = ('%8.0f (%7.2f us)' % (tm, us(tm, t['mhz']))) if tm else '-'
            s_tt = ('%7d / %7d (%6.1f us)' % (t['p99'], t['p999'], us(t['p999'], t['mhz']))) if tm else '-'
            s_tx = ('%7d (%5.1f us)' % (t['max'], us(t['max'], t['mhz']))) if tm else '-'
            s_d = ('%8.0f (%7.2f us)' % (dm, us(dm, d['mhz']))) if dm else '-'
            s_dx = ('%6d (%5.1f us)' % (d['lmax'], us(d['lmax'], d['mhz']))) if d.get('lmax') else '-'
            ratio = ('%6.1fx' % (us(tm, t['mhz']) / us(dm, d['mhz']))) if tm and dm else '-'
            print('%-8d %3d%% | %-28s %-28s %-15s %8s | %-28s %-15s %10s %8s | %7s' % (
                n, p, s_t, s_tt, s_tx, '%.0f' % t['off'] if 'off' in t else '-', s_d, s_dx, '%.0f' % d['off'] if 'off' in d else '-',
                '%s/%s' % ('%.1f' % t['kqps'] if 'kqps' in t else '-', '%.1f' % d['kqps'] if 'kqps' in d else '-'), ratio))
    print('   KQPS column: Tiny/DOMA. mean x: Tiny ORAM mean latency over DOMA mean latency, in time.')
    if bad: print('   WARNING: %d run(s) not clean (errors or wrong responses): see the logs' % bad)

    print('\n2. Tiny ORAM: off-package share of the path bytes, tree layout against the card\'s counters. A command moves whole')
    print('   paths: its own access plus the background evictions Tiny ORAM adds (paths per command = bytes / path bytes).')
    for (n, p), t in sorted(tiny.items()):
        if 'off' not in t or 'top' not in t: continue
        mo, path = offpkg_per_access(n, t['top']); tot = t['off'] + t['on']
        t['paths'] = tot / path
        print('   N=%-8d r=%3d%%: top %.3f GiB; off-package share: model %.2f%%, card %.2f%%; %.3f paths per command; %.0f B off-package per command' % (
            n, p, t['top'] / 2**30, 100.0 * mo / path, 100.0 * t['off'] / tot, t['paths'], t['off']))

    print('\n3. Tiny ORAM at 2M records (L = 19): model')
    pts = {n: [(t['on'], t['off'], t['mean']) for (m, p), t in tiny.items() if m == n and 'on' in t and 'mean' in t] for n in (262144, 1048576)}
    c256 = fit(pts[262144]) if len(pts[262144]) >= 3 else None
    if c256 and pts[1048576]:
        errs = ['%+.1f%%' % (100.0 * ((c256[0] + c256[1] * on + c256[2] * off) - m) / m) for on, off, m in pts[1048576]]
        print('   fit on 256K: mean = %.0f + %.4f * top B + %.4f * pages B (cycles); predicts the 1M runs to %s' % (c256[0], c256[1], c256[2], ', '.join(errs)))
    call = fit(pts[262144] + pts[1048576]) if len(pts[262144]) + len(pts[1048576]) >= 3 else None
    if not call: print('   needs the 256K and 1M runs'); return 1 if bad else 0
    print('   fit on both: mean = %.0f + %.4f * top B + %.4f * pages B (cycles)' % tuple(call))
    mhz = next(iter(tiny.values()))['mhz']; n2 = 2097152; L2 = depth(n2); g2 = tp.geo(BLOCK, L2); path2 = 2.0 * (L2 + 1) * g2['bkt'] * 64
    for p in (0, 20, 50, 100):
        t2 = tiny_top(n2, p); off2, _ = offpkg_per_access(n2, t2)
        t1 = tiny.get((1048576, p), {}); k99 = t1['p99'] / t1['mean'] if t1.get('mean') else None; k999 = t1['p999'] / t1['mean'] if t1.get('mean') else None
        ppc = t1.get('paths', 1.0)                                       # paths per command at 1M, same r
        off2 *= ppc; on2 = path2 * ppc - off2
        m2 = call[0] + call[1] * on2 + call[2] * off2
        d2 = doma.get((n2, p), {}); dm2 = d2['dev'] / d2['cmds'] if d2.get('dev') else None
        print('   r=%3d%%: top %.3f GiB (%.1f%% of the %.1f GiB tree), off-package %.0f B per command (DOMA %.0f); Tiny mean %.0f cycles (%.1f us)%s%s' % (
            p, t2 / 2**30, 100.0 * t2 / g2['tree'], g2['tree'] / 2**30, off2, 2 * (1 - p / 100) * 8 * BLOCK, m2, m2 / mhz,
            (', p99 %.0f, p99.9 %.0f (1M ratios)' % (k99 * m2, k999 * m2)) if k99 else '',
            ('; DOMA measured %.0f cycles (%.1f us): %.1fx' % (dm2, dm2 / d2['mhz'], (m2 / mhz) / (dm2 / d2['mhz']))) if dm2 else ''))
    return 1 if bad else 0

if __name__ == '__main__':
    sys.exit(main())
