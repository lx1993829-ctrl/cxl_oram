#!/bin/bash
# leak_runs_ov.sh -- the card leakage runs for the phase 3 overlap design (docs/LEAK_CARD_RUNBOOK_OV.md). One process per record
# count: small n makes same-bucket accesses frequent (the card's forced collisions), and repeated requests come from the classes.
# Usage, from fpga_zcu208/vitis/ (host_leak_ov built here, ../sim/card_leak_analyze_ov.py beside it):
#   bash leak_runs_ov.sh <bitstream.xclbin> <results folder>
# Settings (environment): BIG=1048576 CMDS=1000000 SMALLCMDS=200000 HBM=20 NS="14 35 70 4096 $BIG" LEAK_SEED=12345;
# the build's OV_PMIN, OV_GA, OV_XWB, OV_L, OV_LEQ (defaults: 1600, 1600, 300, 0 and 0, where 0 means the RTL default).
# Timing only: GET data and halts are not judged. If the design stops, that record count is reported as incomplete and the
# others still run. Exit 0 only if every record count is complete and nothing is flagged.
# A clean record count's CSV is deleted after its analysis, so disk use peaks at one CSV (about 1 GB at large n). It is kept
# if anything is flagged or the run is incomplete. KEEP_CSV=1 keeps them all.
XC=$1; R=${2:-leak_results}; mkdir -p "$R"
source /opt/xilinx/xrt/setup.sh > /dev/null; export DOMA_LAMBDA=7
BIG=${BIG:-1048576}; CMDS=${CMDS:-1000000}; SMALLCMDS=${SMALLCMDS:-200000}; HBM=${HBM:-20}; NS=${NS:-14 35 70 4096 $BIG}; LEAK_SEED=${LEAK_SEED:-12345}
OV_PMIN=${OV_PMIN:-1600}; OV_GA=${OV_GA:-1600}; OV_XWB=${OV_XWB:-300}; OV_L=${OV_L:-0}; OV_LEQ=${OV_LEQ:-0}
phases() { local c=$1
    echo "pair:uni/fixed:$c,pair:get/put:$c,pair:uni/rereq:$c,pair:put/zero:$c,pair:uni/bad:$c,rpair:uni/fixed:$c:16,rpair:uni/rereq:$c:16,rpair:uni/ab:$c:16,rpair:uni/t3:$c:16,rpair:uni/t4:$c:16,rpair:uni/t5:$c:16,uni:$c,scan:$c"; }
rc=0; : > "$R/verdict.txt"
for n in $NS; do
    c=$CMDS; [ "$n" -lt 100000 ] && c=$SMALLCMDS
    t=n$n
    echo "== n = $n, $c commands per phase, seed $LEAK_SEED"
    DOMA_N=$n DOMA_HBM_PCT=$HBM DOMA_LEAK_SEED=$LEAK_SEED DOMA_LEAK_CSV="$R/$t.csv" DOMA_PHASES=$(phases "$c") ./host_leak_ov "$XC" 65536 > "$R/$t.log" 2>&1
    tail -1 "$R/$t.log"
    complete=1; grep -q 'ALL PHASES COMPLETE' "$R/$t.log" || { complete=0; rc=1; }
    if python3 ../sim/card_leak_analyze_ov.py "$R/$t.csv" --pmin "$OV_PMIN" --ga "$OV_GA" --xwb "$OV_XWB" --l "$OV_L" --leq "$OV_LEQ" --out "$R/$t.json" > "$R/$t.analysis" 2>&1; then
        [ "${KEEP_CSV:-0}" = 1 ] || [ "$complete" = 0 ] || rm -f "$R/$t.csv"
    else rc=1; fi
    tail -1 "$R/$t.analysis" | tee -a "$R/verdict.txt"
    grep -a -E "could detect|FAIL  " "$R/$t.analysis"
    # the access rate per kind of command: latency and the schedule check cannot see a stall before a command is issued
    rc_c=$(( c < 500000 ? c : 500000 ))
    DOMA_N=$n DOMA_HBM_PCT=$HBM DOMA_PHASES=get:$rc_c,put:$rc_c,zero:$rc_c,mix:$rc_c,fixed:$rc_c,rereq:$rc_c,scan:$rc_c,get:$rc_c ./host_leak_ov "$XC" 65536 > "$R/$t.rate.log" 2>&1
    python3 ../sim/card_rate_check.py "$R/$t.rate.log" > "$R/$t.rate" 2>&1 || rc=1
    tail -1 "$R/$t.rate" | tee -a "$R/verdict.txt"
done
[ $rc = 0 ] && echo "EVERY RECORD COUNT CLEAN" || echo "SOMETHING TO LOOK AT: $R/verdict.txt and the .analysis and .rate files"
exit $rc
