# Card leakage tests for the overlap design on the U55C (4 KB, λ = 7, arrival, phase 3)

Design: `fpga_zcu208_ov4p3x300_v14c_full`, built with `OV_PMIN=1600 OV_GA=1600 OV_XWB=300` and `doma_big2m_rama.cfg`.

Files added (nothing in the package is overwritten):
- `vitis/host_leak_ov.cpp`: `host_leak.cpp` extended for overlap.
- `vitis/leak_runs_ov.sh`: every card run.
- `sim/card_leak_analyze_ov.py`: the per-command analysis.
- `sim/card_rate_check.py`: the access rate per kind of command.
- `patches/resp_uniform_write.patch`: the fix for the GET/PUT rate difference (section 8).
- `patches/ov_trace.patch`: the optional `OV_TRACE=1` build (section 2).

The older `host_leak.cpp` and `card_leak_analyze.py` are for the design without overlap. They need `TRACE=1`, which `build.sh` refuses with overlap.

## 1. What the tests show

| Test | Classes | Why |
|---|---|---|
| `pair:uni/fixed` | uniform keys, one fixed key | stash hits against misses |
| `pair:get/put` | GET, PUT | the operation |
| `pair:uni/rereq` | uniform, the previous command's key | repeated requests |
| `pair:put/zero` | random PUT data, all-zero PUT data | the data |
| `pair:uni/bad`, `pair:uni/badput` | valid, out-of-range GET or PUT | rejection |
| `rpair:uni/fixed`, `rpair:uni/rereq`, `rpair:uni/ab`, `rpair:uni/t3`, `rpair:uni/t4`, `rpair:uni/t5` | uniform, repeated keys, per run of 16 commands | **repeated requests with all four contexts holding one class** |
| n = 14, 35 | all of the above | **forced collisions**: 2 or 5 buckets, so an access often shares a bucket with one in flight |
| n = 4,096 and n = 1,048,576 | all of the above | collisions rare, card scale |
| `uni` against `scan` | segments | reported, not judged, as drift can separate them |

The card has no way to force a collision onto one chosen distance. That targeted test, with exact pairs, is in simulation (groups C and X).

## 2. Bitstreams

| Run | Bitstream | What it gives |
|---|---|---|
| **A, required** | the production build you are making now, unmodified | Latency per command and the access rate, on the bitstream you measure |
| **B, recommended** | the same design with `OV_TRACE=1` | Also the exact schedule check on real memories, per-location latency and public stream statistics |
| C, recommended if B is built | B with `OV_TEST_LEAK=1` | Positive control on the card: a PUT's read one cycle late must fail the exact check. A clean result proves little without it. |

Build B and C each in their own folder, and never deploy them. They send internal event times to the host.

```bash
cd ~/p3rx300_tr/fpga_zcu208 && patch -p1 < patches/ov_trace.patch && cd vitis
OVERLAP=4 P3=1 OV_PMIN=1600 OV_GA=1600 OV_XWB=300 OV_TRACE=1 SCHED=arrival BEATS=128 CFG=doma_big2m_rama.cfg NMAX=2097152 LAMBDA=7 TARGET=hw nohup bash build.sh > build.log 2>&1 &
```

Check that timing closes at 300 MHz (`check_timing.sh`, which `build.sh` runs). The trace adds a 28-bit subtraction and a 4-to-1 multiplexer on the path into the header record, and this has not been through Vivado.

## 3. Build the host (in `vitis/`)

```bash
g++ -std=c++17 -O2 host_leak_ov.cpp -I$XILINX_XRT/include -L$XILINX_XRT/lib -lxrt_coreutil -pthread -o host_leak_ov
```

Run it from `vitis/`. It checks Z and λ against `../rtl` and refuses to run on a mismatch.

## 4. Run

Try a short run first, a few minutes on the card, to catch any setup problem:

```bash
NS=35 SMALLCMDS=2000 bash leak_runs_ov.sh <run A bitstream>.xclbin leak_try
```

Then the full runs:

```bash
bash leak_runs_ov.sh <run A bitstream>.xclbin leak_A
bash leak_runs_ov.sh <run B bitstream>.xclbin leak_B
```

The script takes four record counts, each in its own process, with 14 phases each. Each large-n phase is 1M commands and each small-n phase 200,000.

- The large run uses 1,048,576 records (`BIG` sets it). The bitstream stays `NMAX=2097152`, as n is chosen at run time. Results apply to the record counts run.
- A clean record count's CSV is deleted after its analysis, so disk use peaks at about 1 GB. A flagged or incomplete run keeps its CSV, as it is then needed. `KEEP_CSV=1` keeps them all.
- If the design stops, that record count ends as incomplete, and the others still run.
- For a second seed, set `LEAK_SEED=<n>` and a new results folder.

To change the design's parameters, set the same `OV_PMIN`, `OV_GA`, `OV_XWB`, `OV_L` and `OV_LEQ` in the script's environment.

## 5. Read the results

Each `n<records>.log` must end with `ALL PHASES COMPLETE`, each `n<records>.analysis` must end with `NO LEAK FOUND IN THESE COMPARISONS`, and each `n<records>.rate` must end with `RATE DOES NOT DEPEND ON THE COMMANDS`. The script ends with `EVERY RECORD COUNT CLEAN`.

Each `n<records>.control` must end with `ANALYSIS CONTROL PASSED`. It adds a difference to one class of the run's real data, and every latency comparison must flag it. It checks the analysis, not the design.

**Rate check positive control, no new bitstream.** Run the rate check's record count on the build from before the response-write fix: `NS=4096 bash leak_runs_ov.sh ~/p3rx300/fpga_zcu208/vitis/doma_hw.xclbin leak_ctrl_old`. Its `n4096.rate` must end with `RATE DEPENDS ON THE COMMANDS`.

**Why there are two checks.** A command's latency starts only when it is issued, and the schedule check takes the request time as an input, so neither sees a stall before the issue. The rate check does, by comparing device cycles per command across kinds of command.

**Pass, run A.** No comparison has |t| > 4.5 or a p-value rejected by Holm at 0.01, and the rate check passes. These are timing tests: GET data and halts are not judged. If the design stops, that record count is reported as incomplete and has to be rerun.

**Pass, run B.** As run A, and every schedule rule is `exact`, so all of these hold for every access:
- s = max(s_prev + PMIN, t'(j−4) + L, request, same-bucket readers' issue)
- ri = max(s + CT_RD, t'(e) + LEQ, previous issue + 2, a(j−2))
- wi = t' + AR_WB
- rel = t' + AR_REL or AR_REL_H
- end = rel + a constant

**Read the detection threshold.** Each analysis prints the smallest mean latency difference it could detect. A clean run A rules out a leak only above that size. Run B's exact check does not have this limit, because it treats the memory's completion time as an input.

**If a row is flagged:**
1. Rerun that record count with another `LEAK_SEED`.
2. A flag that does not repeat is a false alarm under the multiple-comparison budget.
3. A flag that repeats is a finding. Send the logs.

A failed schedule rule is not subject to this. It is deterministic, so send the logs straight away.

## 6. Limits

- Run A cannot separate on- and off-package accesses or see same-bucket waits. The coin makes the comparison valid, but those effects add noise, so its detection threshold is larger.
- The keys come from the host's own generator and the buckets from the design's PRNG. The tests do not examine whether the PRNG is unpredictable.
- Run B's bitstream is a different netlist from run A's. It is cycle-identical in simulation, but its placement differs, so report its achieved clock.

- n = 70 was dropped from the runs after the host crashed with a bus error during it. The crash is intermittent, unexplained and also happened at larger n, so it can still stop another record count. A crash is not a leak result: rerun that record count in a new results folder.

## 7. Send back

- `verdict.txt`, every `n*.log`, `n*.analysis`, `n*.rate`, `n*.rate.log` and `n*.json` from each results folder
- any CSV kept because of a flag or an incomplete run, if small enough to transfer
- the achieved clock of each bitstream, and the commit or zip name of the design

## 8. Known finding: the access rate depended on the operation

First U55C run, 4,096 records, 500,000 commands per phase, unpatched: all GET 1,624.9 cycles per command with a longest response write of 137 cycles; all PUT 2,079.6 with 2,217; all PUT with zero data 2,079.8 with 2,220; a 50% mix 1,633.2 with 2,181. A repeated all-GET phase gave 1,625.3. At 2M records, all PUT reached 2,344.

The kernel writes a PUT's response data slot with every byte strobe off. `patches/resp_uniform_write.patch` writes every slot alike, with zeros for a PUT. It changes the response memory's contents only for a PUT's slot, which no host reads. It is for the overlap builds only: the same strobe line exists on the path without overlap, which is not changed. After the patch, a regression that expects a PUT's slot to stay untouched needs updating.

The strobes as the cause are inferred from the code and these numbers. The patched bitstream's rate check is the test.
