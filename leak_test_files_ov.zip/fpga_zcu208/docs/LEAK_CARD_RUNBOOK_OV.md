# Card leakage tests for the overlap design on the U55C (4 KB, λ = 7, arrival, phase 3)

Design: `fpga_zcu208_ov4p3x300_v14c_full`, built with `OV_PMIN=1600 OV_GA=1600 OV_XWB=300` and `doma_big2m_rama.cfg`.

Files added (nothing in the package is overwritten):
- `vitis/host_leak_ov.cpp`: `host_leak.cpp` extended for overlap.
- `vitis/leak_runs_ov.sh`: every card run.
- `sim/card_leak_analyze_ov.py`: the analysis.
- `patches/ov_trace.patch`: the optional `OV_TRACE=1` build (section 2).

The older `host_leak.cpp` and `card_leak_analyze.py` are for the design without overlap. They need `TRACE=1`, which `build.sh` refuses with overlap.

## 1. What the tests show

| Test | Classes | Why |
|---|---|---|
| `pair:uni/fixed` | uniform keys, one fixed key | stash hits against misses |
| `pair:get/put` | GET, PUT | the operation |
| `pair:uni/rereq` | uniform, the previous command's key | repeated requests |
| `pair:put/zero` | random PUT data, all-zero PUT data | the data |
| `pair:uni/bad` | valid, out-of-range key | rejection |
| `rpair:uni/fixed`, `rpair:uni/rereq`, `rpair:uni/ab`, `rpair:uni/t3`, `rpair:uni/t4`, `rpair:uni/t5` | uniform, repeated keys, per run of 16 commands | **repeated requests with all four contexts holding one class** |
| n = 14, 35, 70 | all of the above | **forced collisions**: 2, 5 or 10 buckets, so an access often shares a bucket with one in flight |
| n = 4,096 and n = 2,097,152 | all of the above | collisions rare, card scale |
| `uni` against `scan` | segments | reported, not judged, as drift can separate them |

The card has no way to force a collision onto one chosen distance. That targeted test, with exact pairs, is in simulation (groups C and X).

## 2. Bitstreams

| Run | Bitstream | What it gives |
|---|---|---|
| **A, required** | the production build you are making now, unmodified | Latency per command and any halts, on the bitstream you measure |
| **B, recommended** | the same design with `OV_TRACE=1` | Also the exact schedule check on real memories, per-location latency and public stream statistics |
| C, recommended if B is built | B with `OV_TEST_LEAK=1` | Positive control on the card: a PUT's read one cycle late must fail the exact check. A clean result proves little without it. |

Build B and C each in their own folder, and never deploy them. They send internal event times to the host.

```bash
cd ~/p3rx300_tr/fpga_zcu208 && patch -p1 < patches/ov_trace.patch && cd vitis
OVERLAP=4 P3=1 OV_PMIN=1600 OV_GA=1600 OV_XWB=300 OV_TRACE=1 SCHED=arrival BEATS=128 CFG=doma_big2m_rama.cfg NMAX=2097152 LAMBDA=7 TARGET=hw nohup bash build.sh > build.log 2>&1 &
```

Check that timing closes at 300 MHz (`check_timing.sh`, which `build.sh` runs). The trace adds a 28-bit subtraction and a 4-to-1 multiplexer on the path into the header record, and this has not been through Vivado.

## 3. Build the host (in `vitis/`)

```bash
g++ -std=c++17 -O2 host_leak_ov.cpp -I$XILINX_XRT/include -L$XILINX_XRT/lib -lxrt_coreutil -pthread -o host_leak_ov
```

Run it from `vitis/`. It checks Z and λ against `../rtl` and refuses to run on a mismatch.

## 4. Run

Try a short run first, a few minutes on the card, to catch any setup problem:

```bash
NS=70 SMALLCMDS=2000 bash leak_runs_ov.sh <run A bitstream>.xclbin leak_try
```

Then the full runs:

```bash
bash leak_runs_ov.sh <run A bitstream>.xclbin leak_A
bash leak_runs_ov.sh <run B bitstream>.xclbin leak_B
```

The script takes five record counts, each in its own process, with 13 phases each. Each large-n phase is 1M commands and each small-n phase 200,000.

- n = 2,097,152 needs 16 GB of card host memory. If the machine does not have it, use `BIG=1048576`.
- A clean record count's CSV is deleted after its analysis, so disk use peaks at about 1 GB. A flagged or halted run keeps its CSV, as it is then needed. `KEEP_CSV=1` keeps them all.
- A halt stops that record count only.
- For a second seed, set `LEAK_SEED=<n>` and a new results folder.

To change the design's parameters, set the same `OV_PMIN`, `OV_GA`, `OV_XWB`, `OV_L` and `OV_LEQ` in the script's environment.

## 5. Read the results

Each `n<records>.log` must end with `ALL PHASES CORRECT`, and each `n<records>.analysis` must end with `NO LEAK FOUND`. The script ends with `EVERY RECORD COUNT CLEAN`.

**Pass, run A.** No comparison has |t| > 4.5 or a p-value rejected by Holm at 0.01, there is no halt, and every GET is correct.

**Pass, run B.** As run A, and every schedule rule is `exact`, so all of these hold for every access:
- s = max(s_prev + PMIN, t'(j−4) + L, request, same-bucket readers' issue)
- ri = max(s + CT_RD, t'(e) + LEQ, previous issue + 2, a(j−2))
- wi = t' + AR_WB
- rel = t' + AR_REL or AR_REL_H
- end = rel + a constant

**Read the detection threshold.** Each analysis prints the smallest mean latency difference it could detect. A clean run A rules out a leak only above that size. Run B's exact check does not have this limit, because it treats the memory's completion time as an input.

**If a row is flagged:**
1. Rerun that record count with another `LEAK_SEED`.
2. A flag that does not repeat is a false alarm under the multiple-comparison budget.
3. A flag that repeats is a finding. Send the logs.

A failed schedule rule is not subject to this. It is deterministic, so send the logs straight away.

**A halt (`LEAK_HALT` line, `.csv.halt` file)** is a result, not only a failure. Past the stash margin, simulation shows that the halt point depends on the keys. Send which record count, phase and command it stopped at, the class in flight and the halt record. Then:
- Run the same record count with two more seeds, to see whether it repeats.
- If it does, compare the halts across key classes before changing `OV_PMIN` or `OV_XWB`.

## 6. Limits

- Run A cannot separate on- and off-package accesses or see same-bucket waits. The coin makes the comparison valid, but those effects add noise, so its detection threshold is larger.
- Halts are the only sign of how close the design is to its deadlines. No build here reports the remaining slack.
- The keys come from the host's own generator and the buckets from the design's PRNG. The tests do not examine whether the PRNG is unpredictable.
- Run B's bitstream is a different netlist from run A's. It is cycle-identical in simulation, but its placement differs, so report its achieved clock.

## 7. Send back

- `verdict.txt`, every `n*.log`, `n*.analysis` and `n*.json` from each results folder
- any `*.csv.halt`
- any CSV kept because of a flag or a halt, if small enough to transfer
- the achieved clock of each bitstream, and the commit or zip name of the design
