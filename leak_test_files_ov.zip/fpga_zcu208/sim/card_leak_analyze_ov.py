#!/usr/bin/env python3
"""card_leak_analyze_ov.py -- analyse a card leakage run of vitis/host_leak_ov (docs/LEAK_CARD_RUNBOOK_OV.md).

    python3 card_leak_analyze_ov.py leak.csv [--out summary.json] [--pmin 1600 --ga 1600 --xwb 300 --l 0 --leq 0 --ctrd 600]
    python3 card_leak_analyze_ov.py leak.csv --export-fix fix.txt      # the records in sim/check_p3.py's input format

leak.csv is DOMA_LEAK_CSV: one row per command. Halts and data correctness are not judged: this is a timing comparison.

Every bitstream, latency only:
  1. Class comparisons. For each pair phase: the command's own latency (lat) and the next command's latency (lat_next),
     class 0 against class 1, with Welch's t and the two-sample KS test. A comparison is flagged if |t| > 4.5 or if its
     p-value is rejected by Holm's method at family-wise alpha = 0.01. The coin is independent of everything else, so
     the comparison is a randomized experiment: on- and off-package accesses and same-bucket waits add noise, not bias.
     Pair phases (coin per command) compare commands. rpair phases (coin per run of L commands) compare the runs' means,
     because latencies within a run are correlated and the run is what the coin assigned.

OV_TRACE=1 bitstream, in addition (summary byte 2 bit 4, detected from the CSV):
  3. The exact schedule (docs/overlap_rtl_spec.md section 17, the rules of sim/check_p3.py). Every visible time is
     recomputed from public events only: the read completions, the requests, the same-bucket masks, the location.
     One pipeline offset per term is fitted on a sample, and must then hold for EVERY access. One cycle off anywhere fails.
     This does not depend on how noisy the real memories are, since a(j) is an input.
  4. Public streams per class: on-package share and same-bucket rates (bits of em) compared between the classes, and lat
     within each location.
  Segments (scan against uni) are reported but not judged: they are not interleaved, so drift can separate them.
This analysis cannot see a stall before a command is issued: lat starts at the issue, and the schedule check takes the
request time as an input. sim/card_rate_check.py covers that, and "NO LEAK FOUND" here does not.
"""
import argparse, csv, json, sys, warnings
from array import array
from collections import defaultdict
warnings.filterwarnings("ignore", category=RuntimeWarning)   # scipy: near-identical samples

import numpy as np
from scipy import stats

NUM = ("phase", "launch", "cmd", "run", "class", "key", "lat", "s", "rq", "ri", "a", "wi", "rel", "end", "hbm", "em")
SAT = 0xFFFF


def load(path):
    col = {k: array("q") for k in NUM}
    kind, op = [], []
    kinds, ops = {}, {}
    status_bad = 0
    with open(path) as f:
        for r in csv.DictReader(f):
            try:                                     # a run cut short can leave a partial last row
                vals = [int(r[k]) for k in NUM]
                st = int(r["status"], 16)
            except (TypeError, ValueError):
                status_bad += 1
                continue
            for k, v in zip(NUM, vals):
                col[k].append(v)
            kind.append(kinds.setdefault(r["kind"], len(kinds)))
            op.append(ops.setdefault(r["op"], len(ops)))
    d = {k: np.frombuffer(v, dtype=np.int64) if len(v) else np.zeros(0, np.int64) for k, v in col.items()}
    d["kind"] = np.array(kind, dtype=np.int32)
    d["op"] = np.array(op, dtype=np.int32)
    return d, {v: k for k, v in kinds.items()}, status_bad


def welch_ks(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    if len(a) < 2 or len(b) < 2:
        return None
    se = np.sqrt(a.var(ddof=1) / len(a) + b.var(ddof=1) / len(b))
    if se == 0:
        same = a[0] == b[0]
        return dict(n0=len(a), n1=len(b), mean0=float(a.mean()), mean1=float(b.mean()), t=0.0 if same else float("inf"),
                    p_t=1.0 if same else 0.0, ks=0.0 if same else 1.0, p_ks=1.0 if same else 0.0, detect=0.0)
    t, pt = stats.ttest_ind(a, b, equal_var=False)
    ks = stats.ks_2samp(a, b, method="asymp")
    return dict(n0=len(a), n1=len(b), mean0=float(a.mean()), mean1=float(b.mean()), t=float(t), p_t=float(pt),
                ks=float(ks.statistic), p_ks=float(ks.pvalue), detect=float(4.5 * se))


def holm(p, alpha=0.01):
    p = np.asarray(p); order = np.argsort(p); m = len(p); rej = np.zeros(m, bool)
    for i, idx in enumerate(order):
        if p[idx] <= alpha / (m - i):
            rej[idx] = True
        else:
            break
    return rej


def by_launch(d):
    """Index ranges of consecutive commands in one launch: a launch drains, so each is one schedule sequence."""
    if len(d["lat"]) == 0:
        return []
    cut = np.nonzero((np.diff(d["launch"]) != 0) | (np.diff(d["cmd"]) != 1))[0] + 1
    b = np.concatenate(([0], cut, [len(d["lat"])]))
    return [(int(b[i]), int(b[i + 1])) for i in range(len(b) - 1)]


# ---- the exact schedule -------------------------------------------------------------------------------------------
def schedule(d, P):
    """The rules of check_p3.py over the header records. Returns (results, totals)."""
    GA, PMIN, CTRD = P["ga"], P["pmin"], P["ctrd"]
    ARWB, AREL, ARELH = 1785 + P["xwb"], 3033 + P["xwb"], 2384 + P["xwb"] + 700
    LEQ = P["leq"] or ARWB + 1024 + 3300
    L = P["l"] or max(ARELH, AREL) + 250
    s, hbm, em = d["s"], d["hbm"], d["em"]
    rq, ri, a, wi, rel, end = s - d["rq"], s + d["ri"], s + d["a"], s + d["wi"], s + d["rel"], s + d["end"]
    n = len(s)
    sat = (d["ri"] == SAT) | (d["a"] == SAT) | (d["wi"] == SAT) | (d["rel"] == SAT) | (d["end"] == SAT) | (d["rq"] == SAT)
    # One sequence across launches: the core's counter runs on, and a same-bucket gate can reach back over a launch boundary.
    # The first accesses' same-bucket masks can refer to the preload, which is not recorded, so the read rule skips those.
    idx = np.arange(n, dtype=np.int64)
    tp = np.maximum.accumulate(a - idx * GA) + idx * GA if n else np.zeros(0, np.int64)
    NONE = np.iinfo(np.int64).min // 2

    def back(x, k):
        y = np.full(n, NONE, np.int64)
        y[k:] = x[:-k]
        y[idx < k] = NONE
        return y

    # start rule: s = max(s_prev + PMIN, t'(j-4) + L, request, same-bucket readers' issue)
    hold = np.full(n, NONE, np.int64)
    for q, dist in ((1, 3), (2, 2), (3, 1)):              # q back from j; that access is dist after j-4
        emq = back(em, q); riq = back(ri, q)
        hit = (idx >= 4) & (emq != NONE) & (((np.where(emq == NONE, 0, emq)) >> (dist - 1)) & 1 == 1)
        hold[hit] = np.maximum(hold[hit], riq[hit])
    start_terms = [("s_prev+PMIN", back(s, 1) + PMIN), ("t'+L", back(tp, 4) + L), ("request", rq), ("reader issue", hold)]
    # read issue: ri = max(s + CT_RD, t'(e) + LEQ, previous issue + 2, completion two reads back)
    eqt = np.full(n, NONE, np.int64)
    for dist in (1, 2, 3):
        hit = (idx >= dist) & ((em >> (dist - 1)) & 1 == 1)
        v = back(tp, dist)
        eqt[hit] = np.maximum(eqt[hit], v[hit] + LEQ)
    ri_terms = [("s+CT_RD", s + CTRD), ("t'(e)+LEQ", eqt), ("prev+2", back(ri, 1) + 2), ("copy free", back(a, 2))]

    def fit(name, obs, terms, mask):
        use = np.nonzero(mask)[0]
        sample = use[:min(len(use), 200000)]
        offs = [0] * len(terms)

        def miss(idxs, o):
            pred = np.full(len(idxs), NONE, np.int64)
            for (_, v), x in zip(terms, o):
                vv = v[idxs]
                pred = np.maximum(pred, np.where(vv > NONE // 2, vv + x, NONE))
            return int(np.count_nonzero(pred != obs[idxs]))
        best = miss(sample, offs)
        for _ in range(4):                                  # coordinate search: each term's pipeline offset, a few cycles
            for k in range(len(terms)):
                for x in range(-8, 9):
                    o = list(offs); o[k] = x
                    m = miss(sample, o)
                    if m < best:
                        best, offs = m, o
            if best == 0:
                break
        pred = np.full(len(use), NONE, np.int64)
        for (_, v), x in zip(terms, offs):
            vv = v[use]
            pred = np.maximum(pred, np.where(vv > NONE // 2, vv + x, NONE))
        wrong = use[pred != obs[use]]
        alone = [0] * len(terms)
        vals = np.stack([np.where(v[use] > NONE // 2, v[use] + x, NONE) for (_, v), x in zip(terms, offs)])
        top = vals.max(axis=0)
        cnt = (vals == top).sum(axis=0)
        for k in range(len(terms)):
            alone[k] = int(np.count_nonzero((vals[k] == top) & (cnt == 1)))
        return dict(rule=name, accesses=int(len(use)), wrong=int(len(wrong)), first_wrong=[int(x) for x in wrong[:5]],
                    terms={t: dict(offset=x, decides=c) for (t, _), x, c in zip(terms, offs, alone)})

    ok = ~sat
    res = [fit("start  s = max(s_prev + PMIN, t'(j-4) + L, request, readers' issue)", s, start_terms, ok & (idx >= 1)),
           fit("read issue  ri = max(s + CT_RD, t'(e) + LEQ, prev + 2, a(j-2))", ri, ri_terms, ok & (idx >= 3)),
           fit("write-back  wi = t' + AR_WB", wi, [("t'+AR_WB", tp + ARWB)], ok),
           fit("release off package  rel = t' + AR_REL", rel, [("t'+AR_REL", tp + AREL)], ok & (hbm == 0)),
           fit("release on package  rel = t' + AR_REL_H", rel, [("t'+AR_REL_H", tp + ARELH)], ok & (hbm == 1))]
    de = (end - rel)[ok]
    vals, cnt = np.unique(de, return_counts=True)
    if len(vals):
        top = vals[np.argmax(cnt)]
        res.append(dict(rule="end = release + a constant", accesses=int(len(de)), wrong=int(np.count_nonzero(de != top)),
                        first_wrong=[], terms={f"constant {int(top)}": dict(offset=0, decides=int(cnt.max()))}))
    tot = dict(accesses=int(n), saturated=int(np.count_nonzero(sat)), on_package=int(np.count_nonzero(hbm == 1)),
               same_bucket=int(np.count_nonzero(em)), LEQ=int(LEQ), L=int(L), AR_WB=ARWB, AR_REL=AREL, AR_REL_H=ARELH)
    return res, tot


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("leak_csv")
    ap.add_argument("--out", default="card_leak_ov_summary.json")
    ap.add_argument("--pmin", type=int, default=1600); ap.add_argument("--ga", type=int, default=1600)
    ap.add_argument("--xwb", type=int, default=300); ap.add_argument("--l", type=int, default=0)
    ap.add_argument("--leq", type=int, default=0); ap.add_argument("--ctrd", type=int, default=600)
    ap.add_argument("--export-fix", default="", help="write the records in check_p3.py's input format, then continue")
    a = ap.parse_args()
    P = dict(pmin=a.pmin, ga=a.ga, xwb=a.xwb, l=a.l, leq=a.leq, ctrd=a.ctrd)

    d, kinds, cut_rows = load(a.leak_csv)
    if cut_rows:
        print(f"note: {cut_rows} incomplete row(s) skipped: this CSV was cut short")
    n = len(d["lat"])
    traced = bool(n and np.any(d["s"] != 0))
    print(f"{n} commands, {len(np.unique(d['phase']))} phases, {'OV_TRACE records' if traced else 'latency only (no OV_TRACE records)'}; "
          f"PMIN {a.pmin}, GA {a.ga}, XWB {a.xwb}, L {a.l or 'RTL default'}, LEQ {a.leq or 'RTL default'}")

    if a.export_fix:
        with open(a.export_fix, "w") as f:
            for i in range(n):                           # consecutive numbers: one sequence, across launches
                s = int(d["s"][i])
                f.write(f"{i} {s} {s - int(d['rq'][i])} {int(d['em'][i] != 0)} {int(d['hbm'][i])} 0 {s + int(d['a'][i])} "
                        f"{s + int(d['ri'][i])} {s + int(d['wi'][i])} {int(d['em'][i])} {s + int(d['rel'][i])} {s + int(d['end'][i])}\n")
        print(f"wrote {a.export_fix}")

    lat_next = np.full(n, -1, np.int64)
    for b, e in by_launch(d):
        if e - b > 1:
            lat_next[b:e - 1] = d["lat"][b + 1:e]

    tests, seg = [], []
    names = {}
    phases = sorted(np.unique(d["phase"]).tolist())
    for ph in phases:
        m = d["phase"] == ph
        ks = sorted(set(zip(d["class"][m].tolist(), d["kind"][m].tolist())))
        if len(ks) != 2:
            names[ph] = kinds[ks[0][1]] if ks else "?"
            continue
        names[ph] = "/".join(kinds[k] for _, k in ks)
        cl = d["class"][m]; runs = d["run"][m]; lat = d["lat"][m]; nx = lat_next[m]
        cmds_per_run = len(lat) / max(1, len(np.unique(runs)))
        by_run = cmds_per_run > 1.5
        label = f"{'runs' if by_run else 'pair'} {names[ph]} (phase {ph})"

        def add(q, x, c, loc="all", sel=None):
            if sel is not None:
                x, c = x[sel], c[sel]
            t = welch_ks(x[c == 0], x[c == 1])
            if t:
                tests.append((label, loc, q, t))
        if by_run:                                  # the coin's unit is the run: its mean is the observation
            u, inv = np.unique(runs, return_inverse=True)
            cnt = np.bincount(inv)
            mean = np.bincount(inv, lat) / cnt
            rc = np.zeros(len(u), np.int64); rc[inv] = cl
            add("lat", mean, rc)
            add("lat_next_run", mean[1:], rc[:-1])       # the next run's mean, by this run's class
            if traced:
                hb = d["hbm"][m]
                for loc, name in ((0, "off"), (1, "on")):
                    w = hb == loc
                    if w.sum():
                        cn = np.bincount(inv[w], minlength=len(u)); sm = np.bincount(inv[w], lat[w], minlength=len(u))
                        have = cn > 0
                        add("lat", sm[have] / cn[have], rc[have], loc=name)
        else:
            add("lat", lat, cl)
            have = nx >= 0
            add("lat_next", nx, cl, sel=have)
            if traced:
                hb = d["hbm"][m]
                for loc, name in ((0, "off"), (1, "on")):
                    w = hb == loc
                    if w.sum():
                        add("lat", lat, cl, loc=name, sel=w)
        if traced:
            add("on_package", d["hbm"][m].astype(float), cl)
            for bit in (0, 1, 2):
                add(f"same_bucket_{bit + 1}", ((d["em"][m] >> bit) & 1).astype(float), cl)

    single = {ph: names[ph] for ph in phases if "/" not in names[ph]}
    up = [ph for ph, k in single.items() if k == "uni"]
    for sp, k in single.items():
        if k == "scan" and up:
            t = welch_ks(d["lat"][d["phase"] == up[0]], d["lat"][d["phase"] == sp])
            if t:
                seg.append((f"segment uni (phase {up[0]}) / scan (phase {sp})", "all", "lat", t))

    rej = holm([min(t["p_t"], t["p_ks"]) for *_, t in tests]) if tests else []
    print(f"\n== class comparisons (flag: |t| > 4.5, or Holm at 0.01 over {len(tests)} comparisons)")
    print(f"  {'comparison':<36}{'loc':<5}{'qty':<16}{'n0':>9}{'n1':>9}{'mean diff':>11}{'|t|':>8}{'KS':>8}{'detect':>9}  result")
    flagged = 0; out_tests = []
    for (lab, loc, q, t), hr in zip(tests, rej):
        bad = bool(abs(t["t"]) > 4.5 or hr)
        flagged += int(bad)
        out_tests.append(dict(test=lab, loc=loc, q=q, flagged=bad, **t))
        print(f"  {lab:<36}{loc:<5}{q:<16}{t['n0']:>9}{t['n1']:>9}{t['mean0'] - t['mean1']:>11.3f}{abs(t['t']):>8.2f}{t['ks']:>8.4f}"
              f"{t['detect']:>9.2f}  {'FLAG' if bad else 'ok'}")
    lat_rows = [t for lab, loc, q, t in tests if q == "lat" and loc == "all"]
    if lat_rows:
        print(f"  the smallest mean latency difference these comparisons could detect: {min(t['detect'] for t in lat_rows):.1f} to "
              f"{max(t['detect'] for t in lat_rows):.1f} cycles")
    if seg:
        print("\n== segments (not interleaved: drift can separate them; reported, not judged)")
        for lab, loc, q, t in seg:
            print(f"  {lab:<36}{loc:<5}{q:<16}{t['n0']:>9}{t['n1']:>9}{t['mean0'] - t['mean1']:>11.3f}{abs(t['t']):>8.2f}{t['ks']:>8.4f}{t['detect']:>9.2f}")

    sched_ok = True; sres = []; stot = {}
    if traced:
        sres, stot = schedule(d, P)
        print(f"\n== exact schedule: {stot['accesses']} accesses, {stot['on_package']} on package, {stot['same_bucket']} same-bucket, "
              f"{stot['saturated']} with a saturated field; AR_WB {stot['AR_WB']}, AR_REL {stot['AR_REL']}, AR_REL_H {stot['AR_REL_H']}, L {stot['L']}, LEQ {stot['LEQ']}")
        for r in sres:
            good = r["wrong"] == 0
            sched_ok = sched_ok and good
            desc = ", ".join(f"{k} {v['offset']:+d} (decides {v['decides']})" for k, v in r["terms"].items())
            print(f"  {'PASS' if good else 'FAIL'}  {r['rule']}: {r['accesses']} accesses, {'exact' if good else str(r['wrong']) + ' not matching'}; {desc}")
            if not good:
                print(f"        first differing accesses (row in the CSV, 0-based): {r['first_wrong']}")
        if stot["saturated"]:
            print(f"  note: {stot['saturated']} accesses have a time beyond 65,534 cycles and are left out of the exact check")
    else:
        print("\n== exact schedule: not available without OV_TRACE records (latency comparisons only)")

    ok = flagged == 0 and sched_ok and n > 0 and not cut_rows
    json.dump(dict(commands=int(n), traced=traced, parameters=P, comparisons=out_tests, flagged=flagged, incomplete=bool(cut_rows),
                   segments=[dict(test=l, loc=lo, q=q, **t) for l, lo, q, t in seg], schedule=sres, schedule_totals=stot, all_pass=ok),
              open(a.out, "w"), indent=1)
    verdict = "NO LEAK FOUND IN THESE COMPARISONS" if ok else ("CHECK THE FLAGGED ROWS" if flagged or not sched_ok else "INCOMPLETE RUN")
    print(f"\n== {verdict}: {flagged} of {len(tests)} comparisons flagged"
          + (f"; schedule {'exact' if sched_ok else 'NOT exact'}" if traced else "; schedule not checked") + f" (details: {a.out})")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
