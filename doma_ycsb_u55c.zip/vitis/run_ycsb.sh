#!/bin/bash
# run_ycsb.sh -- YCSB workloads A-F on the U55C with host_ycsb (doma_kernel). No sudo; the card's configuration is
# not touched (host_ycsb only loads the xclbin and allocates buffers, as host_doma does).
#   bash run_ycsb.sh <xclbin> [smoke|full|both]          (default: both)
# smoke: oram_ycsb.c's default size, every workload in one process (n_iters 100, 128 slots, init_occ 64, scan_len 10);
#        the same run was simulated against the Verilated kernel (sim/xrt_mock/results/ycsb_smoke_sim.log)
# full:  oram_ycsb.c's largest size: 32768 slots, init_occ 16384; A-D and F with n_iters 100000, E with 26000
#        (E issues up to n_iters * scan_len reads; oram_ycsb.c caps a run at 262144 ORAM ops). Needs NMAX >= 32768.
# Overrides: INST (instance_id, seeds the generator; default 0), NS, OCC, ITERS, ITERS_E, SCAN, OUT (result dir).
# Results: $OUT/<mode>_<workload>.log and .csv (per command: latency in cycles, status).
set -u
cd "$(dirname "$0")"
X=${1:?usage: run_ycsb.sh <xclbin> [smoke|full|both]}
MODE=${2:-both}
[ -x ./host_ycsb ] || { echo "build host_ycsb first:"; echo "  g++ -std=c++17 -O2 -ffp-contract=off host_ycsb.cpp -I\$XILINX_XRT/include -L\$XILINX_XRT/lib -lxrt_coreutil -pthread -o host_ycsb"; exit 1; }
[ -f "$X" ] || { echo "no xclbin $X"; exit 1; }
OUT=${OUT:-ycsb_results}; mkdir -p "$OUT"
INST=${INST:-0}; NS=${NS:-32768}; OCC=${OCC:-$((NS / 2))}; ITERS=${ITERS:-100000}; ITERS_E=${ITERS_E:-26000}; SCAN=${SCAN:-10}
fails=0
run() {   # run <tag> <workload(s)> <n_iters> <num_slots> <init_occ> <scan_len>
    local tag=$1 w=$2 log="$OUT/$1_$2.log"
    echo "== $tag $w: n_iters=$3 num_slots=$4 init_occ=$5 scan_len=$6 instance_id=$INST"
    YCSB_CSV="$OUT/$1_$2.csv" ./host_ycsb "$X" 1 "$INST" "$3" "$4" "$w" "$5" "$6" > "$log" 2>&1
    local rc=$?
    # the run phase's lines, the gem5-style summary line and the verdict (several workloads: the summary table)
    awk '/^summary/{t=1} t{print; next} /^RUN /{n=3} n>0{print; n--; next}
         /^oram_ycsb:|^WORKLOAD FAILED|^ERRORS|errors 0x|MISMATCH|failed|cannot|^MOCK: /{print}' "$log"
    [ $rc = 0 ] || { fails=$((fails + 1)); echo "   FAILED (exit $rc): see $log"; }
}
[ "$MODE" != full ]  && run smoke ABCDEF 100 128 64 10
if [ "$MODE" != smoke ]; then
    for w in A B C D F; do run full $w "$ITERS" "$NS" "$OCC" "$SCAN"; done
    run full E "$ITERS_E" "$NS" "$OCC" "$SCAN"
fi
echo
echo "kernel clock in $X: $(xclbinutil --info -i "$X" 2>/dev/null | awk '/Name:.*DATA_CLK/{f=1} f && /Frequency:/{print $2; exit}') MHz (host_ycsb's microseconds assume DOMA_MHZ=${DOMA_MHZ:-300})"
[ $fails = 0 ] && echo "run_ycsb: every run PASSED (logs in $OUT/)" || echo "run_ycsb: $fails run(s) FAILED (logs in $OUT/)"
exit $fails
