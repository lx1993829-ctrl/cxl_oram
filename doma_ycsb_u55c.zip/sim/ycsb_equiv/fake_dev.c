// fake_dev.c -- runs gem5's oram_ycsb.c natively: maps its MMIO/ring/result addresses and plays the device
// with an ideal memory (32 B per slot), logging every ring entry as "opIdx slot op w0 w1" to $FAKE_TRACE.
#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <pthread.h>
#ifndef MAP_FIXED_NOREPLACE
#define MAP_FIXED_NOREPLACE 0x100000
#endif
#define CMD   0x0E0000000ULL
#define RING  0x600000000ULL
#define RES   0x610000000ULL
static FILE *tf;
static uint32_t mem[65536][8];
static void *map(uint64_t a, size_t n) {
    void *p = mmap((void *)a, n, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED_NOREPLACE | MAP_NORESERVE, -1, 0);
    if (p != (void *)a) { perror("mmap"); exit(3); }
    return p;
}
#define V32(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define V64(a) (*(volatile uint64_t *)(uintptr_t)(a))
static int inst = 0;
static void *dev(void *x) {
    (void)x;
    uint64_t cmd = CMD + inst * 0x1000ULL, ring = RING + inst * 0x1000ULL, res = RES + inst * 0x1000000ULL;
    uint64_t cons = 0; uint32_t done = 0;
    for (;;) {
        uint64_t prod = V64(ring + 0x000);
        if (prod < cons) cons = 0;                     /* main reset the ring */
        if (cons >= prod) continue;
        __atomic_thread_fence(__ATOMIC_ACQUIRE);
        uint64_t e = ring + 0x100 + (cons % 16) * 64;
        uint32_t slot = V32(e + 0), w2 = V32(e + 8), lo = V32(e + 0xC), hi = V32(e + 0x30);
        uint64_t opIdx = ((uint64_t)hi << 32) | lo; uint32_t op = (w2 >> 8) & 0xFF, idx = (slot - 0x1000) / 0x1000;
        uint32_t wd[8]; for (int j = 0; j < 8; j++) wd[j] = V32(e + 0x10 + j * 4);
        fprintf(tf, "%llu %u %u %08x %08x\n", (unsigned long long)opIdx, idx, op, op == 1 ? wd[0] : 0u, op == 1 ? wd[1] : 0u);
        uint64_t r = res + opIdx * 64;
        if (op == 1) memcpy(mem[idx], wd, 32);
        else { for (int j = 0; j < 8; j++) V32(r + 0x20 + j * 4) = mem[idx][j]; }
        __atomic_thread_fence(__ATOMIC_RELEASE);
        V64(r + 0x08) = 1 | (op == 1 ? 0 : 8);
        cons++; V64(ring + 0x040) = cons;
        done++; V32(cmd + 0xE0) = done;
    }
    return 0;
}
static void fin(void) { if (tf) fflush(tf); }
__attribute__((constructor)) static void start(void) {
    const char *t = getenv("FAKE_TRACE"); tf = fopen(t ? t : "/dev/null", "w");
    const char *i = getenv("FAKE_INST"); inst = i ? atoi(i) : 0;
    map(CMD, 0x20000); map(RING, 0x20000); map(RES, 0x40000000);
    V32(CMD + inst * 0x1000ULL + 0xC4) = 1;            /* READY */
    V32(CMD + inst * 0x1000ULL + 0x80) = 2;            /* K = 2 leases, as the gem5 device */
    V32(CMD + inst * 0x1000ULL + 0x84) = 0x1111; V32(CMD + inst * 0x1000ULL + 0x88) = 0x2222;
    atexit(fin);
    pthread_t th; pthread_create(&th, 0, dev, 0); pthread_detach(th);
}
