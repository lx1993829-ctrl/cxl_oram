// =========================================================================
// oram_ycsb.c — YCSB workload generator for flat ORAM accelerator.
//
// Two phases:
//   LOAD — write init_occupancy slots to populate the ORAM.
//   RUN  — execute n_iters logical operations per the chosen workload.
//
// Workloads:
//   A  50% read, 50% write              Zipfian
//   B  95% read, 5% write               Zipfian
//   C  100% read                         Zipfian
//   D  95% read, 5% insert (hashed)     Latest (Zipfian over recency)
//   E  95% scan, 5% insert (hashed)     Zipfian start, uniform length [1,scan_len]
//   F  50% read, 50% read-modify-write  Zipfian
//
// argv: <N> <instance_id> [n_iters] [num_slots] [workload] [init_occ] [scan_len]
//
//   N             — instances (unused, kept for compatibility)
//   instance_id   — ORAM instance 0-31
//   n_iters       — logical ops in run phase           (default 100)
//   num_slots     — total slot capacity                (default 128)
//   workload      — 1=A 2=B 3=C 4=D 5=E 6=F           (default 1)
//   init_occ      — slots populated in load phase      (default num_slots)
//   scan_len      — maxscanlength for workload E (default 10, YCSB default 100)
//
// Build:
//   musl-gcc -O0 -static -o oram_ycsb oram_ycsb.c -lm
// =========================================================================

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* ---- MMIO / ring-buffer constants (unchanged from oram_workload.c) ---- */

#define ORAM_CMD_BASE     0x0E0000000ULL
#define CMD_RING_BASE     0x600000000ULL
#define RESULT_BUF_BASE   0x610000000ULL

#define OFF_NUM_K              0x80
#define OFF_TOKEN_BASE         0x84
#define OFF_READY              0xC4
#define OFF_CPU_OP_COUNT       0xE0
#define OFF_CMD_RING_DOORBELL  0x150

#define DEBUG_OFF_TOTAL_OPS    0x10
#define DEBUG_OFF_READY        0x14
#define DEBUG_OFF_K            0x18
#define DEBUG_OFF_OP_COUNT     0x1C
#define DEBUG_OFF_PASS         0x20
#define DEBUG_OFF_FAIL         0x24

#define RING_PROD_IDX_OFF      0x000
#define RING_CONS_IDX_OFF      0x040
#define RING_ENTRIES_OFF       0x100
#define RING_ENTRY_BYTES       64
#define CMD_RING_DEPTH         16

#define RES_STATUS_OFF         0x08
#define RES_RDATA_OFF          0x20
#define RES_DONE_BIT           (1ull << 0)
#define RES_RDATA_VALID        (1ull << 3)

#define DEFAULT_N_ITERS        100
#define DEFAULT_NUM_SLOTS      128
#define DEFAULT_SCAN_LEN       10
#define MAX_SLOTS              32768
#define MAX_ITERS              131072
#define MAX_RUN_ORAM_OPS       (2*MAX_ITERS)  /* worst case: workload F */

#define WL_A  1
#define WL_B  2
#define WL_C  3
#define WL_D  4
#define WL_E  5
#define WL_F  6

/* ---- low-level helpers (unchanged) ---- */

static inline uint32_t rd32(uint64_t a){return *(volatile uint32_t*)(uintptr_t)a;}
static inline void     wr32(uint64_t a,uint32_t v){*(volatile uint32_t*)(uintptr_t)a=v;}
static inline uint64_t rd64(uint64_t a){return *(volatile uint64_t*)(uintptr_t)a;}
static inline void     wr64(uint64_t a,uint64_t v){*(volatile uint64_t*)(uintptr_t)a=v;}

static uint32_t poll_mmio32(uint64_t addr,uint32_t mask,int maxIter){
    for(int i=0;i<maxIter;i++){uint32_t v=rd32(addr);if(v&mask)return v;}
    return 0;
}

static uint32_t xorshift32(uint32_t *s){
    uint32_t x=*s; x^=x<<13; x^=x>>17; x^=x<<5; *s=x; return x;
}

static inline uint32_t payload_word(uint32_t i,int j){
    return 0xABCD0000u | (i<<8) | (uint32_t)j;
}

static void write_ring_entry(uint64_t ring_base,uint64_t opIdx,uint32_t slot,
                             uint32_t token,uint8_t lease,uint8_t op,
                             uint8_t hwid,const uint32_t *wdata){
    uint64_t base=ring_base+RING_ENTRIES_OFF+(opIdx%CMD_RING_DEPTH)*RING_ENTRY_BYTES;
    wr32(base+0x00,slot);
    wr32(base+0x04,token);
    wr32(base+0x08,(uint32_t)lease|((uint32_t)op<<8)|((uint32_t)hwid<<16));
    wr32(base+0x0C,(uint32_t)(opIdx&0xFFFFFFFFu));
    if(op==1&&wdata){ for(int j=0;j<8;j++) wr32(base+0x10+j*4,wdata[j]); }
    else            { for(int j=0;j<8;j++) wr32(base+0x10+j*4,0); }
    wr32(base+0x30,(uint32_t)((opIdx>>32)&0xFFFFFFFFu));
    __asm__ __volatile__("":::"memory");
    wr32(base+0x34,1u); wr32(base+0x38,0); wr32(base+0x3C,0);
}

/* ---- Zipfian generator (YCSB scrambled method, alpha=0.99) ---- */

struct zipfian {
    uint32_t num_items;
    double   theta;      /* 0.99 */
    double   zeta_n;     /* sum 1/k^theta for k=1..num_items */
    double   zeta_2;     /* sum 1/k^theta for k=1..2 */
    double   alpha;      /* 1 / (1 - theta) */
    double   eta;
};

static double compute_zeta(uint32_t n, double theta){
    double sum=0.0;
    for(uint32_t i=1;i<=n;i++) sum+=1.0/pow((double)i,theta);
    return sum;
}

static void zipfian_init(struct zipfian *z, uint32_t n){
    z->num_items=n;
    z->theta=0.99;
    z->zeta_n=compute_zeta(n,z->theta);
    z->zeta_2=compute_zeta(2,z->theta);
    z->alpha=1.0/(1.0-z->theta);
    z->eta=(1.0-pow(2.0/(double)n,1.0-z->theta))
          /(1.0-z->zeta_2/z->zeta_n);
}

/* O(1) update when a new item is inserted (workload D). */
static void zipfian_inc(struct zipfian *z){
    z->num_items++;
    z->zeta_n+=1.0/pow((double)z->num_items,z->theta);
    z->eta=(1.0-pow(2.0/(double)z->num_items,1.0-z->theta))
          /(1.0-z->zeta_2/z->zeta_n);
}

static uint32_t fnv1a_hash(uint32_t val){
    uint32_t h=2166136261u;
    h^=(val      )&0xFF; h*=16777619u;
    h^=(val >>  8)&0xFF; h*=16777619u;
    h^=(val >> 16)&0xFF; h*=16777619u;
    h^=(val >> 24)&0xFF; h*=16777619u;
    return h;
}

/* Scrambled Zipfian: returns value in [0, num_items). */
static uint32_t zipfian_next(struct zipfian *z, uint32_t *rng){
    double u=(double)(xorshift32(rng)&0x7FFFFFFFu)/(double)0x7FFFFFFFu;
    double uz=u*z->zeta_n;
    uint32_t rank;
    if(uz<1.0)
        rank=0;
    else if(uz<1.0+pow(0.5,z->theta))
        rank=1;
    else
        rank=(uint32_t)((double)z->num_items
              *pow(z->eta*u-z->eta+1.0, z->alpha));
    if(rank>=z->num_items) rank=z->num_items-1;
    /* scramble so hot ranks don't always map to slot 0,1,2... */
    return fnv1a_hash(rank)%z->num_items;
}

/* Raw (unscrambled) Zipfian rank in [0, num_items).  Used by workload D
   to index into insert_log: rank 0 = most popular → most recent. */
static uint32_t zipfian_next_raw(struct zipfian *z, uint32_t *rng){
    double u=(double)(xorshift32(rng)&0x7FFFFFFFu)/(double)0x7FFFFFFFu;
    double uz=u*z->zeta_n;
    uint32_t rank;
    if(uz<1.0)
        rank=0;
    else if(uz<1.0+pow(0.5,z->theta))
        rank=1;
    else
        rank=(uint32_t)((double)z->num_items
              *pow(z->eta*u-z->eta+1.0, z->alpha));
    if(rank>=z->num_items) rank=z->num_items-1;
    return rank;
}

/* ---- issue one ORAM op through the ring buffer ---- */

static void issue_op(uint64_t ring_base, uint64_t cmd_base,
                     uint64_t opIdx, uint32_t slotIdx,
                     uint32_t slots_per_client,
                     uint32_t token0, uint32_t token1,
                     uint8_t op, const uint32_t *wdata){
    uint32_t slot=0x1000u+slotIdx*0x1000u;
    uint8_t  hwid=(slotIdx<slots_per_client)?0:1;
    uint32_t token=(hwid==0)?token0:token1;
    uint8_t  lease_id=hwid+1;

    while((opIdx-rd64(ring_base+RING_CONS_IDX_OFF))>=CMD_RING_DEPTH)
        for(volatile int d=0;d<100;d++){}
    write_ring_entry(ring_base,opIdx,slot,token,lease_id,op,hwid,wdata);
    wr64(ring_base+RING_PROD_IDX_OFF,opIdx+1);
    wr32(cmd_base+OFF_CMD_RING_DOORBELL,1);
}

/* ---- per-op tracking arrays (BSS, zero cost in binary) ---- */

#define MAX_INSERT_LOG         (MAX_SLOTS + MAX_ITERS)

static uint32_t last_write_opidx[MAX_SLOTS];       /* global opIdx of last write */
static uint32_t run_slot[MAX_RUN_ORAM_OPS];         /* slot per run-phase ORAM op */
static uint8_t  run_is_read[MAX_RUN_ORAM_OPS];      /* 1 = read */
static uint32_t run_expect_opidx[MAX_RUN_ORAM_OPS]; /* for reads: last_write_opidx */

/* Chronological insert log for workload D "latest" distribution.
   insert_log[k] = slot ID of the k-th write (load + run combined).
   Reads sample a Zipfian rank and index from the end of this log,
   so rank 0 → most recently written slot (wherever it hashed to). */
static uint32_t insert_log[MAX_INSERT_LOG];

/* Occupied slot table: occupied[k] = slot ID of the k-th occupied slot.
   Zipfian rank indexes into this array to get the actual slot ID.
   Needed because occupied slots are non-contiguous (even slots). */
static uint32_t occupied[MAX_SLOTS];

/* ================================================================ */

int main(int argc, char **argv){
    int N           =(argc>1)?atoi(argv[1]):1;
    int instance_id =(argc>2)?atoi(argv[2]):0;
    int n_iters     =(argc>3)?atoi(argv[3]):DEFAULT_N_ITERS;
    int num_slots   =(argc>4)?atoi(argv[4]):DEFAULT_NUM_SLOTS;
    int workload    =(argc>5)?atoi(argv[5]):WL_A;
    int init_occ    =(argc>6)?atoi(argv[6]):num_slots;
    int scan_len    =(argc>7)?atoi(argv[7]):DEFAULT_SCAN_LEN;
    (void)N;

    /* --- sanity checks --- */
    if(instance_id<0||instance_id>=32)
        {fprintf(stderr,"bad instance_id %d\n",instance_id);return 1;}
    if(n_iters<1||n_iters>MAX_ITERS)
        {fprintf(stderr,"n_iters %d out of range [1,%d]\n",n_iters,MAX_ITERS);return 1;}
    if(num_slots<1||num_slots>MAX_SLOTS)
        {fprintf(stderr,"bad num_slots %d\n",num_slots);return 1;}
    if(workload<WL_A||workload>WL_F)
        {fprintf(stderr,"bad workload %d (1=A..6=F)\n",workload);return 1;}
    if(init_occ<1||init_occ>num_slots/2)
        {fprintf(stderr,"bad init_occ %d (must be 1..%d for even-slot layout)\n",init_occ,num_slots/2);return 1;}
    if(scan_len<1||scan_len>num_slots)
        {fprintf(stderr,"bad scan_len %d\n",scan_len);return 1;}
    if(workload==WL_D&&init_occ>=num_slots)
        fprintf(stderr,"WARN: workload D with init_occ==num_slots — hashed inserts "
                "will always collide with existing slots (updates, not new records)\n");

    /* compute max run-phase ORAM ops for bounds check */
    uint32_t max_run_ops;
    if(workload==WL_F)      max_run_ops=2u*(uint32_t)n_iters;
    else if(workload==WL_E) max_run_ops=(uint32_t)n_iters*(uint32_t)scan_len;
    else                    max_run_ops=(uint32_t)n_iters;
    if(max_run_ops>MAX_RUN_ORAM_OPS)
        {fprintf(stderr,"run-phase ORAM ops %u exceed MAX_RUN_ORAM_OPS %d\n",
                 max_run_ops,MAX_RUN_ORAM_OPS);return 1;}

    const char *wl_names[]={"?","A","B","C","D","E","F"};
    fprintf(stderr,"oram_ycsb: inst=%d workload=%s n_iters=%d num_slots=%d "
            "init_occ=%d scan_len=%d\n",
            instance_id,wl_names[workload],n_iters,num_slots,init_occ,scan_len);

    /* --- MMIO setup --- */
    uint64_t cmd_base   =ORAM_CMD_BASE   +(uint64_t)instance_id*0x1000ULL;
    uint64_t ring_base  =CMD_RING_BASE   +(uint64_t)instance_id*0x1000ULL;
    uint64_t result_base=RESULT_BUF_BASE +(uint64_t)instance_id*0x1000000ULL;
    uint32_t rng=(uint32_t)(instance_id+1)*2654435761u;

    uint32_t ready=poll_mmio32(cmd_base+OFF_READY,1,10000000);
    uint32_t K=rd32(cmd_base+OFF_NUM_K);
    uint32_t token0=rd32(cmd_base+OFF_TOKEN_BASE+0);
    uint32_t token1=rd32(cmd_base+OFF_TOKEN_BASE+4);
    uint32_t slots_per_client=(uint32_t)num_slots/K;

    wr64(ring_base+RING_PROD_IDX_OFF,0);
    wr64(ring_base+RING_CONS_IDX_OFF,0);

    memset(last_write_opidx,0xFF,sizeof(last_write_opidx));

    /* ============================================================
     * LOAD PHASE — write init_occ even slots: 0, 2, 4, ..., 2*(init_occ-1).
     * This spreads occupancy across both HBM and CXL regions so that
     * each region has ~50% occupancy and unoccupied odd slots for inserts.
     * Global opIdx 0 .. init_occ-1.
     * ============================================================ */
    uint32_t load_ops=(uint32_t)init_occ;
    uint32_t insert_count=0;        /* entries in insert_log so far */
    uint32_t occ_count=0;           /* entries in occupied[] */
    uint32_t insert_counter=0;      /* monotonic counter for hashing new inserts */
    for(uint32_t i=0;i<load_ops;i++){
        uint32_t slotIdx=i*2;       /* even slots: 0, 2, 4, ... */
        uint32_t wdata[8];
        for(int j=0;j<8;j++) wdata[j]=payload_word(i,j);
        last_write_opidx[slotIdx]=i;
        insert_log[insert_count++]=slotIdx;
        occupied[occ_count++]=slotIdx;
        issue_op(ring_base,cmd_base,(uint64_t)i, slotIdx,
                 slots_per_client,token0,token1, 1/*write*/,wdata);
    }
    insert_counter=load_ops;        /* next hashed insert starts here */

    /* ============================================================
     * RUN PHASE — execute n_iters logical ops.
     * Global opIdx continues from load_ops.
     * ============================================================ */
    struct zipfian z;
    zipfian_init(&z, insert_count);    /* Zipfian over all records so far */

    uint64_t opIdx=(uint64_t)load_ops;
    uint32_t run_idx=0;               /* index into run_* arrays */
    uint32_t run_reads=0, run_writes=0;

    for(int i=0;i<n_iters;i++){
        switch(workload){

        /* ---- A / B / C: simple read/write mix ---- */
        case WL_A: case WL_B: case WL_C: {
            uint32_t slotIdx=occupied[zipfian_next(&z,&rng)];
            int is_read;
            if(workload==WL_C)      is_read=1;
            else if(workload==WL_A) is_read=(xorshift32(&rng)%100<50);
            else                    is_read=(xorshift32(&rng)%100<95);

            run_slot[run_idx]=slotIdx;
            run_is_read[run_idx]=(uint8_t)is_read;

            if(is_read){
                run_expect_opidx[run_idx]=last_write_opidx[slotIdx];
                issue_op(ring_base,cmd_base,opIdx, slotIdx,
                         slots_per_client,token0,token1, 0,NULL);
                run_reads++;
            } else {
                uint32_t wdata[8];
                for(int j=0;j<8;j++) wdata[j]=payload_word((uint32_t)opIdx,j);
                last_write_opidx[slotIdx]=(uint32_t)opIdx;
                run_expect_opidx[run_idx]=0xFFFFFFFFu;
                issue_op(ring_base,cmd_base,opIdx, slotIdx,
                         slots_per_client,token0,token1, 1,wdata);
                run_writes++;
            }
            run_idx++; opIdx++;
            break;
        }

        /* ---- D: 95% read (latest), 5% insert (hashed) ---- */
        case WL_D: {
            int is_read=(xorshift32(&rng)%100<95);

            if(!is_read){
                /* INSERT: hash to an odd slot (unoccupied by load phase).
                   Retry if collision with a prior insert. */
                uint32_t half=(uint32_t)num_slots/2;
                uint32_t slotIdx;
                do {
                    slotIdx=fnv1a_hash(insert_counter)%half*2+1;
                    insert_counter++;
                } while(last_write_opidx[slotIdx]!=0xFFFFFFFFu);
                uint32_t wdata[8];
                for(int j=0;j<8;j++) wdata[j]=payload_word((uint32_t)opIdx,j);
                last_write_opidx[slotIdx]=(uint32_t)opIdx;
                insert_log[insert_count++]=slotIdx;
                occupied[occ_count++]=slotIdx;
                zipfian_inc(&z);
                run_slot[run_idx]=slotIdx;
                run_is_read[run_idx]=0;
                run_expect_opidx[run_idx]=0xFFFFFFFFu;
                issue_op(ring_base,cmd_base,opIdx, slotIdx,
                         slots_per_client,token0,token1, 1,wdata);
                run_writes++;
            } else {
                /* READ: latest distribution — Zipfian rank indexes the
                   insert_log from the end, so rank 0 = most recent write. */
                uint32_t rank=zipfian_next_raw(&z,&rng);
                uint32_t slotIdx=insert_log[insert_count-1-rank];
                run_slot[run_idx]=slotIdx;
                run_is_read[run_idx]=1;
                run_expect_opidx[run_idx]=last_write_opidx[slotIdx];
                issue_op(ring_base,cmd_base,opIdx, slotIdx,
                         slots_per_client,token0,token1, 0,NULL);
                run_reads++;
            }
            run_idx++; opIdx++;
            break;
        }

        /* ---- E: 95% scan (uniform length [1,scan_len]), 5% insert (hashed) ---- */
        case WL_E: {
            int is_scan=(xorshift32(&rng)%100<95);

            if(!is_scan){
                /* INSERT: hash to odd slot, retry on collision. */
                uint32_t half=(uint32_t)num_slots/2;
                uint32_t slotIdx;
                do {
                    slotIdx=fnv1a_hash(insert_counter)%half*2+1;
                    insert_counter++;
                } while(last_write_opidx[slotIdx]!=0xFFFFFFFFu);
                uint32_t wdata[8];
                for(int j=0;j<8;j++) wdata[j]=payload_word((uint32_t)opIdx,j);
                last_write_opidx[slotIdx]=(uint32_t)opIdx;
                insert_log[insert_count++]=slotIdx;
                /* Don't zipfian_inc — scan distribution stays over init_occ. */
                run_slot[run_idx]=slotIdx;
                run_is_read[run_idx]=0;
                run_expect_opidx[run_idx]=0xFFFFFFFFu;
                issue_op(ring_base,cmd_base,opIdx, slotIdx,
                         slots_per_client,token0,token1, 1,wdata);
                run_writes++;
                run_idx++; opIdx++;
            } else {
                /* SCAN: Zipfian start rank in occupied[], length uniform [1, scan_len]. */
                uint32_t start_rank=zipfian_next(&z,&rng);
                uint32_t len=1+xorshift32(&rng)%(uint32_t)scan_len;
                for(uint32_t s=0;s<len;s++){
                    uint32_t slotIdx=occupied[(start_rank+s)%occ_count];
                    run_slot[run_idx]=slotIdx;
                    run_is_read[run_idx]=1;
                    run_expect_opidx[run_idx]=last_write_opidx[slotIdx];
                    issue_op(ring_base,cmd_base,opIdx, slotIdx,
                             slots_per_client,token0,token1, 0,NULL);
                    run_reads++;
                    run_idx++; opIdx++;
                }
            }
            break;
        }

        /* ---- F: 50% read, 50% read-modify-write ---- */
        case WL_F: {
            uint32_t slotIdx=occupied[zipfian_next(&z,&rng)];
            int is_rmw=(xorshift32(&rng)%100<50);

            /* read (common to both plain-read and RMW) */
            run_slot[run_idx]=slotIdx;
            run_is_read[run_idx]=1;
            run_expect_opidx[run_idx]=last_write_opidx[slotIdx];
            issue_op(ring_base,cmd_base,opIdx, slotIdx,
                     slots_per_client,token0,token1, 0,NULL);
            run_reads++;
            run_idx++; opIdx++;

            if(is_rmw){
                /* write back modified data */
                uint32_t wdata[8];
                for(int j=0;j<8;j++) wdata[j]=payload_word((uint32_t)opIdx,j);
                last_write_opidx[slotIdx]=(uint32_t)opIdx;
                run_slot[run_idx]=slotIdx;
                run_is_read[run_idx]=0;
                run_expect_opidx[run_idx]=0xFFFFFFFFu;
                issue_op(ring_base,cmd_base,opIdx, slotIdx,
                         slots_per_client,token0,token1, 1,wdata);
                run_writes++;
                run_idx++; opIdx++;
            }
            break;
        }
        } /* switch */
    } /* for n_iters */

    uint32_t total_oram_ops=(uint32_t)opIdx;  /* load + run */

    /* wait for every op to complete */
    while(rd32(cmd_base+OFF_CPU_OP_COUNT)<total_oram_ops)
        for(volatile int d=0;d<100;d++){}

    /* ============================================================
     * VERIFY — check every read in the run phase.
     * ============================================================ */
    uint32_t pass=0, fail=0;
    for(uint32_t r=0;r<run_idx;r++){
        if(!run_is_read[r]) continue;

        uint64_t globalIdx=(uint64_t)load_ops+(uint64_t)r;
        uint64_t resAddr=result_base+globalIdx*64;
        uint64_t status;
        while(!((status=rd64(resAddr+RES_STATUS_OFF))&RES_DONE_BIT))
            for(volatile int d=0;d<100;d++){}

        if(!(status&RES_RDATA_VALID)){
            fprintf(stderr,"RDATA_INVALID inst=%d opIdx=%lu slot=%u status=0x%lx\n",
                    instance_id,(unsigned long)globalIdx,
                    run_slot[r],(unsigned long)status);
            fail++; continue;
        }

        uint32_t r0=rd32(resAddr+RES_RDATA_OFF+0);
        uint32_t r1=rd32(resAddr+RES_RDATA_OFF+4);
        uint32_t exp_idx=run_expect_opidx[r];
        uint32_t e0=payload_word(exp_idx,0);
        uint32_t e1=payload_word(exp_idx,1);

        if(r0==e0 && r1==e1){
            pass++;
        } else {
            uint32_t r2=rd32(resAddr+RES_RDATA_OFF+8);
            uint32_t r3=rd32(resAddr+RES_RDATA_OFF+12);
            fprintf(stderr,"MISMATCH inst=%d opIdx=%lu slot=%u exp_wr_idx=%u "
                    "got=[%08x %08x %08x %08x] exp=[%08x %08x] status=0x%lx\n",
                    instance_id,(unsigned long)globalIdx,run_slot[r],exp_idx,
                    r0,r1,r2,r3,e0,e1,(unsigned long)status);
            fail++;
        }
    }

    fprintf(stderr,"oram_ycsb: inst=%d wl=%s total_oram_ops=%u "
            "run_reads=%u run_writes=%u pass=%u fail=%u insert_count=%u\n",
            instance_id,wl_names[workload],total_oram_ops,
            run_reads,run_writes,pass,fail,insert_count);

    /* ============================================================
     * PAD — for workloads E/F the actual ORAM op count depends on
     * RNG (variable scan length, 50/50 RMW split).  The device
     * expects a fixed total to fire the E2E summary.  Pad with
     * dummy reads to close the gap.  All ORAM ops cost the same,
     * so padding does not distort the average.
     * ============================================================ */
    uint32_t expected_total;
    if(workload==WL_F)      expected_total=(uint32_t)init_occ+2u*(uint32_t)n_iters;
    else if(workload==WL_E) expected_total=(uint32_t)init_occ+(uint32_t)n_iters*(uint32_t)scan_len;
    else                    expected_total=(uint32_t)init_occ+(uint32_t)n_iters;

    while(total_oram_ops<expected_total){
        issue_op(ring_base,cmd_base,opIdx, 0/*slot 0*/,
                 slots_per_client,token0,token1, 0/*read*/,NULL);
        opIdx++; total_oram_ops++;
    }

    /* wait for all ops including padding to complete */
    while(rd32(cmd_base+OFF_CPU_OP_COUNT)<total_oram_ops)
        for(volatile int d=0;d<100;d++){}

    /* write debug registers (same layout as oram_workload.c) */
    wr32(cmd_base+DEBUG_OFF_TOTAL_OPS,total_oram_ops);
    wr32(cmd_base+DEBUG_OFF_READY,ready);
    wr32(cmd_base+DEBUG_OFF_K,K);
    wr32(cmd_base+DEBUG_OFF_OP_COUNT,rd32(cmd_base+OFF_CPU_OP_COUNT));
    wr32(cmd_base+DEBUG_OFF_PASS,pass);
    wr32(cmd_base+DEBUG_OFF_FAIL,fail);
    return (fail==0)?0:1;
}