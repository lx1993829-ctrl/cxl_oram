#!/bin/bash
# cmp.sh <inst> <n_iters> <num_slots> <workload 1..6> <init_occ> <scan_len>
# Runs gem5's oram_ycsb.c natively (fake_dev.c plays the device) and host_ycsb --dry-run with the same arguments,
# and diffs their op traces ("opIdx slot op w0 w1") and their oram_ycsb summary lines.
# Build the gem5 workload first, as gem5 runs it (static musl, -O0), or with the system compiler:
#   zig cc -target x86_64-linux-musl -O0 -static -o oram_ycsb_fake oram_ycsb.c fake_dev.c -lm -lpthread
#   gcc -O0 -o oram_ycsb_fake oram_ycsb.c fake_dev.c -lm -lpthread
# BIN: that binary (default ./oram_ycsb_fake); HOST: a host_ycsb build (default ../xrt_mock/host_ycsb_sim; the card
# build works too: --dry-run never opens the device).
set -u
cd "$(dirname "$0")"
BIN=${BIN:-./oram_ycsb_fake}; HOST=${HOST:-../xrt_mock/host_ycsb_sim}
i=$1; it=$2; ns=$3; w=$4; io=$5; sl=$6
t=out/${i}_${it}_${ns}_${w}_${io}_${sl}; mkdir -p out
FAKE_INST=$i FAKE_TRACE=$t.gem5 timeout 1200 $BIN 1 $i $it $ns $w $io $sl 2> $t.gem5.err; rc=$?
YCSB_PAD=1 YCSB_TRACE=$t.host $HOST x 1 $i $it $ns $w $io $sl --dry-run > $t.host.out
g=$(grep "^oram_ycsb: inst=.* wl=" $t.gem5.err | sed 's/ pass=[0-9]* fail=[0-9]*//'); h=$(grep "^oram_ycsb:" $t.host.out | sed 's/ pass=- fail=-//')
n=$(wc -l < $t.gem5)
if cmp -s $t.gem5 $t.host && [ "$g" = "$h" ] && [ $rc = 0 ]; then
    echo "SAME  inst=$i iters=$it slots=$ns wl=$w occ=$io scan=$sl: $n ops identical; gem5 self-check: $(grep -o 'pass=[0-9]* fail=[0-9]*' $t.gem5.err)"
else
    echo "DIFF  inst=$i iters=$it slots=$ns wl=$w occ=$io scan=$sl (gem5 workload exit $rc)"; echo " gem5: $g"; echo " host: $h"; diff $t.gem5 $t.host | head -5
fi
