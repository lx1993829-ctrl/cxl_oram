#!/bin/bash
# run_all.sh -- the comparisons behind results.log: A-F at three sizes and three seeds, up to the largest run oram_ycsb.c allows
cd "$(dirname "$0")"
for w in 1 2 3 4 5 6; do ./cmp.sh 0 100 128 $w 64 10; done
for w in 1 2 3 4 5 6; do ./cmp.sh 7 5000 4096 $w 1500 25; done
for w in 1 2 3 4 5 6; do ./cmp.sh 31 131072 32768 $w 16384 2; done
./cmp.sh 3 20000 32768 5 16384 10
