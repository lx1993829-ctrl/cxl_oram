# Host programs against the RTL, without the card (mock XRT)

`xrt/` replaces the three XRT headers the host programs include (`xrt_bo.h`, `xrt_device.h`, `xrt_kernel.h`), and
`xrt_mock.cpp` implements them on a Verilated `doma_kernel`. The host programs in `vitis/` compile **unchanged** and
run end to end: arguments and `ap_start` over the kernel's AXI-Lite port, `ap_done` polling, and seven AXI memories
with the testbench's latencies (`tb_doma_kernel.v`: HBM 53 cycles with 2% at +105, writes acknowledged after 26).

The mock also checks the host program:
- device and host copies of each buffer are separate, so a missing `sync()` shows up as wrong data (device memory
  starts as `0xCD`);
- every kernel access must fall inside one buffer, and every AXI burst must stay within 4 KB with correct `wlast`.

```bash
cd sim/xrt_mock
bash build_model.sh            # Verilate doma_kernel: 4 KB, ORAM_N=1048576, arrival, secure build (about 1 min)
bash build_hosts.sh            # host_ycsb_sim and host_doma_sim
./host_ycsb_sim doma_hw.xclbin 1 0 100 128 all 64 10    # the xclbin name is only printed
DOMA_PAGES_HBM=1 DOMA_N=256 ./host_doma_sim doma_hw.xclbin 200
```

Speed is about 150,000 cycles/s, so the smoke run above takes about 95 s.

Environment variables:
- `MOCK_CFG=doma`: `doma.cfg` placement, with the buckets in `HOST[0]`. The default is `doma_hw.cfg`, with the buckets in `HBM[8]`.
- `MOCK_HOST_LAT=<cycles>`: host-memory read latency.
- `MOCK_VERBOSE=1`: prints every launch.
- `MOCK_FLIP=<k>`: flips one bit in the k-th data beat written to `resp_output`, to check that a wrong read is caught.

## Results (`results/`)

| Log | Run | Outcome |
|---|---|---|
| `ycsb_smoke_sim.log` | `host_ycsb ... 1 0 100 128 all 64 10` | A–F pass; every command 9,326–9,431 cycles; 0 access errors |
| `ycsb_n32768_D_sim.log` | 32,768 slots (4,096 buckets, pool 7,864), workload D | pass; boot 16.7 M cycles (56 ms); same latency |
| `ycsb_chunk_pad_sim.log` | E and F, 37 commands per launch, `YCSB_PAD=1`, `YCSB_DATA=gem5` | pass, padding reads included |
| `ycsb_hostmem_sim.log` | `MOCK_CFG=doma` (buckets in `HOST[0]`), `DOMA_N=512` > `num_slots` | pass |
| `ycsb_fault_sim.log` | `MOCK_FLIP`: one bit flipped in a GET's block, past its first 8 bytes | caught (`fail=1`); gem5's two-word check would have missed it |
| `host_doma_sim.log` | `host_doma`, 256 blocks, 200 commands | `ALL RESPONSES CORRECT` (the mock reproduces the known-good host) |

## Same op sequence as gem5 (`../ycsb_equiv/`)

`fake_dev.c` runs gem5's `oram_ycsb.c` natively. It maps the MMIO, ring and result addresses and plays the device
with an ideal memory. `cmp.sh` then diffs that op trace against `host_ycsb --dry-run`. All of the following matched,
op for op:
- A–F at 128, 4,096 and 32,768 slots;
- instance ids 0, 7 and 31;
- up to 278,528 ops, with `YCSB_PAD=1`.

This holds with glibc, and also with a static musl build (`zig cc -target x86_64-linux-musl -O0 -static`). The musl
build is the same kind of binary that gem5 runs.
