`timescale 1ns / 1ps
// plain_oram_top.v -- the non-oblivious baseline core (ORAM_PLAIN); see the comment block after the port list.
`include "oram_params.vh"

module plain_oram_top #(
    parameter UNIFORM_FILL = 0,   // 1: GETs take the write-data fill too (data ignored), so GET and PUT start alike
    parameter N            = `ORAM_N,
    parameter Z            = `ORAM_Z,
    parameter B            = `ORAM_B,
    parameter STASH_DEPTH  = `ORAM_STASH_DEPTH,
    parameter AXI_DW       = `AXI_DATA_W,
    parameter AXI_AW       = `AXI_ADDR_W,
    parameter AXI_SW       = `AXI_STRB_W,
    parameter AXI_IDW      = `AXI_ID_W,
    parameter AXI_LENW     = `AXI_LEN_W,
    parameter NUM_CLIENTS    = `ORAM_NUM_CLIENTS,
    parameter TDM_CID_W      = (NUM_CLIENTS > 1) ? $clog2(NUM_CLIENTS) : 1,
    parameter NUM_REGIONS    = 16,
    parameter TOKEN_WIDTH    = 32,
    parameter LEASE_ID_WIDTH = 8,
    parameter SLOT_AW        = `SLOT_ADDR_W
)(
    input  wire                 clk,
    input  wire                 rst_n,

    // Management Interface
    input  wire                                   mgmt_req,
    input  wire [2:0]                             mgmt_op,
    input  wire [LEASE_ID_WIDTH-1:0]              mgmt_lease_id,
    input  wire [TDM_CID_W-1:0]                   mgmt_client_id,
    input  wire [SLOT_AW-1:0]                     mgmt_base_addr,   // slot addresses (slot << 12)
    input  wire [SLOT_AW-1:0]                     mgmt_size,
    input  wire [31:0]                            mgmt_duration,
    input  wire [TOKEN_WIDTH-1:0]                 mgmt_token_in,
    output wire                                   mgmt_ack,
    output wire                                   mgmt_error,
    output wire [TOKEN_WIDTH-1:0]                 mgmt_token_out,
    output wire [NUM_CLIENTS*TOKEN_WIDTH-1:0]     client_token_out,
    output wire [63:0]                            dbg_halt_info,

    // Client Interface (flattened)
    input  wire [NUM_CLIENTS-1:0]                     client_req,
    input  wire [NUM_CLIENTS-1:0]                     client_op,
    input  wire [NUM_CLIENTS*SLOT_AW-1:0]             client_slot_addr,
    input  wire [NUM_CLIENTS*AXI_DW-1:0]              client_wdata,
    input  wire [NUM_CLIENTS*AXI_DW/8-1:0]            client_wstrb,   // byte strobes per write beat (all ones = whole block)
    input  wire [NUM_CLIENTS-1:0]                     client_wdata_valid,
    input  wire [NUM_CLIENTS*TOKEN_WIDTH-1:0]         client_token,
    input  wire [NUM_CLIENTS*LEASE_ID_WIDTH-1:0]      client_lease_id,
    output wire [NUM_CLIENTS-1:0]                     client_done,
    output wire [NUM_CLIENTS*AXI_DW-1:0]              client_rdata,
    output wire [NUM_CLIENTS-1:0]                     client_rdata_valid,
    output wire [NUM_CLIENTS-1:0]                     access_violation,
    output wire [NUM_CLIENTS-1:0]     client_lockout,   // F10: client locked after repeated violations
    input  wire                       key_load,         // F1: latch aes_key/aes_iv_seed (once per boot)
    output wire                       key_ready,        // F1: a key is loaded; accesses are accepted
    output wire                       err_ct_overrun,   // Phase 2: sticky timing-gate overrun (fail-stop)
    output wire                       oram_ready,       // Phase 2: key loaded and DDR formatted
    // Phase 3: static time-division arbiter. Configuration latched ONCE, on the
    // first cycle after reset (boot-time); slots start when oram_ready rises.
    input  wire [15:0]                cfg_tdm_slot_cycles, // access window length (0 = `ORAM_TDM_SLOT)
    output wire [NUM_CLIENTS*`BEAT_CNT_W-1:0] client_wbeat_req, // write beat each client should present
    output wire [NUM_CLIENTS-1:0]     client_ready,        // client may issue a request
    output wire                       err_slot_overrun,    // sticky: controller busy at a slot start
    output wire                       dbg_slot_start,      // debug builds only (0 otherwise)
    output wire [31:0]                dbg_real_cnt,

    // BRAM Init Interface
    input  wire                                       init_mode,
    input  wire [SLOT_AW-1:0]                         init_pm_wr_addr,
    input  wire [`BUCKET_ID_W-1:0]                    init_pm_wr_bucket,
    input  wire [1:0]                                 init_pm_wr_status,
    input  wire                                       init_pm_wr_en,
    input  wire [`BUCKET_ID_W-1:0]                    init_bm_wr_bucket,
    input  wire [Z*`SLOT_ID_W-1:0]                    init_bm_wr_slot_list,
    input  wire [`FILL_CNT_W-1:0]                     init_bm_wr_fill,
    input  wire                                       init_bm_wr_en,

    // AES-GCM Configuration
    input  wire [127:0]                               aes_key,
    input  wire [95:0]                                aes_iv_seed,
    input  wire [`SLOT_ID_W:0]                        cfg_n,            // run-time blocks (0: the build's maximum)
    input  wire [`BUCKET_ID_W:0]                      cfg_hbm_bkts,     // buckets 0 .. cfg_hbm_bkts-1 in HBM
    input  wire [`SLOT_ID_W:0]                        cfg_pool_n,       // stash pool entries (0: N)

    // AXI Master -> DDR
    output wire [AXI_IDW-1:0]   m_axi_arid,
    output wire [AXI_AW-1:0]    m_axi_araddr,
    output wire [AXI_LENW-1:0]  m_axi_arlen,
    output wire [2:0]            m_axi_arsize,
    output wire [1:0]            m_axi_arburst,
    output wire                  m_axi_arvalid,
    input  wire                  m_axi_arready,
    input  wire [AXI_IDW-1:0]   m_axi_rid,
    input  wire [AXI_DW-1:0]    m_axi_rdata,
    input  wire [1:0]            m_axi_rresp,
    input  wire                  m_axi_rlast,
    input  wire                  m_axi_rvalid,
    output wire                  m_axi_rready,
    output wire [AXI_IDW-1:0]   m_axi_awid,
    output wire [AXI_AW-1:0]    m_axi_awaddr,
    output wire [AXI_LENW-1:0]  m_axi_awlen,
    output wire [2:0]            m_axi_awsize,
    output wire [1:0]            m_axi_awburst,
    output wire                  m_axi_awvalid,
    input  wire                  m_axi_awready,
    output wire [AXI_DW-1:0]    m_axi_wdata,
    output wire [AXI_SW-1:0]    m_axi_wstrb,
    output wire                  m_axi_wlast,
    output wire                  m_axi_wvalid,
    input  wire                  m_axi_wready,
    input  wire [AXI_IDW-1:0]   m_axi_bid,
    input  wire [1:0]            m_axi_bresp,
    input  wire                  m_axi_bvalid,
    output wire                  m_axi_bready,
    // position map in HBM: addresses relative to the metadata buffer (the kernel adds its base)
    output wire [63:0]           m_meta_araddr,
    output wire [7:0]            m_meta_arlen,
    output wire [2:0]            m_meta_arsize,
    output wire [1:0]            m_meta_arburst,
    output wire                  m_meta_arvalid,
    input  wire                  m_meta_arready,
    input  wire [AXI_DW-1:0]     m_meta_rdata,
    input  wire                  m_meta_rlast,
    input  wire                  m_meta_rvalid,
    output wire                  m_meta_rready,
    output wire [63:0]           m_meta_awaddr,
    output wire [7:0]            m_meta_awlen,
    output wire [2:0]            m_meta_awsize,
    output wire [1:0]            m_meta_awburst,
    output wire                  m_meta_awvalid,
    input  wire                  m_meta_awready,
    output wire [AXI_DW-1:0]     m_meta_wdata,
    output wire [AXI_DW/8-1:0]   m_meta_wstrb,
    output wire                  m_meta_wlast,
    output wire                  m_meta_wvalid,
    input  wire                  m_meta_wready,
    input  wire                  m_meta_bvalid,
    output wire                  m_meta_bready,
    // bucket records in HBM (metadata + IV/tag), addresses relative to their buffer
    output wire [63:0]                 m_brec_araddr,
    output wire [7:0]                  m_brec_arlen,
    output wire [2:0]                  m_brec_arsize,
    output wire [1:0]                  m_brec_arburst,
    output wire                        m_brec_arvalid,
    input  wire                        m_brec_arready,
    input  wire [AXI_DW-1:0]           m_brec_rdata,
    input  wire                        m_brec_rlast,
    input  wire                        m_brec_rvalid,
    output wire                        m_brec_rready,
    output wire [63:0]                 m_brec_awaddr,
    output wire [7:0]                  m_brec_awlen,
    output wire [2:0]                  m_brec_awsize,
    output wire [1:0]                  m_brec_awburst,
    output wire                        m_brec_awvalid,
    input  wire                        m_brec_awready,
    output wire [AXI_DW-1:0]           m_brec_wdata,
    output wire [AXI_DW/8-1:0]         m_brec_wstrb,
    output wire                        m_brec_wlast,
    output wire                        m_brec_wvalid,
    input  wire                        m_brec_wready,
    input  wire                        m_brec_bvalid,
    output wire                        m_brec_bready,
    output wire [63:0]                 m_stash_araddr,
    output wire [7:0]                  m_stash_arlen,
    output wire [2:0]                  m_stash_arsize,
    output wire [1:0]                  m_stash_arburst,
    output wire                        m_stash_arvalid,
    input  wire                        m_stash_arready,
    input  wire [AXI_DW-1:0]           m_stash_rdata,
    input  wire                        m_stash_rlast,
    input  wire                        m_stash_rvalid,
    output wire                        m_stash_rready,
    output wire [63:0]                 m_stash_awaddr,
    output wire [7:0]                  m_stash_awlen,
    output wire [2:0]                  m_stash_awsize,
    output wire [1:0]                  m_stash_awburst,
    output wire                        m_stash_awvalid,
    input  wire                        m_stash_awready,
    output wire [AXI_DW-1:0]           m_stash_wdata,
    output wire [AXI_DW/8-1:0]         m_stash_wstrb,
    output wire                        m_stash_wlast,
    output wire                        m_stash_wvalid,
    input  wire                        m_stash_wready,
    input  wire                        m_stash_bvalid,
    output wire                        m_stash_bready,
    output wire [4:0] dbg_oram_state,
    // Status
    output wire                  oram_busy,
    output wire                  err_stash_overflow,
    output wire                  err_bucket_overflow,
    output wire                  err_tag_mismatch,
    output wire [`BEAT_CNT_W-1:0]  oram_beat_cnt,
    output wire dbg_gcm_tag_match,
    output wire dbg_gcm_tag_valid,

    // Test controls
    input  wire dbg_force_same_bucket,
    input  wire [`BUCKET_ID_W-1:0] dbg_prng_override,
    input  wire perf_reset,

    // Performance counters - 4-way: rb=read/bucket, rs=read/stash, wb=write/bucket, ws=write/stash
    output wire [31:0] perf_rb_ddr_rd, perf_rb_decrypt, perf_rb_encrypt,
    output wire [31:0] perf_rb_compact, perf_rb_evict, perf_rb_ddr_wr,
    output wire [31:0] perf_rb_scan, perf_rb_stash,
    output wire [31:0] perf_rb_total, perf_rb_ops,
    output wire [31:0] perf_rs_ddr_rd, perf_rs_decrypt, perf_rs_encrypt,
    output wire [31:0] perf_rs_compact, perf_rs_evict, perf_rs_ddr_wr,
    output wire [31:0] perf_rs_scan, perf_rs_stash,
    output wire [31:0] perf_rs_total, perf_rs_ops,
    output wire [31:0] perf_wb_ddr_rd, perf_wb_decrypt, perf_wb_encrypt,
    output wire [31:0] perf_wb_compact, perf_wb_evict, perf_wb_ddr_wr,
    output wire [31:0] perf_wb_scan, perf_wb_stash,
    output wire [31:0] perf_wb_total, perf_wb_ops,
    output wire [31:0] perf_ws_ddr_rd, perf_ws_decrypt, perf_ws_encrypt,
    output wire [31:0] perf_ws_compact, perf_ws_evict, perf_ws_ddr_wr,
`ifdef ORAM_PHASE_TRACE
    output wire [10:0] phase_ent,           // build option: the core's phase-entry pulses
`endif
    output wire [31:0] perf_ws_scan, perf_ws_stash,
    output wire [31:0] perf_ws_total, perf_ws_ops
);

// plain_oram_top -- the non-oblivious, non-private baseline (build option ORAM_PLAIN), with secure_oram_top's ports.
// Following BOLT's description of its FPGA baseline (a key-value store using only HBM): each request is served by one
// access to the requested record's slot, record k at bucket-port address k * BLOCK (the kernel routes it to HBM when
// the host sizes the HBM page buffer for every slot: DOMA_PLAIN=1). No ORAM, no encryption or integrity, no padding,
// no stash, no position map. The kernel's command, data-slot and response path is unchanged, so its per-command cost
// is the same as DOMA's. Protocol, as doma_kernel drives it:
//   the lease and the key load are acknowledged at once; a request (one-cycle client_req) is followed by the command's
//   data slot, BEATS beats, one per cycle, without backpressure (GETs too: UNIFORM_FILL); the slot is taken first,
//   then a GET reads the record's slot and returns its beats (client_rdata_valid), a PUT writes the record's bytes
//   (the kernel's byte strobes, so packed neighbours are untouched); client_done follows. A read waits until every
//   earlier write is acknowledged (the ordering DOMA's axi_master keeps), a write may be posted.
    localparam integer BEATS = `BEATS_PER_BLOCK;
    localparam integer BLK_LG = $clog2(BEATS) + 5;               // log2 of the block size in bytes
    localparam [2:0] P_IDLE = 3'd0, P_FILL = 3'd1, P_RD_AR = 3'd2, P_RD_R = 3'd3, P_WR_AW = 3'd4, P_WR_W = 3'd5, P_DONE = 3'd6;
    reg  [2:0]  st;
    reg         op;                                               // 1 = PUT
    reg  [SLOT_AW-13:0] slot;                                     // record index (client_slot_addr >> 12)
    reg  [7:0]  cnt;                                              // beat counter (BEATS <= 128)
    reg  [15:0] wr_out;                                           // writes issued and not yet acknowledged
    reg         ack_q, key_q, done_q;
    reg  [AXI_DW-1:0]   dbuf [0:BEATS-1];
    reg  [AXI_DW/8-1:0] sbuf [0:BEATS-1];
    wire [AXI_AW-1:0]   rec_addr = {{(AXI_AW-(SLOT_AW-12)-BLK_LG){1'b0}}, slot, {BLK_LG{1'b0}}};
    wire aw_hs = (st == P_WR_AW) && m_axi_awready;
    wire w_hs  = (st == P_WR_W) && m_axi_wready;
    wire b_hs  = m_axi_bvalid;
    always @(posedge clk) if (st == P_FILL && client_wdata_valid[0]) begin dbuf[cnt] <= client_wdata[AXI_DW-1:0]; sbuf[cnt] <= client_wstrb[AXI_DW/8-1:0]; end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st <= P_IDLE; op <= 1'b0; slot <= 0; cnt <= 8'd0; wr_out <= 16'd0; ack_q <= 1'b0; key_q <= 1'b0; done_q <= 1'b0;
        end else begin
            ack_q <= mgmt_req; done_q <= 1'b0;
            if (key_load) key_q <= 1'b1;
            wr_out <= wr_out + (aw_hs ? 16'd1 : 16'd0) - (b_hs ? 16'd1 : 16'd0);
            case (st)
                P_IDLE:  if (client_req[0]) begin op <= client_op[0]; slot <= client_slot_addr[SLOT_AW-1:12]; cnt <= 8'd0; st <= P_FILL; end
                P_FILL:  if (client_wdata_valid[0]) begin
                             cnt <= cnt + 8'd1;
                             if (cnt == BEATS - 1) begin cnt <= 8'd0; st <= op ? P_WR_AW : P_RD_AR; end
                         end
                P_RD_AR: if (wr_out == 16'd0 && m_axi_arready) st <= P_RD_R;          // the read waits for earlier writes
                P_RD_R:  if (m_axi_rvalid && m_axi_rlast) st <= P_DONE;
                P_WR_AW: if (m_axi_awready) st <= P_WR_W;
                P_WR_W:  if (m_axi_wready) begin
                             cnt <= cnt + 8'd1;
                             if (cnt == BEATS - 1) st <= P_DONE;                    // done at hand-off, as DOMA
                         end
                P_DONE:  begin done_q <= 1'b1; st <= P_IDLE; end
                default: st <= P_IDLE;
            endcase
        end
    end
    assign mgmt_ack = ack_q; assign mgmt_error = 1'b0; assign dbg_halt_info = 64'd0; assign mgmt_token_out = 0; assign client_token_out = {NUM_CLIENTS{{{(TOKEN_WIDTH-1){1'b0}}, 1'b1}}};
    assign key_ready = key_q; assign oram_ready = key_q;
    assign client_ready = (st == P_IDLE) && key_q;
    assign client_done = done_q;
    assign client_rdata = m_axi_rdata;
    assign client_rdata_valid = (st == P_RD_R) && m_axi_rvalid;
    assign m_axi_arid = 0; assign m_axi_awid = 0;
    assign m_axi_araddr = rec_addr; assign m_axi_awaddr = rec_addr;
    assign m_axi_arlen = BEATS - 1; assign m_axi_awlen = BEATS - 1;
    assign m_axi_arsize = 3'd5; assign m_axi_awsize = 3'd5; assign m_axi_arburst = 2'd1; assign m_axi_awburst = 2'd1;
    assign m_axi_arvalid = (st == P_RD_AR) && (wr_out == 16'd0);
    assign m_axi_rready = (st == P_RD_R);
    assign m_axi_awvalid = (st == P_WR_AW);
    assign m_axi_wvalid = (st == P_WR_W);
    assign m_axi_wdata = dbuf[cnt]; assign m_axi_wstrb = sbuf[cnt]; assign m_axi_wlast = (cnt == BEATS - 1);
    assign m_axi_bready = 1'b1;
    // everything DOMA's core drives that the baseline does not use
    assign access_violation = 0;
    assign client_lockout = 0;
    assign err_ct_overrun = 0;
    assign client_wbeat_req = 0;
    assign err_slot_overrun = 0;
    assign dbg_slot_start = 0;
    assign dbg_real_cnt = 0;
    assign m_meta_araddr = 0;
    assign m_meta_arlen = 0;
    assign m_meta_arsize = 0;
    assign m_meta_arburst = 0;
    assign m_meta_arvalid = 0;
    assign m_meta_rready = 1'b1;
    assign m_meta_awaddr = 0;
    assign m_meta_awlen = 0;
    assign m_meta_awsize = 0;
    assign m_meta_awburst = 0;
    assign m_meta_awvalid = 0;
    assign m_meta_wdata = 0;
    assign m_meta_wstrb = 0;
    assign m_meta_wlast = 0;
    assign m_meta_wvalid = 0;
    assign m_meta_bready = 1'b1;
    assign m_brec_araddr = 0;
    assign m_brec_arlen = 0;
    assign m_brec_arsize = 0;
    assign m_brec_arburst = 0;
    assign m_brec_arvalid = 0;
    assign m_brec_rready = 1'b1;
    assign m_brec_awaddr = 0;
    assign m_brec_awlen = 0;
    assign m_brec_awsize = 0;
    assign m_brec_awburst = 0;
    assign m_brec_awvalid = 0;
    assign m_brec_wdata = 0;
    assign m_brec_wstrb = 0;
    assign m_brec_wlast = 0;
    assign m_brec_wvalid = 0;
    assign m_brec_bready = 1'b1;
    assign m_stash_araddr = 0;
    assign m_stash_arlen = 0;
    assign m_stash_arsize = 0;
    assign m_stash_arburst = 0;
    assign m_stash_arvalid = 0;
    assign m_stash_rready = 1'b1;
    assign m_stash_awaddr = 0;
    assign m_stash_awlen = 0;
    assign m_stash_awsize = 0;
    assign m_stash_awburst = 0;
    assign m_stash_awvalid = 0;
    assign m_stash_wdata = 0;
    assign m_stash_wstrb = 0;
    assign m_stash_wlast = 0;
    assign m_stash_wvalid = 0;
    assign m_stash_bready = 1'b1;
    assign dbg_oram_state = 0;
    assign oram_busy = 0;
    assign err_stash_overflow = 0;
    assign err_bucket_overflow = 0;
    assign err_tag_mismatch = 0;
    assign oram_beat_cnt = 0;
    assign dbg_gcm_tag_match = 0;
    assign dbg_gcm_tag_valid = 0;
    assign perf_rb_ddr_rd = 0;
    assign perf_rb_decrypt = 0;
    assign perf_rb_encrypt = 0;
    assign perf_rb_compact = 0;
    assign perf_rb_evict = 0;
    assign perf_rb_ddr_wr = 0;
    assign perf_rb_scan = 0;
    assign perf_rb_stash = 0;
    assign perf_rb_total = 0;
    assign perf_rb_ops = 0;
    assign perf_rs_ddr_rd = 0;
    assign perf_rs_decrypt = 0;
    assign perf_rs_encrypt = 0;
    assign perf_rs_compact = 0;
    assign perf_rs_evict = 0;
    assign perf_rs_ddr_wr = 0;
    assign perf_rs_scan = 0;
    assign perf_rs_stash = 0;
    assign perf_rs_total = 0;
    assign perf_rs_ops = 0;
    assign perf_wb_ddr_rd = 0;
    assign perf_wb_decrypt = 0;
    assign perf_wb_encrypt = 0;
    assign perf_wb_compact = 0;
    assign perf_wb_evict = 0;
    assign perf_wb_ddr_wr = 0;
    assign perf_wb_scan = 0;
    assign perf_wb_stash = 0;
    assign perf_wb_total = 0;
    assign perf_wb_ops = 0;
    assign perf_ws_ddr_rd = 0;
    assign perf_ws_decrypt = 0;
    assign perf_ws_encrypt = 0;
    assign perf_ws_compact = 0;
    assign perf_ws_evict = 0;
    assign perf_ws_ddr_wr = 0;
    assign perf_ws_scan = 0;
    assign perf_ws_stash = 0;
    assign perf_ws_total = 0;
    assign perf_ws_ops = 0;
`ifdef ORAM_PHASE_TRACE
    assign phase_ent = 0;
`endif
endmodule
