`default_nettype none   // implicit nets are errors (catches undeclared / mistyped wires)
// =============================================================================
// ghash_lane6.v -- GHASH at two blocks per cycle (6-way interleaved Horner)
//
// GHASH_H(X_1..X_n) = XOR_i X_i * H^(n+1-i)
//
// The extension of ghash_lane3 (one block per cycle, three chains with H^3) to two blocks
// per cycle. Blocks are dealt round-robin, by their index in the message, to six chains,
// each running Horner with H^6:
//     B_l <- (B_l * H^6) ^ X        (B_l * H^6 is precomputed as P_l)
// A cycle carries one or two blocks (data_mask 2'b01 or 2'b11, the first block in
// data_in[127:0]); the first goes to chain ln, the second to chain ln+1 (mod 6), and ln
// advances by the number of blocks. A chain is therefore reused at the earliest three
// cycles later, exactly when its next product is ready (operand register, multiply,
// reduce), so two blocks can be accepted every cycle with no back-pressure. Two
// multipliers: the cycle's first block uses multiplier A, the second multiplier B,
// each result written back to the chain it belongs to.
//
// After the beat flagged `last` (the message's final block is its last valid block, the
// GCM length block), the chains are combined, the chain of block n - d weighted H^(d+1):
//     Y = XOR_{d=0..5} B[chain(n-d)] * H^(d+1)
// three cycles of two multiplies, the same for every message (constant time). Chains that
// never received a block are zero, so short messages (n < 6) work; a one-block message X
// gives X * H, which is how the core derives H^2..H^6 once per key.
//
// Same multiplier and bit conventions as ghash_single_cycle_fpga / ghash_lane3
// (gf_pmul_128 + gf_reduce_128, reflected bit order). ghash_valid pulses once, with the
// final value, 7 cycles after the beat flagged last was accepted.
// =============================================================================
module ghash_lane6 (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         enable,
    input  wire         start,        // load H^1..H^6 and clear all chains
    input  wire [127:0] h1_key,
    input  wire [127:0] h2_key,
    input  wire [127:0] h3_key,
    input  wire [127:0] h4_key,
    input  wire [127:0] h5_key,
    input  wire [127:0] h6_key,
    input  wire [255:0] data_in,      // first block [127:0], second block [255:128]
    input  wire [1:0]   data_mask,    // 2'b01: one block, 2'b11: two blocks (2'b10, 2'b00: nothing)
    input  wire         data_valid,
    input  wire         last,         // qualifies data_valid: the beat holds the message's final block
    output reg  [127:0] ghash_out,
    output reg          ghash_valid,
    output wire         ready
);
    function [127:0] reflect128;
        input [127:0] d;
        integer j;
        begin
            for (j = 0; j < 128; j = j + 1)
                reflect128[j] = d[127-j];
        end
    endfunction
    function [2:0] lane_minus;          // (l - k) mod 6, l and k in 0..5
        input [2:0] l;
        input [2:0] k;
        begin
            lane_minus = (l >= k) ? (l - k) : (l + 3'd6 - k);
        end
    endfunction
    function [2:0] lane_plus1;          // (l + 1) mod 6
        input [2:0] l;
        begin
            lane_plus1 = (l == 3'd5) ? 3'd0 : l + 3'd1;
        end
    endfunction

    reg [127:0] hq1, hq2, hq3, hq4, hq5, hq6;
    reg [127:0] B [0:5];                // chain accumulators
    reg [127:0] P [0:5];                // B_l * H^6 for the chain's next block
    reg [2:0]   ln;                     // chain of the next block
    reg         loaded;
    reg         combining;
    reg [2:0]   cmb_step;               // 1..3: issue combine multiplies, 4: wait for them
    reg [2:0]   l_last;                 // chain of the final block
    reg [127:0] cmb_acc;
    reg [2:0]   cmb_pending;

    assign ready = loaded && !combining;

    wire         accept = data_valid && data_mask[0] && loaded && !combining && !start;
    wire         two    = data_mask[1];
    wire [2:0]   la     = ln;
    wire [2:0]   lb     = lane_plus1(ln);
    wire [127:0] bn_a   = P[la] ^ data_in[127:0];
    wire [127:0] bn_b   = P[lb] ^ data_in[255:128];

    // ---- operand select for the two multipliers ----
    reg          ma_go, mb_go;
    reg  [127:0] ma_x, ma_h, mb_x, mb_h;
    reg  [3:0]   ma_tag, mb_tag;        // 0..5: P[tag]; 8: combine term
    always @(*) begin
        ma_go = 1'b0; ma_x = 128'b0; ma_h = 128'b0; ma_tag = 4'd0;
        mb_go = 1'b0; mb_x = 128'b0; mb_h = 128'b0; mb_tag = 4'd0;
        if (accept) begin
            ma_go = 1'b1; ma_x = bn_a; ma_h = hq6; ma_tag = {1'b0, la};
            if (two) begin mb_go = 1'b1; mb_x = bn_b; mb_h = hq6; mb_tag = {1'b0, lb}; end
        end else if (combining && cmb_step >= 3'd1 && cmb_step <= 3'd3) begin
            ma_go = 1'b1; mb_go = 1'b1; ma_tag = 4'd8; mb_tag = 4'd8;
            case (cmb_step)
                3'd1:    begin ma_x = B[l_last];                    ma_h = hq1;
                               mb_x = B[lane_minus(l_last, 3'd1)];  mb_h = hq2; end
                3'd2:    begin ma_x = B[lane_minus(l_last, 3'd2)];  ma_h = hq3;
                               mb_x = B[lane_minus(l_last, 3'd3)];  mb_h = hq4; end
                default: begin ma_x = B[lane_minus(l_last, 3'd4)];  ma_h = hq5;
                               mb_x = B[lane_minus(l_last, 3'd5)];  mb_h = hq6; end
            endcase
        end
    end

    // Operand registers in front of the multipliers (as in ghash_lane3: operand selection
    // and the 128x128 multiply do not share a cycle), then product register, then reduce
    // and write back. A chain's next product lands three cycles after its update.
    reg          ma_go_q, mb_go_q;
    reg  [3:0]   ma_tag_q, mb_tag_q;
    reg  [127:0] ma_x_q, ma_h_q, mb_x_q, mb_h_q;
    wire [255:0] prod_a, prod_b;
    gf_pmul_128 u_pmul_a (.a(reflect128(ma_h_q)), .b(reflect128(ma_x_q)), .p(prod_a));
    gf_pmul_128 u_pmul_b (.a(reflect128(mb_h_q)), .b(reflect128(mb_x_q)), .p(prod_b));
    reg  [255:0] prod_a_q, prod_b_q;
    reg          sa_v, sb_v;
    reg  [3:0]   sa_tag, sb_tag;
    wire [127:0] red_a, red_b;
    gf_reduce_128 u_reduce_a (.c(prod_a_q), .r(red_a));
    gf_reduce_128 u_reduce_b (.c(prod_b_q), .r(red_b));
    wire [127:0] mres_a = reflect128(red_a);
    wire [127:0] mres_b = reflect128(red_b);
    wire         ca = sa_v && sa_tag[3];          // combine terms landing this cycle
    wire         cb = sb_v && sb_tag[3];

    integer i;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            hq1 <= 0; hq2 <= 0; hq3 <= 0; hq4 <= 0; hq5 <= 0; hq6 <= 0;
            for (i = 0; i < 6; i = i + 1) begin B[i] <= 0; P[i] <= 0; end
            ln <= 0; loaded <= 0; combining <= 0; cmb_step <= 0; l_last <= 0;
            cmb_acc <= 0; cmb_pending <= 0;
            ma_go_q <= 0; mb_go_q <= 0; ma_tag_q <= 0; mb_tag_q <= 0;
            ma_x_q <= 0; ma_h_q <= 0; mb_x_q <= 0; mb_h_q <= 0;
            prod_a_q <= 0; prod_b_q <= 0; sa_v <= 0; sb_v <= 0; sa_tag <= 0; sb_tag <= 0;
            ghash_out <= 0; ghash_valid <= 0;
        end else if (enable) begin
            ghash_valid <= 1'b0;

            // stage 0: capture the selected operands
            ma_go_q <= ma_go; ma_tag_q <= ma_tag;
            mb_go_q <= mb_go; mb_tag_q <= mb_tag;
            if (ma_go) begin ma_x_q <= ma_x; ma_h_q <= ma_h; end
            if (mb_go) begin mb_x_q <= mb_x; mb_h_q <= mb_h; end

            // stage 1: capture the products
            sa_v <= ma_go_q; sa_tag <= ma_tag_q;
            sb_v <= mb_go_q; sb_tag <= mb_tag_q;
            if (ma_go_q) prod_a_q <= prod_a;
            if (mb_go_q) prod_b_q <= prod_b;

            // stage 2: write back the reduced products (the two always go to different chains)
            if (sa_v && !sa_tag[3]) P[sa_tag[2:0]] <= mres_a;
            if (sb_v && !sb_tag[3]) P[sb_tag[2:0]] <= mres_b;
            if (ca || cb) begin
                cmb_acc     <= cmb_acc ^ (ca ? mres_a : 128'b0) ^ (cb ? mres_b : 128'b0);
                cmb_pending <= cmb_pending - {2'b0, ca} - {2'b0, cb};
            end

            if (accept) begin
                B[la] <= bn_a;
                if (two) B[lb] <= bn_b;
                ln <= two ? lane_plus1(lb) : lb;
                if (last) begin
                    combining   <= 1'b1;
                    cmb_step    <= 3'd1;
                    l_last      <= two ? lb : la;
                    cmb_acc     <= 128'b0;
                    cmb_pending <= 3'd6;
                end
            end

            if (combining) begin
                if (cmb_step >= 3'd1 && cmb_step <= 3'd3)
                    cmb_step <= cmb_step + 3'd1;
                else if (cmb_step == 3'd4 && cmb_pending == 3'd0) begin
                    ghash_out   <= cmb_acc;
                    ghash_valid <= 1'b1;
                    combining   <= 1'b0;
                    cmb_step    <= 3'd0;
                end
            end

            if (start) begin                       // last assignment wins
                hq1 <= h1_key; hq2 <= h2_key; hq3 <= h3_key; hq4 <= h4_key; hq5 <= h5_key; hq6 <= h6_key;
                loaded <= 1'b1;
                for (i = 0; i < 6; i = i + 1) begin B[i] <= 0; P[i] <= 0; end
                ln <= 0; combining <= 0; cmb_step <= 0; cmb_acc <= 0; cmb_pending <= 0;
                ma_go_q <= 1'b0; mb_go_q <= 1'b0; sa_v <= 1'b0; sb_v <= 1'b0;   // drop anything in flight
            end
        end
    end
`ifndef SYNTHESIS
    always @(posedge clk) if (rst_n && enable && data_valid && !accept && !start && data_mask[0])
        $display("[%0t] GHASH_LANE6: ERROR block dropped (loaded=%0d combining=%0d)", $time, loaded, combining);
`endif
endmodule
`default_nettype wire
