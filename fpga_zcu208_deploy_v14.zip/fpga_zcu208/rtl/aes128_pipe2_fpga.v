`default_nettype none   // implicit nets are errors (catches undeclared / mistyped wires)
`timescale 1ns / 1ps
//============================================================================
// AES-128 for the two-lane GCM core (aes_gcm_2lane.v): one key schedule shared by
// two encryption pipelines.
//
// aes128_key_sched_fpga      the registered key schedule of aes128_encrypt_pipeline_fpga,
//                            on its own: rk(i) is computed from the REGISTER rk(i-1), one
//                            SubWord plus XORs per clock, so rk(10) is right 11 cycles after
//                            the key input changes (the core waits 12 after a key change).
// aes128_encrypt_pipeline_rk_fpga
//                            the same ten-round pipeline as aes128_encrypt_pipeline_fpga
//                            (initial AddRoundKey register + aes128_round_fpga x 10), with
//                            the round keys as an input: 11 cycles from plaintext to
//                            ciphertext, one block per clock.
//
// aes128_encrypt_pipeline_fpga (aes128_round_fpga.v) is unchanged and still used by the
// one-lane reference core, aes_gcm_pipelined.v.
//============================================================================

module aes128_key_sched_fpga (
    input  wire          clk,
    input  wire          rst_n,
    input  wire [127:0]  key,
    output wire [1407:0] rk_all          // {rk10, rk9, ..., rk0}, 128 bits each
);
    reg  [127:0] rk0, rk1, rk2, rk3, rk4, rk5, rk6, rk7, rk8, rk9, rk10;
    wire [127:0] rk1_n, rk2_n, rk3_n, rk4_n, rk5_n, rk6_n, rk7_n, rk8_n, rk9_n, rk10_n;
    aes128_key_round #(.RCON(8'h01)) kr1  (.rk_in(rk0), .rk_out(rk1_n));
    aes128_key_round #(.RCON(8'h02)) kr2  (.rk_in(rk1), .rk_out(rk2_n));
    aes128_key_round #(.RCON(8'h04)) kr3  (.rk_in(rk2), .rk_out(rk3_n));
    aes128_key_round #(.RCON(8'h08)) kr4  (.rk_in(rk3), .rk_out(rk4_n));
    aes128_key_round #(.RCON(8'h10)) kr5  (.rk_in(rk4), .rk_out(rk5_n));
    aes128_key_round #(.RCON(8'h20)) kr6  (.rk_in(rk5), .rk_out(rk6_n));
    aes128_key_round #(.RCON(8'h40)) kr7  (.rk_in(rk6), .rk_out(rk7_n));
    aes128_key_round #(.RCON(8'h80)) kr8  (.rk_in(rk7), .rk_out(rk8_n));
    aes128_key_round #(.RCON(8'h1b)) kr9  (.rk_in(rk8), .rk_out(rk9_n));
    aes128_key_round #(.RCON(8'h36)) kr10 (.rk_in(rk9), .rk_out(rk10_n));
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rk0 <= 128'b0; rk1 <= 128'b0; rk2 <= 128'b0; rk3 <= 128'b0;
            rk4 <= 128'b0; rk5 <= 128'b0; rk6 <= 128'b0; rk7 <= 128'b0;
            rk8 <= 128'b0; rk9 <= 128'b0; rk10 <= 128'b0;
        end else begin
            rk0 <= key;   rk1 <= rk1_n; rk2 <= rk2_n; rk3 <= rk3_n; rk4 <= rk4_n; rk5 <= rk5_n;
            rk6 <= rk6_n; rk7 <= rk7_n; rk8 <= rk8_n; rk9 <= rk9_n; rk10 <= rk10_n;
        end
    end
    assign rk_all = {rk10, rk9, rk8, rk7, rk6, rk5, rk4, rk3, rk2, rk1, rk0};
endmodule

module aes128_encrypt_pipeline_rk_fpga (
    input  wire          clk,
    input  wire          rst_n,
    input  wire          enable,
    input  wire [127:0]  plaintext,
    input  wire [1407:0] rk_all,         // from aes128_key_sched_fpga
    input  wire          valid_in,
    output wire [127:0]  ciphertext,
    output wire          valid_out
);
    wire [127:0] rk [0:10];
    genvar r;
    generate for (r = 0; r <= 10; r = r + 1) begin : g_rk
        assign rk[r] = rk_all[128*r +: 128];
    end endgenerate

    // Initial AddRoundKey (round 0)
    reg [127:0] state_r0;
    reg         valid_r0;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_r0 <= 128'b0;
            valid_r0 <= 1'b0;
        end else if (enable) begin
            state_r0 <= plaintext ^ rk[0];
            valid_r0 <= valid_in;
        end
    end

    // Rounds 1..10 (round 10 without MixColumns)
    wire [127:0] st [0:10];
    wire         vl [0:10];
    assign st[0] = state_r0;
    assign vl[0] = valid_r0;
    generate for (r = 1; r <= 10; r = r + 1) begin : g_round
        aes128_round_fpga u_round (
            .clk(clk), .rst_n(rst_n), .enable(enable),
            .is_final_round(r == 10 ? 1'b1 : 1'b0),
            .state_in(st[r-1]), .round_key(rk[r]),
            .valid_in(vl[r-1]),
            .state_out(st[r]), .valid_out(vl[r])
        );
    end endgenerate

    assign ciphertext = st[10];
    assign valid_out  = vl[10];
endmodule
`default_nettype wire
