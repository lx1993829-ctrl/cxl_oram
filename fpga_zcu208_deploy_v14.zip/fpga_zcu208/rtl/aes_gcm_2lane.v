`default_nettype none   // implicit nets are errors (catches undeclared / mistyped wires)
`timescale 1ns / 1ps
//============================================================================
// AES-GCM, two 16-byte blocks per cycle (one 256-bit memory beat per cycle)
//
// The two-lane successor of aes_gcm_pipelined.v (kept unchanged as the reference). It
// computes exactly the same AES-128-GCM message: same key, same IV (the 96-bit LFSR, the
// same seeding and the same 96 steps per encryption), no AAD (len(A) = 0, as aes_len_bits
// in the old core), counter blocks IV||2, IV||3, ..., the length block len(A)||len(C),
// tag = GHASH ^ E(IV||1). For the same calls it returns the same ciphertext, tag and
// iv_out; only the timing differs.
//
// Data: data_in[255:0] carries one or two blocks, selected by data_mask: 2'b11 = two blocks
// (block 2k in [127:0], 2k+1 in [255:128], the order the one-lane core was fed), 2'b01 = one
// block in [127:0]. Any length works, even or odd. data_last marks the beat holding the
// message's final block; data_last with no beat at all (before the first beat) is the empty
// message, as in the old core. data_out / data_out_mask / data_out_valid / data_out_last
// return the beat 13 cycles after it was accepted (no back-pressure: the consumer takes
// every beat). Blocks are always full (the old core's data_bytes_valid is not supported).
//
// CTR: two AES-128 pipelines (aes128_encrypt_pipeline_rk_fpga) share one key schedule
// (aes128_key_sched_fpga). A two-block beat encrypts counters c and c+1 and advances the
// counter by 2 (a one-block beat by 1); counter_overflow is set if any block of the message
// uses counter 0xFFFFFFFF (the next one would wrap), as in the old core.
//
// GHASH: ghash_lane6, six interleaved Horner chains with H^6 and two multipliers, so it
// takes two blocks per cycle. H^1..H^6 are computed once per key (H = AES_K(0) on lane 0,
// then H^2..H^6 by five one-block GHASH runs, the old core's hp_step sequencer extended).
// The length block follows the last data beat in a one-block cycle (never padded: a zero
// block would change GHASH).
//
// Timing is constant: a message of n beats takes the same number of cycles for any data,
// key and IV, encryption or decryption. Start to tag_valid: 23 + n cycles when the key is
// unchanged; the first message after reset or a key change adds the key setup (a fixed
// 75 cycles: schedule settle 12, H 13, five GHASH runs 50). E(IV||1) is computed on lane 0 in the
// cycle before the first beat and never cached, so no shortcut depends on the IV.
//
// input_ready is high from the first cycle the core can take a beat until it accepts the
// beat flagged data_last, and never drops inside a message (no internal FIFO can fill):
// a producer may keep reads in flight. The key must be stable from start to tag_valid.
// tag_in is sampled with start (the controller sets both in the same cycle).
//============================================================================

module aes_gcm_2lane #(
    parameter [31:0] CTR0 = 32'd2     // first data counter. GCM: 2. Other values only for the
                                      // counter-overflow test (tb_gcm2.v).
)(
    input  wire         clk,
    input  wire         rst_n,
    input  wire         enable,

    // Control
    input  wire         start,
    input  wire         encrypt,
    input  wire [127:0] key,
    input  wire [95:0]  iv,
    // v14: advance the IV as an encryption would, without one (a register update, the core idle; it lands two
    // cycles after the pulse, and the core must not start in those cycles). The controller pulses it where an
    // on-package bucket is written in plaintext, so every later encryption gets the IV it would have had
    // (off-package ciphertext identical to v11g's).
    input  wire         iv_advance,

    // Data in: one 256-bit beat (one or two blocks) per cycle
    input  wire [255:0] data_in,
    input  wire [1:0]   data_mask,
    input  wire         data_valid,
    input  wire         data_last,

    // Data out
    output reg  [255:0] data_out,
    output reg  [1:0]   data_out_mask,
    output reg          data_out_valid,
    output reg          data_out_last,

    // Tag
    input  wire [127:0] tag_in,
    output reg  [127:0] tag_out,
    output reg          tag_valid,
    output reg          tag_match,

    // Status
    output wire         ready,
    output wire         busy,
    output wire         input_ready,

    // IV management (as aes_gcm_pipelined)
    output wire [95:0]  iv_out,
    output reg          iv_updated,
    output reg          counter_overflow
);
    localparam [3:0]
        ST_IDLE  = 4'd0,
        ST_KWAIT = 4'd1,     // key changed: let the key schedule settle
        ST_KH    = 4'd2,     // H = AES_K(0) on lane 0
        ST_KHW   = 4'd3,     // wait for H
        ST_HPOW  = 4'd4,     // H^2..H^6: five one-block GHASH runs
        ST_EY0   = 4'd5,     // E(IV||1) on lane 0, GHASH loaded with H^1..H^6
        ST_PROC  = 4'd6,     // take beats until data_last
        ST_DRAIN = 4'd7,     // last beat through AES, length block, GHASH combine
        ST_DONE  = 4'd8;     // advance the IV LFSR (encryption)
    localparam [1:0] K_DATA = 2'd0, K_EY0 = 2'd1, K_H = 2'd2;
    localparam integer AES_LAT = 11;                 // aes128_encrypt_pipeline_rk_fpga
    localparam integer SB_N    = AES_LAT + 1;        // sideband stages: input register + AES latency
    localparam [3:0]  KEY_SETTLE = 4'd12;            // > 11: rk10 is right 11 cycles after a key change

    reg [3:0] state;

    //=========================================================================
    // IV LFSR (identical to aes_gcm_pipelined): x^96 + x^10 + x^9 + x^6 + 1,
    // advanced 96 steps after every encryption
    //=========================================================================
    reg [95:0] iv_lfsr;
    reg [95:0] active_iv;
    reg        iv_seeded;
    function [95:0] advance_lfsr_96;
        input [95:0] state_in;
        reg [95:0] s;
        reg fb;
        integer step;
        begin
            s = state_in;
            for (step = 0; step < 96; step = step + 1) begin
                fb = s[95] ^ s[9] ^ s[8] ^ s[5];
                s = {s[94:0], fb};
            end
            advance_lfsr_96 = s;
        end
    endfunction
    wire [95:0] lfsr_advanced = advance_lfsr_96(iv_lfsr);
    wire [95:0] safe_seed = (iv == 96'b0) ? 96'hA5A5A5A5A5A5A5A5A5A5A5A5 : iv;
    // v14: the IV advance, pipelined so that no path from the IV input to the LFSR is longer than before: at the pulse
    // the seed (safe_seed) and whether this advance must seed are registered (adv1), the seed's 96 steps are registered
    // next (adv2), and then the LFSR takes them (the first use after reset or a key change: seed, then 96 steps) or
    // its own 96 steps (ST_IDLE below)
    reg         adv1, adv2, adv_seed1, adv_seed2;
    reg [95:0]  adv_s1, adv_s2;
    wire [95:0] adv_s1_96 = advance_lfsr_96(adv_s1);
    assign iv_out = active_iv;

    reg [127:0] last_key;
    // v14: the IV seeding's registered key compare (it was key_changed, against last_key) is against the key the LFSR
    // was last used under (iv_last_key: set by a start, as last_key, and by an IV advance); last_key (a start only)
    // still decides whether H must be recomputed. Without an IV advance the two keys are always equal, so the
    // seeding is exactly as before.
    reg [127:0] iv_last_key;
    reg         iv_key_changed;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) iv_key_changed <= 1'b1;
        else        iv_key_changed <= (key != iv_last_key);
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin adv1 <= 1'b0; adv2 <= 1'b0; adv_seed1 <= 1'b0; adv_seed2 <= 1'b0; adv_s1 <= 96'b0; adv_s2 <= 96'b0; end
        else if (enable) begin
            adv1 <= iv_advance && (state == ST_IDLE) && !start;
            if (iv_advance) begin adv_s1 <= safe_seed; adv_seed1 <= !iv_seeded || iv_key_changed; end
            adv2 <= adv1;
            if (adv1) begin adv_s2 <= adv_s1_96; adv_seed2 <= adv_seed1; end
        end
    end

    //=========================================================================
    // Registers
    //=========================================================================
    reg  [95:0]  iv_reg;
    reg          is_encrypt;
    reg  [127:0] tag_in_reg;
    reg  [127:0] h_pow [1:6];       // H^1..H^6 for the current key
    reg          hpow_valid;
    reg  [127:0] e_y0;
    reg  [31:0]  ctr, ctr1;         // counters of the next beat's lanes 0 and 1 (ctr1 = ctr + 1)
    reg  [63:0]  data_len_bits;
    wire [63:0]  aad_len_bits = 64'd0;   // no AAD (the old core's aad_len_bits never left 0)
    reg          any_beat;          // a beat was accepted in this message
    reg  [3:0]   kwait;
    reg  [2:0]   hp_k;              // HPOW: computing H^(hp_k+1) = GHASH(H^hp_k)
    reg  [1:0]   hp_step;
    reg          len_pending;       // the last data beat left AES: the length block follows

    assign ready       = (state == ST_IDLE) && !adv1 && !adv2;   // (v14: not while an IV advance lands)
    assign busy        = (state != ST_IDLE);
    assign input_ready = (state == ST_PROC);

    wire accept_beat  = (state == ST_PROC) && data_valid && data_mask[0];
    wire accept_empty = (state == ST_PROC) && !data_valid && data_last && !any_beat;   // empty message
    wire two_in       = data_mask[1];

    //=========================================================================
    // AES: one key schedule, two pipelines
    //=========================================================================
    wire [1407:0] rk_all;
    aes128_key_sched_fpga u_ksched (.clk(clk), .rst_n(rst_n), .key(key), .rk_all(rk_all));

    reg  [127:0] aes_pt0, aes_pt1;
    reg          aes_v0,  aes_v1;
    wire [127:0] aes_ct0, aes_ct1;
    wire         aes_vo0, aes_vo1;
    aes128_encrypt_pipeline_rk_fpga u_aes0 (
        .clk(clk), .rst_n(rst_n), .enable(enable), .plaintext(aes_pt0), .rk_all(rk_all),
        .valid_in(aes_v0), .ciphertext(aes_ct0), .valid_out(aes_vo0));
    aes128_encrypt_pipeline_rk_fpga u_aes1 (
        .clk(clk), .rst_n(rst_n), .enable(enable), .plaintext(aes_pt1), .rk_all(rk_all),
        .valid_in(aes_v1), .ciphertext(aes_ct1), .valid_out(aes_vo1));

    // Sideband delay line, aligned with the AES pipelines: stage 0 is written with the AES
    // input registers, stage SB_N-1 is valid in the cycle the keystream leaves AES. The data
    // stages have no reset (shift-register LUTs); the control stages do.
    reg  [255:0] sb_d    [0:SB_N-1];
    reg  [1:0]   sb_kind [0:SB_N-1];
    reg  [1:0]   sb_mask [0:SB_N-1];
    reg          sb_last [0:SB_N-1];
    reg          sb_v    [0:SB_N-1];
    reg  [255:0] sb_d_in;
    reg  [1:0]   sb_kind_in, sb_mask_in;
    reg          sb_last_in, sb_v_in;
    integer k;
    always @(posedge clk) if (enable) begin
        sb_d[0] <= sb_d_in;
        for (k = 1; k < SB_N; k = k + 1) sb_d[k] <= sb_d[k-1];
    end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (k = 0; k < SB_N; k = k + 1) begin sb_v[k] <= 1'b0; sb_kind[k] <= 2'd0; sb_mask[k] <= 2'd0; sb_last[k] <= 1'b0; end
        end else if (enable) begin
            sb_v[0] <= sb_v_in; sb_kind[0] <= sb_kind_in; sb_mask[0] <= sb_mask_in; sb_last[0] <= sb_last_in;
            for (k = 1; k < SB_N; k = k + 1) begin
                sb_v[k] <= sb_v[k-1]; sb_kind[k] <= sb_kind[k-1]; sb_mask[k] <= sb_mask[k-1]; sb_last[k] <= sb_last[k-1];
            end
        end
    end
    wire         so_v    = sb_v[SB_N-1];
    wire [1:0]   so_kind = sb_kind[SB_N-1];
    wire [1:0]   so_mask = sb_mask[SB_N-1];
    wire         so_last = sb_last[SB_N-1];
    wire [255:0] so_d    = sb_d[SB_N-1];
    wire [255:0] so_x    = so_d ^ {aes_ct1, aes_ct0};                 // CTR: data XOR keystream
    wire [255:0] so_out  = {so_mask[1] ? so_x[255:128] : 128'b0, so_x[127:0]};

    //=========================================================================
    // GHASH
    //=========================================================================
    reg          gh_start;
    reg  [255:0] gh_d;
    reg  [1:0]   gh_m;
    reg          gh_v, gh_last;
    wire [127:0] gh_out;
    wire         gh_valid, gh_ready;
    ghash_lane6 u_ghash (
        .clk(clk), .rst_n(rst_n), .enable(enable), .start(gh_start),
        .h1_key(h_pow[1]), .h2_key(h_pow[2]), .h3_key(h_pow[3]),
        .h4_key(h_pow[4]), .h5_key(h_pow[5]), .h6_key(h_pow[6]),
        .data_in(gh_d), .data_mask(gh_m), .data_valid(gh_v), .last(gh_last),
        .ghash_out(gh_out), .ghash_valid(gh_valid), .ready(gh_ready));

    //=========================================================================
    // AES input select (combinational), registered below with the sideband
    //=========================================================================
    always @(*) begin
        sb_v_in = 1'b0; sb_kind_in = K_DATA; sb_mask_in = 2'b00; sb_last_in = 1'b0; sb_d_in = data_in;
        if (state == ST_KH) begin
            sb_v_in = 1'b1; sb_kind_in = K_H;
        end else if (state == ST_EY0) begin
            sb_v_in = 1'b1; sb_kind_in = K_EY0;
        end else if (accept_beat) begin
            sb_v_in = 1'b1; sb_mask_in = {two_in, 1'b1}; sb_last_in = data_last;
        end else if (accept_empty) begin
            sb_v_in = 1'b1; sb_mask_in = 2'b00; sb_last_in = 1'b1;   // no block: only closes the message
        end
    end

    //=========================================================================
    // Main state machine
    //=========================================================================
    integer j;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= ST_IDLE;
            iv_lfsr <= 96'b0; active_iv <= 96'b0; iv_seeded <= 1'b0; iv_updated <= 1'b0;
            last_key <= 128'b0; iv_last_key <= 128'b0; iv_reg <= 96'b0; is_encrypt <= 1'b1; tag_in_reg <= 128'b0;
            for (j = 1; j <= 6; j = j + 1) h_pow[j] <= 128'b0;
            hpow_valid <= 1'b0; e_y0 <= 128'b0;
            ctr <= CTR0; ctr1 <= CTR0 + 32'd1; data_len_bits <= 64'd0; any_beat <= 1'b0;
            kwait <= 4'd0; hp_k <= 3'd1; hp_step <= 2'd0; len_pending <= 1'b0;
            aes_pt0 <= 128'b0; aes_pt1 <= 128'b0; aes_v0 <= 1'b0; aes_v1 <= 1'b0;
            gh_start <= 1'b0; gh_d <= 256'b0; gh_m <= 2'b00; gh_v <= 1'b0; gh_last <= 1'b0;
            data_out <= 256'b0; data_out_mask <= 2'b00; data_out_valid <= 1'b0; data_out_last <= 1'b0;
            tag_out <= 128'b0; tag_valid <= 1'b0; tag_match <= 1'b0; counter_overflow <= 1'b0;
        end else if (enable) begin
            // one-cycle pulses
            gh_start <= 1'b0; gh_v <= 1'b0; gh_last <= 1'b0;
            data_out_valid <= 1'b0; data_out_last <= 1'b0;
            tag_valid <= 1'b0; iv_updated <= 1'b0;

            // ---- AES inputs (lane 0: counter c, H or E(Y0); lane 1: counter c+1) ----
            aes_v0 <= 1'b0; aes_v1 <= 1'b0;
            if (state == ST_KH) begin
                aes_pt0 <= 128'b0;                       aes_v0 <= 1'b1;
            end else if (state == ST_EY0) begin
                aes_pt0 <= {iv_reg, 32'h00000001};       aes_v0 <= 1'b1;
            end else if (accept_beat) begin
                aes_pt0 <= {iv_reg, ctr};  aes_v0 <= 1'b1;
                aes_pt1 <= {iv_reg, ctr1}; aes_v1 <= two_in;
                if (ctr == 32'hFFFFFFFF || (two_in && ctr1 == 32'hFFFFFFFF)) begin
                    counter_overflow <= 1'b1;
`ifdef ORAM_DEBUG
                    $display("[%0t] [AES-GCM2] WARNING: 32-bit counter overflow!", $time);
`endif
                end
                ctr  <= two_in ? ctr  + 32'd2 : ctr  + 32'd1;
                ctr1 <= two_in ? ctr1 + 32'd2 : ctr1 + 32'd1;
                data_len_bits <= data_len_bits + (two_in ? 64'd256 : 64'd128);
                any_beat <= 1'b1;
            end

            // ---- AES outputs (the sideband says what left the pipelines) ----
            if (so_v) begin
                case (so_kind)
                    K_H:   h_pow[1] <= aes_ct0;
                    K_EY0: e_y0     <= aes_ct0;
                    default: begin
                        if (so_mask[0]) begin
                            data_out <= so_out; data_out_mask <= so_mask;
                            data_out_valid <= 1'b1; data_out_last <= so_last;
                            // GHASH runs over the ciphertext: the output when encrypting, the input when decrypting
                            gh_d <= is_encrypt ? so_out : {so_mask[1] ? so_d[255:128] : 128'b0, so_d[127:0]};
                            gh_m <= so_mask; gh_v <= 1'b1;
                        end
                        if (so_last) len_pending <= 1'b1;
                    end
                endcase
            end
            if (len_pending) begin                       // the length block, alone, closes the GHASH
                gh_d <= {128'b0, aad_len_bits, data_len_bits}; gh_m <= 2'b01; gh_v <= 1'b1; gh_last <= 1'b1;
                len_pending <= 1'b0;
            end

            case (state)
                ST_IDLE: if (start) begin
                    is_encrypt <= encrypt;
                    tag_in_reg <= tag_in;
                    ctr <= CTR0; ctr1 <= CTR0 + 32'd1;
                    data_len_bits <= 64'd0; any_beat <= 1'b0; len_pending <= 1'b0;
                    counter_overflow <= 1'b0;
                    // IV selection, exactly as aes_gcm_pipelined: decryption uses the given IV; the first
                    // encryption after reset or a key change seeds the LFSR with the given IV, later ones
                    // use the LFSR's current value
                    if (!encrypt) begin
                        iv_reg <= iv; active_iv <= iv;
                    end else if (!iv_seeded || iv_key_changed) begin
                        iv_lfsr <= safe_seed; active_iv <= safe_seed; iv_reg <= safe_seed; iv_seeded <= 1'b1;
                    end else begin
                        active_iv <= iv_lfsr; iv_reg <= iv_lfsr;
                    end
                    last_key <= key; iv_last_key <= key;
                    if ((key != last_key) || !hpow_valid) begin   // new key: H and its powers first
                        hpow_valid <= 1'b0; kwait <= KEY_SETTLE; state <= ST_KWAIT;
                    end else
                        state <= ST_EY0;
                end else if (adv2) begin
                    // v14: the IV update of one encryption (its seeding at start, its 96 steps at the end)
                    iv_lfsr <= adv_seed2 ? adv_s2 : lfsr_advanced; iv_seeded <= 1'b1;
                    iv_last_key <= key; iv_updated <= 1'b1;
                end
                ST_KWAIT: if (kwait != 4'd1) kwait <= kwait - 4'd1; else state <= ST_KH;
                ST_KH:    state <= ST_KHW;                       // AES(0) issued on lane 0 (above)
                ST_KHW:   if (so_v && so_kind == K_H) begin hp_k <= 3'd1; hp_step <= 2'd0; state <= ST_HPOW; end
                ST_HPOW: begin
                    // H^(k+1) = GHASH_H(H^k): a one-block message X gives X * H. Only h_pow[1] matters
                    // to a one-block message (the other chains are zero), so the partial powers are harmless.
                    case (hp_step)
                        2'd0: begin gh_start <= 1'b1; hp_step <= 2'd1; end
                        2'd1: begin gh_d <= {128'b0, h_pow[hp_k]}; gh_m <= 2'b01; gh_v <= 1'b1; gh_last <= 1'b1; hp_step <= 2'd2; end
                        default: if (gh_valid) begin
                            h_pow[hp_k + 3'd1] <= gh_out;
                            if (hp_k == 3'd5) begin hpow_valid <= 1'b1; state <= ST_EY0; end
                            else begin hp_k <= hp_k + 3'd1; hp_step <= 2'd0; end
                        end
                    endcase
                end
                ST_EY0: begin                                    // E(IV||1) issued on lane 0 (above)
                    gh_start <= 1'b1;                            // GHASH: load H^1..H^6, clear the chains
                    state <= ST_PROC;
                end
                ST_PROC: if ((accept_beat && data_last) || accept_empty) state <= ST_DRAIN;
                ST_DRAIN: if (gh_valid) begin
                    tag_out   <= gh_out ^ e_y0;
                    tag_valid <= 1'b1;
                    tag_match <= is_encrypt ? 1'b1 : ((gh_out ^ e_y0) == tag_in_reg);
                    state     <= ST_DONE;
                end
                ST_DONE: begin
                    if (is_encrypt) begin                        // the next encryption gets a fresh IV
                        iv_lfsr <= lfsr_advanced;
                        iv_updated <= 1'b1;
                    end
                    state <= ST_IDLE;
                end
                default: state <= ST_IDLE;
            endcase
        end
    end

`ifndef SYNTHESIS
    // protocol checks (simulation only)
    always @(posedge clk) if (rst_n && enable) begin
        if (start && state != ST_IDLE)
            $display("[%0t] AES_GCM_2LANE: ERROR start while busy (state %0d) ignored", $time, state);
        if (iv_advance && (state != ST_IDLE || start || adv1 || adv2))
            $display("[%0t] AES_GCM_2LANE: ERROR IV advance while busy (state %0d, start %0d, advance %0d%0d) ignored", $time, state, start, adv1, adv2);
        if (start && (adv1 || adv2))
            $display("[%0t] AES_GCM_2LANE: ERROR start while an IV advance lands (it is lost)", $time);
        if (data_valid && state != ST_PROC && state != ST_IDLE)
            $display("[%0t] AES_GCM_2LANE: ERROR beat while input_ready is low (state %0d) dropped", $time, state);
        if (data_valid && !data_mask[0])
            $display("[%0t] AES_GCM_2LANE: ERROR beat with lane 0 empty (mask %b) ignored", $time, data_mask);
        if (so_v && (so_kind != K_DATA || so_mask[0]) && aes_vo0 !== 1'b1)
            $display("[%0t] AES_GCM_2LANE: ERROR sideband and AES pipeline out of step", $time);
    end
`endif
endmodule
`default_nettype wire
