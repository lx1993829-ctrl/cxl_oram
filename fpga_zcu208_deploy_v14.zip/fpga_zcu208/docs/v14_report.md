# v14: on-package buckets in plaintext

On-package (HBM) buckets are kept in plaintext in arrival-mode builds (the deployed ones). An access to one skips
decryption, the tag check and re-encryption, and its write-back streams behind the eviction copies. Everything
off package is v11g's, cycle for cycle. Strict-mode builds are unchanged.

## Design, as agreed

- **Path by location.** The path is chosen by `acc_hbm` (bucket < cfg_hbm_bkts).
  - An on-package read lands in scratch as plaintext (same 32 B per cycle, same beat order). `S_DDR_READ` waits for the
    last beat and the whole record, then the operation starts.
  - At `S_EA_START` (every decision made), the write-back is issued and streams behind the copies. The master may send
    a position once its copy has landed (`enc_pos_done` = leading landed positions).
  - Blocks cross between locations through the stash (plaintext).
- **IV.** Every skipped encryption (on-package write-back or format) advances the IV with no GCM pass:
  `aes_gcm_2lane` `iv_advance`, using the same first-use seeding and the same 96 steps.
  - The advance is pipelined: it lands two cycles after the pulse. That keeps the 96-step XOR network out of the
    IV-input path. The FSM waits for nothing, so no cycles are added on the path.
  - The seeding compare now uses `iv_last_key`, which a start and an advance both set; it replaced `key_changed`.
    Without an advance this is exactly v11g's rule.
- **Boot.**
  - On-package buckets are formatted with zeros, forced at the master's output.
  - The boot gets shorter by an amount set only by the on-package bucket count.
  - At 0% on package the boot is v11g's.
- **Records.** For an on-package bucket, only beat 0 (fill, slot list) is written. Beat 1 (IV/tag) is never written or
  read. Choice: the record layout and fetch stay v11g's, so the record unit and every off-package record are unchanged.
- **Overruns, on package.**
  1. The write-back has not started by t_arr+AR_WB_H. This is the early check, sized from the decisions' worst case.
  2. The release gate has not been reached by t_arr+AR_REL_H, meaning the last W beat was not accepted in time.

  Either one raises 0x108 in the release cycle itself, never earlier, with the same halt as off package. The release
  never moves. A beat held for its copy is not an overrun on package; off package it still is.
- **Phase trace.** On package, slot 5 = slot 6 and slot 8 = slot 10 (zero-length crypto). All 16 slots stay in order,
  and host_phases and host_ycsb accept them unchanged (their order checks use <=).

## Changes, file:line (v14 package, rtl/ CRLF as v11g)

**rtl/flat_oram_gcm.v**
- 264-274: `BYP`; `acc_hbm` moved here; `fmt_zero`.
- 282-289: phase trace, zero-length crypto on package.
- 345, 370: `gcm_iv_adv` → `iv_advance`.
- 567-571, 594: `m_axi_wdata` zeroed while `fmt_zero` (the master's write data renamed `axim_wdata_m`).
- 609-611: hold comment.
- 707-712: `acc_hbm` moved (comment), `ar_max_rel_h`, `bm_seen`, `byp_ov`.
- 893-901: `byp_acc`, `byp_lead`.
- 915-916: resets.
- 934: pulse default.
- 955: `bm_seen`.
- 961: write-back gate (`!byp_acc`).
- 976-988:
  - the stall is no overrun on package, and a bank conflict is deferred;
  - deadline (1) at 985;
  - deadline (2) at 986;
  - `enc_pos_done <= byp_lead` at 988.
- 1079: `bm_seen` cleared at the lookup.
- 1099, 1103: read gate (`byp_ov` cleared) → `S_DDR_READ`.
- 1107-1110: `S_DDR_READ` (was unused): wait for the last beat and the record.
- 1336-1346: `S_EA_START`: write-back issued, IV advance, `ar_max_wb_h`.
- 1362-1366: `ar_max_rel_h`.
- 1404-1412: plaintext format.
- 1420: `fmt_zero` cleared.
- 1589: safety-monitor comment.

**rtl/aes_gcm_2lane.v**
- 57-61: `iv_advance` port.
- 131-137: pipeline registers.
- 141-146: `iv_last_key` and `iv_key_changed` (replaces `key_changed`); 279: its reset.
- 148-159: advance pipeline.
- 180: `ready` low while an advance lands.
- 349, 354: seeding uses `iv_key_changed`; a start sets `iv_last_key`.
- 359-362: the advance lands in ST_IDLE.
- 408-411: simulation checks.

**rtl/oram_params.vh**
- 16: package revision.
- 242-244: the older λ7 comment marked as superseded.
- 250-268: v14 budget rules.
- 261-268, 286-293, 331-338: the λ7 `AR_WB_H`, `AR_DONE_H` and `AR_REL_H` values.

**sim/**
- tb_doma_kernel.v:
  - per-access observable hashes;
  - `+inspect` memory dump;
  - `+junk_mem`;
  - `+hbmb_whold` and `+hbmb_whold_at`;
  - OVERRUN-AT report;
  - `+phase_trace` check;
  - `TB_V11G_REF`.
- axi_mem_model.v: `w_hold`.
- oram_timing_monitor.v: `byp` and `t_dg` columns.
- tb_ni.v, tb_onboard_test_top.v: monitor port; `TB_V11G_REF`.
- tb_gcm2.v: `iv_advance` tied off.
- worst_case.py: part 4, the on-package model.
- run_verilator.sh: new `onpkg` group; on-package cycle model in the worst and combined groups; AR_REL_H check in
  arrival; IV advance in crypto; host-memory part of the digests for on-package runs; `RTL_DIR`/`TB_DEFS` reference
  mode.
- golden_bucket_digests.txt: v11g references for the new runs.
- New files: tb_ivadv.v, inspect_check.py, compare_v11g.py, budgets_v14.py.

**docs/**
- README_FPGA.md: v14 section.
- New: v14_budgets.txt, v14_regression_lambda7.txt, v14_resources_timing.txt, this report.

Cumulative patch: patches/fpga_onpkg_plaintext.patch. v11g plus this patch reproduces the package.

## On-package budgets, λ=7 (cycles at 300 MHz)

**Rules**
- AR_WB_H = max(derived, measured) + 74.
- AR_REL_H = max(derived + bp(b), measured) + 74, where bp(b) = ceil(0.05 (8b + 2 bursts + 22)) is a 5% slower HBM
  write.
- AR_DONE_H = AR_REL_H + v11g's acknowledgement allowance.

"Derived" is the cycle model on the directed worst cases with every metadata read at 200 cycles. "Measured" is the worst
of 7 calibration runs per size.

| size | AR_WB_H v11g → v14 | AR_REL_H v11g → v14 | AR_DONE_H v11g → v14 | saved per on-package access |
|---|---|---|---|---|
| 32 B | 798 → 644 | 834 → 659 | 842 → 667 | 175 |
| 64 B | 802 → 640 | 844 → 663 | 858 → 677 | 181 |
| 128 B | 810 → 632 | 869 → 672 | 890 → 693 | 197 |
| 256 B | 826 → 616 | 919 → 690 | 953 → 724 | 229 |
| 512 B | 858 → 584 | 1018 → 725 | 1080 → 787 | 293 |
| 1 KB | 969 → 567 | 1266 → 843 | 1381 → 958 | 423 |
| 2 KB | 1321 → 663 | 1891 → 1208 | 2112 → 1429 | 683 |
| 4 KB | 2025 → 855 | 3141 → 1938 | 3575 → 2372 | 1,203 |

The release and end of an on-package access move earlier by the AR_REL_H difference. Off-package budgets and CT_RD are
unchanged. λ6 is not recalibrated: it keeps v11g's on-package budgets, which are safe and not tight.

**Measured, 120 commands, every bucket on package (HBM reads at 179 cycles), per command v11g → v14:**

| size | per command | device cycles | device cycles, half on package |
|---|---|---|---|
| 32 B | 1,302 → 1,127 | −13% | −9% |
| 64 B | 1,322 → 1,141 | −14% | −9% |
| 128 B | 1,367 → 1,170 | −14% | −9% |
| 256 B | 1,457 → 1,228 | −16% | −10% |
| 512 B | 1,636 → 1,343 | −18% | −11% |
| 1 KB | 2,051 → 1,628 | −20% | −13% |
| 2 KB | 2,996 → 2,313 | −22% | −14% |
| 4 KB | 4,886 → 3,683 | −24% | −14% |

## Regression, λ=7, every size (docs/v14_regression_lambda7.txt)

**15 groups × 8 sizes: 736 PASS, 0 FAIL.** 512 B to 4 KB ran on the cloud; 32 B to 256 B and the v11g references ran on
the laptop.

**Full existing regression.** All of it passes, including the existing digest check against the v11b/v11g reference
in 45 runs per size. In arrival runs with buckets on package, only the host-memory part is compared, and it is
bit-identical.

**v11g comparison** (compare_v11g.py: every run against v11g's RTL under the same testbenches):
- No bucket on package: 34 to 48 runs per size are identical on every line. That covers the boot, cycles, latencies,
  timing hashes, per-access shapes and digests.
- Buckets on package (20, 25, 50 and 100%, onpkg20, onpkg_trace): 8 runs per size are identical in host-memory bucket
  writes, off-package access shapes, host traffic and results.
- At 32 B to 256 B, the laptop's v14 builds of bp1/bp2 ran one cycle off, and boot_over at 64 B printed its halt 1 ns
  later. Those cases are the calibration build under 30% random backpressure.
  - Rerun on the cloud, all 9 runs are identical to v11g.
  - The cloud's v14 and v11g give the same bp1 trace hash.
  - So the laptop's simulator settles a testbench race differently for the two netlists; the RTL does not.

**onpkg group, every size**
- 100% and 20% on package: every GET correct.
- Memory inspection (inspect_check.py, gcm2_ref.py): on-package buckets hold their blocks in plaintext. Off-package
  buckets verify under their IV and tag and decrypt to their blocks, none in plaintext.
- Boot from junk-filled memory: never-written blocks read and inspect as zeros.
- Release and end are one fixed offset across stash histories and stash speed (preloaded; empty with other keys;
  metadata at 200 cycles). At 32 B the release is 990 cycles after the access start; at 2 KB, 2050.
- Slow HBM within the bound (metadata at 200 cycles, every HBM write burst held so the total is bp(b) + 60): nothing
  moves, no overrun.
- Beyond the bound (writes held AR_REL_H from the 51st access): 0x108 is raised in the cycle t_arr+AR_REL_H exactly
  (32 B 659, 2 KB 1208). The 50 accesses before it released at the usual offset. No hang, and the next launch reports
  the halt.
- Phase trace: on-package records have zero-length crypto phases with every slot in order; off-package records have
  timed crypto phases.

**Other new checks, every size**
- Cycle model, both paths: on package (directed worst cases, gap-free) and the derived adverse bound fit AR_WB_H and
  AR_REL_H (combined). The measured release gate fits AR_REL_H in arrival.
- IV advance unit test (with mutation checks): every later IV, ciphertext and tag is as if each skipped operation had
  been an encryption, including seeding after reset and after a key change.

## Resources and 300 MHz risk (docs/v14_resources_timing.txt)

Yosys synth_xilinx (xcup), flat_oram_gcm at 32 B. This is an estimate, not Vivado.

| | v11g | v14 | change |
|---|---|---|---|
| LUTs | 63,965 | 64,584 | +619 (+1.0%) |
| Registers | 21,706 | 22,034 | +328 (+1.5%) |
| Block RAM | 32 RAMB36 | 32 RAMB36 | none |
| LUT-RAM | 101 | 101 | none |

Most of the added registers are the advance pipeline (192) and `iv_last_key` (128).

**Logic depth.** The deepest path stays at v11g's 7 LUT levels.
- These grew by one level and stay at most 7: `iv_key_changed`, `enc_pos_done`, `err_ct_overrun_r` (the deadline
  compares, the same shape as the existing write-back gate compare), and the master's state.
- The advance's 96-step network is register to register, 7 levels.
- `m_axi_wdata` gets one LUT after the master's output register.

## Uncertainties

1. **Timing.** The depth figures are a Yosys proxy. Vivado place and route at 300 MHz has not been run: on the server,
   vitis/synth_ooc.tcl and worst_paths.tcl, or a hardware build.
2. **The slow-HBM bound is an assumption.** The budgets cover metadata reads at 200 cycles (U55C measured worst: 191)
   and an HBM write taking 5% longer. Beyond that the access halts with 0x108 at the release time. The worst stash
   wait comes from the directed full-window cases, as in v11b.
3. **λ=6 is not recalibrated** and not built for v14.
4. **Overrun handling after a halt.** After an on-package overrun the controller finishes the late access internally,
   then halts in S_IDLE, as off package. The kernel has already reported ERR at the release time, and the result is
   never returned.
5. **Not run on the card.** host_phases and host_ycsb accept zero-length crypto phases by code inspection (`<=`
   chain), not by a run on the card.
6. **Testbench race.** The laptop-only one-cycle race in the backpressure tests is a testbench artifact. It also exists
   in v11g's runs; it shows only when the netlist changes.
