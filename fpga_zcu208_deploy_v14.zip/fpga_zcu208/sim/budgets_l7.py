#!/usr/bin/env python3
"""budgets_l7.py -- DOMA's lambda = 7 arrival budgets, from lambda = 7 measurements (sim/measure_lambda.sh).

    python3 budgets_l7.py --show  PARAMS measure_lambda7.csv [more.csv ...]
    python3 budgets_l7.py --write PARAMS measure_lambda7.csv [more.csv ...]

Each CSV has the columns beats, host_measured, hbm_measured, status (measure_lambda.sh's output); a size may appear in
several (e.g. measured on two machines): its worst is the largest. The rules (README, "Lambda 7 budgets"), per size,
with the lambda = 6 budgets already in PARAMS (sim/budgets.py):
  HBM buckets:  AR_WB_H(7) = max(AR_WB_H(6), measured HBM worst + 74); AR_REL_H(7), AR_DONE_H(7) move by the same amount
  host buckets: AR_WB(7)   = max(AR_WB(6),   measured host worst + 54); AR_REL(7),   AR_DONE(7)   move by the same amount
(+74 and +54: the margins sim/budgets.py adds at lambda 6.) They are the ORAM_AR_*_L7_B<beats> defines, selected by
ORAM_C == 7. Host lambda = 7 budgets are new in v11b: the random placement at boot lets the directed calibration cases
reach buckets whose waiting blocks spill past the stash window, and their host worst at lambda 7 exceeds lambda 6's.
"""
import csv, re, sys

def read(params):
    raw = open(params, newline="").read()
    return raw, "\r\n" in raw, raw.replace("\r\n", "\n")

def get(s, name):
    m = re.search(r"^`define %s +(\d+)" % name, s, re.M)
    if not m: sys.exit(f"budgets_l7.py: {name} not found")
    return int(m.group(1))

def worst(csvs):
    w = {}
    for p in csvs:
        for r in csv.DictReader(open(p)):
            b = int(r["beats"])
            if r["status"] != "ok": sys.exit(f"budgets_l7.py: {p}: the measurement at {b} beats did not pass: {r['status']}")
            h, m = int(r["host_measured"]), int(r["hbm_measured"])
            oh, om = w.get(b, (0, 0)); w[b] = (max(oh, h), max(om, m))
    return w

def compute(s, w):
    out = []
    for b in sorted(w):
        host, hbm = w[b]
        wb6h, rel6h, done6h = get(s, f"ORAM_AR_WB_H_B{b}"), get(s, f"ORAM_AR_REL_H_B{b}"), get(s, f"ORAM_AR_DONE_H_B{b}")
        wb6, rel6, done6 = get(s, f"ORAM_AR_WB_B{b}"), get(s, f"ORAM_AR_REL_B{b}"), get(s, f"ORAM_AR_DONE_B{b}")
        wb7h = max(wb6h, hbm + 74); dh = wb7h - wb6h
        wb7 = max(wb6, host + 54); d = wb7 - wb6
        out.append(dict(b=b, host=host, hbm=hbm, wb6=wb6, wb7=wb7, rel7=rel6 + d, done7=done6 + d, d=d,
                        wb6h=wb6h, wb7h=wb7h, rel7h=rel6h + dh, done7h=done6h + dh, dh=dh))
    return out

def main(a):
    if len(a) < 3 or a[0] not in ("--show", "--write"): sys.exit(__doc__)
    params = a[1]
    raw, crlf, s = read(params)
    res = compute(s, worst(a[2:]))
    for x in res:
        print(f"{x['b']*32:>5} B ({x['b']:3d} beats): host {x['host']}: AR_WB(7) = max({x['wb6']}, {x['host']} + 54) = {x['wb7']} (+{x['d']}), "
              f"AR_REL(7) {x['rel7']}, AR_DONE(7) {x['done7']}; HBM {x['hbm']}: AR_WB_H(7) = max({x['wb6h']}, {x['hbm']} + 74) = "
              f"{x['wb7h']} (+{x['dh']}), AR_REL_H(7) {x['rel7h']}, AR_DONE_H(7) {x['done7h']}")
    if a[0] == "--write":
        for x in res:
            for k, v in (("AR_WB_L7", x["wb7"]), ("AR_REL_L7", x["rel7"]), ("AR_DONE_L7", x["done7"]),
                         ("AR_WB_H_L7", x["wb7h"]), ("AR_REL_H_L7", x["rel7h"]), ("AR_DONE_H_L7", x["done7h"])):
                pat = re.compile(r"^(`define ORAM_%s_B%d +)\d+" % (k, x["b"]), re.M)
                if len(pat.findall(s)) != 1: sys.exit(f"budgets_l7.py: ORAM_{k}_B{x['b']} not found exactly once")
                s = pat.sub(lambda m: m.group(1) + str(v), s)
        open(params, "w", newline="").write(s.replace("\n", "\r\n") if crlf else s)
        print(f"written {params}")

if __name__ == "__main__":
    main(sys.argv[1:])
