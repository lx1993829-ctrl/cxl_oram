#!/usr/bin/env python3
"""golden_from_logs.py OUT REG.out... -- write sim/golden_bucket_digests.txt from regression outputs of THIS package.

run_verilator.sh prints, after its checks, one line per kernel/ni run that wrote buckets and did not halt:
    "  DIGEST <lambda> <beats> <run> bucket writes: ..."
This collects them from any number of outputs (full runs or single groups, from any machine), checks that a run
seen more than once has the same digest every time, and writes the reference file in golden_digests.sh's format,
with this package as the reference (v11b: random direct placement changes every bucket, so the reference is the
package itself; later versions compare with it).
"""
import re, subprocess, sys, os

def main(a):
    if len(a) < 2: sys.exit(__doc__)
    out, logs = a[0], a[1:]
    here = os.path.dirname(os.path.abspath(__file__))
    params = open(os.path.join(here, "..", "rtl", "oram_params.vh")).read()
    rev = re.search(r'`define ORAM_PKG_REV "([^"]*)"', params).group(1)
    rtl = os.path.join(here, "..", "rtl")
    h = subprocess.run("cat *.v *.vh | tr -d '\\r' | sha256sum | cut -c1-16", shell=True, cwd=rtl, capture_output=True, text=True).stdout.strip()
    dig, src = {}, {}
    for p in logs:
        for line in open(p, errors="replace"):
            m = re.match(r"^  DIGEST (\d+) (\d+) (\S+) (bucket writes: .*)$", line.rstrip("\n"))
            if not m: continue
            key = (int(m.group(1)), int(m.group(2)), m.group(3)); d = m.group(4)
            if key in dig and dig[key] != d:
                sys.exit(f"golden_from_logs.py: {key} differs between {src[key]} and {p}")
            dig[key] = d; src.setdefault(key, p)
    with open(out, "w") as f:
        f.write("# Bucket-write digests of the reference RTL under this package's testbenches (sim/golden_from_logs.py).\n")
        f.write(f"# Reference: {rev}\n")
        f.write(f"# reference rtl/: {h} (sha256 of its .v and .vh files, concatenated in name order, carriage returns removed)\n")
        f.write("# Columns: lambda, block size in beats, run (build/run_<run>.log), the run's 'bucket writes:' line.\n")
        for (l, b, t) in sorted(dig):
            f.write(f"{l} {b} {t} {dig[(l, b, t)]}\n")
    per = {}
    for (l, b, t) in dig: per[(l, b)] = per.get((l, b), 0) + 1
    print(f"written {out}: {len(dig)} runs; per (lambda, beats): " + ", ".join(f"{l}/{b}: {n}" for (l, b), n in sorted(per.items())))

if __name__ == "__main__":
    main(sys.argv[1:])
