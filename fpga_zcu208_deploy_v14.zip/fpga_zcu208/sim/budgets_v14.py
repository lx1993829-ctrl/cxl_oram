#!/usr/bin/env python3
"""budgets_v14.py -- v14: DOMA's lambda = 7 on-package budgets (plaintext path), from calibration runs.

    python3 budgets_v14.py --show  PARAMS DIR [DIR ...]
    python3 budgets_v14.py --write PARAMS DIR [DIR ...]

Each DIR is one size's calibration tree (the cycle model's output DIR/sim/build/wc_adv.txt, from the directed worst
cases with every metadata read at 200 cycles; and DIR/sim/build/run_*.log, the directed and kernel runs with buckets
on package). Its block size is read from wc_adv.txt. Rules, per size b (beats per block), cycles at 300 MHz:

  derived_wb  = record wait + stash wait (both at their worst under the 200-cycle profile) + worst (B + C)
  derived_rel = the same + worst (B + C + Wb)                      (sim/worst_case.py, part 4)
  AR_WB_H     = max(derived_wb, measured write-back start) + 74      the early check, condition (1)
  AR_REL_H    = max(derived_rel + bp(b), measured release gate) + 74 the release time, condition (2)
  AR_DONE_H   = AR_REL_H + (AR_DONE_H - AR_REL_H as before)          the acknowledgement allowance, unchanged
  bp(b)       = ceil(0.05 (Z b + 2 bursts + 22)): the HBM bucket port taking the write-back 5% slower (the allowance
                v11g's AR_REL_H gave the HBM write); +74: the lambda = 7 margin (sim/budgets_l7.py)

Written into the ORAM_AR_{WB,REL,DONE}_H_L7_B<b> defines (selected by ORAM_C == 7). Lambda 6 is not calibrated for v14.
"""
import glob, math, re, sys

Z, MARGIN = 8, 74

def bursts(b): return math.ceil(Z * b * 32 / 4096)
def bp(b): return math.ceil(0.05 * (Z * b + 2 * bursts(b) + 22))

def measure(d):
    w = open(f"{d}/sim/build/wc_adv.txt").read()
    b = int(re.search(r"BEATS=(\d+)", w).group(1))
    if "RESULT: PASS" not in w: sys.exit(f"budgets_v14.py: the cycle model did not pass in {d}")
    dwb = int(re.search(r"on-package: derived write-back start after arrival = [0-9 +]+= (\d+)", w).group(1))
    drel = int(re.search(r"on-package: derived release gate after arrival = [0-9 +]+= (\d+)", w).group(1))
    mwb = mrel = 0; runs = 0
    for f in glob.glob(f"{d}/sim/build/run_*.log"):
        t = open(f, errors="replace").read()
        m = re.search(r"ar_max_wb_h=(\d+).*?ar_max_rel_h=(\d+)", t)
        if not m: continue
        if "ALL CHECKS PASSED" not in t and "data_errors=0, ct_overrun=0" not in t:
            sys.exit(f"budgets_v14.py: {f} did not pass")
        mwb, mrel, runs = max(mwb, int(m.group(1))), max(mrel, int(m.group(2))), runs + 1
    if mwb == 0 or mrel == 0: sys.exit(f"budgets_v14.py: no on-package measurement in {d}")
    return b, dict(dwb=dwb, drel=drel, mwb=mwb, mrel=mrel, runs=runs)

def get(s, name):
    m = re.search(r"^`define %s +(\d+)" % name, s, re.M)
    if not m: sys.exit(f"budgets_v14.py: {name} not found")
    return int(m.group(1))

def main(a):
    if len(a) < 3 or a[0] not in ("--show", "--write"): sys.exit(__doc__)
    params = a[1]
    raw = open(params, newline="").read(); crlf = "\r\n" in raw; s = raw.replace("\r\n", "\n")
    out = []
    for d in a[2:]:
        b, x = measure(d)
        wb = max(x["dwb"], x["mwb"]) + MARGIN
        rel = max(x["drel"] + bp(b), x["mrel"]) + MARGIN
        owb, orel, odone = get(s, f"ORAM_AR_WB_H_L7_B{b}"), get(s, f"ORAM_AR_REL_H_L7_B{b}"), get(s, f"ORAM_AR_DONE_H_L7_B{b}")
        done = rel + (odone - orel)
        out.append((b, wb, rel, done))
        print(f"{b*32:>5} B ({b:3d} beats): AR_WB_H = max(derived {x['dwb']}, measured {x['mwb']}) + {MARGIN} = {wb} (v11g {owb}); "
              f"AR_REL_H = max(derived {x['drel']} + {bp(b)}, measured {x['mrel']}) + {MARGIN} = {rel} (v11g {orel}, -{orel - rel}); "
              f"AR_DONE_H = {done} (v11g {odone}); {x['runs']} runs")
    if a[0] == "--write":
        for b, wb, rel, done in out:
            for k, v in (("AR_WB_H_L7", wb), ("AR_REL_H_L7", rel), ("AR_DONE_H_L7", done)):
                pat = re.compile(r"^(`define ORAM_%s_B%d +)\d+" % (k, b), re.M)
                if len(pat.findall(s)) != 1: sys.exit(f"budgets_v14.py: ORAM_{k}_B{b} not found exactly once")
                s = pat.sub(lambda m: m.group(1) + str(v), s)
        open(params, "w", newline="").write(s.replace("\n", "\r\n") if crlf else s)
        print(f"written {params}")

if __name__ == "__main__":
    main(sys.argv[1:])
