// tb_ivadv.v -- v14: the GCM core's IV advance (aes_gcm_2lane iv_advance) against real encryptions.
// Two instances see the same sequence of operations. Core A encrypts every one. Core B replaces a pseudo-random
// subset of the encryptions (the very first one after reset included, so the advance must also seed the LFSR) by an
// IV advance pulse, as the controller does for an on-package bucket. Every encryption that B does perform must give
// the same IV, ciphertext and tag as A's encryption at the same place in the sequence. A key change in the middle
// (with an advance as the first operation under the new key) checks the reseeding. Decryptions are interleaved on
// both cores (they never move the LFSR). Ends with "IVADV: ALL CHECKS PASSED".
`timescale 1ns/1ps
module tb_ivadv;
    reg clk = 1'b0, rst_n = 1'b0;
    always #2 clk = ~clk;
    reg [127:0] key = 128'h000102030405060708090a0b0c0d0e0f;
    reg  [1:0]   st = 0, enc = 0, dv = 0, dl = 0, adv = 0;
    reg  [95:0]  iv = 96'h0123456789abcdef01234567;
    reg  [255:0] din = 0;
    wire [255:0] dout [0:1]; wire dov [0:1], tv [0:1], tm [0:1], rdy [0:1], ir [0:1];
    wire [127:0] tag [0:1]; wire [95:0] ivo [0:1];
    genvar g;
    generate for (g = 0; g < 2; g = g + 1) begin : C
        aes_gcm_2lane u (
            .clk(clk), .rst_n(rst_n), .enable(1'b1), .start(st[g]), .encrypt(enc[g]), .key(key), .iv(iv), .iv_advance(adv[g]),
            .data_in(din), .data_mask(2'b11), .data_valid(dv[g]), .data_last(dl[g]),
            .data_out(dout[g]), .data_out_mask(), .data_out_valid(dov[g]), .data_out_last(),
            .tag_in(128'd0), .tag_out(tag[g]), .tag_valid(tv[g]), .tag_match(tm[g]),
            .ready(rdy[g]), .busy(), .input_ready(ir[g]), .iv_out(ivo[g]), .iv_updated(), .counter_overflow());
    end endgenerate
    reg [255:0] co [0:1]; reg [127:0] to [0:1]; reg [95:0] io [0:1];
    always @(posedge clk) begin
        if (dov[0]) co[0] <= dout[0]; if (dov[1]) co[1] <= dout[1];
        if (tv[0]) begin to[0] <= tag[0]; io[0] <= ivo[0]; end
        if (tv[1]) begin to[1] <= tag[1]; io[1] <= ivo[1]; end
    end
    // one operation on core c: a one-beat message (encrypt or decrypt), or an IV advance
    task op; input integer c; input integer e; input integer a; input [255:0] d; begin
        while (!rdy[c]) @(negedge clk);
        if (a) begin adv[c] = 1; @(negedge clk); adv[c] = 0; @(negedge clk); end
        else begin
            enc[c] = e; st[c] = 1; @(negedge clk); st[c] = 0;
            while (!ir[c]) @(negedge clk);
            din = d; dv[c] = 1; dl[c] = 1; @(negedge clk); dv[c] = 0; dl[c] = 0;
            while (!tv[c]) @(negedge clk);
            @(negedge clk);
        end
    end endtask
    function [31:0] xs32; input [31:0] x; reg [31:0] y; begin
        y = (x == 32'd0) ? 32'h2545F491 : x; y = y ^ (y << 13); y = y ^ (y >> 17); xs32 = y ^ (y << 5);
    end endfunction
    initial begin #4000000; $display("IVADV: TIMEOUT at operation %0d (rdy %0d/%0d ir %0d/%0d)", i, rdy[0], rdy[1], ir[0], ir[1]); $finish; end
    integer i, fails = 0, nenc = 0, nadv = 0, ndec = 0; reg [31:0] r = 32'h77; reg skip; reg [255:0] d;
    initial begin
        repeat (5) @(negedge clk); rst_n = 1; repeat (5) @(negedge clk);
        for (i = 0; i < 400; i = i + 1) begin
            if (i == 200) begin key = 128'hfedcba98765432100123456789abcdef; repeat (2) @(negedge clk); end
            r = xs32(r); d = {8{r}};
            // the first operation after reset and after the key change is an advance on B; otherwise one in three
            skip = (i == 0) || (i == 200) || (r[7:0] < 8'd85);
            if (r[9:8] == 2'd3 && i != 0 && i != 200) begin            // a decryption on both (never moves the LFSR)
                op(0, 0, 0, d); op(1, 0, 0, d); ndec = ndec + 1;
                if (co[0] !== co[1] || to[0] !== to[1]) begin fails = fails + 1; $display("FAIL decryption %0d differs", i); end
            end else begin
                op(0, 1, 0, d);                                       // A encrypts
                op(1, 1, skip, d);                                    // B encrypts or advances
                if (skip) nadv = nadv + 1;
                else begin
                    nenc = nenc + 1;
                    if (io[0] !== io[1] || co[0] !== co[1] || to[0] !== to[1]) begin
                        fails = fails + 1;
                        if (fails < 5) $display("FAIL op %0d: IV %h vs %h, tag %h vs %h", i, io[0], io[1], to[0], to[1]);
                    end
                end
            end
        end
        $display("IVADV: %0d encryptions compared, %0d replaced by an IV advance (first after reset and after a key change included), %0d decryptions; %0d mismatches",
                 nenc, nadv, ndec, fails);
        if (fails == 0 && nadv > 50 && nenc > 100) $display("IVADV: ALL CHECKS PASSED"); else $display("IVADV: FAILED");
        $finish;
    end
endmodule
