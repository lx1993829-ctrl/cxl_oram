#!/usr/bin/env python3
"""inspect_check.py -- v14: check the bucket memories after a kernel run (tb_doma_kernel +inspect=<file>).

    python3 inspect_check.py DUMP

For every bucket, its record's metadata (fill count, slot list) says which block sits at each filled position.
  on package (bucket < hbm):  every filled position holds the block's expected contents in plaintext
  off package:                the whole bucket (one GCM message, Z * BEATS beats) verifies under the IV and tag in the
                              record's second beat and decrypts to the expected contents at every filled position;
                              no position's ciphertext equals its plaintext
Blocks waiting in the stash are not in a bucket and are not checked here (the GETs check them).
Prints one summary line; exit status 0 if everything holds.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gcm2_ref import gcm

M128 = (1 << 128) - 1

def main(path):
    recs, data, exp = {}, {}, {}
    for line in open(path):
        f = line.split()
        if not f: continue
        if f[0] == "H":
            Z, BEATS, nb, hbm, n, SW, FW = map(int, f[1:8]); key = int(f[8], 16)
        elif f[0] == "R": recs[int(f[1])] = (int(f[2], 16), int(f[3], 16))
        elif f[0] == "D": data[int(f[1])] = [int(x, 16) for x in f[2:]]
        elif f[0] == "E": exp[int(f[1])] = [int(x, 16) for x in f[2:]]
    bad, nbk_on, nbk_off, nblk_on, nblk_off, empty_off = [], 0, 0, 0, 0, 0
    for b in range(nb):
        meta, ivtag = recs[b]
        fill = meta & ((1 << FW) - 1)
        slots = [(meta >> (FW + i * SW)) & ((1 << SW) - 1) for i in range(Z)]
        beats = data[b]
        if len(beats) != Z * BEATS: bad.append(f"bucket {b}: {len(beats)} beats dumped"); continue
        if fill > Z: bad.append(f"bucket {b}: fill {fill} > Z"); continue
        if b < hbm:
            nbk_on += 1
            for p in range(fill):
                s = slots[p]
                if s not in exp: bad.append(f"bucket {b} position {p}: slot {s} outside the ORAM"); continue
                if beats[p * BEATS:(p + 1) * BEATS] != exp[s]:
                    bad.append(f"on-package bucket {b} position {p} (slot {s}) is not the block in plaintext")
                nblk_on += 1
        else:
            nbk_off += 1
            iv, tag = ivtag & ((1 << 96) - 1), (ivtag >> 96) & M128
            ct = []
            for x in beats: ct += [x & M128, x >> 128]
            pt, t, _ = gcm(key, iv, ct, encrypt=False)
            if t != tag: bad.append(f"off-package bucket {b}: the tag does not verify"); continue
            if fill == 0: empty_off += 1
            for p in range(fill):
                s = slots[p]
                if s not in exp: bad.append(f"bucket {b} position {p}: slot {s} outside the ORAM"); continue
                got = [pt[2 * j] | (pt[2 * j + 1] << 128) for j in range(p * BEATS, (p + 1) * BEATS)]
                if got != exp[s]: bad.append(f"off-package bucket {b} position {p} (slot {s}) decrypts to other data")
                if beats[p * BEATS:(p + 1) * BEATS] == exp[s]: bad.append(f"off-package bucket {b} position {p} (slot {s}) holds plaintext")
                nblk_off += 1
    if bad:
        for x in bad[:10]: print("INSPECT FAIL: " + x)
        print(f"INSPECT: FAILED ({len(bad)} problems)")
        return 1
    print(f"INSPECT: PASS: {nbk_on} on-package buckets hold their {nblk_on} blocks in plaintext; {nbk_off} off-package "
          f"buckets ({empty_off} empty) verify under their IV and tag and decrypt to their {nblk_off} blocks, none in plaintext")
    return 0

if __name__ == "__main__":
    if len(sys.argv) != 2: sys.exit(__doc__)
    sys.exit(main(sys.argv[1]))
