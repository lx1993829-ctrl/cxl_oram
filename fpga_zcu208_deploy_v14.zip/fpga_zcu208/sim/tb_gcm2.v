// tb_gcm2.v -- the two-lane GCM core (aes_gcm_2lane.v) against the one-lane reference core (aes_gcm_pipelined.v,
// unchanged) and against an independent model (gcm2_ref.py: pure-Python AES-128-GCM and the IV LFSR).
// Run by run_verilator.sh (units / crypto groups); gcm2_ref.py writes the operation list gcm2_vec.hex first.
//
// Every operation of the list runs on BOTH cores, which see the same sequence of starts (so their IV LFSRs stay in
// step). Checked per operation: every output block, the tag, tag_match, iv_out and counter_overflow, against the
// model and between the cores. Sections (gcm2_ref.py): NIST CAVP encryption / decryption vectors (96-bit IV, no AAD,
// whole blocks; the FAIL vectors must give tag_match = 0), GCM spec test cases, random messages of 1 to 2,100
// blocks (2,049 included: a 32 KB bucket plus its length block) under changing keys, each decrypted crosswise (the
// new core's output by the old core and the old core's by the new), wrong tags (a flipped ciphertext or tag bit),
// a back-to-back group (each message started as soon as the core is ready, a beat on every cycle, key changes
// inside), the counter-overflow flag (two more instances of the new core whose counter starts at 0xFFFFFFF0 /
// 0xFFFFFFF1, so 0xFFFFFFFF falls in lane 1 / lane 0), and constant time. Some messages mix one-block beats into
// the two-block stream, some have idle cycles (both cores), to cover every chain rotation of the GHASH.
//
// Constant time: for every operation without idle cycles or one-block beats, the new core's cycles from start to
// tag_valid are recorded by (blocks, whether the key changed); each length must take one cycle count, whatever the
// data, key, IV or direction. The count is also compared with the formula 23 + beats (+ the key setup).
`timescale 1ns/1ps
module tb_gcm2;
    reg clk = 1'b0, rst_n = 1'b0;
    always #2 clk = ~clk;
    reg [63:0] cyc = 64'd0;
    always @(posedge clk) cyc <= cyc + 64'd1;

    localparam MAXW = 260000, MAXOP = 1024, MAXB = 120000;
    reg [127:0] vec [0:MAXW-1];
    // operations, parsed from the file
    integer op_core [0:MAXOP-1], op_fl [0:MAXOP-1], op_n [0:MAXOP-1], op_ref [0:MAXOP-1], op_sec [0:MAXOP-1],
            op_grp [0:MAXOP-1], op_in [0:MAXOP-1], op_exp [0:MAXOP-1];
    reg [127:0] op_key [0:MAXOP-1], op_tagin [0:MAXOP-1], op_etag [0:MAXOP-1];
    reg [95:0]  op_iv [0:MAXOP-1], op_eiv [0:MAXOP-1];
    // results
    reg [127:0] out1 [0:MAXB-1], out2 [0:MAXB-1];
    integer     ob1 [0:MAXOP-1], ob2 [0:MAXOP-1], cyc2 [0:MAXOP-1];
    reg [127:0] tag1 [0:MAXOP-1], tag2 [0:MAXOP-1];
    reg [95:0]  ivo1 [0:MAXOP-1], ivo2 [0:MAXOP-1];
    reg         mt1 [0:MAXOP-1], mt2 [0:MAXOP-1], ov1 [0:MAXOP-1], ov2 [0:MAXOP-1];

    reg [127:0] key = 128'd0;

    // ---------------- the one-lane reference core ----------------
    reg          s1 = 0, e1 = 0, v1 = 0, l1 = 0;
    reg  [95:0]  iv1 = 0;
    reg  [127:0] d1 = 0, ti1 = 0;
    wire [127:0] do1, to1; wire dov1, dol1, tv1, tm1, rdy1, bsy1, ir1, ivu1, ovf1; wire [95:0] ivout1;
    aes_gcm_pipelined u_old (
        .clk(clk), .rst_n(rst_n), .enable(1'b1), .start(s1), .encrypt(e1), .key(key), .iv(iv1),
        .data_in(d1), .data_valid(v1), .data_last(l1), .data_bytes_valid(4'd0),
        .data_out(do1), .data_out_valid(dov1), .data_out_last(dol1),
        .tag_in(ti1), .tag_out(to1), .tag_valid(tv1), .tag_match(tm1),
        .ready(rdy1), .busy(bsy1), .input_ready(ir1), .iv_out(ivout1), .iv_updated(ivu1), .counter_overflow(ovf1));

    // ---------------- the two-lane core: the instance under test and two counter-test instances ----------------
    reg  [1:0]   sel = 0;
    reg          s2 = 0, e2 = 0, v2 = 0, l2 = 0;
    reg  [1:0]   m2 = 0;
    reg  [95:0]  iv2 = 0;
    reg  [255:0] d2 = 0;
    reg  [127:0] ti2 = 0;
    wire [255:0] do2 [0:2]; wire [1:0] dom2 [0:2];
    wire         dov2 [0:2], dol2 [0:2], tv2 [0:2], tm2 [0:2], rdy2 [0:2], ir2 [0:2], ovf2 [0:2];
    wire [127:0] to2 [0:2]; wire [95:0] ivout2 [0:2];
    genvar g;
    generate for (g = 0; g < 3; g = g + 1) begin : L
        localparam [31:0] C0 = (g == 0) ? 32'd2 : (g == 1) ? 32'hFFFFFFF0 : 32'hFFFFFFF1;
        aes_gcm_2lane #(.CTR0(C0)) u (
            .clk(clk), .rst_n(rst_n), .enable(1'b1),
            .start(s2 && sel == g), .encrypt(e2), .key(key), .iv(iv2), .iv_advance(1'b0),
            .data_in(d2), .data_mask(m2), .data_valid(v2 && sel == g), .data_last(l2 && sel == g),
            .data_out(do2[g]), .data_out_mask(dom2[g]), .data_out_valid(dov2[g]), .data_out_last(dol2[g]),
            .tag_in(ti2), .tag_out(to2[g]), .tag_valid(tv2[g]), .tag_match(tm2[g]),
            .ready(rdy2[g]), .busy(), .input_ready(ir2[g]), .iv_out(ivout2[g]), .iv_updated(), .counter_overflow(ovf2[g]));
    end endgenerate

    // ---------------- collectors: outputs land at a running block index, tags are counted ----------------
    integer gi1 = 0, gi2 = 0, tc1 = 0, tc2 = 0;
    reg [127:0] tq1, tq2; reg [95:0] ivq1, ivq2; reg mq1, mq2, oq1, oq2;
    reg [63:0] t_start2 = 0, t_end2 = 0;
    integer last_mask_err = 0;
    always @(posedge clk) begin
        if (dov1) begin out1[gi1] <= do1; gi1 <= gi1 + 1; end
        if (tv1)  begin tq1 <= to1; mq1 <= tm1; ivq1 <= ivout1; oq1 <= ovf1; tc1 <= tc1 + 1; end
        if (dov2[sel]) begin
            out2[gi2] <= do2[sel][127:0];
            if (dom2[sel][1]) out2[gi2 + 1] <= do2[sel][255:128];
            else if (do2[sel][255:128] != 128'd0) last_mask_err = last_mask_err + 1;   // an empty lane reads zero
            gi2 <= gi2 + (dom2[sel][1] ? 2 : 1);
        end
        if (s2 && rdy2[sel]) t_start2 <= cyc;
        if (tv2[sel]) begin tq2 <= to2[sel]; mq2 <= tm2[sel]; ivq2 <= ivout2[sel]; oq2 <= ovf2[sel]; tc2 <= tc2 + 1; t_end2 <= cyc; end
    end

    // deterministic draws (xorshift32), for idle cycles, one-block beats and the unused lane's contents
    reg [31:0] rs = 32'h1234567;
    function [31:0] xs32; input [31:0] x; reg [31:0] y; begin
        y = (x == 32'd0) ? 32'h2545F491 : x; y = y ^ (y << 13); y = y ^ (y >> 17); xs32 = y ^ (y << 5);
    end endfunction
    task rnd; output [31:0] r; begin rs = xs32(rs); r = rs; end endtask

    function [127:0] in_blk1; input integer i; input integer b; begin       // input block b of op i, for the old core
        if (op_fl[i] & 8) in_blk1 = out2[ob2[op_ref[i]] + b];             // cross: the NEW core's output
        else              in_blk1 = vec[op_in[i] + b];
    end endfunction
    function [127:0] in_blk2; input integer i; input integer b; begin       // ... for the new core
        if (op_fl[i] & 8) in_blk2 = out1[ob1[op_ref[i]] + b];             // cross: the OLD core's output
        else              in_blk2 = vec[op_in[i] + b];
    end endfunction

    // ---------------- drivers (inputs change on the falling edge, the cores sample on the rising edge) ----------------
    task run2; input integer i;
        integer n, blk, two, t; reg [31:0] r, r2;
        begin
            sel = op_core[i]; n = op_n[i];
            while (!rdy2[sel]) @(negedge clk);
            if (key != op_key[i]) begin key = op_key[i]; @(negedge clk); end   // one cycle: the cores' registered key compare
            e2  = op_fl[i] & 1;
            iv2 = (op_fl[i] & 8) ? ivo1[op_ref[i]] : op_iv[i];
            ti2 = (op_fl[i] & 8) ? tag1[op_ref[i]] : op_tagin[i];
            ob2[i] = gi2; t = tc2;
            s2 = 1; @(negedge clk); s2 = 0;
            if (n == 0) begin
                while (!ir2[sel]) @(negedge clk);
                l2 = 1; v2 = 0; @(negedge clk); l2 = 0;
            end
            blk = 0;
            while (blk < n) begin
                rnd(r); rnd(r2);
                if (ir2[sel] && !((op_fl[i] & 32) && r[2:0] == 3'd0)) begin
                    two = (n - blk >= 2) && !((op_fl[i] & 16) && r2[1:0] == 2'd0);
                    d2[127:0]   = in_blk2(i, blk);
                    d2[255:128] = two ? in_blk2(i, blk + 1) : {r, r2, ~r, r2 ^ 32'h5A5A5A5A};   // an unused lane is ignored
                    m2 = {two[0], 1'b1}; v2 = 1; l2 = (blk + 1 + two == n);
                    blk = blk + 1 + two;
                end else begin v2 = 0; l2 = 0; end
                @(negedge clk);
            end
            v2 = 0; l2 = 0;
            while (tc2 == t) @(negedge clk);
            tag2[i] = tq2; mt2[i] = mq2; ivo2[i] = ivq2; ov2[i] = oq2; cyc2[i] = t_end2 - t_start2;
        end
    endtask
    task run1; input integer i;
        integer n, blk, t; reg [31:0] r;
        begin
            n = op_n[i];
            while (!rdy1) @(negedge clk);
            if (key != op_key[i]) begin key = op_key[i]; repeat (20) @(negedge clk); end   // the old core needs the schedule settled
            e1  = op_fl[i] & 1;
            iv1 = (op_fl[i] & 8) ? ivo2[op_ref[i]] : op_iv[i];
            ti1 = (op_fl[i] & 8) ? tag2[op_ref[i]] : op_tagin[i];
            ob1[i] = gi1; t = tc1;
            s1 = 1; @(negedge clk); s1 = 0;
            if (n == 0) begin
                while (!ir1) @(negedge clk);
                l1 = 1; v1 = 0; @(negedge clk); l1 = 0;
            end
            blk = 0;
            while (blk < n) begin
                rnd(r);
                if (ir1 && !((op_fl[i] & 32) && r[2:0] == 3'd0)) begin
                    d1 = in_blk1(i, blk); v1 = 1; l1 = (blk == n - 1); blk = blk + 1;
                end else begin v1 = 0; l1 = 0; end
                @(negedge clk);
            end
            v1 = 0; l1 = 0;
            while (tc1 == t) @(negedge clk);
            tag1[i] = tq1; mt1[i] = mq1; ivo1[i] = ivq1; ov1[i] = oq1;
        end
    endtask

    // ---------------- checks ----------------
    integer nops, p, i, j, b, bad, bad_x, sb [0:15], sn [0:15], nbad_ct, ct_n, gstart;
    integer ct_cyc [0:4209];                       // by 2*blocks + key setup; -1 = not seen
    integer ks_add, base_ok, tmin, tmax, nks, nct, k_idx;
    reg [127:0] w;
    task check; input integer i;
        integer e, k, nb; reg ok, okx;
        begin
            e = 0; nb = op_n[i];
            ok = 1; okx = 1;
            for (k = 0; k < nb; k = k + 1) begin
                if (out2[ob2[i] + k] !== vec[op_exp[i] + k]) ok = 0;
                if (op_core[i] == 0 && out1[ob1[i] + k] !== vec[op_exp[i] + k]) ok = 0;
                if (op_core[i] == 0 && out1[ob1[i] + k] !== out2[ob2[i] + k]) okx = 0;
            end
            if (tag2[i] !== op_etag[i] || ivo2[i] !== op_eiv[i] || mt2[i] !== ((op_fl[i] >> 2) & 1) || ov2[i] !== ((op_fl[i] >> 6) & 1)) ok = 0;
            if (op_core[i] == 0) begin
                if (tag1[i] !== op_etag[i] || ivo1[i] !== op_eiv[i] || mt1[i] !== ((op_fl[i] >> 2) & 1) || ov1[i] !== 1'b0) ok = 0;
                if (tag1[i] !== tag2[i] || ivo1[i] !== ivo2[i] || mt1[i] !== mt2[i]) okx = 0;
            end
            if (!ok || !okx) begin
                bad = bad + 1; if (!okx) bad_x = bad_x + 1;
                if (bad <= 8)
                    $display("MISMATCH op %0d (section %0d, core %0d, %s, %0d blocks, flags %02h): tag new %h old %h want %h; iv new %h old %h want %h; match new %0d old %0d; ovf %0d; first block new %h old %h want %h",
                             i, op_sec[i], op_core[i], (op_fl[i] & 1) ? "enc" : "dec", nb, op_fl[i], tag2[i], tag1[i], op_etag[i],
                             ivo2[i], ivo1[i], op_eiv[i], mt2[i], mt1[i], ov2[i],
                             nb ? out2[ob2[i]] : 128'd0, nb ? out1[ob1[i]] : 128'd0, nb ? vec[op_exp[i]] : 128'd0);
                sb[op_sec[i]] = sb[op_sec[i]] + 1;
            end
            sn[op_sec[i]] = sn[op_sec[i]] + 1;
        end
    endtask

    initial begin
        $readmemh("gcm2_vec.hex", vec);
        // parse
        p = 0; nops = 0;
        while (vec[p][127:120] == 8'hA5 && vec[p][119:112] != 8'hFF) begin
            w = vec[p];
            op_core[nops] = w[119:112]; op_fl[nops] = w[111:104]; op_n[nops] = w[103:88]; op_ref[nops] = w[87:72];
            op_sec[nops] = w[71:64]; op_grp[nops] = w[63:48];
            op_key[nops] = vec[p+1]; op_iv[nops] = vec[p+2][95:0]; op_tagin[nops] = vec[p+3];
            op_etag[nops] = vec[p+4]; op_eiv[nops] = vec[p+5][95:0];
            op_in[nops] = p + 6; op_exp[nops] = p + 6 + op_n[nops];
            p = p + 6 + 2 * op_n[nops]; nops = nops + 1;
        end
        if (vec[p][119:112] != 8'hFF) begin $display("GCM2: ERROR bad vector file at word %0d", p); $finish; end
        for (i = 0; i < 16; i = i + 1) begin sb[i] = 0; sn[i] = 0; end
        for (i = 0; i < 4210; i = i + 1) ct_cyc[i] = -1;
        bad = 0; bad_x = 0; nbad_ct = 0; nct = 0;
        repeat (5) @(negedge clk); rst_n = 1; repeat (3) @(negedge clk);
        // groups: run the group's operations on the new core back to back, then on the old core
        i = 0;
        while (i < nops) begin
            gstart = i; j = i;
            while (j < nops && op_grp[j] == op_grp[gstart]) j = j + 1;
            for (b = gstart; b < j; b = b + 1) run2(b);
            for (b = gstart; b < j; b = b + 1) if (op_core[b] == 0) run1(b);
            for (b = gstart; b < j; b = b + 1) check(b);
            i = j;
        end
        // constant time: one cycle count per (blocks, key setup), from operations with no idle cycles or one-block beats
        for (i = 0; i < nops; i = i + 1)
            if (op_core[i] == 0 && !(op_fl[i] & 48)) begin
                k_idx = 2 * op_n[i] + ((op_fl[i] >> 7) & 1);
                nct = nct + 1;
                if (ct_cyc[k_idx] < 0) ct_cyc[k_idx] = cyc2[i];
                else if (ct_cyc[k_idx] != cyc2[i]) begin
                    nbad_ct = nbad_ct + 1;
                    if (nbad_ct < 5) $display("CONSTANT TIME: op %0d, %0d blocks: %0d cycles, earlier %0d", i, op_n[i], cyc2[i], ct_cyc[k_idx]);
                end
            end
        // the formula: 23 + beats without a key change (an empty message counts one beat), + KS with one
        ks_add = -1; base_ok = 1; ct_n = 0; nks = 0;
        for (i = 0; i < 2101; i = i + 1) begin
            if (ct_cyc[2*i] >= 0) begin
                ct_n = ct_n + 1;
                if (ct_cyc[2*i] != 23 + ((i == 0) ? 1 : (i + 1) / 2)) begin
                    base_ok = 0; $display("CONSTANT TIME: %0d blocks take %0d cycles, formula %0d", i, ct_cyc[2*i], 23 + ((i == 0) ? 1 : (i + 1) / 2));
                end
            end
            if (ct_cyc[2*i+1] >= 0 && ct_cyc[2*i] >= 0) begin
                nks = nks + 1;
                if (ks_add < 0) ks_add = ct_cyc[2*i+1] - ct_cyc[2*i];
                else if (ct_cyc[2*i+1] - ct_cyc[2*i] != ks_add) begin base_ok = 0; $display("CONSTANT TIME: key setup differs at %0d blocks", i); end
            end
        end
        for (i = 1; i <= 9; i = i + 1)
            $display("  section %0d: %0d operations, %0d mismatches", i, sn[i], sb[i]);
        $display("GCM2: %0d operations (%0d on the old/new pair), outputs compared block by block; new vs old differences: %0d",
                 nops, nops - sn[8], bad_x);
        $display("GCM2: constant time: %0d timed operations, %0d lengths, every length one cycle count: %0s; start to tag = 23 + beats: %0s; key setup adds %0d cycles (same at %0d lengths)",
                 nct, ct_n, nbad_ct == 0 ? "yes" : "NO", base_ok ? "yes" : "NO", ks_add, nks);
        $display("GCM2: empty-lane outputs not zero: %0d", last_mask_err);
        if (bad == 0 && nbad_ct == 0 && base_ok && last_mask_err == 0 && nops > 300) $display("GCM2: ALL CHECKS PASSED");
        else $display("GCM2: FAILED (%0d mismatching operations, %0d timing differences)", bad, nbad_ct);
        $finish;
    end
    initial begin #2000000000; $display("GCM2: ERROR timeout"); $finish; end
endmodule
