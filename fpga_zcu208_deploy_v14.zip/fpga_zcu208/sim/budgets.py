#!/usr/bin/env python3
"""budgets.py -- DOMA's arrival-mode timing budgets for every block size (Z = 8), from its calibration runs.

    python3 budgets.py --placeholders PARAMS 1 2 ...    # arrival budgets of these sizes -> the 4 KB values (calibration)
    python3 budgets.py --write PARAMS CALDIR 1 2 ...     # compute these sizes from CALDIR and write them into PARAMS
    python3 budgets.py --show CALDIR 1 2 ...             # compute and print only

CALDIR holds, per size b (BEATS): worst_case_<b>.txt (the worst group's build/worst_case.txt) and ar_<b>.txt (every
"ar_max_wb=.. ar_max_wb_h=.." report of the arrival, combined and hostwait runs). Used by calibrate_sizes.sh.

Rules (cycles at 300 MHz; Z = 8; bursts = 4 KB bursts of a bucket):
  derived_arr = verification left at the last beat + stash wait + worst (B+C+D) + Ec   (worst group, gap-free trace)
  AR_WB     = max(derived_arr, measured host worst) + 54
  AR_WB_H   = max(derived_arr + 32 + 54, measured HBM worst (adverse and combined runs) + 42 + 32)   # +32: the stash
  AR_REL    = AR_WB + the host release allowance as before (32 B 36, 4 KB 1,248, else ceil(1.2 (8 b + 2 bursts + 22)))
  AR_REL_H  = AR_WB_H + max(36, ceil(1.05 (8 b + 2 bursts + 22)))
  AR_DONE   = AR_WB + the acknowledgement allowance as before (32 B 148, 4 KB 1,620, linear in b between)
  AR_DONE_H = AR_WB_H + its allowance as before (32 B 44, 4 KB 1,550, linear in b between)
  Strict budgets (CT_WB, CT_DONE): unchanged at every size (v11a). The strict derivation below (HBM read worst 307,
  gap-free delivery after the first position) held while verification was crypto-bound; with the two-lane core it is
  memory-bound, and the self-test's slower memory (worst_case.py checks it) and the kernel's 30% host-read gaps no
  longer fit the derived values. Keeping the existing strict budgets keeps every strict-mode check as before.
"""
import math, re, sys

Z, PM_LAT, MARGIN, STASH, ADV = 8, 250, 54, 32, 42
AR = ["AR_WB", "AR_DONE", "AR_WB_H", "AR_DONE_H", "AR_REL", "AR_REL_H"]
KINDS = ["CT_WB", "CT_DONE"] + AR
NAME = {1: "32 B", 2: "64 B", 4: "128 B", 8: "256 B", 16: "512 B", 32: "1 KB", 64: "2 KB", 128: "4 KB"}
PLACEHOLDER = dict(AR_WB=4795, AR_DONE=6415, AR_WB_H=4795, AR_DONE_H=6345, AR_REL=6043, AR_REL_H=6043)


def interp(b, at1, at128):
    return round(at1 + (at128 - at1) * (b - 1) / 127)


def bursts(b):
    return math.ceil(Z * b * 32 / 4096)


def rel_host(b):
    return {1: 36, 128: 1248}.get(b, math.ceil(1.2 * (Z * b + 2 * bursts(b) + 22)))


def rel_hbm(b):   # 5% over the hand-off, handshakes included (+22, as in the host rule), never below 36
    return max(36, math.ceil(1.05 * (Z * b + 2 * bursts(b) + 22)))


def inputs(b, caldir):
    w = open(f"{caldir}/worst_case_{b}.txt").read()
    sec = w.split("timing_worst.csv")[1].split("timing_selftest.csv")[0]
    m = re.search(r"derived after arrival = [0-9 +]+= (\d+)", sec)
    if not m:
        sys.exit(f"budgets.py: no 'derived after arrival' in {caldir}/worst_case_{b}.txt (needs the t_ln trace)")
    darr = int(m.group(1))
    rest = int(re.search(r"rest of verification \d+\.\.(\d+)", sec).group(1))
    wait = int(re.search(r"stash wait \d+\.\.(\d+)", sec).group(1))
    bcd = int(re.search(r"B\+C\+D = (\d+)", w).group(1))
    ec = int(re.search(r"encryption Ec: (\d+)", w).group(1))
    ar = ar_h = 0
    for mm in re.finditer(r"ar_max_wb=(\d+) ar_max_wb_h=(\d+)", open(f"{caldir}/ar_{b}.txt").read()):
        ar, ar_h = max(ar, int(mm.group(1))), max(ar_h, int(mm.group(2)))
    if ar == 0 or ar_h == 0:
        sys.exit(f"budgets.py: missing host or HBM measurements for {b} beats in {caldir}/ar_{b}.txt")
    return dict(darr=darr, rest=rest, wait=wait, bcd=bcd, ec=ec, ar=ar, ar_h=ar_h)


def budgets(b, x, old_ct=None):
    ar_wb = max(x["darr"], x["ar"]) + MARGIN
    ar_wb_h = max(x["darr"] + STASH + MARGIN, x["ar_h"] + ADV + STASH)
    r = dict(AR_WB=ar_wb, AR_DONE=ar_wb + {1: 148, 128: 1620}.get(b, interp(b, 148, 1620)),
             AR_WB_H=ar_wb_h, AR_DONE_H=ar_wb_h + {1: 44, 128: 1550}.get(b, interp(b, 44, 1550)),
             AR_REL=ar_wb + rel_host(b), AR_REL_H=ar_wb_h + rel_hbm(b))
    if old_ct:                                   # strict budgets unchanged (every size, v11a)
        r.update(old_ct)
    else:
        strict = 267 + 307 + x["rest"] + x["wait"] + x["bcd"] + x["ec"]
        r["CT_WB"] = strict + MARGIN - PM_LAT - (Z - 1) * b
        r["CT_DONE"] = r["CT_WB"] + interp(b, 100, 1744)
    return r


def read(params):
    raw = open(params, newline="").read()
    return raw, "\r\n" in raw, raw.replace("\r\n", "\n")


def write_file(params, s, crlf):
    open(params, "w", newline="").write(s.replace("\n", "\r\n") if crlf else s)


def set_define(s, kind, b, value, comment):
    pat = re.compile(r"^`define ORAM_%s_B%d +\d+[^\n]*$" % (kind, b), re.M)
    if len(pat.findall(s)) != 1:
        sys.exit(f"budgets.py: ORAM_{kind}_B{b} not found exactly once")
    return pat.sub(lambda _: f"`define ORAM_{kind}_B{b}".ljust(30) + f"{value}" + (f"    // {comment}" if comment else ""), s)


def old_ct(s, b):
    return {k: int(re.search(r"^`define ORAM_%s_B%d +(\d+)" % (k, b), s, re.M).group(1)) for k in ("CT_WB", "CT_DONE")}


def placeholders(params, sizes):
    raw, crlf, s = read(params)
    for b in sizes:
        for k in AR:
            s = set_define(s, k, b, PLACEHOLDER[k], "CALIBRATION PLACEHOLDER (the 4 KB value): replaced by budgets.py --write")
    write_file(params, s, crlf)
    print(f"arrival budgets of {', '.join(NAME[b] for b in sizes)} set to the 4 KB placeholders")


def write(params, caldir, sizes):
    raw, crlf, s = read(params)
    for b in sizes:
        x = inputs(b, caldir)
        r = budgets(b, x, old_ct(s, b))           # strict budgets unchanged at every size (see above)
        note = (f"recalibrated: derived after the last beat {x['darr']}, measured host {x['ar']}, "
                f"HBM (adverse, combined) {x['ar_h']} (sim/budgets.py)")
        for k in AR:
            s = set_define(s, k, b, r[k], note if k == "AR_WB" else "")
        print(f"{NAME[b]:>5} ({b:3d} beats): " + "  ".join(f"{k}={r[k]}" for k in KINDS)
              + f"   [derived after arrival {x['darr']}, host {x['ar']}, HBM {x['ar_h']}]")
    write_file(params, s, crlf)
    print(f"written {params}")


def show(caldir, sizes):
    for b in sizes:
        x = inputs(b, caldir)
        r = budgets(b, x, {"CT_WB": -1, "CT_DONE": -1})
        print(f"{NAME[b]:>5} ({b:3d} beats): " + "  ".join(f"{k}={r[k]}" for k in AR)
              + f"   [derived after arrival {x['darr']}, host {x['ar']}, HBM {x['ar_h']}]")


if __name__ == "__main__":
    a = sys.argv[1:]
    if a[:1] == ["--placeholders"] and len(a) > 2:
        placeholders(a[1], [int(v) for v in a[2:]])
    elif a[:1] == ["--write"] and len(a) > 3:
        write(a[1], a[2], [int(v) for v in a[3:]])
    elif a[:1] == ["--show"] and len(a) > 2:
        show(a[1], [int(v) for v in a[2:]])
    else:
        sys.exit(__doc__)
