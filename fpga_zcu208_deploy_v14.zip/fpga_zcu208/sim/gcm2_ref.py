#!/usr/bin/env python3
"""gcm2_ref.py -- independent AES-128-GCM reference for the two-lane core tests (tb_gcm2.v, tb_ghash6.v).

Pure Python (no packages): AES-128 (FIPS-197), GHASH (NIST SP 800-38D, Algorithm 1), GCM with a selectable first
counter, and a model of the cores' IV selection (the 96-bit LFSR of aes_gcm_pipelined.v: seeded with the given IV
on the first encryption after reset or a key change, advanced 96 steps after every encryption).

  python3 gcm2_ref.py gcm   gcm_nist_vectors.txt  gcm2_vec.hex     # tb_gcm2 operation list
  python3 gcm2_ref.py ghash6 ghash6_vec.hex                       # tb_ghash6 messages

Self-checks before writing anything: FIPS-197 Appendix C.1, GCM test cases 2 and 3 (McGrew-Viega), and every NIST
CAVP vector in gcm_nist_vectors.txt (encryption: ciphertext and tag; decryption: plaintext, and failure exactly
where the file says FAIL). If the 'cryptography' package happens to be installed, random messages are also checked
against it (optional; nothing depends on it). Random draws use a fixed seed: the output is identical on every run.
"""
import sys, random

# ---------------------------------------------------------------- AES-128 (FIPS-197), encryption only
SBOX = [0] * 256
def _init_sbox():
    p = q = 1
    while True:                                     # p runs over GF(2^8)*, q = p^-1
        p = p ^ ((p << 1) & 0xFF) ^ (0x1B if p & 0x80 else 0)
        q ^= q << 1; q ^= q << 2; q ^= q << 4; q &= 0xFF
        if q & 0x80: q ^= 0x09
        x = q ^ ((q << 1) | (q >> 7)) ^ ((q << 2) | (q >> 6)) ^ ((q << 3) | (q >> 5)) ^ ((q << 4) | (q >> 4))
        SBOX[p] = (x ^ 0x63) & 0xFF
        if p == 1: break
    SBOX[0] = 0x63
_init_sbox()
def xt(b): return ((b << 1) ^ 0x1B) & 0xFF if b & 0x80 else b << 1
# T-tables: column (s0,s1,s2,s3) after SubBytes+MixColumns as one 32-bit word per input byte position
T0 = [0] * 256; T1 = [0] * 256; T2 = [0] * 256; T3 = [0] * 256
for _x in range(256):
    s = SBOX[_x]; s2 = xt(s); s3 = s2 ^ s
    T0[_x] = (s2 << 24) | (s << 16) | (s << 8) | s3
    T1[_x] = (s3 << 24) | (s2 << 16) | (s << 8) | s
    T2[_x] = (s << 24) | (s3 << 16) | (s2 << 8) | s
    T3[_x] = (s << 24) | (s << 16) | (s3 << 8) | s2
RCON = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1B, 0x36]

def key_expand(key):                                 # key: 128-bit int -> 44 words
    w = [(key >> (96 - 32 * i)) & 0xFFFFFFFF for i in range(4)]
    for i in range(4, 44):
        t = w[i - 1]
        if i % 4 == 0:
            t = ((t << 8) | (t >> 24)) & 0xFFFFFFFF
            t = (SBOX[t >> 24] << 24) | (SBOX[(t >> 16) & 255] << 16) | (SBOX[(t >> 8) & 255] << 8) | SBOX[t & 255]
            t ^= RCON[i // 4 - 1] << 24
        w.append(w[i - 4] ^ t)
    return w

def aes_enc(w, blk):                                 # one block: 128-bit int -> 128-bit int
    s0 = ((blk >> 96) & 0xFFFFFFFF) ^ w[0]; s1 = ((blk >> 64) & 0xFFFFFFFF) ^ w[1]
    s2 = ((blk >> 32) & 0xFFFFFFFF) ^ w[2]; s3 = (blk & 0xFFFFFFFF) ^ w[3]
    for r in range(1, 10):
        k = 4 * r
        t0 = T0[s0 >> 24] ^ T1[(s1 >> 16) & 255] ^ T2[(s2 >> 8) & 255] ^ T3[s3 & 255] ^ w[k]
        t1 = T0[s1 >> 24] ^ T1[(s2 >> 16) & 255] ^ T2[(s3 >> 8) & 255] ^ T3[s0 & 255] ^ w[k + 1]
        t2 = T0[s2 >> 24] ^ T1[(s3 >> 16) & 255] ^ T2[(s0 >> 8) & 255] ^ T3[s1 & 255] ^ w[k + 2]
        t3 = T0[s3 >> 24] ^ T1[(s0 >> 16) & 255] ^ T2[(s1 >> 8) & 255] ^ T3[s2 & 255] ^ w[k + 3]
        s0, s1, s2, s3 = t0, t1, t2, t3
    def fin(a, b, c, d, kw):
        return ((SBOX[a >> 24] << 24) | (SBOX[(b >> 16) & 255] << 16) | (SBOX[(c >> 8) & 255] << 8) | SBOX[d & 255]) ^ kw
    return (fin(s0, s1, s2, s3, w[40]) << 96) | (fin(s1, s2, s3, s0, w[41]) << 64) | \
           (fin(s2, s3, s0, s1, w[42]) << 32) | fin(s3, s0, s1, s2, w[43])

# ---------------------------------------------------------------- GHASH (SP 800-38D Algorithm 1) and GCM
R = 0xE1 << 120
def gmul(X, Y):                                      # bit 0 of a block = MSB
    Z, V = 0, Y
    for i in range(127, -1, -1):
        if (X >> i) & 1: Z ^= V
        V = (V >> 1) ^ R if V & 1 else V >> 1
    return Z
class GHashTable:                                    # 8-bit table for a fixed H (fast, checked against gmul)
    def __init__(self, H):
        self.H = H
        self.t = [[0] * 256 for _ in range(16)]
        for pos in range(16):                        # byte pos (0 = most significant) times H
            for b in range(256):
                self.t[pos][b] = gmul(b << (8 * (15 - pos)), H) if b else 0
    def mul(self, X):
        z = 0
        for pos in range(16):
            z ^= self.t[pos][(X >> (8 * (15 - pos))) & 255]
        return z
def ghash(gt, blocks):
    y = 0
    for x in blocks: y = gt.mul(y ^ x)
    return y

M128 = (1 << 128) - 1
def gcm(key, iv, data, encrypt=True, ctr0=2, gt_cache={}):
    """data: list of 128-bit ints. Returns (out blocks, tag, overflow). No AAD."""
    w = key_expand(key)
    if key not in gt_cache: gt_cache.clear(); gt_cache[key] = GHashTable(aes_enc(w, 0))
    gt = gt_cache[key]
    out, ovf = [], False
    for i, x in enumerate(data):
        c = (ctr0 + i) & 0xFFFFFFFF
        if c == 0xFFFFFFFF: ovf = True
        out.append(x ^ aes_enc(w, (iv << 32) | c))
    ct = out if encrypt else data
    tag = ghash(gt, ct + [128 * len(data)]) ^ aes_enc(w, (iv << 32) | 1)   # length block: len(A)=0 || len(C)
    return out, tag, ovf

# ---------------------------------------------------------------- the cores' IV selection
def lfsr96(s):
    for _ in range(96):
        fb = ((s >> 95) ^ (s >> 9) ^ (s >> 8) ^ (s >> 5)) & 1
        s = ((s << 1) | fb) & ((1 << 96) - 1)
    return s
class CoreModel:
    """IV choice of aes_gcm_pipelined / aes_gcm_2lane for a sequence of starts (and the 2-lane key setup)."""
    def __init__(self): self.last_key, self.seeded, self.lfsr, self.hpow = 0, False, 0, False
    def start(self, key, iv, encrypt):
        key_changed = (key != self.last_key)       # the cores' registered compare (key stable >= 1 cycle)
        keysetup = key_changed or not self.hpow
        if not encrypt: use = iv
        elif not self.seeded or key_changed:
            use = iv if iv != 0 else int("A5" * 12, 16); self.lfsr = use; self.seeded = True
        else: use = self.lfsr
        self.last_key, self.hpow = key, True
        return use, keysetup
    def done(self, encrypt):
        if encrypt: self.lfsr = lfsr96(self.lfsr)

def hexblocks(s): return [int(s[i:i + 32], 16) for i in range(0, len(s), 32)] if s != '-' else []

def self_checks(nist_path):
    w = key_expand(0x000102030405060708090a0b0c0d0e0f)          # FIPS-197 C.1
    assert aes_enc(w, 0x00112233445566778899aabbccddeeff) == 0x69c4e0d86a7b0430d8cdb78070b4c55a
    for t in range(200):                                           # table GHASH = Algorithm 1
        H, X = random.getrandbits(128), random.getrandbits(128)
        assert GHashTable(H).mul(X) == gmul(X, H)
    o, t, _ = gcm(0, 0, [0])                                       # GCM test case 2
    assert o == [0x0388dace60b6a392f328c2b971b2fe78] and t == 0xab6e47d42cec13bdf53a67b21257bddf
    k3, iv3 = 0xfeffe9928665731c6d6a8f9467308308, 0xcafebabefacedbaddecaf888   # test case 3
    p3 = hexblocks("d9313225f88406e5a55909c5aff5269a86a7a9531534f7da2e4c303d8a318a72"
                   "1c3c0c95956809532fcf0e2449a6b525b16aedf5aa0de657ba637b391aafd255")
    o, t, _ = gcm(k3, iv3, p3)
    assert o == hexblocks("42831ec2217774244b7221b784d0d49ce3aa212f2c02a4e035c17e2329aca12e"
                          "21d514b25466931c7d8f6a5aac84aa051ba30b396a0aac973d58e091473f5985")
    assert t == 0x4d5c2af327cd64a62cf35abd2ba6fab4
    vecs = []
    for line in open(nist_path):
        if line.startswith('#') or not line.strip(): continue
        f = line.split()
        v = dict(enc=(f[0] == 'E'), key=int(f[1], 16), iv=int(f[2], 16), pt=hexblocks(f[3]), ct=hexblocks(f[4]),
                 tag=int(f[5], 16), fail=(len(f) > 6 and f[6] == 'FAIL'))
        if v['enc']:
            o, t, _ = gcm(v['key'], v['iv'], v['pt'])
            assert o == v['ct'] and t == v['tag'], "NIST encryption vector"
        else:
            o, t, _ = gcm(v['key'], v['iv'], v['ct'], encrypt=False)
            assert (t != v['tag']) == v['fail'], "NIST decryption vector (authentication)"
            if not v['fail']: assert o == v['pt'], "NIST decryption vector (plaintext)"
        vecs.append(v)
    try:                                                           # optional: an unrelated implementation
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        for _ in range(40):
            k, iv, n = random.getrandbits(128), random.getrandbits(96), random.randint(0, 40)
            pt = [random.getrandbits(128) for _ in range(n)]
            o, t, _ = gcm(k, iv, pt)
            r = AESGCM(k.to_bytes(16, 'big')).encrypt(iv.to_bytes(12, 'big'), b''.join(x.to_bytes(16, 'big') for x in pt), None)
            assert r == b''.join(x.to_bytes(16, 'big') for x in o) + t.to_bytes(16, 'big')
        extra = "; random messages also match the 'cryptography' package"
    except ImportError:
        extra = ""
    print("reference: FIPS-197 C.1, GCM test cases 2-3 and %d NIST CAVP vectors (%d encrypt, %d decrypt, %d FAIL) match%s"
          % (len(vecs), sum(v['enc'] for v in vecs), sum(not v['enc'] for v in vecs), sum(v['fail'] for v in vecs), extra))
    return vecs

# ---------------------------------------------------------------- tb_gcm2 operation list
# Header word (128 bits): [127:120] 0xA5, [119:112] core (0 = the old/new pair, 1 = new core with CTR0 = 0xFFFFFFF0,
# 2 = new core with CTR0 = 0xFFFFFFF1, 0xFF = end), [111:104] flags, [103:88] blocks, [87:72] reference op (cross),
# [71:64] section, [63:48] group, [47:0] op index.
# flags: 0 encrypt, 1 change key first, 2 expect tag_match, 3 cross (input = the OTHER core's output of the reference
# op), 4 mixed (random one-block beats inside the message), 5 gaps (random idle cycles), 6 expect counter_overflow,
# 7 expect the 2-lane key setup.
# Then: key, iv, tag_in, expected tag, expected iv_out, n input blocks, n expected output blocks.
SECTIONS = {1: "NIST CAVP encrypt", 2: "NIST CAVP decrypt", 3: "GCM spec test cases", 4: "random, new vs old",
            5: "cross decryption", 6: "wrong tag", 7: "back-to-back", 8: "counter overflow", 9: "constant time"}

def gen_gcm(nist_path, out_path):
    random.seed(20261027)
    vecs = self_checks(nist_path)
    models = {0: CoreModel(), 1: CoreModel(), 2: CoreModel()}
    ctr0s = {0: 2, 1: 0xFFFFFFF0, 2: 0xFFFFFFF1}
    ops = []; cur_key = {'k': None}          # the TB drives one key for all cores: changing it is an event
    gid = [0]
    def add(core, enc, key, iv, data, section, tag_in=0, flip=None, cross=None, mixed=False, gaps=False, group=None,
            expect_match=True):
        newkey = (key != cur_key['k']); cur_key['k'] = key
        m = models[core]
        use_iv, ks = m.start(key, iv, enc)
        if cross is not None:
            ref = ops[cross]; data = ref['exp']; use_iv = ref['exp_iv']; tag_in = ref['exp_tag']   # (the TB uses the other core's values)
        src = list(data)
        if flip is not None and flip[0] == 'data': src[flip[1]] ^= 1 << flip[2]
        if flip is not None and flip[0] == 'tag': tag_in ^= 1 << flip[2]
        out, tag, ovf = gcm(key, use_iv, src, encrypt=enc, ctr0=ctr0s[core])
        match = True if enc else (tag == tag_in)
        assert match == expect_match, (section, enc, flip)
        m.done(enc)
        if group is None: gid[0] += 1; g = gid[0]
        else: g = group
        ops.append(dict(core=core, enc=enc, newkey=newkey, match=match, cross=cross, mixed=mixed, gaps=gaps, ovf=ovf,
                        ks=ks, n=len(src), section=section, group=g, key=key, iv=iv, tag_in=tag_in, exp_tag=tag,
                        exp_iv=use_iv, src=src if cross is None else [0] * len(src), exp=out))
        return len(ops) - 1
    # 1-2. NIST CAVP: a new key per vector, so an encryption seeds the LFSR with the vector's IV and uses it as is
    for v in vecs:
        if v['enc']: add(0, True, v['key'], v['iv'], v['pt'], 1)
    for v in vecs:
        if not v['enc']: add(0, False, v['key'], v['iv'], v['ct'], 2, tag_in=v['tag'], expect_match=not v['fail'])
    # 3. GCM spec test cases 2 and 3 (decryption: test case 2's IV is 0, which an encryption would replace by the
    #    LFSR's non-zero seed), and test case 3 as an encryption
    add(0, False, 0, 0, [0x0388dace60b6a392f328c2b971b2fe78], 3, tag_in=0xab6e47d42cec13bdf53a67b21257bddf)
    k3, iv3 = 0xfeffe9928665731c6d6a8f9467308308, 0xcafebabefacedbaddecaf888
    c3 = hexblocks("42831ec2217774244b7221b784d0d49ce3aa212f2c02a4e035c17e2329aca12e"
                   "21d514b25466931c7d8f6a5aac84aa051ba30b396a0aac973d58e091473f5985")
    add(0, False, k3, iv3, c3, 3, tag_in=0x4d5c2af327cd64a62cf35abd2ba6fab4)
    add(0, True, k3 ^ 1, iv3, [random.getrandbits(128) for _ in range(4)], 3)        # (key change: seeds with iv3)
    # 4-5. random messages, 1 to 2,100 blocks (2,049 = a 32 KB bucket + length block; 2,048, 2,050, odd and even),
    #      several messages per key (the LFSR's IVs), each followed by its cross decryption
    lens = [1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 31, 64, 127, 255, 256, 257, 1023, 1024, 1025, 2047, 2048, 2049, 2050,
            2099, 2100] + [random.randint(1, 2100) for _ in range(13)]
    random.shuffle(lens)
    key = random.getrandbits(128)
    for i, n in enumerate(lens):
        if i % 4 == 0: key = random.getrandbits(128)
        iv = random.getrandbits(96)
        e = add(0, True, key, iv, [random.getrandbits(128) for _ in range(n)], 4, mixed=(i % 5 == 3), gaps=(i % 7 == 5))
        add(0, False, key, 0, None, 5, cross=e, mixed=(i % 6 == 2))
    # a key change followed by a decryption first: the decryption records the new key, so the next encryption does
    # NOT re-seed and continues the LFSR (the old core's behaviour, kept)
    key = random.getrandbits(128)
    add(0, False, key, random.getrandbits(96), [random.getrandbits(128) for _ in range(5)], 4, tag_in=0, expect_match=False)
    add(0, True, key, random.getrandbits(96), [random.getrandbits(128) for _ in range(9)], 4)
    # 6. wrong tags: one flipped bit in the ciphertext or in the tag -> tag_match = 0
    for i in range(12):
        n = random.choice([1, 2, 3, 16, 129, 2049])
        e = add(0, True, key, 0, [random.getrandbits(128) for _ in range(n)], 6)
        ref = ops[e]
        if i % 2 == 0:
            add(0, False, key, ref['exp_iv'], ref['exp'], 6, tag_in=ref['exp_tag'],
                flip=('data', random.randrange(n), random.randrange(128)), expect_match=False)
        else:
            add(0, False, key, ref['exp_iv'], ref['exp'], 6, tag_in=ref['exp_tag'],
                flip=('tag', 0, random.randrange(128)), expect_match=False)
    # 7. back-to-back: one group, started as soon as the core is ready, beats on every cycle, key changes inside
    gid[0] += 1; g = gid[0]
    key = random.getrandbits(128)
    for i in range(24):
        if i in (9, 18): key = random.getrandbits(128)      # (an encryption: decryptions use their message's key)
        n = random.choice([1, 2, 3, 4, 7, 8, 33, 64, 200, 2049])
        if i % 3 == 2:
            ref = ops[-1]
            add(0, False, key, ref['exp_iv'], ref['exp'] if ref['enc'] else ref['src'], 7, tag_in=ref['exp_tag'] if ref['enc'] else 0,
                group=g, expect_match=ref['enc'])
        else:
            add(0, True, key, random.getrandbits(96), [random.getrandbits(128) for _ in range(n)], 7, group=g)
    # 8. counter overflow: the counter-test instances start at 0xFFFFFFF0 (0xFFFFFFFF in lane 1 of beat 7) and
    #    0xFFFFFFF1 (lane 0 of beat 7); flagged exactly when a block uses 0xFFFFFFFF, the keystream wraps to 0
    key = random.getrandbits(128)
    for core, ns in ((1, (15, 16, 17, 20, 2)), (2, (14, 15, 16, 30, 3))):
        for n in ns:
            e = add(core, True, key, random.getrandbits(96), [random.getrandbits(128) for _ in range(n)], 8)
            add(core, False, key, ops[e]['exp_iv'], ops[e]['exp'], 8, tag_in=ops[e]['exp_tag'])
    # 9. constant time: the same lengths with all-zero, all-one and random data, different keys and IVs, both directions
    for n in (0, 1, 2, 3, 6, 7, 64, 129, 2049):
        for variant in range(4):
            key = random.getrandbits(128) if variant != 1 else (0 if n % 2 else M128)
            fill = [0] * n if variant == 1 else ([M128] * n if variant == 2 else [random.getrandbits(128) for _ in range(n)])
            e = add(0, True, key, random.getrandbits(96), fill, 9)
            add(0, False, key, ops[e]['exp_iv'], ops[e]['exp'], 9, tag_in=ops[e]['exp_tag'])
            add(0, True, key, random.getrandbits(96), fill[::-1], 9)          # same key: no key setup
    # ---- write
    with open(out_path, "w") as f:
        def wr(x): f.write("%032x\n" % (x & M128))
        for i, o in enumerate(ops):
            fl = (o['enc'] << 0) | (o['newkey'] << 1) | (o['match'] << 2) | ((o['cross'] is not None) << 3) | \
                 (o['mixed'] << 4) | (o['gaps'] << 5) | (o['ovf'] << 6) | (o['ks'] << 7)
            wr((0xA5 << 120) | (o['core'] << 112) | (fl << 104) | (o['n'] << 88) | ((o['cross'] or 0) << 72) |
               (o['section'] << 64) | (o['group'] << 48) | i)
            for x in (o['key'], o['iv'], o['tag_in'], o['exp_tag'], o['exp_iv']): wr(x)
            for x in o['src']: wr(x)
            for x in o['exp']: wr(x)
        wr((0xA5 << 120) | (0xFF << 112))
    nb = sum(o['n'] for o in ops)
    print("tb_gcm2 operations: %d (%d blocks), sections: %s" % (len(ops), nb,
          ", ".join("%s %d" % (SECTIONS[s], sum(o['section'] == s for o in ops)) for s in sorted(SECTIONS))))

# ---------------------------------------------------------------- tb_ghash6 messages
def gen_ghash6(out_path):
    random.seed(6)
    words = []
    for m in range(300):
        H = random.getrandbits(128) | 1
        n = random.choice([1, 2, 3, 4, 5, 6, 7, 8, 11, 12, 13]) if m < 200 else random.randint(50, 400)
        blocks = [random.getrandbits(128) for _ in range(n)]
        hp = [H]
        for _ in range(5): hp.append(gmul(hp[-1], H))
        y = 0
        for x in blocks: y = gmul(y ^ x, H)
        words += [n] + hp + [y] + blocks
    with open(out_path, "w") as f:
        for w in words: f.write("%032x\n" % w)
    print("ghash6 messages: 300, words:", len(words))

if __name__ == "__main__":
    if len(sys.argv) >= 4 and sys.argv[1] == "gcm": gen_gcm(sys.argv[2], sys.argv[3])
    elif len(sys.argv) >= 3 and sys.argv[1] == "ghash6": gen_ghash6(sys.argv[2])
    else: sys.exit(__doc__)
