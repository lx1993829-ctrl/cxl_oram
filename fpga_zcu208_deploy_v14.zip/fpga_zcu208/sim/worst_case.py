#!/usr/bin/env python3
"""Derive the worst case the ORAM timing gates must cover, from per-access traces.

Usage:  python3 worst_case.py [--params ../rtl/oram_params.vh] TRACE.csv [TRACE2.csv ...]

Traces come from oram_timing_monitor.v (+timing_log=<file>): one line per access,
with cycles counted from the start of the access.

1. Each access is cut into segments at fixed milestones:
     L0 = t_l0   - t_rd     first position landed after the read was issued (memory)
     A  = t_scan - t_l0     rest of verification (crypto-bound while memory keeps up)
     W  = t_op   - t_scan   wait for the stash (its lists and blocks come from HBM; memory)
     B  = t_evict- t_op     operation phase: lookup, copies, compaction, map update
     C  = t_ea   - t_evict  eviction decisions
     D  = t_ea0  - t_ea     wait before encrypting position 0 (its eviction copy)
     Ec = t_e    - t_ea0    encryption of all positions
2. The cycle model: every on-chip segment is a function of the path features only
     B by (path, copies);  C by evictions;  D by (position 0 gets an eviction, evictions);  Ec constant
   and the structural rules of the controller hold (copies, fill, eviction count).
   Any key with two different values, or any broken rule, is reported: the model
   would then not explain the measured timing, and no bound is claimed.
3. Every feature combination the controller allows is enumerated. Per trace file
   (i.e. per memory model) the bound on the encryption end is
     max(t_rd) + max(L0) + max(A) + max(W) + max over combinations of (B + C + D) + Ec
   (W overlaps verification in reality -- the stash is fetched from the position lookup on -- so adding its
   maximum to A's is conservative)
   and is compared with the deadline CT_WB + 7*BEATS, when the write-back needs the
   last position. The worst combination is also reported, and whether a traced access
   actually reached it.
4. v14, on-package (plaintext) accesses (trace column byp = 1; arrival builds). Cut at
     Ab = t_scan - t_ln   the record's arrival after the bucket's last beat (memory)
     W  = t_op   - t_scan  the stash wait (memory)
     B, C                   as above (on chip)
     Wb = t_dg   - t_ea    write-back: issued at S_EA_START, streaming behind the eviction copies, until the
                            release gate is reached (its last beat handed off); on chip with a gap-free bucket port
   Wb must be a function of (position 0 gets an eviction, evictions), as D above, and B and C of their keys.
   Per trace file:
     derived write-back start after the arrival = max(Ab) + max(W) + max over combinations of (B + C)
     derived release gate after the arrival     = max(Ab) + max(W) + max over combinations of (B + C + Wb)
   (AR_WB_H and AR_REL_H, sim/budgets_l7.py), compared with the observed t_ea - t_ln and t_dg - t_ln.
"""
import csv, re, sys, os
from collections import defaultdict

def param(text, name):
    m = re.search(r"`define\s+%s\s+(\d+)" % name, text)
    if not m: sys.exit(f"cannot find {name} in parameter file")
    return int(m.group(1))

def path_of(r):
    if r["dummy"]: return "dummy"
    kind = "write" if r["op"] else "read"
    where = "bucket" if r["fib"] else ("stash" if r["fis"] else "new")
    return f"{kind}_{where}"

def main(argv):
    params = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "rtl", "oram_params.vh")
    if len(argv) > 2 and argv[1] == "--params": params, argv = argv[2], [argv[0]] + argv[3:]
    files = argv[1:]
    if not files: sys.exit(__doc__)
    ptxt = open(params).read()
    Z = param(ptxt, "ORAM_Z")
    BEATS = int(os.environ.get("ORAM_BEATS", "128"))   # block size in beats (run_verilator.sh exports it)
    sz = BEATS if re.search(r"`define\s+ORAM_CT_WB_B%d\s" % BEATS, ptxt) else 128   # per-size budgets
    PM = param(ptxt, "ORAM_PM_LAT")                       # position-map lookup budget (HBM)
    CT_RD = param(ptxt, "ORAM_CT_RD_BASE") + PM
    CT_WB, CT_DONE = param(ptxt, "ORAM_CT_WB_B%d" % sz) + PM, param(ptxt, "ORAM_CT_DONE_B%d" % sz) + PM
    deadline = CT_WB + (Z - 1) * BEATS
    recs, brecs = {}, {}
    for f in files:
        rows, brows = [], []
        with open(f) as fh:
            for r in csv.DictReader(fh):
                if None in r.values() or None in r: continue      # incomplete line (run still writing)
                r = {k: int(v) for k, v in r.items()}
                if r.get("byp", 0) == 1:                         # v14: on-package access, plaintext path (part 4)
                    if min(r[k] for k in ("t_scan","t_evict","t_ea","t_ln","t_dg")) >= 0:
                        r["path"] = path_of(r)
                        top = r["t_op"] if r.get("t_op", -1) >= 0 else r["t_scan"]
                        r.update(Ab=r["t_scan"]-r["t_ln"], W=top-r["t_scan"], B=r["t_evict"]-top, C=r["t_ea"]-r["t_evict"],
                                 Wb=r["t_dg"]-r["t_ea"], w=int(r["fill1"] == 0 and r["n_ev"] > 0))
                        brows.append(r)
                    continue
                if min(r[k] for k in ("t_rd","t_l0","t_scan","t_evict","t_ea","t_ea0","t_e")) < 0: continue
                r["path"] = path_of(r)
                top = r["t_op"] if r.get("t_op", -1) >= 0 else r["t_scan"]   # traces before the HBM stash: no wait
                r.update(L0=r["t_l0"]-r["t_rd"], A=r["t_scan"]-r["t_l0"], W=top-r["t_scan"], B=r["t_evict"]-top,
                         C=r["t_ea"]-r["t_evict"], D=r["t_ea0"]-r["t_ea"], Ec=r["t_e"]-r["t_ea0"])
                r["w"] = int(r["fill1"] == 0 and r["n_ev"] > 0)
                if r.get("t_ln", -1) >= 0:                       # arrival mode: work after the bucket's LAST beat
                    r["A_arr"], r["E_arr"] = r["t_scan"] - r["t_ln"], r["t_e"] - r["t_ln"]
                rows.append(r)
        recs[f] = rows; brecs[f] = brows
    allr = [r for rows in recs.values() for r in rows]
    allb = [r for rows in brecs.values() for r in rows]
    if not allr and allb:                                                     # on-package traces only
        print(f"accesses traced: {len(allb)} on package in {len(files)} file(s); Z={Z}, BEATS={BEATS}")
        return bypass_model(recs, brecs, allb, Z, BEATS, [])
    print(f"accesses traced: {len(allr)} in {len(files)} file(s); Z={Z}, BEATS={BEATS}; "
          f"gates CT_RD={CT_RD} CT_WB={CT_WB} CT_DONE={CT_DONE}; deadline CT_WB+{Z-1}*{BEATS} = {deadline}")
    problems = []
    # ---- structural rules of the controller ----
    base = {}
    for r in allr:
        # A dummy access performs no data operation (it goes straight to eviction),
        # whatever its lookup flags say: fill unchanged, no copies.
        hit = r["fib"] == 1 and not r["dummy"]
        if r["fill1"] != (r["fill0"] - 1 if hit else r["fill0"]):
            problems.append(f"fill rule broken: {r}")
        if r["n_ev"] > Z - r["fill1"]:
            problems.append(f"more evictions than free positions: {r}")
        comp = int(hit and r["pos"] != r["fill0"] - 1)
        b = r["n_cp"] - comp
        if base.setdefault(r["path"], b) != b:
            problems.append(f"copy rule broken on {r['path']}: copies={r['n_cp']} compaction={comp}")
    # ---- on-chip segments must be functions of their keys ----
    def table(keyf, seg):
        t = defaultdict(set)
        for r in allr: t[keyf(r)].add(r[seg])
        for k, v in t.items():
            if len(v) > 1: problems.append(f"segment {seg} not determined by {k}: values {sorted(v)}")
        return {k: max(v) for k, v in t.items()}
    TB = table(lambda r: (r["path"], r["n_cp"]), "B")
    TC = table(lambda r: r["n_ev"], "C")
    TD = table(lambda r: (r["w"], r["n_ev"] if r["w"] else None), "D")
    TE = table(lambda r: 0, "Ec")
    print("\nCycle model (on-chip segments, cycles):")
    print("  operation phase B by (path, copies): " + ", ".join(f"{p}/{c}={v}" for (p, c), v in sorted(TB.items())))
    print("  eviction decisions C by evictions:   " + ", ".join(f"{n}={v}" for n, v in sorted(TC.items())))
    print("  wait D, position 0 evicted into:     " + ", ".join(f"{n}={v}" for (w, n), v in sorted(TD.items(), key=lambda kv: (kv[0][0], kv[0][1] or 0)) if w)
          + f";  otherwise {TD.get((0, None), '?')}")
    print(f"  encryption Ec: {TE.get(0, '?')}")
    # ---- enumerate every combination the controller allows ----
    paths = sorted(base)
    best, missing = None, set()
    for p in paths:
        hitp = p.endswith("_bucket")
        for fill0 in (range(1, Z + 1) if hitp else range(0, Z + 1)):
            for comp in ((0, 1) if hitp and fill0 >= 2 else (0,)):
                ncp = base[p] + comp
                fill1 = fill0 - 1 if hitp else fill0
                for nev in range(0, Z - fill1 + 1):
                    w = int(fill1 == 0 and nev > 0)
                    kb, kd = (p, ncp), (w, nev if w else None)
                    if kb not in TB: missing.add(f"B{kb}"); continue
                    if nev not in TC: missing.add(f"C[{nev}]"); continue
                    if kd not in TD: missing.add(f"D{kd}"); continue
                    v = TB[kb] + TC[nev] + TD[kd]
                    if best is None or v > best[0]:
                        best = (v, dict(path=p, fill_before=fill0, compaction=comp, copies=ncp, evictions=nev, waits_for_copy=w))
    if missing: problems.append("combinations never measured (model incomplete): " + ", ".join(sorted(missing)))
    print("\nWorst on-chip combination: " + (f"{best[1]}  B+C+D = {best[0]} cycles" if best else "none"))
    ok = not problems and best is not None
    for f, rows in recs.items():
        if not rows: continue
        L0, A, W = max(r["L0"] for r in rows), max(r["A"] for r in rows), max(r["W"] for r in rows)
        # the budgets must hold on the real memory, not just the testbench model: L0 is at least the
        # measured worst-case read latency (MEM_L0_MAX, set by run_verilator.sh from the U55C measurement)
        L0 = max(L0, int(os.environ.get("MEM_L0_MAX", "0")))
        trd = max(r["t_rd"] for r in rows)
        bound = trd + L0 + A + W + best[0] + TE[0] if best else None
        obs = max(r["t_e"] for r in rows)
        hit = [r for r in rows if best and r["path"] == best[1]["path"] and r["n_cp"] == best[1]["copies"]
               and r["n_ev"] == best[1]["evictions"] and r["w"] == best[1]["waits_for_copy"]]
        wmax = max((r["t_w"] for r in rows if r["t_w"] >= 0), default=-1)
        print(f"\n{os.path.basename(f)}: {len(rows)} accesses")
        print(f"  memory: read issued at {trd}; first position landed {min(r['L0'] for r in rows)}..{L0} cycles later; "
              f"rest of verification {min(r['A'] for r in rows)}..{A}; stash wait {min(r['W'] for r in rows)}..{W}")
        if bound is not None:
            print(f"  derived worst encryption end = {trd} + {L0} + {A} + {W} + {best[0]} + {TE[0]} = {bound}")
            print(f"  observed worst encryption end = {obs}  (worst combination reached by {len(hit)} traced access(es))")
            print(f"  deadline {deadline}: margin {deadline - bound} cycles")
            if bound > deadline: ok = False; problems.append(f"{os.path.basename(f)}: bound {bound} exceeds deadline {deadline}")
            if obs > bound: ok = False; problems.append(f"{os.path.basename(f)}: an access ({obs}) exceeded the derived bound ({bound})")
        arr = [r for r in rows if "A_arr" in r]
        if arr and best:
            # Arrival budgets count from the last beat. The bound uses the verification still left at the last beat
            # (A_arr), not the verification from position 0 (A), which would also count positions 1..Z-1 arriving.
            # Gap-free delivery leaves the most work after the last beat; this trace must be gap-free (worst group).
            Aarr, Earr = max(r["A_arr"] for r in arr), max(r["E_arr"] for r in arr)
            darr = Aarr + W + best[0] + TE[0]
            print(f"  after the last beat: verification {min(r['A_arr'] for r in arr)}..{Aarr}; "
                  f"derived after arrival = {Aarr} + {W} + {best[0]} + {TE[0]} = {darr}; observed {Earr}")
            if Earr > darr: ok = False; problems.append(f"{os.path.basename(f)}: work after the last beat ({Earr}) exceeded the derived bound ({darr})")
        print(f"  write-back done at most {wmax} (completion gate {CT_DONE}, margin {CT_DONE - wmax}; memory-dependent)")
        if wmax > CT_DONE: ok = False; problems.append(f"{os.path.basename(f)}: write-back done {wmax} after CT_DONE {CT_DONE}")
    if allb:                                         # v14: the on-package path, then one verdict for both
        return bypass_model(recs, brecs, allb, Z, BEATS, problems, ok)
    print()
    for pr in problems[:20]: print("  PROBLEM: " + pr)
    print("RESULT: " + ("PASS (cycle model explains every access; derived worst case fits the budget)" if ok else "FAIL"))
    return 0 if ok else 1

def bypass_model(recs, brecs, allb, Z, BEATS, problems, ok=True):
    """v14, part 4 of the docstring: on-package accesses (plaintext, no crypto)."""
    print(f"\nOn-package (plaintext) accesses traced: {len(allb)}")
    base = {}
    for r in allb:
        hit = r["fib"] == 1 and not r["dummy"]
        if r["fill1"] != (r["fill0"] - 1 if hit else r["fill0"]): problems.append(f"on-package: fill rule broken: {r}")
        if r["n_ev"] > Z - r["fill1"]: problems.append(f"on-package: more evictions than free positions: {r}")
        comp = int(hit and r["pos"] != r["fill0"] - 1)
        b = r["n_cp"] - comp
        if base.setdefault(r["path"], b) != b:
            problems.append(f"on-package: copy rule broken on {r['path']}: copies={r['n_cp']} compaction={comp}")
    def table(keyf, seg):
        t = defaultdict(set)
        for r in allb: t[keyf(r)].add(r[seg])
        for k, v in t.items():
            if len(v) > 1: problems.append(f"on-package: segment {seg} not determined by {k}: values {sorted(v)}")
        return {k: max(v) for k, v in t.items()}
    TB = table(lambda r: (r["path"], r["n_cp"]), "B")
    TC = table(lambda r: r["n_ev"], "C")
    TW = table(lambda r: (r["w"], r["n_ev"] if r["w"] else None), "Wb")
    print("Cycle model, on-package path (on-chip segments, cycles):")
    print("  operation phase B by (path, copies): " + ", ".join(f"{p}/{c}={v}" for (p, c), v in sorted(TB.items())))
    print("  eviction decisions C by evictions:   " + ", ".join(f"{n}={v}" for n, v in sorted(TC.items())))
    print("  write-back Wb, position 0 evicted into: " + ", ".join(f"{n}={v}" for (w, n), v in sorted(TW.items(), key=lambda kv: (kv[0][0], kv[0][1] or 0)) if w)
          + f";  otherwise {TW.get((0, None), '?')}")
    best_d = best_r = None; missing = set()
    for p in sorted(base):
        hitp = p.endswith("_bucket")
        for fill0 in (range(1, Z + 1) if hitp else range(0, Z + 1)):
            for comp in ((0, 1) if hitp and fill0 >= 2 else (0,)):
                ncp = base[p] + comp
                fill1 = fill0 - 1 if hitp else fill0
                for nev in range(0, Z - fill1 + 1):
                    w = int(fill1 == 0 and nev > 0)
                    kb, kw = (p, ncp), (w, nev if w else None)
                    if kb not in TB: missing.add(f"B{kb}"); continue
                    if nev not in TC: missing.add(f"C[{nev}]"); continue
                    if kw not in TW: missing.add(f"Wb{kw}"); continue
                    c = dict(path=p, fill_before=fill0, compaction=comp, copies=ncp, evictions=nev, waits_for_copy=w)
                    d, rl = TB[kb] + TC[nev], TB[kb] + TC[nev] + TW[kw]
                    if best_d is None or d > best_d[0]: best_d = (d, c)
                    if best_r is None or rl > best_r[0]: best_r = (rl, c)
    if missing: problems.append("on-package: combinations never measured (model incomplete): " + ", ".join(sorted(missing)))
    print("Worst on-chip combination, decisions:   " + (f"{best_d[1]}  B+C = {best_d[0]} cycles" if best_d else "none"))
    print("Worst on-chip combination, write-back:  " + (f"{best_r[1]}  B+C+Wb = {best_r[0]} cycles" if best_r else "none"))
    ok = ok and not problems and best_d is not None and best_r is not None
    for f, rows in brecs.items():
        if not rows or best_d is None or best_r is None: continue
        Ab, W = max(r["Ab"] for r in rows), max(r["W"] for r in rows)
        dwb, drel = Ab + W + best_d[0], Ab + W + best_r[0]
        owb, orel = max(r["t_ea"] - r["t_ln"] for r in rows), max(r["t_dg"] - r["t_ln"] for r in rows)
        print(f"\n{os.path.basename(f)}: {len(rows)} on-package accesses")
        print(f"  memory: record after the last beat {min(r['Ab'] for r in rows)}..{Ab}; stash wait {min(r['W'] for r in rows)}..{W}")
        print(f"  on-package: derived write-back start after arrival = {Ab} + {W} + {best_d[0]} = {dwb}; observed {owb}")
        print(f"  on-package: derived release gate after arrival = {Ab} + {W} + {best_r[0]} = {drel}; observed {orel}")
        if owb > dwb: ok = False; problems.append(f"{os.path.basename(f)}: on-package write-back start ({owb}) after the derived bound ({dwb})")
        if orel > drel: ok = False; problems.append(f"{os.path.basename(f)}: on-package release gate ({orel}) after the derived bound ({drel})")
    print()
    for pr in problems[:20]: print("  PROBLEM: " + pr)
    print("RESULT: " + ("PASS (cycle model explains every access; derived worst case fits the budget)" if ok else "FAIL"))
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main(sys.argv))
