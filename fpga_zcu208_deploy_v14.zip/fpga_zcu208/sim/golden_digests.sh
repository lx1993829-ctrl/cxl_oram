#!/bin/bash
# golden_digests.sh -- the reference for the end-to-end check: digests of every bucket write of the kernel and ni
# runs, from a reference package's RTL under THIS package's testbenches and stimulus. run_verilator.sh compares every
# run that has a reference with it, so every bucket written must stay bit-identical to the reference's.
# v11a's reference was v10e (the two-lane core left every bucket unchanged). v11b's random direct placement changes
# where every block starts, so its reference is v11b itself: the check then guards later changes against it.
#   bash sim/golden_digests.sh [reference package (fpga_zcu208); default: this package]   # all sizes, lambda 6 and 7
#   SIZES="1 128" LAMBDAS="6" bash sim/golden_digests.sh /path/to/reference/fpga_zcu208
# Output: sim/golden_bucket_digests.txt, one line per run: <lambda> <beats> <run> bucket writes: ... A run that halts
# (the budget-overrun and undersized-pool tests) gets no line: where it stops depends on timing, which may differ.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"; REF="$(cd "${1:-$HERE/..}" && pwd)"
[ -f "$REF/rtl/flat_oram_gcm.v" ] && [ -f "$REF/rtl/oram_params.vh" ] || { echo "not a DOMA package: $REF"; exit 2; }
REFREV=$(grep -E '^`define ORAM_PKG_REV' "$REF/rtl/oram_params.vh" | sed -E 's/.*"(.*)".*/\1/')
SIZES=${SIZES:-"1 2 4 8 16 32 64 128"}; LAMBDAS=${LAMBDAS:-"6 7"}
OUT="$HERE/golden_bucket_digests.txt"; TMP=$(mktemp -d "${TMPDIR:-/tmp}/golden_XXXX")
# the reference's own rtl/ and sim/ (its scripts and file list), with this package's testbenches and their monitors
cp -r "$REF/rtl" "$TMP/rtl" && cp -r "$REF/sim" "$TMP/sim" && rm -rf "$TMP/sim/build" "$TMP/sim/calib" \
    && cp "$HERE/tb_ni.v" "$HERE/tb_doma_kernel.v" "$HERE/oram_timing_monitor.v" "$TMP/sim/" || exit 2
{
    echo "# Bucket-write digests of the reference RTL under this package's testbenches (sim/golden_digests.sh)."
    echo "# Reference: $REFREV"
    echo "# reference rtl/: $(cd "$REF/rtl" && cat *.v *.vh | sha256sum | cut -c1-16) (sha256 of its .v and .vh files, concatenated in name order)"
    echo "# Columns: lambda, block size in beats, run (build/run_<run>.log), the run's 'bucket writes:' line."
} > "$OUT.new"
# keep the lines of other sizes / lambdas from an earlier run (the script can run size by size)
[ -f "$OUT" ] && grep -v "^#" "$OUT" | while read -r l b rest; do
    case " $LAMBDAS " in *" $l "*) case " $SIZES " in *" $b "*) continue ;; esac ;; esac
    echo "$l $b $rest"
done >> "$OUT.new"
for L in $LAMBDAS; do
    for b in $SIZES; do
        s=$(date +%s)
        ( cd "$TMP/sim" && rm -rf build && ORAM_LAMBDA=$L ORAM_BEATS=$b bash run_verilator.sh kernel > reg_kernel.out 2>&1;
          ORAM_LAMBDA=$L ORAM_BEATS=$b bash run_verilator.sh ni > reg_ni.out 2>&1 )
        n=0
        for f in "$TMP"/sim/build/run_*.log; do
            t=$(basename "$f" .log); t=${t#run_}
            d=$(grep -a "^bucket writes:" "$f" | tail -1)
            [ -n "$d" ] || continue
            grep -aq "DOMA HALT" "$f" && continue
            echo "$L $b $t $d" >> "$OUT.new"; n=$((n + 1))
        done
        echo "lambda $L, $b beats: $n runs, $(( ($(date +%s) - s) / 60 )) min ($(grep -c "^  PASS" "$TMP/sim/reg_kernel.out") + $(grep -c "^  PASS" "$TMP/sim/reg_ni.out") checks passed on the reference)"
    done
done
{ grep "^#" "$OUT.new"; grep -v "^#" "$OUT.new" | sort -k1,1n -k2,2n -k3,3; } > "$OUT"; rm -f "$OUT.new"; rm -rf "$TMP"
echo "written: $OUT"
