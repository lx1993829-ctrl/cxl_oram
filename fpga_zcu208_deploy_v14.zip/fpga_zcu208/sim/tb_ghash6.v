// tb_ghash6.v -- ghash_lane6 against the Python reference (gcm2_ref.py ghash6 -> ghash6_vec.hex).
// Each message is fed as a random mix of two-block and one-block beats (every chain rotation), +gaps=1 also with
// random idle cycles. 300 messages of 1 to 400 blocks, each with its own H (H^1..H^6 from the reference).
`timescale 1ns/1ps
module tb_ghash6;
    reg clk = 0, rst_n = 0; always #1 clk = ~clk;
    reg start = 0, dv = 0, last = 0;
    reg [1:0] mask = 0;
    reg [127:0] h [1:6];
    reg [255:0] din = 0;
    wire [127:0] gout; wire gval, rdy;
    ghash_lane6 dut (.clk(clk), .rst_n(rst_n), .enable(1'b1), .start(start),
                     .h1_key(h[1]), .h2_key(h[2]), .h3_key(h[3]), .h4_key(h[4]), .h5_key(h[5]), .h6_key(h[6]),
                     .data_in(din), .data_mask(mask), .data_valid(dv), .last(last),
                     .ghash_out(gout), .ghash_valid(gval), .ready(rdy));
    reg [127:0] mem [0:40000];
    integer p, m, n, i, k, bad, msgs, cnt, gaps, ones, twos;
    reg [31:0] rs;
    reg [127:0] exp;
    initial begin
        $readmemh("ghash6_vec.hex", mem);
        if (!$value$plusargs("gaps=%d", gaps)) gaps = 1;
        rs = 32'hC0FFEE11; ones = 0; twos = 0;
        for (k = 1; k <= 6; k = k + 1) h[k] = 0;
        repeat (4) @(posedge clk); rst_n = 1; @(negedge clk);
        p = 0; bad = 0; msgs = 0;
        for (m = 0; m < 300; m = m + 1) begin
            n = mem[p]; for (k = 1; k <= 6; k = k + 1) h[k] = mem[p + k]; exp = mem[p + 7]; p = p + 8;
            start = 1; @(negedge clk); start = 0;
            i = 0;
            while (i < n) begin
                rs = rs ^ (rs << 13); rs = rs ^ (rs >> 17); rs = rs ^ (rs << 5);
                if (gaps && rs[2:0] == 3'd0) begin dv = 0; @(negedge clk); end
                else begin
                    if (n - i >= 2 && rs[4:3] != 2'd0) begin
                        din = {mem[p + i + 1], mem[p + i]}; mask = 2'b11; i = i + 2; twos = twos + 1;
                    end else begin
                        din = {~mem[p + i], mem[p + i]}; mask = 2'b01; i = i + 1; ones = ones + 1;   // the unused lane is ignored
                    end
                    dv = 1; last = (i == n); @(negedge clk); dv = 0; last = 0;
                end
            end
            p = p + n;
            cnt = 0; while (!gval && cnt < 1000) begin @(negedge clk); cnt = cnt + 1; end
            if (gout !== exp) begin bad = bad + 1; if (bad < 4) $display("MISMATCH msg %0d (n=%0d): got %h want %h", m, n, gout, exp); end
            msgs = msgs + 1;
            @(negedge clk);
        end
        $display("GHASH6 unit vs reference: %0d messages (%0d two-block and %0d one-block beats), %0d mismatches (gaps=%0d) %s",
                 msgs, twos, ones, bad, gaps, bad == 0 ? "PASS" : "FAIL");
        $finish;
    end
endmodule
