// oram_timing_monitor.v -- simulation only.
// Writes one CSV line per access (enable with +timing_log=<file>): the cycle, counted
// from the start of the access, at which each segment of the work ends, plus the
// features that decide the path. sim/worst_case.py validates a cycle model against
// these traces and derives the worst case the timing gates must cover.
`timescale 1ns / 1ps
`include "oram_params.vh"
module oram_timing_monitor (
    input wire        clk,
    input wire [4:0]  state,
    input wire [31:0] ct_cnt,
    input wire        req_op,           // 1 = write
    input wire        found_in_bucket,
    input wire        found_in_stash,
    input wire [7:0]  found_pos,
    input wire [7:0]  bkt_fill_count,
    input wire [7:0]  fill,
    input wire [15:0] landed_beats,
    input wire [7:0]  enc_pos_done,
    input wire [1:0]  cr_mode,
    input wire [7:0]  cr_pos,
    input wire        write_done,
    input wire        fmt_done,
    input wire        byp               // v14: the access's bucket is on package (plaintext path)
);
    integer fd; reg [8*256-1:0] fname;
    reg [4:0] ps; reg [15:0] pl; reg [7:0] pe;
    integer t_rd, t_l0, t_ln, t_scan, t_op, t_evict, t_ea, t_ea0, t_e, t_w, n_cp, n_ev, t_dg, f_byp;
    integer f_dummy, f_op, f_fib, f_fis, f_fill0, f_pos, f_fill1, first_chk, in_acc;
    initial begin
        fd = 0; ps = 0; pl = 0; pe = 0; in_acc = 0;
        if ($value$plusargs("timing_log=%s", fname)) begin
            fd = $fopen(fname, "w");
            if (fd) $fdisplay(fd, "dummy,op,fib,fis,fill0,pos,fill1,n_cp,n_ev,t_rd,t_l0,t_scan,t_evict,t_ea,t_ea0,t_e,t_w,t_op,t_ln,byp,t_dg");
        end
    end
    always @(posedge clk) begin
        if (state == 5'd2 && ps != 5'd2) begin                  // access reached the read gate
            in_acc = 1; n_cp = 0; n_ev = 0; first_chk = 1;
            t_rd = -1; t_l0 = -1; t_ln = -1; t_scan = -1; t_op = -1; t_evict = -1; t_ea = -1; t_ea0 = -1; t_e = -1; t_w = -1;
            t_dg = -1; f_byp = 0;
        end
        if (in_acc) begin
            if (ps == 5'd2 && state != 5'd2) t_rd = ct_cnt;     // read issued
            if (pl < `BEATS_PER_BLOCK && landed_beats >= `BEATS_PER_BLOCK) t_l0 = ct_cnt;   // position 0 landed (any block size)
            if (pl < `ORAM_Z * `BEATS_PER_BLOCK && landed_beats >= `ORAM_Z * `BEATS_PER_BLOCK) t_ln = ct_cnt;   // last bucket beat landed: the arrival budgets start here
            if (state == 5'd10 && ps != 5'd10) t_scan = ct_cnt; // all positions verified
            if (state == 5'd11 && ps == 5'd10) t_op = ct_cnt;   // the stash is ready (S_SCAN waited for it)
            if (ps == 5'd10 && state != 5'd10) begin
                // no dummy accesses: the column stays in the trace format, always 0
                f_dummy = 0; f_op = req_op; f_fib = found_in_bucket; f_fis = found_in_stash;
                f_fill0 = bkt_fill_count; f_pos = found_pos; f_byp = byp;
            end
            if (state == 5'd23 && ps != 5'd23) t_dg = ct_cnt;   // v14: release gate reached (write handed off)
            if (state == 5'd12 && ps != 5'd12) n_cp = n_cp + 1; // operation-phase copy (S_CP)
            if (state == 5'd16 && ps != 5'd16) t_evict = ct_cnt;// operation done
            if (state == 5'd17 && ps != 5'd17 && first_chk) begin f_fill1 = fill; first_chk = 0; end
            if (state == 5'd18 && ps != 5'd18) n_ev = n_ev + 1; // eviction decided
            if (state == 5'd20 && ps != 5'd20) t_ea = ct_cnt;   // all decisions made
            if (state == 5'd6 && ps != 5'd6 && cr_mode == 2'd1 && cr_pos == 8'd0) t_ea0 = ct_cnt;
            if (enc_pos_done == `ORAM_Z && pe != `ORAM_Z) t_e = ct_cnt;           // all re-encrypted
            if (write_done && fmt_done) t_w = ct_cnt;           // write-back done
            if (state == 5'd0 && ps == 5'd24) begin             // access finished
                if (fd) $fdisplay(fd, "%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d",
                    f_dummy, f_op, f_fib, f_fis, f_fill0, f_pos, f_fill1, n_cp, n_ev,
                    t_rd, t_l0, t_scan, t_evict, t_ea, t_ea0, t_e, t_w, t_op, t_ln, f_byp, t_dg);
                in_acc = 0;
            end
        end
        ps <= state; pl <= landed_beats; pe <= enc_pos_done;
    end
endmodule

// bucket_write_digest -- simulation only. A digest of every beat written on a bucket port, in order (data and byte
// strobes), and of every write burst's address and length (FNV-1a over 64-bit words). Two runs that write the same
// buckets in the same order give the same digests whatever their timing: the regression compares the kernel and ni
// runs with v10e's (sim/golden_bucket_digests.txt, written by v10e's RTL under the same testbenches and stimulus).
module bucket_write_digest #(parameter DW = 256, AW = 64) (
    input  wire          clk,
    input  wire [AW-1:0] awaddr,
    input  wire [7:0]    awlen,
    input  wire          awvalid, awready,
    input  wire [DW-1:0] wdata,
    input  wire [DW/8-1:0] wstrb,
    input  wire          wvalid, wready,
    output reg  [63:0]   dig_w,          // data digest
    output reg  [63:0]   dig_a,          // address digest
    output reg  [31:0]   n_w,            // beats written
    output reg  [31:0]   n_a             // bursts
);
    function [63:0] fnv; input [63:0] h; input [63:0] x; begin fnv = (h ^ x) * 64'h00000100000001B3; end endfunction
    reg [63:0] h; integer k;
    initial begin dig_w = 64'hCBF29CE484222325; dig_a = 64'hCBF29CE484222325; n_w = 0; n_a = 0; end
    always @(posedge clk) begin
        if (wvalid && wready) begin
            h = dig_w;
            for (k = 0; k < DW / 64; k = k + 1) h = fnv(h, wdata[64*k +: 64]);
            dig_w <= fnv(h, wstrb);
            n_w <= n_w + 1;
        end
        if (awvalid && awready) begin dig_a <= fnv(dig_a, {awaddr, awlen}); n_a <= n_a + 1; end
    end
endmodule
