#!/usr/bin/env python3
"""layout_check.py LOG n B Z -- check DOMA's boot layout (random direct placement, v11b) from a testbench's
+layout_log dump: one line "slot bucket status" per position-map write of the layout (status 1: in the bucket,
2: in the stash, waiting for that bucket), in placement order.

Checks:
  * every slot 0..n-1 is placed exactly once, in a bucket 0..B-1;
  * for every bucket, the first Z slots placed there are in it and every later one is in the stash (status 2);
  * the per-bucket counts fit Binomial(n, 1/B): chi-square over count classes (classes merged until each expects
    at least 5 buckets), p > 0.001; and the stash's share is reported against its expectation B E[(X - Z)+].
Prints one summary line; exit 0 if every check passes.
"""
import math, sys

def binom_pmf(n, p, k):
    return math.exp(math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1) + k * math.log(p) + (n - k) * math.log1p(-p))

def gammq(a, x):   # regularized upper incomplete gamma Q(a, x) (Numerical Recipes: series / continued fraction)
    if x <= 0: return 1.0
    gln = math.lgamma(a)
    if x < a + 1:
        ap, s, d = a, 1.0 / a, 1.0 / a
        for _ in range(1000):
            ap += 1; d *= x / ap; s += d
            if abs(d) < abs(s) * 1e-15: break
        return 1.0 - s * math.exp(-x + a * math.log(x) - gln)
    b, c, d = x + 1 - a, 1e300, 1.0 / (x + 1 - a); h = d
    for i in range(1, 1000):
        an = -i * (i - a); b += 2
        d = an * d + b; d = 1e-300 if abs(d) < 1e-300 else d
        c = b + an / c; c = 1e-300 if abs(c) < 1e-300 else c
        d = 1.0 / d; de = d * c; h *= de
        if abs(de - 1) < 1e-15: break
    return math.exp(-x + a * math.log(x) - gln) * h

def main(a):
    if len(a) != 4: sys.exit(__doc__)
    path, n, B, Z = a[0], int(a[1]), int(a[2]), int(a[3])
    rows = []
    for line in open(path):
        if line.startswith("#") or not line.strip(): continue
        s, b, st = map(int, line.split())
        rows.append((s, b, st))
    errs = []
    seen = [0] * n
    count = [0] * B
    for s, b, st in rows:
        if not (0 <= s < n): errs.append(f"slot {s} out of range"); continue
        if not (0 <= b < B): errs.append(f"slot {s}: bucket {b} out of range"); continue
        seen[s] += 1
        want = 1 if count[b] < Z else 2
        if st != want: errs.append(f"slot {s}: bucket {b} holds {count[b]} already, status {st} (expected {want})")
        count[b] += 1
    missing = [s for s in range(n) if seen[s] == 0]; dup = [s for s in range(n) if seen[s] > 1]
    if missing: errs.append(f"{len(missing)} slots never placed (first {missing[:5]})")
    if dup: errs.append(f"{len(dup)} slots placed twice (first {dup[:5]})")
    # chi-square of the count distribution against Binomial(n, 1/B)
    p = 1.0 / B
    kmax = max(count) if count else 0
    obs = [0] * (kmax + 1)
    for c in count: obs[c] += 1
    exp_ = [B * binom_pmf(n, p, k) for k in range(kmax + 1)]
    exp_[-1] += B * max(0.0, 1.0 - sum(binom_pmf(n, p, k) for k in range(kmax + 1)))   # upper tail into the last class
    classes, eo, ee = [], 0, 0.0
    for k in range(kmax + 1):          # merge classes from the left until each expects >= 5
        eo += obs[k]; ee += exp_[k]
        if ee >= 5: classes.append((eo, ee)); eo, ee = 0, 0.0
    if ee > 0:
        if classes: o, e = classes.pop(); classes.append((o + eo, e + ee))
        else: classes.append((eo, ee))
    chi2 = sum((o - e) ** 2 / e for o, e in classes)
    dof = max(1, len(classes) - 1)
    pval = gammq(dof / 2.0, chi2 / 2.0)
    if pval < 0.001: errs.append(f"per-bucket counts do not fit Binomial(n, 1/B): chi2 {chi2:.1f}, {dof} dof, p {pval:.2g}")
    stash = sum(max(0, c - Z) for c in count)
    exp_stash = B * sum((k - Z) * binom_pmf(n, p, k) for k in range(Z + 1, min(n, Z + 80) + 1))
    summary = (f"{n} slots in {B} buckets, every slot placed once; {stash} in the stash at boot (expected {exp_stash:.0f}); "
               f"per-bucket counts vs Binomial(n, 1/B): chi2 {chi2:.1f}, {dof} dof, p {pval:.3f}")
    if errs:
        print("FAIL: " + "; ".join(errs[:5]) + f" -- {summary}")
        sys.exit(1)
    print(summary)

if __name__ == "__main__":
    main(sys.argv[1:])
