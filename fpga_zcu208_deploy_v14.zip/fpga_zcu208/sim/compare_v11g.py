#!/usr/bin/env python3
"""compare_v11g.py -- v14 against v11g, run by run under the same testbenches and stimulus.

    python3 compare_v11g.py V14_BUILD_DIR V11G_BUILD_DIR

V11G_BUILD_DIR holds the logs of the same run_verilator.sh groups run against v11g's RTL
(RTL_DIR=<v11g>/rtl TB_DEFS=-DTB_V11G_REF bash run_verilator.sh <group>). For every run_<tag>.log in both:
  no bucket on package (0%): every result line identical -- the boot, every launch's cycles, latencies, timing hashes,
      per-access shapes, traffic and bucket-write digests (only banner, calibration and simulator lines are skipped)
  buckets on package: everything an off-package observer or the host memory sees identical -- the host-memory
      bucket-write digests (data and addresses), the per-access shape hash of the off-package accesses (every host
      bucket-port handshake relative to the access start, the release and the end), the host-port traffic, and each
      launch's results (completed, errors, GETs, PUTs, rejected, bad); the on-package side (plaintext writes, shorter
      fixed times) differs by design
  every bucket on package in tb_ni (one bucket port: no host memory): skipped
Prints one line per class and every difference; exit status 0 if there is none.
"""
import os, re, sys, glob

SKIP = re.compile(r"^(tb_doma_kernel \||tb_onboard_test_top \||tb_ni|calib:|HB cyc=|INSPECT|- |\s*$|.*Verilog \$finish|.*S i m u l a t i o n|.*Walltime|.*wall time|"
                  r"%Warning|%Info|configuration:|packed records:|OVERRUN-AT)")

def lines(p):
    return [l.rstrip("\r\n") for l in open(p, errors="replace") if not SKIP.match(l)]

def onpkg(ls):
    """the run had buckets on package (kernel runs: HBM bucket writes; tb_ni: HBM-bucket work measured)"""
    for l in ls:
        m = re.match(r"^bucket writes: host .*; HBM (\d+) beats", l)
        if m and int(m.group(1)) > 0: return True
        if re.search(r"on-package release/end hash", l): return True
        m = re.search(r"ar_max_wb_h=(\d+)", l)
        if m and int(m.group(1)) > 0: return True
    return False

def host_view(ls):
    out = []
    for l in ls:
        if l.startswith("bucket writes:"):
            out.append(l.split("; HBM")[0] if "; HBM" in l else None)
        elif re.search(r": off-package access shape hash|: traffic record", l):
            out.append(l)
        else:
            m = re.match(r"^(\w+): size=(\d+) .*completed=(\d+) .*errors=(\w+)\s+gets=(\d+) puts=(\d+) rejected=(\d+)\s+bad=(\d+)", l)
            if m: out.append("launch " + " ".join(m.groups()))
    return out

def main(a14, a11):
    same0 = same1 = skipped = 0; bad = []; only = []
    for p in sorted(glob.glob(os.path.join(a14, "run_*.log"))):
        tag = os.path.basename(p)[4:-4]
        q = os.path.join(a11, os.path.basename(p))
        if not os.path.exists(q): only.append(tag); continue
        l14, l11 = lines(p), lines(q)
        if any("bucket writes: " in l and "host" not in l for l in l14) and onpkg(l14):
            skipped += 1; continue                                  # tb_ni with every bucket on package
        if not onpkg(l14) and not onpkg(l11):
            if l14 == l11: same0 += 1
            else:
                d = [f"    v11g: {x}\n    v14:  {y}" for x, y in zip(l11, l14) if x != y][:3]
                if len(l11) != len(l14): d.append(f"    {len(l11)} vs {len(l14)} lines")
                bad.append(f"{tag} (0% on package): differs\n" + "\n".join(d))
        else:
            h14, h11 = host_view(l14), host_view(l11)
            if h14 == h11 and h14: same1 += 1
            else:
                d = [f"    v11g: {x}\n    v14:  {y}" for x, y in zip(h11, h14) if x != y][:3]
                bad.append(f"{tag} (on package): off-package view differs\n" + "\n".join(d))
    print(f"v11g comparison: {same0} runs with no bucket on package identical on every line (boot, cycles, timing hashes, shapes, digests); "
          f"{same1} runs with buckets on package identical in everything off package (host-memory bucket writes, per-access shapes, "
          f"traffic, results); {skipped} single-port runs with every bucket on package skipped; {len(only)} runs without a v11g log")
    if only: print("  without a v11g log: " + " ".join(only))
    for b in bad: print("  DIFF " + b)
    return 1 if bad else 0

if __name__ == "__main__":
    if len(sys.argv) != 3: sys.exit(__doc__)
    sys.exit(main(sys.argv[1], sys.argv[2]))
