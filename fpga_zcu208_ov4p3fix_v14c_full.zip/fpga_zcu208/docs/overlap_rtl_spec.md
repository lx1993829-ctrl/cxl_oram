# Overlap RTL spec, step 1: two accesses in flight (4 KB, design A)

Basis: v14d1 (`rtl/flat_oram_gcm.v`, `stash_hbm.v` 7c03d7ae), arrival-mode builds, λ = 7, Z = 8. Build switch
`ORAM_OVERLAP2`; without it the RTL is v14d1, bit for bit.

## 0. Why step 1 is two in flight, one GCM core, no forwarding

The measured model (`overlap_study.md` §1.2) puts the bound at P ≈ 2,850–2,900 cycles per access while the stash
runs at design A's 0.44 beats per cycle at 2M. At that spacing:

- **The previous access is finished with all shared secret state before the next one starts.** Access i's decisions,
  its position-map writes, its bucket-record write and its stash commit all end by about s(i) + 2,200, and
  s(i+1) ≥ s(i) + P. So access i+1 reads exactly the sequential state:
  - no key forwarding, no in-flight key table;
  - no bucket-image forwarding except for the same bucket (D1, below);
  - no second staging set: `stash_hbm.v` is untouched.

  A fixed check enforces it; if it ever fails, the design halts (C1, §4).
- **One GCM core is enough.** i's encryption ends near s(i) + 3,400. i+1's ciphertext starts landing at
  s(i+1) + 671 ≥ s(i) + 3,520.
- **What remains to build:**
  - two contexts;
  - a second scratch buffer and a second result buffer, copies of today's templates;
  - separate read and write engines on the bucket port;
  - a fixed start rule;
  - the same-bucket rule;
  - kernel changes.

Step 2 (4 in flight, two GCM cores, forwarding, a stash metadata port) is worth building only if the card's stash
rate under design B or RAMA reaches about 1 beat per cycle. It reuses everything here.

## 1. Stages and who owns what

Each access j has a fixed start s(j). It moves through three units:

| Unit | Work | States |
|---|---|---|
| **Front** F | Lookup (position map, bucket record), stash open request, read gate at s + CT_RD, bucket read into scratch[j mod 2] | Today's S_IDLE → S_POS_LOOKUP → S_RD_GATE, as a separate small FSM |
| **Main** M | Decryption (off package) or arrival wait (on package), scan, decisions, copies, position-map updates, evictions, commit, encryption | Today's S_CR_* (DA), S_DDR_READ, S_SCAN … S_EA_START, S_CR_* (EA) |
| **Tail** T | Wait for the write-back data hand-off, done gate at t_arr + AR_REL(_H), result stream from res[j mod 2], `client_done` | Today's S_DDR_WRITE, S_DONE_GATE, S_RES_STREAM, as a separate small FSM |

Timeline at P = 2,850, off package (offsets from s(i)):

```
access i     F 0-1,701 (read lands)   M 671-3,400 (decrypt, decide, encrypt)   T 3,400-4,960 (write hand-off, release, result)
access i+1                                         F 2,850-4,551               M 3,521-6,250 ...   T 6,250-7,810
```

**Hand-offs:**
- **F → M:** when M is free (it has handed its previous access to T) and the F context's read has been issued.
- **M → T:** at the end of encryption (off package), or at S_EA_START once the eviction copies are done (on package).

At most two accesses are in flight:
- F(i+1) overlaps M(i);
- M(i+1) overlaps T(i);
- T(i−1) has ended before F(i+1) starts. A check enforces this (C3).

**Per-access context:** two banks, indexed by the access's parity bit.
- Contents: request (slot, op, partition), req_b, b′, acc_hbm, same_bucket, the read state (landed beats, arr_seen,
  t_arr), its cycle counter ct_cnt, res_zero, wb_active, wb_done_seen, enc_pos_done and the per-access deadline maxima.
- **The decision registers stay single.** M handles one access at a time: fill, slot list, eviction queue, copy
  state and cr_*.

## 2. Shared resources

| Resource | Today | Step 1 | Why no request-dependent timing |
|---|---|---|---|
| **Bucket port** (gmem2 host, gmem6 HBM) | One `axi_master`, read or write at a time; a read is held until every earlier write is acknowledged | **Two `axi_master` instances, the module unchanged.** One only reads (AR/R); the other only writes (AW/W/B). The kernel's router already selects per channel. **The read hold changes:** a read is held only under the same-bucket rule (D1). | i's write and i+1's read are at fixed times to public addresses. Each one's latency may depend on the other's traffic, which is public (A6, §5). |
| **Scratch** | One `scratch_buf` | **Two instances**, today's template unchanged. F writes the arriving read into scratch[j mod 2]. M reads and writes scratch[mp]. T's write-back stream reads scratch[tp]. | Different memories: no shared port, no multi-writer memory. |
| **Result buffer** `res` | One, written by S_CP, read by S_RES_STREAM | **Two copies** of today's `res` template. M writes res[mp]; T reads res[tp]. | As above. |
| **GCM core** | M only | M only. Decryption of i+1 starts after M has handed i to T, so encryption of i has ended. | Unchanged. The IV LFSR advances in access order, as today. |
| **Stash** (`stash_hbm`) | Opened at the lookup; the open waits for the previous commit to be quiet | **Unchanged module.** F's open request fires only when M has handed the previous access to T (its copies are done) and the stash is write-quiet. | The open's start depends on the previous access's commit, which is internal. Its effect is bounded by the next access's fixed deadlines (fail-stop), as today. |
| **Position map, bucket records, IV/tag table** | One access | F(i+1) reads only after i's writes (C1). | Sequential. |
| **Debug maxima** (ct_max_*, ar_max_*) | One writer | Updated from M and T. One of them takes priority, and the other's update is held one cycle. | Debug only. |

**New memories:** scratch #2 and res #2, each a second instance of an existing single-write-port template. **No new
multi-writer memory.** Both go into the netlist group (`run_stash_netlist.sh`, plus a new `tb_scratch` unit test
against the Vivado and Yosys netlists).

## 3. The fixed schedule

**Start rule.** s(j) = max(the cycle request j is presented, s(j−1) + P).
- P is a build constant (`ORAM_OV_P`, one value per build, calibrated on the card).
- F starts j at s(j) only if F is free, which C3 guarantees.

**Fixed offsets, all as today:**

| Event | When |
|---|---|
| Lookup | s(j) |
| Read issue | s(j) + CT_RD |
| Off-package write-back | t_arr(j) + AR_WB |
| Release | t_arr(j) + AR_REL(_H) |
| Response | after the release |

**Same bucket (D1).** At the lookup, F compares b(j) with the bucket of every access whose write-back is not yet
acknowledged: at most i = j − 1. If they are equal, j's read issues at s(j) + CT_RD + D_EQ instead, and j's whole
schedule, including the next start, shifts by D_EQ. D_EQ is a constant: i's write-back is acknowledged by then, or
the design halts (C4).
- The equality of two bucket indices is public: the trace shows both addresses.
- The decryption of j uses the IV and tag i wrote, because it starts after i's encryption has ended.

**New checks.** Each check is fail-stop: the design halts at the access's release time, as v14b does.

| Check | Condition | Why |
|---|---|---|
| C1 | At s(j), M has passed i's S_EA_START (decisions, position-map and record writes issued), and those writes are acknowledged | j's lookup sees i's results |
| C2 | M is free for j by t_arr(j) − 1,030 + slack (decryption must not start late) | Covered by j's AR_WB check. Recorded separately for calibration. |
| C3 | T is free when M hands over j | T(j−1) is done |
| C4 | With b(j) = b(i): i's write-back is acknowledged by s(j) + CT_RD + D_EQ | Same-bucket read-after-write |
| Today's | CT_RD, AR_WB(_H), AR_REL(_H), AR_DONE(_H), each from its own access's s or t_arr | Recalibrated with the neighbour's traffic present |

## 4. Correctness

**Claim:** the overlapped design computes, for every access, exactly what v14d1 computes sequentially. By induction
on j:
- **Position map, bucket records, stash.** Written only by M, in access order. All of i's writes are issued before
  s(j) and acknowledged before j's reads issue (C1).
- **Stash open.** j's open fires after i's commit is quiet and i's copies are done, so `stash_hbm` sees the same
  sequence of operations as in v14d1.
- **Buckets.** j reads b(j) after every earlier write to b(j) is acknowledged:
  - for i − 1 and earlier, by the release and the start spacing;
  - for i, by C4.

  The ciphertext and the IV/tag pair are the sequential ones.
- **Scratch and result buffers** are private to their access by parity. C3 guarantees a buffer's previous owner has
  finished with it.
- **GCM and the IV LFSR** are used by M only, in access order.

**Test:** the overlapped design's responses, and its final bucket and stash images, equal v14d1's on the same
streams. The eviction scoreboard runs in every run.

## 5. Leakage, stage by stage

**Rule.** Every externally visible event of access j happens at a constant offset from s(j) or t_arr(j). The
visible events are host-port reads and writes (time, address, size), and the response. s(j) depends only on request
arrival times and the public bucket-equality class.

- **F.** The lookup and read gate are fixed offsets from s(j), as today. The read is no longer held for unrelated
  writes; it is held only on equality (public).
- **M.** Unchanged; internal, bounded by j's deadlines. Its start depends on i's encryption end (internal), as the
  open's start depended on the previous commit before.
- **T.** Unchanged: release and response at fixed offsets from t_arr(j).
- **Cross-access effects:**
  - **Bucket port.** j's read latency includes i's concurrent write traffic, which is public (fixed size and time,
    public address).
  - **Stash traffic.** j's stash open (secret volume) runs alongside i's on-package write-back. On package nothing
    is observable; only the deadlines matter, and they are fail-stop.
  - **Host-visible events of i** (write-back, release, response) are fixed offsets from t_arr(i) and never wait on j.
- **A6 (stated).** A memory's latency may depend on the public trace (now including the neighbour access's fixed
  traffic) and on request-independent noise.
  - The stash's secret-volume traffic stays on its own pseudo-channels (HBM[12:15]), as it already runs alongside
    the access's own bucket read today.
  - Assumed, as today, not to change the bucket port's latency enough to matter. The 2M calibration with the
    neighbour present measures it.
- **Halts.** A halt depends on memory timing and the stash (fail-stop), as today. The neighbour's stash volume is now
  one more input to the on-package deadlines, so the 10% margin is recalibrated with it present.

**The test that would catch a violation:** the injected-leak define `TB_OV_LEAK` makes F wait one extra cycle when
j's key equals i's key. The paired-stream hash check must fail with it, and pass without it.

## 6. Kernel

- **Commands.** The kernel holds up to two commands at the controller. It presents command j as soon as the
  controller's front is free (`client_ready_next`), not after `client_done` of j−1.
- **Data in both directions at once.** PUT data for j (`client_wdata_beat_req`, during M(j)'s copy) and the result
  stream of j−1 (`client_rdata`, during T) can be active together. The kernel serves them from separate paths.
  Responses are written in order, because T finishes in order.
- **Tokens.** The per-command token and debug record follow the command into its context.

## 7. Order of work and tests

1. **Two read/write engines** on the bucket port, plus the read-hold change (equality only). Regression: v14d1
   hashes unchanged with `ORAM_OVERLAP2` off; with it on and P = ∞ (no overlap), hashes identical to v14d1.
2. **Second scratch and result buffers**, parity selection, context banks. With P = ∞ still identical.
3. **F and T as separate FSMs**, the hand-offs, the start rule, C1–C4. Then P finite.
4. **Kernel** (two commands in the controller).
5. **Tests:**
   - **Paired streams:** different keys, data and op mix, same arrivals; hashes identical. Cases: repeated key
     (k times, ABAB), same bucket (`dbg_force_same_bucket`), stash-filling scan, 0 / 20 / 100% on package, the
     card-like stash.
   - **Injected leak:** fails as it should.
   - **Sequential equivalence:** against v14d1, with the scoreboard.
   - **XRT mock:** host_doma's 4,096-record sequence.
   - **Netlist group:** scratch #2 and res #2.
6. **Card:**
   - debug-bitstream calibration of P, D_EQ, C1–C4 and today's deadlines at 2M records, 20% and 50% on package;
   - all responses correct;
   - leakage Runs A and B;
   - throughput at P.

**Expected** (§1.2 model, card stash rate): about 2,850–2,900 cycles per request, 1.7× at 0–20% on package and
1.4× at 100%. With a faster stash, P falls toward the decision-end bound (≈ 2,250 off package; C1), about 2.2×,
without step 2.

## 8. Implementation (step 1, in progress)

All of the following sits behind `ORAM_OVERLAP2`. Without the define, the preprocessed `flat_oram_gcm.v`,
`secure_oram_top.v` and `doma_kernel.v` are textually identical to v14d1 (`verilator -E`, checked).

**Patch scripts:** `/home/claude/ovp/patch_{ctrl,top,kernel}.py`, applied to v14d1. They are kept so the changes can
be reviewed as one diff.

**Deviations from §1–§3, found while building:**
- **Two tails, one per access parity.** An off-package access's tail lasts from S_EA_START to its end (≈ 2,820
  cycles), longer than P − (the next access's decision time). With one tail, an off→on pair failed check C3 in the
  first simulation. Each tail has its own context: counter, t_arr, class, op, result-zero flag, bucket, deadline
  record, write pending and handed-off flags.
- **Write-backs leave in access order, one in flight, each acknowledged before the next is issued.** The kernel's
  bucket-port switch routes B responses by the latest AW. In the first simulation, an on-package write issued while
  an off-package write's B was still outstanding lost that B, which looked like a same-bucket hazard (C4 fired).
  - On package, the write issues as soon as the engine is free and quiet. Not observable.
  - Off package, it issues exactly at t_arr + AR_WB. If the engine is busy then, the design halts (fail-stop),
    never waits.
- **The write stream's hold** uses the progress of the access being written: M's progress while M is still on that
  access, otherwise "all positions done".
- **T takes the access at S_EA_START.** The off-package write gate (t_arr + AR_WB) then runs on T's context, while
  M finishes the encryption.

**Fail-stop checks implemented:**

| Check | Condition |
|---|---|
| C1 | M has passed the previous access's S_EA_START when F accepts |
| C3 | The tail of the same parity is idle at M's take and at S_EA_START. Results leave in order, one at a time. |
| C4 | A same-bucket write-back is acknowledged at the shifted read gate |
| Read engine | Free at accept and at the gate |
| Buffer reuse | Scratch and result buffers of the same parity are free |
| Write engine | Free and quiet at an off-package write's fixed time |

**Testbench additions:**
- **Overlap-aware eviction scoreboard.** A PUT counts at its access's S_EA_START. The slot list is taken as decided.
- **`folded off-package shape hash`.** Per-access events relative to the access start, folded in completion order.
  It is defined under overlap and computed identically in the serial build, so the two can be compared.
- **On-package release/end hash** under overlap.
- **Test options:** `+same_key=R` and `+abab_key=R`.
- **Injected leak, test only (`TB_OV_LEAK`):** a PUT's read gate is one cycle late.

**First result** (4 KB, λ 7, 20% on package, host read latency 401, preload of 512, then 200 + 4 commands, P = 2,900):
- **Correctness:** all responses correct; no halt; the eviction scoreboard checked 84,224 copied beats with 0 wrong.
- **Throughput:** 2,926 cycles per command, against 4,863 for v14d1 at 20% (1.66×). The excess over P comes from
  same-bucket shifts: with 512 records there are only 73 buckets, so equal consecutive buckets are common in this
  test.

**Comparison runs** (`/home/claude/ov/R`; v14d1 = `base`, overlap = `ovf`; 4 KB, λ 7, preload of 512, then about
200 commands; all runs pass every check with 0 wrong evicted beats):

| Run | v14d1 cycles/cmd | Overlap cycles/cmd | Gain |
|---|---|---|---|
| 0% on package, host read latency 401 | 5,138 | 2,926 | 1.76× |
| 20%, card-like stash (gap 40, 3.9 pseudo-channels, one ID, latency 120) | 4,924 | 2,962 | 1.66× |
| 100% on package | 4,141 | 2,908 | 1.42× |

**Paired streams** (same keys and arrivals; 0%, 50% and 100% PUTs; 20% on package; 300 commands): every visible hash
is identical across the three:
- bucket-port timing, over 3,968 requests;
- folded off-package shape;
- on-package release and end.

**Against v14d1:**
- **On-package release and end:** identical in every run (3,738 and 3,869 cycles after each access's start).
- **Folded off-package shape: every access identical to v14d1 except same-bucket ones.** The per-access event dump
  (`+shape_dump`, 0% on package, 64 accesses) shows exactly one differing access, number 59, whose bucket equalled
  the previous access's. Every one of its events is shifted by D_EQ = 2,700, as designed (D1: public bucket
  equality). There are 73 buckets in these tests, so equal consecutive buckets are common; at 2M records they are
  rare.

**Injected leak (`TB_OV_LEAK`, a PUT's read gate one cycle late) is caught:**

| Hash | 0% PUTs | 100% PUTs |
|---|---|---|
| Bucket-port timing | 741e8f33… (as without the leak) | **3c8d5054…** |
| Folded off-package shape | 13f150e6… | **296c0f8f…** |
| On-package release/end | a0e60f76…, release 3,738 | **013953e6…, release 3,739** |

**Repeated keys:** the same key 120 times in a row (`+same_key=120`) and ABAB (`+abab_key=120`), at 0%, 50% and 100%
PUTs. Every response is correct, the scoreboard reports 0 wrong, and the paired hashes are identical:
- same key: 52b9f3be… / 7be8689f… / bff2058f…;
- ABAB: 883a80f9… / 41d51c90… / bff2058f….

Throughput is 2,965 cycles per command: a repeated key goes to its fresh random bucket, so it never stalls.

## 9. Timing-leak review of step 1 (every wait that could reach a visible event)

**Visible events:**
- **Host bucket port:** each read and write (time, address, length), R and W beats.
- **The result:** its release and its end.
- **The start spacing:** the request rate.

On-package HBM traffic, the stash and the metadata are on package and not observable; their only effect is through
fail-stop deadlines.

**Two leaks found in the first version and fixed:**
1. **The start waited on F being free.** F is free once M takes the previous access, after M's previous encryption
   or copies, whose duration depends on the stash. Now s(j) = max(request presented, s(j−1) + P (+ D_EQ)) exactly. If
   F still holds the previous access then, the design halts (C3). With P = 2,900 this cannot happen inside the
   deadlines: M is free by s(j−1) + about 600 off package and about 840 on package.
2. **The same-bucket shift depended on whether the previous write had been acknowledged.** An on-package write's
   hand-off time depends on the eviction copies. The shift now depends on bucket equality with the previous access
   alone (public). At the shifted gate that write must be acknowledged, else the design halts (C4). The bucket of the
   access before that is never a reason to shift; its write must be acknowledged by the read, else halt.

**Every remaining wait, and why it is safe:**

| Wait | Depends on | Visible effect |
|---|---|---|
| Kernel presents a request | Its command fetch (HBM), a free request buffer (freed at a result's end, public), completion-queue room (freed after a response write, public) | Request arrival: public, as today |
| F accept | Request presented, s(j−1) + P (+ D_EQ) | None beyond those (no wait on internal state; C1/C3 halt instead) |
| F lookup | Position-map and record latency (HBM) | None: the read issues at s + CT_RD exactly (late lookup: halt) |
| Read gate | Fixed: CT_RD (+ D_EQ on public equality) | None |
| Read beats | Host memory latency and the other access's fixed write traffic (public), never back-pressured | As today (A6) |
| M take, stash open, decisions, encryption | Previous access's encryption or copies, stash commit (internal) | None: bounded by the fixed deadlines (fail-stop) |
| Off-package write | Fixed: t_arr + AR_WB. The write engine must be free and quiet then (halt otherwise); a beat held by unfinished encryption is a stall (halt) | None |
| On-package write | Engine free and quiet, copies landed | Not observable (HBM); bounded by AR_REL_H (halt at the release time) |
| Release | Fixed: t_arr + AR_REL(_H); write handed off by then (halt otherwise); results in order, one at a time (halt otherwise) | None |
| Kernel response write | After the result's end | Public |

**Halts.** Fail-stop conditions now include C1, C3, C4, the write engine and the result order. As for v14d1's
overruns, whether one fires can depend on internal timing. With calibrated budgets, none fires: the simulations
above have no halt, and the card's debug calibration must show margins for each.

**Checked in simulation:**
- **Paired streams** (GET/PUT mix 0/50/100%, same keys and arrivals): identical bucket-port timing, per-access
  off-package shape, and on-package release/end hashes.
- **Same key ×120 and ABAB:** identical paired hashes.
- **Injected one-cycle PUT-dependent delay:** caught by all three hashes.
- **Per-access event dump against v14d1:** identical except the public same-bucket shift.

**After both fixes: per access, overlap equals v14d1 exactly, apart from the public shift.** The testbench takes D_EQ
out of every time of exactly the accesses whose bucket equalled the previous access's (the "equality-corrected"
hashes). The result must equal v14d1's hashes bit for bit:
- **0% on package:** off-package shape including every R and W beat, 5b58a7fb… for both builds.
- **100% on package:** release/end, 7b6e4606… for both builds.

`run_overlap.sh` checks this at 0%, 100% and 20% with the card-like stash.

## 10. Step 2: four in flight (`ORAM_OVERLAP4`)

**Build switch.** An OVERLAP4 build defines both `ORAM_OVERLAP2` and `ORAM_OVERLAP4`. Every step-1 block sits
unchanged in the `else` branch of an `ifdef ORAM_OVERLAP4`. Checked with `verilator -E`: a step-1 build and a v14d1
build preprocess to exactly the text they had before. Patches: `/home/claude/ovp/patch_ov4.py` (controller) and
`patch_tk4.py` (top, kernel), applied after the step-1 patches.

**Structure:**

| Part | Step 2 |
|---|---|
| Contexts | 4, index = access number mod 4. Front records, scratch buffers, result buffers, tails and request buffers are each four copies of the existing single-write-port templates. The kernel holds up to four commands. |
| Main stage M | Decryption on core D (the stored IV), the decisions and the commit. It is free for the next access once the eviction copies are done (staging reuse: `stash_hbm.v` unchanged). |
| Encryption stage E | Core E, jobs in access order: an encryption off package, an IV advance on package. The boot format also runs on core E, so all IVs come from one generator in the serial order. |
| Read address (D2) | At accept, if one of the three previous accesses requested the same key and has not passed its decisions, the read goes to that access's new bucket (drawn at its start). A select, no wait. |
| Status, pool index, bucket record | As looked up, then corrected by every position-map and record write made after the lookup and before M takes the access. M's take reads no memory. |
| Same bucket (D1) | The bucket equals one of the three previous accesses' (public) → fixed shift D_EQ (default 3,600). Each of those writes must be acknowledged at the shifted gate (C4, else halt). The decryption of such an access starts only after its read has issued, after the earlier access's IV and tag were written. |
| Start rule | s(j) = max(request, s(j−1) + P (+ D_EQ)), P default 1,500. The context four back must be finished (taken, tail done, write acknowledged), else halt. |
| Budgets | The stages queue behind earlier accesses, so the arrival-relative write-back and release get fixed allowances: AR_WB +700, AR_WB_H +1,200, AR_REL_H +1,400 (`ORAM_OV4_X*`, to be calibrated). Per-access latency rises. Throughput is set by P. |

**First results** (4 KB, λ 7, host read latency 401, 20% on package, preload of 512, then 204 commands):
- **Correctness:** all responses correct; 84,224 copied beats checked, 0 wrong; no halt.
- **Throughput:** 1,631 cycles per command, against 4,863 for v14d1 (3.0×). Excluding the 6 same-bucket shifts:
  about 1,523 (3.2×).

**Regression:** `OV=4 bash sim/run_overlap.sh`. Same set and checks as step 1, plus keys repeating every 3 and every
4 commands. The comparison with v14d1's per-access times is skipped, because the budgets differ.

**Not yet:**
- debug and calibration records for four contexts;
- the netlist check of the new memories;
- the XRT-mock host sequence for step 2;
- card calibration of P, D_EQ and the allowances.

**Step-2 fixes found by the regression (all internal timing, no visible effect):**
1. **Eviction copies overlap the next access.** At 0% on package, M waited for an access's copies before taking the
   next one, which pushed a later encryption past its fixed write-back time (fail-stop halt). Now:
   - the copies belong to `c_own`, set when an access's decisions start, and run on while M takes the next access;
   - only the next stash open waits for them (the staging slots are reused);
   - E sees an access's pending copies only while it is still `c_own`.
2. **The stash open waits for the previous commit to register.** The stash's write-quiet flag lags a commit request
   by a cycle or two, so an open right after a commit was refused (stash error). The open now also requires no
   commit request this cycle and at least 3 cycles since the last one.
3. **Same-cycle corrections at the take.** A bucket-record write by the previous access, landing in the cycle M took
   the next access to the same bucket, was missed: the access took the old record, missed the block just evicted
   there, and one GET returned zeros. A record write, a position-map write, or the access's own record read landing in
   the take cycle is now passed straight to M.
4. **Testbench:** the scoreboard attributes each copy to its owner's slot list and request.

After these fixes, 0% and 20% on package (preload of 512, then 204 commands) both pass: all responses correct,
0 wrong evicted beats, no halt. That is 1,649 and 1,631 cycles per command: 3.1× and 3.0× v14d1, including the
same-bucket shifts.

**Step-2 status, 2026-11-04:**
- **`OV=4 run_overlap.sh`:** 26/26 on your laptop after the bucket-record fixes. The encryption stage's IV/tag write
  never shares a cycle with a record write. A same-bucket access fetches its record at its shifted gate. The
  decisions wait for the record.
- **Remaining before a card build** (scripts in the package):
  - `sim/run_overlap_more.sh`:
    - the scratch_buf netlist check;
    - host_doma's sequence in the XRT mock for steps 1 and 2;
    - 4,096-record kernel runs: 3 seeds × 0 / 20 / 50% on package, steps 1 and 2;
    - the too-slow-stash fail-stop check for step 2.
  - `bash sim/run_scratch_netlist.sh vivado` on the server.
  - `bash vitis/synth_ooc_overlap.sh 1` and `4` on the server: utilization and 300 MHz timing.
- **scratch_buf unit test (`tb_scratch.v`):**
  - random traffic on all five ports against a reference copy;
  - passes on the RTL and on the Yosys gate netlist;
  - the negative control (one bank's copy writes dropped) fails at once, with 2,072 mismatches.

## 11. Logic depth without Vivado (2026-11-04)

**Method.** `sim/ys_depth.sh` maps the controller, top and kernel (where all overlap logic lives) to UltraScale+
cells with Yosys (`synth_xilinx -family xcup`, no LUT RAM, so register-array read muxes count). The datapath blocks
(GCM, stash, scratch, AXI masters, HBM tables) are black boxes. `sim/ys_depth.py` then reports, for every register,
the deepest logic in front of it:

- a LUT counts 1;
- MUXF7, MUXF8 and MUXF9 count 0.3 each;
- a carry chain counts 1 to enter, then 0.15 per CARRY4.

It is a proxy, not a timing analysis. The measure that matters is the comparison with v14d1, whose paths closed at
300 MHz on the card.

**Before.** v14d1's deepest paths are its own:

| Path | Depth |
|---|---|
| `bkt_slot_list` | 13.9 |
| `bm_wr_slot_list` | 13.8 |
| `trf_beat` | 13.4 |
| M's done gate | 10–12 |

The overlap builds added new paths:

| Build | Path | Depth |
|---|---|---|
| Step 2 | the read gate and lookup (`f_ct[f_par]` 4:1 muxes, 32-bit compares) into `bm_rd_bucket`, `s_need`, `f_eqa`, `b_ctx` | 10.8–11.8 |
| Step 2 | the write-back issue (`t_ct` and `t_tarr` muxes, an add, a compare) into `axim_cmd_bucket` | 10.1 |
| Step 2 | `HALT_BITS` | 12.1 |
| Step 1 | the same write-back path | 10.1 |
| Step 1 | `HALT_BITS` | 12.0 |

**Changes.** Applied by `/home/claude/ovp/patch_timing.py`, after `patch_ov4.py`. All are cycle-exact.

- **T1, the tail's deadlines (steps 1 and 2).** `t_rel = t_ct − t_tarr` is kept as its own 33-bit counter:
  - it is set with `t_ct` at S_EA_START and counts with it;
  - each context compares it with constants (`t_wbok`, `t_gok`, `t_glate`, `ev_rtv`), and the write-back issue and
    T_GATE then select a single bit;
  - the 33 bits make the difference exact, so no compare can wrap.
- **T2, the serial tail (steps 1 and 2).** S_WB_GATE, S_DDR_WRITE, S_DONE_GATE and S_RES_STREAM are never entered in
  an overlap build, because T does that work. Their logic is removed there: each state now goes to S_HALT, which is
  equally unreachable.
- **F1, the front stage (step 2).** F holds one access at a time, so what it read through `f_par`-indexed 4:1 muxes now
  comes from plain copies:
  - the forwarding result, draw, partition and slot (written only at the accept);
  - the buckets of the three earlier accesses (a shift register, written at each lookup);
  - its own bucket and same-bucket flag;
  - its counter (`fl_ct` equals `f_ct[f_par]` while F is busy).

  Each copy is written in the same cycle, with the same value, as the array entry it mirrors. The read gate and the
  lookup's overrun check become flags registered with `fl_ct`: each takes the comparison of the counter's next value.
  The same-bucket mask is built per context from three equalities, with no variable bit index. The context indices
  are explicit 2-bit wires (`an`, `fp_m1..3`).

**After:**
- **Step 2:** every overlap path is 9.5 or less: the tail's result start at 9.5, `HALT_BITS` at 8.8. The only deeper
  paths are v14d1's own three.
- **Step 1:** every overlap path is 9.0 or less.

**Equivalence.**
- **v14d1:** its preprocessed source is unchanged (`verilator -E`).
- **Steps 1 and 2:** each was built from the old and the new RTL and run on the same cases. Every output line is
  identical: responses, every visible hash, the bucket-write digests, cycle counts, calibration maxima and halt records.
  - Step 2 cases: p50, c0, c1, k4a, ab50, cs and slow56.
  - Step 1 cases: p50, c0, c1, ab50, cs and slow78.
  - Halt cases, both steps: a too-slow stash (stash error), a too-slow bucket read (read-gate overrun) and an
    on-package deadline miss (write-back start and release hand-off).
- **`OV=4 run_overlap.sh` on the new RTL:** 26 passed, 0 failed. Throughput is unchanged:
  - 0% on package: 1,649 cycles per command;
  - p50: 1,600;
  - card-like stash: 1,720;
  - 100% on package: 1,630.

**Remaining risk.** The scratch and result buffers' read data passes one more 4:1 mux (step 2) or 2:1 mux (step 1)
after the block RAM than in v14d1. That is one LUT level on a path v14d1 closed.

## 12. Fixed-schedule check (`check_fixed_schedule.py`, in `run_overlap.sh`)

The paired streams vary only GET and PUT. This check also covers the keys, the data and the stash state. The
testbench (`+fix_dump=<file>`) writes one line per completed access:
- its start cycle;
- the cycle its request was first presented;
- the public same-bucket flag;
- whether it is on package;
- one hash of its visible times relative to its start, with the same-bucket shift taken out. Off package that is every
  bucket-port event, the release and the end; on package, the release and the end.

The check requires three things:

1. **One shape per class, in each run.** Every off-package access has the same hash, and every on-package access has
   the same hash.
2. **The start rule, exactly.** Every start is `s(j) = max(r(j) + K1, s(j−1) + P (+ D_EQ) + K2)`, where `r(j)` is the
   request time and `K1` and `K2` are the design's constants. Both are learned from the run, and every access must then
   follow them. Here `K1 = K2 = 1`.
3. **The same shapes across runs** that share the memory latencies: random keys, one repeated key, ABAB, keys repeating
   every 3 and every 4 commands, 0 / 20 / 50% on package, and the card-like stash.

The testbench memories have fixed latencies (`+hb=0`). Only the memories' latencies, the request arrivals and the
public bucket equality may move a visible time, so any dependence on keys, data or the stash shows up as a second
shape, or as a start off the rule.

**First results, step 2 (new RTL).** Every run had one shape per class, every start followed the rule (`K1 = K2 = 1`),
and the shapes were identical across seven runs:

| Run | Accesses | Off package | On package |
|---|---|---|---|
| p50 | 816 | 669 | 147 |
| sk100 | 636 | 519 | 117 |
| ab50 | 636 | 519 | 117 |
| k3a | 636 | 519 | 117 |
| k4a | 636 | 333 | 303 |
| c0 | 716 | 716 | 0 |
| cs | 716 | 577 | 139 |

The injected-leak build (a PUT's read one cycle late) fails, as it should:
- l100: two off-package shapes, 668 and 1 (the one GET in run 2);
- l0: two shapes in each class, because the preload is all PUTs.

**Regression with the fixed-schedule checks, on the new RTL (2026-11-04):**

| Step | Result | Fixed-schedule checks |
|---|---|---|
| Step 2 (`OV=4 run_overlap.sh`) | 29 passed, 0 failed | 3 |
| Step 1 (`run_overlap.sh`) | 32 passed, 0 failed | 3, plus the per-access comparison with v14d1 |

The three fixed-schedule checks are:
- every run, one visible shape per class, start rule exact (15 runs);
- identical shapes across the 12 runs with the same memory latencies;
- the injected-leak build fails.

## 13. Card build of step 2 (package `fpga_zcu208_overlap2_v14c_overlay.zip`)

**Package.** An overlay over v14c. It holds every v14d1 file (51 files; the overlap changed six of them: the three RTL
files, `vitis/build.sh`, `sim/run_verilator.sh` and `sim/tb_doma_kernel.v`) plus the overlap files, 67 files in all,
and a new `MANIFEST.sha256` covering the whole tree after unzipping over v14c (319 files). Check it with:

    cd fpga_zcu208 && sha256sum -c --quiet MANIFEST.sha256

The three RTL files carry both steps behind the switch. The overlap top (`secure_oram_top.v`) connects the
controller's `client_acc`, `client_wsel` and `client_rsel`, and the kernel (`doma_kernel.v`) holds up to four
commands. Without the switch, all three preprocess to exactly v14d1's text (`verilator -E -P`, compared on 768 files:
the 3 RTL files × 256 configurations, namely block sizes 32 B / 256 B / 4 KB / default × NMAX 2M or default ×
strict / arrival / trace / debug / stash IDs / interim / plain × SYNTHESIS and SECURE_BUILD on and off; 0 differ).
`vitis/package_kernel.tcl` packages every `rtl/*.v` and `*.vh`, so no file list changes. An `ORAM_OVERLAP4` without
`ORAM_OVERLAP2` stops at elaboration (a missing module).

**Build command** (in `vitis/`; Vitis 2024.1 environment as for v14d1):

    OVERLAP=4 SCHED=arrival BEATS=128 CFG=doma_big2m.cfg NMAX=2097152 LAMBDA=7 TARGET=hw bash build.sh

`build.sh` prints the `rtl/oram_build_cfg.vh` it wrote. For this command:

    `define ORAM_BLOCK_BEATS 128      (inside `ifndef)
    `define ORAM_N 2097152            (inside `ifndef)
    `define ORAM_SCHED_ARRIVAL
    `define ORAM_OVERLAP2
    `define ORAM_OVERLAP4
    `define ORAM_OV_P 1500
    `define ORAM_OV_DEQ 3600
    `define ORAM_C 7                  (inside `ifndef)

Other switch values:
- `OVERLAP=2` (or 1) writes `ORAM_OVERLAP2`, with P 2,900 and D_EQ 2,700;
- unset or 0 is v14d1;
- any other value stops the build;
- `OV_P` and `OV_DEQ` override P and D_EQ. Without them the defaults above hold, and they are the values every
  regression used;
- step 2's allowances keep their RTL defaults: `ORAM_OV4_XWB` 700, `ORAM_OV4_XWB_H` 1,200 and `ORAM_OV4_XREL_H` 1,400.

After a `TARGET=hw` build, `build.sh` runs two checks:
- `check_timing.sh`: whether the routed timing met 300 MHz;
- `check_overlap_build.sh 4`: whether the configuration has both defines, and whether the placed design
  (`post_place_util_hier.rpt`) contains the second GCM core `u_aes_gcm_e` and the four scratch buffers
  `g_scr[0..3]`. Either missing means v14d1 was built, or the overlap was trimmed.

**Host.** `host_doma`, `host_phases` and `host_ycsb` are unchanged, and are run exactly as for v14d1
(`DOMA_LAMBDA=7`, the same `DOMA_N` and pool). host_doma's own sequence on the step-2 RTL, through the XRT mock
(N max 2M, n = 4,096, 20% on package):
- boot errors 0;
- 5,000 commands (2,546 GET, 2,454 PUT), all responses correct;
- 7,617,091 device cycles: 1,523 per command, against about 4,900 for v14d1;
- per-command latency 5,434–9,572 cycles.

## 14. Step 2 front end: two bucket reads in flight (2026-11-04)

**Why.** The card halted step 2 at access cycle 1,768. Step 2 had a single bucket read engine. Access j+1's read is
due at s + P + 266 = 1,766, and on the card access j's host read was still arriving then (address to last beat:
median 1,490, 99.99% 2,632, max 3,892). A read that is due while another is still arriving can only wait or halt, and
with one engine every wait is a full read long.

**14.1 The read unit (`rtl/axi_rd2.v`).** Two copies of `axi_master`'s read path (the module unchanged, its write side
tied off) share the one AXI read port:
- a read command goes to a free copy and carries its context;
- AR: the older read's burst addresses first; the younger's once the older has issued all of its own;
- R: every accepted burst address is recorded in order (which copy issued it, one bit per burst, at most 2 × 8
  outstanding), and each R burst goes to the copy at the head of that record. One AXI ID, so the slave returns bursts
  in address order, and every read's data returns in issue order;
- outputs: the landed beat with its context (`rdata_ctx`), the completing read's context (`done_ctx`), the context of
  the burst address on the bus (`ar_ctx`) and of the R burst being received (`r_ctx`).

The kernel (`rtl/doma_kernel.v`, `ORAM_OVERLAP4` only) routes R bursts between host memory and HBM by a per-burst
record of the same kind (the port of every accepted burst address, popped on RLAST), instead of the latest AR. Both
records have one writer each (a register file written at the AR handshake only). The controller-side and kernel-side
records see the same AR handshakes in the same order, so they agree burst by burst.

**14.2 The waiting read gate (approved 2026-11-04).** Access q's read is due at its gate,
`f_ct[q] >= OV_CT_RD` (`+ OV_DEQ` if its bucket equals one of the three earlier accesses' buckets: public). Reads issue
in access order. A due read issues at once, or later **only while both read copies are busy**, that is while earlier
reads are still arriving: a wait on the memory's latency alone. Nothing else can delay it:
- not the keys or the data: the gate is a count from the start and the public equality flag;
- not the stash: the read does not wait for any decision, write or eviction;
- not a same-key dependency: same-key data is forwarded inside the schedule as before (section 10), never by a wait.

At the moment it issues, two conditions must hold, and each is a **fail-stop, never a wait** (they depend on the
stash's timing through the write-backs):
- its buffers are free: the write-back four accesses back has ended;
- every earlier write to its bucket is acknowledged (C4).

The cycle after an issue never issues (the read unit takes the command then).

**14.3 The bucket-record reads.** One record read outstanding at a time (an arbiter, R3). A same-bucket access re-reads
its record when its bucket read issues, after every earlier write to that record. The front lookup's own record read
waits behind it. The order of the record reads is fixed by the access order and the public equality flags, and
their timing by the metadata memory's latency.

**14.4 The arrival spacing rule (`ORAM_OV4_GA`: RTL default 1,200, card 1,500).** Reads return in issue order, so after a slow read the
next read's last beat can follow the slow one's by a single bucket's beats (1,024 cycles). Every write-back is taken at
a fixed time after its arrival (`t_arr + AR_WB`), and one write-back takes 1,024 beats and its acknowledgement, so two
arrivals 1,024 apart put two write-backs on the write engine at once. In simulation with card-like read tails this was
a fail-stop at the write-back issue (the write engine not yet quiet). Every arrival-relative time (write-back, release,
deadlines) now uses the **effective arrival**

    t'(j) = max(t(j), t'(j-1) + OV_GA)

It is a function of the memories' latencies and a public constant only, and it only ever moves a time later. Decryption
still starts at the real arrival.

`OV_GA` must stay below P minus the usual arrival difference between the two classes (an on-package read arrives
earlier after its start than a host read), so that it binds only after a read slower than the usual one. With fixed
latencies it then never binds and every access keeps one visible shape per class:
- simulation: 1,500 − 261 = 1,239, so 1,200. A first try at 1,500 bound on every on-package access that followed an
  off-package one; the fixed-schedule check caught it (four on-package shapes, a function of the earlier buckets'
  locations only: public, but not the fixed schedule we want);
- card: 2,150 − (1,490 − 1,189) ≈ 1,850, so 1,500 (`build.sh OVERLAP=4`). The calibration readouts take the time since the effective arrival as 0 while it is
still ahead.

**14.5 Parameters.** `OV_CT_RD` (`ORAM_OV_CT_RD`, `build.sh OV_CTRD`) is the read gate after the start; the lookup
must be done by it (fail-stop otherwise).

A context is reused four accesses later, so 4 P must cover a context's life: the read gate, the read, the release
(`AR_REL` 3,033 + 700) and the result stream (~130). With the card's worst host read (3,892):
600 + 3,892 + 3,733 + 130 = 8,355 ≤ 4 × 2,150.

| | Simulation default | Card (`build.sh OVERLAP=4` default) |
|---|---|---|
| P (`ORAM_OV_P`) | 1,500 | 2,150 (≈ 139.5 KQPS ceiling at 300 MHz) |
| Read gate `OV_CT_RD` | 266 | 600 |
| Same-bucket shift D_EQ | 3,600 | 6,000 |
| Arrival spacing `OV_GA` | 1,200 | 1,500 |

D_EQ on the card: the earlier write to the same bucket ends at most about
600 + 3,892 + 2,485 (`AR_WB`) + 1,024 + its acknowledgement after the earlier start, so ≈ 6,000 + 600 after this one's
start is the gate; C4 at issue is the fail-stop if a write is later still.

**14.6 Data dependency.** What a later access reads, and when:
- a later read only ever issues at or after its fixed gate, never earlier, so every earlier write's position relative
  to it is what the fixed schedule gives, and C4 is checked at the actual issue;
- read data returns in issue order (both burst records), and every landed beat, arrival and record read is attributed
  to its own context (`rd_ctx`, `done_ctx`, `b_ctx`), so a beat can never be written into another access's scratch;
- the scratch buffer it lands in is checked free at issue;
- the bucket record is re-read after every earlier write to it (14.3), and a record or position-map write landing in
  the cycle of a take is passed through;
- the write-backs stay in access order on one write engine.

**14.7 What the fixed-schedule check found, and the keyed check (`check_fixed_schedule.py --ctx 1`).** With two reads
in flight, on-package accesses showed two visible shapes (release and end 47 cycles apart, at the simulated latencies):
- **Cause:** an on-package read issued while the previous access's host read was still arriving. Its data waits in the
  in-order read port behind that read's last beats. This happens when the previous bucket is off package and the
  current one on package, and the current one is not same-bucket shifted.
- **Why it is allowed:** it is a function of where the two random buckets live (public: the address trace shows it) and
  of the host memory's latency. It does not depend on the keys, the data or the stash.
- **On the card:** with P = 2,150 and the read gate at 600, the previous host read has normally ended (median 1,490
  after its gate) before the on-package read issues. It overlaps only on a slow host read.

The check now keys each access's class by its own and the previous access's public facts (on or off package,
same-bucket flag). At the simulated latencies it finds 13–14 classes and 3 shapes in all:
- off package;
- on package after an off-package read still arriving;
- every other on-package access.

Within each class the shape is exactly one, in every run and across runs, and the injected leak is still detected.
Step 1 (`OV=2`) keeps the unkeyed check.

**14.8 Netlist check of the read unit (`sim/run_rd2_netlist.sh`).** The new read unit holds two small register arrays:
the burst record (1 bit × 32) and the two contexts. Each has one writer. Per the rule from v14d's staging bug, it is
still checked at netlist level:
- `axi_rd2` with both `axi_master` copies is synthesized by Yosys to gates and run in lock step with the RTL
  (`tb_rd2.v`), with random commands and a random in-order AXI read slave;
- every output must be equal every cycle, and every read's beats must reach its own context, in order, with its own
  bucket's data.

Result: 4 seeds × 400,000 cycles, about 312 reads per seed, two reads in flight on 99.5% of cycles, 0 errors.
The kernel's per-burst R record (`rs_q`, 32 × 1 bit, one writer) is exercised by every kernel testbench run above.

**14.9 v14d1 and step 1 unchanged.** With `ORAM_OVERLAP4` off, `flat_oram_gcm.v`, `doma_kernel.v` and
`secure_oram_top.v` preprocess identically to the delivered Option A package (`verilator -E -P`, blank lines dropped):
768 of 768 comparisons, 3 files × 256 combinations of the 8 switches. That package itself preprocesses identically to
v14d1 without the switches.

**14.10 Regression, 2026-11-04 (`docs/overlap_regression_step2_rd2_2026-11-04.txt`): 39 passed, 0 failed.**
- **Correctness:** every run (simulation parameters and card parameters, with and without host read tails, 0/20/50/100%
  on package, one key, ABAB, keys in turns of 3 and 4, card-like stash) returns every response correctly, with 0 wrong
  evicted beats and no halt.
- **Leak:**
  - paired streams give identical visible hashes (simulation latencies, and card parameters under random read tails);
  - the injected leak is detected by the hashes in both settings and by the fixed-schedule check;
  - fixed schedule (keyed by the previous access, 14.7): exact in all 15 runs and across 12 runs.
- **Throughput** (cycles per access):
  - simulation parameters: 1,600–1,720, against v14d1's 4,924–5,138 in the same runs;
  - card parameters under host read tails: 2,446 at 20% on package and 2,350 at 100% (≈ 123–128 KQPS at 300 MHz).
- **Read unit netlist:** 4 of 4 seeds pass (14.8).
- **Identity:** 768 of 768 comparisons pass (14.9).

**Build (card), in `vitis/`:**

    OVERLAP=4 SCHED=arrival BEATS=128 CFG=doma_big2m.cfg NMAX=2097152 LAMBDA=7 TARGET=hw bash build.sh
    ./check_timing.sh

`build.sh` prints the configuration it wrote. It must show `ORAM_OV_P 2150`, `ORAM_OV_CT_RD 600`, `ORAM_OV_DEQ 6000`
and `ORAM_OV4_GA 1500`. After the build, `check_overlap_build.sh` also requires both bucket read copies
(`g_rd[0]`, `g_rd[1]`) in the placed design. Timing: the redesign was not yet checked for 300 MHz; the earlier step 2
closed at 283 MHz.

**Still open in step 2:**
- the on-package write-back still starts when the decisions end (stash-dependent, as in v14d1); Option A for step 2 is
  phase 3;
- 300 MHz timing.

**14.11 After the regression (2026-11-04).**
- **Step 1 unchanged:** `OV=2 run_overlap.sh` passed 32 of 32, with the same throughput.
- **Mock XRT at the card parameters:** buckets in host memory at the card's 467-cycle read latency, at 0% and 20% on
  package. The unmodified `host_doma` (4,096 keys, 5,000 commands) reported ALL RESPONSES CORRECT with 0 errors, in
  10.94 M device cycles: about 2,190 cycles per command, ≈ 137 KQPS at 300 MHz.
- **Logic depth** (`ys_depth.sh step2`): the maximum is 13.40 (`trf_beat`, v14d1's own path). The new logic is shallower:

| New path | Depth |
|---|---|
| The read unit's burst-record write enable (`u_axi_rd.rq`, through ARREADY) | 11.15 |
| The kernel's R record (`rs_q`) | 10.15 |
| The read issue (`rp`) | 9.95 |

  All of these are below v14d1's deepest paths, which are 13.4–13.9. The known step 2 timing risk is unchanged: the
  scratch and result read data pass a 4:1 mux after the block RAM (section 11).

## 15. Round 2 on the card: all-zero GETs, and the fix (2026-11-05)

**What the card showed.** The round 2 build (`fpga_zcu208_ov4rd2_v14c`, 254 MHz) returned an all-zero data slot for
every GET from the first command, at 0%, 20% and 100% on package and at 4,096 and 1M records. There was no halt and
no integrity error. Speed matched the mock (about 2,200 cycles per command).

The `host_doma` diagnosis mode (`DOMA_DIAG=1`) narrowed it down:
- the kernel wrote each GET's data slot, and it was zero;
- at 100% on package, right after the preload, the on-package buckets were entirely zero (0 of 19,202,048 bytes);
- of the first 64 preloaded values, 43 were still in the stash pool and 21 were nowhere.

**Cause.** The kernel's synthesis log has `Synth 8-3848: Net g_scr[k].scr_ev_wr_addr / scr_ev_wr_data / scr_ev_wr_en
does not have driver` (k = 0..3):
- step 2 instantiates the four scratch buffers inside a generate block (`g_scr`), and their eviction-copy write port
  names `scr_ev_wr_*`;
- those signals were declared at module level about 450 lines further down;
- Verilator, Yosys and every testbench resolve such a name to the later module-level declaration;
- Vivado creates a new, undriven net local to the generate block instead.

So on the card no eviction copy ever reached the scratch, and every bucket was written back without its evicted
blocks. Off package the empty buckets were encrypted with valid tags, so no integrity check fired. Step 1 was not
affected: its scratch buffers are instantiated at module level, where Vivado does resolve the later declaration.

Tying the eviction write to 0 in simulation, which is what Vivado built, reproduces the card: all-zero GETs, and the
eviction scoreboard reporting zeros where the evicted blocks' data should be.

**Fix (`rtl/flat_oram_gcm.v`, step 2 only).** `scr_ev_wr_addr`, `scr_ev_wr_data` and `scr_ev_wr_en` are declared
before the generate block. Without `ORAM_OVERLAP4`, every RTL file preprocesses exactly as before.

**New checks.**
- `sim/check_gen_decl.sh`: reports any name used inside a generate block before its declaration. It covers every RTL
  file in 7 build configurations, preprocessed as Vivado sees them (`SYNTHESIS`). On the round 2 RTL it reports
  exactly these three nets; on the fixed RTL, none. It runs first in `run_overlap.sh`.
- `sim/run_overlap_host.sh`: the card's own `host_doma` (unmodified, `DOMA_DIAG=1`) against the Verilated kernel in
  the XRT mock, at the card parameters, with buckets in host memory at 467 cycles, at 0%, 20% and 100% on package.
  Every response is checked, as on the card.
- `vitis/host_doma.cpp`, `DOMA_DIAG=1` (diagnosis only):
  - it fills the response data slots with `A5` before each launch, and prints what the first wrong GETs' slots hold
    and where the expected value is;
  - at 100% on package it searches the on-package buckets and the stash pool for the preloaded values.

## 16. Round 4: timing toward 300 MHz (2026-11-05)

**What limited round 2 and 3 (254 MHz, WNS −0.594 ns at 300).** From the card's `worst_groups`:
- most failing paths start or end at the four scratch buffers (128 block RAMs across the die);
- their reads went from block-RAM output, through the 8:1 bank select and the 4:1 context select, into six consumers:
  the result, stash and scratch copy registers, both cores' data inputs, and the write master's W registers. Even the
  3-level ones miss by 0.58 ns;
- the write-back context `w_par` reached the block RAMs' enables through the hold rule (7 levels);
- the read unit's burst-record head drove RREADY into the platform and the kernel's traffic counter (13 levels);
- the kernel's R-routing head;
- the request buffers' writes, straight from the platform's read channel;
- the read context into the arrival adder.

**Changes (step 2 only).**
- **`scratch_buf` `OREG=1`** (the default 0 keeps every other build as it was): the banks' block-RAM output registers
  are used, so both read ports return data two cycles after the read, and their valids follow. The step 2 readers:
  - **the decryption feed** (`fd_v` three deep), **the encryption feed** (`e_fd_v` three deep); the queue rule
    (`rd_lin < wr_lim`) counts beats read and not yet written back, so it holds with the deeper pipeline;
  - **the copies** (`S_CP`) are driven by the read valid: unchanged;
  - **the write-back** (`rtl/wb_pf.v`, new):
    - axi_master's write path assumes a one-cycle scratch, so `wb_pf` reads the bucket's beats in order, at most
      three ahead of the master, into a four-beat buffer;
    - it answers the master as a one-cycle scratch would;
    - the master's hold also covers "not yet prefetched", and the overrun checks keep the original hold's stall
      alone;
    - its reads follow the same position rule as the hold, a cycle late (the positions only ever grow);
    - its scratch read request is a register, decoded per scratch from `w_par` delayed by a cycle;
    - **schedule:** measured against round 3, access by access (45 accesses, same run): every write's first W beat
      is 3 cycles later and its last 4 cycles later. The bucket address and read beats, the write address, and the
      release and end of both classes are unchanged. It is a fixed shift, the same for every access.
- **`axi_rd2`:** the record's head and "not empty" are registers, computed from this cycle's push and pop, with a
  burst count. RREADY is one gate.
- **Kernel:** the R-routing head is a register, computed the same way.
- **Top:** a request buffer's filling beat is written one cycle after it arrives. The access's PUT flag to the
  controller is a register; its data is read only long after the request is taken.
- **Controller:**
  - the arrival time is captured per context, with no select in front of the adder;
  - the boot's "bucket count known" condition is a cycle late.

**Logic-depth proxy** (`ys_depth.sh step2`; the block RAMs and `axi_master` are black boxes): the new logic reaches at
most 11.3 (the record's write pointer and count); the maximum, 13.4–13.6, is v14d1's own (`trf_beat`,
`bkt_slot_list`, `bm_wr_slot_list`). The block-RAM paths themselves only show in Vivado; the output registers remove
the block RAM's clock-to-output from all of them.

**Regression, 2026-11-05 (`docs/overlap_regression_step2_r4_2026-11-05.txt`):**
- **`OV=4 run_overlap.sh`:** 40 of 40 pass. That covers correctness, the paired-stream and injected-leak checks at
  the simulated and card parameters with host read tails, the fixed schedule in every run and across runs, and the
  generate-scope check. Throughput is unchanged (the start spacing sets it).
- **`run_overlap_host.sh`:** `host_doma` at 0%, 20% and 100% on package, all responses correct.
- **`run_rd2_netlist.sh`:** 4 of 4 pass.
- **Identity:** with step 2 off, all three RTL files preprocess exactly as in round 3 (768 of 768).

## 17. Phase 3: starts and same-bucket reads after the arrivals (`ORAM_OV4_P3`, `build.sh OVERLAP=4 P3=1`)

**Why.** In round 4 the start spacing P (2,150) had to budget for the worst host read: a context is reused four
accesses later, and its read, release and result must all fit in 4P. In phase 3 the start waits on the arrival
instead, so a slow read delays later starts by exactly its own lateness, and P is no longer sized for the tail.

**Rules** (t′ is the effective arrival, section 14.4: a function of the memories' latencies and public constants):
1. **Start.** s(j) = max( s(j−1) + OV_PMIN, t′(j−4) + OV_L, request(j), the read issue of any of j−3..j−1 that reads
   j−4's bucket ).
   - j−4 is the context's previous access. OV_L covers its release, result and write acknowledgement.
   - The last term keeps that access's state until its same-bucket readers have issued; their gate needs it.
   - All four terms are public:
     - starts;
     - arrivals;
     - requests: every command fills its data slot, GET or PUT (`UNIFORM_FILL`);
     - same-bucket flags.
2. **Same-bucket read gate.** The read issues at max( s + CT_RD, t′(e) + OV_LEQ ) for every earlier access e with
   the same bucket. OV_LEQ covers e's write-back at t′(e) + AR_WB, streamed and acknowledged. The next start is no
   longer shifted. "Every earlier same-bucket write acknowledged" (C4) is still checked at the actual issue, as a
   fail-stop.
3. **Every write-back at exactly t′ + AR_WB, on or off package** (Option A in step 2). A held beat, meaning a late
   eviction copy, is now a fail-stop on package too.
   - The on-package bucket channels (HBM[16:31]) see writes only at public times, so on-package arrivals, which
     now drive starts, cannot carry the stash's timing.
   - The stash is on HBM[12:15] and the records on HBM[10:11], separate channels (`doma_big2m.cfg`).
   - With arrivals at least OV_GA apart and one write slot per access, writes never overlap on the one write
     engine.
4. **Unchanged:**
   - the read gate s + CT_RD and the lookup by it (fail-stop);
   - the arrival spacing;
   - the accept checks (the context four back finished: fail-stop);
   - reads issued in access order, waiting only while both read copies are busy;
   - results in order.

**Defaults** (`AR_*` as in section 14):

| Parameter | Value |
|---|---|
| OV_PMIN | 1,500 |
| OV_LEQ | AR_WB + 1,024 + 300 = 3,809 |
| OV_L | max(AR_REL_H, AR_REL) + 250 = 4,034, and at least OV_LEQ + 2 |

**Exact schedule check (`sim/check_p3.py`).** Every access's visible times are recomputed from public events alone:
- **inputs:** the starts, requests, read completions (memory latency) and same-bucket masks;
- **recomputed:** the start, the read issue, the write-back issue, the release (each class) and the end;
- **rule:** each must match exactly for every access of every run. Each term has one fixed pipeline offset, fitted
  once over all runs;
- **coverage:** it also reports how many accesses each term decided alone, so a term the runs never exercise is
  visible;
- **leak test:** the injected-leak build (a PUT's read one cycle late) must fail it.

The testbench's `+fix_dump` adds each access's read issue, read completion, write-back issue and same-bucket mask.

**Regression: `OV=5 bash sim/run_overlap.sh`.** It runs the step 2 set with phase 3. On top of that it adds:
- small-tree runs (`+nblk=64/48/32`), so same-bucket accesses are frequent;
- the exact schedule check, at the simulation and at the card parameters under host read tails;
- the paired-stream and injected-leak checks, and phase 3 paired streams on a small tree with read tails.

`OV=5 bash sim/run_overlap_host.sh` runs the card's own `host_doma` on phase 3.

**What phase 3 changes for leak testing.** With a fixed start spacing, a delay in one access stayed in that access.
In phase 3 later starts follow the arrivals, so any delay of a read carries into the accesses after it. A
secret-dependent delay anywhere would therefore be amplified, not absorbed, which makes the two whole-schedule checks
the important ones:
- the paired streams (0/50/100% PUTs, identical visible hashes, with host read tails and on a small tree);
- the exact rule check (`check_p3.py`), which allows no input but public events.

The injected leak (a PUT's read one cycle late) shows the effect. Its build differs from the normal build even in a
run without PUTs, because the preload's PUTs shifted the later starts. With no PUT anywhere (no preload) the two are
identical, so the regression compares those runs.

**Phase 3 results, 2026-11-05 (`docs/overlap_regression_p3_2026-11-05.txt`):**
- **`OV=5 run_overlap.sh`:** 49 of 49 pass.
  - every response correct, including the small trees with frequent same-bucket accesses;
  - the exact schedule check: 10,434 accesses at the simulation parameters and 5,320 at the card parameters under host
    read tails, 963 of them same-bucket;
  - paired streams and injected-leak detections, at both parameter sets;
  - the generate-scope check.
- **Throughput** (cycles per access, against round 4):
  - card parameters under host read tails: 1,842 at 20% on package (2,446) and 1,557 at 100% (2,350), so about
    163–193 KQPS at 300 MHz;
  - simulation parameters: 1,558–1,635.
- **`OV=5 run_overlap_host.sh`** (on the laptop): `host_doma` at 0%, 20% and 100% on package, all responses correct.
- **Identity with phase 3 off:**
  - all RTL files preprocess exactly as in round 4 (60 of 60, five step 2 configurations, with and without
    `SYNTHESIS`);
  - the non-step-2 builds exactly as in round 3 (768 of 768).
- **Logic depth** (`ys_depth.sh step2p3`): no new path is deeper than round 4's. The maximum, 13.6, is v14d1's own.

**Build:** `OVERLAP=4 P3=1 SCHED=arrival BEATS=128 CFG=doma_big2m.cfg NMAX=2097152 LAMBDA=7 TARGET=hw bash build.sh`

**Margin settings (`build.sh`, 2026-11-05).** Phase 3's margins depend on the host's write acknowledgement, which has
not been measured on the card. With the defaults, back-to-back write-backs at 1,500 cycles need it within about 450
cycles of the last beat, OV_LEQ assumes about 300 and OV_L about 525. `build.sh` now takes `OV_LEQ` and `OV_L` (cycles
after the effective arrival; unset: the defaults above; values below the defaults, or OV_L < OV_LEQ + 2, are refused)
next to `OV_PMIN` and `OV_GA`. All four are public constants: they move every visible time by a fixed amount and add
no input to the schedule. Two margin variants, built next to the default:

| Variant | OV_PMIN | OV_GA | OV_LEQ | OV_L | write ack covered (about) | throughput bound at 300 MHz |
|---|---|---|---|---|---|---|
| default | 1,500 | 1,500 | 3,809 | 4,034 | 300 cycles | 200 KQPS |
| mid (`m`) | 1,700 | 1,700 | 4,109 | 4,334 | 600 cycles | 176 KQPS |
| wide (`w`) | 1,950 | 1,950 | 4,609 | 4,834 | 900 cycles | 154 KQPS |

`OV=5 P3_TAG=m P3_PMIN=1700 P3_GA=1700 P3_LEQ=4109 P3_L=4334 bash sim/run_overlap.sh` (and the same for `w`) runs the
phase 3 regression with a variant's card parameters (logs in `sim/build/ov5<tag>/`).

Margin variants, regression 2026-11-05 (`docs/overlap_regression_p3m_2026-11-05.txt`, `_p3w_`): 49 of 49 pass for each,
the exact schedule check at each variant's parameters included. Cycles per access, card parameters under host read
tails, 20% / 100% on package: default 1,842 / 1,557; mid 1,939 / 1,750; wide 2,140 / 1,998; round 4 2,446 / 2,350.

## 18. The card slip of phase 3 (2026-11-05): results lost by the kernel's completion side

**Card symptom** (p3mid and p3wide, 300 MHz, 4,096 records, every bucket on package): from about command 1,816 every
GET returned the value of the NEXT command's key (a real current value), with no halt, and later a command never
completed (0x10).

**Cause** (`rtl/doma_kernel.v`, every step 2 build, round 4 included). DOMA pushes each result at a fixed time
(release + a constant), with no backpressure. The kernel's completion side had one result buffer and took a result
(`c_done`, and its beats) only while it was waiting for it (`KC_WAIT`). A result that landed while the previous response
was still being written to the response memory (HBM[7]) was dropped: its done was never seen, so every later response
carried the next command's result, and the launch's last command timed out. Results of consecutive accesses come at
least about GA apart (t' + AR_REL(_H)); in round 4 they were usually P = 2,150 apart and only rarely closer, in phase
3 they are usually OV_PMIN apart (1,500 to 1,950), so a response write that is occasionally slower than that on the card
became frequent enough to show.

**Reproduced** in simulation with the response memory slowed (`+resp_whold=1800`: wready low 1,800 cycles after each
response write address): wrong GETs carrying a later command's value (`tb_doma_kernel` now names the command whose
value came back), then status 0x10, exactly as on the card.

**Fix** (step 2 builds only; `ORAM_OVERLAP4`): one result buffer per command at DOMA (`rbuf` four times, by the
command's place in the command queue), and every result counted when it lands (`rin_p`, `dq_n`, `dn_t`), whatever the
completion side is doing. Results already come in command order (DOMA fail-stops otherwise), and at most four commands
are between issue and write-out (`CQ_D`), so four buffers always suffice. The controller and the top are unchanged
(byte-identical files); DOMA's schedule and every visible bus time are unchanged. The non-step-2 builds preprocess
exactly as before (768 of 768).

**Security.** The completion side now absorbs any response-write latency instead of losing data. A slow response
memory delays the kernel's next requests (the command queue is full), and phase 3 starts follow the requests; request
times are public inputs to the schedule, and response-memory latency depends on no secret. The exact schedule check
covers runs with slow response writes (`rw20`, `lmix`).

**Card-side measurement.** In step 2 builds the traffic record's bytes 24-27 count the results that landed while an
earlier response was still being written (each one was lost before the fix), and bytes 28-31 hold the longest
response write in cycles; `host_doma` prints both.

**Regression additions** (`run_overlap.sh`, OV=4 and OV=5): `rw100` (every bucket on package, response writes held
1,800 cycles), `rw20` (20%, response writes held 2,500 cycles, on-package bucket and command read tails), `lmix` (four
launches of 900 commands under mixed latencies and response backpressure); no `KERNEL OVERLAP` warning in any run; and
`rw100` must have had late results. `tb_doma_kernel` takes `+launches=K` (K launches of `+cmds` commands, fresh keys,
every GET checked), `+resp_whold`, `+resp_rdy`, `+cmd_slow_pct/extra` and `+hbmb_slow_pct/extra`.
`sim/run_slip_long.sh` runs eight long mixed-latency runs (40 launches x 900 commands each by default).

A first version of the fix still reset the arriving result's beat count when a response's write-out ended, so a
result that was arriving at that moment landed shifted (`rw20`: one GET returned its own beat 127 as beat 0). Fixed:
the count restarts only at each result's done; the testbench flags any result that is neither a whole block nor
empty.

## 19. The card's integrity halts (0x208) of phase 3: a same-bucket read before the host write is readable

**Card symptom.** At 20% on package, integrity halts after about 4,900 commands (low, OV_PMIN 1,500), 52,000 (mid)
and 25,000 (wide) at 4,096 records, and 66,000 at 1M records (mid).

**Not a slow read.** Phase 3 low with host reads at the card's worst (5% of bursts 3,400 cycles slower, about 3,880
in all) ran 7,200 commands, every GET correct. A context is reused only after its previous access's arrival plus OV_L,
and the reuse fail-stops if anything of that access is pending.

**Cause.** A posted PCIe write can be acknowledged before a later read sees its data. Phase 3's same-bucket gate let
a read of the same bucket issue at t'(e) + OV_LEQ, OV_LEQ = AR_WB + 1,024 + 300: 300 cycles after the earlier write's
last beat (mid 600, wide 1,100). Round 4 left more than 3,000 (D_EQ 6,000) and never halted. With host writes made
readable 2,500 cycles after their acknowledgement (`+host_bearly=2500`), phase 3 low reads the stale bucket and halts
with the integrity failure, exactly as on the card; at 300 or 1,500 cycles it passes (the read of a bucket streams at
the same rate as its write landed). Counting the 1M-record preload's accesses, every card failure came after a similar
number of same-bucket host reads (about 17 to 230), so the 1M point fits too.

**Fix.** OV_LEQ's default is now AR_WB + 1,024 + 3,300 = 6,809 (about round 4's margin), and OV_L no longer follows
it (default 4,034): a context whose access still has same-bucket readers waiting is held by the start rule's own
term until they have issued (`eq_hold`), so only same-bucket accesses wait longer. Both are public constants; the hold
depends on bucket equality alone. `build.sh` refuses OV_LEQ below 3,809 and OV_L below 4,034, and no longer ties them.

**Regression.** `hbe` (20%, small tree) and `hbe0` (off package): host writes readable 2,500 cycles after their
acknowledgement, every GET correct, exact schedule; negative control `ovcq hbe`: the same run with the old OV_LEQ
3,809 must halt with the integrity failure.
