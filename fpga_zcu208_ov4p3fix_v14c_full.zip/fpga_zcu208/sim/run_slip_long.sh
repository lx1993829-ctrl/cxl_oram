#!/bin/bash
# run_slip_long.sh -- long phase 3 runs looking for the card's integrity halt (0x208) and any result slip
# (docs/overlap_rtl_spec.md section 18). One step 2 phase 3 testbench at a card parameter set, then J runs at a time,
# each LAUNCHES launches of 900 commands (fresh keys every launch, every GET checked against its own command), under
# mixed latencies: host reads 480 cycles with 3% of bursts 1,500 slower and 15% empty beat cycles, on-package bucket
# reads with 3% 1,200 slower, command reads with 2% 800 slower, HBM read gaps, and slow response writes. Each run stops
# at its first failing launch; the summary lists every run's launches, commands and first failure.
# Usage: bash run_slip_long.sh [jobs] [launches]        (defaults: nproc, 40 -> 36,000 commands per run)
#        P3_PMIN=1700 P3_GA=1700 P3_L=4334 bash run_slip_long.sh ...   (defaults: the low variant, 1500, 1500 and the
#        RTL defaults of LEQ (6809 since section 19) and L (4034): on the card the low variant failed soonest)
#        Two of the eight runs make host writes readable only 2,500 / 3,000 cycles after their acknowledgement.
#        HOST_SLOW_PCT=5 HOST_SLOW_EXTRA=3400 (defaults): host read bursts this much slower (the card measured reads up
#        to 3,892 cycles; 480 + 3,400 = 3,880)
#        SEEDS="101 102 103 104" bash run_slip_long.sh ...                          (default: 8 seeds)
set -u
cd "$(dirname "$0")"
RTL=${RTL_DIR:-../rtl}; J=${1:-$(nproc)}; NL=${2:-40}
PM=${P3_PMIN:-1500}; GA=${P3_GA:-1500}; LEQ=${P3_LEQ:-0}; L=${P3_L:-0}
HSP=${HOST_SLOW_PCT:-5}; HSX=${HOST_SLOW_EXTRA:-3400}
O=build/slip_${PM}_${HSX}; mkdir -p $O
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
echo "== building phase 3 at PMIN $PM, GA $GA, LEQ $LEQ, L $L (0: the RTL default); host read tails $HSP% +$HSX cycles"
verilator --binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -I$RTL \
  -DORAM_BLOCK_BEATS=128 -DORAM_C=7 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -Wno-BLKANDNBLK \
  -DORAM_OVERLAP2 -DORAM_OVERLAP4 -DORAM_OV4_P3 -DORAM_OV_PMIN=$PM -DORAM_OV_CT_RD=600 -DORAM_OV4_GA=$GA \
  -DORAM_OV4_LEQ=$LEQ -DORAM_OV4_L=$L \
  --top-module tb_doma_kernel tb_doma_kernel.v oram_timing_monitor.v axi_mem_model.v $SRCS $RTL/doma_kernel.v \
  -Mdir $O/v -o V > $O/build.log 2>&1 || { echo "BUILD FAILED ($O/build.log)"; exit 1; }
M="+hb=0 +host_lat=480 +host_wlat=98 +host_slow_pct=$HSP +host_slow_extra=$HSX +host_gap=15 +hbmb_slow_pct=3 +hbmb_slow_extra=1200"
M="$M +cmd_slow_pct=2 +cmd_slow_extra=800 +hbm_gap=10"
SEEDS=${SEEDS:-"101 102 103 104 105 106 107 108"}
: > $O/jobs.txt
i=0
for s in $SEEDS; do
    case $((i % 8)) in            # on-package share and response-write stress vary (the card failed at 20%)
        0)   X="+hbm_pct=20" ;;
        4)   X="+hbm_pct=20 +host_bearly=2500" ;;
        1|5) X="+hbm_pct=20 +resp_rdy=20" ;;
        2)   X="+hbm_pct=20 +resp_whold=2500" ;;
        3)   X="+hbm_pct=50 +resp_rdy=30" ;;
        6)   X="+hbm_pct=10 +host_bearly=3000" ;;
        7)   X="+hbm_pct=100 +resp_whold=1800" ;;
    esac
    echo "s$s $M $X +preload +seed=$s +cmds=900 +launches=$NL +cmds2=4 +put_pct=50" >> $O/jobs.txt
    i=$((i + 1))
done
echo "== running $(wc -l < $O/jobs.txt) runs of $NL launches x 900 commands, $J at a time ($(date))"
O=$O xargs -P $J -L 1 bash -c 'n=$0; ./$O/v/V "$@" > $O/$n.log 2>&1; echo "  done $n $(date +%H:%M)"' < $O/jobs.txt
echo "== summary"
fail=0
while read -r n rest; do
    l=$O/$n.log
    nl=$(grep -cE '^(run1|runL): size' $l); nc=$(grep -E '^(run1|runL): size' $l | sed -E 's/.*completed=([0-9]+).*/\1/' | paste -sd+ | bc)
    late=$(grep -E '^(run1|runL): completion side' $l | sed -E 's/.*side: ([0-9]+) results.*/\1/' | paste -sd+ | bc)
    if grep -q "ALL CHECKS PASSED" $l && ! grep -q "KERNEL OVERLAP" $l; then
        echo "PASS  $n: $nl launches, $nc commands, $late results landed during an earlier response write ($(echo $rest | grep -oE '\+hbm_pct=[0-9]+|\+resp_[a-z]+=[0-9]+|\+host_bearly=[0-9]+' | tr '\n' ' '))"
    else
        fail=$((fail + 1))
        echo "FAIL  $n: after $nl launches, $nc commands ($l)"
        grep -E "DOMA HALT|integrity|FAIL|KERNEL OVERLAP|slip by" $l | head -6 | sed 's/^/      /'
    fi
done < $O/jobs.txt
echo "== $fail failing runs"
[ $fail = 0 ]
