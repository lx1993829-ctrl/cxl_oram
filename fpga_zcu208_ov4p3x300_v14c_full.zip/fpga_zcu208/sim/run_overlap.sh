#!/bin/bash
# run_overlap.sh: overlap step 1 (ORAM_OVERLAP2, two accesses in flight) regression, 4 KB blocks, lambda 7.
# Builds three kernel testbenches (v14d1 = base, overlap = ovf, overlap with the injected leak = ovl), runs the set below
# in parallel, and checks:
#   - every run: all responses correct, eviction scoreboard 0 wrong, no halt (ALL CHECKS PASSED), except as noted;
#   - paired streams (same keys and arrivals, different GET/PUT mix): identical visible hashes (bucket-port timing,
#     folded off-package shape, on-package release/end) for p0/p50/p100, same-key sk0/sk100, ABAB ab0/ab50;
#   - the injected leak (TB_OV_LEAK, a PUT's read one cycle late) changes the hashes between l0 and l100;
#   - on-package release/end hash equal to v14d1 (c1, 100% on package);
#   - fixed schedule (check_fixed_schedule.py, every overlap run): every access's visible times relative to its start,
#     with the public same-bucket shift taken out, are one fixed shape per class (off / on package), the same in every
#     run with the same memory latencies (random keys, one repeated key, ABAB, keys in turns of 3 and 4, card-like
#     stash); every start follows s(j) = max(request + K1, s(j-1) + P (+ D_EQ) + K2) exactly; the injected-leak build
#     must fail it;
#   - throughput against v14d1.
# Usage: bash run_overlap.sh [jobs]      (default jobs = nproc). Logs: build/ov/. About 20-40 min on 8 cores.
#        OV=4 bash run_overlap.sh [jobs]  step 2 (ORAM_OVERLAP4, four in flight, two bucket reads in flight): the same
#        set and checks, except the comparison with v14d1's per-access times (step 2 has larger write-back and release
#        allowances), and with the fixed-schedule shape keyed by the previous access's public facts too (--ctx 1: reads
#        return in issue order, so an on-package read can wait behind a host read still arriving). Also builds step 2 at
#        the card's parameters (build.sh OVERLAP=4 defaults) and runs it under card-like host read tails (3% of bursts
#        1,500 cycles slower, 15% empty beat cycles): correctness, paired streams 0/50/100% PUTs with identical visible
#        hashes, and the injected leak detected. Logs: build/ov4/.
set -u
cd "$(dirname "$0")"
RTL=${RTL_DIR:-../rtl}; J=${1:-$(nproc)}
OV=${OV:-2}
if [ "$OV" = 5 ]; then O=build/ov5${P3_TAG:-}; XD="-DORAM_OVERLAP2 -DORAM_OVERLAP4 -DORAM_OV4_P3"      # step 2, phase 3
elif [ "$OV" = 4 ]; then O=build/ov4; XD="-DORAM_OVERLAP2 -DORAM_OVERLAP4"; else O=build/ov; XD="-DORAM_OVERLAP2"; fi
mkdir -p $O
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
build() {   # build <dir> [defines]
    local d=$1; shift
    verilator --binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -I$RTL \
      -DORAM_BLOCK_BEATS=128 -DORAM_C=7 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -Wno-BLKANDNBLK "$@" \
      --top-module tb_doma_kernel tb_doma_kernel.v oram_timing_monitor.v axi_mem_model.v $SRCS $RTL/doma_kernel.v \
      -Mdir $O/$d -o V > $O/build_$d.log 2>&1 && echo "built $d" || { echo "BUILD FAILED $d ($O/build_$d.log)"; exit 1; }
}
echo "== Vivado generate-scope check (check_gen_decl.sh)"
GD=$(bash check_gen_decl.sh $RTL 2>&1); echo "$GD" | tail -1
echo "== building (3 testbenches)"
build base; build ovf $XD; build ovl $XD -DTB_OV_LEAK   # one at a time (parallel verilator builds can exhaust memory)
DIRS="base ovf ovl"
if [ "$OV" -ge 4 ]; then   # step 2 at the card's parameters, under card-like host read tails (two reads in flight, arrival spacing)
    CP="-DORAM_OV_P=2150 -DORAM_OV_CT_RD=600 -DORAM_OV_DEQ=6000 -DORAM_OV4_GA=1500"   # build.sh OVERLAP=4 defaults
    # build.sh OVERLAP=4 P3=1 defaults, or its OV_PMIN / OV_GA / OV_LEQ / OV_L settings (P3_PMIN, P3_GA, P3_LEQ, P3_L;
    # P3_TAG names the log folder build/ov5<tag>)
    [ "$OV" = 5 ] && CP="-DORAM_OV_PMIN=${P3_PMIN:-1500} -DORAM_OV_CT_RD=600 -DORAM_OV4_GA=${P3_GA:-1500} -DORAM_OV4_LEQ=${P3_LEQ:-0} -DORAM_OV4_L=${P3_L:-0} -DORAM_OV4_XWB=${P3_XWB:-700} -DORAM_OV4_XREL_H=$(( ${P3_XWB:-700} + 700 ))"
    build ovc $XD $CP; build ovcl $XD $CP -DTB_OV_LEAK; DIRS="$DIRS ovc ovcl"
    # phase 3 with the old same-bucket gap (OV_LEQ 3809, 300 cycles after the write's last beat): the negative control of
    # the late-landing host write case (2026-11-05, section 19)
    [ "$OV" = 5 ] && { build ovcq $XD $CP -DORAM_OV4_LEQ=$(( 1785 + ${P3_XWB:-700} + 1324 )) -DORAM_OV4_L=4034; DIRS="$DIRS ovcq"; }
fi
for d in $DIRS; do [ -x $O/$d/V ] || { echo "missing $O/$d/V"; exit 1; }; done
H="+hb=0 +host_lat=401 +host_wlat=98"
cat > $O/jobs.txt <<EOF
ovf p0 $H +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=0
ovf p50 $H +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=50
ovf p100 $H +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=100
base p50 $H +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=50
ovl l0 $H +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=0
ovl l100 $H +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=100
ovf sk0 $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +same_key=120 +put_pct=0
ovf sk100 $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +same_key=120 +put_pct=100
ovf ab0 $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +abab_key=120 +put_pct=0
ovf ab50 $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +abab_key=120 +put_pct=50
ovf k3a $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +cyc_key=120 +cyc_n=3 +put_pct=0
ovf k3b $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +cyc_key=120 +cyc_n=3 +put_pct=100
ovf k4a $H +hbm_pct=50 +preload +cmds=120 +cmds2=4 +cyc_key=120 +cyc_n=4 +put_pct=30
ovf c0 $H +hbm_pct=0 +preload +cmds=200 +cmds2=4 +seed=5
base c0 $H +hbm_pct=0 +preload +cmds=200 +cmds2=4 +seed=5
ovf c1 +hb=0 +hbm_pct=100 +preload +seed=3 +cmds=200 +cmds2=4
base c1 +hb=0 +hbm_pct=100 +preload +seed=3 +cmds=200 +cmds2=4
ovf cs $H +hbm_pct=20 +preload +cmds=200 +cmds2=4 +stash_gap=40 +stash_pcs=390 +stash_idblk=1 +stash_lat=120 +stash_slow_pct=0
base cs $H +hbm_pct=20 +preload +cmds=200 +cmds2=4 +stash_gap=40 +stash_pcs=390 +stash_idblk=1 +stash_lat=120 +stash_slow_pct=0
ovf j2 +hb=0 +junk_mem +host_lat=263 +host_wlat=98 +hbm_pct=20 +preload
ovf c3 +hb=0 +hbm_pct=50 +cmds=200 +cmds2=10 +host_lat=263 +host_wlat=98 +seed=7
EOF
if [ "$OV" -ge 4 ]; then
    # host reads 480 cycles, 3% of bursts 1,500 slower, 15% of beat cycles empty: the same latency stream in each pair
    T="+hb=0 +host_lat=480 +host_wlat=98 +host_slow_pct=3 +host_slow_extra=1500 +host_gap=15 +seed=11"
    cat >> $O/jobs.txt <<EOF2
ovc t0 $T +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=0
ovc t50 $T +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=50
ovc t100 $T +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=100
ovc tsk $T +hbm_pct=20 +preload +cmds=150 +cmds2=4 +same_key=150 +put_pct=50
ovc tab $T +hbm_pct=50 +preload +cmds=150 +cmds2=4 +abab_key=150 +put_pct=50
ovc tc100 +hb=0 +hbm_pct=100 +preload +seed=3 +cmds=200 +cmds2=4 +put_pct=50
ovcl tl0 $T +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=0
ovcl tl100 $T +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=100
ovc rw100 +hb=0 +hbm_pct=100 +preload +seed=3 +cmds=300 +cmds2=4 +put_pct=50 +resp_whold=1800
ovc rw20 $T +hbm_pct=20 +preload +seed=5 +cmds=300 +cmds2=4 +put_pct=50 +resp_whold=2500 +hbmb_slow_pct=3 +hbmb_slow_extra=1200 +cmd_slow_pct=2 +cmd_slow_extra=800
ovc hbe $T +nblk=48 +hbm_pct=20 +preload +seed=5 +cmds=300 +cmds2=4 +put_pct=50 +host_bearly=2500
ovc hbe0 $T +nblk=32 +hbm_pct=0 +preload +seed=6 +cmds=300 +cmds2=4 +put_pct=50 +host_bearly=2500
ovc lmix $T +hbm_pct=20 +preload +seed=21 +cmds=900 +launches=4 +cmds2=4 +put_pct=50 +resp_rdy=20 +hbmb_slow_pct=3 +hbmb_slow_extra=1200 +cmd_slow_pct=2 +cmd_slow_extra=800 +hbm_gap=10
EOF2
fi
if [ "$OV" = 5 ]; then   # phase 3: a small tree, so that same-bucket accesses (their arrival-relative gate) are frequent
    cat >> $O/jobs.txt <<EOF3
ovf nb64 $H +nblk=64 +hbm_pct=20 +preload +cmds=200 +cmds2=4 +put_pct=50
ovf nb32 $H +nblk=32 +hbm_pct=50 +preload +cmds=200 +cmds2=4 +put_pct=50 +seed=4
ovc tnb $T +nblk=48 +hbm_pct=30 +preload +cmds=300 +cmds2=4 +put_pct=50
ovc tnb0 $T +nblk=32 +hbm_pct=0 +preload +cmds=200 +cmds2=4 +put_pct=0
ovc tnb100 $T +nblk=32 +hbm_pct=0 +preload +cmds=200 +cmds2=4 +put_pct=100
ovc tnp $T +hbm_pct=20 +cmds=300 +cmds2=4 +put_pct=0
ovcq hbe $T +nblk=48 +hbm_pct=20 +preload +seed=5 +cmds=300 +cmds2=4 +put_pct=50 +host_bearly=2500
ovcl tlnp $T +hbm_pct=20 +cmds=300 +cmds2=4 +put_pct=0
EOF3
fi
echo "== running $(wc -l < $O/jobs.txt) runs, $J at a time"
rm -f $O/fx_*.txt
O=$O xargs -P $J -L 1 bash -c 'b=$0; t=$1; shift 1; timeout 7200 ./$O/$b/V "$@" +fix_dump=$O/fx_${b}_$t.txt > $O/${b}_$t.log 2>&1; echo "  done $b $t"' < $O/jobs.txt
pass=0; fail=0
gd_ok=0; echo "$GD" | grep -q "^PASS" && gd_ok=1
ok() { echo "PASS  $*"; pass=$((pass+1)); }
bad() { echo "FAIL  $*"; fail=$((fail+1)); }
hashes() { grep -E "^run1: (bucket-port timing|folded off-package shape|on-package release/end) hash" $O/$1.log | sed -E 's/ over .*//'; }
cpc() { grep -E "^run1: size=" $O/$1.log | sed -E 's/.*size=([0-9]+) .*device total=([0-9]+).*/\2 \1/' | awk '{printf "%.0f", $1/$2}'; }
echo "== checks"
[ $gd_ok = 1 ] && ok "no name used in a generate block before its declaration (Vivado would make it an undriven local net)" \
               || bad "a name is used in a generate block before its declaration: $(echo "$GD" | head -3 | tr '\n' ' ')"
while read -r b t rest; do
    l=$O/${b}_$t
    if [ "$b $t" = "ovl l100" ] || [ "$b $t" = "ovcl tl100" ] || [ "$b" = "ovcq" ]; then continue; fi
    grep -q "ALL CHECKS PASSED" $l.log && grep -q "eviction scoreboard: .* 0 wrong" $l.log \
        && ok "$b $t: all responses correct, scoreboard 0 wrong" || bad "$b $t ($l.log)"
done < $O/jobs.txt
# 2026-11-05: the kernel's completion side never loses or misplaces a result (sim-only warnings), and the slow
# response-memory runs really had results land while an earlier response was being written (the card's slip)
kw=$(cat $O/*.log 2>/dev/null | grep -c "KERNEL OVERLAP")
[ "$kw" = 0 ] && ok "kernel completion side: no result lost or misplaced in any run" || bad "kernel completion side warnings: $kw ($(grep -l 'KERNEL OVERLAP' $O/*.log | head -3 | tr '\n' ' '))"
if [ "$OV" -ge 4 ]; then
    late=$(grep -E "^run1: completion side: [0-9]+" $O/ovc_rw100.log | sed -E 's/^run1: completion side: ([0-9]+).*/\1/')
    [ -n "$late" ] && [ "$late" -gt 0 ] && ok "slow response writes (1,800 cycles each): $late results landed during an earlier response write, every GET correct" \
        || bad "slow response-write run did not exercise the completion side (late results: '${late}')"
    grep -q "PASSED" $O/ovc_hbe.log && grep -q "PASSED" $O/ovc_hbe0.log \
        && ok "host writes readable 2,500 cycles after their acknowledgement: every GET correct, no halt" \
        || bad "late-landing host writes ($O/ovc_hbe.log, $O/ovc_hbe0.log)"
    if [ "$OV" = 5 ]; then
        grep -q "integrity (tag) failure" $O/ovcq_hbe.log \
            && ok "negative control: the old same-bucket gap (OV_LEQ 3809) reads the stale bucket and halts (integrity): the late-landing case is caught" \
            || bad "negative control: OV_LEQ 3809 did not fail the late-landing case ($O/ovcq_hbe.log)"
    fi
    echo "      long mixed-latency run (lmix): $(grep -cE '^(run1|runL): size' $O/ovc_lmix.log) launches, $(grep -E '^(run1|runL): size' $O/ovc_lmix.log | sed -E 's/.*completed=([0-9]+).*/\1/' | paste -sd+ | bc) commands"
fi
same() { local a=$1 b=$2; [ -n "$(hashes $a)" ] && [ "$(hashes $a)" = "$(hashes $b)" ]; }
same ovf_p0 ovf_p50 && same ovf_p0 ovf_p100 && ok "paired streams 0/50/100% PUTs: identical visible hashes" || bad "paired streams 0/50/100% PUTs differ"
same ovf_sk0 ovf_sk100 && ok "same key x120, 0/100% PUTs: identical visible hashes" || bad "same-key paired hashes differ"
same ovf_ab0 ovf_ab50 && ok "ABAB keys, 0/50% PUTs: identical visible hashes" || bad "ABAB paired hashes differ"
same ovf_k3a ovf_k3b && ok "keys in turns of 3, 0/100% PUTs: identical visible hashes" || bad "period-3 key paired hashes differ"
same ovl_l0 ovf_p0 && ok "injected-leak build without PUTs equals the overlap build" || bad "injected-leak build without PUTs differs"
[ "$(hashes ovl_l0 | grep timing)" != "$(hashes ovl_l100 | grep timing)" ] && [ "$(hashes ovl_l0 | grep release)" != "$(hashes ovl_l100 | grep release)" ] \
    && ok "injected leak (a PUT's read one cycle late) detected by the paired hashes" || bad "injected leak NOT detected"
if [ "$OV" -ge 4 ]; then
    same ovc_t0 ovc_t50 && same ovc_t0 ovc_t100 && ok "card parameters, host read tails: paired streams 0/50/100% PUTs, identical visible hashes" \
        || bad "card parameters, host read tails: paired hashes differ"
    if [ "$OV" = 5 ]; then
        # phase 3: starts follow the arrivals, so the leak in the preload's PUTs carries into run 1; compare runs with no
        # PUT at all (no preload)
        same ovcl_tlnp ovc_tnp && ok "card parameters, injected-leak build with no PUT at all equals the overlap build" || bad "card-parameter leak build with no PUT differs"
    else
        same ovcl_tl0 ovc_t0 && ok "card parameters, injected-leak build without PUTs equals the overlap build" || bad "card-parameter leak build without PUTs differs"
    fi
    [ "$(hashes ovcl_tl0 | grep timing)" != "$(hashes ovcl_tl100 | grep timing)" ] \
        && ok "card parameters, host read tails: injected leak detected by the paired hashes" || bad "card parameters: injected leak NOT detected"
fi
if [ "$OV" = 5 ]; then
    same ovc_tnb0 ovc_tnb100 && ok "phase 3, small tree (frequent same-bucket accesses), host read tails: 0/100% PUTs, identical visible hashes" \
        || bad "phase 3, small tree: paired hashes differ"
fi
# every access's visible times equal v14d1's once the public same-bucket shift (D_EQ) is taken out of exactly the
# accesses that had it: off-package shape and on-package release/end, at 0%, 100% and 20% (card-like stash)
corr() { grep -E "^run1: equality-corrected hashes" $O/$1.log | sed -E 's/ \(.*//'; }
neq()  { grep -E "^run1: equality-corrected hashes" $O/$1.log | sed -E 's/.*\(([0-9]+) same-bucket.*/\1/'; }
for t in c0 c1 cs; do
    [ "$OV" -ge 4 ] && break
    [ -n "$(corr ovf_$t)" ] && [ "$(corr ovf_$t)" = "$(corr base_$t)" ] \
        && ok "$t: every access's visible times equal v14d1's apart from the public same-bucket shift ($(neq ovf_$t) shifted accesses)" \
        || bad "$t: visible times differ from v14d1 beyond the same-bucket shift"
done
# fixed schedule: nothing visible depends on keys, data or stash state (only on arrivals, bucket equality, on package)
if [ "$OV" = 4 ]; then PD="--p 1500 --deq 3600 --ctx 1"; else PD="--p 2900 --deq 2700"; fi   # step 2: keyed by the previous access (reads in flight return in order)
if [ "$OV" = 5 ]; then
    # phase 3: every start, read issue, write-back, release and end recomputed exactly from public events (check_p3.py),
    # one set of pipeline offsets over all runs of a build
    FX5="p0 p50 p100 sk0 sk100 ab0 ab50 k3a k3b k4a c0 c1 cs j2 c3 nb64 nb32"
    python3 check_p3.py $(for t in $FX5; do echo $O/fx_ovf_$t.txt; done) > $O/p3_ovf.out 2>&1 \
        && ok "phase 3 schedule exact in $(echo $FX5 | wc -w) runs (simulation parameters): $(grep -c PASS $O/p3_ovf.out) rules, $(head -1 $O/p3_ovf.out | sed 's/^check_p3: //; s/;.*//')" \
        || { bad "phase 3 schedule broken (simulation parameters, $O/p3_ovf.out)"; grep FAIL $O/p3_ovf.out | head -3 | sed 's/^/      /'; }
    FXC="t0 t50 t100 tsk tab tc100 tnb tnb0 tnb100 rw20 lmix hbe hbe0"
    python3 check_p3.py --ctrd 600 --ga ${P3_GA:-1500} --pmin ${P3_PMIN:-1500} --leq ${P3_LEQ:-0} --l ${P3_L:-0} --arwb $(( 1785 + ${P3_XWB:-700} )) --arrel $(( 3033 + ${P3_XWB:-700} )) --arrelh $(( 2384 + ${P3_XWB:-700} + 700 )) $(for t in $FXC; do echo $O/fx_ovc_$t.txt; done) > $O/p3_ovc.out 2>&1 \
        && ok "phase 3 schedule exact in $(echo $FXC | wc -w) runs (card parameters, host read tails): $(head -1 $O/p3_ovc.out | sed 's/^check_p3: //; s/;.*//')" \
        || { bad "phase 3 schedule broken (card parameters, $O/p3_ovc.out)"; grep FAIL $O/p3_ovc.out | head -3 | sed 's/^/      /'; }
    python3 check_p3.py $O/fx_ovl_l100.txt > $O/p3_ovl.out 2>&1 && bad "injected leak NOT detected by the phase 3 schedule check" \
        || ok "injected leak detected by the phase 3 schedule check ($(grep FAIL $O/p3_ovl.out | head -1 | sed 's/^ *FAIL  //; s/:.*//'))"
    python3 check_p3.py --ctrd 600 --ga ${P3_GA:-1500} --pmin ${P3_PMIN:-1500} --leq ${P3_LEQ:-0} --l ${P3_L:-0} --arwb $(( 1785 + ${P3_XWB:-700} )) --arrel $(( 3033 + ${P3_XWB:-700} )) --arrelh $(( 2384 + ${P3_XWB:-700} + 700 )) $O/fx_ovcl_tl100.txt > $O/p3_ovcl.out 2>&1 && bad "card parameters: injected leak NOT detected by the phase 3 schedule check" \
        || ok "card parameters: injected leak detected by the phase 3 schedule check"
else
FX_ALL="p0 p50 p100 sk0 sk100 ab0 ab50 k3a k3b k4a c0 c1 cs j2 c3"
FX_SAME="p0 p50 p100 sk0 sk100 ab0 ab50 k3a k3b k4a c0 cs"     # same memory latencies (host 401 / 98)
fxbad=""; for t in $FX_ALL; do python3 check_fixed_schedule.py $PD $O/fx_ovf_$t.txt > $O/fx_ovf_$t.out 2>&1 || fxbad="$fxbad $t"; done
[ -z "$fxbad" ] && ok "fixed schedule in every run ($(echo $FX_ALL | wc -w) runs): one visible shape per class, start rule exact" \
                || bad "fixed schedule broken in:$fxbad (see $O/fx_ovf_<run>.out)"
python3 check_fixed_schedule.py $PD $(for t in $FX_SAME; do echo $O/fx_ovf_$t.txt; done) > $O/fx_across.out 2>&1 \
    && ok "fixed schedule across $(echo $FX_SAME | wc -w) runs (random keys, one key, ABAB, turns of 3 and 4, 0/20/50% on package, card-like stash): identical visible shapes" \
    || { bad "visible shapes differ between runs ($O/fx_across.out)"; grep FAIL $O/fx_across.out | head -3 | sed 's/^/      /'; }
python3 check_fixed_schedule.py $PD $O/fx_ovl_l100.txt > $O/fx_ovl_l100.out 2>&1 \
    && bad "injected leak NOT detected by the fixed-schedule check" || ok "injected leak detected by the fixed-schedule check"
fi
echo "== throughput (cycles per command, run1)"
for t in c0 p50 cs c1; do echo "  $t: v14d1 $(cpc base_$t), overlap $(cpc ovf_$t)"; done
[ "$OV" -ge 4 ] && for t in t50 tc100; do echo "  $t (card parameters, host read tails): $(cpc ovc_$t)"; done
echo "== $pass passed, $fail failed"
[ $fail = 0 ]
