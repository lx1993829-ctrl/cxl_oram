`timescale 1ns / 1ps
`include "oram_params.vh"

// =============================================================================
// flat_oram_gcm.v - ORAM Top with AES-GCM Encryption (v2 - same-bucket fix)
// =============================================================================

module flat_oram_gcm #(
    parameter N            = `ORAM_N,
    parameter Z            = `ORAM_Z,
    parameter C            = `ORAM_C,
    parameter B            = `ORAM_B,
    parameter STASH_DEPTH  = `ORAM_STASH_DEPTH,
    parameter AXI_DW       = `AXI_DATA_W,
    parameter AXI_AW       = `AXI_ADDR_W,
    parameter AXI_SW       = `AXI_STRB_W,
    parameter AXI_IDW      = `AXI_ID_W,
    parameter AXI_LENW     = `AXI_LEN_W,
    parameter SLOT_AW      = `SLOT_ADDR_W,
    parameter BUCKET_W     = `BUCKET_ID_W,
    parameter SLOT_W       = `SLOT_ID_W,
    parameter FILL_W       = `FILL_CNT_W,
    parameter POS_W        = `POS_IN_BKT_W,
    parameter PTR_W        = `STASH_PTR_W,
    parameter BEATS        = `BEATS_PER_BLOCK,
    parameter BEAT_W       = `BEAT_CNT_W,
    parameter TOTAL_BEATS  = `BEATS_PER_BKT,
    parameter AES_BLK_W    = 128
)(
    input  wire                 clk,
    input  wire                 rst_n,

    // Client Interface
    input  wire                 client_req,
    input  wire                 client_op,
    input  wire [SLOT_AW-1:0]  client_slot_addr,
    input  wire [AXI_DW-1:0]   client_wdata,
    input  wire [AXI_DW/8-1:0] client_wstrb,     // byte strobes of the write beat (all ones = whole block)
    input  wire                 client_wdata_valid,
    input  wire [BEAT_W-1:0]   client_wdata_beat,
    output wire [BEAT_W-1:0]   client_wdata_beat_req,
    output reg  [AXI_DW-1:0]   client_rdata,
    output reg                  client_rdata_valid,
    output reg  [BEAT_W-1:0]   client_rdata_beat,
    output reg                  client_done,
    output reg                  client_stall,
`ifdef ORAM_OVERLAP2
    output reg                  client_acc,       // overlap: request taken (its start s); the request is held until then
`ifdef ORAM_OVERLAP4
    output wire [1:0]           client_wsel,      // overlap: request buffer (access number mod 4) of M's access
    output wire [1:0]           client_rsel,      // overlap: buffer of the access whose result streams
`else
    output wire                 client_wsel,      // overlap: write buffer (access parity) the PUT data is read from
    output wire                 client_rsel,      // overlap: parity of the access whose result streams
`endif
`endif

    output reg                  err_bucket_overflow,
    output reg                  err_stash_overflow,
    output reg                  err_tag_mismatch,
    output wire err_ct_overrun,   // Phase 2: sticky, a timing gate was missed (fail-stop)
    output wire [63:0] dbg_halt_info,   // latched at the first error: [63:40] bucket, [39:35] state, [34] HBM bucket,
                                        // [33:32] on-package deadline (v14b: 01 write-back start, 10 hand-off by the
                                        // release, 11 scratch bank conflict; 00 another cause), [31:20] cycles missed
                                        // by (saturating at 4095), [19] position-map, [18] bucket-record, [17] stash
                                        // unit error, [16] the missed time is a lower bound (the late event had not
                                        // happened yet), [15:0] access cycle
    output wire fmt_done,         // Phase 2: boot-time encrypted format complete

    // BRAM Init Interface
    input  wire                     init_mode,
    input  wire [SLOT_AW-1:0]      init_pm_wr_addr,
    input  wire [BUCKET_W-1:0]     init_pm_wr_bucket,
    input  wire [1:0]              init_pm_wr_status,
    input  wire                     init_pm_wr_en,
    input  wire [BUCKET_W-1:0]     init_bm_wr_bucket,
    input  wire [Z*SLOT_W-1:0]    init_bm_wr_slot_list,
    input  wire [FILL_W-1:0]      init_bm_wr_fill,
    input  wire                     init_bm_wr_en,

    // AES-GCM Key
    input  wire [127:0]            aes_key,
    input  wire [95:0]             aes_iv_seed,
    input  wire [`SLOT_ID_W:0]     cfg_n,              // run-time number of blocks (0: the build's maximum N)
    input  wire [`BUCKET_ID_W:0]   cfg_hbm_bkts,       // buckets 0 .. cfg_hbm_bkts-1 live in HBM (timing below)
    input  wire [`SLOT_ID_W:0]     cfg_pool_n,         // stash pool entries (0: N); exhausting it is the only overflow
`ifdef ORAM_NOCRYPTO
    input  wire [15:0]             cfg_nc_rel,         // run-time release time, host-memory buckets (0: the build's time)
    input  wire [15:0]             cfg_nc_rel_h,       // run-time release time, HBM buckets (0: the build's time)
    input  wire [15:0]             cfg_nc_ctrd,        // run-time read gate (0: the build's CT_RD)
`endif

    // AXI4 Master -> DDR
    output wire [AXI_IDW-1:0]   m_axi_arid,
    output wire [AXI_AW-1:0]    m_axi_araddr,
    output wire [AXI_LENW-1:0]  m_axi_arlen,
    output wire [2:0]            m_axi_arsize,
    output wire [1:0]            m_axi_arburst,
    output wire                  m_axi_arvalid,
    input  wire                  m_axi_arready,
    input  wire [AXI_IDW-1:0]   m_axi_rid,
    input  wire [AXI_DW-1:0]    m_axi_rdata,
    input  wire [1:0]            m_axi_rresp,
    input  wire                  m_axi_rlast,
    input  wire                  m_axi_rvalid,
    output wire                  m_axi_rready,
    output wire [AXI_IDW-1:0]   m_axi_awid,
    output wire [AXI_AW-1:0]    m_axi_awaddr,
    output wire [AXI_LENW-1:0]  m_axi_awlen,
    output wire [2:0]            m_axi_awsize,
    output wire [1:0]            m_axi_awburst,
    output wire                  m_axi_awvalid,
    input  wire                  m_axi_awready,
    output wire [AXI_DW-1:0]    m_axi_wdata,
    output wire [AXI_SW-1:0]    m_axi_wstrb,
    output wire                  m_axi_wlast,
    output wire                  m_axi_wvalid,
    input  wire                  m_axi_wready,
    input  wire [AXI_IDW-1:0]   m_axi_bid,
    input  wire [1:0]            m_axi_bresp,
    input  wire                  m_axi_bvalid,
    output wire                  m_axi_bready,
    // position map in HBM (addresses relative to the metadata buffer; the kernel adds its base)
    output wire [63:0]           m_meta_araddr,
    output wire [7:0]            m_meta_arlen,
    output wire [2:0]            m_meta_arsize,
    output wire [1:0]            m_meta_arburst,
    output wire                  m_meta_arvalid,
    input  wire                  m_meta_arready,
    input  wire [AXI_DW-1:0]     m_meta_rdata,
    input  wire                  m_meta_rlast,
    input  wire                  m_meta_rvalid,
    output wire                  m_meta_rready,
    output wire [63:0]           m_meta_awaddr,
    output wire [7:0]            m_meta_awlen,
    output wire [2:0]            m_meta_awsize,
    output wire [1:0]            m_meta_awburst,
    output wire                  m_meta_awvalid,
    input  wire                  m_meta_awready,
    output wire [AXI_DW-1:0]     m_meta_wdata,
    output wire [AXI_DW/8-1:0]   m_meta_wstrb,
    output wire                  m_meta_wlast,
    output wire                  m_meta_wvalid,
    input  wire                  m_meta_wready,
    input  wire                  m_meta_bvalid,
    output wire                  m_meta_bready,
    // bucket records in HBM: metadata + per-position IV/tag (addresses relative to their buffer)
    output wire [63:0]           m_brec_araddr,
    output wire [7:0]            m_brec_arlen,
    output wire [2:0]            m_brec_arsize,
    output wire [1:0]            m_brec_arburst,
    output wire                  m_brec_arvalid,
    input  wire                  m_brec_arready,
    input  wire [AXI_DW-1:0]     m_brec_rdata,
    input  wire                  m_brec_rlast,
    input  wire                  m_brec_rvalid,
    output wire                  m_brec_rready,
    output wire [63:0]           m_brec_awaddr,
    output wire [7:0]            m_brec_awlen,
    output wire [2:0]            m_brec_awsize,
    output wire [1:0]            m_brec_awburst,
    output wire                  m_brec_awvalid,
    input  wire                  m_brec_awready,
    output wire [AXI_DW-1:0]     m_brec_wdata,
    output wire [AXI_DW/8-1:0]   m_brec_wstrb,
    output wire                  m_brec_wlast,
    output wire                  m_brec_wvalid,
    input  wire                  m_brec_wready,
    input  wire                  m_brec_bvalid,
    output wire                  m_brec_bready,
    // the stash in HBM: per-bucket lists + block pool (addresses relative to its buffer)
`ifdef ORAM_STASH_PC_IDS
    output wire [1:0]             m_stash_arid,      // v14d design B: the read's pseudo-channel (ID)
    input  wire [1:0]             m_stash_rid,
`endif
    output wire [63:0]            m_stash_araddr,
    output wire [7:0]             m_stash_arlen,
    output wire [2:0]             m_stash_arsize,
    output wire [1:0]             m_stash_arburst,
    output wire                   m_stash_arvalid,
    input  wire                   m_stash_arready,
    input  wire [AXI_DW-1:0]      m_stash_rdata,
    input  wire                   m_stash_rlast,
    input  wire                   m_stash_rvalid,
    output wire                   m_stash_rready,
    output wire [63:0]            m_stash_awaddr,
    output wire [7:0]             m_stash_awlen,
    output wire [2:0]             m_stash_awsize,
    output wire [1:0]             m_stash_awburst,
    output wire                   m_stash_awvalid,
    input  wire                   m_stash_awready,
    output wire [AXI_DW-1:0]      m_stash_wdata,
    output wire [AXI_DW/8-1:0]    m_stash_wstrb,
    output wire                   m_stash_wlast,
    output wire                   m_stash_wvalid,
    input  wire                   m_stash_wready,
    input  wire                   m_stash_bvalid,
    output wire                   m_stash_bready,

    // Debug
    output wire dbg_gcm_tag_valid,

    // Test controls
    input  wire                  dbg_force_same_bucket,  // override req_b_new = req_b
    input  wire [BUCKET_W-1:0]  dbg_prng_override,      // when != 0, replaces prng_bucket
    input  wire                  perf_reset,              // clear all perf counters
    output wire dbg_gcm_tag_match,
    output wire [4:0]            dbg_state,
    output wire                  dbg_client_done,
    output wire                  dbg_client_req,
    output wire [BUCKET_W-1:0]  dbg_req_b,
    output wire [BUCKET_W-1:0]  dbg_req_b_new,
    output wire                  dbg_found_in_bucket,
    output wire                  dbg_found_in_stash,
    output wire                  dbg_same_bucket,
    output wire                  dbg_err_stash_ovf,
    output wire [PTR_W:0]       dbg_stash_occ,

    // Performance counters - 4 categories:
    //   rb = READ,  found in bucket    (needs decrypt + re-encrypt)
    //   rs = READ,  found in stash     (stash read, no decrypt)
    //   wb = WRITE, found in bucket    (encrypt to scratch)
    //   ws = WRITE, found in stash     (stash overwrite)
    // Each category tracks 8 phases + total + ops count.
    output reg  [31:0]  perf_rb_ddr_rd, perf_rb_decrypt, perf_rb_encrypt,
    output reg  [31:0]  perf_rb_compact, perf_rb_evict, perf_rb_ddr_wr,
    output reg  [31:0]  perf_rb_scan, perf_rb_stash,
    output reg  [31:0]  perf_rb_total, perf_rb_ops,

    output reg  [31:0]  perf_rs_ddr_rd, perf_rs_decrypt, perf_rs_encrypt,
    output reg  [31:0]  perf_rs_compact, perf_rs_evict, perf_rs_ddr_wr,
    output reg  [31:0]  perf_rs_scan, perf_rs_stash,
    output reg  [31:0]  perf_rs_total, perf_rs_ops,

    output reg  [31:0]  perf_wb_ddr_rd, perf_wb_decrypt, perf_wb_encrypt,
    output reg  [31:0]  perf_wb_compact, perf_wb_evict, perf_wb_ddr_wr,
    output reg  [31:0]  perf_wb_scan, perf_wb_stash,
    output reg  [31:0]  perf_wb_total, perf_wb_ops,

    output reg  [31:0]  perf_ws_ddr_rd, perf_ws_decrypt, perf_ws_encrypt,
    output reg  [31:0]  perf_ws_compact, perf_ws_evict, perf_ws_ddr_wr,
`ifdef ORAM_PHASE_TRACE
    output wire [10:0]  phase_ent,          // build option: a one-cycle pulse when an access enters a phase (below)
`endif
`ifdef ORAM_ONPKG_DEBUG
    // v14b debug build (ORAM_ONPKG_DEBUG, build.sh DEBUG=1): see "on-package debug" below
    output wire [255:0] dbg_acc_rec,        // the access just ended: its record (stable while client_done is high)
    output wire [255:0] dbg_st_rec,         // v14c: the same access's stash open (its reads on the stash port)
    output wire [767:0] dbg_ov_rec,         // [255:0] counters, [511:256] first on-package overrun, [767:512] first deadline (2) miss
`endif
    output reg  [31:0]  perf_ws_scan, perf_ws_stash,
    output reg  [31:0]  perf_ws_total, perf_ws_ops
);

    // =========================================================================
    // FSM States
    // =========================================================================
    // Phase 2 state machine (full-bucket verify / re-encrypt, constant time)
    localparam [4:0]
        S_IDLE         = 5'd0,
        S_POS_LOOKUP   = 5'd1,
        S_RD_GATE      = 5'd2,
        S_DDR_READ     = 5'd3,
        S_CR_IV        = 5'd4,
        S_CR_IVW       = 5'd5,
        S_CR_START     = 5'd6,
        S_CR_FEED      = 5'd7,
        S_CR_RECV      = 5'd8,
        S_CR_TAG       = 5'd9,
        S_SCAN         = 5'd10,
        S_OP           = 5'd11,
        S_CP           = 5'd12,
        S_COMPACT      = 5'd13,
        S_COMPACT2     = 5'd14,
        S_PM_UPD       = 5'd15,
        S_EVICT        = 5'd16,
        S_EVICT_CHK    = 5'd17,
        S_EVICT_DONE   = 5'd18,
        S_EVICT_WAIT   = 5'd19,
        S_EA_START     = 5'd20,
        S_WB_GATE      = 5'd21,
        S_DDR_WRITE    = 5'd22,
        S_DONE_GATE    = 5'd23,
        S_RES_STREAM   = 5'd24,
        S_FMT_START    = 5'd25,
        S_FMT_WRITE    = 5'd26,
        S_FMT_WAIT     = 5'd27,
        S_HALT         = 5'd28,
        S_LAYOUT       = 5'd29,   // place every slot at an independent uniform bucket (random direct placement)
        S_UNUSED30     = 5'd30;   // (was the Fisher-Yates shuffle)   // Fisher-Yates shuffle of the slot numbers   // random lazy layout: every slot -> random bucket, all buckets empty   // F4: fail-stop (integrity failure / stash overflow)

    reg [4:0] state;
    // v14: on-package (HBM) buckets are kept in plaintext in arrival-mode builds. An access to one has no decryption
    // pass, tag check or re-encryption (S_DDR_READ, S_EA_START); its write-back streams behind the eviction copies,
    // and the boot formats it with zeros (S_FMT_START). The IV advances wherever an encryption is skipped, so every
    // off-package bucket gets the IV, ciphertext and tag it had in v11g. Strict-mode builds are unchanged (BYP = 0).
`ifdef ORAM_SCHED_ARRIVAL
    localparam        BYP = 1'b1;
`else
    localparam        BYP = 1'b0;
`endif
    reg               acc_hbm;         // this access's bucket is in HBM (on package): AR_*_H budgets; plaintext if BYP
    reg               fmt_zero;        // v14: the bucket being formatted is on package: its write carries zeros
`ifdef ORAM_PHASE_TRACE
    // phase trace (build option ORAM_PHASE_TRACE): pulse k when the state machine enters phase k. Bits: 0 position-map
    // lookup, 1 read gate, 2 crypto (first entry per access is the decryption pass), 3 block operation (scan or
    // compaction path), 4 eviction, 5 re-encryption, 6 write-back gate, 7 write-back, 8 release gate, 9 result, 10 idle.
    reg [4:0] ph_prev_state;
    always @(posedge clk or negedge rst_n) if (!rst_n) ph_prev_state <= 5'd0; else ph_prev_state <= state;
    wire ph_new = (state != ph_prev_state);
    // v14: on the on-package path the two crypto phases take no time: bit 2 fires with the operation (S_SCAN), bit 5
    // with the write-back (S_DDR_WRITE), so the trace keeps its 16 slots in order with zero-length crypto phases.
`ifdef ORAM_NOCRYPTO
    wire ph_byp = BYP;                 // every bucket: no crypto phases
`else
    wire ph_byp = BYP && acc_hbm;
`endif
    assign phase_ent = ph_new ? {state == S_IDLE, state == S_RES_STREAM, state == S_DONE_GATE, state == S_DDR_WRITE,
                                 state == S_WB_GATE, ph_byp ? (state == S_DDR_WRITE) : (state == S_EA_START), state == S_EVICT,
                                 (state == S_SCAN || state == S_CP),
                                 (state >= S_CR_IV && state <= S_CR_TAG) || (ph_byp && state == S_SCAN), state == S_RD_GATE,
                                 state == S_POS_LOOKUP} : 11'd0;
`endif

    // =========================================================================
    // Internal registers
    // =========================================================================
    reg [SLOT_AW-1:0]   req_slot_addr;
    reg                  req_op;
    reg [BUCKET_W-1:0]  req_b, req_b_new;
    wire [23:0]         req_b24 = req_b;   // the halt record's bucket field
    reg [Z*SLOT_W-1:0]  bkt_slot_list;
    reg [FILL_W-1:0]    bkt_fill_count;
    reg                  same_bucket;
    reg                  found_in_bucket, found_in_stash;
    reg [POS_W-1:0]     found_pos;
    reg [PTR_W-1:0]     found_stash_idx;
    reg [PTR_W-1:0]     stash_alloc_idx;
    reg [SLOT_AW-1:0]   ev_slot_addr;     // registered copy of st_cam_bkt_slot_addr
    wire [PTR_W:0] stash_occupancy;
    reg [BEAT_W-1:0]    beat_cnt;
    reg [POS_W-1:0]     scan_pos;
    reg [FILL_W-1:0]    evict_slots_remaining;

    // AES-GCM feed control (two-lane core: one whole 256-bit beat per cycle each way)
`ifdef ORAM_OVERLAP4
    reg  [2:0]           fd_v, fd_last, fd_zero;   // scratch reads in flight to the core (step 2: 3-cycle read latency)
`else
    reg  [1:0]           fd_v, fd_last, fd_zero;   // scratch reads in flight to the core (2-cycle read latency)
`endif
    reg  [10:0]          rd_lin, rd_base;          // next read {position, beat}; its position's first beat
    reg  [10:0]          wr_lin;                   // beats of this message written back = {position, beat} of the next
    reg  [10:0]          wr_end;                   // landed_beats at which the next write's position has landed
    reg  [10:0]          wr_lim;                   // wr_lin + OQ_D: reads may run at most OQ_D beats ahead of the writes

    // Same-bucket read: buffer decrypted plaintext for re-encryption
    // We use stash data_mem as temporary storage (at stash_alloc_idx)
    // even though the slot won't be inserted into stash.
    // Alternative: a dedicated 4KB buffer. For simplicity, reuse stash data port.
    // Actually simpler: buffer the 128 plaintext beats in a small BRAM.
    // But we already have the plaintext coming out of GCM - we can pipeline
    // the re-encrypt right after decrypt finishes.
    // Approach: save the decrypted beats into stash data memory (as scratch space),
    // then read them back for re-encryption. This reuses existing stash data ports.
    // OR: pipeline decrypt output directly into encrypt input.
    //
    // Chosen approach: After decrypt finishes and data is returned to client,
    // we start a fresh encrypt. We read the plaintext from the stash data memory
    // where we temporarily stored it during decrypt (using stash_alloc_idx).
    // After encrypt, we DON'T call st_ins_en (don't actually insert into stash).
    // The stash entry is just scratch space.

    // Same-bucket write: we need to feed 128 beats of client data to GCM encrypt.
    // The client provides data beat-by-beat via client_wdata.

    // =========================================================================
    // AES-GCM Instance
    // =========================================================================
    // Two lanes (aes_gcm_2lane): a whole 256-bit beat per cycle in and out, the same GCM message as the
    // one-lane core (aes_gcm_pipelined, kept as the tests' reference): same ciphertext, tag and IVs.
    reg          gcm_start;
    reg          gcm_iv_adv;      // v14: advance the IV as an encryption would (on-package write-back or format)
    reg          gcm_encrypt;
    reg [AXI_DW-1:0] gcm_data_in;
    reg          gcm_data_valid;
    reg          gcm_data_last;
    wire [AXI_DW-1:0] gcm_data_out;
    wire [1:0]   gcm_data_out_mask;
    wire         gcm_data_out_valid;
    wire         gcm_data_out_last;
    reg  [127:0] gcm_tag_in;
    wire [127:0] gcm_tag_out;
    wire         gcm_tag_valid;
    wire         gcm_tag_match;
    wire         gcm_ready;
    wire         gcm_busy;
    wire         gcm_input_ready;
    wire [95:0]  gcm_iv_out;
    wire         gcm_iv_updated;
    wire         gcm_counter_overflow;

    (* max_fanout = 32 *) reg  [95:0]  gcm_iv_reg;

`ifdef ORAM_OVERLAP4
    // Two cores. D (decryption, M) uses the IV stored with each bucket and never its own IV generator. E (encryption,
    // the E stage) owns the IV generator: every encryption and IV advance, in access order, and the boot format, which
    // M drives on core E (before the first access), so the IVs form one sequence as in the serial design.
    wire        fmt_on = !fmt_done_r;
    wire [AXI_DW-1:0] d_out, ex_out; wire [1:0] d_om, ex_om; wire d_ov, ex_ov, d_ol, ex_ol;
    wire [127:0] d_tag, ex_tag; wire d_tv, ex_tv, d_tm, ex_tm, d_rdy, ex_rdy, d_busy, ex_busy, d_ir, ex_ir;
    wire [95:0] d_ivo, ex_ivo; wire d_ivu, ex_ivu, d_co, ex_co;
    aes_gcm_2lane u_aes_gcm (
        .clk(clk), .rst_n(rst_n), .enable(1'b1),
        .start(gcm_start && !fmt_on), .encrypt(1'b0),
        .key(aes_key), .iv(gcm_iv_reg), .iv_advance(1'b0),
        .data_in(gcm_data_in), .data_mask(2'b11), .data_valid(gcm_data_valid && !fmt_on),
        .data_last(gcm_data_last),
        .data_out(d_out), .data_out_mask(d_om), .data_out_valid(d_ov),
        .data_out_last(d_ol),
        .tag_in(gcm_tag_in), .tag_out(d_tag),
        .tag_valid(d_tv), .tag_match(d_tm),
        .ready(d_rdy), .busy(d_busy), .input_ready(d_ir),
        .iv_out(d_ivo), .iv_updated(d_ivu),
        .counter_overflow(d_co)
    );
    aes_gcm_2lane u_aes_gcm_e (
        .clk(clk), .rst_n(rst_n), .enable(1'b1),
        .start(fmt_on ? gcm_start : e_gcm_start), .encrypt(1'b1),
        .key(aes_key), .iv(fmt_on ? gcm_iv_reg : e_gcm_iv_reg), .iv_advance(fmt_on ? gcm_iv_adv : e_gcm_iv_adv),
        .data_in(fmt_on ? gcm_data_in : e_gcm_data_in), .data_mask(2'b11),
        .data_valid(fmt_on ? gcm_data_valid : e_gcm_data_valid),
        .data_last(fmt_on ? gcm_data_last : e_gcm_data_last),
        .data_out(ex_out), .data_out_mask(ex_om), .data_out_valid(ex_ov),
        .data_out_last(ex_ol),
        .tag_in(128'd0), .tag_out(ex_tag),
        .tag_valid(ex_tv), .tag_match(ex_tm),
        .ready(ex_rdy), .busy(ex_busy), .input_ready(ex_ir),
        .iv_out(ex_ivo), .iv_updated(ex_ivu),
        .counter_overflow(ex_co)
    );
    assign gcm_data_out = fmt_on ? ex_out : d_out;   assign gcm_data_out_mask = fmt_on ? ex_om : d_om;
    assign gcm_data_out_valid = fmt_on ? ex_ov : d_ov; assign gcm_data_out_last = fmt_on ? ex_ol : d_ol;
    assign gcm_tag_out = fmt_on ? ex_tag : d_tag;     assign gcm_tag_valid = fmt_on ? ex_tv : d_tv;
    assign gcm_tag_match = fmt_on ? ex_tm : d_tm;     assign gcm_ready = fmt_on ? ex_rdy : d_rdy;
    assign gcm_busy = fmt_on ? ex_busy : d_busy;      assign gcm_input_ready = fmt_on ? ex_ir : d_ir;
    assign gcm_iv_out = fmt_on ? ex_ivo : d_ivo;      assign gcm_iv_updated = fmt_on ? ex_ivu : d_ivu;
    assign gcm_counter_overflow = fmt_on ? ex_co : d_co;
    assign e_gcm_data_out = ex_out; assign e_gcm_data_out_valid = ex_ov && !fmt_on; assign e_gcm_tag_valid = ex_tv && !fmt_on;
    assign e_gcm_tag_out = ex_tag; assign e_gcm_iv_out = ex_ivo; assign e_gcm_input_ready = ex_ir; assign e_gcm_ready = ex_rdy;
`elsif ORAM_NOCRYPTO
    // NOCRYPTO (docs/nocrypto.md): no AES-GCM core in this build. Nothing reaches the crypto states; the core's outputs
    // are constants, so the logic behind them synthesizes away.
    assign gcm_data_out = {AXI_DW{1'b0}}; assign gcm_data_out_mask = 2'b00;
    assign gcm_data_out_valid = 1'b0;     assign gcm_data_out_last = 1'b0;
    assign gcm_tag_out = 128'd0;          assign gcm_tag_valid = 1'b0;   assign gcm_tag_match = 1'b0;
    assign gcm_ready = 1'b0;              assign gcm_busy = 1'b0;        assign gcm_input_ready = 1'b0;
    assign gcm_iv_out = 96'd0;            assign gcm_iv_updated = 1'b0;  assign gcm_counter_overflow = 1'b0;
`else
    aes_gcm_2lane u_aes_gcm (
        .clk(clk), .rst_n(rst_n), .enable(1'b1),
        .start(gcm_start), .encrypt(gcm_encrypt),
        .key(aes_key), .iv(gcm_iv_reg), .iv_advance(gcm_iv_adv),
        .data_in(gcm_data_in), .data_mask(2'b11), .data_valid(gcm_data_valid),
        .data_last(gcm_data_last),
        .data_out(gcm_data_out), .data_out_mask(gcm_data_out_mask), .data_out_valid(gcm_data_out_valid),
        .data_out_last(gcm_data_out_last),
        .tag_in(gcm_tag_in), .tag_out(gcm_tag_out),
        .tag_valid(gcm_tag_valid), .tag_match(gcm_tag_match),
        .ready(gcm_ready), .busy(gcm_busy), .input_ready(gcm_input_ready),
        .iv_out(gcm_iv_out), .iv_updated(gcm_iv_updated),
        .counter_overflow(gcm_counter_overflow)
    );
`endif

    // =========================================================================
    // IV Slot Table
    // =========================================================================
    reg  [SLOT_AW-1:0]  ivt_rd_addr;
    reg                  ivt_rd_en;
    wire [95:0]          ivt_rd_iv;
    wire [127:0]         ivt_rd_tag;
    wire                 ivt_rd_valid;
    reg  [SLOT_AW-1:0]  ivt_wr_addr;
    reg  [95:0]          ivt_wr_iv;
    reg  [127:0]         ivt_wr_tag;
    reg                  ivt_wr_en;


    // =========================================================================
    // Submodules
    // =========================================================================

    // --- pos_map ---
    reg  [SLOT_AW-1:0]  pm_rd_addr;  reg pm_rd_en;
    wire [BUCKET_W-1:0]  pm_rd_bucket; wire [1:0] pm_rd_status; wire pm_rd_valid;
    wire [`SLOT_ID_W-1:0] pm_rd_pidx;  reg [`SLOT_ID_W-1:0] pm_wr_pidx;   // a stashed block's pool index
    reg  [`SLOT_ID_W-1:0] req_pidx_cur;                                  // the requested block's pool index
    reg  [SLOT_AW-1:0]  pm_wr_addr;  reg [BUCKET_W-1:0] pm_wr_bucket;
    reg  [1:0]           pm_wr_status; reg pm_wr_en;

    // The position map lives in HBM (pos_map_hbm). The boot layout writes every entry before the
    // first access; the legacy init_pm_* inputs are ignored (nothing drives them, and they would
    // bypass the write FIFO's flow control).
    wire pm_wr_ready, pm_wr_quiet, pm_err;
    pos_map_hbm #(.AXI_DW(AXI_DW)) u_pos_map (
        .clk(clk), .rst_n(rst_n), .base(64'd0),
        .rd_slot_addr(pm_rd_addr), .rd_en(pm_rd_en),
        .rd_bucket(pm_rd_bucket), .rd_status(pm_rd_status), .rd_pidx(pm_rd_pidx), .rd_valid(pm_rd_valid),
        .wr_slot_addr(pm_wr_addr), .wr_bucket(pm_wr_bucket), .wr_pidx(pm_wr_pidx),
        .wr_status(pm_wr_status), .wr_en(pm_wr_en),
        .wr_ready(pm_wr_ready), .wr_quiet(pm_wr_quiet), .err(pm_err),
        .m_araddr(m_meta_araddr), .m_arlen(m_meta_arlen), .m_arsize(m_meta_arsize), .m_arburst(m_meta_arburst),
        .m_arvalid(m_meta_arvalid), .m_arready(m_meta_arready), .m_rdata(m_meta_rdata), .m_rlast(m_meta_rlast),
        .m_rvalid(m_meta_rvalid), .m_rready(m_meta_rready),
        .m_awaddr(m_meta_awaddr), .m_awlen(m_meta_awlen), .m_awsize(m_meta_awsize), .m_awburst(m_meta_awburst),
        .m_awvalid(m_meta_awvalid), .m_awready(m_meta_awready), .m_wdata(m_meta_wdata), .m_wstrb(m_meta_wstrb),
        .m_wlast(m_meta_wlast), .m_wvalid(m_meta_wvalid), .m_wready(m_meta_wready),
        .m_bvalid(m_meta_bvalid), .m_bready(m_meta_bready)
    );

    // --- bucket_meta ---
    reg  [BUCKET_W-1:0]  bm_rd_bucket; reg bm_rd_en;
    wire [Z*SLOT_W-1:0]  bm_rd_slot_list; wire [FILL_W-1:0] bm_rd_fill; wire bm_rd_valid;
    reg  [BUCKET_W-1:0]  bm_wr_bucket; reg [Z*SLOT_W-1:0] bm_wr_slot_list;
    reg  [FILL_W-1:0]    bm_wr_fill; reg bm_wr_en;

    // The bucket metadata and the IV/tag table live in HBM as one record per bucket (bucket_rec_hbm):
    // opening a bucket (the metadata read at the read gate) fetches its whole record in one burst,
    // in parallel with the bucket's own read. Boot writes every record before the first access; the
    // legacy init_bm_* inputs are ignored (nothing drives them).
    wire br_wr_ready, br_wr_quiet, br_err;
    wire br_rd_busy;   // the open record is still arriving: a write into it now is a fail-stop (S_LAYOUT waits)
    bucket_rec_hbm #(.AXI_DW(AXI_DW)) u_bucket_rec (
        .clk(clk), .rst_n(rst_n), .base(64'd0),
        .bm_rd_bucket(bm_rd_bucket), .bm_rd_en(bm_rd_en), .bm_rd_slot_list(bm_rd_slot_list),
        .bm_rd_fill(bm_rd_fill), .bm_rd_valid(bm_rd_valid), .bm_rd_busy(br_rd_busy),
        .bm_wr_bucket(bm_wr_bucket), .bm_wr_slot_list(bm_wr_slot_list), .bm_wr_fill(bm_wr_fill), .bm_wr_en(bm_wr_en),
        .iv_rd_addr(ivt_rd_addr), .iv_rd_en(ivt_rd_en), .iv_rd_iv(ivt_rd_iv), .iv_rd_tag(ivt_rd_tag), .iv_rd_valid(ivt_rd_valid),
        .iv_wr_addr(ivt_wr_addr), .iv_wr_iv(ivt_wr_iv), .iv_wr_tag(ivt_wr_tag), .iv_wr_en(ivt_wr_en),
        .wr_ready(br_wr_ready), .wr_quiet(br_wr_quiet), .err(br_err),
        .m_araddr(m_brec_araddr), .m_arlen(m_brec_arlen), .m_arsize(m_brec_arsize), .m_arburst(m_brec_arburst),
        .m_arvalid(m_brec_arvalid), .m_arready(m_brec_arready), .m_rdata(m_brec_rdata), .m_rlast(m_brec_rlast),
        .m_rvalid(m_brec_rvalid), .m_rready(m_brec_rready),
        .m_awaddr(m_brec_awaddr), .m_awlen(m_brec_awlen), .m_awsize(m_brec_awsize), .m_awburst(m_brec_awburst),
        .m_awvalid(m_brec_awvalid), .m_awready(m_brec_awready), .m_wdata(m_brec_wdata), .m_wstrb(m_brec_wstrb),
        .m_wlast(m_brec_wlast), .m_wvalid(m_brec_wvalid), .m_wready(m_brec_wready),
        .m_bvalid(m_brec_bvalid), .m_bready(m_brec_bready)
    );

    // --- random target buckets: a 64-bit xorshift mapped onto the partition's buckets (rng_bucket.v);
    //     a statistical stand-in for the assumed secure random source ---
    // --- run-time size: n blocks (cfg_n; 0 or above the build's maximum N means N) in nb = ceil(n / C)
    //     buckets. Everything sized by the ORAM (target range, format, layout, stash lists) uses these. ---
    reg  [SLOT_W:0]   n_q;
    reg  [BUCKET_W:0] nb_q;
    wire [SLOT_W:0]   n_eff = (cfg_n == 0 || cfg_n > N) ? N : cfg_n;
    // nb = ceil(n / C), bit-serial: lambda need not be a power of two, and a one-cycle division by C would be
    // a long path. It restarts whenever n changes and is done SLOT_W + 2 cycles later (n changes only at
    // configuration); the boot format waits for it (nb_ok).
    localparam DV_W = $clog2(C + 1);
    reg  [SLOT_W:0]   dv_src, dv_x, dv_q;
    reg  [DV_W:0]     dv_r;
    reg  [5:0]        dv_i;
    reg               dv_fin;
    wire              nb_ok = (dv_i == 0) && !dv_fin && (n_eff == dv_src);
`ifdef ORAM_OVERLAP4
    reg               nb_ok_q;
    always @(posedge clk) nb_ok_q <= nb_ok;
`endif
    always @(posedge clk or negedge rst_n)
        if (!rst_n) begin n_q <= N; nb_q <= B; dv_src <= N; dv_x <= 0; dv_q <= 0; dv_r <= 0; dv_i <= 0; dv_fin <= 1'b0; end
        else begin
            n_q <= n_eff;
            dv_fin <= 1'b0;
            if (n_eff != dv_src) begin
                dv_src <= n_eff; dv_x <= n_eff + C - 1; dv_q <= 0; dv_r <= 0; dv_i <= SLOT_W + 1;
            end else if (dv_i != 0) begin : div_step
                reg [DV_W:0] r2;
                r2 = {dv_r[DV_W-1:0], dv_x[SLOT_W]};
                dv_x <= dv_x << 1;
                if (r2 >= C) begin dv_r <= r2 - C; dv_q <= {dv_q[SLOT_W-1:0], 1'b1}; end
                else         begin dv_r <= r2;     dv_q <= {dv_q[SLOT_W-1:0], 1'b0}; end
                dv_i <= dv_i - 1'b1;
                if (dv_i == 1) dv_fin <= 1'b1;
            end else if (dv_fin) nb_q <= dv_q[BUCKET_W:0];
        end
    reg  rng_take;
    wire [BUCKET_W-1:0] prng_bucket;
    wire [BUCKET_W:0]   nb_part = nb_q >> PART_W;
    rng_bucket #(.OUT_W(BUCKET_W)) u_rng (
        .clk(clk), .rst_n(rst_n), .nb(nb_part), .take(rng_take), .bucket(prng_bucket)
    );

    // --- scratch_buf ---
    wire [AXI_DW-1:0] scr_stream_in_data; wire scr_stream_in_valid;
    wire [`SCR_AW-1:0] scr_stream_in_beat_addr;
    reg  [`SCR_AW-1:0] scr_fsm_rd_addr; reg scr_fsm_rd_en;
    wire [AXI_DW-1:0] scr_fsm_rd_data; wire scr_fsm_rd_valid;
    reg  [`SCR_AW-1:0] scr_fsm_wr_addr; reg [AXI_DW-1:0] scr_fsm_wr_data; reg scr_fsm_wr_en;
    wire [`SCR_AW-1:0] scr_stream_out_beat_addr; wire scr_stream_out_rd_en;
    wire [AXI_DW-1:0] scr_stream_out_data; wire scr_stream_out_valid;

`ifdef ORAM_OVERLAP4
`ifndef ORAM_OVERLAP2
    ORAM_OVERLAP4_needs_ORAM_OVERLAP2_too u_ov4_cfg ();   // (a missing module: an OVERLAP4-only build stops here)
`endif
`endif
`ifdef ORAM_OVERLAP2
    // =========================================================================
    // Overlap step 1 (docs/overlap_rtl_spec.md): up to two accesses in flight.
    //   F (front): accept at s, position-map lookup, bucket-record read, read gate at s + CT_RD, bucket read
    //   M (main, `state`): decryption or arrival wait, decisions, commit, encryption
    //   T (tail): write-back hand-off, release gate at t_arr + AR_REL(_H), result stream
    // Each access has a parity bit; its scratch buffer and result buffer are chosen by it (two instances of each,
    // today's templates unchanged). The bucket port has a read-only and a write-only axi_master.
    // =========================================================================
`ifdef ORAM_OVERLAP4
`ifndef ORAM_OV_P
`define ORAM_OV_P 1500
`endif
`ifndef ORAM_OV_CT_RD
`define ORAM_OV_CT_RD 266
`endif
`ifndef ORAM_OV_DEQ
`define ORAM_OV_DEQ 3600
`endif
`endif
`ifndef ORAM_OV_P
`define ORAM_OV_P 2900
`endif
`ifndef ORAM_OV_DEQ
`define ORAM_OV_DEQ 2700
`endif
    localparam [4:0] S_OV_CPW = 5'd30;          // M, on package: the write handed to T; wait for the eviction copies
    localparam integer OV_P = `ORAM_OV_P;        // fixed start spacing (cycles)
    localparam integer OV_DEQ = `ORAM_OV_DEQ;    // same-bucket shift of the read gate and of the next start
`ifdef ORAM_OVERLAP4
    localparam integer OV_CT_RD = `ORAM_OV_CT_RD; // step 2: read gate and lookup budget (access cycles from the start)
`ifndef ORAM_OV4_GA
`define ORAM_OV4_GA 1200
`endif
    // step 2: the least spacing of effective arrivals, t'(j) = max(t(j), t'(j-1) + OV_GA): covers one write-back
    // (1,024 beats and its acknowledgement), as reads in flight can return back to back after a slow one. It must stay
    // below P minus the arrival difference between the two classes (on / off package), so that it binds only after a
    // read slower than the usual (simulation: 1,500 - 261 = 1,239; build.sh sets 1,500 for the card's P = 2,150)
    localparam integer OV_GA = `ORAM_OV4_GA;
    reg  [31:0] ga_wait;                          // cycles until the next effective arrival may fall (0: now)
`endif
`ifdef ORAM_OVERLAP4
    // ---- step 2: four contexts ----
    localparam integer NC = 4;
    localparam [1:0] F_IDLE = 2'd0, F_LOOK = 2'd1, F_GATE = 2'd2;
    localparam [1:0] T_IDLE = 2'd0, T_WB = 2'd1, T_GATE = 2'd2, T_RES = 2'd3;
    localparam [2:0] E_IDLE = 3'd0, E_ADV = 3'd1, E_IV = 3'd2, E_START = 3'd3, E_FEED = 3'd4, E_RECV = 3'd5, E_TAG = 3'd6;
    reg  [1:0]  fst;
    reg  [1:0]  tst [0:NC-1];
    reg  [1:0]  f_par, mp, tp, mp_q, tp_q, w_par, w_next, rs_par, r_next, m_take, b_ctx, ej, ej_q;
    // two bucket reads in flight (axi_rd2): r_par is the context of the R burst being received, rd_ctx of the beat
    // landing in scratch, rdone_ctx of the read completing, ar_ctx of the burst address on the bus
    wire [1:0]  r_par, rd_ctx, rdone_ctx, ar_ctx; wire ra_free;
    // the read issuer: a context's read pending (looked up, not issued), the next read in access order, the gate
    // flags (f_ct >= OV_CT_RD, >= OV_CT_RD + OV_DEQ, registered with f_ct), the same-bucket mask of each context
    reg  [NC-1:0] rp, f_g0, f_g1; reg [1:0] ri_next, axir_cmd_ctx; reg [NC-1:0] f_eqmk [0:NC-1];
    // the record-read arbiter: F's lookup read and the issuer's same-bucket read wait here, one read at a time
    reg         fr_pend, rr_pend, rec_out; reg [BUCKET_W-1:0] fr_b, rr_b; reg [1:0] fr_ctx, rr_ctx;
    // front records, one per context: the request, its lookup (forwarded / corrected), its read
    reg         f_has [0:NC-1], f_looked [0:NC-1], f_hbm [0:NC-1], f_same [0:NC-1], f_instash [0:NC-1], f_eqa [0:NC-1];
    reg         f_arr [0:NC-1], f_bmseen [0:NC-1], f_rdiss [0:NC-1], f_op [0:NC-1], f_fwd [0:NC-1];
    reg  [31:0] f_ct [0:NC-1], f_tarr [0:NC-1];
    reg  [10:0] f_landed [0:NC-1];
    reg  [SLOT_AW-1:0] f_slot [0:NC-1];
    reg  [BUCKET_W-1:0] f_rnd [0:NC-1], f_b [0:NC-1], f_bnew [0:NC-1];
    reg  [`SLOT_ID_W-1:0] f_pidx [0:NC-1];
    reg  [Z*SLOT_W-1:0] f_bml [0:NC-1];
    reg  [FILL_W-1:0]   f_bmf [0:NC-1];
    reg  [NC-1:0] f_eqm;                       // F's access: which earlier contexts have its bucket (public)
    reg         wdone [0:NC-1];                // the context's write-back is acknowledged
    wire        f_eq = f_eqa[f_par];           // (the testbench's view)
    reg  [15:0] s_since, s_need;
    reg         s_any;
    reg         m_has, m_pre_ea, m_is_t;
    reg  [31:0] t_ct [0:NC-1], t_tarr [0:NC-1];
    reg  [32:0] t_rel [0:NC-1];                // t_ct - t_tarr, exact (33-bit signed): the tail's deadline checks
    reg         t_hbm [0:NC-1], t_op [0:NC-1], t_rz [0:NC-1], t_av [0:NC-1], t_byp_ov [0:NC-1], t_wbp [0:NC-1], t_wbd [0:NC-1];
    reg  [BUCKET_W-1:0] t_b [0:NC-1];
    reg  [3:0]  epd [0:NC-1];                  // positions of the context's bucket ready for its write-back
    // the eviction copies belong to c_own (set when an access's decisions start): they run on while M takes the next
    // access; only the next stash open waits for them (the stash's staging is reused)
    reg  [1:0]  c_own; reg c_own_hbm;
    reg  [1:0]  cm_age;                        // cycles since the last stash commit request (its quiet flag lags it)
    reg         axir_cmd_read; reg [BUCKET_W-1:0] axir_cmd_bucket; wire axir_busy, axiw_busy;
    // E: the encryption stage (its own GCM core), jobs in access order
    reg  [2:0]  est;
    reg  [1:0]  e_wait;
    reg         e_act;                         // E owns its context's scratch ports (an encryption)
    reg  [1:0]  eq_ctx [0:NC-1]; reg eq_hbm [0:NC-1]; reg [BUCKET_W-1:0] eq_b [0:NC-1];
    reg  [1:0]  eq_wp, eq_rp; reg [2:0] eq_n;
    reg  [BUCKET_W-1:0] e_b;
    reg  [`SCR_AW-1:0] e_rd_addr, e_wr_addr; reg e_rd_en, e_wr_en; reg [AXI_DW-1:0] e_wr_data;
    reg  [2:0]  e_fd_v, e_fd_last;               // E's scratch reads in flight (3-cycle read latency)
    reg  [10:0] e_rd_lin, e_rd_base, e_wr_lin, e_wr_lim;
    reg  [POS_W:0] e_cr_pos; reg [BEAT_W-1:0] e_beat;
    reg         e_tag_seen; reg [127:0] e_tag_q; reg [95:0] e_iv_q;
    reg         e_gcm_start, e_gcm_iv_adv, e_gcm_data_valid, e_gcm_data_last;
    reg  [AXI_DW-1:0] e_gcm_data_in; reg [95:0] e_gcm_iv_reg;
    wire [AXI_DW-1:0] e_gcm_data_out; wire e_gcm_data_out_valid, e_gcm_tag_valid, e_gcm_input_ready, e_gcm_ready;
    wire [127:0] e_gcm_tag_out; wire [95:0] e_gcm_iv_out;
    always @(posedge clk) begin mp_q <= mp; tp_q <= w_par; ej_q <= ej; end
    reg  [1:0]  mp_q2, ej_q2, w_par_d1, w_par_d2, w_par_d3;
    reg  [3:0]  w_epd_q;                          // the write's encrypted positions, a cycle late (only ever grows)
    always @(posedge clk) begin
        mp_q2 <= mp_q; ej_q2 <= ej_q; w_par_d1 <= w_par; w_par_d2 <= w_par_d1; w_par_d3 <= w_par_d2;
    end
    wire               wbpf_s_rd, wbpf_m_valid, wbpf_have, axim_wdata_stall_m;
    wire               wbpf_act  = wb_active || (state == S_FMT_WAIT);
    wire               wbpf_wait = wbpf_act && !wbpf_have;   // the master's next beat is not in wb_pf yet
    wire [`SCR_AW-1:0] wbpf_s_beat;
    wire [AXI_DW-1:0]  wbpf_m_data;
    assign client_wsel = mp;
    assign client_rsel = rs_par;
    localparam [3:0] ZP4 = Z;
    wire [3:0]  w_epd = epd[w_par];
    wire        res_busy = (tst[0] == T_RES) || (tst[1] == T_RES) || (tst[2] == T_RES) || (tst[3] == T_RES);
    wire [NC-1:0] t_busy;
    wire [AXI_DW-1:0] sc_frd [0:NC-1], sc_sod [0:NC-1];
    wire [NC-1:0] sc_frv, sc_sov, sc_bc, sc_cl;
    // four scratch buffers (today's template, unchanged): the arriving read goes to the read's context, M's ports to
    // M's, E's ports to E's (M never uses its ports while E encrypts the same context), the write-back to the write's
    genvar gk;
    // Declared here, before the generate that uses them: inside a generate block Vivado turns a name declared only
    // further down into an undriven net local to that block (Synth 8-3848; simulators and Yosys resolve it to the
    // module's). That dropped every eviction copy into the scratch on the card (round 2: buckets written back empty).
    reg  [`SCR_AW-1:0] scr_ev_wr_addr; reg [AXI_DW-1:0] scr_ev_wr_data; reg scr_ev_wr_en;
    generate for (gk = 0; gk < NC; gk = gk + 1) begin : g_scr
        wire e_on = e_act && (ej == gk);
        assign t_busy[gk] = (tst[gk] != T_IDLE);
        scratch_buf #(.OREG(1)) u_s (
            .clk(clk), .rst_n(rst_n),
            .stream_in_data(scr_stream_in_data), .stream_in_valid(scr_stream_in_valid && rd_ctx == gk),
            .stream_in_beat_addr(scr_stream_in_beat_addr), .stream_in_ready(),
            .fsm_rd_addr(e_on ? e_rd_addr : scr_fsm_rd_addr), .fsm_rd_en(e_on ? e_rd_en : (scr_fsm_rd_en && mp == gk)),
            .fsm_rd_data(sc_frd[gk]), .fsm_rd_valid(sc_frv[gk]),
            .fsm_wr_addr(e_on ? e_wr_addr : scr_fsm_wr_addr), .fsm_wr_data(e_on ? e_wr_data : scr_fsm_wr_data),
            .fsm_wr_en(e_on ? e_wr_en : (scr_fsm_wr_en && mp == gk)),
            .ev_wr_addr(scr_ev_wr_addr), .ev_wr_data(scr_ev_wr_data), .ev_wr_en(scr_ev_wr_en && c_own == gk),
            .stream_out_beat_addr(wbpf_s_beat),
            .stream_out_rd_en(wbpf_s_rd && w_par_d1 == gk),
            .stream_out_data(sc_sod[gk]), .stream_out_valid(sc_sov[gk]),
            .bank_conflict(sc_bc[gk]), .bank_clash_now(sc_cl[gk])
        );
`ifndef SYNTHESIS
        always @(posedge clk) if (e_on && ((scr_fsm_rd_en && mp == gk) || (scr_fsm_wr_en && mp == gk)))
            $display("[%0t] OVERLAP4: M and E both used scratch %0d's ports", $time, gk);
`endif
    end endgenerate
    assign scr_fsm_rd_data      = sc_frd[mp_q2];
    assign scr_fsm_rd_valid     = sc_frv[mp_q2];
    assign scr_stream_out_data  = sc_sod[w_par_d3];
    assign scr_stream_out_valid = sc_sov[w_par_d3];
    assign scr_bank_conflict    = |sc_bc;
    assign scr_clash            = |sc_cl;
    wire [AXI_DW-1:0] e_rd_data = sc_frd[ej_q2];
    // the write-back's reads, prefetched for a two-cycle scratch (wb_pf.v)
    always @(posedge clk) w_epd_q <= w_epd;
    wb_pf u_wbpf (
        .clk(clk), .rst_n(rst_n), .start(axim_cmd_write), .active(wbpf_act),
        .pos_lim(wb_active ? w_epd_q : ZP4),
        .m_beat(axim_wdata_beat_req), .m_rd(scr_stream_out_rd_en), .m_valid(wbpf_m_valid), .m_data(wbpf_m_data),
        .m_have(wbpf_have),
        .s_rd(wbpf_s_rd), .s_beat(wbpf_s_beat), .s_data(scr_stream_out_data)
    );
`else
    localparam [1:0] F_IDLE = 2'd0, F_LOOK = 2'd1, F_GATE = 2'd2;
    localparam [1:0] T_IDLE = 2'd0, T_WB = 2'd1, T_GATE = 2'd2, T_RES = 2'd3;
    reg  [1:0]  fst;
    reg  [1:0]  tst [0:1];                     // two tails, one per access parity (an access's tail can outlast P)
    reg         f_has, f_looked, f_par, f_hbm, f_same, f_instash, f_eq, f_eqm1, f_eqm2, f_arr, rd_own_m, r_par;
    reg  [31:0] f_ct, f_tarr;
    reg  [10:0] f_landed;
    reg  [SLOT_AW-1:0] f_slot;
    reg         f_op;
    reg  [BUCKET_W-1:0] f_rnd, f_b, f_bnew;
    reg  [`SLOT_ID_W-1:0] f_pidx;
    reg  [15:0] s_since, s_need;
    reg         s_any;
    reg         mp, tp, mp_q, tp_q;           // parity of M's and T's access (and one cycle late, for read data)
    reg         m_has, m_pre_ea, m_is_t;      // M holds an access; it has not passed S_EA_START; it is T's access
    reg  [31:0] t_ct [0:1], t_tarr [0:1];
    reg  [32:0] t_rel [0:1];                   // t_ct - t_tarr, exact (33-bit signed): the tail's deadline checks
    reg         t_hbm [0:1], t_op [0:1], t_rz [0:1], t_av [0:1], t_byp_ov [0:1], t_wbp [0:1], t_wbd [0:1];
    reg  [BUCKET_W-1:0] t_b [0:1];             // t_av: arrival seen; t_wbp: write not yet issued; t_wbd: handed off
    reg         w_par, w_next, rs_par, r_next, lw_u;   // the write in flight / next in order; the result streaming / next
    reg  [BUCKET_W-1:0] lw_b, lw_b2;          // the last two write-back buckets, and whether each may be unacknowledged
    reg         lw_p, lw_p2, lw_v, lw_v2;    // lw_v: the entry exists (an access took that tail)
    reg         axir_cmd_read; reg [BUCKET_W-1:0] axir_cmd_bucket; wire axir_busy, axiw_busy;
    always @(posedge clk) begin mp_q <= mp; tp_q <= w_par; end
    assign client_wsel = mp;
    assign client_rsel = rs_par;
    // the write in flight may send the positions its access has finished: M's progress while M is still on that
    // access, all of them once M has moved on (encryption, or on package the eviction copies, are then complete)
    localparam [3:0] ZP4 = Z;
    wire [3:0]  w_epd = (m_is_t && w_par == mp) ? enc_pos_done : ZP4;
    wire        t_busy0 = (tst[0] != T_IDLE), t_busy1 = (tst[1] != T_IDLE);
    wire [AXI_DW-1:0] s0_frd, s1_frd, s0_sod, s1_sod;
    wire s0_frv, s1_frv, s0_sov, s1_sov, s0_bc, s1_bc, s0_cl, s1_cl;
    // scratch #0 and #1: the arriving read goes to the read's parity, M's ports to M's, the write-back to T's
    scratch_buf u_scratch (
        .clk(clk), .rst_n(rst_n),
        .stream_in_data(scr_stream_in_data), .stream_in_valid(scr_stream_in_valid && !r_par),
        .stream_in_beat_addr(scr_stream_in_beat_addr), .stream_in_ready(),
        .fsm_rd_addr(scr_fsm_rd_addr), .fsm_rd_en(scr_fsm_rd_en && !mp),
        .fsm_rd_data(s0_frd), .fsm_rd_valid(s0_frv),
        .fsm_wr_addr(scr_fsm_wr_addr), .fsm_wr_data(scr_fsm_wr_data),
        .fsm_wr_en(scr_fsm_wr_en && !mp),
        .ev_wr_addr(scr_ev_wr_addr), .ev_wr_data(scr_ev_wr_data), .ev_wr_en(scr_ev_wr_en && !mp),
        .stream_out_beat_addr(scr_stream_out_beat_addr),
        .stream_out_rd_en(scr_stream_out_rd_en && !w_par),
        .stream_out_data(s0_sod), .stream_out_valid(s0_sov),
        .bank_conflict(s0_bc), .bank_clash_now(s0_cl)
    );
    scratch_buf u_scratch1 (
        .clk(clk), .rst_n(rst_n),
        .stream_in_data(scr_stream_in_data), .stream_in_valid(scr_stream_in_valid && r_par),
        .stream_in_beat_addr(scr_stream_in_beat_addr), .stream_in_ready(),
        .fsm_rd_addr(scr_fsm_rd_addr), .fsm_rd_en(scr_fsm_rd_en && mp),
        .fsm_rd_data(s1_frd), .fsm_rd_valid(s1_frv),
        .fsm_wr_addr(scr_fsm_wr_addr), .fsm_wr_data(scr_fsm_wr_data),
        .fsm_wr_en(scr_fsm_wr_en && mp),
        .ev_wr_addr(scr_ev_wr_addr), .ev_wr_data(scr_ev_wr_data), .ev_wr_en(scr_ev_wr_en && mp),
        .stream_out_beat_addr(scr_stream_out_beat_addr),
        .stream_out_rd_en(scr_stream_out_rd_en && w_par),
        .stream_out_data(s1_sod), .stream_out_valid(s1_sov),
        .bank_conflict(s1_bc), .bank_clash_now(s1_cl)
    );
    assign scr_fsm_rd_data      = mp_q ? s1_frd : s0_frd;
    assign scr_fsm_rd_valid     = mp_q ? s1_frv : s0_frv;
    assign scr_stream_out_data  = tp_q ? s1_sod : s0_sod;
    assign scr_stream_out_valid = tp_q ? s1_sov : s0_sov;
    assign scr_bank_conflict    = s0_bc | s1_bc;
    assign scr_clash            = s0_cl | s1_cl;
`endif
`else
    scratch_buf u_scratch (
        .clk(clk), .rst_n(rst_n),
        .stream_in_data(scr_stream_in_data), .stream_in_valid(scr_stream_in_valid),
        .stream_in_beat_addr(scr_stream_in_beat_addr), .stream_in_ready(),
        .fsm_rd_addr(scr_fsm_rd_addr), .fsm_rd_en(scr_fsm_rd_en),
        .fsm_rd_data(scr_fsm_rd_data), .fsm_rd_valid(scr_fsm_rd_valid),
        .fsm_wr_addr(scr_fsm_wr_addr), .fsm_wr_data(scr_fsm_wr_data),
        .fsm_wr_en(scr_fsm_wr_en),
        .ev_wr_addr(scr_ev_wr_addr), .ev_wr_data(scr_ev_wr_data), .ev_wr_en(scr_ev_wr_en),
        .stream_out_beat_addr(scr_stream_out_beat_addr),
        .stream_out_rd_en(scr_stream_out_rd_en),
        .stream_out_data(scr_stream_out_data), .stream_out_valid(scr_stream_out_valid),
        .bank_conflict(scr_bank_conflict), .bank_clash_now(scr_clash)
    );
`endif

    // --- stash ---
    reg  [SLOT_AW-1:0] st_ins_slot; reg [BUCKET_W-1:0] st_ins_tgt; reg st_ins_en;
    wire [PTR_W-1:0] st_ins_idx; wire st_ins_full;
    reg  [PTR_W-1:0] st_remap_idx; reg [BUCKET_W-1:0] st_remap_bkt; reg st_remap_en;
    reg  [PTR_W-1:0] st_evict_idx; reg st_evict_en;
    reg  [PTR_W-1:0] st_dwr_entry; reg [BEAT_W-1:0] st_dwr_beat;
    reg  [AXI_DW-1:0] st_dwr_data; reg st_dwr_en;
    reg  [PTR_W-1:0] st_drd_entry; reg [BEAT_W-1:0] st_drd_beat; reg st_drd_en;
    wire [AXI_DW-1:0] st_drd_data; wire st_drd_valid;
    wire st_cam_slot_hit; wire [PTR_W-1:0] st_cam_slot_idx;
    reg  [BUCKET_W-1:0] st_cam_bkt_target; reg st_cam_bkt_en;
    wire st_cam_bkt_hit; wire [PTR_W-1:0] st_cam_bkt_idx;
    wire [SLOT_AW-1:0] st_cam_bkt_slot_addr; wire st_cam_bkt_inhibit_busy;

    // The stash lives in HBM (stash_hbm): per-bucket lists of pointers into a pool of blocks, like
    // BOLT's eviction buffer. Each access opens two buckets at the position lookup (the bucket read and
    // the new target); the lists and the blocks this access can touch are prefetched on chip while the
    // bucket is read and verified, so S_SCAN waits for `ready` and every stash operation after that is
    // served on chip. S_EA_START commits (lists and written blocks back to HBM); the access completes
    // only when the stash's writes are acknowledged. Single client: one stash.
    reg  st_open_en, st_commit, st_init_go, st_open_req; reg [BUCKET_W-1:0] st_open_b, st_open_bt; reg [SLOT_AW-1:0] st_open_slot;
    reg  st_open_instash; reg [`SLOT_ID_W-1:0] st_open_pidx; wire [`SLOT_ID_W-1:0] st_ins_pidx;
    wire st_ready, st_wr_quiet, st_err, st_init_done;
    wire [15:0] st_landed;                           // v14d: the staging slots whose blocks are on chip
`ifdef ORAM_ONPKG_DEBUG
    wire [7:0] st_dbg_open;                          // v14c debug build: the stash open's composition (stash_hbm)
`endif
    stash_hbm #(.P(STASH_DEPTH), .AXI_DW(AXI_DW)) u_stash (
        .clk(clk), .rst_n(rst_n), .nb(nb_q), .pool_n(cfg_pool_n), .init_go(st_init_go), .init_done(st_init_done),
        .open_en(st_open_en), .open_b(st_open_b), .open_bt(st_open_bt), .open_slot(st_open_slot),
        .open_instash(st_open_instash), .open_pidx(st_open_pidx),
        .ready(st_ready), .commit(st_commit),
        .cam_slot_addr(req_slot_addr), .cam_slot_en(1'b1), .cam_slot_hit(st_cam_slot_hit), .cam_slot_idx(st_cam_slot_idx),
        .cam_bkt_target(st_cam_bkt_target), .cam_bkt_en(st_cam_bkt_en), .cam_bkt_hit(st_cam_bkt_hit),
        .cam_bkt_idx(st_cam_bkt_idx), .cam_bkt_slot_addr(st_cam_bkt_slot_addr), .cam_bkt_inhibit_busy(st_cam_bkt_inhibit_busy),
        .ins_slot_addr(st_ins_slot), .ins_target_bucket(st_ins_tgt), .ins_en(st_ins_en), .ins_idx(st_ins_idx), .ins_pidx(st_ins_pidx), .ins_full(st_ins_full),
        .remap_idx(st_remap_idx), .remap_new_bucket(st_remap_bkt), .remap_en(st_remap_en),
        .evict_idx(st_evict_idx), .evict_en(st_evict_en),
        .dwr_entry(st_dwr_entry), .dwr_beat(st_dwr_beat), .dwr_data(st_dwr_data), .dwr_en(st_dwr_en),
        .drd_entry(st_drd_entry), .drd_beat(st_drd_beat), .drd_en(st_drd_en), .drd_data(st_drd_data), .drd_valid(st_drd_valid),
        .occupancy(stash_occupancy), .landed(st_landed), .wr_quiet(st_wr_quiet), .err(st_err),
`ifdef ORAM_ONPKG_DEBUG
        .dbg_open(st_dbg_open),
`endif
        
`ifdef ORAM_STASH_PC_IDS
        .m_arid(m_stash_arid), .m_rid(m_stash_rid),
`else
        .m_arid(), .m_rid(2'd0),
`endif
        .m_araddr(m_stash_araddr), .m_arlen(m_stash_arlen), .m_arsize(m_stash_arsize), .m_arburst(m_stash_arburst), .m_arvalid(m_stash_arvalid), .m_arready(m_stash_arready), .m_rdata(m_stash_rdata), .m_rlast(m_stash_rlast), .m_rvalid(m_stash_rvalid), .m_rready(m_stash_rready), .m_awaddr(m_stash_awaddr), .m_awlen(m_stash_awlen), .m_awsize(m_stash_awsize), .m_awburst(m_stash_awburst), .m_awvalid(m_stash_awvalid), .m_awready(m_stash_awready), .m_wdata(m_stash_wdata), .m_wstrb(m_stash_wstrb), .m_wlast(m_stash_wlast), .m_wvalid(m_stash_wvalid), .m_wready(m_stash_wready), .m_bvalid(m_stash_bvalid), .m_bready(m_stash_bready)
    );

    // --- axi_master ---
    reg axim_cmd_read, axim_cmd_write; reg [BUCKET_W-1:0] axim_cmd_bucket;
    wire axim_read_done, axim_write_done, axim_busy, axim_wr_quiet;
    wire [AXI_DW-1:0] axim_rdata_data; wire axim_rdata_valid; wire [`SCR_AW-1:0] axim_rdata_beat;
    wire [`SCR_AW-1:0] axim_wdata_beat_req;

    // v14: an on-package bucket's format writes zeros (no encryption has filled the scratch with encrypted zeros):
    // the master's write data is forced to zero at its output while fmt_zero is set (from S_FMT_START to that
    // bucket's write done). At the output, not on the scratch-to-master path: that path starts at a block RAM.
    wire [AXI_DW-1:0] axim_wdata_m;
    assign m_axi_wdata = fmt_zero ? {AXI_DW{1'b0}} : axim_wdata_m;
`ifdef ORAM_OVERLAP2
    // read-only master: AR/R of the bucket port (it never writes, so it never holds a read behind a write; the
    // same-bucket rule does that, F_GATE). The write-only master below drives AW/W/B and reports wr_quiet.
`ifdef ORAM_OVERLAP4
    // step 2: two bucket reads in flight, data in issue order (axi_rd2.v)
    axi_rd2 #(.BEAT_AW(`SCR_AW)) u_axi_rd (
        .clk(clk), .rst_n(rst_n),
        .cmd_read(axir_cmd_read), .cmd_bucket(axir_cmd_bucket), .cmd_ctx(axir_cmd_ctx),
        .free(ra_free), .busy_any(), .busy_all(axir_busy),
        .rdata_data(axim_rdata_data), .rdata_valid(axim_rdata_valid), .rdata_beat_addr(axim_rdata_beat), .rdata_ctx(rd_ctx),
        .read_done(axim_read_done), .done_ctx(rdone_ctx), .ar_ctx(ar_ctx), .r_ctx(r_par),
        .m_axi_arid(m_axi_arid), .m_axi_araddr(m_axi_araddr), .m_axi_arlen(m_axi_arlen), .m_axi_arsize(m_axi_arsize),
        .m_axi_arburst(m_axi_arburst), .m_axi_arvalid(m_axi_arvalid), .m_axi_arready(m_axi_arready),
        .m_axi_rid(m_axi_rid), .m_axi_rdata(m_axi_rdata), .m_axi_rresp(m_axi_rresp), .m_axi_rlast(m_axi_rlast),
        .m_axi_rvalid(m_axi_rvalid), .m_axi_rready(m_axi_rready)
    );
`else
    axi_master #(.BEAT_AW(`SCR_AW)) u_axi_rd (
        .clk(clk), .rst_n(rst_n),
        .cmd_read(axir_cmd_read), .cmd_write(1'b0), .cmd_bucket(axir_cmd_bucket),
        .cmd_read_done(axim_read_done), .cmd_write_done(), .cmd_busy(axir_busy), .wr_quiet(),
        .rdata_data(axim_rdata_data), .rdata_valid(axim_rdata_valid), .rdata_beat_addr(axim_rdata_beat),
        .wdata_data({AXI_DW{1'b0}}), .wdata_valid(1'b0), .wdata_ready(), .wdata_beat_req(),
        .wdata_hold(1'b0), .wdata_stall(),
        .m_axi_arid(m_axi_arid), .m_axi_araddr(m_axi_araddr), .m_axi_arlen(m_axi_arlen), .m_axi_arsize(m_axi_arsize),
        .m_axi_arburst(m_axi_arburst), .m_axi_arvalid(m_axi_arvalid), .m_axi_arready(m_axi_arready),
        .m_axi_rid(m_axi_rid), .m_axi_rdata(m_axi_rdata), .m_axi_rresp(m_axi_rresp), .m_axi_rlast(m_axi_rlast),
        .m_axi_rvalid(m_axi_rvalid), .m_axi_rready(m_axi_rready),
        .m_axi_awid(), .m_axi_awaddr(), .m_axi_awlen(), .m_axi_awsize(), .m_axi_awburst(), .m_axi_awvalid(),
        .m_axi_awready(1'b0), .m_axi_wdata(), .m_axi_wstrb(), .m_axi_wlast(), .m_axi_wvalid(), .m_axi_wready(1'b0),
        .m_axi_bid({AXI_IDW{1'b0}}), .m_axi_bresp(2'b00), .m_axi_bvalid(1'b0), .m_axi_bready()
    );
`endif
    axi_master #(.BEAT_AW(`SCR_AW)) u_axi_master (
        .clk(clk), .rst_n(rst_n),
        .cmd_read(1'b0), .cmd_write(axim_cmd_write),
        .cmd_bucket(axim_cmd_bucket),
        .cmd_read_done(), .cmd_write_done(axim_write_done),
        .cmd_busy(axiw_busy), .wr_quiet(axim_wr_quiet),
        .rdata_data(), .rdata_valid(),
        .rdata_beat_addr(),
`ifdef ORAM_OVERLAP4
        .wdata_data(wbpf_m_data), .wdata_valid(wbpf_m_valid),
`else
        .wdata_data(scr_stream_out_data), .wdata_valid(scr_stream_out_valid),
`endif
        .wdata_ready(), .wdata_beat_req(axim_wdata_beat_req),
`ifdef ORAM_OVERLAP4
        .wdata_hold(axim_wdata_hold || wbpf_wait), .wdata_stall(axim_wdata_stall_m),
`else
        .wdata_hold(axim_wdata_hold), .wdata_stall(axim_wdata_stall),
`endif
        .m_axi_arid(), .m_axi_araddr(), .m_axi_arlen(), .m_axi_arsize(), .m_axi_arburst(), .m_axi_arvalid(),
        .m_axi_arready(1'b0), .m_axi_rid({AXI_IDW{1'b0}}), .m_axi_rdata({AXI_DW{1'b0}}), .m_axi_rresp(2'b00),
        .m_axi_rlast(1'b0), .m_axi_rvalid(1'b0), .m_axi_rready(),
        .m_axi_awid(m_axi_awid), .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awlen(m_axi_awlen), .m_axi_awsize(m_axi_awsize),
        .m_axi_awburst(m_axi_awburst), .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awready(m_axi_awready),
        .m_axi_wdata(axim_wdata_m), .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wlast(m_axi_wlast), .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready),
        .m_axi_bid(m_axi_bid), .m_axi_bresp(m_axi_bresp),
        .m_axi_bvalid(m_axi_bvalid), .m_axi_bready(m_axi_bready)
    );
    assign axim_busy = axir_busy | axiw_busy;
`else
    axi_master #(.BEAT_AW(`SCR_AW)) u_axi_master (
        .clk(clk), .rst_n(rst_n),
        .cmd_read(axim_cmd_read), .cmd_write(axim_cmd_write),
        .cmd_bucket(axim_cmd_bucket),
        .cmd_read_done(axim_read_done), .cmd_write_done(axim_write_done),
        .cmd_busy(axim_busy), .wr_quiet(axim_wr_quiet),
        .rdata_data(axim_rdata_data), .rdata_valid(axim_rdata_valid),
        .rdata_beat_addr(axim_rdata_beat),
        .wdata_data(scr_stream_out_data), .wdata_valid(scr_stream_out_valid),
        .wdata_ready(), .wdata_beat_req(axim_wdata_beat_req),
        .wdata_hold(axim_wdata_hold), .wdata_stall(axim_wdata_stall),
        .m_axi_arid(m_axi_arid), .m_axi_araddr(m_axi_araddr),
        .m_axi_arlen(m_axi_arlen), .m_axi_arsize(m_axi_arsize),
        .m_axi_arburst(m_axi_arburst), .m_axi_arvalid(m_axi_arvalid),
        .m_axi_arready(m_axi_arready),
        .m_axi_rid(m_axi_rid), .m_axi_rdata(m_axi_rdata),
        .m_axi_rresp(m_axi_rresp), .m_axi_rlast(m_axi_rlast),
        .m_axi_rvalid(m_axi_rvalid), .m_axi_rready(m_axi_rready),
        .m_axi_awid(m_axi_awid), .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awlen(m_axi_awlen), .m_axi_awsize(m_axi_awsize),
        .m_axi_awburst(m_axi_awburst), .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awready(m_axi_awready),
        .m_axi_wdata(axim_wdata_m), .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wlast(m_axi_wlast), .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready),
        .m_axi_bid(m_axi_bid), .m_axi_bresp(m_axi_bresp),
        .m_axi_bvalid(m_axi_bvalid), .m_axi_bready(m_axi_bready)
    );
`endif

    assign scr_stream_in_data      = axim_rdata_data;
    assign scr_stream_in_valid     = axim_rdata_valid;
    assign scr_stream_in_beat_addr = axim_rdata_beat;
    assign scr_stream_out_beat_addr = axim_wdata_beat_req;
`ifdef ORAM_OVERLAP2
    assign axim_wdata_hold = wb_active && (w_epd < Z) &&
                             ({1'b0, axim_wdata_beat_req[BEAT_AW +: POS_W]} >= w_epd);
`else
    assign axim_wdata_hold = wb_active && (enc_pos_done < Z) &&
                             ({1'b0, axim_wdata_beat_req[BEAT_AW +: POS_W]} >= enc_pos_done);
`endif
    // Write-back streams while later positions are still being encrypted: the
    // master may only read positions already re-encrypted (never plaintext), and
    // the scratch read is suppressed while it is held. v14, on-package bucket: the
    // master may only read positions whose eviction copies have landed (enc_pos_done
    // counts those there), so the plaintext write streams behind the copies.
`ifdef ORAM_OVERLAP4
    // step 2: the master reads (wb_pf answers) only beats already prefetched; a stall is the original hold's alone
    assign scr_stream_out_rd_en = ((wb_active && !axim_wdata_hold) || (state == S_FMT_WAIT)) && !wbpf_wait;
    assign axim_wdata_stall     = axim_wdata_stall_m && axim_wdata_hold;
`else
    assign scr_stream_out_rd_en = (wb_active && !axim_wdata_hold) || (state == S_FMT_WAIT);
`endif
    assign client_wdata_beat_req = beat_cnt;

    // =========================================================================
    // Helper functions
    // =========================================================================
    function [SLOT_AW-1:0] get_slot_at;
        input [Z*SLOT_W-1:0] list; input [POS_W-1:0] pos;
        integer base;
        begin base = pos * SLOT_W; get_slot_at = list[base +: SLOT_W] << 12; end
    endfunction

    function [Z*SLOT_W-1:0] set_slot_at;
        input [Z*SLOT_W-1:0] list; input [POS_W-1:0] pos; input [SLOT_W-1:0] val;
        integer base;
        begin set_slot_at = list; base = pos * SLOT_W; set_slot_at[base +: SLOT_W] = val; end
    endfunction

    // {position, beat within the block}: the same layout the scratch buffer and the AXI streams
    // use. (This used a fixed 7-bit beat field, right only for 128-beat blocks.)
    function [`SCR_AW-1:0] scr_addr;
        input [POS_W-1:0] p; input [BEAT_W-1:0] b;
        reg   [`SCR_AW-1:0] pe, be;
        begin
            pe = p; be = b;
            scr_addr = (pe << $clog2(BEATS)) | (be & (BEATS - 1));
        end
    endfunction

    // =========================================================================
    // Debug
    // =========================================================================
    assign dbg_state          = state;
    assign dbg_client_done    = client_done;
    assign dbg_client_req     = client_req;
    assign dbg_req_b          = req_b;
    assign dbg_req_b_new      = req_b_new;
    assign dbg_found_in_bucket = found_in_bucket;
    assign dbg_found_in_stash = found_in_stash;
    assign dbg_same_bucket    = same_bucket;
    assign dbg_err_stash_ovf  = err_stash_overflow;
    assign dbg_stash_occ      = stash_occupancy;
    assign dbg_gcm_tag_valid = gcm_tag_valid;
    assign dbg_gcm_tag_match = gcm_tag_match;
    // =========================================================================
    // Main FSM
    // =========================================================================
    // =========================================================================
    // Phase 2 (F3, F5-F8): full-bucket verify / re-encrypt, constant time
    // =========================================================================
    // Every access: read the whole bucket, decrypt and VERIFY all Z positions
    // (holes included), do the operation on plaintext, evict, RE-ENCRYPT all Z
    // positions with fresh IVs, write the whole bucket back. Bucket read,
    // write-back and result release happen at fixed cycle counts after
    // acceptance (CT_RD / CT_WB / CT_DONE); results are released only after
    // verification. Any integrity failure, stash overflow or timing overrun is
    // sticky and fail-stop. After reset (once a key is loaded) a format pass
    // writes an encrypted zero block to every position of every bucket.
    localparam integer CT_RD   = `ORAM_CT_RD;
    localparam integer CT_WB   = `ORAM_CT_WB;
    localparam integer CT_DONE = `ORAM_CT_DONE;
    localparam [1:0] CR_DA = 2'd0, CR_EA = 2'd1, CR_FMT = 2'd2;
    localparam [1:0] CPS_SCR = 2'd0, CPS_STASH = 2'd1, CPS_CLIENT = 2'd2;
    reg  [31:0]       ct_cnt;
    // Crypto streaming
    reg  [10:0]       landed_beats;    // read-stream beats in scratch for this access
    reg  [3:0]        enc_pos_done;    // positions fully re-encrypted (0..Z)
    // Decryption keeps pace with the bucket read: a beat is read from scratch as soon as it has landed (two-lane core:
    // one beat per cycle, the memory's rate). Its plaintext goes back to the same scratch bank, whose single write port
    // the landing beats hold until the position has fully landed, so the core's output beats pass through a short
    // queue (LUT-RAM, OQ_D beats) that writes a beat only once its position has landed. Reads stop while OQ_D beats are
    // read and not yet written back, so the queue cannot overflow. The last position's plaintext is written once it
    // has landed, one beat per cycle: decryption ends about BEATS + 5 cycles after the bucket's last beat (at 4 KB,
    // one position of 128 beats; the old core needed 2 cycles per beat for every position). Encryption and the boot
    // format never come near the limit (their writes follow the core at once).
    localparam integer OQ_AW = 5, OQ_D = 1 << OQ_AW;
    (* ram_style = "distributed" *) reg [AXI_DW-1:0] oq_d [0:OQ_D-1];
    reg  [OQ_AW-1:0]  oq_wp, oq_rp;
    reg  [OQ_AW:0]    oq_n;
    reg               wb_pending;      // write-back not yet issued (issued at CT_WB)
    // ---- arrival-relative scheduling (build option ORAM_SCHED_ARRIVAL) ----
    // An access's write-back and end follow the bucket read's last beat (t_arr, a bus event the attacker sees;
    // the bucket master never back-pressures a read) by the fixed times AR_WB and AR_DONE. Hidden work stays
    // padded: the read issues at CT_RD (the position-map lookup), and AR_WB covers the worst on-chip work
    // after the arrival. The boot format (cr_mode == CR_FMT) reads no bucket and keeps CT_WB / CT_DONE.
`ifdef ORAM_SCHED_ARRIVAL
    localparam        AR_MODE = 1'b1;
`ifdef ORAM_OVERLAP4
    // step 2: the main and encryption stages queue behind the previous accesses, so the write-back and release come a
    // fixed allowance later after the arrival (ORAM_OV4_X*: calibrated, simulation then card)
`ifndef ORAM_OV4_XWB
`define ORAM_OV4_XWB 700
`endif
`ifndef ORAM_OV4_XWB_H
`define ORAM_OV4_XWB_H 1200
`endif
`ifndef ORAM_OV4_XREL_H
`define ORAM_OV4_XREL_H 1400
`endif
    localparam integer AR_WB  = `ORAM_AR_WB + `ORAM_OV4_XWB, AR_DONE = `ORAM_AR_DONE + `ORAM_OV4_XWB,
                       AR_DONE_H = `ORAM_AR_DONE_H + `ORAM_OV4_XREL_H, AR_WB_H = `ORAM_AR_WB_H + `ORAM_OV4_XWB_H;
    localparam integer AR_REL = `ORAM_AR_REL + `ORAM_OV4_XWB, AR_REL_H = `ORAM_AR_REL_H + `ORAM_OV4_XREL_H;
`ifdef ORAM_OV4_P3
`ifndef ORAM_OV_PMIN
`define ORAM_OV_PMIN 1500
`endif
`ifndef ORAM_OV4_LEQ
`define ORAM_OV4_LEQ 0
`endif
`ifndef ORAM_OV4_L
`define ORAM_OV4_L 0
`endif
    // phase 3 (section 17). OV_LEQ: after an access's effective arrival, its write-back (at AR_WB) has been streamed,
    // acknowledged AND has become readable, so a later read of the same bucket may issue. OV_L: after it, the context
    // is free (release, result, acknowledgement), so the access four later may start. 0: the defaults below.
    // 2026-11-05 (section 19): a host write may become readable some time after its acknowledgement (a posted PCIe
    // write); the default leaves 3,300 cycles after the write's last beat, about round 4's margin (its D_EQ), instead
    // of 300. (The card's integrity halts themselves were a record-unit race, section 20.) OV_L no longer follows
    // OV_LEQ: a context whose access has same-bucket readers still waiting is held by the start rule's own term
    // (eq_hold) until they have issued.
    localparam integer OV_PMIN = `ORAM_OV_PMIN;
    localparam integer OV_LEQ  = (`ORAM_OV4_LEQ != 0) ? `ORAM_OV4_LEQ : AR_WB + 1024 + 3300;
    localparam integer OV_L0   = ((AR_REL_H > AR_REL) ? AR_REL_H : AR_REL) + 250;
    localparam integer OV_L    = (`ORAM_OV4_L != 0) ? `ORAM_OV4_L : OV_L0;
    reg  [15:0] cfc [0:NC-1], eqc [0:NC-1];  // cycles until the context is free / its same-bucket readers may read
    reg         cf_wait [0:NC-1];            // accepted, its read not yet arrived
    reg         ea_arr  [0:NC-1];            // arrived since its accept
    reg         f_eqok  [0:NC-1];            // its same-bucket gate has passed (sticky until its next accept)
    wire [NC-1:0] cf_ok, ea_ok;
    reg  [NC-1:0] eq_hold;                   // a same-bucket reader of the context's access has not issued its read
    genvar gp;
    generate for (gp = 0; gp < NC; gp = gp + 1) begin : g_p3
        assign cf_ok[gp] = !cf_wait[gp] && cfc[gp] == 16'd0;
        assign ea_ok[gp] = ea_arr[gp] && eqc[gp] == 16'd0;
    end endgenerate
    always @(*) begin : p3_hold
        integer q, k;
        for (k = 0; k < NC; k = k + 1) begin
            eq_hold[k] = 1'b0;
            for (q = 0; q < NC; q = q + 1) if (rp[q] && f_eqa[q] && f_eqmk[q][k]) eq_hold[k] = 1'b1;
        end
    end
`endif
`else
    localparam integer AR_WB  = `ORAM_AR_WB, AR_DONE = `ORAM_AR_DONE, AR_DONE_H = `ORAM_AR_DONE_H, AR_WB_H = `ORAM_AR_WB_H;
    localparam integer AR_REL = `ORAM_AR_REL, AR_REL_H = `ORAM_AR_REL_H;   // release once the write-back data is handed off
`endif
`else
    localparam        AR_MODE = 1'b0;
    localparam integer AR_WB  = 0, AR_DONE = 0, AR_DONE_H = 0, AR_WB_H = 0, AR_REL = 0, AR_REL_H = 0;
`endif
`ifdef ORAM_ONPKG_FIXWB
    // Option A (docs/fixwb_option_a.md): the on-package write-back starts at exactly t_arr + AR_WBF_H and streams
    // hold-free. 440 at 4 KB, lambda 7: the card's worst first write beat (305) plus its worst hold (28), + 10% + 74.
`ifdef ORAM_OVERLAP2
    ORAM_ONPKG_FIXWB_is_not_supported_with_the_overlap_builds_yet u_fixwb_ov ();
`endif
`ifndef ORAM_SCHED_ARRIVAL
    ORAM_ONPKG_FIXWB_needs_ORAM_SCHED_ARRIVAL u_fixwb_sched ();
`endif
`ifdef ORAM_AR_WBF_H
    localparam integer AR_WBF_H = `ORAM_AR_WBF_H;
`else
    localparam integer AR_WBF_H = 440;
    generate if (!(C == 7 && BEATS == 128)) begin : g_wbf
        ORAM_ONPKG_FIXWB_needs_ORAM_AR_WBF_H_for_this_block_size_and_lambda u_wbf ();
    end endgenerate
`endif
`endif
`ifdef ORAM_NOCRYPTO
    // NOCRYPTO (docs/nocrypto.md, evaluation builds only): every bucket, host memory included, takes the on-package
    // plaintext path: no AES-GCM, no tag, no IV. acc_hbm keeps its meaning, the bucket's class (where it is), and selects
    // that class's fixed times; both classes run Option A's schedule: the write-back at exactly t_arr + WBF, hold-free,
    // the release at exactly t_arr + REL. oram_params.vh holds the times per block size and class.
`ifndef ORAM_ONPKG_FIXWB
    ORAM_NOCRYPTO_needs_ORAM_ONPKG_FIXWB u_nc_fixwb ();
`endif
`ifdef ORAM_OVERLAP2
    ORAM_NOCRYPTO_is_not_supported_with_the_overlap_builds u_nc_ov ();
`endif
`ifndef ORAM_SCHED_ARRIVAL
    ORAM_NOCRYPTO_needs_ORAM_SCHED_ARRIVAL u_nc_sched ();
`endif
`ifdef ORAM_ONPKG_INTERIM
    ORAM_NOCRYPTO_replaces_the_interim_budgets u_nc_int ();
`endif
    localparam integer AR_WBF = `ORAM_AR_WBF;
    generate if (C != 7 || AR_WBF_H == 0 || AR_WBF == 0 || AR_REL_H == 0 || AR_REL == 0) begin : g_nc_table
        // no fixed times for this block size or lambda: give them explicitly (build.sh WBF= WBF_HOST= REL= REL_HOST=, lambda 7)
        ORAM_NOCRYPTO_has_no_times_for_this_block_size_or_lambda u_nc_table ();
    end endgenerate
    generate if (AR_WBF_H >= AR_REL_H || AR_WBF >= AR_REL) begin : g_nc_times
        ORAM_NOCRYPTO_write_back_time_must_be_before_the_release u_nc_times ();
    end endgenerate
`ifdef TB_NC_LEAK
    // TEST ONLY (the regression's negative control): a PUT's write-back one cycle late, a secret on the bus
    wire [31:0] nc_wbf = (acc_hbm ? AR_WBF_H : AR_WBF) + (req_op ? 32'd1 : 32'd0);
`else
    wire [31:0] nc_wbf = acc_hbm ? AR_WBF_H : AR_WBF;   // this access's write-back time after its arrival
`endif
    // the release time: the kernel registers rel / rel_h if set (fixed for the whole run, written before ap_start), else the
    // build's. Registered: acc_hbm is known long before the arrival, and the release comparison keeps its one adder
    wire [31:0] nc_rel_o = (cfg_nc_rel   != 16'd0) ? {16'd0, cfg_nc_rel}   : AR_REL;
    wire [31:0] nc_rel_h = (cfg_nc_rel_h != 16'd0) ? {16'd0, cfg_nc_rel_h} : AR_REL_H;
    reg  [31:0] nc_rel;                                  //             and its release time
    always @(posedge clk) nc_rel <= acc_hbm ? nc_rel_h : nc_rel_o;
    reg  [31:0] nc_ct_rd;                                // the read gate: register ctrd if set, else CT_RD (fixed for the run)
    always @(posedge clk) nc_ct_rd <= (cfg_nc_ctrd != 16'd0) ? {16'd0, cfg_nc_ctrd} : CT_RD;
    // readouts for the budgets (simulation: sim/budgets_nocrypto.py; synthesis trims them): worst value per class
    reg  [31:0] nc_need;                                 // this access: the earliest t_arr + WBF that serves it, as ct_cnt
    reg  [31:0] ar_max_need, ar_max_need_h;              // worst (nc_need - t_arr): the decisions and every copy in time
    reg  [31:0] ar_max_dec, ar_max_dec_h;                // worst (decisions' end - t_arr)
    reg  [31:0] ar_max_wr, ar_max_wr_h;                  // worst (hand-off - t_arr - WBF): the write, issue to last beat accepted
    reg  [31:0] nc_acc_seen;                             // accesses counted in these readouts
    initial begin nc_need = 0; ar_max_need = 0; ar_max_need_h = 0; ar_max_dec = 0; ar_max_dec_h = 0; ar_max_wr = 0; ar_max_wr_h = 0; nc_acc_seen = 0; end
`endif
    reg  [31:0]       t_arr;           // ct_cnt when this access's bucket read completed
    reg               arr_seen;
`ifdef ORAM_OVERLAP4
    // step 2: the time since the effective arrival, 0 while it is still ahead (calibration readouts only)
    wire [31:0] ar_since  = (ct_cnt >= t_arr) ? ct_cnt - t_arr : 32'd0;                    // readouts only
    wire [31:0] ar_since1 = (ct_cnt + 32'd1 >= t_arr) ? ct_cnt + 32'd1 - t_arr : 32'd0;
`endif
    // (acc_hbm: declared with BYP, above)
    reg  [31:0]       ar_max_wb;       // worst (encryption end - t_arr), off-package buckets: calibrates AR_WB
    reg  [31:0]       ar_max_wb_h;     // the same for HBM buckets: calibrates AR_WB_H (v14, BYP: worst write-back start)
    reg  [31:0]       ar_max_rel_h;    // v14, BYP: worst (release gate reached - t_arr), the write handed off: calibrates AR_REL_H
    reg               bm_seen;         // v14: this access's bucket record (metadata beat) has arrived
    reg               byp_ov;          // v14: an on-package timing miss, reported at the release time (t_arr + AR_REL_H)
    // v14b: which on-package deadline this access missed, and by how many cycles (the halt record, every build):
    // ov_d1 the write-back had not started at t_arr + AR_WB_H; ov_d2 the write was not handed off at t_arr + AR_REL_H;
    // ov_bc a scratch bank conflict. ov_by1 / ov_by2 count from the deadline to the late event (S_EA_START reached /
    // S_DONE_GATE reached), ov_run1 / ov_run2 while it has not happened. ov_rel: the release check raised the overrun.
    reg               ov_d1, ov_d2, ov_bc, ov_rel, ov_run1, ov_run2, halt_rel;
    reg  [15:0]       ov_by1, ov_by2;
`ifdef ORAM_ONPKG_DEBUG
    localparam        ONPKG_HALT = 1'b0;   // debug build: an on-package overrun is counted and recorded, never halts
`else
    localparam        ONPKG_HALT = 1'b1;
`endif
    reg               wb_active;       // write-back in progress
    reg               wb_done_seen;
    wire              axim_wdata_hold, axim_wdata_stall, scr_bank_conflict, scr_clash;
    // Eviction overlap: the eviction loop only decides (which stash entry goes to
    // which position); a background engine performs the 128-beat copies while the
    // encryption runs, and encryption of a position waits only for its own copy.
    reg  [PTR_W-1:0]  evq_ent [0:15];  // copy queue: source stash entry (up to Z evictions)
    reg  [POS_W-1:0]  evq_pos [0:15];  //             destination position
    reg  [4:0]        evq_wp, evq_rp;
    reg  [15:0]       ev_pending;      // positions whose eviction copy is not done (Z <= 16)
    reg               ec_active;
    reg  [PTR_W-1:0]  ec_ent;
    reg  [POS_W-1:0]  ec_pos;
    localparam EC_W = $clog2(BEATS + 1);             // eviction-copy beat counters count 0..BEATS
    reg  [EC_W-1:0]   ec_rd_beat, ec_wr_beat;
    wire [BEAT_W-1:0] ec_rd_beat_x = ec_rd_beat, ec_wr_beat_x = ec_wr_beat;   // zero-extended
`ifndef ORAM_OVERLAP4
    reg  [`SCR_AW-1:0] scr_ev_wr_addr; reg [AXI_DW-1:0] scr_ev_wr_data; reg scr_ev_wr_en;
`endif
    // Board calibration: in debug builds these are tagged for ILA insertion
    // (Set Up Debug picks up mark_debug nets); they hold the worst arrival seen.
`ifdef ORAM_DEBUG_PORTS
    (* mark_debug = "true" *) reg [31:0] ct_max_rd, ct_max_wb, ct_max_done;
`else
    reg  [31:0]       ct_max_rd, ct_max_wb, ct_max_done;
`endif
    reg               err_ct_overrun_r, fmt_done_r;
    reg               halt_info_v, pm_err_seen, br_err_seen, st_err_seen;   // the halt record (dbg_halt_info)
`ifndef ORAM_BOOT_SETTLE
`define ORAM_BOOT_SETTLE 262144
`endif
    localparam [19:0] BOOT_SETTLE = `ORAM_BOOT_SETTLE;   // cycles after the boot writes are acknowledged (~0.9 ms at 300 MHz)
    reg  [19:0]       boot_settle;
    reg  [63:0]       halt_info_r;
    reg               boot_drain;   // layout written; waiting for every boot write to be acknowledged
    // Fixed-time boot (v11b): the placement is padded to a budget, as an access is. Placing a slot in its bucket
    // costs one record read and write; placing it in the stash (its bucket is full) costs a list open, a pool
    // block and a commit as well. Unpadded, the boot would last a + b * O_0 cycles, and O_0 (the blocks placed
    // in the stash, a function of the initial positions) would show in the init launch's duration. So the
    // layout and all its writes must be done exactly LAY_BUDGET = n * LAY_TB + (n >> LAY_OSH) * LAY_TS +
    // LAY_BASE cycles after the layout starts; the controller becomes ready then (plus BOOT_SETTLE), whatever
    // the placement, or halts with a timing overrun. LAY_TB and LAY_TS bound one slot's placement in its
    // bucket and in the stash; n >> LAY_OSH (n / 4) bounds O_0 (expected 5.2% of n at lambda 6, 9.2% at 7).
    // The budget depends on n only, never on a host-chosen quantity (the pool size is the host's).
    // (ORAM_LAY_TB, ORAM_LAY_TS0, ORAM_LAY_BASE: rtl/oram_params.vh)
    localparam integer LAY_TB   = `ORAM_LAY_TB;                 // cycles: one slot placed in its bucket (worst)
    localparam integer LAY_TS   = `ORAM_LAY_TS0 + (Z + 3) * BEATS;   //    one slot placed in the stash (worst): the open
                                                                // reads the target's window blocks (W = Z + 1), the
                                                                // new block goes in, the commit writes it back
    localparam integer LAY_BASE = `ORAM_LAY_BASE;               //         the last writes landing
    localparam integer LAY_OSH  = 2;                            // O_0 <= n / 4
    reg  [39:0]       lay_cyc;      // cycles since the layout started
    reg  [39:0]       lay_bud_b, lay_bud_s, lay_budget;
    reg               lay_run;      // the boot budget is running (layout started, not yet ready)
    reg               lay_due;      // the budget has elapsed (and everything was done)
    wire              boot_quiet = axim_wr_quiet && pm_wr_quiet && br_wr_quiet && st_init_done && st_wr_quiet;
    // measurement only (calibrates LAY_TB, LAY_TS; never visible to the host): worst cycles of one slot's
    // placement in its bucket and in the stash, the blocks placed in the stash, the cycle the layout was done
    reg  [39:0]       lay_t0, lay_end;
    reg  [15:0]       lay_max_b, lay_max_s;
    reg               lay_st;
    reg  [SLOT_W:0]   lay_nst;
    // the budget, from the run-time n (stable long before the layout starts: the format comes first)
    always @(posedge clk) begin
        lay_bud_b  <= n_q * LAY_TB;
        lay_bud_s  <= (n_q >> LAY_OSH) * LAY_TS;
        lay_budget <= lay_bud_b + lay_bud_s + LAY_BASE;
    end
    reg  [BUCKET_W:0] fmt_b;
    reg  [SLOT_W:0]   lay_i;
    // One ORAM per client: partition p owns slots p*N_PART.. and buckets p*B_PART..
    localparam PART_W = `ORAM_PART_W;
    localparam NP     = 1 << PART_W;
    localparam N_PART = N >> PART_W;
    localparam B_PART = B >> PART_W;
    localparam BL_W   = BUCKET_W - PART_W;          // bucket index within a partition
    localparam PW     = (PART_W > 0) ? PART_W : 1;   // register width; a constant 0 when unpartitioned
    localparam [BUCKET_W-1:0] BL_MASK = {BUCKET_W{1'b1}} >> PART_W;
    reg  [PW-1:0]     req_part;                     // partition of the current access
    reg  [PW-1:0]     lay_p;                        // partition being laid out at boot
    reg  [BUCKET_W-1:0] lay_b;                      // layout: the bucket drawn for slot lay_i
    reg  [2:0]        lay_ph;                       //         phase of the slot's placement (S_LAYOUT)
    reg  [BEAT_W:0]   lay_beat;                     //         zero beats written into its stash entry
    reg  [PTR_W-1:0]  lay_ent;                      //         its stash staging entry
    localparam BEAT_AW = $clog2(BEATS);             // beat index bits within a block
    wire [PW-1:0]     in_part = (PART_W > 0) ? client_slot_addr[SLOT_W+11 -: PW] : {PW{1'b0}};
    // first bucket / first slot of a partition (0 when there is a single ORAM)
    wire [BUCKET_W-1:0] req_part_w = req_part, in_part_w = in_part, lay_p_w = lay_p;
    wire [SLOT_W-1:0]   lay_p_s    = lay_p;
    wire [BUCKET_W-1:0] req_bbase  = (PART_W > 0) ? (req_part_w << BL_W) : {BUCKET_W{1'b0}};
    wire [BUCKET_W-1:0] in_bbase   = (PART_W > 0) ? (in_part_w  << BL_W) : {BUCKET_W{1'b0}};
    wire [BUCKET_W-1:0] lay_bbase  = (PART_W > 0) ? (lay_p_w    << BL_W) : {BUCKET_W{1'b0}};
    wire [SLOT_W-1:0]   lay_sbase  = (PART_W > 0) ? (lay_p_s << (SLOT_W - PART_W)) : {SLOT_W{1'b0}};
    wire [BUCKET_W-1:0] b_new_sel  = (|dbg_prng_override) ? dbg_prng_override : rnd_bucket_q;
    wire [BUCKET_W-1:0] b_new_part = req_bbase | (b_new_sel & BL_MASK);
    // Boot layout (v11b): random direct placement. Every slot is placed at an independent, uniform bucket of
    // its partition, drawn from the same generator as the remap targets (rng_bucket.v, a statistical stand-in
    // for the assumed secure random source). A slot whose bucket is full (Z) waits in the stash for it, as a
    // remapped block would. The initial state is then exactly the stash analysis's: per-bucket counts
    // Binomial(n, 1/B), nothing waiting for a bucket that could take it, the excess over Z in the stash (O_0).
    // It replaces the keyed permutation (C slots per bucket) and the kernel's boot touch pass.
    wire [SLOT_W-PART_W:0] n_part = n_q >> PART_W;          // run-time slots per partition
    wire [SLOT_W-1:0] lay_slot = lay_sbase | lay_i[SLOT_W-1:0];   // the slot being placed
    wire [SLOT_AW-1:0] lay_slot_addr = {{(SLOT_AW-SLOT_W-12){1'b0}}, lay_slot, 12'd0};
    // the new target of the next access, taken from the generator when the access starts
    reg  [BUCKET_W-1:0] rnd_bucket_q;
    reg  [1:0]        cr_mode;
    reg  [POS_W:0]    cr_pos;
    reg               cr_zero;
    reg               tag_seen, tag_match_q;
    reg  [127:0]      tag_q;
    reg  [95:0]       iv_q;
    reg  [1:0]        cp_src;
    reg               cp_to_stash, cp_to_scr, cp_to_res;
    reg  [POS_W-1:0]  cp_src_pos, cp_dst_pos;
    reg  [PTR_W-1:0]  cp_src_ent, cp_dst_ent;
    reg  [BEAT_W:0]   cp_rd_beat, cp_wr_beat;
    reg  [4:0]        cp_ret;
    reg  [PTR_W-1:0]  tgt_ent, ev_ent;
    reg  [POS_W:0]    fill;
    reg               res_zero;
    reg  [BEAT_W:0]   res_beat, res_out_beat;
    reg  [1:0]        res_pipe;
    // result buffer (BRAM): written by the copy engine, read at release time
    reg  [AXI_DW-1:0] res_buf [0:BEATS-1];
    reg               res_wr_en;
    reg  [6:0]        res_wr_addr, res_rd_addr;
    reg  [AXI_DW-1:0] res_wr_data, res_rd_data;
    // The AES core derives its round keys one key-schedule round per clock (11 cycles). The key
    // is loaded once per boot; the boot layout starts only once it has been stable for 16 cycles.
    reg [127:0] key_seen;
    reg [4:0]   key_age;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin key_seen <= 128'd0; key_age <= 5'd0; end
        else if (aes_key != key_seen) begin key_seen <= aes_key; key_age <= 5'd0; end
        else if (key_age != 5'd31) key_age <= key_age + 5'd1;
    end
    wire key_settled = (key_age >= 5'd16);

`ifdef ORAM_OVERLAP2
`ifdef ORAM_OVERLAP4
    // four result buffers (today's template, four times): M writes its access's, T reads its access's
    wire [AXI_DW-1:0] res_rdk [0:NC-1];
    genvar gr;
    generate for (gr = 0; gr < NC; gr = gr + 1) begin : g_res
        reg [AXI_DW-1:0] rb [0:BEATS-1];
        reg [AXI_DW-1:0] rq;
        always @(posedge clk) begin
            if (res_wr_en && mp == gr) rb[res_wr_addr] <= res_wr_data;
            rq <= rb[res_rd_addr];
        end
        assign res_rdk[gr] = rq;
    end endgenerate
    always @(*) res_rd_data = res_rdk[rs_par];
    // the oq of the encryption stage (LUT-RAM, written by core E only)
    (* ram_style = "distributed" *) reg [AXI_DW-1:0] e_oq_d [0:OQ_D-1];
    reg  [OQ_AW-1:0] e_oq_wp, e_oq_rp; reg [OQ_AW:0] e_oq_n;
    always @(posedge clk) if (e_gcm_data_out_valid) e_oq_d[e_oq_wp] <= e_gcm_data_out;
    wire [AXI_DW-1:0] e_oq_hd = e_oq_d[e_oq_rp];
    // F's new target bucket for the access being accepted (its own draw, its partition)
    reg  [PW-1:0]       f_part [0:NC-1];
    reg  [PW-1:0]       f_part_in;
    wire [BUCKET_W-1:0] f_part_w   = fl_part;
    wire [BUCKET_W-1:0] f_bbase    = (PART_W > 0) ? (f_part_w << BL_W) : {BUCKET_W{1'b0}};
    wire [BUCKET_W-1:0] f_bnew_sel = (|dbg_prng_override) ? dbg_prng_override : fl_rnd;
    wire [BUCKET_W-1:0] f_bnew_part = f_bbase | (f_bnew_sel & BL_MASK);
    // read-address forwarding (D2): the newest of the three earlier accesses that requested the same key and has not
    // yet passed its decisions (f_fwd) goes to that access's new bucket. A select, no wait.
    // decided when the lookup read is issued (accept): an access that has passed its decisions issued its position-map
    // writes before, and the lookup read is ordered after them (pos_map_hbm)
    wire [1:0]  an = f_par + 2'd1, ap1 = an - 2'd1, ap2 = an - 2'd2, ap3 = an - 2'd3;
    wire [1:0]  fp_m1 = f_par - 2'd1, fp_m2 = f_par - 2'd2, fp_m3 = f_par - 2'd3;   // the three earlier contexts
    wire        aw1 = f_fwd[ap1] && f_slot[ap1] == client_slot_addr;
    wire        aw2 = f_fwd[ap2] && f_slot[ap2] == client_slot_addr;
    wire        aw3 = f_fwd[ap3] && f_slot[ap3] == client_slot_addr;
    wire        a_fwv = aw1 || aw2 || aw3;
    wire [BUCKET_W-1:0] a_fwb = aw1 ? f_bnew[ap1] : aw2 ? f_bnew[ap2] : f_bnew[ap3];
    reg         f_fwv [0:NC-1]; reg [BUCKET_W-1:0] f_fwb [0:NC-1];
    reg         f_pmc [0:NC-1];               // a position-map write corrected the record after its lookup read
    reg  [1:0]  s_prev;                       // earlier accesses so far (0..3): the same-bucket comparison's reach
    // F's access (one at a time), copies of its front record: the same values, written in the same cycles
    reg                 fl_fwv, fl_eqa, fl_g0, fl_g1, fl_g2;   // fl_g*: fl_ct >= CT_RD, >= CT_RD + OV_DEQ, fl_ct + 1 > CT_RD
    reg  [BUCKET_W-1:0] fl_fwb, fl_rnd, fl_b, fl_b1, fl_b2, fl_b3; // fl_b1..3: the buckets of the three earlier accesses
    reg  [PW-1:0]       fl_part;
    reg  [SLOT_AW-1:0]  fl_slot;
    reg  [31:0]         fl_ct;                                 // = f_ct[f_par] while F is busy
    wire [BUCKET_W-1:0] f_lk_b = fl_fwv ? fl_fwb : pm_rd_bucket;
`else
    // two result buffers (today's template, twice): M writes its access's, T reads its access's
    reg  [AXI_DW-1:0] res_buf1 [0:BEATS-1];
    reg  [AXI_DW-1:0] res_rd0, res_rd1;
    always @(posedge clk) begin
        if (res_wr_en && !mp) res_buf[res_wr_addr] <= res_wr_data;
        res_rd0 <= res_buf[res_rd_addr];
    end
    always @(posedge clk) begin
        if (res_wr_en && mp) res_buf1[res_wr_addr] <= res_wr_data;
        res_rd1 <= res_buf1[res_rd_addr];
    end
    always @(*) res_rd_data = rs_par ? res_rd1 : res_rd0;
    // F's new target bucket (as b_new_part, from F's own draw and partition)
    reg  [PW-1:0]       f_part;
    wire [BUCKET_W-1:0] f_part_w   = f_part;
    wire [BUCKET_W-1:0] f_bbase    = (PART_W > 0) ? (f_part_w << BL_W) : {BUCKET_W{1'b0}};
    wire [BUCKET_W-1:0] f_bnew_sel = (|dbg_prng_override) ? dbg_prng_override : f_rnd;
    wire [BUCKET_W-1:0] f_bnew_part = f_bbase | (f_bnew_sel & BL_MASK);
`endif
    wire                ov_err     = err_tag_mismatch || err_stash_overflow || err_ct_overrun_r;
`else
    always @(posedge clk) begin
        if (res_wr_en) res_buf[res_wr_addr] <= res_wr_data;
        res_rd_data <= res_buf[res_rd_addr];
    end
`endif
    assign err_ct_overrun = err_ct_overrun_r;
    assign fmt_done       = fmt_done_r;
    // the halt record: latched fields, plus (when the on-package release check raised the halt) which deadline was
    // missed and by how many cycles, which keeps counting until the late event happens (bit 16 while it has not)
    wire [1:0]  ov_code = ov_d2 ? 2'b10 : ov_bc ? 2'b11 : ov_d1 ? 2'b01 : 2'b00;
    wire [15:0] ov_by   = ov_d2 ? ov_by2 : ov_d1 ? ov_by1 : 16'd0;
    wire        ov_lb   = ov_d2 ? ov_run2 : ov_d1 ? ov_run1 : 1'b0;
    assign dbg_halt_info  = {halt_info_r[63:34], halt_rel ? ov_code : 2'b00,
                             halt_rel ? ((ov_by > 16'd4095) ? 12'hFFF : ov_by[11:0]) : 12'd0,
                             halt_info_r[19:17], halt_rel && ov_lb, halt_info_r[15:0]};
    function [SLOT_W-1:0] slot_id_at;
        input [Z*SLOT_W-1:0] list; input [POS_W-1:0] pos;
        begin slot_id_at = list[pos*SLOT_W +: SLOT_W]; end
    endfunction
    function [SLOT_AW-1:0] ivt_addr;          // IV/tag table keyed by (bucket, position)
        input [BUCKET_W-1:0] b; input [POS_W-1:0] p;
        begin ivt_addr = {{(SLOT_AW-BUCKET_W-POS_W-12){1'b0}}, b, p, 12'd0}; end
    endfunction
    wire              cp_data_ok = (cp_src == CPS_SCR)   ? scr_fsm_rd_valid :
                                   (cp_src == CPS_STASH) ? st_drd_valid : client_wdata_valid;
    // A PUT merges: bytes whose strobe is set come from the client, the rest from the block's
    // old contents (the scratch or stash copy being read, or zeros for a never-written slot).
    // A full strobe gives exactly the client's data. Other copies (GET results, compaction)
    // pass their source through unchanged.
    reg               cp_merge;
    wire [AXI_DW-1:0] cp_old     = (cp_src == CPS_SCR)   ? scr_fsm_rd_data :
                                   (cp_src == CPS_STASH) ? st_drd_data : {AXI_DW{1'b0}};
    wire [AXI_DW-1:0] cp_mask;
    genvar gm;
    generate for (gm = 0; gm < AXI_DW/8; gm = gm + 1) begin : g_cp_mask
        assign cp_mask[8*gm +: 8] = {8{client_wstrb[gm]}};
    end endgenerate
    wire [AXI_DW-1:0] cp_data    = cp_merge ? ((cp_old & ~cp_mask) | (client_wdata & cp_mask)) :
                                   (cp_src == CPS_SCR)   ? scr_fsm_rd_data :
                                   (cp_src == CPS_STASH) ? st_drd_data : client_wdata;
    // ---- write-back queue of the crypto engine and the decryption's read gate (see OQ_D) ----
    // The core returns beats in message order, so the queue holds data only: the head's scratch address is wr_lin.
    wire              oq_push = gcm_data_out_valid;          // the core returns beats only inside a message
    always @(posedge clk) if (oq_push) oq_d[oq_wp] <= gcm_data_out;   // reset-free (LUT-RAM)
    wire [AXI_DW-1:0] oq_hd   = oq_d[oq_rp];
    wire              oq_pop  = (oq_n != 0) && (cr_mode != CR_DA || landed_beats >= wr_end);
    // decryption: read beat rd_lin once it has landed. Every mode: at most OQ_D beats read and not yet written back,
    // so the queue can never overflow (only decryption ever comes near it, and only while a position is landing)
    wire              rd_room   = (rd_lin < wr_lim);
    wire              rd_landed = (landed_beats > rd_lin);
    wire [10:0]        wr_pos  = wr_lin >> BEAT_AW;          // positions of this message fully written back
    // v14: this access's bucket is on package and kept in plaintext (never true in a format: cr_mode == CR_FMT)
`ifdef ORAM_NOCRYPTO
    wire              byp_acc = BYP && cr_mode != CR_FMT;     // every access
`else
    wire              byp_acc = BYP && acc_hbm && cr_mode != CR_FMT;
`endif
`ifdef ORAM_OVERLAP4
    wire [15:0]       e_evp = (c_own == ej) ? ev_pending : 16'd0;
    wire              copies_done = (evq_rp == evq_wp) && !ec_active;
    wire              st_open_ok = st_wr_quiet && copies_done && (cm_age == 2'd3) && !st_commit;
`endif
    // v14, on package: the two deadlines' checks (ev_d1: the write-back has not started at t_arr + AR_WB_H; ev_rt: the
    // release time t_arr + AR_REL_H; ev_d2: the write is not handed off then)
`ifdef ORAM_OVERLAP2
    // M: the decisions are not done by t_arr + AR_WB_H (deadline 1), or still not by the release time (deadline 2);
    // T: the write is not handed off by the release time (deadline 2), reported then
    wire              ev_d1   = byp_acc && m_has && m_pre_ea && arr_seen && ct_cnt == t_arr + AR_WB_H && state != S_EA_START;
    wire              ev_rt_m = byp_acc && m_has && m_pre_ea && arr_seen && ct_cnt == t_arr + AR_REL_H;
`ifdef ORAM_OVERLAP4
    wire [NC-1:0]     ev_rtv, ev_d2v, t_gatev;
    wire [NC-1:0]     t_wbok, t_gok, t_glate;   // write-back budget reached; release gate reached; and passed
    genvar ge;
    generate for (ge = 0; ge < NC; ge = ge + 1) begin : g_ev
        assign ev_rtv[ge]  = BYP && t_hbm[ge] && t_busy[ge] && t_av[ge] && t_rel[ge][31:0] == AR_REL_H;
        assign t_wbok[ge]  = t_av[ge] && !t_rel[ge][32] && t_rel[ge][31:0] >= (t_hbm[ge] ? AR_WB_H : AR_WB);
        assign t_gok[ge]   = !t_rel[ge][32] && t_rel[ge][31:0] >= (t_hbm[ge] ? AR_REL_H : AR_REL);
        assign t_glate[ge] = !t_rel[ge][32] && t_rel[ge][31:0] >  (t_hbm[ge] ? AR_REL_H : AR_REL);
        assign ev_d2v[ge]  = ev_rtv[ge] && tst[ge] != T_GATE;
        assign t_gatev[ge] = (tst[ge] == T_GATE);
    end endgenerate
    reg  [NC-1:0]     t_bypv;
    always @(*) begin : t_byp_vec integer q; for (q = 0; q < NC; q = q + 1) t_bypv[q] = t_byp_ov[q]; end
`ifdef ORAM_OV4_P3
    wire [NC-1:0]     t_wsok;                   // phase 3: the write slot, t' + AR_WB, on or off package
    genvar gw;
    generate for (gw = 0; gw < NC; gw = gw + 1) begin : g_ws
        assign t_wsok[gw] = t_av[gw] && !t_rel[gw][32] && t_rel[gw][31:0] >= AR_WB;
    end endgenerate
`endif
`else
    wire              ev_rt0  = BYP && t_hbm[0] && t_busy0 && t_av[0] && t_rel[0][31:0] == AR_REL_H;
    wire              ev_rt1  = BYP && t_hbm[1] && t_busy1 && t_av[1] && t_rel[1][31:0] == AR_REL_H;
    wire [1:0]        t_wbok, t_gok, t_glate;   // write-back budget reached; release gate reached; and passed
    genvar ge;
    generate for (ge = 0; ge < 2; ge = ge + 1) begin : g_ev
        assign t_wbok[ge]  = t_av[ge] && !t_rel[ge][32] && t_rel[ge][31:0] >= (t_hbm[ge] ? AR_WB_H : AR_WB);
        assign t_gok[ge]   = !t_rel[ge][32] && t_rel[ge][31:0] >= (t_hbm[ge] ? AR_REL_H : AR_REL);
        assign t_glate[ge] = !t_rel[ge][32] && t_rel[ge][31:0] >  (t_hbm[ge] ? AR_REL_H : AR_REL);
    end endgenerate
    wire              ev_d20  = ev_rt0 && tst[0] != T_GATE, ev_d21 = ev_rt1 && tst[1] != T_GATE;
`endif
`else
`ifdef ORAM_NOCRYPTO
    wire              ev_d1 = byp_acc && arr_seen && ct_cnt == t_arr + nc_wbf && wb_pending &&
                              state != S_EA_START && state != S_DDR_WRITE;
`elsif ORAM_ONPKG_FIXWB
    // Option A: (1) the write-back is due at t_arr + AR_WBF_H: every decision must be made by then (S_EA_START reached)
    wire              ev_d1 = byp_acc && arr_seen && ct_cnt == t_arr + AR_WBF_H && wb_pending &&
                              state != S_EA_START && state != S_DDR_WRITE;
`else
    wire              ev_d1 = byp_acc && arr_seen && ct_cnt == t_arr + AR_WB_H && wb_pending && state != S_EA_START;
`endif
`ifdef ORAM_NOCRYPTO
    wire              ev_rt = byp_acc && arr_seen && ct_cnt == t_arr + nc_rel;
`else
    wire              ev_rt = byp_acc && arr_seen && ct_cnt == t_arr + AR_REL_H;
`endif
    wire              ev_d2 = ev_rt && state != S_DONE_GATE;
`endif
    // v14: the leading positions whose eviction copies have landed (0..Z): what an on-package write-back may send
    reg  [3:0]        byp_lead;
    always @(*) begin : byp_lead_enc
        integer bi;
        byp_lead = Z[3:0];
        for (bi = Z - 1; bi >= 0; bi = bi - 1) if (ev_pending[bi]) byp_lead = bi[3:0];
    end
    reg  [31:0] acc_ddr_rd, acc_decrypt, acc_encrypt, acc_compact, acc_evict, acc_ddr_wr,
                acc_scan, acc_stash, acc_total;
    reg         acc_commit;
    always @(posedge clk) begin
        if (!rst_n) begin
            state <= S_IDLE;
            client_done <= 0; client_stall <= 1; client_rdata_valid <= 0;
            client_rdata <= 0; client_rdata_beat <= 0;
            err_bucket_overflow <= 0; err_stash_overflow <= 0; err_tag_mismatch <= 0;
            err_ct_overrun_r <= 0; fmt_done_r <= 0; boot_drain <= 0; fmt_b <= 0;
            halt_info_v <= 0; halt_info_r <= 64'd0; pm_err_seen <= 0; br_err_seen <= 0; st_err_seen <= 0; boot_settle <= 0;
            pm_rd_en <= 0; pm_wr_en <= 0; bm_rd_en <= 0; bm_wr_en <= 0; rng_take <= 0;
            ivt_rd_en <= 0; ivt_wr_en <= 0; axim_cmd_read <= 0; axim_cmd_write <= 0;
            gcm_start <= 0; gcm_data_valid <= 0; gcm_data_last <= 0; gcm_encrypt <= 0; gcm_iv_reg <= 0; gcm_iv_adv <= 0;
            fmt_zero <= 0; bm_seen <= 0; byp_ov <= 0; ar_max_rel_h <= 0;
            ov_d1 <= 0; ov_d2 <= 0; ov_bc <= 0; ov_rel <= 0; ov_run1 <= 0; ov_run2 <= 0; halt_rel <= 0; ov_by1 <= 0; ov_by2 <= 0;
            scr_fsm_rd_en <= 0; scr_fsm_wr_en <= 0; scr_ev_wr_en <= 0;
            st_open_instash <= 1'b0; st_open_pidx <= 0; pm_wr_pidx <= 0; req_pidx_cur <= 0;
            st_ins_en <= 0; st_remap_en <= 0; st_evict_en <= 0; st_dwr_en <= 0; st_drd_en <= 0; st_open_en <= 0; st_commit <= 0; st_init_go <= 0;
            st_cam_bkt_en <= 0; st_cam_bkt_target <= 0;
            res_wr_en <= 0; res_rd_addr <= 0; res_pipe <= 0;
            ct_cnt <= 0; ct_max_rd <= 0; ct_max_wb <= 0; ct_max_done <= 0; t_arr <= 0; arr_seen <= 1'b0; ar_max_wb <= 0; ar_max_wb_h <= 0; acc_hbm <= 1'b0;
            landed_beats <= 0; enc_pos_done <= 0; wb_pending <= 0; wb_active <= 0; wb_done_seen <= 0;
            evq_wp <= 0; evq_rp <= 0; ev_pending <= 0; ec_active <= 0; ec_rd_beat <= 0; ec_wr_beat <= 0;
            tag_seen <= 0; beat_cnt <= 0; acc_commit <= 0; st_open_req <= 0;
`ifdef ORAM_OVERLAP4
            ga_wait <= 0;
`endif
            fd_v <= 2'b00; fd_last <= 2'b00; fd_zero <= 2'b00; rd_lin <= 0; rd_base <= 0; wr_lin <= 0; wr_end <= 0; wr_lim <= 0;
            oq_wp <= 0; oq_rp <= 0; oq_n <= 0;
            cp_merge <= 0; rnd_bucket_q <= 0; lay_i <= 0; lay_b <= 0; lay_ph <= 0; lay_beat <= 0; lay_ent <= 0; req_part <= 0; lay_p <= 0;
            lay_cyc <= 0; lay_run <= 0; lay_due <= 0; lay_t0 <= 0; lay_end <= 0; lay_max_b <= 0; lay_max_s <= 0; lay_st <= 0; lay_nst <= 0;
`ifdef ORAM_OVERLAP2
`ifdef ORAM_OVERLAP4
            begin : ov4_rst
                integer q;
                for (q = 0; q < NC; q = q + 1) begin
                    tst[q] <= T_IDLE; f_has[q] <= 0; f_looked[q] <= 0; f_hbm[q] <= 0; f_same[q] <= 0; f_instash[q] <= 0;
                    f_eqa[q] <= 0; f_arr[q] <= 0; f_bmseen[q] <= 0; f_rdiss[q] <= 0; f_op[q] <= 0; f_fwd[q] <= 0;
                    f_ct[q] <= 0; f_tarr[q] <= 0; f_landed[q] <= 0; f_slot[q] <= 0; f_rnd[q] <= 0; f_b[q] <= 0; f_bnew[q] <= 0;
                    f_pidx[q] <= 0; f_bml[q] <= 0; f_bmf[q] <= 0; f_part[q] <= 0; wdone[q] <= 1'b1; epd[q] <= 0;
                    c_own <= 0; c_own_hbm <= 0; cm_age <= 2'd3;
                    f_fwv[q] <= 0; f_fwb[q] <= 0; f_pmc[q] <= 0;
                    t_ct[q] <= 0; t_tarr[q] <= 0; t_rel[q] <= 0; t_hbm[q] <= 0; t_op[q] <= 0; t_rz[q] <= 0; t_av[q] <= 0; t_byp_ov[q] <= 0;
`ifdef ORAM_OV4_P3
                    cfc[q] <= 0; eqc[q] <= 0; cf_wait[q] <= 0; ea_arr[q] <= 0; f_eqok[q] <= 0;
`endif
                    t_b[q] <= 0; t_wbp[q] <= 0; t_wbd[q] <= 0; eq_ctx[q] <= 0; eq_hbm[q] <= 0; eq_b[q] <= 0;
                end
            end
            client_acc <= 0; fst <= F_IDLE; f_par <= 2'd3; f_eqm <= 0;
            fl_fwv <= 0; fl_eqa <= 0; fl_fwb <= 0; fl_rnd <= 0; fl_b <= 0; fl_b1 <= 0; fl_b2 <= 0; fl_b3 <= 0; fl_part <= 0; fl_slot <= 0;
            fl_ct <= 0; fl_g0 <= (32'd0 >= OV_CT_RD); fl_g1 <= (32'd0 >= OV_CT_RD + OV_DEQ); fl_g2 <= (32'd1 > OV_CT_RD); s_prev <= 0; m_take <= 0; b_ctx <= 0;
            rp <= 0; ri_next <= 0; axir_cmd_ctx <= 0; f_g0 <= 0; f_g1 <= 0; fr_pend <= 0; rr_pend <= 0; rec_out <= 0;
            fr_b <= 0; rr_b <= 0; fr_ctx <= 0; rr_ctx <= 0;
            begin : rd2_rst integer q; for (q = 0; q < NC; q = q + 1) f_eqmk[q] <= 0; end
            s_since <= 0; s_need <= 0; s_any <= 0; mp <= 0; tp <= 0; m_has <= 0; m_pre_ea <= 0; m_is_t <= 0;
            w_par <= 0; w_next <= 0; rs_par <= 0; r_next <= 0; axir_cmd_read <= 0; axir_cmd_bucket <= 0;
            est <= E_IDLE; e_act <= 0; e_wait <= 0; ej <= 0; eq_wp <= 0; eq_rp <= 0; eq_n <= 0; e_b <= 0;
            e_rd_en <= 0; e_wr_en <= 0; e_fd_v <= 0; e_fd_last <= 0; e_rd_lin <= 0; e_rd_base <= 0; e_wr_lin <= 0; e_wr_lim <= 0;
            e_cr_pos <= 0; e_beat <= 0; e_tag_seen <= 0; e_gcm_start <= 0; e_gcm_iv_adv <= 0; e_gcm_data_valid <= 0;
            e_gcm_data_last <= 0; e_gcm_iv_reg <= 0; e_oq_wp <= 0; e_oq_rp <= 0; e_oq_n <= 0; f_part_in <= 0;
`else
            client_acc <= 0; fst <= F_IDLE; tst[0] <= T_IDLE; tst[1] <= T_IDLE; f_has <= 0; f_looked <= 0; f_par <= 1'b1; f_eq <= 0; f_eqm1 <= 0; f_eqm2 <= 0;
            f_arr <= 0; rd_own_m <= 0; r_par <= 0; f_ct <= 0; f_tarr <= 0; f_landed <= 0; f_op <= 0; f_slot <= 0; f_part <= 0;
            f_rnd <= 0; f_b <= 0; f_bnew <= 0; f_hbm <= 0; f_same <= 0; f_instash <= 0; f_pidx <= 0;
            s_since <= 0; s_need <= 0; s_any <= 0; mp <= 0; tp <= 0; m_has <= 0; m_pre_ea <= 0; m_is_t <= 0;
            t_ct[0] <= 0; t_tarr[0] <= 0; t_rel[0] <= 0; t_hbm[0] <= 0; t_op[0] <= 0; t_rz[0] <= 0; t_av[0] <= 0; t_byp_ov[0] <= 0; t_b[0] <= 0;
            t_ct[1] <= 0; t_tarr[1] <= 0; t_rel[1] <= 0; t_hbm[1] <= 0; t_op[1] <= 0; t_rz[1] <= 0; t_av[1] <= 0; t_byp_ov[1] <= 0; t_b[1] <= 0;
            t_wbp[0] <= 0; t_wbp[1] <= 0; t_wbd[0] <= 0; t_wbd[1] <= 0; w_par <= 0; w_next <= 0; rs_par <= 0; r_next <= 0; lw_u <= 0;
            lw_b <= 0; lw_b2 <= 0; lw_p <= 0; lw_p2 <= 0; lw_v <= 0; lw_v2 <= 0; axir_cmd_read <= 0; axir_cmd_bucket <= 0;
`endif
`endif
        end else begin
            client_done <= 0; client_rdata_valid <= 0;
            pm_rd_en <= 0; pm_wr_en <= 0; bm_rd_en <= 0; bm_wr_en <= 0; rng_take <= 0;
            ivt_rd_en <= 0; ivt_wr_en <= 0; axim_cmd_read <= 0; axim_cmd_write <= 0;
            gcm_start <= 0; gcm_data_valid <= 0; gcm_data_last <= 0; gcm_iv_adv <= 0;
            scr_fsm_rd_en <= 0; scr_fsm_wr_en <= 0; scr_ev_wr_en <= 0;
            st_ins_en <= 0; st_remap_en <= 0; st_evict_en <= 0; st_dwr_en <= 0; st_drd_en <= 0; st_open_en <= 0; st_commit <= 0; st_init_go <= 0;
            res_wr_en <= 0; acc_commit <= 0;
            if (state != S_IDLE && fmt_done_r) ct_cnt <= ct_cnt + 32'd1;
`ifdef ORAM_OVERLAP2
`ifdef ORAM_OVERLAP4
            client_acc <= 0; axir_cmd_read <= 0;
            e_gcm_start <= 0; e_gcm_iv_adv <= 0; e_gcm_data_valid <= 0; e_gcm_data_last <= 0; e_rd_en <= 0; e_wr_en <= 0;
            begin : ov4_cnt
                integer q;
                for (q = 0; q < NC; q = q + 1) begin
                    // from the accept until M takes it and F has issued its read (M's ct_cnt counts the same)
                    if (f_has[q] || (fst != F_IDLE && f_par == q) || rp[q]) begin
                        f_ct[q] <= f_ct[q] + 32'd1;
                        f_g0[q] <= (f_ct[q] + 32'd1 >= OV_CT_RD); f_g1[q] <= (f_ct[q] + 32'd1 >= OV_CT_RD + OV_DEQ);
                    end
                    if (t_busy[q]) begin t_ct[q] <= t_ct[q] + 32'd1; t_rel[q] <= t_rel[q] + 33'd1; end
                    // a write is acknowledged once its data was handed off and no response is outstanding (one write
                    // in flight at a time)
                    if (t_wbd[q] && axim_wr_quiet && !wb_active && !axim_cmd_write) wdone[q] <= 1'b1;
                end
            end
            if (axim_write_done) t_wbd[w_par] <= 1'b1;
            if (s_since != 16'hFFFF) s_since <= s_since + 16'd1;
            if (fst != F_IDLE) begin   // f_ct[f_par] counts every cycle F is busy
                fl_ct <= fl_ct + 32'd1;
                fl_g0 <= (fl_ct + 32'd1 >= OV_CT_RD); fl_g1 <= (fl_ct + 32'd1 >= OV_CT_RD + OV_DEQ); fl_g2 <= (fl_ct + 32'd1 + 32'd1 > OV_CT_RD);
            end
            // position-map and record writes after a front record's lookup correct it (M takes it with them)
            begin : ov4_corr
                integer q;
                for (q = 0; q < NC; q = q + 1) begin
                    if (pm_wr_en && f_has[q] && pm_wr_addr == f_slot[q]) begin
                        f_instash[q] <= (pm_wr_status == `ST_IN_STASH); f_pidx[q] <= pm_wr_pidx; f_pmc[q] <= 1'b1;
                    end
                    if (bm_wr_en && f_has[q] && f_looked[q] && bm_wr_bucket == f_b[q]) begin
                        f_bml[q] <= bm_wr_slot_list; f_bmf[q] <= bm_wr_fill; f_bmseen[q] <= 1'b1;
                    end
                end
            end
`else
            client_acc <= 0; axir_cmd_read <= 0;
            if (fst != F_IDLE || f_has) f_ct <= f_ct + 32'd1;
            if (t_busy0) begin t_ct[0] <= t_ct[0] + 32'd1; t_rel[0] <= t_rel[0] + 33'd1; end
            if (t_busy1) begin t_ct[1] <= t_ct[1] + 32'd1; t_rel[1] <= t_rel[1] + 33'd1; end
            if (axim_write_done) t_wbd[w_par] <= 1'b1;
            if (s_since != 16'hFFFF) s_since <= s_since + 16'd1;
            // the last two write-backs: acknowledged once every write is (the newest only after its data was handed off)
            if (axim_wr_quiet) begin lw_p2 <= 1'b0; if (t_wbd[lw_u]) lw_p <= 1'b0; end
`endif
`endif
            if (lay_run) lay_cyc <= lay_cyc + 40'd1;
            if (pm_err || br_err || st_err) err_ct_overrun_r <= 1'b1;   // metadata or stash error: stop (fail-stop)
            if (pm_err) pm_err_seen <= 1'b1;
            if (br_err) br_err_seen <= 1'b1;
            if (st_err) st_err_seen <= 1'b1;
            if (!halt_info_v && (err_tag_mismatch || err_stash_overflow || err_ct_overrun_r)) begin   // the halt record
                halt_info_v <= 1'b1; halt_rel <= ov_rel;
                halt_info_r <= {req_b24, state, acc_hbm, 2'b00, 12'd0, pm_err_seen, br_err_seen, st_err_seen, 1'b0,
                                ((ct_cnt > 32'hFFFF) ? 16'hFFFF : ct_cnt[15:0])};
            end
            // ---- crypto streaming (independent of the FSM state) ----
`ifdef ORAM_OVERLAP2
`ifdef ORAM_OVERLAP4
            // a beat of the read in flight belongs to its context (r_par): M's counters if M has taken it
            if (scr_stream_in_valid) begin
                if (m_has && mp == rd_ctx) landed_beats <= landed_beats + 11'd1; else f_landed[rd_ctx] <= f_landed[rd_ctx] + 11'd1;
            end
`else
            if (scr_stream_in_valid) begin if (rd_own_m) landed_beats <= landed_beats + 11'd1; else f_landed <= f_landed + 11'd1; end
`endif
`else
            if (scr_stream_in_valid) landed_beats <= landed_beats + 11'd1;
`endif
            if (st_ins_en) req_pidx_cur <= st_ins_pidx;  // the pool index this insert allocates
`ifdef ORAM_OVERLAP4
            // the record read at a lookup belongs to that front record (b_ctx); to M if M has taken it already. A
            // later write to the same bucket (above) wins over a read that returns after it.
            if (bm_rd_valid && fmt_done_r) begin
                if (!(f_bmseen[b_ctx] && f_looked[b_ctx]) && !(bm_wr_en && bm_wr_bucket == f_b[b_ctx]))
                    begin f_bml[b_ctx] <= bm_rd_slot_list; f_bmf[b_ctx] <= bm_rd_fill; end
                f_bmseen[b_ctx] <= 1'b1;
                if (m_has && mp == b_ctx && !bm_seen) begin bkt_slot_list <= bm_rd_slot_list; bkt_fill_count <= bm_rd_fill; bm_seen <= 1'b1; end
            end else if (bm_rd_valid) begin
                bkt_slot_list  <= bm_rd_slot_list;
                bkt_fill_count <= bm_rd_fill;
                bm_seen        <= 1'b1;
            end
`else
            if (bm_rd_valid) begin                       // bucket metadata (read issued at S_RD_GATE)
                bkt_slot_list  <= bm_rd_slot_list;
                bkt_fill_count <= bm_rd_fill;
                bm_seen        <= 1'b1;                  // v14 (cleared at the position lookup)
            end
`endif
            // a stash open deferred until the previous access's commit has drained (early release)
`ifdef ORAM_OVERLAP4
            if (st_open_req && st_open_ok) begin st_open_en <= 1; st_open_req <= 0; end
            if (st_commit) cm_age <= 2'd0; else if (cm_age != 2'd3) cm_age <= cm_age + 2'd1;
`else
            if (st_open_req && st_wr_quiet) begin st_open_en <= 1; st_open_req <= 0; end
`endif
            // write-back starts at exactly CT_WB, wherever the encryption is
`ifdef ORAM_OVERLAP2
`ifdef ORAM_OVERLAP4
            // a read completing now has its effective arrival ga_wait cycles from now (0 unless the previous arrival
            // was less than OV_GA ago); the next one no earlier than OV_GA after it
            if (axim_read_done) begin
                if (m_has && mp == rdone_ctx) begin if (!arr_seen) begin t_arr <= ct_cnt + ga_wait; arr_seen <= 1'b1; end end
                else begin : f_arrive                    // per context (no select in front of the adder: 300 MHz)
                    integer q;
                    for (q = 0; q < NC; q = q + 1)
                        if (rdone_ctx == q && !f_arr[q]) begin f_tarr[q] <= f_ct[q] + ga_wait; f_arr[q] <= 1'b1; end
                end
                ga_wait <= ga_wait + OV_GA - 1;
            end else if (ga_wait != 0) ga_wait <= ga_wait - 1;
`ifdef ORAM_OV4_P3
            // phase 3: from each effective arrival (now + ga_wait), count to the context's release (OV_L) and to its
            // same-bucket readers' gate (OV_LEQ)
            begin : p3_cnt
                integer q, k; reg ok;
                for (q = 0; q < NC; q = q + 1) begin
                    if (axim_read_done && rdone_ctx == q) begin
                        cfc[q] <= ga_wait[15:0] + OV_L; eqc[q] <= ga_wait[15:0] + OV_LEQ;
                        cf_wait[q] <= 1'b0; ea_arr[q] <= 1'b1;
                    end else begin
                        if (cfc[q] != 16'd0) cfc[q] <= cfc[q] - 16'd1;
                        if (eqc[q] != 16'd0) eqc[q] <= eqc[q] - 16'd1;
                    end
                    ok = 1'b1;
                    for (k = 0; k < NC; k = k + 1) if (f_eqmk[q][k] && !ea_ok[k]) ok = 1'b0;
                    if (f_eqa[q] && f_looked[q] && ok) f_eqok[q] <= 1'b1;
                end
            end
`endif
            // write-backs, in access order (w_next): off package exactly at t_arr + AR_WB (the engine must be free and
            // quiet then: fail-stop otherwise, never a wait); on package once the engine is free and quiet
            begin : w_issue
                reg [1:0] wu; wu = w_next;
                if (t_wbp[wu] && tst[wu] != T_IDLE) begin
`ifdef ORAM_OV4_P3
                    if (t_wsok[wu]) begin                 // phase 3: on or off package, at exactly t' + AR_WB
`else
                    if (BYP && t_hbm[wu] ? (!wb_active && !axim_cmd_write && axim_wr_quiet)
                                         : t_wbok[wu]) begin
`endif
                        if (wb_active || axim_cmd_write || !axim_wr_quiet) err_ct_overrun_r <= 1'b1;
                        else begin
                            axim_cmd_bucket <= t_b[wu]; axim_cmd_write <= 1'b1;
                            t_wbp[wu] <= 1'b0; wb_active <= 1'b1; w_par <= wu; w_next <= wu + 2'd1;
                        end
                    end
                end
            end
`else
            if (axim_read_done) begin
                if (rd_own_m) begin if (!arr_seen) begin t_arr <= ct_cnt; arr_seen <= 1'b1; end end
                else if (!f_arr) begin f_tarr <= f_ct; f_arr <= 1'b1; end
            end
            // write-backs, in access order (w_next): off package exactly at t_arr + AR_WB (the write engine must be free
            // then: fail-stop otherwise, never a wait); on package as soon as the engine is free (not observable)
            begin : w_issue
                reg wu; wu = w_next;
                if (t_wbp[wu] && tst[wu] != T_IDLE) begin
                    // one write in flight at a time, acknowledged before the next (the kernel's bucket-port switch
                    // routes B by the latest AW: kernel doma_kernel.v)
                    if (BYP && t_hbm[wu] ? (!wb_active && !axim_cmd_write && axim_wr_quiet)
                                         : t_wbok[wu]) begin
                        if (wb_active || axim_cmd_write || !axim_wr_quiet) err_ct_overrun_r <= 1'b1;
                        else begin
                            axim_cmd_bucket <= t_b[wu]; axim_cmd_write <= 1'b1;
                            t_wbp[wu] <= 1'b0; wb_active <= 1'b1; w_par <= wu; w_next <= ~wu;
                        end
                    end
                end
            end
`endif
            if (1'b0) begin
                if (1'b0)
`else
            if (axim_read_done && !arr_seen) begin t_arr <= ct_cnt; arr_seen <= 1'b1; end   // the bucket's last beat
`ifdef ORAM_NOCRYPTO
            if (wb_pending && ((AR_MODE && cr_mode != CR_FMT) ?
                    (arr_seen && ct_cnt >= t_arr + nc_wbf && (state == S_EA_START || state == S_DDR_WRITE))
                  : (CT_WB != 0 && ct_cnt >= CT_WB))) begin
`elsif ORAM_ONPKG_FIXWB
            if (wb_pending && ((AR_MODE && cr_mode != CR_FMT) ?
                    (byp_acc ? (arr_seen && ct_cnt >= t_arr + AR_WBF_H && (state == S_EA_START || state == S_DDR_WRITE))
                             : (arr_seen && ct_cnt >= t_arr + (acc_hbm ? AR_WB_H : AR_WB)))
                  : (CT_WB != 0 && ct_cnt >= CT_WB))) begin
`else
            if (wb_pending && ((AR_MODE && cr_mode != CR_FMT) ? (!byp_acc && arr_seen && ct_cnt >= t_arr + (acc_hbm ? AR_WB_H : AR_WB))
                                                              : (CT_WB != 0 && ct_cnt >= CT_WB))) begin
`endif
                if (cr_mode != CR_FMT && !arr_seen)
`endif
                    // the write-back gate opened while this access's bucket read is still in flight: the budget
                    // is too early for the memory. Fail-stop (an overrun), never issue the write into a busy
                    // master (that would hang instead of halting).
                    err_ct_overrun_r <= 1'b1;
                else begin
                    axim_cmd_bucket <= req_b; axim_cmd_write <= 1'b1;
                    wb_pending <= 1'b0; wb_active <= 1'b1;
                end
            end
            if (axim_write_done) begin wb_active <= 1'b0; wb_done_seen <= 1'b1; end
            // the write-back caught up with the encryption (budget too early), or
            // two streams met in one scratch bank: timing violation -> fail-stop
            // (v14, on package: the write waits for the copies by design, so a held beat is no overrun there; a bank
            // conflict is, reported at the release time like the deadlines below)
`ifdef ORAM_OVERLAP2
            // the write-back (T's) caught up with the encryption: overrun. A scratch bank conflict: recorded on each
            // on-package access in flight (reported at its release time), an overrun if an off-package one is in flight.
`ifdef ORAM_OVERLAP4
`ifdef ORAM_OV4_P3
            if (axim_wdata_stall && wb_active) err_ct_overrun_r <= 1'b1;   // phase 3: hold-free on package too
`else
            if (axim_wdata_stall && wb_active && !(BYP && t_hbm[w_par])) err_ct_overrun_r <= 1'b1;
`endif
`ifdef ORAM_ONPKG_DEBUG
            if (scr_clash) begin : ov4_bc
`else
            if (scr_bank_conflict) begin : ov4_bc
`endif
                integer q;
                ov_bc <= 1'b1;
                if (m_has && byp_acc) byp_ov <= 1'b1;
                if (m_has && !byp_acc) err_ct_overrun_r <= 1'b1;
                for (q = 0; q < NC; q = q + 1) begin
                    if (t_busy[q] && BYP && t_hbm[q]) t_byp_ov[q] <= 1'b1;
                    if (t_busy[q] && !(BYP && t_hbm[q])) err_ct_overrun_r <= 1'b1;
                end
            end
`else
            if (axim_wdata_stall && wb_active && !(BYP && t_hbm[w_par])) err_ct_overrun_r <= 1'b1;
`ifdef ORAM_ONPKG_DEBUG
            if (scr_clash) begin
`else
            if (scr_bank_conflict) begin
`endif
                ov_bc <= 1'b1;
                if (m_has && byp_acc) byp_ov <= 1'b1;
                if (t_busy0 && BYP && t_hbm[0]) t_byp_ov[0] <= 1'b1;
                if (t_busy1 && BYP && t_hbm[1]) t_byp_ov[1] <= 1'b1;
                if ((m_has && !byp_acc) || (t_busy0 && !(BYP && t_hbm[0])) || (t_busy1 && !(BYP && t_hbm[1])))
                    err_ct_overrun_r <= 1'b1;
            end
`endif
`else
`ifdef ORAM_ONPKG_DEBUG
            if ((axim_wdata_stall && !byp_acc) || scr_clash) begin   // debug: every conflict (the flag is sticky)
`else
            if ((axim_wdata_stall && !byp_acc) || scr_bank_conflict) begin
`endif
                if (byp_acc) begin byp_ov <= 1'b1; ov_bc <= 1'b1; end else err_ct_overrun_r <= 1'b1;
            end
`ifdef ORAM_ONPKG_FIXWB
            // Option A: the on-package write streams hold-free from its fixed start. A beat held for an eviction copy
            // that has not landed is a deadline (1) miss (ov_by1 counts the held cycles), reported at the release time.
            if (axim_wdata_stall && wb_active && byp_acc) begin
                byp_ov <= 1'b1; ov_d1 <= 1'b1; if (ov_by1 != 16'hFFFF) ov_by1 <= ov_by1 + 16'd1;
            end
`endif
`endif
            // v14, on package: (1) every eviction decision made, the write-back started, by t_arr + AR_WB_H (an early
            // check: AR_WB_H covers the decisions' worst case); (2) the write handed off (its last beat accepted) and
            // the release gate reached by the release time t_arr + AR_REL_H. A miss of either is a timing overrun,
            // reported at the release time itself, never earlier; the release never moves.
            // v14b: each miss is recorded (ov_*) with the cycles until the late event, for the halt record; the debug
            // build (ONPKG_HALT = 0) records and counts it but does not halt.
            if (ev_d1) begin
                byp_ov <= 1'b1; ov_d1 <= 1'b1; ov_by1 <= 16'd1; ov_run1 <= 1'b1;
            end
            if (ov_run1) begin
                if (state == S_EA_START) ov_run1 <= 1'b0; else if (ov_by1 != 16'hFFFF) ov_by1 <= ov_by1 + 16'd1;
            end
`ifdef ORAM_OVERLAP2
`ifdef ORAM_OVERLAP4
            if (|ev_rtv) begin
                if (|ev_d2v) begin ov_d2 <= 1'b1; ov_by2 <= 16'd1; ov_run2 <= 1'b1; end
                if (|(ev_rtv & (t_bypv | ev_d2v))) begin ov_rel <= 1'b1; if (ONPKG_HALT) err_ct_overrun_r <= 1'b1; end
            end
            if (ev_rt_m) begin                                   // the release time came with the decisions still running
                ov_d2 <= 1'b1; ov_by2 <= 16'd1; ov_run2 <= 1'b1; ov_rel <= 1'b1; if (ONPKG_HALT) err_ct_overrun_r <= 1'b1;
            end
            if (ov_run2) begin
                if (|t_gatev) ov_run2 <= 1'b0; else if (ov_by2 != 16'hFFFF) ov_by2 <= ov_by2 + 16'd1;
            end
            // on package: the write-back may send the leading positions whose eviction copies (M, same access) landed
            if (c_own_hbm) epd[c_own] <= byp_lead;
`else
            if (ev_rt0 || ev_rt1) begin
                if (ev_d20 || ev_d21) begin ov_d2 <= 1'b1; ov_by2 <= 16'd1; ov_run2 <= 1'b1; end
                if ((ev_rt0 && (t_byp_ov[0] || ev_d20)) || (ev_rt1 && (t_byp_ov[1] || ev_d21))) begin
                    ov_rel <= 1'b1; if (ONPKG_HALT) err_ct_overrun_r <= 1'b1;
                end
            end
            if (ev_rt_m) begin                                   // the release time came with the decisions still running
                ov_d2 <= 1'b1; ov_by2 <= 16'd1; ov_run2 <= 1'b1; ov_rel <= 1'b1; if (ONPKG_HALT) err_ct_overrun_r <= 1'b1;
            end
            if (ov_run2) begin
                if (tst[0] == T_GATE || tst[1] == T_GATE) ov_run2 <= 1'b0; else if (ov_by2 != 16'hFFFF) ov_by2 <= ov_by2 + 16'd1;
            end
            // on package: T's write-back may send the leading positions whose eviction copies (M, same access) landed
            if (byp_acc && m_is_t) enc_pos_done <= byp_lead;
`endif
`else
            if (ev_rt) begin
                if (ev_d2) begin ov_d2 <= 1'b1; ov_by2 <= 16'd1; ov_run2 <= 1'b1; end
                if (byp_ov || ev_d2) begin ov_rel <= 1'b1; if (ONPKG_HALT) err_ct_overrun_r <= 1'b1; end
            end
            if (ov_run2) begin
                if (state == S_DONE_GATE) ov_run2 <= 1'b0; else if (ov_by2 != 16'hFFFF) ov_by2 <= ov_by2 + 16'd1;
            end
            // v14, on package: the write-back may send the leading positions whose eviction copies have landed
            if (byp_acc && wb_active) enc_pos_done <= byp_lead;
`endif
            // ---- background eviction-copy engine: stash entry -> bucket position ----
            // Safe to read entries the eviction loop already marked free: nothing is
            // inserted into the stash between eviction and the end of this access,
            // and encryption (hence the access) cannot finish before every copy.
            // v14d: a copy starts once its block has landed (the stash's `ready` no longer waits for the window's data;
            // the write-back streams behind the copies, so a later landing only holds the write, never a decision)
            if (!ec_active && evq_rp != evq_wp && st_landed[evq_ent[evq_rp[3:0]][3:0]]) begin
                ec_active <= 1'b1; ec_ent <= evq_ent[evq_rp[3:0]]; ec_pos <= evq_pos[evq_rp[3:0]];
                ec_rd_beat <= 0; ec_wr_beat <= 0;
            end
            if (ec_active) begin
                if (ec_rd_beat < BEATS) begin
                    st_drd_entry <= ec_ent; st_drd_beat <= ec_rd_beat_x;
                    st_drd_en <= 1'b1; ec_rd_beat <= ec_rd_beat + 1'b1;
                end
                if (st_drd_valid && ec_wr_beat < BEATS) begin
                    scr_ev_wr_addr <= scr_addr(ec_pos, ec_wr_beat_x);
                    scr_ev_wr_data <= st_drd_data; scr_ev_wr_en <= 1'b1;
                    ec_wr_beat <= ec_wr_beat + 1'b1;
                end
                if (ec_wr_beat == BEATS) begin
                    ec_active <= 1'b0; evq_rp <= evq_rp + 5'd1;
                    ev_pending[ec_pos] <= 1'b0;
                end
            end
            if (gcm_tag_valid) begin
                tag_seen <= 1'b1; tag_match_q <= gcm_tag_match;
                tag_q <= gcm_tag_out; iv_q <= gcm_iv_out;
            end
            // ---- crypto engine data path (independent of the FSM state) ----
            // reads issued in S_CR_FEED return two cycles later: one whole beat to the core per cycle
`ifdef ORAM_OVERLAP4
            // step 2: the scratch returns data two cycles after the read (its block RAMs' output registers)
            fd_v <= {fd_v[1:0], 1'b0}; fd_last <= {fd_last[1:0], 1'b0}; fd_zero <= {fd_zero[1:0], 1'b0};
            gcm_data_in <= fd_zero[2] ? {AXI_DW{1'b0}} : scr_fsm_rd_data;        // boot format: zero blocks
            if (fd_v[2]) begin
                gcm_data_valid <= 1'b1;
                gcm_data_last  <= fd_last[2];                                       // end of the bucket's message
            end
`else
            fd_v <= {fd_v[0], 1'b0}; fd_last <= {fd_last[0], 1'b0}; fd_zero <= {fd_zero[0], 1'b0};
            gcm_data_in <= fd_zero[1] ? {AXI_DW{1'b0}} : scr_fsm_rd_data;        // boot format: zero blocks
            if (fd_v[1]) begin
                gcm_data_valid <= 1'b1;
                gcm_data_last  <= fd_last[1];                                       // end of the bucket's message
            end
`endif
            // the core's output beats: queued, then written back in place, one beat per cycle (S_CP's copies,
            // below, use the same write port in their own states, when the queue is empty)
            if (oq_push) oq_wp <= oq_wp + 1'b1;
            scr_fsm_wr_addr <= wr_lin[`SCR_AW-1:0]; scr_fsm_wr_data <= oq_hd;
            if (oq_pop) begin
                scr_fsm_wr_en <= 1;
                oq_rp <= oq_rp + 1'b1; wr_lin <= wr_lin + 11'd1; wr_lim <= wr_lim + 11'd1;
                if ((wr_lin & (BEATS - 1)) == BEATS - 1) wr_end <= wr_end + BEATS;    // next position
            end
            oq_n <= oq_n + oq_push - oq_pop;
            if (oq_push && !oq_pop && oq_n == OQ_D) err_ct_overrun_r <= 1'b1;   // impossible (rd_room); fail-stop if it were not
            case (state)
                S_IDLE: begin
                    client_stall <= !fmt_done_r;
                    if (err_tag_mismatch || err_stash_overflow || err_ct_overrun_r) begin
                        client_stall <= 1;
                        state <= S_HALT;                  // fail-stop
                    end else if (!fmt_done_r && boot_drain) begin
                        // Ready only once every boot write is acknowledged: an access must never
                        // start with writes outstanding (its read would be held while its fixed
                        // write-back point still arrives).
                        // Every boot write is acknowledged, but on the card the HBM controllers acknowledge a write when
                        // they queue it, so the first read after boot can still wait microseconds behind the queued writes
                        // (measured: 1,120-2,426 cycles for the first lookup against CT_RD = 266, a timing overrun). So the
                        // controller waits a fixed BOOT_SETTLE cycles more before it accepts the first access.
                        // v11b: the settle starts only when the boot budget has elapsed (lay_due, below), with every
                        // write landed, so the controller is ready at the same cycle whatever the placement.
                        if (lay_due && boot_quiet) begin
                            if (boot_settle == BOOT_SETTLE) begin fmt_done_r <= 1'b1; boot_drain <= 1'b0; boot_settle <= 0; lay_run <= 1'b0; end
                            else boot_settle <= boot_settle + 1'b1;
                        end
                    end else if (!fmt_done_r) begin
`ifdef ORAM_OVERLAP4
                        if (aes_key != 128'd0 && key_settled && nb_ok_q) begin   // (nb_ok a cycle late: boot only, 300 MHz)
`else
                        if (aes_key != 128'd0 && key_settled && nb_ok) begin   // key loaded and settled, bucket count known: format DDR
`endif
                            fmt_b <= 0;
                            state <= S_FMT_START;
                        end
`ifdef ORAM_OVERLAP2
`ifdef ORAM_OVERLAP4
                    end else if (f_has[m_take] && f_looked[m_take]) begin   // take the next context in order
                        req_slot_addr <= f_slot[m_take]; req_part <= f_part[m_take]; req_op <= f_op[m_take];
                        req_b <= f_b[m_take]; acc_hbm <= f_hbm[m_take]; req_b_new <= f_bnew[m_take]; same_bucket <= f_same[m_take];
                        // (a position-map or record write landing in this very cycle is passed through: it is
                        // the correction the front record would get one cycle later)
                        req_pidx_cur <= (pm_wr_en && pm_wr_addr == f_slot[m_take]) ? pm_wr_pidx : f_pidx[m_take]; res_zero <= 1'b0;
                        ct_cnt <= f_ct[m_take] + 32'd1; mp <= m_take; m_take <= m_take + 2'd1;
                        m_has <= 1'b1; m_pre_ea <= 1'b1; m_is_t <= 1'b0;
                        f_has[m_take] <= 1'b0;
                        if (tst[m_take] != T_IDLE) err_ct_overrun_r <= 1'b1;   // its result buffer: the tail four back is done
                        // the read so far (landed beats, arrival), and from now on M's (r_par == mp)
                        landed_beats <= f_landed[m_take] + ((scr_stream_in_valid && rd_ctx == m_take) ? 11'd1 : 11'd0);
                        if (f_arr[m_take]) begin t_arr <= f_tarr[m_take]; arr_seen <= 1'b1; end
                        else if (axim_read_done && rdone_ctx == m_take) begin t_arr <= f_ct[m_take] + ga_wait; arr_seen <= 1'b1; end
                        else arr_seen <= 1'b0;
                        // the bucket record, as read and corrected by every later write to it (if it has arrived)
                        if (bm_wr_en && f_looked[m_take] && bm_wr_bucket == f_b[m_take]) begin
                            bkt_slot_list <= bm_wr_slot_list; bkt_fill_count <= bm_wr_fill; bm_seen <= 1'b1;
                        end else if (bm_rd_valid && b_ctx == m_take && !f_bmseen[m_take]) begin   // its own read, now
                            bkt_slot_list <= bm_rd_slot_list; bkt_fill_count <= bm_rd_fill; bm_seen <= 1'b1;
                        end else begin
                            bkt_slot_list <= f_bml[m_take]; bkt_fill_count <= f_bmf[m_take]; bm_seen <= f_bmseen[m_take];
                        end
                        // the stash open, with the corrected status and pool index (the previous access's copies are
                        // done: M was free), once its commit drained
                        st_open_b <= f_b[m_take]; st_open_slot <= f_slot[m_take]; st_open_bt <= f_bnew[m_take];
                        if (pm_wr_en && pm_wr_addr == f_slot[m_take]) begin
                            st_open_instash <= (pm_wr_status == `ST_IN_STASH); st_open_pidx <= pm_wr_pidx;
                        end else begin
                            st_open_instash <= f_instash[m_take]; st_open_pidx <= f_pidx[m_take];
                        end
                        if (st_open_ok) st_open_en <= 1; else st_open_req <= 1;
                        byp_ov <= 1'b0; ov_d1 <= 1'b0; ov_run1 <= 1'b0; ov_by1 <= 16'd0;
                        cr_mode <= CR_DA; cr_pos <= 0; cr_zero <= 1'b0;
                        state <= (BYP && f_hbm[m_take]) ? S_DDR_READ : S_CR_IV;
                    end
`else
                    end else if (f_has && f_looked) begin           // take F's access (its lookup is done)
                        req_slot_addr <= f_slot; req_part <= f_part; req_op <= f_op;
                        req_b <= f_b; acc_hbm <= f_hbm; req_b_new <= f_bnew; same_bucket <= f_same;
                        req_pidx_cur <= f_pidx; res_zero <= 1'b0;
                        ct_cnt <= f_ct + 32'd1; mp <= f_par; m_has <= 1'b1; m_pre_ea <= 1'b1; m_is_t <= 1'b0;
                        f_has <= 1'b0; f_looked <= 1'b0;
                        if (tst[f_par] != T_IDLE) err_ct_overrun_r <= 1'b1;   // its result buffer: the tail two back is done
                        // the read: landed beats and arrival so far, and from now on M's
                        rd_own_m <= 1'b1;
                        landed_beats <= f_landed + (scr_stream_in_valid ? 11'd1 : 11'd0);
                        if (f_arr) begin t_arr <= f_tarr; arr_seen <= 1'b1; end
                        else if (axim_read_done) begin t_arr <= f_ct; arr_seen <= 1'b1; end
                        else arr_seen <= 1'b0;
                        // the stash open: the previous access's copies are done (M was free); once its commit drained
                        st_open_b <= f_b; st_open_slot <= f_slot; st_open_bt <= f_bnew;
                        st_open_instash <= f_instash; st_open_pidx <= f_pidx;
                        if (st_wr_quiet) st_open_en <= 1; else st_open_req <= 1;
                        evq_wp <= 0; evq_rp <= 0; ev_pending <= 0; ec_active <= 0;
                        byp_ov <= 1'b0; ov_d1 <= 1'b0; ov_run1 <= 1'b0; ov_by1 <= 16'd0;
                        cr_mode <= CR_DA; cr_pos <= 0; cr_zero <= 1'b0;
                        state <= (BYP && f_hbm) ? S_DDR_READ : S_CR_IV;
                    end
`endif
`else
                    end else if (client_req) begin
                        req_slot_addr <= client_slot_addr;
                        req_part      <= in_part;
                        req_op        <= client_op;
                        client_stall  <= 1;
                        ct_cnt        <= 32'd0; arr_seen <= 1'b0;
                        res_zero      <= 1'b0;
                        pm_rd_addr    <= client_slot_addr; pm_rd_en <= 1;
                        rnd_bucket_q  <= prng_bucket; rng_take <= 1;   // use it; the generator draws the next
                        state         <= S_POS_LOOKUP;
                    end
`endif
                end
                S_POS_LOOKUP: begin
                    if (pm_rd_valid) begin
                        req_b       <= pm_rd_bucket;
                        acc_hbm     <= ({1'b0, pm_rd_bucket} < cfg_hbm_bkts);
                        // open the bucket's record in HBM now: HBM is on-package and its accesses are
                        // not observable, so this fetch need not wait for the fixed read gate (only the
                        // bucket's own, off-package read does). It then lands well before position 0.
                        bm_rd_bucket <= pm_rd_bucket; bm_rd_en <= 1; bm_seen <= 1'b0;
                        // open the stash's two buckets (the one read, the new target) now as well
                        st_open_b <= pm_rd_bucket; st_open_slot <= req_slot_addr;
                        if (st_wr_quiet) st_open_en <= 1; else st_open_req <= 1;   // after an early release: once quiet
                        st_open_instash <= (pm_rd_status == `ST_IN_STASH); st_open_pidx <= pm_rd_pidx;
                        req_pidx_cur <= pm_rd_pidx;
                        st_open_bt <= dbg_force_same_bucket ? pm_rd_bucket : b_new_part;
                        // the new bucket stays inside the access's own partition
                        req_b_new   <= dbg_force_same_bucket ? pm_rd_bucket : b_new_part;
                        same_bucket <= dbg_force_same_bucket ? 1'b1 : (b_new_part == pm_rd_bucket);
                        if (ct_cnt + 1 > ct_max_rd) ct_max_rd <= ct_cnt + 1;
`ifdef ORAM_NOCRYPTO
                        if (ct_cnt >= nc_ct_rd) err_ct_overrun_r <= 1'b1;
`else
                        if (CT_RD != 0 && ct_cnt + 1 > CT_RD) err_ct_overrun_r <= 1'b1;
`endif
                        state <= S_RD_GATE;
                    end
                end
                S_RD_GATE: begin
`ifdef ORAM_NOCRYPTO
                    if (ct_cnt >= nc_ct_rd) begin
`else
                    if (CT_RD == 0 || ct_cnt >= CT_RD) begin
`endif
                        axim_cmd_bucket <= req_b; axim_cmd_read <= 1;
                        landed_beats <= 0; enc_pos_done <= 0;
                        evq_wp <= 0; evq_rp <= 0; ev_pending <= 0; ec_active <= 0;
                        wb_pending <= 1'b1; wb_active <= 1'b0; wb_done_seen <= 1'b0; byp_ov <= 1'b0;
                        ov_d1 <= 1'b0; ov_d2 <= 1'b0; ov_bc <= 1'b0; ov_rel <= 1'b0; ov_run1 <= 1'b0; ov_run2 <= 1'b0;
                        ov_by1 <= 16'd0; ov_by2 <= 16'd0;
                        // streaming: start the verify loop now; each position waits
                        // only until its own beats have landed (S_CR_IV)
                        cr_mode <= CR_DA; cr_pos <= 0; cr_zero <= 1'b0;
`ifdef ORAM_NOCRYPTO
                        state <= S_DDR_READ;                                // every bucket: no verification pass
`else
                        state <= (BYP && acc_hbm) ? S_DDR_READ : S_CR_IV;   // v14: on package, no verification pass
`endif
                    end
                end
                S_DDR_READ: begin
                    // v14 (was unused): an on-package bucket. Its plaintext lands in scratch straight from the read
                    // stream; once its last beat and its whole record are in (the metadata; its IV/tag beat is unused),
                    // the block operation starts. No decryption, no tag check.
                    if (arr_seen && bm_seen && !br_rd_busy) state <= S_SCAN;
                end
`ifndef ORAM_NOCRYPTO
                S_CR_IV: begin
                    // PER-BUCKET AUTHENTICATION: one GCM message spans all Z positions. It starts here, at position 0:
                    // the bucket's IV and tag are read and the message starts; S_CR_FEED then streams every position
                    // (the counter runs on across positions, GHASH accumulates), and the single tag is checked or
                    // stored after the last. Decryption starts at once: its reads wait for each beat to land
                    // (rd_landed), so the core is ready before position 0 has landed.
                    beat_cnt <= 0; rd_lin <= 0; rd_base <= 0; wr_lin <= 0; wr_end <= BEATS; wr_lim <= OQ_D;
                    tag_seen <= 1'b0;
                    if (cr_mode == CR_DA) begin
`ifdef ORAM_OVERLAP4
                        if (!f_eqa[mp] || f_rdiss[mp]) begin
                            ivt_rd_addr <= ivt_addr(req_b, {POS_W{1'b0}}); ivt_rd_en <= 1;
                            state <= S_CR_IVW;
                        end
`else
                        ivt_rd_addr <= ivt_addr(req_b, {POS_W{1'b0}}); ivt_rd_en <= 1;
                        state <= S_CR_IVW;
`endif
                    end else if (!(cr_mode == CR_EA && ev_pending[0])) begin
                        gcm_encrypt <= 1'b1; gcm_iv_reg <= aes_iv_seed; gcm_start <= 1'b1;
                        state <= S_CR_START;
                    end                                 // else: eviction copy into position 0 still running
                end
                S_CR_IVW: begin
                    if (ivt_rd_valid) begin
                        gcm_iv_reg <= ivt_rd_iv; gcm_tag_in <= ivt_rd_tag;
                        gcm_encrypt <= 1'b0; gcm_start <= 1'b1;
                        state <= S_CR_START;
                    end
                end
                S_CR_START: if (gcm_input_ready) state <= S_CR_FEED;   // the core takes beats from now on
                S_CR_FEED: begin
                    // One beat per cycle: the scratch read (the boot format: a zero beat) of position cr_pos, beat
                    // beat_cnt; the data path above hands it to the core two cycles later, the last one flagged.
                    // Decryption: once the beat has landed. Encryption: a position starts once its eviction copy is
                    // done and the previous position is written back, so the encryption never overtakes the eviction
                    // copies and takes the same time whatever they do.
                    if (cr_mode == CR_EA && wr_pos < Z) enc_pos_done <= wr_pos[3:0];
                    if (gcm_input_ready && rd_room &&
                        ((cr_mode == CR_DA) ? rd_landed :
                         (cr_mode == CR_EA) ? (beat_cnt != 0 || (!ev_pending[cr_pos[POS_W-1:0]] && wr_lin >= rd_base)) :
                                              1'b1)) begin
                        if (!cr_zero) begin
                            scr_fsm_rd_addr <= scr_addr(cr_pos[POS_W-1:0], beat_cnt);
                            scr_fsm_rd_en   <= 1;
                        end
                        fd_v[0] <= 1'b1; fd_zero[0] <= cr_zero;
                        fd_last[0] <= (beat_cnt == BEATS - 1) && (cr_pos == Z - 1);   // end of the bucket's message
                        rd_lin <= rd_lin + 11'd1;
                        if (beat_cnt != BEATS - 1) beat_cnt <= beat_cnt + 1;
                        else begin
                            beat_cnt <= 0;
                            if (cr_pos == Z - 1) state <= S_CR_RECV;
                            else begin cr_pos <= cr_pos + 1'b1; rd_base <= rd_base + BEATS; end
                        end
                    end
                end
                S_CR_RECV: begin                        // every beat issued: wait until all are written back
                    if (cr_mode == CR_EA && wr_pos < Z) enc_pos_done <= wr_pos[3:0];
                    if (wr_lin == TOTAL_BEATS) state <= S_CR_TAG;   // the bucket's tag follows the last position
                end
                S_CR_TAG: begin
                    if (tag_seen) begin
                        if (cr_mode == CR_DA && !tag_match_q) begin
                            err_tag_mismatch <= 1'b1;    // the whole bucket must verify
                            client_stall <= 1;
                            state <= S_HALT;
                        end else begin
                            if (cr_mode != CR_DA) begin  // record the bucket's fresh IV + tag
                                ivt_wr_addr <= ivt_addr(req_b, {POS_W{1'b0}});
                                ivt_wr_iv   <= iv_q; ivt_wr_tag <= tag_q; ivt_wr_en <= 1;
                            end
                            if (cr_mode == CR_EA) enc_pos_done <= {1'b0, cr_pos} + 4'd1;
                            if (cr_pos == Z - 1) begin
                                if (cr_mode == CR_EA && ct_cnt > ct_max_wb) ct_max_wb <= ct_cnt;  // encryption end
`ifdef ORAM_OVERLAP4
                                if (cr_mode == CR_EA && arr_seen && !acc_hbm && ar_since > ar_max_wb)   ar_max_wb   <= ar_since;
`else
                                if (cr_mode == CR_EA && arr_seen && !acc_hbm && ct_cnt - t_arr > ar_max_wb)   ar_max_wb   <= ct_cnt - t_arr;
`endif
`ifdef ORAM_OVERLAP4
                                if (cr_mode == CR_EA && arr_seen &&  acc_hbm && ar_since > ar_max_wb_h) ar_max_wb_h <= ar_since;
`else
                                if (cr_mode == CR_EA && arr_seen &&  acc_hbm && ct_cnt - t_arr > ar_max_wb_h) ar_max_wb_h <= ct_cnt - t_arr;
`endif
`ifdef ORAM_OVERLAP2
                                if (cr_mode == CR_EA) m_has <= 1'b0;
                                state <= (cr_mode == CR_DA) ? S_SCAN : (cr_mode == CR_EA) ? S_IDLE : S_FMT_WRITE;
`else
                                state <= (cr_mode == CR_DA) ? S_SCAN :
                                         (cr_mode == CR_EA) ? ((CT_WB == 0) ? S_WB_GATE : S_DDR_WRITE) :
                                                              S_FMT_WRITE;
`endif
                            end
                            else begin
                                cr_pos <= cr_pos + 1'b1;
                                state  <= S_CR_IV;
                            end
                        end
                    end
                end
`endif
`ifdef ORAM_OVERLAP4
                S_SCAN: if (st_ready && bm_seen) begin  // the stash's lists and blocks, and the record, are on chip
                    c_own <= mp; c_own_hbm <= BYP && acc_hbm;
`else
                S_SCAN: if (st_ready) begin            // the stash's lists and blocks are on chip
`endif
                    begin : scan_block
                        integer i; reg hit; reg [POS_W-1:0] hit_pos;
                        hit = 0; hit_pos = 0;
                        for (i = 0; i < Z; i = i + 1)
                            if (i < bkt_fill_count)
                                if (get_slot_at(bkt_slot_list, i[POS_W-1:0]) == req_slot_addr)
                                    begin hit = 1; hit_pos = i[POS_W-1:0]; end
                        found_in_bucket <= hit;
                        found_pos       <= hit_pos;
                    end
                    found_in_stash  <= st_cam_slot_hit;
                    found_stash_idx <= st_cam_slot_idx;
                    fill <= bkt_fill_count;                      // zero-extends: holds 0..Z
                    state <= S_OP;
                end
                S_OP: begin
                    cp_rd_beat <= 0; cp_wr_beat <= 0; beat_cnt <= 0;
                    cp_to_stash <= 0; cp_to_scr <= 0; cp_to_res <= 0; cp_merge <= 0;
                    if (found_in_bucket) begin
                        if (st_ins_full) begin
                            err_stash_overflow <= 1'b1; client_stall <= 1; state <= S_HALT;
                        end else begin
                            tgt_ent <= st_ins_idx;
                            st_ins_slot <= req_slot_addr; st_ins_tgt <= req_b_new; st_ins_en <= 1;
                            cp_dst_ent <= st_ins_idx; cp_to_stash <= 1;
                            if (req_op) begin cp_src <= CPS_SCR; cp_src_pos <= found_pos; cp_merge <= 1; end  // old block from the bucket
                            else begin cp_src <= CPS_SCR; cp_src_pos <= found_pos; cp_to_res <= 1; end
                            cp_ret <= S_COMPACT;
                            state  <= S_CP;
                        end
                    end else if (found_in_stash) begin
                        tgt_ent <= found_stash_idx;
                        st_remap_idx <= found_stash_idx; st_remap_bkt <= req_b_new; st_remap_en <= 1;
                        if (req_op) begin cp_src <= CPS_STASH; cp_src_ent <= found_stash_idx;   // merge in place
                                          cp_dst_ent <= found_stash_idx; cp_to_stash <= 1; cp_merge <= 1; end
                        else        begin cp_src <= CPS_STASH; cp_src_ent <= found_stash_idx; cp_to_res <= 1; end
                        cp_ret <= S_PM_UPD;
                        state  <= S_CP;
                    end else if (req_op) begin
                        if (st_ins_full) begin
                            err_stash_overflow <= 1'b1; client_stall <= 1; state <= S_HALT;
                        end else begin
                            tgt_ent <= st_ins_idx;
                            st_ins_slot <= req_slot_addr; st_ins_tgt <= req_b_new; st_ins_en <= 1;
                            cp_src <= CPS_CLIENT; cp_dst_ent <= st_ins_idx; cp_to_stash <= 1; cp_merge <= 1;  // old = zeros
                            cp_ret <= S_PM_UPD;
                            state  <= S_CP;
                        end
                    end else begin
                        // read of a never-written slot: zeros, but STILL remap it --
                        // otherwise two reads of the same slot touch the same bucket
                        res_zero <= 1'b1;
                        pm_wr_addr <= req_slot_addr; pm_wr_bucket <= req_b_new;
                        pm_wr_status <= `ST_DUMMY; pm_wr_pidx <= 0; pm_wr_en <= 1;
                        state <= S_EVICT;
                    end
                end
                S_CP: begin
                    if (cp_src == CPS_SCR && cp_rd_beat < BEATS) begin
                        scr_fsm_rd_addr <= scr_addr(cp_src_pos, cp_rd_beat[BEAT_W-1:0]);
                        scr_fsm_rd_en <= 1; cp_rd_beat <= cp_rd_beat + 1'b1;
                    end
                    if (cp_src == CPS_STASH && cp_rd_beat < BEATS) begin
                        st_drd_entry <= cp_src_ent; st_drd_beat <= cp_rd_beat[BEAT_W-1:0];
                        st_drd_en <= 1; cp_rd_beat <= cp_rd_beat + 1'b1;
                    end
                    if (cp_data_ok && cp_wr_beat < BEATS) begin
                        if (cp_to_stash) begin
                            st_dwr_entry <= cp_dst_ent; st_dwr_beat <= cp_wr_beat[BEAT_W-1:0];
                            st_dwr_data <= cp_data; st_dwr_en <= 1;
                        end
                        if (cp_to_scr) begin
                            scr_fsm_wr_addr <= scr_addr(cp_dst_pos, cp_wr_beat[BEAT_W-1:0]);
                            scr_fsm_wr_data <= cp_data; scr_fsm_wr_en <= 1;
                        end
                        if (cp_to_res) begin
                            res_wr_addr <= cp_wr_beat & (BEATS - 1); res_wr_data <= cp_data; res_wr_en <= 1;
                        end
                        cp_wr_beat <= cp_wr_beat + 1'b1;
                        if (cp_src == CPS_CLIENT || cp_merge) beat_cnt <= beat_cnt + 1;   // client beat = beat written
                    end
                    if (cp_wr_beat == BEATS) state <= cp_ret;
                end
                S_COMPACT: begin
                    cp_rd_beat <= 0; cp_wr_beat <= 0;
                    if ({1'b0, found_pos} != fill - 1'b1) begin
                        bkt_slot_list <= set_slot_at(bkt_slot_list, found_pos,
                                         slot_id_at(bkt_slot_list, fill[POS_W-1:0] - 1'b1));
                        cp_src <= CPS_SCR; cp_src_pos <= fill[POS_W-1:0] - 1'b1; cp_merge <= 0;
                        cp_to_stash <= 0; cp_to_res <= 0; cp_to_scr <= 1; cp_dst_pos <= found_pos;
                        cp_ret <= S_COMPACT2;
                        state  <= S_CP;
                    end else
                        state <= S_COMPACT2;
                end
                S_COMPACT2: begin
                    fill  <= fill - 1'b1;
                    state <= S_PM_UPD;
                end
                S_PM_UPD: begin
                    pm_wr_addr <= req_slot_addr; pm_wr_bucket <= req_b_new;
                    pm_wr_status <= `ST_IN_STASH; pm_wr_pidx <= req_pidx_cur; pm_wr_en <= 1;
                    state <= S_EVICT;
                end
                S_EVICT: begin
                    st_cam_bkt_target <= req_b; st_cam_bkt_en <= 1;
                    state <= S_EVICT_CHK;
                end
                S_EVICT_CHK: begin
                    cp_rd_beat <= 0; cp_wr_beat <= 0;
                    if (st_cam_bkt_inhibit_busy) begin
                        // the stash masks the entry it just evicted for one cycle:
                        // look again next cycle (stopping here limited eviction to
                        // one block per access -- audit fix)
                    end else if (fill < Z && st_cam_bkt_hit) begin
                        ev_ent <= st_cam_bkt_idx; ev_slot_addr <= st_cam_bkt_slot_addr;
                        // eviction overlap: queue the 128-beat copy; the background
                        // engine runs it while later decisions and encryption proceed
                        evq_ent[evq_wp[3:0]] <= st_cam_bkt_idx;
                        evq_pos[evq_wp[3:0]] <= fill[POS_W-1:0];
                        evq_wp <= evq_wp + 5'd1;
                        ev_pending[fill[POS_W-1:0]] <= 1'b1;
                        state <= S_EVICT_DONE;
                    end else begin
                        st_cam_bkt_en <= 0;
                        state <= S_EA_START;
                    end
                end
                S_EVICT_DONE: begin
                    bkt_slot_list <= set_slot_at(bkt_slot_list, fill[POS_W-1:0], ev_slot_addr[SLOT_W+11:12]);
                    fill <= fill + 1'b1;
                    st_evict_idx <= ev_ent; st_evict_en <= 1;
                    pm_wr_addr <= ev_slot_addr; pm_wr_bucket <= req_b;
                    pm_wr_status <= `ST_VALID; pm_wr_pidx <= 0; pm_wr_en <= 1;
                    state <= S_EVICT_WAIT;
                end
                S_EVICT_WAIT: state <= S_EVICT_CHK;
`ifdef ORAM_OVERLAP2
`ifdef ORAM_OVERLAP4
                S_EA_START: if (ov_err) state <= S_HALT; else begin
                    // T takes this access (write-back, release, result); E encrypts it (off package) or advances the IV
                    // (on package), in access order. The tail and the E queue must have room (fail-stop otherwise).
                    if (tst[mp] != T_IDLE || eq_n == NC) err_ct_overrun_r <= 1'b1;
                    tst[mp] <= T_WB; tp <= mp; t_ct[mp] <= ct_cnt + 32'd1; t_tarr[mp] <= t_arr; t_rel[mp] <= {1'b0, ct_cnt + 32'd1} - {1'b0, t_arr}; t_av[mp] <= arr_seen;
                    t_hbm[mp] <= acc_hbm; t_op[mp] <= req_op; t_rz[mp] <= res_zero; t_b[mp] <= req_b; t_byp_ov[mp] <= byp_ov;
                    t_wbp[mp] <= 1'b1; t_wbd[mp] <= 1'b0; epd[mp] <= 0; f_fwd[mp] <= 1'b0;
                    eq_ctx[eq_wp] <= mp; eq_hbm[eq_wp] <= BYP && acc_hbm; eq_b[eq_wp] <= req_b; eq_wp <= eq_wp + 2'd1;
                    m_pre_ea <= 1'b0; m_is_t <= 1'b1;
                    ov_d2 <= 1'b0; ov_rel <= 1'b0; ov_run2 <= 1'b0; ov_by2 <= 16'd0;
                    if (!(BYP && acc_hbm) && ct_cnt + 32'd1 > t_arr + AR_WB) err_ct_overrun_r <= 1'b1;
`ifdef ORAM_OVERLAP4
                    if (BYP && acc_hbm && arr_seen && ar_since > ar_max_wb_h) ar_max_wb_h <= ar_since;
`else
                    if (BYP && acc_hbm && arr_seen && ct_cnt - t_arr > ar_max_wb_h) ar_max_wb_h <= ct_cnt - t_arr;
`endif
                    st_commit <= 1;
                    bm_wr_bucket <= req_b; bm_wr_slot_list <= bkt_slot_list;
                    bm_wr_fill <= fill[FILL_W-1:0]; bm_wr_en <= 1;
                    m_has <= 1'b0; state <= S_IDLE;            // M is free; the eviction copies run on
                end
                S_OV_CPW: if (evq_rp == evq_wp && !ec_active) begin m_has <= 1'b0; state <= S_IDLE; end
`else
                S_EA_START: if (ov_err) state <= S_HALT; else begin
                    // T takes this access (its write-back, release and result); the tail must be free (C3)
                    if (tst[mp] != T_IDLE) err_ct_overrun_r <= 1'b1;
                    tst[mp] <= T_WB; tp <= mp; t_ct[mp] <= ct_cnt + 32'd1; t_tarr[mp] <= t_arr; t_rel[mp] <= {1'b0, ct_cnt + 32'd1} - {1'b0, t_arr}; t_av[mp] <= arr_seen;
                    t_hbm[mp] <= acc_hbm; t_op[mp] <= req_op; t_rz[mp] <= res_zero; t_b[mp] <= req_b; t_byp_ov[mp] <= byp_ov;
                    t_wbp[mp] <= 1'b1; t_wbd[mp] <= 1'b0;
                    m_pre_ea <= 1'b0; m_is_t <= 1'b1;
                    lw_b2 <= lw_b; lw_p2 <= lw_p; lw_v2 <= lw_v; lw_b <= req_b; lw_p <= 1'b1; lw_v <= 1'b1; lw_u <= mp;
                    enc_pos_done <= 0;
                    ov_d2 <= 1'b0; ov_rel <= 1'b0; ov_run2 <= 1'b0; ov_by2 <= 16'd0;
                    // the off-package write budget already passed: the write would be late (overrun, as a stall was)
                    if (!(BYP && acc_hbm) && ct_cnt + 32'd1 > t_arr + AR_WB) err_ct_overrun_r <= 1'b1;
                    st_commit <= 1;
                    bm_wr_bucket <= req_b; bm_wr_slot_list <= bkt_slot_list;
                    bm_wr_fill <= fill[FILL_W-1:0]; bm_wr_en <= 1;
                    cr_mode <= CR_EA; cr_pos <= 0; cr_zero <= 1'b0;
                    if (BYP && acc_hbm) begin                   // the write issues once the engine is free (w_issue)
                        gcm_iv_reg <= aes_iv_seed; gcm_iv_adv <= 1'b1;
`ifdef ORAM_OVERLAP4
                        if (arr_seen && ar_since > ar_max_wb_h) ar_max_wb_h <= ar_since;
`else
                        if (arr_seen && ct_cnt - t_arr > ar_max_wb_h) ar_max_wb_h <= ct_cnt - t_arr;
`endif
                        state <= S_OV_CPW;
                    end else
                        state <= S_CR_IV;
                end
                S_OV_CPW: if (evq_rp == evq_wp && !ec_active) begin m_has <= 1'b0; state <= S_IDLE; end
`endif
`else
                S_EA_START: begin
                    st_commit <= 1;                     // the stash's lists and written blocks back to HBM
                    bm_wr_bucket <= req_b; bm_wr_slot_list <= bkt_slot_list;
                    bm_wr_fill <= fill[FILL_W-1:0]; bm_wr_en <= 1;
                    cr_mode <= CR_EA; cr_pos <= 0; cr_zero <= 1'b0;
`ifdef ORAM_NOCRYPTO
                    // every decision is made; the write gate issues the plaintext write at t_arr + WBF (host or HBM)
                    state <= S_DDR_WRITE;
`else
                    if (BYP && acc_hbm) begin
                        // v14, on package: every decision is made; write the plaintext bucket back now, streaming
                        // behind the eviction copies (enc_pos_done, above). No re-encryption: the IV advances as the
                        // encryption would have (a register update in the core), and the record keeps no IV/tag.
`ifndef ORAM_ONPKG_FIXWB
                        axim_cmd_bucket <= req_b; axim_cmd_write <= 1'b1;
                        wb_pending <= 1'b0; wb_active <= 1'b1;
`endif
                        // (Option A: the write gate issues it at t_arr + AR_WBF_H)
                        gcm_iv_reg <= aes_iv_seed; gcm_iv_adv <= 1'b1;
`ifdef ORAM_OVERLAP4
                        if (arr_seen && ar_since > ar_max_wb_h) ar_max_wb_h <= ar_since;   // calibrates AR_WB_H
`else
                        if (arr_seen && ct_cnt - t_arr > ar_max_wb_h) ar_max_wb_h <= ct_cnt - t_arr;   // calibrates AR_WB_H
`endif
                        state <= S_DDR_WRITE;
                    end else
                        state <= S_CR_IV;
`endif
                end
`endif
`ifdef ORAM_OVERLAP2
                // never entered in the overlap builds: T does the write-back hand-off, release and result
                S_WB_GATE, S_DDR_WRITE, S_DONE_GATE, S_RES_STREAM: state <= S_HALT;
`else
                S_WB_GATE: begin                    // calibration builds only (CT_WB == 0):
                    axim_cmd_bucket <= req_b;       // write back after encryption ends
                    axim_cmd_write <= 1;
                    wb_pending <= 1'b0; wb_active <= 1'b1;
                    state <= S_DDR_WRITE;
                end
                S_DDR_WRITE: begin                  // write-back issued at CT_WB (streaming)
                    // complete only once every write-back burst is acknowledged: AXI does not order a
                    // later read against an unacknowledged write, so the next access could read stale
                    // ciphertext. A slow acknowledgement is a late arrival at the done gate (overrun).
                    // done only when the bucket's, the position map's, the record's and the stash's writes are acknowledged
                    // arrival mode: once the write-back data is handed off; the acknowledgements drain during the
                    // next access's lookup (every later read is ordered after them, see oram_params.vh AR_REL)
                    if ((wb_done_seen || axim_write_done) &&
                        ((AR_MODE && cr_mode != CR_FMT) || (axim_wr_quiet && pm_wr_quiet && br_wr_quiet && st_wr_quiet))) begin
                        // v14, on package: the release gate is reached this many cycles after the arrival (calibrates AR_REL_H)
`ifdef ORAM_OVERLAP4
                        if (byp_acc && arr_seen && ar_since1 > ar_max_rel_h) ar_max_rel_h <= ar_since1;
`else
                        if (byp_acc && arr_seen && ct_cnt + 32'd1 - t_arr > ar_max_rel_h) ar_max_rel_h <= ct_cnt + 32'd1 - t_arr;
`endif
                        state <= S_DONE_GATE;
                    end
                end
                S_DONE_GATE: begin : done_gate
`ifdef ORAM_NOCRYPTO
                    reg [31:0] dn; dn = (AR_MODE && cr_mode != CR_FMT) ? t_arr + nc_rel : CT_DONE;
`else
                    reg [31:0] dn; dn = (AR_MODE && cr_mode != CR_FMT) ? t_arr + (acc_hbm ? AR_REL_H : AR_REL) : CT_DONE;
`endif
                    if (CT_DONE == 0 || ct_cnt >= dn) begin
                        if (ct_cnt > ct_max_done) ct_max_done <= ct_cnt;
                        // (debug build: an on-package access arriving late was counted as a deadline (2) miss)
                        if (CT_DONE != 0 && ct_cnt > dn && (ONPKG_HALT || !byp_acc)) err_ct_overrun_r <= 1'b1;
                        res_beat <= 0; res_out_beat <= 0; res_pipe <= 2'b00;
                        state <= S_RES_STREAM;
                    end
                end
                S_RES_STREAM: begin
                    res_pipe <= {res_pipe[0], (res_beat < BEATS)};
                    if (res_beat < BEATS) begin
                        res_rd_addr <= res_beat & (BEATS - 1); res_beat <= res_beat + 1'b1;
                    end
                    if (res_pipe[1]) begin
                        if (req_op == 1'b0) begin
                            client_rdata       <= res_zero ? {AXI_DW{1'b0}} : res_rd_data;
                            client_rdata_beat  <= res_out_beat[BEAT_W-1:0];
                            client_rdata_valid <= 1;
                        end
                        res_out_beat <= res_out_beat + 1'b1;
                    end
                    if (res_out_beat == BEATS) begin
                        client_done  <= 1'b1;
                        client_stall <= 0;
                        acc_commit   <= 1'b1;
                        state <= S_IDLE;
                    end
                end
`endif
                S_FMT_START: if (br_wr_ready) begin
                    st_init_go <= 1;                    // boot has started: the stash zeroes its lists in HBM
                    req_b <= fmt_b[BUCKET_W-1:0];
                    // the bucket's metadata starts empty: the layout fills only the buckets it draws
                    bm_wr_bucket <= fmt_b[BUCKET_W-1:0]; bm_wr_slot_list <= {(Z*SLOT_W){1'b0}};
                    bm_wr_fill <= {FILL_W{1'b0}}; bm_wr_en <= 1;
                    cr_mode <= CR_FMT; cr_pos <= 0; cr_zero <= 1'b1;
`ifdef ORAM_NOCRYPTO
                    fmt_zero <= 1'b1;                   // every bucket in plaintext: zeros written straight to it
                    state <= S_FMT_WRITE;
`else
                    if (BYP && fmt_b < cfg_hbm_bkts) begin
                        // v14: an on-package bucket is formatted in plaintext: zeros written straight to it (fmt_zero),
                        // the IV advanced as its encryption would have, no IV/tag in its record
                        fmt_zero <= 1'b1; gcm_iv_reg <= aes_iv_seed; gcm_iv_adv <= 1'b1;
                        state <= S_FMT_WRITE;
                    end else begin
                        fmt_zero <= 1'b0;
                        state <= S_CR_IV;
                    end
`endif
                end
                S_FMT_WRITE: begin
                    axim_cmd_bucket <= fmt_b[BUCKET_W-1:0]; axim_cmd_write <= 1;
`ifdef ORAM_NOCRYPTO
                    wb_done_seen <= 1'b0;
`endif
                    state <= S_FMT_WAIT;
                end
                S_FMT_WAIT: begin
`ifdef ORAM_NOCRYPTO
                    // each bucket's write acknowledged before the next. With no encryption between them, the last HBM
                    // bucket's write is followed at once by the first host bucket's, and the kernel's bucket-port switch
                    // routes B by the latest AW (doma_kernel.v): that response would be lost and the boot would never be quiet.
                    if ((wb_done_seen || axim_write_done) && axim_wr_quiet) begin
`else
                    if (axim_write_done) begin
`endif
                        fmt_zero <= 1'b0;                     // v14: this bucket's (zero) write is done
                        if (fmt_b == nb_q - 1) begin          // the run-time number of buckets
                            lay_p <= 0; lay_i <= 0; lay_ph <= 0; state <= S_LAYOUT;
                            lay_cyc <= 0; lay_run <= 1'b1; lay_due <= 1'b0; lay_t0 <= 0;   // the boot budget starts
                        end
                        else begin fmt_b <= fmt_b + 1'b1; state <= S_FMT_START; end
                    end
                end
                S_LAYOUT: begin
                    // One slot at a time (lay_i of partition lay_p): draw its bucket, read the bucket's record, and
                    // either append the slot (fill < Z) or insert it into the stash with that target (the bucket is
                    // full). Its data is the formatted (encrypted) zeros in the bucket, or a zero block in the pool.
                    case (lay_ph)
                    3'd0: if (pm_wr_ready && br_wr_ready) begin   // draw (the generator's next value is waiting)
                        lay_b <= lay_bbase | (prng_bucket & BL_MASK); rng_take <= 1;
                        bm_rd_bucket <= lay_bbase | (prng_bucket & BL_MASK); bm_rd_en <= 1;
                        lay_ph <= 3'd1; lay_st <= 1'b0;
                    end
                    // bm_rd_valid comes with the record's first beat (slot list, fill); its IV/tag beat may still be
                    // arriving, and writing the record then is a fail-stop in the record unit (the card's HBM returns
                    // the two beats with a gap; v11b/v11c halted here). Take the first beat, then wait for the rest.
                    3'd1: if (bm_rd_valid) lay_ph <= 3'd7;
                    3'd7: if (!br_rd_busy) begin                   // the whole record is in (reads wait for writes)
                        if (bm_rd_fill < Z) begin
                            bm_wr_bucket <= lay_b; bm_wr_slot_list <= set_slot_at(bm_rd_slot_list, bm_rd_fill[POS_W-1:0], lay_slot);
                            bm_wr_fill <= bm_rd_fill + 1'b1; bm_wr_en <= 1;
                            pm_wr_addr <= lay_slot_addr; pm_wr_bucket <= lay_b;
                            pm_wr_status <= `ST_VALID; pm_wr_pidx <= 0; pm_wr_en <= 1;
                            lay_ph <= 3'd6;
                        end else begin
                            lay_ph <= 3'd2; lay_st <= 1'b1;        // full: the slot waits in the stash
                        end
                    end
                    3'd2: if (st_init_done && st_wr_quiet) begin   // open the target's lists
                        st_open_b <= lay_b; st_open_bt <= lay_b; st_open_slot <= lay_slot_addr;
                        st_open_instash <= 1'b0; st_open_pidx <= 0; st_open_en <= 1;
                        lay_ph <= 3'd3;
                    end
                    3'd3: if (st_ready) begin
                        if (st_ins_full) begin                     // the pool cannot hold the initial excess
                            err_stash_overflow <= 1'b1; client_stall <= 1; state <= S_HALT;
                        end else begin
                            st_ins_slot <= lay_slot_addr; st_ins_tgt <= lay_b; st_ins_en <= 1;
                            lay_ent <= st_ins_idx; lay_beat <= 0;
                            lay_ph <= 3'd4;
                        end
                    end
                    3'd4: begin                                    // its pool block: zeros, one beat per cycle
                        st_dwr_entry <= lay_ent; st_dwr_beat <= lay_beat[BEAT_W-1:0];
                        st_dwr_data <= {AXI_DW{1'b0}}; st_dwr_en <= 1;
                        lay_beat <= lay_beat + 1'b1;
                        if (lay_beat == BEATS - 1) lay_ph <= 3'd5;
                    end
                    3'd5: if (pm_wr_ready) begin                   // write the lists and the block back
                        st_commit <= 1;
                        pm_wr_addr <= lay_slot_addr; pm_wr_bucket <= lay_b;
                        pm_wr_status <= `ST_IN_STASH; pm_wr_pidx <= req_pidx_cur; pm_wr_en <= 1;
                        lay_ph <= 3'd6;
                    end
                    default: begin                                 // next slot, partition, or done
                        lay_ph <= 3'd0;
                        // measurement: this slot's placement took lay_cyc - lay_t0 + 1 cycles, from the cycle after its
                        // predecessor's (so its cost includes waiting for the predecessors' writes); the next starts next
                        lay_t0 <= lay_cyc + 40'd1;
                        if (lay_st) begin
                            lay_nst <= lay_nst + 1'b1;
                            if (lay_cyc - lay_t0 + 40'd1 > {24'd0, lay_max_s}) lay_max_s <= lay_cyc[15:0] - lay_t0[15:0] + 16'd1;
                        end else if (lay_cyc - lay_t0 + 40'd1 > {24'd0, lay_max_b}) lay_max_b <= lay_cyc[15:0] - lay_t0[15:0] + 16'd1;
                        if (lay_i == n_part - 1) begin
                            if (lay_p == NP - 1) begin boot_drain <= 1'b1; state <= S_IDLE; lay_end <= lay_cyc; end
                            else begin lay_p <= lay_p + 1'b1; lay_i <= 0; end
                        end else
                            lay_i <= lay_i + 1'b1;
                    end
                    endcase
                end
                S_HALT: begin
                    client_stall <= 1;
                end
                default: state <= S_HALT;
            endcase
`ifdef ORAM_OVERLAP2
`ifdef ORAM_OVERLAP4
            // ================= F: accept, lookup (forwarded), read gate =================
            case (fst)
`ifdef ORAM_OV4_P3
                // phase 3: s = max(request, previous s + OV_PMIN, t' of the context's previous access + OV_L, and the
                // read issue of any later access waiting on that access's bucket: its same-bucket gate needs it)
                F_IDLE: if (client_req && fmt_done_r && !ov_err && state != S_HALT &&
                            (!s_any || s_since >= OV_PMIN) && cf_ok[an] && !eq_hold[an]) begin
`else
                F_IDLE: if (client_req && fmt_done_r && !ov_err && state != S_HALT &&
                            (!s_any || s_since >= s_need)) begin
`endif
                    // s = max(request presented, previous s + P (+ D_EQ)), nothing else. The context four back must be
                    // finished: taken by M, its tail done, its write-back acknowledged (fail-stop otherwise).
                    if (f_has[an] || tst[an] != T_IDLE || !wdone[an] ||
                        (m_has && mp == an)) err_ct_overrun_r <= 1'b1;
                    else begin : f_acc
                        reg [1:0] n; n = f_par + 2'd1;
                        client_acc <= 1'b1; s_any <= 1'b1; s_since <= 16'd0; s_need <= OV_P;
                        f_slot[n] <= client_slot_addr; f_part[n] <= in_part; f_op[n] <= client_op;
                        f_ct[n] <= 32'd0; f_has[n] <= 1'b1; f_looked[n] <= 1'b0; f_par <= n;
                        f_landed[n] <= 0; f_arr[n] <= 1'b0; f_bmseen[n] <= 1'b0; f_rdiss[n] <= 1'b0; f_eqa[n] <= 1'b0;
                        f_fwd[n] <= 1'b1; wdone[n] <= 1'b0; t_wbd[n] <= 1'b0; f_pmc[n] <= 1'b0; f_fwv[n] <= a_fwv; f_fwb[n] <= a_fwb;
                        fl_fwv <= a_fwv; fl_fwb <= a_fwb; fl_slot <= client_slot_addr; fl_part <= in_part; fl_rnd <= prng_bucket;
                        fl_ct <= 32'd0; fl_g0 <= (32'd0 >= OV_CT_RD); fl_g1 <= (32'd0 >= OV_CT_RD + OV_DEQ); fl_g2 <= (32'd1 > OV_CT_RD); fl_eqa <= 1'b0;
                        f_g0[n] <= (32'd0 >= OV_CT_RD); f_g1[n] <= (32'd0 >= OV_CT_RD + OV_DEQ); rp[n] <= 1'b0;
`ifdef ORAM_OV4_P3
                        cf_wait[n] <= 1'b1; ea_arr[n] <= 1'b0; f_eqok[n] <= 1'b0;
`endif
                        if (s_any && s_prev != 2'd3) s_prev <= s_prev + 2'd1;
                        pm_rd_addr <= client_slot_addr; pm_rd_en <= 1;
                        f_rnd[n] <= prng_bucket; rng_take <= 1;
                        fst <= F_LOOK;
                    end
                end
                F_LOOK: if (pm_rd_valid) begin : f_look
                    reg [1:0] n; reg [BUCKET_W-1:0] b; reg [NC-1:0] m; reg e1, e2, e3; integer q;
                    n = f_par; b = f_lk_b;                         // forwarded read address (D2)
                    f_b[n] <= b; f_hbm[n] <= ({1'b0, b} < cfg_hbm_bkts);
                    fl_b <= b; fl_b1 <= b; fl_b2 <= fl_b1; fl_b3 <= fl_b2;
                    // status and pool index as looked up, unless a later write already corrected them (ov4_corr)
                    if (!f_pmc[n] && !(pm_wr_en && pm_wr_addr == fl_slot)) begin
                        f_instash[n] <= (pm_rd_status == `ST_IN_STASH); f_pidx[n] <= pm_rd_pidx;
                    end
                    f_bnew[n] <= dbg_force_same_bucket ? b : f_bnew_part;
                    f_same[n] <= dbg_force_same_bucket ? 1'b1 : (f_bnew_part == b);
                    // D1: the same bucket as one of the three previous accesses: decided by bucket equality alone
                    // (public), a fixed shift; each of those writes must be acknowledged by the shifted gate (C4)
                    m = 0;
                    e1 = (s_prev >= 2'd1) && (fl_b1 == b); e2 = (s_prev >= 2'd2) && (fl_b2 == b); e3 = (s_prev >= 2'd3) && (fl_b3 == b);
                    for (q = 0; q < NC; q = q + 1)   // (the three earlier contexts are distinct)
                        m[q] = (e1 && fp_m1 == q[1:0]) || (e2 && fp_m2 == q[1:0]) || (e3 && fp_m3 == q[1:0]);
                    f_eqm <= m; f_eqmk[n] <= m; f_eqa[n] <= (e1 || e2 || e3); fl_eqa <= (e1 || e2 || e3);
                    rp[n] <= 1'b1;                                 // its read is now the issuer's (R2)
`ifdef ORAM_OV4_P3
                    if (e1 || e2 || e3) begin end                  // phase 3: no shift of the next start
`else
                    if (e1 || e2 || e3) s_need <= OV_P + OV_DEQ;
`endif
                    // the bucket record: now, unless an earlier access with this bucket may still write it (then at
                    // the shifted gate, once those writes are acknowledged; bucket_rec_hbm must never see a write
                    // into a record it is fetching)
                    else begin fr_pend <= 1'b1; fr_b <= b; fr_ctx <= n; end   // through the record arbiter (R3)
                    if (fl_ct + 1 > ct_max_rd) ct_max_rd <= fl_ct + 1;
                    if (fl_g2) err_ct_overrun_r <= 1'b1;              // the lookup took longer than OV_CT_RD
                    f_looked[n] <= 1'b1;
                    fst <= F_GATE;
                end
                // the read is issued by the read issuer below (R2); F is free for the next access
                F_GATE: fst <= F_IDLE;
                default: fst <= F_IDLE;
            endcase
            // ================= R2: the read issuer (bucket reads in access order) =================
            // Access q's read is due at its gate, f_ct[q] >= OV_CT_RD (+ OV_DEQ if its bucket equals one of the three
            // earlier accesses' buckets: public). It is issued at the gate, or later only while both read copies are
            // busy (earlier reads still arriving: a wait on memory latency alone). At issue its buffers must be free
            // (the write-back four back has ended) and every earlier write to its bucket acknowledged (C4): else
            // fail-stop, never a wait (those depend on the stash). The cycle after an issue never issues (the read
            // unit sees its command then).
            begin : r_issue
                reg [1:0] q; reg gate, bad; integer k;
                q = ri_next;
`ifdef ORAM_OV4_P3
`ifdef TB_OV_LEAK
                gate = (f_ct[q] >= OV_CT_RD + (f_op[q] ? 1 : 0)) && (!f_eqa[q] || f_eqok[q]);  // TEST ONLY: a PUT's read late
`else
                gate = f_g0[q] && (!f_eqa[q] || f_eqok[q]);   // phase 3: s + CT_RD, and t'(e) + OV_LEQ for each e
`endif
`else
`ifdef TB_OV_LEAK
                gate = (f_ct[q] >= OV_CT_RD + (f_eqa[q] ? OV_DEQ : 0) + (f_op[q] ? 1 : 0));   // TEST ONLY: a PUT's read late
`else
                gate = f_eqa[q] ? f_g1[q] : f_g0[q];
`endif
`endif
                if (rp[q] && gate) begin
                    bad = (wb_active && w_par == q) || t_wbp[q];
                    for (k = 0; k < NC; k = k + 1) if (f_eqmk[q][k] && !wdone[k]) bad = 1'b1;
                    if (bad) err_ct_overrun_r <= 1'b1;
                    else if (ra_free && !axir_cmd_read) begin
                        axir_cmd_bucket <= f_b[q]; axir_cmd_read <= 1'b1; axir_cmd_ctx <= q;
                        rp[q] <= 1'b0; f_rdiss[q] <= 1'b1; ri_next <= q + 2'd1;
                        if (f_eqa[q]) begin rr_pend <= 1'b1; rr_b <= f_b[q]; rr_ctx <= q; end   // its record, now
                    end
                end
            end
            // ================= R3: the record reads, one at a time =================
            if (bm_rd_valid) rec_out <= 1'b0;
            if (fmt_done_r && !rec_out && !br_rd_busy && !bm_rd_en) begin
                if (rr_pend) begin bm_rd_bucket <= rr_b; bm_rd_en <= 1; b_ctx <= rr_ctx; rr_pend <= 1'b0; rec_out <= 1'b1; end
                else if (fr_pend) begin bm_rd_bucket <= fr_b; bm_rd_en <= 1; b_ctx <= fr_ctx; fr_pend <= 1'b0; rec_out <= 1'b1; end
            end
            // ================= T (four units, by context): hand-off, release gate, result =================
            begin : t_units
                integer u; reg [31:0] dn;
                for (u = 0; u < NC; u = u + 1) begin
                    case (tst[u])
                        T_WB: if (t_wbd[u]) begin
                            if (BYP && t_hbm[u] && t_av[u] && t_rel[u][31:0] > ar_max_rel_h) ar_max_rel_h <= t_rel[u][31:0];
                            tst[u] <= T_GATE;
                        end
                        T_GATE: begin
                            if (t_gok[u]) begin
                                if (t_ct[u] > ct_max_done) ct_max_done <= t_ct[u];
                                if (t_glate[u] && (ONPKG_HALT || !(BYP && t_hbm[u]))) err_ct_overrun_r <= 1'b1;
                                // results leave in access order, one at a time (fail-stop otherwise)
                                if (u[1:0] != r_next || res_busy) err_ct_overrun_r <= 1'b1;
                                res_beat <= 0; res_out_beat <= 0; res_pipe <= 2'b00; rs_par <= u[1:0]; r_next <= u[1:0] + 2'd1;
                                tst[u] <= T_RES;
                            end
                        end
                        T_RES: begin
                            res_pipe <= {res_pipe[0], (res_beat < BEATS)};
                            if (res_beat < BEATS) begin
                                res_rd_addr <= res_beat & (BEATS - 1); res_beat <= res_beat + 1'b1;
                            end
                            if (res_pipe[1]) begin
                                if (t_op[u] == 1'b0) begin
                                    client_rdata       <= t_rz[u] ? {AXI_DW{1'b0}} : res_rd_data;
                                    client_rdata_beat  <= res_out_beat[BEAT_W-1:0];
                                    client_rdata_valid <= 1;
                                end
                                res_out_beat <= res_out_beat + 1'b1;
                            end
                            if (res_out_beat == BEATS) begin
                                client_done <= 1'b1; acc_commit <= 1'b1;
                                tst[u] <= T_IDLE;
                            end
                        end
                        default: ;
                    endcase
                end
            end
            // ================= E: encryption (off package) or IV advance (on package), in access order ==========
            // the crypto data path of S_CR_* (encryption), on core E and E's scratch ports
            e_fd_v <= {e_fd_v[1:0], 1'b0}; e_fd_last <= {e_fd_last[1:0], 1'b0};
            e_gcm_data_in <= e_rd_data;
            if (e_fd_v[2]) begin e_gcm_data_valid <= 1'b1; e_gcm_data_last <= e_fd_last[2]; end
            if (e_gcm_data_out_valid) e_oq_wp <= e_oq_wp + 1'b1;
            e_wr_addr <= e_wr_lin[`SCR_AW-1:0]; e_wr_data <= e_oq_hd;
            if (e_oq_n != 0) begin e_wr_en <= 1'b1; e_oq_rp <= e_oq_rp + 1'b1; e_wr_lin <= e_wr_lin + 11'd1; e_wr_lim <= e_wr_lim + 11'd1; end
            e_oq_n <= e_oq_n + (e_gcm_data_out_valid ? 1'b1 : 1'b0) - ((e_oq_n != 0) ? 1'b1 : 1'b0);
            if (e_gcm_tag_valid) begin e_tag_seen <= 1'b1; e_tag_q <= e_gcm_tag_out; e_iv_q <= e_gcm_iv_out; end
            if (est == E_FEED || est == E_RECV) if ((e_wr_lin >> BEAT_AW) < Z) epd[ej] <= e_wr_lin >> BEAT_AW;
            case (est)
                E_IDLE: if (eq_n != 0 && fmt_done_r) begin
                    ej <= eq_ctx[eq_rp]; e_b <= eq_b[eq_rp]; eq_rp <= eq_rp + 2'd1;
                    if (eq_hbm[eq_rp]) begin                    // on package: advance the IV as an encryption would
                        e_gcm_iv_reg <= aes_iv_seed; e_gcm_iv_adv <= 1'b1; est <= E_ADV;
                    end else begin
                        e_act <= 1'b1; est <= E_IV;
                    end
                end
                E_ADV: begin                                    // the advance lands over the next cycles
                    e_wait <= e_wait + 2'd1;
                    if (e_wait == 2'd3 && e_gcm_ready) begin e_wait <= 2'd0; est <= E_IDLE; end
                    else if (e_wait == 2'd3) e_wait <= 2'd3;
                end
                E_IV: begin
                    e_beat <= 0; e_cr_pos <= 0; e_rd_lin <= 0; e_rd_base <= 0; e_wr_lin <= 0; e_wr_lim <= OQ_D; e_tag_seen <= 1'b0;
                    if (!e_evp[0]) begin e_gcm_iv_reg <= aes_iv_seed; e_gcm_start <= 1'b1; est <= E_START; end
                end
                E_START: if (e_gcm_input_ready) est <= E_FEED;
                E_FEED: begin
                    // a position starts once its eviction copy is done and the previous one is written back
                    if (e_gcm_input_ready && (e_rd_lin < e_wr_lim) &&
                        (e_beat != 0 || (!e_evp[e_cr_pos[POS_W-1:0]] && e_wr_lin >= e_rd_base))) begin
                        e_rd_addr <= scr_addr(e_cr_pos[POS_W-1:0], e_beat); e_rd_en <= 1'b1;
                        e_fd_v[0] <= 1'b1; e_fd_last[0] <= (e_beat == BEATS - 1) && (e_cr_pos == Z - 1);
                        e_rd_lin <= e_rd_lin + 11'd1;
                        if (e_beat != BEATS - 1) e_beat <= e_beat + 1'b1;
                        else begin
                            e_beat <= 0;
                            if (e_cr_pos == Z - 1) est <= E_RECV;
                            else begin e_cr_pos <= e_cr_pos + 1'b1; e_rd_base <= e_rd_base + BEATS; end
                        end
                    end
                end
                E_RECV: if (e_wr_lin == TOTAL_BEATS) est <= E_TAG;
                E_TAG: if (e_tag_seen && state != S_EA_START) begin   // (never in the cycle M writes a record)
                    ivt_wr_addr <= ivt_addr(e_b, {POS_W{1'b0}}); ivt_wr_iv <= e_iv_q; ivt_wr_tag <= e_tag_q; ivt_wr_en <= 1;
                    epd[ej] <= ZP4;
                    if (t_ct[ej] > ct_max_wb) ct_max_wb <= t_ct[ej];
                    if (t_av[ej] && t_rel[ej][31:0] > ar_max_wb) ar_max_wb <= t_rel[ej][31:0];
                    e_act <= 1'b0; est <= E_IDLE;
                end
                default: est <= E_IDLE;
            endcase
            eq_n <= eq_n + ((state == S_EA_START && !ov_err) ? 3'd1 : 3'd0) - ((est == E_IDLE && eq_n != 0 && fmt_done_r) ? 3'd1 : 3'd0);
            // busy while any access is in flight (or the controller is not ready / halted)
            client_stall <= !fmt_done_r || state == S_HALT || ov_err || fst != F_IDLE || m_has || (|t_busy) || est != E_IDLE ||
                            f_has[0] || f_has[1] || f_has[2] || f_has[3];
`else
            // ================= F: accept, lookup, read gate =================
            case (fst)
                F_IDLE: if (client_req && fmt_done_r && !ov_err && state != S_HALT &&
                            (!s_any || s_since >= s_need)) begin
                    // s = max(request presented, previous s + P), and nothing else: the start never waits on internal
                    // progress. C1: the previous access's decisions are done; C3: M has taken the previous access
                    // (F is free); the previous read has completed. Any of them false: fail-stop, never a wait.
                    if (f_has || (m_has && m_pre_ea) || axir_busy) err_ct_overrun_r <= 1'b1;
                    else begin
                    client_acc <= 1'b1; s_any <= 1'b1; s_since <= 16'd0; s_need <= OV_P;
                    f_slot <= client_slot_addr; f_part <= in_part; f_op <= client_op;
                    f_ct <= 32'd0; f_has <= 1'b1; f_looked <= 1'b0; f_par <= ~f_par;
                    f_landed <= 0; f_arr <= 1'b0; rd_own_m <= 1'b0;
                    pm_rd_addr <= client_slot_addr; pm_rd_en <= 1;
                    f_rnd <= prng_bucket; rng_take <= 1;
                    fst <= F_LOOK;
                    end
                end
                F_LOOK: if (pm_rd_valid) begin
                    f_b <= pm_rd_bucket; f_hbm <= ({1'b0, pm_rd_bucket} < cfg_hbm_bkts);
                    bm_rd_bucket <= pm_rd_bucket; bm_rd_en <= 1; bm_seen <= 1'b0;
                    f_instash <= (pm_rd_status == `ST_IN_STASH); f_pidx <= pm_rd_pidx;
                    f_bnew <= dbg_force_same_bucket ? pm_rd_bucket : f_bnew_part;
                    f_same <= dbg_force_same_bucket ? 1'b1 : (f_bnew_part == pm_rd_bucket);
                    // D1: the same bucket as the previous access. Decided by bucket equality ALONE (public: both
                    // addresses are on the bus), never by whether that write has been acknowledged yet (its timing
                    // can depend on the stash). The shift is fixed; the write must be acknowledged by the shifted gate
                    // (C4, fail-stop). The bucket of the access before that is checked at the gate (fail-stop) only.
                    f_eqm1 <= lw_v && (pm_rd_bucket == lw_b); f_eqm2 <= lw_v2 && (pm_rd_bucket == lw_b2);
                    f_eq <= lw_v && (pm_rd_bucket == lw_b);
                    if (lw_v && pm_rd_bucket == lw_b) s_need <= OV_P + OV_DEQ;
                    if (f_ct + 1 > ct_max_rd) ct_max_rd <= f_ct + 1;
                    if (CT_RD != 0 && f_ct + 1 > CT_RD) err_ct_overrun_r <= 1'b1;
                    f_looked <= 1'b1;
                    fst <= F_GATE;
                end
`ifdef TB_OV_LEAK
                // TEST ONLY (injected leak): a PUT's read gate one cycle late. The paired-stream check must catch it.
                F_GATE: if (CT_RD == 0 || f_ct >= CT_RD + (f_eq ? OV_DEQ : 0) + (f_op ? 1 : 0)) begin
`else
                F_GATE: if (CT_RD == 0 || f_ct >= CT_RD + (f_eq ? OV_DEQ : 0)) begin
`endif
                    // C4: a same-bucket write-back must be acknowledged by now (else fail-stop, never a wait)
                    // ... and the buffers of this parity are free: the write-back of the access two back has ended
                    if ((f_eqm1 && lw_p) || (f_eqm2 && lw_p2) || axir_busy || (wb_active && w_par == f_par)) err_ct_overrun_r <= 1'b1;
                    else begin axir_cmd_bucket <= f_b; axir_cmd_read <= 1'b1; r_par <= f_par; end
                    fst <= F_IDLE;
                end
                default: fst <= F_IDLE;
            endcase
            // ================= T (two units, by access parity): hand-off, release gate, result =================
            begin : t_units
                integer u; reg [31:0] dn;
                for (u = 0; u < 2; u = u + 1) begin
                    case (tst[u])
                        T_WB: if (t_wbd[u]) begin                 // the write-back data handed off
                            if (BYP && t_hbm[u] && t_av[u] && t_rel[u][31:0] > ar_max_rel_h) ar_max_rel_h <= t_rel[u][31:0];
                            tst[u] <= T_GATE;
                        end
                        T_GATE: begin
                            if (t_gok[u]) begin
                                if (t_ct[u] > ct_max_done) ct_max_done <= t_ct[u];
                                if (t_glate[u] && (ONPKG_HALT || !(BYP && t_hbm[u]))) err_ct_overrun_r <= 1'b1;
                                // results leave in access order, one at a time (fail-stop otherwise; never happens
                                // while accesses are spaced by P)
                                if (u[0] != r_next || tst[~u[0]] == T_RES) err_ct_overrun_r <= 1'b1;
                                res_beat <= 0; res_out_beat <= 0; res_pipe <= 2'b00; rs_par <= u[0]; r_next <= ~u[0];
                                tst[u] <= T_RES;
                            end
                        end
                        T_RES: begin
                            res_pipe <= {res_pipe[0], (res_beat < BEATS)};
                            if (res_beat < BEATS) begin
                                res_rd_addr <= res_beat & (BEATS - 1); res_beat <= res_beat + 1'b1;
                            end
                            if (res_pipe[1]) begin
                                if (t_op[u] == 1'b0) begin
                                    client_rdata       <= t_rz[u] ? {AXI_DW{1'b0}} : res_rd_data;
                                    client_rdata_beat  <= res_out_beat[BEAT_W-1:0];
                                    client_rdata_valid <= 1;
                                end
                                res_out_beat <= res_out_beat + 1'b1;
                            end
                            if (res_out_beat == BEATS) begin
                                client_done <= 1'b1; acc_commit <= 1'b1;
                                tst[u] <= T_IDLE;
                            end
                        end
                        default: ;
                    endcase
                end
            end
            // busy while any access is in flight (or the controller is not ready / halted)
            client_stall <= !fmt_done_r || state == S_HALT || ov_err || f_has || fst != F_IDLE || m_has || t_busy0 || t_busy1;
`endif
`endif

            // the boot budget has elapsed: everything placed and landed, or a timing overrun (fail-stop). This
            // overrides the state machine's choice in this cycle (the layout cannot run past its budget). A boot
            // that already halted (the pool cannot hold the initial excess) keeps its own error.
            if (lay_run && !lay_due && lay_cyc == lay_budget && state != S_HALT) begin
                if (boot_drain && boot_quiet) lay_due <= 1'b1;
                else begin err_ct_overrun_r <= 1'b1; client_stall <= 1; lay_run <= 1'b0; state <= S_HALT; end
            end
        end
    end
`ifdef ORAM_NOCRYPTO
    // Per access, the earliest write-back time that would have served it hold-free (nc_need, as ct_cnt):
    //   - the decisions done: the gate may fire in the cycle S_EA_START is reached;
    //   - every eviction copy in time: the master asks for position p's first beat p * BEATS cycles after its first
    //     beat, two cycles after the gate fires; the copy's last write sets ev_pending[p] low one cycle later and
    //     enc_pos_done another cycle later, so a copy finishing in cycle Y (ec_wr_beat == BEATS) needs the gate at
    //     Y - p * BEATS or later. The regression checks this boundary (run_nocrypto.sh: WBF = worst need runs hold-free,
    //     WBF = worst need - 1 does not).
    wire [31:0] nc_land = ct_cnt - ({28'd0, 1'b0, ec_pos} << $clog2(BEATS));
    wire [31:0] nc_need_c = (ec_active && ec_wr_beat == BEATS && nc_land > nc_need) ? nc_land : nc_need;   // a copy finished
    wire [31:0] nc_need_n = (state == S_RD_GATE) ? 32'd0 :
                            (state == S_EA_START && ct_cnt > nc_need_c) ? ct_cnt : nc_need_c;           // the decisions ended
    always @(posedge clk) begin
        nc_need <= nc_need_n;
        if (fmt_done_r && state == S_EA_START && arr_seen) begin
            if (acc_hbm) begin if (ct_cnt - t_arr > ar_max_dec_h) ar_max_dec_h <= ct_cnt - t_arr; end
            else         begin if (ct_cnt - t_arr > ar_max_dec)   ar_max_dec   <= ct_cnt - t_arr; end
        end
        if (fmt_done_r && state == S_DDR_WRITE && arr_seen && (wb_done_seen || axim_write_done)) begin
            if (acc_hbm) begin if (ct_cnt + 32'd1 - t_arr - AR_WBF_H > ar_max_wr_h) ar_max_wr_h <= ct_cnt + 32'd1 - t_arr - AR_WBF_H; end
            else         begin if (ct_cnt + 32'd1 - t_arr - AR_WBF   > ar_max_wr)   ar_max_wr   <= ct_cnt + 32'd1 - t_arr - AR_WBF; end
        end
        if (fmt_done_r && state == S_RES_STREAM && res_out_beat == BEATS) begin   // the access ends: every copy has landed
            nc_acc_seen <= nc_acc_seen + 32'd1;
            if (acc_hbm) begin if (nc_need - t_arr > ar_max_need_h) ar_max_need_h <= nc_need - t_arr; end
            else         begin if (nc_need - t_arr > ar_max_need)   ar_max_need   <= nc_need - t_arr; end
        end
    end
`endif
`ifdef ORAM_ONPKG_DEBUG
    // =========================================================================
    // v14b on-package debug (build option ORAM_ONPKG_DEBUG; never in a measured or deployed build)
    // =========================================================================
    // An on-package overrun is recorded and counted here and does not halt (ONPKG_HALT = 0): the access runs on, the
    // write is handed off late, and the release waits for it, so the access's times are the card's own.
    //  dbg_acc_rec: per access, raw access-cycle timestamps (ct_cnt, 16 bits, 0xFFFF = did not happen), so the host
    //    takes each difference exactly as the deadline checks do (S_EA_START - t_arr <= AR_WB_H, S_DONE_GATE entry -
    //    t_arr <= AR_REL_H). 16-bit words: 0 t_arr (bucket read done), 1 flags, 2 write-back issued (S_EA_START on
    //    package), 3 release gate reached (S_DONE_GATE entered: the write handed off), 4 last W accepted, 5 first W
    //    accepted, 6 bucket record arrived, 7 stash open issued, 8 stash ready (S_SCAN left: the decisions start),
    //    9 S_SCAN entered (bucket and record in), 10 last eviction copy landed, 11 cycles with W held by the memory
    //    (wvalid && !wready), 12 cycles with no W beat offered while writing (waiting for copies), 13 bucket read
    //    address accepted, 14 first bucket read beat, 15 access end (client_done). Flags: [0] on package, [1] plaintext
    //    path, [2] deadline (1) missed, [3] deadline (2) missed, [4] scratch bank conflict, [5] arrival seen, [6] PUT,
    //    [11:8] eviction copies queued.
    //  dbg_ov_rec: [255:0] counters since boot (type 0x5C), [511:256] the first on-package overrun (0x5D), [767:512]
    //    the first deadline (2) miss (0x5E); layouts in docs/v14b_card_calibration.md (and vitis/host_doma.cpp).
    localparam [15:0] DNONE = 16'hFFFF;
    wire [15:0] ct16 = (ct_cnt > 32'hFFFE) ? 16'hFFFE : ct_cnt[15:0];
    reg  [15:0] r_tarr, r_ea, r_dg, r_wl, r_wf, r_bm, r_so, r_sx, r_se, r_cl, r_wst, r_wsv, r_ar, r_r1, r_end, r_flg;
    reg  [15:0] r_cpb, r_wbt;                                   // copy beats landed, bucket W beats: this access
    reg  [15:0] c_baw, c_bwl, c_bb, c_bar, c_brl, c_saw, c_swl, c_sb, c_sar, c_srl;   // port handshakes since boot
    reg  [31:0] d_acc, d_on, d_n1, d_n2, d_nbc;
    reg  [15:0] d_by1, d_by2, d_wb, d_rel, d_sx;
    reg         sa_v, sb_v;
    reg  [255:0] sa, sb;
    wire        dbg_end = (state == S_RES_STREAM) && (res_out_beat == BEATS);   // the edge that sets client_done
    // v14c, the stash open of this access on the stash port (raw access cycles, 0xFFFF = did not happen). 16-bit words:
    //  0 {reads issued [15:8], open deferred until the stash was quiet [7], b has a chain [6], bt == b [5], requested
    //    block stashed [4], b's window entries [3:0]}  1 read beats  2 first read address accepted  3 first read beat
    //  4 head(b) landed (level 2 may start)  5 last read beat  6 longest read (address to first beat)  7 sum of the read
    //  latencies (saturating)  8 cycles with a read address waiting (arvalid && !arready)  9 cycles with reads
    //  outstanding and no beat  10 stash write beats during the open  11 cycles from the last stash write response
    //  to the open  12 position lookup done  13 first level-2 read address  14 {outstanding stash writes at the open
    //  [15:8], the bucket's fill [7:0]}  15 the stash ready (the open complete)
    reg  [31:0] cyc32, last_sb;
    reg  [15:0] s_ar1, s_r1, s_ha, s_rl, s_lk, s_l2a, s_end, s_nb, s_lmax, s_lsum, s_arw, s_gap, s_wb, s_qb;
    reg  [7:0]  s_info;
    reg  [7:0]  s_nr, s_wq;
    reg         s_on, s_def, lf_first;
    reg  [3:0]  s_age;
    reg  [15:0] lf [0:31];
    reg  [4:0]  lf_wp, lf_rp;
    assign dbg_st_rec = {s_end, s_wq, {(8-FILL_W){1'b0}}, bkt_fill_count, s_l2a, s_lk, s_qb, s_wb, s_gap, s_arw, s_lsum, s_lmax,
                         s_rl, s_ha, s_r1, s_ar1, s_nb, s_nr, s_info[7:0]};
    function [15:0] dsub; input [15:0] a, b; begin dsub = (a == DNONE || b == DNONE || a < b) ? 16'd0 : a - b; end endfunction
    // outstanding counts as signed 8 bits (negative: the completions lead, e.g. W beats ahead of their address)
    function [7:0] sat8; input [15:0] x; begin
        sat8 = (!x[15] && x > 16'd127) ? 8'h7F : (x[15] && x < 16'hFF80) ? 8'h80 : x[7:0]; end endfunction
`ifdef ORAM_NOCRYPTO
    localparam [15:0] D_WBH = AR_WB_H;
    wire       [15:0] D_RELH = nc_rel_h[15:0];              // the time in force, for the debug record
`else
    localparam [15:0] D_WBH = AR_WB_H, D_RELH = AR_REL_H;
`endif
    wire [1:0]   d_ev  = ev_d2 ? 2'd2 : ev_d1 ? 2'd1 : 2'd3;
    wire [255:0] d_snap = {4'd0, enc_pos_done, req_b24,
                           {m_stash_rready, m_stash_rvalid, m_stash_arvalid, m_stash_bvalid, m_stash_wready, m_stash_wvalid, m_stash_awready, m_stash_awvalid},
                           sat8(c_sar - c_srl), sat8(c_swl - c_sb), sat8(c_saw - c_swl),
                           {m_axi_rready, m_axi_rvalid, m_axi_arvalid, m_axi_bvalid, m_axi_wready, m_axi_wvalid, m_axi_awready, m_axi_awvalid},
                           sat8(c_bar - c_brl), sat8(c_bwl - c_bb), sat8(c_baw - c_bwl),
                           r_wbt, ev_pending[7:0], evq_rp[3:0], evq_wp[3:0], r_cpb, 16'd0,
`ifdef ORAM_OVERLAP4
                           (arr_seen ? ((ar_since > 32'hFFFE) ? 16'hFFFE : ar_since[15:0]) : DNONE), ct16,
`else
                           (arr_seen ? ((ct_cnt - t_arr > 32'hFFFE) ? 16'hFFFE : ct_cnt[15:0] - t_arr[15:0]) : DNONE), ct16,
`endif
                           d_acc,
                           {ec_active, bm_seen, st_wr_quiet, st_ready, wb_active, wb_pending, arr_seen, acc_hbm},
                           3'd0, state, 6'd0, d_ev, 8'h00};
    assign dbg_acc_rec = {r_end, r_r1, r_ar, r_wsv, r_wst, r_cl, r_se, r_sx, r_so, r_bm, r_wf, r_wl, r_dg, r_ea, r_flg, r_tarr};
    assign dbg_ov_rec  = {sb_v ? sb : 256'd0, sa_v ? sa : 256'd0,
                          d_sx, d_rel, d_wb, d_by2, d_nbc, d_n2, d_n1, d_on, d_by1, D_RELH, D_WBH, 8'd1, 8'h5C};
    always @(posedge clk) begin
        if (!rst_n) begin
            {r_tarr, r_ea, r_dg, r_wl, r_wf, r_bm, r_so, r_sx, r_se, r_cl, r_ar, r_r1, r_end} <= {13{DNONE}};
            r_wst <= 0; r_wsv <= 0; r_flg <= 0; r_cpb <= 0; r_wbt <= 0;
            {c_baw, c_bwl, c_bb, c_bar, c_brl, c_saw, c_swl, c_sb, c_sar, c_srl} <= 160'd0;
            d_acc <= 0; d_on <= 0; d_n1 <= 0; d_n2 <= 0; d_nbc <= 0; d_by1 <= 0; d_by2 <= 0; d_wb <= 0; d_rel <= 0; d_sx <= 0;
            sa_v <= 0; sb_v <= 0; sa <= 0; sb <= 0;
            cyc32 <= 0; last_sb <= 0;
        end else begin
            // the ports' handshakes (outstanding = issued - completed, modulo 2^16)
            if (m_axi_awvalid && m_axi_awready) c_baw <= c_baw + 1'b1;
            if (m_axi_wvalid && m_axi_wready && m_axi_wlast) c_bwl <= c_bwl + 1'b1;
            if (m_axi_bvalid && m_axi_bready) c_bb <= c_bb + 1'b1;
            if (m_axi_arvalid && m_axi_arready) c_bar <= c_bar + 1'b1;
            if (m_axi_rvalid && m_axi_rready && m_axi_rlast) c_brl <= c_brl + 1'b1;
            if (m_stash_awvalid && m_stash_awready) c_saw <= c_saw + 1'b1;
            if (m_stash_wvalid && m_stash_wready && m_stash_wlast) c_swl <= c_swl + 1'b1;
            if (m_stash_bvalid && m_stash_bready) c_sb <= c_sb + 1'b1;
            if (m_stash_arvalid && m_stash_arready) c_sar <= c_sar + 1'b1;
            if (m_stash_rvalid && m_stash_rready && m_stash_rlast) c_srl <= c_srl + 1'b1;
            if (state == S_IDLE) begin                      // between accesses: a fresh record (the kernel took the last)
                {r_tarr, r_ea, r_dg, r_wl, r_wf, r_bm, r_so, r_sx, r_se, r_cl, r_ar, r_r1, r_end} <= {13{DNONE}};
                r_wst <= 0; r_wsv <= 0; r_cpb <= 0; r_wbt <= 0;
            end else if (fmt_done_r) begin                  // an access (the boot format and layout are not)
                if (axim_read_done && !arr_seen) r_tarr <= ct16;
`ifdef ORAM_NOCRYPTO
                // word 2: the decisions' end (S_EA_START); the write's issue is t_arr + WBF by construction
                if (state == S_EA_START && r_ea == DNONE) r_ea <= ct16;
`else
                if (axim_cmd_write && r_ea == DNONE) r_ea <= ct16 - 16'd1;      // issued in the cycle before
`endif
                if (state == S_DONE_GATE && r_dg == DNONE) r_dg <= ct16;
                if (m_axi_wvalid && m_axi_wready) begin r_wl <= ct16; if (r_wf == DNONE) r_wf <= ct16; r_wbt <= r_wbt + 1'b1; end
                if (m_axi_wvalid && !m_axi_wready) r_wst <= r_wst + 1'b1;
`ifdef ORAM_NOCRYPTO
                // word 12: the earliest write-back time that serves this access hold-free, raw access cycle (nc_need)
                r_wsv <= (nc_need_n > 32'hFFFE) ? 16'hFFFE : nc_need_n[15:0];
`else
                if (wb_active && !m_axi_wvalid) r_wsv <= r_wsv + 1'b1;
`endif
                if (bm_rd_valid && r_bm == DNONE) r_bm <= ct16;
                if (st_open_en && r_so == DNONE) r_so <= ct16;
                if (state == S_SCAN && r_se == DNONE) r_se <= ct16;
                if (state == S_SCAN && st_ready && r_sx == DNONE) r_sx <= ct16;
                if (ec_active && ec_wr_beat == BEATS) r_cl <= ct16;
                if (scr_ev_wr_en) r_cpb <= r_cpb + 1'b1;
                if (m_axi_arvalid && m_axi_arready && r_ar == DNONE) r_ar <= ct16;
                if (m_axi_rvalid && m_axi_rready && r_r1 == DNONE) r_r1 <= ct16;
            end
            // v14c: the stash open on the stash port (see dbg_st_rec below)
            cyc32 <= cyc32 + 32'd1;
            if (m_stash_bvalid && m_stash_bready) last_sb <= cyc32;
            if (state == S_IDLE) begin
                {s_ar1, s_r1, s_ha, s_rl, s_lk, s_l2a, s_end} <= {7{DNONE}};
                s_nr <= 0; s_nb <= 0; s_lmax <= 0; s_lsum <= 0; s_arw <= 0; s_gap <= 0; s_wb <= 0; s_qb <= DNONE; s_info <= 0;
                s_on <= 1'b0; s_age <= 0; s_def <= 1'b0; s_wq <= 0; lf_wp <= 0; lf_rp <= 0; lf_first <= 1'b1;
            end else if (fmt_done_r) begin
                if (st_open_req) s_def <= 1'b1;
                if (state == S_POS_LOOKUP && pm_rd_valid && s_lk == DNONE) s_lk <= ct16;
                if (st_open_en) begin
                    s_on <= 1'b1; s_age <= 0;
                    s_qb <= (cyc32 - last_sb > 32'hFFFE) ? 16'hFFFE : cyc32[15:0] - last_sb[15:0];
                    s_wq <= sat8(c_saw - c_sb);
                end
                if (s_on) begin
                    if (s_age != 4'hF) s_age <= s_age + 1'b1;
                    if (m_stash_arvalid && m_stash_arready) begin
                        lf[lf_wp] <= ct16; lf_wp <= lf_wp + 1'b1; if (s_nr != 8'hFF) s_nr <= s_nr + 1'b1;
                        if (s_ar1 == DNONE) s_ar1 <= ct16;
                        if (st_dbg_open[7] && s_l2a == DNONE) s_l2a <= ct16;
                    end
                    if (m_stash_arvalid && !m_stash_arready) s_arw <= s_arw + 1'b1;
                    if (m_stash_rvalid && m_stash_rready) begin
                        s_nb <= s_nb + 1'b1; s_rl <= ct16; if (s_r1 == DNONE) s_r1 <= ct16;
                        if (lf_first) begin : lat
                            reg [15:0] l; l = ct16 - lf[lf_rp];
                            if (l > s_lmax) s_lmax <= l;
                            s_lsum <= (s_lsum + l < s_lsum) ? 16'hFFFF : s_lsum + l;
                            lf_first <= 1'b0;
                        end
                        if (m_stash_rlast) begin lf_rp <= lf_rp + 1'b1; lf_first <= 1'b1; end
                    end else if (lf_wp != lf_rp) s_gap <= s_gap + 1'b1;   // reads outstanding, no beat
                    if (m_stash_wvalid && m_stash_wready) s_wb <= s_wb + 1'b1;
                    if (st_dbg_open[7] && s_ha == DNONE) begin s_ha <= ct16; s_info[7:0] <= {s_def, st_dbg_open[6:0]}; end
                    if (st_ready && s_age >= 4'd4) begin s_on <= 1'b0; s_end <= ct16; end
                end
            end
            // the first on-package overrun, and the first deadline (2) miss, as they happen
            if ((ev_d1 || ev_d2 || (byp_acc && scr_clash)) && !sa_v) begin sa_v <= 1'b1; sa <= d_snap | 256'h5D; end
            if (ev_d2 && !sb_v) begin sb_v <= 1'b1; sb <= d_snap | 256'h5E; end
            if (dbg_end) begin                               // the access ends: its record and the counters
                r_end <= ct16;
                r_flg <= {4'd0, evq_wp[3:0], 1'b0, req_op, arr_seen, ov_bc, ov_d2, ov_d1, byp_acc, acc_hbm};
                d_acc <= d_acc + 1'b1;
                if (byp_acc) begin
                    d_on <= d_on + 1'b1;
                    if (ov_d1) begin d_n1 <= d_n1 + 1'b1; if (ov_by1 > d_by1) d_by1 <= ov_by1; end
                    if (ov_d2) begin d_n2 <= d_n2 + 1'b1; if (ov_by2 > d_by2) d_by2 <= ov_by2; end
                    if (ov_bc) d_nbc <= d_nbc + 1'b1;
                    if (dsub(r_ea, r_tarr) > d_wb)  d_wb  <= dsub(r_ea, r_tarr);
                    if (dsub(r_dg, r_tarr) > d_rel) d_rel <= dsub(r_dg, r_tarr);
                    if (dsub(r_sx, r_tarr) > d_sx)  d_sx  <= dsub(r_sx, r_tarr);
                end
                // the missed time of a snapshot taken in this access, now final
                if (sa_v && sa[63:32] == d_acc)
                    sa[111:96] <= (sa[9:8] == 2'd1) ? ov_by1 : (sa[9:8] == 2'd2) ? ov_by2 : 16'd0;
                if (sb_v && sb[63:32] == d_acc) sb[111:96] <= ov_by2;
            end
        end
    end
`endif
    // =========================================================================
    // Performance counters (debug builds only; secure_oram_top zeroes them)
    // =========================================================================
    // where the block was found: bucket, stash, or never written (in neither)
    localparam [2:0] CAT_RB = 3'd0, CAT_RS = 3'd1, CAT_WB = 3'd2, CAT_WS = 3'd3,
                     CAT_RN = 3'd4, CAT_WN = 3'd5;
    // never-written categories: internal counters (read by the testbench), no ports
    reg [31:0] perf_rn_total, perf_rn_ops, perf_rn_ddr_rd, perf_rn_decrypt, perf_rn_encrypt,
               perf_rn_compact, perf_rn_evict, perf_rn_ddr_wr, perf_rn_scan, perf_rn_stash;
    reg [31:0] perf_wn_total, perf_wn_ops, perf_wn_ddr_rd, perf_wn_decrypt, perf_wn_encrypt,
               perf_wn_compact, perf_wn_evict, perf_wn_ddr_wr, perf_wn_scan, perf_wn_stash;
    reg [2:0] perf_cat;
    wire acc_busy = fmt_done_r && state != S_IDLE && state != S_HALT;
    wire in_cr    = (state == S_CR_IV || state == S_CR_IVW || state == S_CR_START ||
                     state == S_CR_FEED || state == S_CR_RECV || state == S_CR_TAG);
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            perf_cat <= CAT_RB;
            acc_ddr_rd <= 0; acc_decrypt <= 0; acc_encrypt <= 0; acc_compact <= 0;
            acc_evict <= 0; acc_ddr_wr <= 0; acc_scan <= 0; acc_stash <= 0; acc_total <= 0;
        end else begin
            if (state == S_OP) perf_cat <= found_in_bucket ? (req_op ? CAT_WB : CAT_RB) :
                                    found_in_stash  ? (req_op ? CAT_WS : CAT_RS) :
                                                      (req_op ? CAT_WN : CAT_RN);
            if (state == S_IDLE) begin
                acc_ddr_rd <= 0; acc_decrypt <= 0; acc_encrypt <= 0; acc_compact <= 0;
                acc_evict <= 0; acc_ddr_wr <= 0; acc_scan <= 0; acc_stash <= 0; acc_total <= 0;
            end else if (acc_busy) begin
                acc_total <= acc_total + 1;
                if (state == S_POS_LOOKUP || state == S_RD_GATE || state == S_DDR_READ) acc_ddr_rd <= acc_ddr_rd + 1;
                if (in_cr && cr_mode == CR_DA) acc_decrypt <= acc_decrypt + 1;
                if ((in_cr && cr_mode == CR_EA) || state == S_EA_START) acc_encrypt <= acc_encrypt + 1;
                if (state == S_SCAN || state == S_OP) acc_scan <= acc_scan + 1;
                if ((state == S_CP && (cp_ret == S_COMPACT || cp_ret == S_PM_UPD)) || state == S_PM_UPD) acc_stash <= acc_stash + 1;
                if (state == S_COMPACT || state == S_COMPACT2 || (state == S_CP && cp_ret == S_COMPACT2)) acc_compact <= acc_compact + 1;
                if (state == S_EVICT || state == S_EVICT_CHK || state == S_EVICT_DONE || state == S_EVICT_WAIT ||
                    (state == S_CP && cp_ret == S_EVICT_DONE)) acc_evict <= acc_evict + 1;
                if (state == S_WB_GATE || state == S_DDR_WRITE || state == S_DONE_GATE || state == S_RES_STREAM)
                    acc_ddr_wr <= acc_ddr_wr + 1;
            end
        end
    end
    `define PERF_COMMIT(cat) \
        perf_``cat``_ddr_rd  <= perf_``cat``_ddr_rd  + acc_ddr_rd;  \
        perf_``cat``_decrypt <= perf_``cat``_decrypt + acc_decrypt; \
        perf_``cat``_encrypt <= perf_``cat``_encrypt + acc_encrypt; \
        perf_``cat``_compact <= perf_``cat``_compact + acc_compact; \
        perf_``cat``_evict   <= perf_``cat``_evict   + acc_evict;   \
        perf_``cat``_ddr_wr  <= perf_``cat``_ddr_wr  + acc_ddr_wr;  \
        perf_``cat``_scan    <= perf_``cat``_scan    + acc_scan;    \
        perf_``cat``_stash   <= perf_``cat``_stash   + acc_stash;   \
        perf_``cat``_total   <= perf_``cat``_total   + acc_total;   \
        perf_``cat``_ops     <= perf_``cat``_ops     + 1;
    `define PERF_CLEAR(cat) \
        perf_``cat``_ddr_rd <= 0; perf_``cat``_decrypt <= 0; perf_``cat``_encrypt <= 0; \
        perf_``cat``_compact <= 0; perf_``cat``_evict <= 0; perf_``cat``_ddr_wr <= 0; \
        perf_``cat``_scan <= 0; perf_``cat``_stash <= 0; perf_``cat``_total <= 0; perf_``cat``_ops <= 0;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            `PERF_CLEAR(rb) `PERF_CLEAR(rs) `PERF_CLEAR(wb) `PERF_CLEAR(ws) `PERF_CLEAR(rn) `PERF_CLEAR(wn)
        end else if (perf_reset) begin
            `PERF_CLEAR(rb) `PERF_CLEAR(rs) `PERF_CLEAR(wb) `PERF_CLEAR(ws) `PERF_CLEAR(rn) `PERF_CLEAR(wn)
        end else if (acc_commit) begin
            case (perf_cat)
                CAT_RB: begin `PERF_COMMIT(rb) end
                CAT_RS: begin `PERF_COMMIT(rs) end
                CAT_WB: begin `PERF_COMMIT(wb) end
                    CAT_RN: begin `PERF_COMMIT(rn) end
                    CAT_WN: begin `PERF_COMMIT(wn) end
                default: begin `PERF_COMMIT(ws) end
            endcase
        end
    end
    `undef PERF_COMMIT
    `undef PERF_CLEAR

`ifndef SYNTHESIS
    // Safety monitor (simulation only): the write-back must never read a beat of
    // a position that is not yet re-encrypted -- that would put plaintext on DDR.
    // (v14, on-package bucket: a position whose eviction copy has not landed.)
    reg [`SCR_AW-1:0] mon_req_q; reg [3:0] mon_epd_q; reg mon_act_q;
`ifdef ORAM_OVERLAP4
    always @(posedge clk)       // step 2: the write-back's scratch reads are wb_pf's (a read of beat b at s_rd)
        if (wb_active && wbpf_s_rd && w_epd < Z && {1'b0, wbpf_s_beat[BEAT_AW +: POS_W]} >= w_epd)
            $display("[%0t] SAFETY VIOLATION: write-back read beat %0d (position %0d) before it was encrypted (done=%0d)",
                     $time, wbpf_s_beat, wbpf_s_beat[BEAT_AW +: POS_W], w_epd);
`endif
    always @(posedge clk) begin
`ifdef ORAM_OVERLAP2
        mon_req_q <= axim_wdata_beat_req; mon_epd_q <= w_epd; mon_act_q <= wb_active;
`else
        mon_req_q <= axim_wdata_beat_req; mon_epd_q <= enc_pos_done; mon_act_q <= wb_active;
`endif
        if (mon_act_q && wb_active && axim_wdata_beat_req == mon_req_q + 1'b1 &&
            {1'b0, mon_req_q[BEAT_AW +: POS_W]} >= mon_epd_q && mon_epd_q < Z)
            $display("[%0t] SAFETY VIOLATION: write-back read beat %0d (position %0d) before it was encrypted (done=%0d)",
                     $time, mon_req_q, mon_req_q[BEAT_AW +: POS_W], mon_epd_q);
    end
`endif
`ifndef SYNTHESIS
    initial if (C > Z || (PART_W > 0 && N != B * C))       // the boot layout handles a partial last bucket
        $display("ERROR: layout needs C <= Z, and N == B*C when partitioned (N=%0d B=%0d C=%0d Z=%0d)", N, B, C, Z);
`endif
`ifndef SYNTHESIS
    // Diagnostics (simulation and hardware emulation only): say why the controller halts.
    reg dg_ct_q = 1'b0, dg_tag_q = 1'b0, dg_st_q = 1'b0;
`ifdef ORAM_OVERLAP4
    always @(posedge clk)
        if (err_ct_overrun_r && !dg_ct_q)
            $display("[%0t] OVERLAP4 STATE at halt: F %0d ctx %0d (has %0d%0d%0d%0d looked %0d ct %0d eq %0d eqm %b wdone %0d%0d%0d%0d) M state %0d ctx %0d (has %0d pre_ea %0d is_t %0d ct %0d t_arr %0d arr %0d) T %0d %0d %0d %0d E %0d ctx %0d q %0d | w_par %0d w_next %0d wb_active %0d r_next %0d axir_busy %0d s_since %0d",
                     $time, fst, f_par, f_has[0], f_has[1], f_has[2], f_has[3], f_looked[f_par], f_ct[f_par], f_eqa[f_par], f_eqm,
                     wdone[0], wdone[1], wdone[2], wdone[3], state, mp, m_has, m_pre_ea, m_is_t, ct_cnt, t_arr, arr_seen,
                     tst[0], tst[1], tst[2], tst[3], est, ej, eq_n, w_par, w_next, wb_active, r_next, axir_busy, s_since);
`elsif ORAM_OVERLAP2
    always @(posedge clk)
        if (err_ct_overrun_r && !dg_ct_q)
            $display("[%0t] OVERLAP STATE at halt: F %0d (has %0d looked %0d ct %0d eq %0d) M state %0d (has %0d pre_ea %0d is_t %0d ct %0d t_arr %0d arr %0d landed %0d rd_own_m %0d) T0 %0d ct %0d tarr %0d hbm %0d wbp %0d wbd %0d | T1 %0d ct %0d tarr %0d hbm %0d wbp %0d wbd %0d | w_par %0d w_next %0d wb_active %0d r_next %0d axir_busy %0d s_since %0d",
                     $time, fst, f_has, f_looked, f_ct, f_eq, state, m_has, m_pre_ea, m_is_t, ct_cnt, t_arr, arr_seen, landed_beats, rd_own_m,
                     tst[0], t_ct[0], t_tarr[0], t_hbm[0], t_wbp[0], t_wbd[0], tst[1], t_ct[1], t_tarr[1], t_hbm[1], t_wbp[1], t_wbd[1],
                     w_par, w_next, wb_active, r_next, axir_busy, s_since);
`endif
    always @(posedge clk) begin
        dg_ct_q <= err_ct_overrun_r; dg_tag_q <= err_tag_mismatch; dg_st_q <= err_stash_overflow;
        if (err_ct_overrun_r && !dg_ct_q)
            $display("[%0t] DOMA HALT: timing overrun in state %0d at access cycle %0d (budgets rd=%0d wb=%0d done=%0d; write-back stalled=%0d, bank conflict=%0d, write responses pending=%0d) bucket %0d",
                     $time, state, ct_cnt, CT_RD, CT_WB, CT_DONE, axim_wdata_stall, scr_bank_conflict, !axim_wr_quiet, req_b);
        if (err_tag_mismatch && !dg_tag_q)
            $display("[%0t] DOMA HALT: integrity (tag) failure on bucket %0d at access cycle %0d", $time, req_b, ct_cnt);
        if (err_stash_overflow && !dg_st_q)
            $display("[%0t] DOMA HALT: stash overflow, bucket %0d", $time, req_b);
    end
`endif

`ifdef ORAM_OVERLAP2
`ifdef ORAM_OVERLAP4
`ifdef ORAM_ONPKG_DEBUG
    ORAM_OVERLAP4_has_no_debug_records_yet u_no_ov4_dbg ();
`endif
`endif
    // overlap step 1 needs arrival scheduling (its write-back and release follow t_arr) and a write-back budget
    generate if (!AR_MODE || CT_WB == 0) begin : overlap_needs_arrival_mode
        ORAM_OVERLAP2_needs_ORAM_SCHED_ARRIVAL u_no_ov ();
    end endgenerate
`endif
`ifdef ORAM_ONPKG_INTERIM
    // v14b: the interim on-package budgets (oram_params.vh) are derived for 4 KB blocks at lambda = 7 only
    generate if (!(`ORAM_C == 7 && `ORAM_BLOCK_BEATS == 128))
    begin : interim_4kb_lambda7_only
        ORAM_ONPKG_INTERIM_is_for_4KB_lambda7_only u_no_interim ();
    end endgenerate
`endif
    // Timing budgets exist only for the calibrated block sizes (oram_params.vh): any other size has none and must not
    // build (it would otherwise run with another size's budgets). The missing module below stops synthesis.
    generate if (!(`ORAM_BLOCK_BEATS == 1 || `ORAM_BLOCK_BEATS == 2 || `ORAM_BLOCK_BEATS == 4 || `ORAM_BLOCK_BEATS == 8 ||
                   `ORAM_BLOCK_BEATS == 16 || `ORAM_BLOCK_BEATS == 32 || `ORAM_BLOCK_BEATS == 64 || `ORAM_BLOCK_BEATS == 128))
    begin : unsupported_block_size
        ORAM_BLOCK_BEATS_has_no_timing_budgets u_no_budgets ();
    end endgenerate

endmodule