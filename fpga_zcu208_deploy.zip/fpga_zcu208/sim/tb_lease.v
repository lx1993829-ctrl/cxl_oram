`timescale 1ns/1ps
// tb_lease.v -- the lease table seen from the management port (driven by the untrusted host):
//   GRANT and TRANSFER never return a token to the caller (only the owner's client lane carries it),
//   QUERY returns no token, REVOKE needs both the owner ID and the lease's token.
module tb_lease;
    localparam NC = 2, TW = 32, AW = 32;
    reg clk = 0, rst_n = 0;
    always #5 clk = ~clk;
    reg mgmt_req = 0; reg [2:0] mgmt_op = 0; reg [7:0] mgmt_lease_id = 0; reg [0:0] mgmt_client_id = 0;
    reg [AW-1:0] mgmt_base_addr = 0, mgmt_size = 0; reg [TW-1:0] mgmt_token_in = 0;
    wire mgmt_ack, mgmt_error; wire [TW-1:0] mgmt_token_out; wire [NC*TW-1:0] client_token_out;
    wire [NC-1:0] val_valid; wire [15:0] active_leases;
    lease_token_table #(.ADDR_WIDTH(AW), .NUM_CLIENTS(NC), .NUM_REGIONS(16), .LEASE_ID_WIDTH(8), .TOKEN_WIDTH(TW)) dut (
        .clk(clk), .rst_n(rst_n), .mgmt_req(mgmt_req), .mgmt_op(mgmt_op), .mgmt_lease_id(mgmt_lease_id),
        .mgmt_client_id(mgmt_client_id), .mgmt_base_addr(mgmt_base_addr), .mgmt_size(mgmt_size),
        .mgmt_duration(32'hFFFF_FFFF), .mgmt_token_in(mgmt_token_in), .mgmt_ack(mgmt_ack), .mgmt_error(mgmt_error),
        .mgmt_token_out(mgmt_token_out), .client_token_out(client_token_out),
        .client_addr({NC*AW{1'b0}}), .client_token({NC*TW{1'b0}}), .client_lease_id({NC*8{1'b0}}),
        .val_valid(val_valid), .active_leases(active_leases));

    integer fails = 0, checks = 0;
    reg ok_r, err_r; reg [TW-1:0] tok_out_r;
    task check(input cond, input [8*72-1:0] what);
        begin checks = checks + 1; if (!cond) begin fails = fails + 1; $display("LEASE: FAIL %0s", what); end end
    endtask
    task op(input [2:0] o, input [7:0] lid, input cid, input [TW-1:0] tok, input [AW-1:0] base);
        integer t;
        begin
            @(posedge clk); mgmt_req <= 1; mgmt_op <= o; mgmt_lease_id <= lid; mgmt_client_id <= cid;
            mgmt_token_in <= tok; mgmt_base_addr <= base; mgmt_size <= 32'h10000;
            @(posedge clk); mgmt_req <= 0;
            ok_r = 0; err_r = 0; t = 0;
            while (!mgmt_ack && !mgmt_error && t < 200) begin @(posedge clk); t = t + 1; end
            ok_r = mgmt_ack; err_r = mgmt_error; tok_out_r = mgmt_token_out;
            repeat (3) @(posedge clk);
        end
    endtask
    reg [TW-1:0] t5, t7, t7n;
    initial begin
        repeat (5) @(posedge clk); rst_n = 1; repeat (5) @(posedge clk);
        // GRANT lease 5 to client 1: the caller gets no token, client 1's lane does, client 0's lane stays empty
        op(3'd0, 8'd5, 1'b1, 0, 32'h0);
        t5 = client_token_out[1*TW +: TW];
        check(ok_r, "GRANT acknowledged");
        check(tok_out_r == 0, "GRANT: the management caller receives no token");
        check(t5 != 0, "GRANT: the owner's lane carries the token");
        check(client_token_out[0 +: TW] == 0, "GRANT: another client's lane carries nothing");
        // QUERY: no token
        op(3'd3, 8'd5, 1'b0, 0, 32'h0);
        check(ok_r && tok_out_r == 0, "QUERY: acknowledged without a token");
        // REVOKE with the owner ID alone: refused, lease still active
        op(3'd1, 8'd5, 1'b1, 0, 32'h0);
        check(err_r && !ok_r, "REVOKE with the owner ID but no token is refused");
        check(active_leases != 0, "the lease survives the refused REVOKE");
        // REVOKE with the token but the wrong owner ID: refused
        op(3'd1, 8'd5, 1'b0, t5, 32'h0);
        check(err_r && !ok_r, "REVOKE with the token but another client's ID is refused");
        // REVOKE with owner ID and token: accepted, lease gone
        op(3'd1, 8'd5, 1'b1, t5, 32'h0);
        check(ok_r, "REVOKE with the owner ID and the token is accepted");
        check(active_leases == 0, "the lease is gone after the accepted REVOKE");
        // TRANSFER lease 7 from client 0 to client 1: the caller gets no token, client 1's lane gets the new one
        op(3'd0, 8'd7, 1'b0, 0, 32'h0);
        t7 = client_token_out[0 +: TW];
        check(ok_r && t7 != 0, "GRANT lease 7 to client 0");
        op(3'd4, 8'd7, 1'b0, t7, 32'h1);            // new owner in mgmt_base_addr[0], as the module expects
        t7n = client_token_out[1*TW +: TW];
        check(ok_r, "TRANSFER with the owner ID and the token is accepted");
        check(tok_out_r == 0, "TRANSFER: the management caller receives no token");
        check(t7n != 0 && t7n != t7, "TRANSFER: the new owner's lane carries a new token");
        if (fails == 0) $display("LEASE: PASS %0d checks", checks);
        else            $display("LEASE: %0d of %0d checks FAILED", fails, checks);
        $finish;
    end
endmodule
