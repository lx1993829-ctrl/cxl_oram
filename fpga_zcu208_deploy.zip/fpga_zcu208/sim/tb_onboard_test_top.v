`timescale 1ns / 1ps
`include "oram_params.vh"

module tb_onboard_test_top;

    reg clk, rst_n, start;

    wire        done;
    wire        all_pass;
    wire [5:0]  fail_count;
    wire [5:0]  test_number;
    wire [52:0] test_result;
    wire        running;
    wire [2:0]  phase;

    // =========================================================================
    // DUT - simulation uses internal MIG via `define SIMULATION
    // Add +define+SIMULATION to XSim compile options, or
    // `define SIMULATION at the top of this file.
    // =========================================================================
    onboard_test_top #(
        .NUM_CLIENTS(`ORAM_NUM_CLIENTS),
        .TOKEN_WIDTH(32),
        .LEASE_ID_WIDTH(8)
    ) uut (
        .clk(clk), .rst_n(rst_n), .start(start),
        .done(done), .all_pass(all_pass), .fail_count(fail_count),
        .test_number(test_number), .test_result(test_result),
        .running(running), .phase(phase),
        // AXI ports - unused in sim (internal MIG handles traffic)
        .m_axi_arid(), .m_axi_araddr(), .m_axi_arlen(),
        .m_axi_arsize(), .m_axi_arburst(), .m_axi_arvalid(),
        .m_axi_arready(1'b0),
        .m_axi_rid({`AXI_ID_W{1'b0}}),
        .m_axi_rdata({`AXI_DATA_W{1'b0}}),
        .m_axi_rresp(2'b0), .m_axi_rlast(1'b0), .m_axi_rvalid(1'b0),
        .m_axi_rready(),
        .m_axi_awid(), .m_axi_awaddr(), .m_axi_awlen(),
        .m_axi_awsize(), .m_axi_awburst(), .m_axi_awvalid(),
        .m_axi_awready(1'b0),
        .m_axi_wdata(), .m_axi_wstrb(), .m_axi_wlast(), .m_axi_wvalid(),
        .m_axi_wready(1'b0),
        .m_axi_bid({`AXI_ID_W{1'b0}}),
        .m_axi_bresp(2'b0), .m_axi_bvalid(1'b0),
        .m_axi_bready()
    );

    // Clock: 100 MHz
    initial clk = 0;
    always #5 clk = ~clk;

    // =========================================================================
    // WORKAROUND: XSim lease_token_table unpacked array bug
    // =========================================================================
    initial begin
        wait(rst_n);
        @(posedge clk);
`ifdef XSIM_FORCE_LEASE_VALID
        force uut.dut.val_valid = uut.client_req;   // bypasses lease checks: XSim workaround only
`endif
    end

    // =========================================================================
    // Test Sequence
    // =========================================================================
    initial begin
        rst_n = 0; start = 0;
        repeat(20) @(posedge clk);
        rst_n = 1;
        $display("[%0t] Reset released", $time);
        repeat(10) @(posedge clk);
        @(posedge clk); start = 1;
        @(posedge clk); start = 0;
        $display("[%0t] Start pulsed", $time);

        wait(done);
        repeat(5) @(posedge clk);

        // Report
        $display("");
        $display("============================================================");
        $display("  ON-BOARD TEST RESULTS");
        $display("============================================================");
        $display("  Phase reached : %0d", phase);
        $display("  Last test     : T%0d", test_number);
        $display("  CT arrivals: rd=%0d wb=%0d done=%0d  overrun=%0d  tag_err=%0d  stash_ovf=%0d  fmt_done=%0d",
            uut.dut.u_oram.ct_max_rd, uut.dut.u_oram.ct_max_wb, uut.dut.u_oram.ct_max_done,
            uut.dut.u_oram.err_ct_overrun_r, uut.dut.u_oram.err_tag_mismatch, uut.dut.u_oram.err_stash_overflow, uut.dut.u_oram.fmt_done_r);
        $display("  access windows: %0d  err_slot_overrun=%0d", uut.dut.real_cnt, uut.dut.err_slot_overrun_r);
        $display("  Fail count    : %0d", fail_count);
        $display("  All pass      : %s", all_pass ? "YES" : "NO");
        $display("============================================================");
        begin : report_block
            integer t;
            for (t = 0; t < 53; t = t + 1) begin
                if (t == 0)  $display("  --- Phase 2: Bootstrap Write ---");
                if (t == 12) $display("  --- Phase 3: Read Back ---");
                if (t == 24) $display("  --- Phase 4: Re-read Shuffled ---");
                if (t == 36) $display("  --- Phase 5: Overwrite + Readback ---");
                if (t == 42) $display("  --- Phase 6: Client 1 ---");
                if (t == 45) $display("  --- Phase 7: Security ---");
                if (t == 48) $display("  --- Phase 8: Perf Tests ---");
                if (uut.test_skipped[t])
                    $display("  T%0d: SKIPPED (needs a second client; single-client run)", t + 1);
                else if (test_result[t])
                    $display("  T%0d: PASS", t + 1);
                else
                    $display("  T%0d: *** FAIL ***", t + 1);
            end
        end
        $display("============================================================");
        begin : skip_count
            integer ts, nsk;
            nsk = 0;
            for (ts = 0; ts < 53; ts = ts + 1) if (uut.test_skipped[ts]) nsk = nsk + 1;
            if (all_pass && nsk == 0)
                $display("  *** ALL 53 TESTS PASSED ***");
            else if (all_pass)
                $display("  *** ALL %0d RUN TESTS PASSED (%0d skipped: they need a second client) ***", 53 - nsk, nsk);
            else
                $display("  *** %0d FAILURE(S) out of %0d tests run ***", fail_count, 53 - nsk);
        end
        $display("============================================================");
        $display("");
        repeat(20) @(posedge clk); $finish;
    end

    // =========================================================================
    // Progress & Debug Monitor
    // =========================================================================
    reg [2:0]  prev_phase;
    reg [5:0]  prev_test;
    reg [5:0]  prev_fail_count;
    reg [4:0]  prev_oram_state;
    reg        prev_tag_mismatch;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            prev_phase      <= 3'd0;
            prev_test       <= 6'd0;
            prev_fail_count <= 6'd0;
            prev_oram_state <= 5'd0;
            prev_tag_mismatch <= 1'b0;
        end else if (running) begin
            // Tag mismatch monitor
            prev_tag_mismatch <= uut.err_tag_mismatch;
            if (uut.err_tag_mismatch && !prev_tag_mismatch)
                $display("[%0t] *** TAG MISMATCH at T%0d oram_state=%0d ***",
                         $time, test_number, uut.dut_dbg_oram_state);
            // Phase transitions
            if (phase != prev_phase) begin
                case (phase)
                    3'd0: $display("[%0t] Phase 0: BRAM Init", $time);
                    3'd1: begin
                        $display("[%0t] Phase 1: Lease Grants", $time);
                        // Dump pos_map entries to verify init worked
                        $display("  pos_map[1] (slot 0x1000): bucket=%0d status=%0d",
                            uut.dut.u_oram.u_pos_map.mem[1][5:0],
                            uut.dut.u_oram.u_pos_map.mem[1][7:6]);
                        $display("  pos_map[2] (slot 0x2000): bucket=%0d status=%0d",
                            uut.dut.u_oram.u_pos_map.mem[2][5:0],
                            uut.dut.u_oram.u_pos_map.mem[2][7:6]);
                        $display("  pos_map[3] (slot 0x3000): bucket=%0d status=%0d",
                            uut.dut.u_oram.u_pos_map.mem[3][5:0],
                            uut.dut.u_oram.u_pos_map.mem[3][7:6]);
                    end
                    3'd2: $display("[%0t] Phase 2: Bootstrap Write (T1-T12)", $time);
                    3'd3: $display("[%0t] Phase 3: Read Back (T13-T24)", $time);
                    3'd4: $display("[%0t] Phase 4: Re-read Shuffled (T25-T36)", $time);
                    3'd5: $display("[%0t] Phase 5: Overwrite + Readback (T37-T42)", $time);
                    3'd6: $display("[%0t] Phase 6: Client 1 (T43-T45)", $time);
                    3'd7: $display("[%0t] Phase 7: Security (T46-T48)", $time);
                endcase
                prev_phase <= phase;
            end

            // Test start
            if (test_number != prev_test && test_number != 0) begin
                $display("[%0t] Starting T%0d (read=%b verify=%b client=%b slot=0x%05h)",
                    $time, test_number,
                    uut.cur_is_read, uut.cur_needs_verify,
                    uut.cur_client, uut.cur_slot);
                prev_test <= test_number;
            end

            // MIG: AR handshake - show cmd_bucket too
            if (uut.dut_axi_arvalid && uut.dut_arready)
                $display("[%0t] MIG AR: addr=0x%08h len=%0d cmd_bucket=%0d (T%0d)",
                    $time, uut.dut_axi_araddr, uut.dut_axi_arlen,
                    uut.dut.u_oram.axim_cmd_bucket, test_number);

            // MIG: AW handshake
            if (uut.dut_axi_awvalid && uut.dut_awready)
                $display("[%0t] MIG AW: addr=0x%08h len=%0d cmd_bucket=%0d (T%0d)",
                    $time, uut.dut_axi_awaddr, uut.dut_axi_awlen,
                    uut.dut.u_oram.axim_cmd_bucket, test_number);

            // MIG: B response
            if (uut.dut_bvalid && uut.dut_axi_bready)
                $display("[%0t] MIG B: resp (T%0d)", $time, test_number);

            // ORAM FSM state transitions
            if (uut.dut.u_oram.state != prev_oram_state) begin
                $display("[%0t] ORAM: %0d -> %0d (T%0d)",
                    $time, prev_oram_state, uut.dut.u_oram.state, test_number);
                // On pos_lookup -> DDR_READ transition, show what pos_map returned
                if (prev_oram_state == 5'd1 && uut.dut.u_oram.state == 5'd2) begin
                    $display("    pm_rd_bucket=%0d pm_rd_status=%0d req_b=%0d req_b_new=%0d",
                        uut.dut.u_oram.u_pos_map.rd_bucket,
                        uut.dut.u_oram.u_pos_map.rd_status,
                        uut.dut.u_oram.req_b,
                        uut.dut.u_oram.req_b_new);
                    $display("    axim_cmd_bucket=%0d bucket_base=0x%08h",
                        uut.dut.u_oram.axim_cmd_bucket,
                        uut.dut.u_oram.u_axi_master.bucket_base);
                end
                prev_oram_state <= uut.dut.u_oram.state;
            end

            // client_done
            if (|uut.client_done)
                $display("[%0t] client_done=%b (T%0d)", $time, uut.client_done, test_number);

            // Read beat capture: first 3 beats
            if (uut.cur_is_read && uut.tst_state == 5'd7) begin
                if (|uut.dut.client_rdata_valid) begin
                    if (uut.rd_beat_count < 3)
                        $display("[%0t] RDATA[%0d][31:0]=0x%08h (T%0d)",
                            $time, uut.rd_beat_count,
                            uut.dut.client_rdata[uut.cur_client * 256 +: 32],
                            test_number);
                end
            end

            // Verify: first 3 beats and any mismatch
            if (uut.tst_state == 5'd9 && uut.verify_beat > 0) begin
                if (uut.verify_beat <= 4) begin
                    $display("[%0t] VERIFY[%0d]: got=0x%08h exp=0x%08h (T%0d)",
                        $time, uut.verify_beat - 7'd1,
                        uut.verify_rdata[31:0],
                        (uut.verify_beat - 7'd1),
                        test_number);
                end
            end

            // Fail events
            if (fail_count != prev_fail_count) begin
                $display("[%0t] *** FAIL T%0d ***", $time, test_number);
                $display("    tst_state=%0d timeout=%0d mismatch=%b beats=%0d",
                    uut.tst_state, uut.timeout_cnt,
                    uut.rd_mismatch, uut.rd_beat_count);
                $display("    oram_state=%0d busy=%b done=%b violation=%b",
                    uut.dut.u_oram.state, uut.oram_busy,
                    uut.client_done, uut.access_violation);
                $display("    mig_fsm=%0d arvalid=%b awvalid=%b",
                    0, uut.dut_axi_arvalid, uut.dut_axi_awvalid);
                $display("    captured[0]=0x%08h [1]=0x%08h [2]=0x%08h",
                    uut.captured_rdata[0][31:0],
                    uut.captured_rdata[1][31:0],
                    uut.captured_rdata[2][31:0]);
                prev_fail_count <= fail_count;
            end
        end
    end

    // =========================================================================
    // Watchdog
    // =========================================================================
    initial begin
        #(64'd5_000_000_000);
        $display("[WATCHDOG] 5s timeout at phase=%0d T%0d tst=%0d oram=%0d",
            phase, test_number, uut.tst_state,
            uut.dut.u_oram.state);
        $finish;
    end

    initial begin
`ifdef DUMP_VCD
        $dumpfile("tb_onboard_test.vcd");
        $dumpvars(0, tb_onboard_test_top);
`endif
    end



    initial begin : layout_report
        integer li, nd; reg [63:0] seen;
        wait (uut.dut.u_oram.fmt_done_r === 1'b1);
        #20;
        seen = 64'd0; nd = 0;
        for (li = 0; li <= 32; li = li + 1) begin
            if (!seen[uut.dut.u_oram.u_pos_map.mem[uut.slot_addrs[li][20:12]][5:0]]) nd = nd + 1;
            seen[uut.dut.u_oram.u_pos_map.mem[uut.slot_addrs[li][20:12]][5:0]] = 1'b1;
        end
        $display("  LAYOUT: random lazy layout done; the self-test's 33 slots map to %0d distinct buckets (status=never-written)", nd);
    end
    // ---- Phase 2 tamper checks (+tamper_hole / +tamper_target) -------------
    // The adversary flips one bit of ciphertext in DDR after the format pass.
    // Bucket 0 holds slot_addrs[0] at position 0 (fill 1); positions 1-7 are
    // holes, which the original design never verified. The next access to
    // bucket 0 must detect it and halt (fail-stop).
    // Tamper watchdog (plain Verilog-2001: no fork/join_any): if the flipped bit
    // is not detected within 200 ms of simulated time after the format pass,
    // report MISSED.
    // Start-up check: which package is compiled in, and refuse a stale header.
    initial begin : pkg_check
`ifndef ORAM_PKG_REV
        $display("ERROR: an OLD oram_params.vh is being compiled (it has no ORAM_PKG_REV).");
        $display("       The project is using a stale copy. Replace it with rtl/oram_params.vh");
        $display("       from the package (vivado/add_sources.tcl with ORAM_REPLACE 1 does this).");
        $finish;
`else
        $display("tb_onboard_test_top | package %s | ORAM_CT_WB=%0d ORAM_CT_DONE=%0d",
                 `ORAM_PKG_REV, `ORAM_CT_WB, `ORAM_CT_DONE);
`endif
    end

    // ---- Padding monitor (simulation only) --------------------------------------
    // Every access is pinned to fixed points, counted from its start: the DDR read is
    // issued at CT_RD, the write-back starts at CT_WB, the access completes at CT_DONE.
    // Per path, record when the path-dependent work really finished (all 8 positions
    // re-encrypted) and how much idle time (padding) filled the rest.
    integer pd_n [0:5], pd_e_sum [0:5], pd_e_min [0:5], pd_e_max [0:5];
    integer pd_w_min [0:5], pd_w_max [0:5], pd_rd_sum [0:5];
    integer cur_e, cur_w, cur_rd, pk;
    // Phase timeline: when each phase of an access really starts and ends (cycles
    // from access start), accumulated per category. Phases overlap, so durations do
    // not add up to the total. 0 DDR read, 1 verify, 2 data operation, 3 eviction
    // decisions, 4 eviction copies, 5 re-encryption, 6 write-back, 7 result return.
    integer ph_ps [0:7], ph_pe [0:7];
    integer ph_s [0:47], ph_e [0:47], ph_n [0:47];
    integer pp;
    reg [10:0] ph_land_q; reg ph_ec_q, ph_wb_q;
    reg [4:0]  pd_state_q;
    reg [3:0]  pd_epd_q;
    reg [31:0] pd_ops_q [0:5];
    task pad_clear; begin
        for (pp = 0; pp < 48; pp = pp + 1) begin ph_s[pp] = 0; ph_e[pp] = 0; ph_n[pp] = 0; end
        for (pk = 0; pk < 6; pk = pk + 1) begin
            pd_n[pk] = 0; pd_e_sum[pk] = 0; pd_rd_sum[pk] = 0;
            pd_e_min[pk] = 1000000000; pd_e_max[pk] = 0;
            pd_w_min[pk] = 1000000000; pd_w_max[pk] = 0;
        end
    end endtask
    task pad_commit; input integer k; begin
        for (pp = 0; pp < 8; pp = pp + 1)
            if (ph_ps[pp] >= 0 && ph_pe[pp] >= 0) begin
                ph_s[k*8+pp] = ph_s[k*8+pp] + ph_ps[pp]; ph_e[k*8+pp] = ph_e[k*8+pp] + ph_pe[pp];
                ph_n[k*8+pp] = ph_n[k*8+pp] + 1;
            end
        pd_n[k] = pd_n[k] + 1;
        pd_e_sum[k] = pd_e_sum[k] + cur_e;  pd_rd_sum[k] = pd_rd_sum[k] + cur_rd;
        if (cur_e < pd_e_min[k]) pd_e_min[k] = cur_e;
        if (cur_e > pd_e_max[k]) pd_e_max[k] = cur_e;
        if (cur_w < pd_w_min[k]) pd_w_min[k] = cur_w;
        if (cur_w > pd_w_max[k]) pd_w_max[k] = cur_w;
    end endtask
    initial begin cur_e = 0; cur_w = 0; cur_rd = 0; pad_clear; end
    always @(posedge clk) begin
        pd_state_q <= uut.dut.u_oram.state;
        pd_epd_q   <= uut.dut.u_oram.enc_pos_done;
        if (uut.dut.u_oram.state == 5'd2 && pd_state_q != 5'd2)          // arrived at the read gate
            cur_rd = uut.dut.u_oram.ct_cnt;
        if (uut.dut.u_oram.state == 5'd2 && pd_state_q != 5'd2)          // access starts: clear its timeline
            for (pp = 0; pp < 8; pp = pp + 1) begin ph_ps[pp] = -1; ph_pe[pp] = -1; end
        if (pd_state_q == 5'd2 && uut.dut.u_oram.state != 5'd2) ph_ps[0] = uut.dut.u_oram.ct_cnt;                 // read issued
        if (ph_land_q < (`ORAM_Z * `BEATS_PER_BLOCK) && uut.dut.u_oram.landed_beats >= (`ORAM_Z * `BEATS_PER_BLOCK)) ph_pe[0] = uut.dut.u_oram.ct_cnt;  // last beat landed
        if (uut.dut.u_oram.state == 5'd6 && pd_state_q != 5'd6 && uut.dut.u_oram.cr_mode == 2'd0 && uut.dut.u_oram.cr_pos == 0 && ph_ps[1] < 0)
            ph_ps[1] = uut.dut.u_oram.ct_cnt;                                                         // verify starts
        if (uut.dut.u_oram.state == 5'd10 && pd_state_q != 5'd10) begin ph_pe[1] = uut.dut.u_oram.ct_cnt; ph_ps[2] = uut.dut.u_oram.ct_cnt; end
        if (uut.dut.u_oram.state == 5'd16 && pd_state_q != 5'd16) begin ph_pe[2] = uut.dut.u_oram.ct_cnt; ph_ps[3] = uut.dut.u_oram.ct_cnt; end
        if (uut.dut.u_oram.state == 5'd20 && pd_state_q != 5'd20) ph_pe[3] = uut.dut.u_oram.ct_cnt;               // decisions done
        if (uut.dut.u_oram.ec_active && !ph_ec_q && ph_ps[4] < 0) ph_ps[4] = uut.dut.u_oram.ct_cnt;             // first copy starts
        if (!uut.dut.u_oram.ec_active && ph_ec_q) ph_pe[4] = uut.dut.u_oram.ct_cnt;                              // last copy ends
        if (uut.dut.u_oram.state == 5'd6 && pd_state_q != 5'd6 && uut.dut.u_oram.cr_mode == 2'd1 && uut.dut.u_oram.cr_pos == 0)
            ph_ps[5] = uut.dut.u_oram.ct_cnt;                                                         // re-encryption starts
        if (uut.dut.u_oram.enc_pos_done == `ORAM_Z && pd_epd_q != `ORAM_Z) ph_pe[5] = uut.dut.u_oram.ct_cnt;
        if (uut.dut.u_oram.wb_active && !ph_wb_q) ph_ps[6] = uut.dut.u_oram.ct_cnt;                             // write-back issued
        if (uut.dut.u_oram.axim_write_done && uut.dut.u_oram.fmt_done_r) ph_pe[6] = uut.dut.u_oram.ct_cnt;
        if (uut.dut.u_oram.state == 5'd24 && pd_state_q != 5'd24) ph_ps[7] = uut.dut.u_oram.ct_cnt;             // result streams out
        if (uut.dut.u_oram.state == 5'd0 && pd_state_q == 5'd24) ph_pe[7] = uut.dut.u_oram.ct_cnt;
        ph_land_q <= uut.dut.u_oram.landed_beats; ph_ec_q <= uut.dut.u_oram.ec_active; ph_wb_q <= uut.dut.u_oram.wb_active;
        if (uut.dut.u_oram.enc_pos_done == `ORAM_Z && pd_epd_q != `ORAM_Z)     // all positions re-encrypted
            cur_e = uut.dut.u_oram.ct_cnt;
        if (uut.dut.u_oram.axim_write_done && uut.dut.u_oram.fmt_done_r) // write-back finished
            cur_w = uut.dut.u_oram.ct_cnt;
        if (uut.perf_rst) pad_clear;                                     // count the performance phase only
        else if (uut.perf_running) begin                                 // a real access committed to a path
            if (uut.dut.u_oram.perf_rb_ops == pd_ops_q[0] + 1) pad_commit(0);
            if (uut.dut.u_oram.perf_rs_ops == pd_ops_q[1] + 1) pad_commit(1);
            if (uut.dut.u_oram.perf_wb_ops == pd_ops_q[2] + 1) pad_commit(2);
            if (uut.dut.u_oram.perf_ws_ops == pd_ops_q[3] + 1) pad_commit(3);
            if (uut.dut.u_oram.perf_rn_ops == pd_ops_q[4] + 1) pad_commit(4);
            if (uut.dut.u_oram.perf_wn_ops == pd_ops_q[5] + 1) pad_commit(5);
        end
        pd_ops_q[0] <= uut.dut.u_oram.perf_rb_ops; pd_ops_q[1] <= uut.dut.u_oram.perf_rs_ops;
        pd_ops_q[2] <= uut.dut.u_oram.perf_wb_ops; pd_ops_q[3] <= uut.dut.u_oram.perf_ws_ops;
        pd_ops_q[4] <= uut.dut.u_oram.perf_rn_ops; pd_ops_q[5] <= uut.dut.u_oram.perf_wn_ops;
    end
    task ph_row; input integer i; input integer k; input [8*31-1:0] name; begin
        if (ph_n[i] == 0)
            $display("  %s      -       -         -   (no access had this phase)", name);
        else if (ph_n[i] != pd_n[k])
            $display("  %s  %6d  %6d  %8d   (in %0d of %0d accesses)", name, ph_s[i] / ph_n[i], ph_e[i] / ph_n[i],
                     (ph_e[i] - ph_s[i]) / ph_n[i], ph_n[i], pd_n[k]);
        else
            $display("  %s  %6d  %6d  %8d", name, ph_s[i] / ph_n[i], ph_e[i] / ph_n[i], (ph_e[i] - ph_s[i]) / ph_n[i]);
    end endtask
    task pad_row; input integer k; input [8*12-1:0] name; integer dl; begin
        dl = `ORAM_CT_WB + (`ORAM_Z - 1)*`BEATS_PER_BLOCK;     // write-back reaches the last position
        if (pd_n[k] > 0)
            $display("  %s %4d | %5d %5d %5d | %5d %5d %5d | %5d %5d | %4d | %4d %4d",
                name, pd_n[k], pd_e_min[k], pd_e_sum[k] / pd_n[k], pd_e_max[k],
                dl - pd_e_max[k], dl - pd_e_sum[k] / pd_n[k], dl - pd_e_min[k],
                pd_w_min[k], pd_w_max[k], `ORAM_CT_RD - pd_rd_sum[k] / pd_n[k],
                `ORAM_CT_DONE - pd_w_max[k], `ORAM_CT_DONE - pd_w_min[k]);
    end endtask


    // per-access timing trace for sim/worst_case.py (+timing_log=<file>)
    oram_timing_monitor u_tmon (
        .clk(clk), .state(uut.dut.u_oram.state), .ct_cnt(uut.dut.u_oram.ct_cnt),
        .req_op(uut.dut.u_oram.req_op), .found_in_bucket(uut.dut.u_oram.found_in_bucket), .found_in_stash(uut.dut.u_oram.found_in_stash),
        .found_pos({5'd0, uut.dut.u_oram.found_pos}), .bkt_fill_count({4'd0, uut.dut.u_oram.bkt_fill_count}),
        .fill({4'd0, uut.dut.u_oram.fill}), .landed_beats({5'd0, uut.dut.u_oram.landed_beats}),
        .enc_pos_done({4'd0, uut.dut.u_oram.enc_pos_done}), .cr_mode(uut.dut.u_oram.cr_mode), .cr_pos({4'd0, uut.dut.u_oram.cr_pos}),
        .write_done(uut.dut.u_oram.axim_write_done), .fmt_done(uut.dut.u_oram.fmt_done_r));


    // Performance report: printed when the performance phase ends, so the functional
    // tests that follow cannot change it.
    initial begin : perf_report
        wait (uut.perf_done === 1'b1);
        repeat (5) @(posedge clk);
        $display("");
        $display("=== PERFORMANCE PHASE DONE (the paper's workload, from the fresh boot state) ===");
        $display("=== PERFORMANCE COUNTERS (avg cycles/op) ===");
        // Counters are read from the controller itself (always running), not from
        // the top-level ports, which read 0 in non-debug builds by design.
        $display("  reads:  %0d  (block in a bucket %0d, in the stash %0d, never written %0d)",
                 uut.dut.u_oram.perf_rb_ops + uut.dut.u_oram.perf_rs_ops + uut.dut.u_oram.perf_rn_ops, uut.dut.u_oram.perf_rb_ops, uut.dut.u_oram.perf_rs_ops, uut.dut.u_oram.perf_rn_ops);
        $display("  writes: %0d  (block in a bucket %0d, in the stash %0d, never written %0d)",
                 uut.dut.u_oram.perf_wb_ops + uut.dut.u_oram.perf_ws_ops + uut.dut.u_oram.perf_wn_ops, uut.dut.u_oram.perf_wb_ops, uut.dut.u_oram.perf_ws_ops, uut.dut.u_oram.perf_wn_ops);
        $display("  Phases overlap (e.g. verification runs while the bucket is still arriving),");
        $display("  so the durations below do not add up to the total.");
        if (uut.dut.u_oram.perf_rb_ops > 0) begin
            $display("--- READ/BUCKET: block found in a bucket (%0d ops) ---", uut.dut.u_oram.perf_rb_ops);
            $display("  phase (average, cycles from access start)  start     end  duration");
            ph_row(0, 0, "DDR read of the bucket         ");
            ph_row(1, 0, "verify (decrypt, check tags)   ");
            ph_row(2, 0, "data operation                 ");
            ph_row(3, 0, "eviction decisions             ");
            ph_row(4, 0, "eviction copies (background)   ");
            ph_row(5, 0, "re-encrypt all positions       ");
            ph_row(6, 0, "write-back to DDR              ");
            ph_row(7, 0, "return the result              ");
            $display("  TOTAL, fixed for every access                            %0d", uut.dut.u_oram.perf_rb_total / uut.dut.u_oram.perf_rb_ops);
        end
        if (uut.dut.u_oram.perf_rs_ops > 0) begin
            $display("--- READ/STASH: block found in the stash (%0d ops) ---", uut.dut.u_oram.perf_rs_ops);
            $display("  phase (average, cycles from access start)  start     end  duration");
            ph_row(8, 1, "DDR read of the bucket         ");
            ph_row(9, 1, "verify (decrypt, check tags)   ");
            ph_row(10, 1, "data operation                 ");
            ph_row(11, 1, "eviction decisions             ");
            ph_row(12, 1, "eviction copies (background)   ");
            ph_row(13, 1, "re-encrypt all positions       ");
            ph_row(14, 1, "write-back to DDR              ");
            ph_row(15, 1, "return the result              ");
            $display("  TOTAL, fixed for every access                            %0d", uut.dut.u_oram.perf_rs_total / uut.dut.u_oram.perf_rs_ops);
        end
        if (uut.dut.u_oram.perf_rn_ops > 0) begin
            $display("--- READ/NEW: slot never written (returns zeros) (%0d ops) ---", uut.dut.u_oram.perf_rn_ops);
            $display("  phase (average, cycles from access start)  start     end  duration");
            ph_row(32, 4, "DDR read of the bucket         ");
            ph_row(33, 4, "verify (decrypt, check tags)   ");
            ph_row(34, 4, "data operation                 ");
            ph_row(35, 4, "eviction decisions             ");
            ph_row(36, 4, "eviction copies (background)   ");
            ph_row(37, 4, "re-encrypt all positions       ");
            ph_row(38, 4, "write-back to DDR              ");
            ph_row(39, 4, "return the result              ");
            $display("  TOTAL, fixed for every access                            %0d", uut.dut.u_oram.perf_rn_total / uut.dut.u_oram.perf_rn_ops);
        end
        if (uut.dut.u_oram.perf_wb_ops > 0) begin
            $display("--- WRITE/BUCKET: block found in a bucket (%0d ops) ---", uut.dut.u_oram.perf_wb_ops);
            $display("  phase (average, cycles from access start)  start     end  duration");
            ph_row(16, 2, "DDR read of the bucket         ");
            ph_row(17, 2, "verify (decrypt, check tags)   ");
            ph_row(18, 2, "data operation                 ");
            ph_row(19, 2, "eviction decisions             ");
            ph_row(20, 2, "eviction copies (background)   ");
            ph_row(21, 2, "re-encrypt all positions       ");
            ph_row(22, 2, "write-back to DDR              ");
            ph_row(23, 2, "return the result              ");
            $display("  TOTAL, fixed for every access                            %0d", uut.dut.u_oram.perf_wb_total / uut.dut.u_oram.perf_wb_ops);
        end
        if (uut.dut.u_oram.perf_ws_ops > 0) begin
            $display("--- WRITE/STASH: block found in the stash (%0d ops) ---", uut.dut.u_oram.perf_ws_ops);
            $display("  phase (average, cycles from access start)  start     end  duration");
            ph_row(24, 3, "DDR read of the bucket         ");
            ph_row(25, 3, "verify (decrypt, check tags)   ");
            ph_row(26, 3, "data operation                 ");
            ph_row(27, 3, "eviction decisions             ");
            ph_row(28, 3, "eviction copies (background)   ");
            ph_row(29, 3, "re-encrypt all positions       ");
            ph_row(30, 3, "write-back to DDR              ");
            ph_row(31, 3, "return the result              ");
            $display("  TOTAL, fixed for every access                            %0d", uut.dut.u_oram.perf_ws_total / uut.dut.u_oram.perf_ws_ops);
        end
        if (uut.dut.u_oram.perf_wn_ops > 0) begin
            $display("--- WRITE/NEW: first write to a never-written slot (%0d ops) ---", uut.dut.u_oram.perf_wn_ops);
            $display("  phase (average, cycles from access start)  start     end  duration");
            ph_row(40, 5, "DDR read of the bucket         ");
            ph_row(41, 5, "verify (decrypt, check tags)   ");
            ph_row(42, 5, "data operation                 ");
            ph_row(43, 5, "eviction decisions             ");
            ph_row(44, 5, "eviction copies (background)   ");
            ph_row(45, 5, "re-encrypt all positions       ");
            ph_row(46, 5, "write-back to DDR              ");
            ph_row(47, 5, "return the result              ");
            $display("  TOTAL, fixed for every access                            %0d", uut.dut.u_oram.perf_wn_total / uut.dut.u_oram.perf_wn_ops);
        end
        $display("================================================");
        $display("  rb=%0d rs=%0d rn=%0d | wb=%0d ws=%0d wn=%0d  (total=%0d)",
                 uut.dut.u_oram.perf_rb_ops, uut.dut.u_oram.perf_rs_ops, uut.dut.u_oram.perf_rn_ops, uut.dut.u_oram.perf_wb_ops, uut.dut.u_oram.perf_ws_ops, uut.dut.u_oram.perf_wn_ops,
                 uut.dut.u_oram.perf_rb_ops + uut.dut.u_oram.perf_rs_ops + uut.dut.u_oram.perf_rn_ops + uut.dut.u_oram.perf_wb_ops + uut.dut.u_oram.perf_ws_ops + uut.dut.u_oram.perf_wn_ops);
        $display("");
        $display("=== PADDING (cycles from access start; fixed points for EVERY access) ===");
        $display("  read issued at %0d (CT_RD) | write-back starts at %0d (CT_WB) | completes at %0d (CT_DONE) | result out by %0d",
                 `ORAM_CT_RD, `ORAM_CT_WB, `ORAM_CT_DONE, `ORAM_CT_DONE + 132);
        $display("  path          ops | work done (all re-encrypted) | slack absorbed     | write-back done | pad  | pad at");
        $display("                    |   min   avg   max            |   min   avg   max  |   min   max     | read | completion");
        pad_row(0, "READ/BUCKET "); pad_row(1, "READ/STASH  "); pad_row(4, "READ/NEW    ");
        pad_row(2, "WRITE/BUCKET"); pad_row(3, "WRITE/STASH "); pad_row(5, "WRITE/NEW   ");
        $display("  'work done' varies by path; the fixed write-back absorbs the difference (slack = %0d - work done,",
                 `ORAM_CT_WB + (`ORAM_Z - 1)*`BEATS_PER_BLOCK);
        $display("  i.e. how early encryption finished before the write-back needed the last position), and the");
        $display("  completion gate pads to %0d, so every access takes the same total.", `ORAM_CT_DONE);
    end

    initial begin : tamper_watchdog
        if ($test$plusargs("tamper_hole") || $test$plusargs("tamper_target")) begin
            wait (uut.dut.u_oram.fmt_done_r === 1'b1);
            #(64'd200_000_000);
            $display("TAMPER RESULT: MISSED");
            $finish;
        end
    end

    initial begin : tamper_check
        integer tb_beat, tb_bkt;
        if ($test$plusargs("tamper_hole") || $test$plusargs("tamper_target")) begin
            wait (uut.dut.u_oram.fmt_done_r === 1'b1);
            #100;
            // random lazy layout: find the bucket the first test (slot 0x1000) will read
            tb_bkt  = uut.dut.u_oram.u_pos_map.mem[1][5:0];
            // the build's own layout: bucket stride 2^BUCKET_SHIFT bytes, position stride one block
            tb_beat = tb_bkt*(1 << (`BUCKET_SHIFT - 5)) + ($test$plusargs("tamper_hole") ? (5*`BEATS_PER_BLOCK + (3 % `BEATS_PER_BLOCK))
                                                                                  : (0*`BEATS_PER_BLOCK + (7 % `BEATS_PER_BLOCK)));
            uut.ddr_mem[tb_beat] = uut.ddr_mem[tb_beat] ^ 256'd1;
            $display("[%0t] TAMPER: flipped 1 bit in bucket %0d (slot 0x1000's bucket), %s", $time, tb_bkt,
                     $test$plusargs("tamper_hole") ? "position 5" : "position 0");
            wait (uut.dut.u_oram.err_tag_mismatch === 1'b1);
            #2000;
            $display("TAMPER RESULT: DETECTED (err_tag_mismatch=1, controller state=%0d, halted=%0d, client_done pulses after detection suppressed)",
                     uut.dut.u_oram.state, uut.dut.u_oram.state == 5'd28);
            $finish;
        end
    end
endmodule


/*
`timescale 1ns / 1ps
`include "oram_params.vh"

module tb_onboard_test_top;

    reg clk, rst_n, start;

    wire        done;
    wire        all_pass;
    wire [5:0]  fail_count;
    wire [5:0]  test_number;
    wire [47:0] test_result;
    wire        running;
    wire [2:0]  phase;

    // =========================================================================
    // DUT - simulation uses internal MIG via `define SIMULATION
    // Add +define+SIMULATION to XSim compile options, or
    // `define SIMULATION at the top of this file.
    // =========================================================================
    onboard_test_top #(
        .NUM_CLIENTS(`ORAM_NUM_CLIENTS),
        .TOKEN_WIDTH(32),
        .LEASE_ID_WIDTH(8)
    ) uut (
        .clk(clk), .rst_n(rst_n), .start(start),
        .done(done), .all_pass(all_pass), .fail_count(fail_count),
        .test_number(test_number), .test_result(test_result),
        .running(running), .phase(phase),
        // AXI ports - unused in sim (internal MIG handles traffic)
        .m_axi_arid(), .m_axi_araddr(), .m_axi_arlen(),
        .m_axi_arsize(), .m_axi_arburst(), .m_axi_arvalid(),
        .m_axi_arready(1'b0),
        .m_axi_rid({`AXI_ID_W{1'b0}}),
        .m_axi_rdata({`AXI_DATA_W{1'b0}}),
        .m_axi_rresp(2'b0), .m_axi_rlast(1'b0), .m_axi_rvalid(1'b0),
        .m_axi_rready(),
        .m_axi_awid(), .m_axi_awaddr(), .m_axi_awlen(),
        .m_axi_awsize(), .m_axi_awburst(), .m_axi_awvalid(),
        .m_axi_awready(1'b0),
        .m_axi_wdata(), .m_axi_wstrb(), .m_axi_wlast(), .m_axi_wvalid(),
        .m_axi_wready(1'b0),
        .m_axi_bid({`AXI_ID_W{1'b0}}),
        .m_axi_bresp(2'b0), .m_axi_bvalid(1'b0),
        .m_axi_bready()
    );

    // Clock: 100 MHz
    initial clk = 0;
    always #5 clk = ~clk;

    // =========================================================================
    // WORKAROUND: XSim lease_token_table unpacked array bug
    // =========================================================================
    initial begin
        wait(rst_n);
        @(posedge clk);
`ifdef XSIM_FORCE_LEASE_VALID
        force uut.dut.val_valid = uut.client_req;   // bypasses lease checks: XSim workaround only
`endif
    end

    // =========================================================================
    // Test Sequence
    // =========================================================================
    initial begin
        rst_n = 0; start = 0;
        repeat(20) @(posedge clk);
        rst_n = 1;
        $display("[%0t] Reset released", $time);
        repeat(10) @(posedge clk);
        @(posedge clk); start = 1;
        @(posedge clk); start = 0;
        $display("[%0t] Start pulsed", $time);

        wait(done);
        repeat(5) @(posedge clk);

        // Report
        $display("");
        $display("============================================================");
        $display("  ON-BOARD TEST RESULTS");
        $display("============================================================");
        $display("  Phase reached : %0d", phase);
        $display("  Last test     : T%0d", test_number);
        $display("  Fail count    : %0d", fail_count);
        $display("  All pass      : %s", all_pass ? "YES" : "NO");
        $display("============================================================");
        begin : report_block
            integer t;
            for (t = 0; t < 48; t = t + 1) begin
                if (t == 0)  $display("  --- Phase 2: Bootstrap Write ---");
                if (t == 12) $display("  --- Phase 3: Read Back ---");
                if (t == 24) $display("  --- Phase 4: Re-read Shuffled ---");
                if (t == 36) $display("  --- Phase 5: Overwrite + Readback ---");
                if (t == 42) $display("  --- Phase 6: Client 1 ---");
                if (t == 45) $display("  --- Phase 7: Security ---");
                if (test_result[t])
                    $display("  T%0d: PASS", t + 1);
                else
                    $display("  T%0d: *** FAIL ***", t + 1);
            end
        end
        $display("============================================================");
        if (all_pass)
            $display("  *** ALL 53 TESTS PASSED ***");
        else
            $display("  *** %0d FAILURE(S) out of 53 tests ***", fail_count);
        $display("============================================================");
        $display("");
        $display("=== PERFORMANCE COUNTERS (avg cycles/op) ===");
        if (uut.perf_rd_ops > 0) begin
            $display("--- READ (%0d ops) ---", uut.perf_rd_ops);
            $display("  DDR Read:    %0d", uut.perf_rd_ddr_rd  / uut.perf_rd_ops);
            $display("  Scan/Lookup: %0d", uut.perf_rd_scan    / uut.perf_rd_ops);
            $display("  Decrypt:     %0d", uut.perf_rd_decrypt / uut.perf_rd_ops);
            $display("  Stash:       %0d", uut.perf_rd_stash   / uut.perf_rd_ops);
            $display("  Encrypt:     %0d", uut.perf_rd_encrypt / uut.perf_rd_ops);
            $display("  Compact:     %0d", uut.perf_rd_compact / uut.perf_rd_ops);
            $display("  Evict:       %0d", uut.perf_rd_evict   / uut.perf_rd_ops);
            $display("  DDR Write:   %0d", uut.perf_rd_ddr_wr  / uut.perf_rd_ops);
            $display("  TOTAL:       %0d", uut.perf_rd_total   / uut.perf_rd_ops);
        end
        if (uut.perf_wr_ops > 0) begin
            $display("--- WRITE (%0d ops) ---", uut.perf_wr_ops);
            $display("  DDR Read:    %0d", uut.perf_wr_ddr_rd  / uut.perf_wr_ops);
            $display("  Scan/Lookup: %0d", uut.perf_wr_scan    / uut.perf_wr_ops);
            $display("  Decrypt:     %0d", uut.perf_wr_decrypt / uut.perf_wr_ops);
            $display("  Stash:       %0d", uut.perf_wr_stash   / uut.perf_wr_ops);
            $display("  Encrypt:     %0d", uut.perf_wr_encrypt / uut.perf_wr_ops);
            $display("  Compact:     %0d", uut.perf_wr_compact / uut.perf_wr_ops);
            $display("  Evict:       %0d", uut.perf_wr_evict   / uut.perf_wr_ops);
            $display("  DDR Write:   %0d", uut.perf_wr_ddr_wr  / uut.perf_wr_ops);
            $display("  TOTAL:       %0d", uut.perf_wr_total   / uut.perf_wr_ops);
        end
        $display("================================================");
        repeat(20) @(posedge clk); $finish;
    end

    // =========================================================================
    // Progress & Debug Monitor
    // =========================================================================
    reg [2:0]  prev_phase;
    reg [5:0]  prev_test;
    reg [5:0]  prev_fail_count;
    reg [4:0]  prev_oram_state;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            prev_phase      <= 3'd0;
            prev_test       <= 6'd0;
            prev_fail_count <= 6'd0;
            prev_oram_state <= 5'd0;
        end else if (running) begin
            // Phase transitions
            if (phase != prev_phase) begin
                case (phase)
                    3'd0: $display("[%0t] Phase 0: BRAM Init", $time);
                    3'd1: begin
                        $display("[%0t] Phase 1: Lease Grants", $time);
                        // Dump pos_map entries to verify init worked
                        $display("  pos_map[1] (slot 0x1000): bucket=%0d status=%0d",
                            uut.dut.u_oram.u_pos_map.mem[1][5:0],
                            uut.dut.u_oram.u_pos_map.mem[1][7:6]);
                        $display("  pos_map[2] (slot 0x2000): bucket=%0d status=%0d",
                            uut.dut.u_oram.u_pos_map.mem[2][5:0],
                            uut.dut.u_oram.u_pos_map.mem[2][7:6]);
                        $display("  pos_map[3] (slot 0x3000): bucket=%0d status=%0d",
                            uut.dut.u_oram.u_pos_map.mem[3][5:0],
                            uut.dut.u_oram.u_pos_map.mem[3][7:6]);
                    end
                    3'd2: $display("[%0t] Phase 2: Bootstrap Write (T1-T12)", $time);
                    3'd3: $display("[%0t] Phase 3: Read Back (T13-T24)", $time);
                    3'd4: $display("[%0t] Phase 4: Re-read Shuffled (T25-T36)", $time);
                    3'd5: $display("[%0t] Phase 5: Overwrite + Readback (T37-T42)", $time);
                    3'd6: $display("[%0t] Phase 6: Client 1 (T43-T45)", $time);
                    3'd7: $display("[%0t] Phase 7: Security (T46-T48)", $time);
                endcase
                prev_phase <= phase;
            end

            // Test start
            if (test_number != prev_test && test_number != 0) begin
                $display("[%0t] Starting T%0d (read=%b verify=%b client=%b slot=0x%05h)",
                    $time, test_number,
                    uut.cur_is_read, uut.cur_needs_verify,
                    uut.cur_client, uut.cur_slot);
                prev_test <= test_number;
            end

            // MIG: AR handshake - show cmd_bucket too
            if (uut.dut_axi_arvalid && uut.dut_arready)
                $display("[%0t] MIG AR: addr=0x%08h len=%0d cmd_bucket=%0d (T%0d)",
                    $time, uut.dut_axi_araddr, uut.dut_axi_arlen,
                    uut.dut.u_oram.axim_cmd_bucket, test_number);

            // MIG: AW handshake
            if (uut.dut_axi_awvalid && uut.dut_awready)
                $display("[%0t] MIG AW: addr=0x%08h len=%0d cmd_bucket=%0d (T%0d)",
                    $time, uut.dut_axi_awaddr, uut.dut_axi_awlen,
                    uut.dut.u_oram.axim_cmd_bucket, test_number);

            // MIG: B response
            if (uut.dut_bvalid && uut.dut_axi_bready)
                $display("[%0t] MIG B: resp (T%0d)", $time, test_number);

            // ORAM FSM state transitions
            if (uut.dut.u_oram.state != prev_oram_state) begin
                $display("[%0t] ORAM: %0d -> %0d (T%0d)",
                    $time, prev_oram_state, uut.dut.u_oram.state, test_number);
                // On pos_lookup -> DDR_READ transition, show what pos_map returned
                if (prev_oram_state == 5'd1 && uut.dut.u_oram.state == 5'd2) begin
                    $display("    pm_rd_bucket=%0d pm_rd_status=%0d req_b=%0d req_b_new=%0d",
                        uut.dut.u_oram.u_pos_map.rd_bucket,
                        uut.dut.u_oram.u_pos_map.rd_status,
                        uut.dut.u_oram.req_b,
                        uut.dut.u_oram.req_b_new);
                    $display("    axim_cmd_bucket=%0d bucket_base=0x%08h",
                        uut.dut.u_oram.axim_cmd_bucket,
                        uut.dut.u_oram.u_axi_master.bucket_base);
                end
                prev_oram_state <= uut.dut.u_oram.state;
            end

            // client_done
            if (|uut.client_done)
                $display("[%0t] client_done=%b (T%0d)", $time, uut.client_done, test_number);

            // Read beat capture: first 3 beats
            if (uut.cur_is_read && uut.tst_state == 5'd7) begin
                if (|uut.dut.client_rdata_valid) begin
                    if (uut.rd_beat_count < 3)
                        $display("[%0t] RDATA[%0d][31:0]=0x%08h (T%0d)",
                            $time, uut.rd_beat_count,
                            uut.dut.client_rdata[uut.cur_client * 256 +: 32],
                            test_number);
                end
            end

            // Verify: first 3 beats and any mismatch
            if (uut.tst_state == 5'd9 && uut.verify_beat > 0) begin
                if (uut.verify_beat <= 4) begin
                    $display("[%0t] VERIFY[%0d]: got=0x%08h exp=0x%08h (T%0d)",
                        $time, uut.verify_beat - 7'd1,
                        uut.verify_rdata[31:0],
                        (uut.verify_beat - 7'd1),
                        test_number);
                end
            end

            // Fail events
            if (fail_count != prev_fail_count) begin
                $display("[%0t] *** FAIL T%0d ***", $time, test_number);
                $display("    tst_state=%0d timeout=%0d mismatch=%b beats=%0d",
                    uut.tst_state, uut.timeout_cnt,
                    uut.rd_mismatch, uut.rd_beat_count);
                $display("    oram_state=%0d busy=%b done=%b violation=%b",
                    uut.dut.u_oram.state, uut.oram_busy,
                    uut.client_done, uut.access_violation);
                $display("    mig_fsm=%0d arvalid=%b awvalid=%b",
                    0, uut.dut_axi_arvalid, uut.dut_axi_awvalid);
                $display("    captured[0]=0x%08h [1]=0x%08h [2]=0x%08h",
                    uut.captured_rdata[0][31:0],
                    uut.captured_rdata[1][31:0],
                    uut.captured_rdata[2][31:0]);
                prev_fail_count <= fail_count;
            end
        end
    end

    // =========================================================================
    // Watchdog
    // =========================================================================
    initial begin
        #(64'd5_000_000_000);
        $display("[WATCHDOG] 5s timeout at phase=%0d T%0d tst=%0d oram=%0d",
            phase, test_number, uut.tst_state,
            uut.dut.u_oram.state);
        $finish;
    end

    initial begin
`ifdef DUMP_VCD
        $dumpfile("tb_onboard_test.vcd");
        $dumpvars(0, tb_onboard_test_top);
`endif
    end
 endmodule
 */   
    
    
    
  