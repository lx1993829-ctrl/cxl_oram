#!/bin/bash
# calibrate_sizes.sh -- calibrate DOMA's arrival-mode timing budgets at every block size (32 B..4 KB, Z = 8), then run
# the full regression at every size. Needs Verilator 5 (--binary --timing), Icarus Verilog and python3; on a laptop
# with a few cores, about 2.5-3 hours. Run from anywhere:
#
#   bash sim/calibrate_sizes.sh 2>&1 | tee calibrate_sizes.log
#
# 1. the arrival budgets of the sizes to calibrate are set to the 4 KB placeholders, so no measurement run can stop on
#    the very budget it calibrates (the previous parameter file is kept in sim/calib/);
# 2. per size: worst (the derived bound after the last beat, gap-free and with fixed metadata latencies), combined
#    (HBM buckets, slow metadata, a full stash window), hostwait (host buckets at 240 cycles with slow metadata: no
#    stash wait, and no more work after the last beat than derived), arrival (the kernel runs); their reports are
#    kept in sim/calib/;
# 3. at 4 KB the derived bound after the last beat must be 3,845 (1,327 + 1 + 298 + 2,219);
# 4. the budgets are computed by sim/budgets.py and written into rtl/oram_params.vh;
# 5. the full regression runs at every size. The stimulus is deterministic (xorshift32, no $random), so every
#    Verilator version must give the same numbers and hashes: compare the SUMMARY between machines.
#   SIZES="1 128"  calibrate only these sizes (beats)      REG="1 2"  regress only these sizes      REG=""  none
set -u
cd "$(dirname "$0")"
SIM=$(pwd); RTL=$SIM/../rtl; OUT=$SIM/calib
SIZES=${SIZES-"1 2 4 8 16 32 64 128"}; REG=${REG-"1 2 4 8 16 32 64 128"}
declare -A NAME=([1]="32 B" [2]="64 B" [4]="128 B" [8]="256 B" [16]="512 B" [32]="1 KB" [64]="2 KB" [128]="4 KB")
fails=0; summary=""
note() { echo "$1"; summary+="$1"$'\n'; }

v=$(verilator --version 2>/dev/null | awk '{print $2}'); command -v iverilog > /dev/null && command -v python3 > /dev/null || { echo "need iverilog and python3"; exit 2; }
[ "${v%%.*}" -ge 5 ] 2>/dev/null || { echo "need Verilator 5 or newer (found: ${v:-none})"; exit 2; }
mkdir -p "$OUT"; cp "$RTL/oram_params.vh" "$OUT/oram_params.vh.before_$(date +%Y%m%d_%H%M%S)"
echo "== Verilator $v; calibrate: ${SIZES:-none}; regress: ${REG:-none}; outputs in $OUT"

if [ -n "$SIZES" ]; then
    echo "== 1. placeholders"
    python3 budgets.py --placeholders "$RTL/oram_params.vh" $SIZES || { note "FAIL: placeholders"; exit 1; }
    echo "== 2. calibration runs"
    for b in $SIZES; do
        for g in worst combined hostwait arrival; do
            s=$(date +%s); ORAM_BEATS=$b bash run_verilator.sh $g > "$OUT/cal_${b}_$g.out" 2>&1; rc=$?
            echo "   ${NAME[$b]} $g: exit $rc after $(( ($(date +%s) - s) / 60 )) min"
            [ $rc = 0 ] || { note "FAIL: calibration ${NAME[$b]} $g: $(grep -aE '^\s*FAIL' "$OUT/cal_${b}_$g.out" | head -2 | tr -s ' ')"; exit 1; }
            [ $g = worst ] && cp build/worst_case.txt "$OUT/worst_case_$b.txt"
        done
        cat build/run_*.log | grep -aoE "ar_max_wb=[0-9]+ ar_max_wb_h=[0-9]+" | sort -u > "$OUT/ar_$b.txt"
        d=$(sed -n "/^timing_worst.csv/,/^timing_selftest.csv/p" "$OUT/worst_case_$b.txt" | grep -oE "derived after arrival = [0-9 +]+= [0-9]+")
        note "${NAME[$b]}: $d; combined (HBM worst) $(grep -aoE "PASS  combined adverse case: ar_max_wb=[0-9]+ ar_max_wb_h=[0-9]+" "$OUT/cal_${b}_combined.out" | grep -oE "ar_max_wb_h=[0-9]+"); $(grep -aoE "work after the last beat [0-9]+ <= derived [0-9]+" "$OUT/cal_${b}_hostwait.out" | head -1)"
        if [ "$b" = 128 ]; then
            [ "${d##* }" = 3845 ] && note "   4 KB derived bound after the last beat = 3,845, as expected" \
                || { note "   FAIL: 4 KB derived bound after the last beat is ${d##* }, expected 3,845"; fails=$((fails + 1)); }
        fi
    done
    echo "== 3. budgets written into rtl/oram_params.vh"
    python3 budgets.py --write "$RTL/oram_params.vh" "$OUT" $SIZES | tee "$OUT/budgets.txt" || { note "FAIL: writing the budgets"; exit 1; }
    summary+="budgets:"$'\n'"$(grep -E 'beats\)' "$OUT/budgets.txt")"$'\n'
fi

if [ -n "$REG" ]; then
    echo "== 4. full regression"
    for b in $REG; do
        s=$(date +%s); ORAM_BEATS=$b bash run_verilator.sh > "$OUT/reg_$b.out" 2>&1; rc=$?
        hashes=$(grep -aoE "hash [0-9a-f]{16}" "$OUT/reg_$b.out" | awk '{print $2}' | sort -u | tr '\n' ' ')
        line="${NAME[$b]}: $( [ $rc = 0 ] && echo PASS || echo FAIL ) after $(( ($(date +%s) - s) / 60 )) min, hashes: $hashes"
        [ $rc = 0 ] || { fails=$((fails + 1)); line+=$'\n'"$(grep -aE '^\s*FAIL' "$OUT/reg_$b.out" | head -5)"; }
        note "$line"
    done
fi
echo; echo "================ SUMMARY ================"; echo -n "$summary"
if [ $fails != 0 ]; then echo "$fails FAILURE(S)"; elif [ -n "$REG" ]; then echo "ALL SIZES PASSED"; else echo "calibration done (no regression run: REG was empty)"; fi
exit $(( fails > 0 ))
