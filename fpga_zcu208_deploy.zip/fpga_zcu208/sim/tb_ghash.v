// tb_ghash.v -- ghash_lane3 against the Python reference (ghash_ref.py -> vec.hex); +gaps=0 feeds one block per cycle.
`timescale 1ns/1ps
module tb_ghash;
    reg clk = 0, rst_n = 0; always #1 clk = ~clk;
    reg start = 0, dv = 0, last = 0;
    reg [127:0] hk = 0, h2 = 0, h3 = 0, din = 0;
    wire [127:0] gout; wire gval, rdy;
    ghash_lane3 dut (.clk(clk), .rst_n(rst_n), .enable(1'b1), .start(start), .h_key(hk), .h2_key(h2), .h3_key(h3),
                     .data_in(din), .data_valid(dv), .last(last), .ghash_out(gout), .ghash_valid(gval), .ready(rdy));
    reg [127:0] mem [0:200000];
    integer p, m, n, i, gap, bad, msgs, cnt, gaps;
    reg [127:0] exp;
    initial begin
        $readmemh("vec.hex", mem);
        if (!$value$plusargs("gaps=%d", gaps)) gaps = 1;
        repeat (4) @(posedge clk); rst_n = 1; @(negedge clk);
        p = 0; bad = 0; msgs = 0;
        for (m = 0; m < 300; m = m + 1) begin
            n = mem[p]; hk = mem[p+1]; h2 = mem[p+2]; h3 = mem[p+3]; exp = mem[p+4]; p = p + 5;
            start = 1; @(negedge clk); start = 0;
            for (i = 0; i < n; i = i + 1) begin
                while (!rdy) @(negedge clk);
                if (gaps) begin gap = $random & 3; while (gap > 1) begin @(negedge clk); gap = gap - 1; end end
                din = mem[p + i]; dv = 1; last = (i == n - 1); @(negedge clk); dv = 0; last = 0;
            end
            p = p + n;
            cnt = 0; while (!gval && cnt < 1000) begin @(negedge clk); cnt = cnt + 1; end
            if (gout !== exp) begin bad = bad + 1; if (bad < 4) $display("MISMATCH msg %0d (n=%0d): got %h want %h", m, n, gout, exp); end
            msgs = msgs + 1;
            @(negedge clk);
        end
        $display("GHASH unit vs reference: %0d messages, %0d mismatches (gaps=%0d) %s", msgs, bad, gaps, bad == 0 ? "PASS" : "FAIL");
        $finish;
    end
endmodule
