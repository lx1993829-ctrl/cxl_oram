#!/usr/bin/env python3
"""Derive the worst case the ORAM timing gates must cover, from per-access traces.

Usage:  python3 worst_case.py [--params ../rtl/oram_params.vh] TRACE.csv [TRACE2.csv ...]

Traces come from oram_timing_monitor.v (+timing_log=<file>): one line per access,
with cycles counted from the start of the access.

1. Each access is cut into segments at fixed milestones:
     L0 = t_l0   - t_rd     first position landed after the read was issued (memory)
     A  = t_scan - t_l0     rest of verification (crypto-bound while memory keeps up)
     B  = t_evict- t_scan   operation phase: lookup, copies, compaction, map update
     C  = t_ea   - t_evict  eviction decisions
     D  = t_ea0  - t_ea     wait before encrypting position 0 (its eviction copy)
     Ec = t_e    - t_ea0    encryption of all positions
2. The cycle model: every on-chip segment is a function of the path features only
     B by (path, copies);  C by evictions;  D by (position 0 gets an eviction, evictions);  Ec constant
   and the structural rules of the controller hold (copies, fill, eviction count).
   Any key with two different values, or any broken rule, is reported: the model
   would then not explain the measured timing, and no bound is claimed.
3. Every feature combination the controller allows is enumerated. Per trace file
   (i.e. per memory model) the bound on the encryption end is
     max(t_rd) + max(L0) + max(A) + max over combinations of (B + C + D) + Ec
   and is compared with the deadline CT_WB + 7*BEATS, when the write-back needs the
   last position. The worst combination is also reported, and whether a traced access
   actually reached it.
"""
import csv, re, sys, os
from collections import defaultdict

def param(text, name):
    m = re.search(r"`define\s+%s\s+(\d+)" % name, text)
    if not m: sys.exit(f"cannot find {name} in parameter file")
    return int(m.group(1))

def path_of(r):
    if r["dummy"]: return "dummy"
    kind = "write" if r["op"] else "read"
    where = "bucket" if r["fib"] else ("stash" if r["fis"] else "new")
    return f"{kind}_{where}"

def main(argv):
    params = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "rtl", "oram_params.vh")
    if len(argv) > 2 and argv[1] == "--params": params, argv = argv[2], [argv[0]] + argv[3:]
    files = argv[1:]
    if not files: sys.exit(__doc__)
    ptxt = open(params).read()
    Z, BEATS = param(ptxt, "ORAM_Z"), param(ptxt, "BEATS_PER_BLOCK")
    CT_RD, CT_WB, CT_DONE = param(ptxt, "ORAM_CT_RD"), param(ptxt, "ORAM_CT_WB"), param(ptxt, "ORAM_CT_DONE")
    deadline = CT_WB + (Z - 1) * BEATS
    recs = {}
    for f in files:
        rows = []
        with open(f) as fh:
            for r in csv.DictReader(fh):
                if None in r.values() or None in r: continue      # incomplete line (run still writing)
                r = {k: int(v) for k, v in r.items()}
                if min(r[k] for k in ("t_rd","t_l0","t_scan","t_evict","t_ea","t_ea0","t_e")) < 0: continue
                r["path"] = path_of(r)
                r.update(L0=r["t_l0"]-r["t_rd"], A=r["t_scan"]-r["t_l0"], B=r["t_evict"]-r["t_scan"],
                         C=r["t_ea"]-r["t_evict"], D=r["t_ea0"]-r["t_ea"], Ec=r["t_e"]-r["t_ea0"])
                r["w"] = int(r["fill1"] == 0 and r["n_ev"] > 0)
                rows.append(r)
        recs[f] = rows
    allr = [r for rows in recs.values() for r in rows]
    print(f"accesses traced: {len(allr)} in {len(files)} file(s); Z={Z}, BEATS={BEATS}; "
          f"gates CT_RD={CT_RD} CT_WB={CT_WB} CT_DONE={CT_DONE}; deadline CT_WB+{Z-1}*{BEATS} = {deadline}")
    problems = []
    # ---- structural rules of the controller ----
    base = {}
    for r in allr:
        # A dummy access performs no data operation (it goes straight to eviction),
        # whatever its lookup flags say: fill unchanged, no copies.
        hit = r["fib"] == 1 and not r["dummy"]
        if r["fill1"] != (r["fill0"] - 1 if hit else r["fill0"]):
            problems.append(f"fill rule broken: {r}")
        if r["n_ev"] > Z - r["fill1"]:
            problems.append(f"more evictions than free positions: {r}")
        comp = int(hit and r["pos"] != r["fill0"] - 1)
        b = r["n_cp"] - comp
        if base.setdefault(r["path"], b) != b:
            problems.append(f"copy rule broken on {r['path']}: copies={r['n_cp']} compaction={comp}")
    # ---- on-chip segments must be functions of their keys ----
    def table(keyf, seg):
        t = defaultdict(set)
        for r in allr: t[keyf(r)].add(r[seg])
        for k, v in t.items():
            if len(v) > 1: problems.append(f"segment {seg} not determined by {k}: values {sorted(v)}")
        return {k: max(v) for k, v in t.items()}
    TB = table(lambda r: (r["path"], r["n_cp"]), "B")
    TC = table(lambda r: r["n_ev"], "C")
    TD = table(lambda r: (r["w"], r["n_ev"] if r["w"] else None), "D")
    TE = table(lambda r: 0, "Ec")
    print("\nCycle model (on-chip segments, cycles):")
    print("  operation phase B by (path, copies): " + ", ".join(f"{p}/{c}={v}" for (p, c), v in sorted(TB.items())))
    print("  eviction decisions C by evictions:   " + ", ".join(f"{n}={v}" for n, v in sorted(TC.items())))
    print("  wait D, position 0 evicted into:     " + ", ".join(f"{n}={v}" for (w, n), v in sorted(TD.items(), key=lambda kv: (kv[0][0], kv[0][1] or 0)) if w)
          + f";  otherwise {TD.get((0, None), '?')}")
    print(f"  encryption Ec: {TE.get(0, '?')}")
    # ---- enumerate every combination the controller allows ----
    paths = sorted(base)
    best, missing = None, set()
    for p in paths:
        hitp = p.endswith("_bucket")
        for fill0 in (range(1, Z + 1) if hitp else range(0, Z + 1)):
            for comp in ((0, 1) if hitp and fill0 >= 2 else (0,)):
                ncp = base[p] + comp
                fill1 = fill0 - 1 if hitp else fill0
                for nev in range(0, Z - fill1 + 1):
                    w = int(fill1 == 0 and nev > 0)
                    kb, kd = (p, ncp), (w, nev if w else None)
                    if kb not in TB: missing.add(f"B{kb}"); continue
                    if nev not in TC: missing.add(f"C[{nev}]"); continue
                    if kd not in TD: missing.add(f"D{kd}"); continue
                    v = TB[kb] + TC[nev] + TD[kd]
                    if best is None or v > best[0]:
                        best = (v, dict(path=p, fill_before=fill0, compaction=comp, copies=ncp, evictions=nev, waits_for_copy=w))
    if missing: problems.append("combinations never measured (model incomplete): " + ", ".join(sorted(missing)))
    print("\nWorst on-chip combination: " + (f"{best[1]}  B+C+D = {best[0]} cycles" if best else "none"))
    ok = not problems and best is not None
    for f, rows in recs.items():
        if not rows: continue
        L0, A = max(r["L0"] for r in rows), max(r["A"] for r in rows)
        trd = max(r["t_rd"] for r in rows)
        bound = trd + L0 + A + best[0] + TE[0] if best else None
        obs = max(r["t_e"] for r in rows)
        hit = [r for r in rows if best and r["path"] == best[1]["path"] and r["n_cp"] == best[1]["copies"]
               and r["n_ev"] == best[1]["evictions"] and r["w"] == best[1]["waits_for_copy"]]
        wmax = max((r["t_w"] for r in rows if r["t_w"] >= 0), default=-1)
        print(f"\n{os.path.basename(f)}: {len(rows)} accesses")
        print(f"  memory: read issued at {trd}; first position landed {min(r['L0'] for r in rows)}..{L0} cycles later; "
              f"rest of verification {min(r['A'] for r in rows)}..{A}")
        if bound is not None:
            print(f"  derived worst encryption end = {trd} + {L0} + {A} + {best[0]} + {TE[0]} = {bound}")
            print(f"  observed worst encryption end = {obs}  (worst combination reached by {len(hit)} traced access(es))")
            print(f"  deadline {deadline}: margin {deadline - bound} cycles")
            if bound > deadline: ok = False; problems.append(f"{os.path.basename(f)}: bound {bound} exceeds deadline {deadline}")
            if obs > bound: ok = False; problems.append(f"{os.path.basename(f)}: an access ({obs}) exceeded the derived bound ({bound})")
        print(f"  write-back done at most {wmax} (completion gate {CT_DONE}, margin {CT_DONE - wmax}; memory-dependent)")
        if wmax > CT_DONE: ok = False; problems.append(f"{os.path.basename(f)}: write-back done {wmax} after CT_DONE {CT_DONE}")
    print()
    for pr in problems[:20]: print("  PROBLEM: " + pr)
    print("RESULT: " + ("PASS (cycle model explains every access; derived worst case fits the budget)" if ok else "FAIL"))
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main(sys.argv))
