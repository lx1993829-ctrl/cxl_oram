# ghash_ref.py -- independent GHASH reference (NIST SP 800-38D, Algorithm 1), self-checked against
# GCM test case 2; writes 300 random messages (1 to 300 blocks) with H, H^2, H^3 and expected GHASH.
import random
R = 0xE1 << 120
def gmul(X, Y):                      # NIST SP 800-38D, Algorithm 1 (bit 0 of a block = MSB)
    Z, V = 0, Y
    for i in range(127, -1, -1):
        if (X >> i) & 1: Z ^= V
        V = (V >> 1) ^ R if V & 1 else V >> 1
    return Z
def ghash(H, blocks):
    Y = 0
    for X in blocks: Y = gmul(Y ^ X, H)
    return Y
# self-check against GCM test case 2 (key 0, IV 0, one zero block)
H = 0x66e94bd4ef8a2c3b884cfa59ca342b2e
C = 0x0388dace60b6a392f328c2b971b2fe78
L = 0x00000000000000000000000000000080
g = ghash(H, [C, L])
assert g == 0xf38cbb1ad69223dcc3457ae5b6b0f885, hex(g)
print("reference GHASH matches GCM test case 2:", hex(g))
random.seed(2026)
words = []
nmsg = 300
for m in range(nmsg):
    Hk = random.getrandbits(128) | 1
    n = random.choice([1, 2, 3, 4, 5, 7, 8, 13]) if m < 200 else random.randint(50, 300)
    blocks = [random.getrandbits(128) for _ in range(n)]
    H2 = gmul(Hk, Hk); H3 = gmul(H2, Hk)
    words += [n, Hk, H2, H3, ghash(Hk, blocks)] + blocks
import sys
with open(sys.argv[1] if len(sys.argv) > 1 else "vec.hex", "w") as f:
    for w in words: f.write("%032x\n" % w)
print("messages:", nmsg, "words:", len(words))
