#!/bin/bash
# Vivado XSim flow (xvlog / xelab / xsim). NOT run in the environment where these
# files were written (no Vivado there): treat the first run as a bring-up.
#   bash run_xsim.sh            # self-test + tamper + non-interference
# The testbenches are plain Verilog-2001 (they also compile as SystemVerilog).
# If XSim mis-simulates the lease table (the reason the original testbench forced
# val_valid), you will see lease failures from T1 on. Only then add
#   -d XSIM_FORCE_LEASE_VALID  to the xvlog lines below -- that BYPASSES lease
# checking, so T46/T47 (which now check that bad requests are rejected) will fail.
set -u
cd "$(dirname "$0")"
RTL=../rtl
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
mkdir -p build && cd build
RTLX=$(for f in $SRCS; do echo -n "../$f "; done)
# ---- self-test (debug ports, SIMULATION) ----
xvlog -i ../$RTL -d SIMULATION -d ORAM_DEBUG_PORTS $RTLX ../$RTL/onboard_test_top.v > xvlog_selftest.log 2>&1 || { echo "xvlog failed (build/xvlog_selftest.log)"; exit 2; }
xvlog -i ../$RTL -d SIMULATION -d ORAM_DEBUG_PORTS ../tb_onboard_test_top.v ../oram_timing_monitor.v >> xvlog_selftest.log 2>&1 || { echo "xvlog tb failed"; exit 2; }
xelab -debug off -top tb_onboard_test_top -snapshot selftest > xelab_selftest.log 2>&1 || { echo "xelab failed (build/xelab_selftest.log)"; exit 2; }
xsim selftest -R > xsim_selftest.log 2>&1;           grep -E "Fail count|ALL .*PASS|FAILURE" xsim_selftest.log
xsim selftest -R -testplusarg tamper_hole > xsim_tamper_hole.log 2>&1;     grep "TAMPER RESULT" xsim_tamper_hole.log
xsim selftest -R -testplusarg tamper_target > xsim_tamper_target.log 2>&1; grep "TAMPER RESULT" xsim_tamper_target.log
# ---- non-interference (separate compile: different defines) ----
xvlog -i ../$RTL -d ORAM_DEBUG_PORTS $RTLX > xvlog_ni.log 2>&1 && xvlog -i ../$RTL -d ORAM_DEBUG_PORTS ../tb_ni.v ../oram_timing_monitor.v >> xvlog_ni.log 2>&1 \
    && xelab -debug off -top tb_ni -snapshot ni > xelab_ni.log 2>&1 || { echo "tb_ni compile/elab failed (build/x*_ni.log)"; exit 2; }
for v in 0 1 2 3; do
    xsim ni -R -testplusarg ni=$v -testplusarg ops=10 > xsim_ni$v.log 2>&1
    grep "NI:" xsim_ni$v.log | grep -oE "variant=[0-9]|errors=[0-9]+|trace-hash=[0-9a-f]+" | tr '\n' ' '; echo
done
echo "Pass criteria: ALL 53 TESTS PASSED; both TAMPER RESULT: DETECTED; the four trace-hash values identical, errors=0."
