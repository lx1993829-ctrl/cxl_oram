// tb_stash.v -- stash_hbm (windows + chains through a bounded pool) against an exact reference model, driven like the
// controller: open, wait ready, the requested block (read / write, then remap or insert), evictions while the bucket
// has room, commit, wait quiet. Checks every eviction in order, every block's data after HBM round trips, every pool
// index an insert allocates, the chain step, and that the ONLY error is pool exhaustion, exactly when it happens.
// +pool=P (default N) or +poolpct=pct of N, +acc=A, +seed=S, +hot=pct (new targets drawn from 2 hot buckets), +same=pct, +overflow (expect
// the pool to run out: checks ins_full and the fail-stop at exactly that insert)
`timescale 1ns/1ps
`include "oram_params.vh"
module tb_stash;
    localparam N = `ORAM_N, B = `ORAM_B, Z = `ORAM_Z, BEATS = `BEATS_PER_BLOCK, DW = 256, W =
`ifdef TB_STASH_W
        `TB_STASH_W;
`else
        `ORAM_Z + 1;
`endif
    localparam PTW = `STASH_PTR_W, BW = `BUCKET_ID_W, SA = `SLOT_ADDR_W, BTW = `BEAT_CNT_W, PW = $clog2(N);
    localparam integer WORDS = (((B * 128 + 4095) / 4096) * 4096 + ((N * 16 + 4095) / 4096) * 4096 + N * BEATS * 32) / 32 + 64;   // heads up to 4 beats
    reg clk = 0, rst_n = 0; always #1 clk = ~clk;
    reg init_go = 0; wire init_done; reg [PW:0] pool_n = 0;
    reg open_en = 0; reg [BW-1:0] ob, obt; reg [SA-1:0] os; reg oin; reg [PW-1:0] opx; wire ready; reg commit = 0;
    wire cs_hit; wire [PTW-1:0] cs_idx; wire cb_hit; wire [PTW-1:0] cb_idx; wire [SA-1:0] cb_slot; wire cb_busy;
    reg [SA-1:0] ins_slot; reg [BW-1:0] ins_tgt; reg ins_en = 0; wire [PTW-1:0] ins_idx; wire [PW-1:0] ins_pidx; wire ins_full;
    reg [PTW-1:0] rm_idx; reg rm_en = 0; reg [PTW-1:0] ev_idx; reg ev_en = 0;
    reg [PTW-1:0] dw_e; reg [BTW-1:0] dw_b; reg [DW-1:0] dw_d; reg dw_en = 0;
    reg [PTW-1:0] dr_e; reg [BTW-1:0] dr_b; reg dr_en = 0; wire [DW-1:0] dr_d; wire dr_v;
    wire [PTW:0] occ; wire quiet, err;
    wire [63:0] araddr, awaddr; wire [7:0] arlen, awlen; wire [2:0] arsize, awsize; wire [1:0] arburst, awburst;
    wire arvalid, arready, rlast, rvalid, rready, awvalid, awready, wlast, wvalid, wready, bvalid, bready;
    wire [DW-1:0] rdata, wdata; wire [DW/8-1:0] wstrb;
    stash_hbm dut (.clk(clk), .rst_n(rst_n), .init_go(init_go), .nb(B[BW:0]), .pool_n(pool_n), .init_done(init_done),
        .open_en(open_en), .open_b(ob), .open_bt(obt), .open_slot(os), .open_instash(oin), .open_pidx(opx), .ready(ready), .commit(commit),
        .cam_slot_addr(os), .cam_slot_en(1'b1), .cam_slot_hit(cs_hit), .cam_slot_idx(cs_idx),
        .cam_bkt_target(ob), .cam_bkt_en(1'b1), .cam_bkt_hit(cb_hit), .cam_bkt_idx(cb_idx), .cam_bkt_slot_addr(cb_slot), .cam_bkt_inhibit_busy(cb_busy),
        .ins_slot_addr(ins_slot), .ins_target_bucket(ins_tgt), .ins_en(ins_en), .ins_idx(ins_idx), .ins_pidx(ins_pidx), .ins_full(ins_full),
        .remap_idx(rm_idx), .remap_new_bucket(obt), .remap_en(rm_en), .evict_idx(ev_idx), .evict_en(ev_en),
        .dwr_entry(dw_e), .dwr_beat(dw_b), .dwr_data(dw_d), .dwr_en(dw_en), .drd_entry(dr_e), .drd_beat(dr_b), .drd_en(dr_en),
        .drd_data(dr_d), .drd_valid(dr_v), .occupancy(occ), .wr_quiet(quiet), .err(err),
        .m_araddr(araddr), .m_arlen(arlen), .m_arsize(arsize), .m_arburst(arburst), .m_arvalid(arvalid), .m_arready(arready),
        .m_rdata(rdata), .m_rlast(rlast), .m_rvalid(rvalid), .m_rready(rready),
        .m_awaddr(awaddr), .m_awlen(awlen), .m_awsize(awsize), .m_awburst(awburst), .m_awvalid(awvalid), .m_awready(awready),
        .m_wdata(wdata), .m_wstrb(wstrb), .m_wlast(wlast), .m_wvalid(wvalid), .m_wready(wready), .m_bvalid(bvalid), .m_bready(bready));
    axi_mem_model #(.DW(DW), .WORDS(WORDS), .BASE(64'd0), .RLAT(53)) mem (.clk(clk), .rst_n(rst_n),
        .araddr(araddr), .arlen(arlen), .arvalid(arvalid), .arready(arready), .rdata(rdata), .rresp(), .rlast(rlast), .rvalid(rvalid), .rready(rready),
        .awaddr(awaddr), .awlen(awlen), .awvalid(awvalid), .awready(awready), .wdata(wdata), .wstrb(wstrb), .wlast(wlast), .wvalid(wvalid),
        .wready(wready), .bresp(), .bvalid(bvalid), .bready(bready));

    // ---------------- reference model ----------------
    integer loc [0:N-1], bk [0:N-1], px [0:N-1], ver [0:N-1], fill [0:B-1];
    integer win [0:B-1][0:W-1]; integer wn [0:B-1];            // window: slots in order
    integer ch  [0:B-1][0:N-1]; integer cn [0:B-1];            // chain: slots, [0] = head
    integer fs [0:N-1]; integer fsn, fresh, P;                 // free stack (top = fs[fsn-1])
    integer fails = 0, accesses = 0, evs = 0, steps = 0, chained = 0, maxw = 0, maxc = 0, maxst = 0, used = 0, seed, hot, samep, A;
    reg ovf_mode; integer ovf_seen = 0;
    integer short_acc = 0, short_slots = 0;
    integer force_bt = -1;                    // >= 0: the next accesses remap to this bucket (directed scenario)   // reads that moved in fewer slots than fit (Z + 1 candidates: none)
    task fail; input [8*56-1:0] m; begin fails = fails + 1; if (fails < 8) $display("FAIL @%0d: %0s", accesses, m); end endtask
    function [DW-1:0] pat; input integer s; input integer v; input integer k; begin pat = {8{s[11:0], v[11:0], k[7:0]}}; end endfunction
    integer rs; function integer rnd; input integer m; begin rs = rs ^ (rs << 13); rs = rs ^ (rs >>> 17); rs = rs ^ (rs << 5); rnd = ((rs % m) + m) % m; end endfunction
    task w_remove; input integer b; input integer pos; integer q; begin for (q = pos; q < wn[b] - 1; q = q + 1) win[b][q] = win[b][q+1]; wn[b] = wn[b] - 1; end endtask
    task c_remove; input integer b; input integer s; integer q, f; begin f = 0;
        for (q = 0; q < cn[b]; q = q + 1) begin if (f) ch[b][q-1] = ch[b][q]; if (ch[b][q] == s) f = 1; end
        if (!f) fail("model: chain entry missing"); cn[b] = cn[b] - 1; end endtask
    task link; input integer b; input integer s; integer q; begin      // into b: window if room, else chain head
        if (wn[b] < W) begin win[b][wn[b]] = s; wn[b] = wn[b] + 1; end
        else begin for (q = cn[b]; q > 0; q = q - 1) ch[b][q] = ch[b][q-1]; ch[b][0] = s; cn[b] = cn[b] + 1; end
    end endtask
    task read_chk; input integer h; input integer s; integer k; begin
        for (k = 0; k < BEATS; k = k + 1) begin
            @(negedge clk); dr_e = h; dr_b = k; dr_en = 1; @(negedge clk); dr_en = 0;
            if (!dr_v || dr_d !== pat(s, ver[s], k)) fail("block data");
        end end endtask
    task write_new; input integer h; input integer s; integer k; begin
        ver[s] = ver[s] + 1;
        for (k = 0; k < BEATS; k = k + 1) begin @(negedge clk); dw_e = h; dw_b = k; dw_d = pat(s, ver[s], k); dw_en = 1; end
        @(negedge clk); dw_en = 0; end endtask

    task access; input integer s; integer b, bt, h, q, pos, free, ch0, exp_alloc; reg put, inst;
    begin
        b = bk[s]; inst = loc[s];
        if (force_bt >= 0) bt = force_bt; else if (rnd(100) < samep) bt = b; else if (rnd(100) < hot) bt = rnd(2); else bt = rnd(B);
        ch0 = (cn[b] > 0) ? ch[b][0] : -1;
        @(negedge clk); ob = b; obt = bt; os = s << 12; oin = inst; opx = inst ? px[s] : 0; open_en = 1; @(negedge clk); open_en = 0;
        while (!ready) @(negedge clk);
        if (cs_hit !== inst) fail("requested: stashed or not");
        put = rnd(2);
        if (inst) begin                                         // in the stash: read, maybe write, remap
            read_chk(0, s); if (put) write_new(0, s);
            @(negedge clk); rm_idx = 0; rm_en = 1; @(negedge clk); rm_en = 0;
            if (bt != b) begin
                pos = -1; for (q = 0; q < wn[b]; q = q + 1) if (win[b][q] == s) pos = q;
                if (pos >= 0) w_remove(b, pos); else c_remove(b, s);
                link(bt, s);
            end
            bk[s] = bt;
        end else begin                                          // in the bucket: it leaves it, gets a pool entry
            fill[b] = fill[b] - 1;
            exp_alloc = (fresh < P) ? fresh : ((fsn > 0) ? fs[fsn-1] : -1);
            if (ins_full !== (exp_alloc < 0)) fail("ins_full");
            if (exp_alloc < 0) begin                            // the pool is exhausted: the one fail-stop
                if (!ovf_mode) fail("pool exhausted (unexpected)");
                if (err) fail("error before the overflow");
                @(negedge clk); ins_slot = s << 12; ins_tgt = bt; ins_en = 1; @(negedge clk); ins_en = 0; @(negedge clk);
                if (!err) fail("no fail-stop on pool exhaustion");
                ovf_seen = 1;
            end else begin
            if (ins_pidx !== exp_alloc) fail("allocated pool index");
            h = ins_idx;
            @(negedge clk); ins_slot = s << 12; ins_tgt = bt; ins_en = 1; @(negedge clk); ins_en = 0;
            if (fresh < P) fresh = fresh + 1; else fsn = fsn - 1;
            write_new(h, s);
            loc[s] = 1; bk[s] = bt; px[s] = exp_alloc; used = used + 1;
            link(bt, s);
            end
        end
        if (!ovf_seen) begin
        // evictions into b, in window order
        free = Z - fill[b];
        while (free > 0 && wn[b] > 0) begin
            repeat (2) @(negedge clk); while (cb_busy) @(negedge clk); @(negedge clk);
            if (!cb_hit) begin fail("no eviction candidate"); free = 0; end
            else begin
                q = win[b][0];
                if ((cb_slot >> 12) !== q) fail("eviction order");
                h = cb_idx; read_chk(h, q);
                @(negedge clk); ev_idx = h; ev_en = 1; @(negedge clk); ev_en = 0;
                w_remove(b, 0); fill[b] = fill[b] + 1; loc[q] = 0; bk[q] = b; fs[fsn] = px[q]; fsn = fsn + 1; used = used - 1;
                free = free - 1; evs = evs + 1;
            end
        end
        repeat (2) @(negedge clk); while (cb_busy) @(negedge clk); @(negedge clk);
        if (wn[b] == 0 && cb_hit) fail("a candidate that should not exist");
        if (free > 0 && cn[b] > 0) begin                       // room left, yet slots for b still wait in the stash
            short_acc = short_acc + 1; short_slots = short_slots + ((free < cn[b]) ? free : cn[b]);
        end
        // commit: the chain step (b's chain head as read at open, still the head, room in the window)
        if (cn[b] > 0) chained = chained + 1;
        if (cn[b] > 0 && ch0 >= 0 && ch[b][0] == ch0 && wn[b] < W) begin
            win[b][wn[b]] = ch0; wn[b] = wn[b] + 1;
            for (q = 0; q < cn[b] - 1; q = q + 1) ch[b][q] = ch[b][q+1]; cn[b] = cn[b] - 1; steps = steps + 1;
        end
        @(negedge clk); commit = 1; @(negedge clk); commit = 0;
        while (!quiet) @(negedge clk);
        if (err) fail("unexpected error");
        if (used > maxst) maxst = used;
        for (q = 0; q < B; q = q + 1) begin if (wn[q] > maxw) maxw = wn[q]; if (cn[q] > maxc) maxc = cn[q]; end
        accesses = accesses + 1;
        end
    end endtask

    integer i, t;
    initial begin
        if (!$value$plusargs("seed=%d", seed)) seed = 11; rs = seed * 2654435761 + 1;
        if (!$value$plusargs("acc=%d", A)) A = 3000;
        if (!$value$plusargs("hot=%d", hot)) hot = 0;
        if (!$value$plusargs("same=%d", samep)) samep = 10;
        if (!$value$plusargs("pool=%d", P)) P = N;
        if ($value$plusargs("poolpct=%d", i)) P = (N * i) / 100;     // a pool as a share of N
        ovf_mode = $test$plusargs("overflow");
        pool_n = (P == N) ? 0 : P;
        for (i = 0; i < N; i = i + 1) begin loc[i] = 0; bk[i] = i % B; px[i] = 0; ver[i] = 0; end
        for (i = 0; i < B; i = i + 1) begin fill[i] = 0; wn[i] = 0; cn[i] = 0; end
        for (i = 0; i < N; i = i + 1) fill[i % B] = fill[i % B] + 1;
        fsn = 0; fresh = 0;
        repeat (4) @(negedge clk); rst_n = 1; @(negedge clk); init_go = 1; @(negedge clk); init_go = 0;
        while (!init_done) @(negedge clk);
        if ($test$plusargs("directed")) begin : directed
            // the counterexample for W = Z: bucket X empty, W + 1 slots waiting for it (a full candidate list plus one
            // overflow entry), then a candidate is requested and remapped away: W - 1 candidates for Z free positions
            integer X, k, cnt0, src;
            X = 5; cnt0 = short_acc;
            for (k = 0; X + k * B < N; k = k + 1) begin force_bt = X + 1; access(X + k * B); end  // empty X (every block of it, any lambda)
            src = 0;
            for (k = 0; k < W + 1; k = k + 1) begin                                                // W + 1 waiting for X
                while (loc[src] != 0 || bk[src] == X || bk[src] == X + 1 || bk[src] == X + 4) src = src + 1;
                force_bt = X; access(src); src = src + 1;
            end
            if (fill[X] != 0 || wn[X] != W || cn[X] != 1) fail("directed: scenario not set up");
            force_bt = X + 4; access(win[X][0]);                                                    // request a candidate
            force_bt = -1;
            $display("directed: bucket %0d empty, %0d candidates + 1 overflow entry; requesting a candidate: %0s",
                     X, W, (short_acc > cnt0) ? "fewer slots moved in than fit" : "every waiting slot that fits moved in");
        end
        for (t = 0; t < A && !ovf_seen && fails < 8; t = t + 1) access(rnd(N));
        $display("stash_hbm: %0d accesses, %0d evictions, %0d chain steps, %0d accesses with a chain; peak %0d blocks in a pool of %0d, longest window %0d, longest chain %0d; shortfalls %0d (%0d slots)%s",
                 accesses, evs, steps, chained, maxst, P, maxw, maxc, short_acc, short_slots, ovf_mode ? (ovf_seen ? ", pool exhausted: fail-stop exactly there" : ", pool NOT exhausted") : "");
        if (ovf_mode && !ovf_seen) fails = fails + 1;
        if (short_acc > 0 && !$test$plusargs("allow_short")) begin fails = fails + 1; $display("FAIL: %0d reads moved in fewer slots than fit", short_acc); end
        if (fails == 0) $display("*** STASH_HBM: ALL CHECKS PASSED ***"); else $display("*** STASH_HBM: %0d FAILURE(S) ***", fails);
        $finish;
    end
endmodule
