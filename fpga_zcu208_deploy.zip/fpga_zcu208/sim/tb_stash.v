// tb_stash.v -- stash_hbm against a reference model, driven like the controller (open, wait ready, slot
// search, GET/PUT on a stashed block + remap, or insert, then evictions, commit, wait quiet), with the
// U55C's measured HBM latency profile. A growth phase sends blocks to 4 buckets only and fills the pool
// (long lists, deep reuse of freed indices). A last phase makes writes land 200 cycles late and opens each
// access as soon as the previous commit has issued its writes: a fetch that overtook them would be stale.
`timescale 1ns/1ps
`include "oram_params.vh"
module tb_stash;
    localparam N = `ORAM_N, B = `ORAM_B, Z = `ORAM_Z, BEATS = `BEATS_PER_BLOCK, DW = 256;
    localparam PW = `STASH_PTR_W, BW = `BUCKET_ID_W, SA = `SLOT_ADDR_W, BTW = `BEAT_CNT_W;
    localparam LIST_BYTES = `ORAM_STASH_SLOTS * 8;
    localparam integer POOLB = ((B * LIST_BYTES + 4095) / 4096) * 4096;
    localparam integer WORDS = (POOLB + `ORAM_STASH_DEPTH * BEATS * 32) / 32 + 64;
    reg clk = 0, rst_n = 0; always #1.667 clk = ~clk;
    reg open_en = 0, commit = 0, ins_en = 0, remap_en = 0, evict_en = 0, dwr_en = 0, drd_en = 0, cbe = 0;
    reg [BW-1:0] ob = 0, obt = 0, cbt = 0, ins_t = 0, rmb = 0; reg [SA-1:0] os = 0, cs = 0, ins_s = 0;
    reg [PW-1:0] rmi = 0, evi = 0, dwe = 0, dre = 0; reg [BTW-1:0] dwb = 0, drb = 0; reg [DW-1:0] dwd = 0;
    wire init_done, ready, cs_hit, cb_hit, cb_busy, ins_full, drd_v, quiet, err; wire [PW-1:0] cs_idx, cb_idx, ins_idx;
    wire [SA-1:0] cb_slot; wire [DW-1:0] drd_d; wire [PW:0] occ;
    wire [63:0] araddr, awaddr; wire [7:0] arlen, awlen; wire arvalid, arready, rvalid, rlast, rready, awvalid, awready, wvalid, wready, wlast, bvalid, bready;
    wire [DW-1:0] rdata, wdata; wire [DW/8-1:0] wstrb;
    reg init_go = 0;
    stash_hbm dut (.clk(clk), .rst_n(rst_n), .init_go(init_go), .init_done(init_done), .open_en(open_en), .open_b(ob), .open_bt(obt), .open_slot(os),
        .ready(ready), .commit(commit), .cam_slot_addr(cs), .cam_slot_en(1'b1), .cam_slot_hit(cs_hit), .cam_slot_idx(cs_idx),
        .cam_bkt_target(cbt), .cam_bkt_en(cbe), .cam_bkt_hit(cb_hit), .cam_bkt_idx(cb_idx), .cam_bkt_slot_addr(cb_slot),
        .cam_bkt_inhibit_busy(cb_busy), .ins_slot_addr(ins_s), .ins_target_bucket(ins_t), .ins_en(ins_en), .ins_idx(ins_idx),
        .ins_full(ins_full), .remap_idx(rmi), .remap_new_bucket(rmb), .remap_en(remap_en), .evict_idx(evi), .evict_en(evict_en),
        .dwr_entry(dwe), .dwr_beat(dwb), .dwr_data(dwd), .dwr_en(dwr_en), .drd_entry(dre), .drd_beat(drb), .drd_en(drd_en),
        .drd_data(drd_d), .drd_valid(drd_v), .occupancy(occ), .wr_quiet(quiet), .err(err),
        .m_araddr(araddr), .m_arlen(arlen), .m_arsize(), .m_arburst(), .m_arvalid(arvalid), .m_arready(arready), .m_rdata(rdata), .m_rlast(rlast), .m_rvalid(rvalid), .m_rready(rready),
        .m_awaddr(awaddr), .m_awlen(awlen), .m_awsize(), .m_awburst(), .m_awvalid(awvalid), .m_awready(awready), .m_wdata(wdata), .m_wstrb(wstrb), .m_wlast(wlast), .m_wvalid(wvalid), .m_wready(wready), .m_bvalid(bvalid), .m_bready(bready));
    axi_mem_model #(.DW(DW), .WORDS(WORDS), .BASE(64'd0), .RLAT(53)) mem (.clk(clk), .rst_n(rst_n),
        .araddr(araddr), .arlen(arlen), .arvalid(arvalid), .arready(arready), .rdata(rdata), .rresp(), .rlast(rlast), .rvalid(rvalid), .rready(rready),
        .awaddr(awaddr), .awlen(awlen), .awvalid(awvalid), .awready(awready), .wdata(wdata), .wstrb(wstrb), .wlast(wlast), .wvalid(wvalid), .wready(wready), .bresp(), .bvalid(bvalid), .bready(bready));
    integer refst [0:N-1];                 // -1: not stashed; else the target bucket
    reg [DW-1:0] refd [0:N*BEATS-1];       // a stashed block's data
    integer nst = 0, fails = 0, checks = 0, accesses = 0, evictions = 0, seed = 21, j, t, b, bt, s, x, fill, idx, grow = 0, peak = 0, maxw = 0, early = 0, s2, c2;
    reg hit;
    integer nev, evx [0:15], evh [0:15];
    // xorshift32: Verilator's $random(seed) gave a degenerate sequence here (a shifting bit pattern that
    // touched only ~10 slots), so the test uses its own generator
    reg [31:0] rs = 32'h2545F491;
    function [31:0] rnd; input dummy; begin rs = rs ^ (rs << 13); rs = rs ^ (rs >> 17); rs = rs ^ (rs << 5); rnd = rs; end endfunction
    task fail; input [8*48-1:0] m; begin fails = fails + 1; if (fails < 6) $display("FAIL @%0d: %0s", accesses, m); end endtask
    task pulse_open; begin @(negedge clk); ob = b; obt = bt; os = s << 12; open_en = 1; @(negedge clk); open_en = 0;
        t = 0; while (!ready && t < 20000) begin @(negedge clk); t = t + 1; end
        if (!ready) fail("ready never rose"); end endtask
    task read_chk; input integer e; input integer slot; begin : rc integer q;
        for (q = 0; q < BEATS; q = q + 1) begin
            @(negedge clk); dre = e; drb = q; drd_en = 1; @(negedge clk); drd_en = 0;
            checks = checks + 1;
            if (!drd_v || drd_d !== refd[slot * BEATS + q]) fail("block data differs");
        end end endtask
    task write_new; input integer e; input integer slot; begin : wn integer q;
        for (q = 0; q < BEATS; q = q + 1) begin
            @(negedge clk); dwe = e; dwb = q; dwd = {8{rnd(0)}}; dwr_en = 1; refd[slot * BEATS + q] = dwd; @(negedge clk); dwr_en = 0;
        end end endtask
    task access; input integer slot; input put; begin
        s = slot; accesses = accesses + 1;
        b  = (refst[s] >= 0) ? refst[s] : (rnd(0) % B);
        bt = grow ? (rnd(0) % 4)                     // growth: few targets, long lists
                  : (((rnd(0) % 5) == 0) ? b : (rnd(0) % B));
        pulse_open;
        begin : lists_match                                                     // the fetched lists must be exact
            integer q, na, nt, ra, rt;
            na = 0; nt = 0; ra = 0; rt = 0;
            for (q = 0; q < N; q = q + 1) begin if (refst[q] == b) ra = ra + 1; if (refst[q] == bt) rt = rt + 1; end
            for (q = 0; q < `ORAM_STASH_SLOTS; q = q + 1) begin
                if (dut.la_v[q]) begin na = na + 1; if (refst[dut.la_s[q]] != b) fail("b's list holds a block not waiting for b"); end
                if (!dut.same && dut.lt_v[q]) begin nt = nt + 1; if (refst[dut.lt_s[q]] != bt) fail("bt's list holds a block not waiting for bt"); end
            end
            checks = checks + 1;
            if (na != ra || (!dut.same && nt != rt)) fail("a fetched list is missing blocks (stale)");
        end
        @(negedge clk); cs = s << 12; @(negedge clk);                          // slot search (S_SCAN)
        checks = checks + 1;
        if (cs_hit !== (refst[s] >= 0)) fail("slot search wrong");
        if (refst[s] >= 0) begin                                                // stash hit
            idx = cs_idx; read_chk(idx, s);
            if (put) write_new(idx, s);
            @(negedge clk); rmi = idx; rmb = bt; remap_en = 1; @(negedge clk); remap_en = 0; refst[s] = bt;
        end else begin                                                          // into the stash
            if (ins_full) fail("stash full");
            @(negedge clk); idx = ins_idx; ins_s = s << 12; ins_t = bt; ins_en = 1; @(negedge clk); ins_en = 0;
            refst[s] = bt; nst = nst + 1; write_new(idx, s);
        end
        fill = ((rnd(0) & 1) == 0) ? 0 : (rnd(0) % (Z + 1));   // free positions in the bucket
        if (grow) fill = (nst < `ORAM_STASH_DEPTH - 12) ? Z : Z - 2;   // growth: fill the pool, then hover near full
        if (grow && nst < `ORAM_STASH_DEPTH - 12) fill = ((rnd(0) % 8) == 0) ? Z - 1 : Z;   // growth: rare evictions
        // evictions exactly as the controller does them: ask, honor busy, evict, ask again the very next
        // cycle; the evicted blocks are read afterwards (the background copy)
        nev = 0;
        @(negedge clk); cbt = b; cbe = 1; #0.1;                                // let the comparison settle
        while (fill < Z) begin
            while (cb_busy) @(negedge clk);
            if (!cb_hit) fill = Z;
            else begin
                x = cb_slot >> 12; checks = checks + 1;
                if (refst[x] != b) fail("candidate not waiting for this bucket");
                evx[nev] = x; evh[nev] = cb_idx; nev = nev + 1;
                evi = cb_idx; evict_en = 1; @(negedge clk); evict_en = 0;
                refst[x] = -1; nst = nst - 1; evictions = evictions + 1; fill = fill + 1;
            end
        end
        cbe = 0;
        for (j = 0; j < nev; j = j + 1) read_chk(evh[j], evx[j]);
        @(negedge clk); commit = 1; @(negedge clk); commit = 0;
        t = 0;
        if (early) begin                                   // open the next access once the commit has ISSUED its writes
            @(negedge clk); while ((dut.c_pend || dut.job != 1) && t < 20000) begin @(negedge clk); t = t + 1; end
        end else begin
            while (!quiet && t < 20000) begin @(negedge clk); t = t + 1; end
            if (!quiet) fail("not quiet after commit");
        end
        if (occ != nst) fail("occupancy differs from the reference");
        if (nst > peak) peak = nst;
        begin : wcount integer q, c; c = 0; for (q = 0; q < N; q = q + 1) if (refst[q] == b) c = c + 1; if (c > maxw) maxw = c; end
        if (err) fail("error flagged");
    end endtask
    integer k;
    initial begin
        mem.slow_pct = 2; mem.slow_extra = 105; mem.wlat = 26;
        for (k = 0; k < N; k = k + 1) refst[k] = -1;
        repeat (8) @(posedge clk); rst_n = 1;
        repeat (20) @(negedge clk);                                             // nothing happens before boot starts it
        if (init_done || awvalid) fail("lists touched before init_go");
        init_go = 1; @(negedge clk); init_go = 0;
        t = 0; while (!init_done && t < 200000) begin @(negedge clk); t = t + 1; end
        if (!init_done) fail("lists never initialized");
        for (k = 0; k < 2500; k = k + 1) access(rnd(0) % N, rnd(0) & 1);
        grow = 1;                                                               // fill the pool, then drain it
        for (k = 0; k < 1500; k = k + 1) begin
            // below the cap: blocks not yet stashed (each access inserts); at the cap: stashed blocks, so the
            // bucket opened is one of the 4 targets and has blocks waiting to be evicted (the pool hovers near full)
            s2 = rnd(0) % N; c2 = 0;
            while (((nst < `ORAM_STASH_DEPTH - 12) ? (refst[s2] >= 0) : (refst[s2] < 0)) && c2 < 200) begin s2 = rnd(0) % N; c2 = c2 + 1; end
            access(s2, rnd(0) & 1);
        end
        grow = 0;
        mem.wlat = 200; early = 1;                                              // writes land late; open early
        for (k = 0; k < 600; k = k + 1) access(rnd(0) % N, rnd(0) & 1);
        early = 0; t = 0; while (!quiet && t < 20000) begin @(negedge clk); t = t + 1; end
        if (mem.perr != 0) fail("AXI protocol violations");
        $display("stash_hbm: %0d accesses, %0d evictions, %0d checks, %0d mismatches; peak %0d blocks stashed, most %0d waiting for one bucket", accesses, evictions, checks, fails, peak, maxw);
        if (fails == 0) $display("*** STASH_HBM: ALL CHECKS PASSED ***");
        $finish;
    end
    initial begin #400000000; $display("FAIL: TIMEOUT"); $finish; end
endmodule
