`timescale 1ns/1ps
`include "oram_params.vh"
// Bucket addresses at large offsets (build with -DORAM_N=1048576, as the 1M builds).
// For each chosen bucket b: a full read and a full write-back through axi_master. Every AR and AW burst must
// start where the previous one ended, starting at b * BUCKET_BYTES; no burst may cross a 4 KB page; the bursts
// must cover exactly BUCKET_BYTES. At 4 KB blocks the chosen buckets reach past 4 GB (bucket 104857 straddles it),
// so a 32-bit address path, which wraps there, fails this test.
module tb_addr_wide;
    localparam integer AW = `AXI_ADDR_W, DW = `AXI_DATA_W, BW = `BUCKET_ID_W;
    localparam [63:0]  BB = `BUCKET_BYTES;
    reg clk = 0, rst_n = 0;
    always #1 clk = ~clk;

    reg              cmd_read = 0, cmd_write = 0;
    reg  [BW-1:0]    cmd_bucket = 0;
    wire             rd_done, wr_done, busy, wq, wdata_ready, wdata_stall, rdata_valid;
    wire [DW-1:0]    rdata_data;
    wire [`SCR_AW-1:0] rdata_beat_addr, wdata_beat_req;
    wire [`AXI_ID_W-1:0] arid, awid;
    wire [AW-1:0]    araddr, awaddr;
    wire [`AXI_LEN_W-1:0] arlen, awlen;
    wire [2:0]       arsize, awsize;
    wire [1:0]       arburst, awburst;
    wire             arvalid, rready, awvalid, wvalid, wlast, bready;
    wire [DW-1:0]    wdata;
    wire [`AXI_STRB_W-1:0] wstrb;

    // memory side: always ready; read data returned in order, one burst after another
    reg  [8:0]  q_len [0:255];
    integer     q_w = 0, q_r = 0, rbeat = 0, b_owed = 0;
    wire        rvalid = (q_r != q_w);
    wire        rlast  = rvalid && (rbeat == q_len[q_r % 256]);
    wire        bvalid = (b_owed != 0);

    axi_master dut (
        .clk(clk), .rst_n(rst_n), .cmd_read(cmd_read), .cmd_write(cmd_write), .cmd_bucket(cmd_bucket),
        .cmd_read_done(rd_done), .cmd_write_done(wr_done), .cmd_busy(busy), .wr_quiet(wq),
        .rdata_data(rdata_data), .rdata_valid(rdata_valid), .rdata_beat_addr(rdata_beat_addr),
        .wdata_data({DW{1'b0}}), .wdata_valid(1'b1), .wdata_ready(wdata_ready), .wdata_beat_req(wdata_beat_req),
        .wdata_hold(1'b0), .wdata_stall(wdata_stall),
        .m_axi_arid(arid), .m_axi_araddr(araddr), .m_axi_arlen(arlen), .m_axi_arsize(arsize), .m_axi_arburst(arburst),
        .m_axi_arvalid(arvalid), .m_axi_arready(1'b1),
        .m_axi_rid({`AXI_ID_W{1'b0}}), .m_axi_rdata({DW{1'b0}}), .m_axi_rresp(2'b00), .m_axi_rlast(rlast),
        .m_axi_rvalid(rvalid), .m_axi_rready(rready),
        .m_axi_awid(awid), .m_axi_awaddr(awaddr), .m_axi_awlen(awlen), .m_axi_awsize(awsize), .m_axi_awburst(awburst),
        .m_axi_awvalid(awvalid), .m_axi_awready(1'b1),
        .m_axi_wdata(wdata), .m_axi_wstrb(wstrb), .m_axi_wlast(wlast), .m_axi_wvalid(wvalid), .m_axi_wready(1'b1),
        .m_axi_bid({`AXI_ID_W{1'b0}}), .m_axi_bresp(2'b00), .m_axi_bvalid(bvalid), .m_axi_bready(bready));

    // checks
    reg  [63:0] rd_next, wr_next, rd_start, wr_start;
    integer     fails = 0, high = 0;
    task check_burst(input [63:0] a, input [63:0] len, input [63:0] exp_a, input is_wr);
        begin
            if (a !== exp_a) begin
                fails = fails + 1;
                if (fails <= 8) $display("FAIL %s burst at 0x%0h, expected 0x%0h", is_wr ? "write" : "read", a, exp_a);
            end
            if ((a % 4096) + (len + 1) * (DW / 8) > 4096) begin
                fails = fails + 1;
                if (fails <= 8) $display("FAIL %s burst at 0x%0h (%0d beats) crosses a 4 KB page", is_wr ? "write" : "read", a, len + 1);
            end
            if (a >= 64'h1_0000_0000) high = high + 1;
        end
    endtask

    always @(posedge clk) begin
        if (arvalid) begin                                   // arready is always 1
            check_burst({{(64-AW){1'b0}}, araddr}, arlen, rd_next, 0);
            rd_next <= rd_next + (arlen + 1) * (DW / 8);
            q_len[q_w % 256] <= arlen; q_w <= q_w + 1;
        end
        if (rvalid && rready) begin
            if (rlast) begin q_r <= q_r + 1; rbeat <= 0; end else rbeat <= rbeat + 1;
        end
        if (awvalid) begin                                   // awready is always 1
            check_burst({{(64-AW){1'b0}}, awaddr}, awlen, wr_next, 1);
            wr_next <= wr_next + (awlen + 1) * (DW / 8);
        end
        b_owed <= b_owed + ((wvalid && wlast) ? 1 : 0) - ((bvalid && bready) ? 1 : 0);
    end

    task do_bucket(input [63:0] b);
        integer t;
        begin
            rd_start = b * BB; wr_start = b * BB;
            @(negedge clk); rd_next = rd_start; wr_next = wr_start;
            cmd_bucket = b[BW-1:0]; cmd_read = 1; @(negedge clk); cmd_read = 0;
            t = 0; while (!rd_done && t < 200000) begin @(negedge clk); t = t + 1; end
            if (!rd_done) begin fails = fails + 1; $display("FAIL bucket %0d: read never completed", b); end
            else if (rd_next !== rd_start + BB) begin
                fails = fails + 1; $display("FAIL bucket %0d: read covered %0d bytes, expected %0d", b, rd_next - rd_start, BB);
            end
            repeat (4) @(negedge clk);
            cmd_write = 1; @(negedge clk); cmd_write = 0;
            t = 0; while (!(wr_done) && t < 200000) begin @(negedge clk); t = t + 1; end
            if (!wr_done) begin fails = fails + 1; $display("FAIL bucket %0d: write-back never completed", b); end
            t = 0; while (!wq && t < 200000) begin @(negedge clk); t = t + 1; end
            if (wr_next !== wr_start + BB) begin
                fails = fails + 1; $display("FAIL bucket %0d: write-back covered %0d bytes, expected %0d", b, wr_next - wr_start, BB);
            end
            $display("bucket %0d: 0x%0h .. 0x%0h", b, rd_start, rd_start + BB - 1);
            repeat (4) @(negedge clk);
        end
    endtask

    localparam [63:0] NBKT = 64'd1 << BW;
    initial begin
        rd_next = 0; wr_next = 0;
        repeat (8) @(negedge clk); rst_n = 1; repeat (8) @(negedge clk);
        do_bucket(0); do_bucket(1);
        if (NBKT > 104858) begin do_bucket(104857); do_bucket(104858); end
        do_bucket(NBKT / 2 + 1); do_bucket(NBKT - 1);
        $display("address width %0d bits, bucket %0d bytes, %0d bursts above 4 GB checked", AW, BB, high);
        if (fails == 0) $display("ALL CHECKS PASSED");
        else $display("%0d CHECK(S) FAILED", fails);
        $finish;
    end
endmodule
