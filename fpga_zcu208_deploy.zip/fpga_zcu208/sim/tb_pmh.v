// tb_pmh.v -- pos_map_hbm against a reference model, with the U55C's measured HBM latency profile:
// a back-to-back layout pass, random write bursts each followed at once by a checked read, then a
// phase where writes land 200 cycles late (a read that overtook a write would return stale data).
`timescale 1ns/1ps
`include "oram_params.vh"
module tb_pmh;
    localparam N = `ORAM_N, BW = `BUCKET_ID_W, DW = 256; localparam [63:0] BASE = 64'h0000_0060_0000_0000;
    reg clk = 0, rst_n = 0; always #1.667 clk = ~clk;
    localparam PXW = $clog2(N);                                   // pool index (64-bit entries)
    // slot addresses (slot << 12) are wider than 32 bits above 2^20 slots
    reg [`SLOT_ADDR_W-1:0] rd_a = 0, wr_a = 0; reg rd_en = 0, wr_en = 0; reg [BW-1:0] wr_b = 0; reg [1:0] wr_s = 0; reg [PXW-1:0] wr_p = 0;
    wire [BW-1:0] rd_b; wire [1:0] rd_s; wire [PXW-1:0] rd_p; wire rd_v, wr_rdy, quiet, err;
    wire [63:0] araddr, awaddr; wire [7:0] arlen, awlen; wire arvalid, arready, rvalid, rlast, rready, awvalid, awready, wvalid, wready, wlast, bvalid, bready;
    wire [DW-1:0] rdata, wdata; wire [DW/8-1:0] wstrb;
    pos_map_hbm dut (.clk(clk), .rst_n(rst_n), .base(BASE), .rd_slot_addr(rd_a), .rd_en(rd_en), .rd_bucket(rd_b), .rd_status(rd_s), .rd_pidx(rd_p), .rd_valid(rd_v),
        .wr_slot_addr(wr_a), .wr_bucket(wr_b), .wr_status(wr_s), .wr_pidx(wr_p), .wr_en(wr_en), .wr_ready(wr_rdy), .wr_quiet(quiet), .err(err),
        .m_araddr(araddr), .m_arlen(arlen), .m_arsize(), .m_arburst(), .m_arvalid(arvalid), .m_arready(arready), .m_rdata(rdata), .m_rlast(rlast), .m_rvalid(rvalid), .m_rready(rready),
        .m_awaddr(awaddr), .m_awlen(awlen), .m_awsize(), .m_awburst(), .m_awvalid(awvalid), .m_awready(awready), .m_wdata(wdata), .m_wstrb(wstrb), .m_wlast(wlast), .m_wvalid(wvalid), .m_wready(wready), .m_bvalid(bvalid), .m_bready(bready));
    axi_mem_model #(.DW(DW), .WORDS(N / 4 + 8), .BASE(BASE), .RLAT(53)) mem (.clk(clk), .rst_n(rst_n),
        .araddr(araddr), .arlen(arlen), .arvalid(arvalid), .arready(arready), .rdata(rdata), .rresp(), .rlast(rlast), .rvalid(rvalid), .rready(rready),
        .awaddr(awaddr), .awlen(awlen), .awvalid(awvalid), .awready(awready), .wdata(wdata), .wstrb(wstrb), .wlast(wlast), .wvalid(wvalid), .wready(wready), .bresp(), .bvalid(bvalid), .bready(bready));
    // xorshift32 (Verilator's $random(seed) can give a degenerate sequence)
    reg [31:0] rs = 32'h2545F491;
    function [31:0] rnd; input dummy; begin rs = rs ^ (rs << 13); rs = rs ^ (rs >> 17); rs = rs ^ (rs << 5); rnd = rs; end endfunction
    reg [PXW+BW+1:0] refm [0:N-1]; integer k, j, fails = 0, reads = 0, seed = 5, burst;
    task wr; input integer s; input [BW-1:0] b; input [1:0] st; begin
        @(negedge clk); while (!wr_rdy) @(negedge clk);
        wr_a = s << 12; wr_b = b; wr_s = st; wr_p = rs[PXW-1:0] ^ s[PXW-1:0]; wr_en = 1; @(negedge clk); wr_en = 0; refm[s] = {wr_p, st, b};
    end endtask
    task rd_chk; input integer s; begin
        @(negedge clk); rd_a = s << 12; rd_en = 1; @(negedge clk); rd_en = 0;
        while (!rd_v) @(negedge clk);
        if ({rd_p, rd_s, rd_b} !== refm[s]) begin fails = fails + 1; if (fails < 5) $display("FAIL slot %0d: got %b want %b", s, {rd_p, rd_s, rd_b}, refm[s]); end
        reads = reads + 1;
    end endtask
    task rounds; input integer n, maxb; begin
        for (k = 0; k < n; k = k + 1) begin
            burst = rnd(0) % maxb;
            for (j = 0; j < burst; j = j + 1) wr(rnd(0) % N, rnd(0), rnd(0));
            rd_chk(rnd(0) % N);
        end
    end endtask
    initial begin
        mem.slow_pct = 2; mem.slow_extra = 105; mem.wlat = 26;
        repeat (8) @(posedge clk); rst_n = 1;
        for (k = 0; k < N; k = k + 1) begin                                // layout: back to back, never pushing while not ready
            @(negedge clk); if (!wr_rdy) begin wr_en = 0; while (!wr_rdy) @(negedge clk); end
            wr_a = k << 12; wr_b = k % (1 << BW); wr_s = 2'b01; wr_p = (k * 7) % (1 << PXW); wr_en = 1; refm[k] = {wr_p, 2'b01, wr_b};
        end
        @(negedge clk); wr_en = 0;
        rounds(3000, 8);
        mem.wlat = 200; rounds(600, 5);                                     // writes land late
        repeat (400) @(negedge clk);
        if (!quiet) begin $display("FAIL: not quiet at the end"); fails = fails + 1; end
        if (err) begin $display("FAIL: FIFO overflow flagged"); fails = fails + 1; end
        if (mem.perr != 0) begin $display("FAIL: AXI protocol violations"); fails = fails + 1; end
        $display("pos_map_hbm: %0d reads checked, %0d mismatches", reads, fails);
        if (fails == 0) $display("*** POS_MAP_HBM: ALL CHECKS PASSED ***");
        $finish;
    end
    initial begin #50000000; $display("FAIL: TIMEOUT"); $finish; end
endmodule
