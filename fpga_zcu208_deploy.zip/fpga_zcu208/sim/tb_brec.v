// tb_brec.v -- bucket_rec_hbm against a reference model, with the U55C's measured HBM latency profile:
// a boot phase writing every record, access-like rounds (open, metadata check, IV/tag reads in random
// order, write-backs, read-back, fallback reads; half of them reopen the bucket just written), then a
// phase where writes land 200 cycles late (a fetch that overtook a write would return stale data).
`timescale 1ns/1ps
`include "oram_params.vh"
module tb_brec;
    localparam B = `ORAM_B, Z = `ORAM_Z, BW = `BUCKET_ID_W, SW = `SLOT_ID_W, FW = `FILL_CNT_W, PW = `POS_IN_BKT_W, DW = 256;
    localparam [63:0] BASE = 64'h0000_0070_0000_0000;
    reg clk = 0, rst_n = 0; always #1.667 clk = ~clk;
    reg [BW-1:0] bm_rb = 0, bm_wb = 0; reg bm_re = 0, bm_we = 0; reg [Z*SW-1:0] bm_wl = 0; reg [FW-1:0] bm_wf = 0;
    reg [31:0] iv_ra = 0, iv_wa = 0; reg iv_re = 0, iv_we = 0; reg [95:0] iv_wi = 0; reg [127:0] iv_wt = 0;
    wire [Z*SW-1:0] bm_rl; wire [FW-1:0] bm_rf; wire bm_rv; wire [95:0] iv_ri; wire [127:0] iv_rt; wire iv_rv, wr_rdy, quiet, err;
    wire [63:0] araddr, awaddr; wire [7:0] arlen, awlen; wire arvalid, arready, rvalid, rlast, rready, awvalid, awready, wvalid, wready, wlast, bvalid, bready;
    wire [DW-1:0] rdata, wdata; wire [DW/8-1:0] wstrb;
    bucket_rec_hbm dut (.clk(clk), .rst_n(rst_n), .base(BASE),
        .bm_rd_bucket(bm_rb), .bm_rd_en(bm_re), .bm_rd_slot_list(bm_rl), .bm_rd_fill(bm_rf), .bm_rd_valid(bm_rv),
        .bm_wr_bucket(bm_wb), .bm_wr_slot_list(bm_wl), .bm_wr_fill(bm_wf), .bm_wr_en(bm_we),
        .iv_rd_addr(iv_ra), .iv_rd_en(iv_re), .iv_rd_iv(iv_ri), .iv_rd_tag(iv_rt), .iv_rd_valid(iv_rv),
        .iv_wr_addr(iv_wa), .iv_wr_iv(iv_wi), .iv_wr_tag(iv_wt), .iv_wr_en(iv_we), .wr_ready(wr_rdy), .wr_quiet(quiet), .err(err),
        .m_araddr(araddr), .m_arlen(arlen), .m_arsize(), .m_arburst(), .m_arvalid(arvalid), .m_arready(arready), .m_rdata(rdata), .m_rlast(rlast), .m_rvalid(rvalid), .m_rready(rready),
        .m_awaddr(awaddr), .m_awlen(awlen), .m_awsize(), .m_awburst(), .m_awvalid(awvalid), .m_awready(awready), .m_wdata(wdata), .m_wstrb(wstrb), .m_wlast(wlast), .m_wvalid(wvalid), .m_wready(wready), .m_bvalid(bvalid), .m_bready(bready));
    axi_mem_model #(.DW(DW), .WORDS(B * 8), .BASE(BASE), .RLAT(53)) mem (.clk(clk), .rst_n(rst_n),
        .araddr(araddr), .arlen(arlen), .arvalid(arvalid), .arready(arready), .rdata(rdata), .rresp(), .rlast(rlast), .rvalid(rvalid), .rready(rready),
        .awaddr(awaddr), .awlen(awlen), .awvalid(awvalid), .awready(awready), .wdata(wdata), .wstrb(wstrb), .wlast(wlast), .wvalid(wvalid), .wready(wready), .bresp(), .bvalid(bvalid), .bready(bready));
    // xorshift32 (Verilator's $random(seed) can give a degenerate sequence)
    reg [31:0] rs = 32'h2545F491;
    function [31:0] rnd; input dummy; begin rs = rs ^ (rs << 13); rs = rs ^ (rs >> 17); rs = rs ^ (rs << 5); rnd = rs; end endfunction
    reg [Z*SW+FW-1:0] rbm [0:B-1]; reg [223:0] riv [0:B*8-1];
    integer k, p, j, b, fails = 0, checks = 0, seed = 3, ordr [0:7], t;
    function [31:0] ivad; input integer bb, pp; begin ivad = (bb << (PW + 12)) | (pp << 12); end endfunction
    task wait_ready; begin if (!wr_rdy) begin bm_we = 0; iv_we = 0; while (!wr_rdy) @(negedge clk); end end endtask
    task w_bm; input integer bb; begin
        @(negedge clk); wait_ready; bm_wb = bb; bm_wl = {rnd(0), rnd(0)}; bm_wf = rnd(0); bm_we = 1;
        rbm[bb] = {bm_wl, bm_wf}; @(negedge clk); bm_we = 0; end endtask
    task w_iv; input integer bb, pp; begin
        @(negedge clk); wait_ready; iv_wa = ivad(bb, pp); iv_wi = {rnd(0), rnd(0), rnd(0)};
        iv_wt = {rnd(0), rnd(0), rnd(0), rnd(0)}; iv_we = 1; riv[bb * 8 + pp] = {iv_wt, iv_wi};
        @(negedge clk); iv_we = 0; end endtask
    task r_iv; input integer bb, pp; begin
        @(negedge clk); iv_ra = ivad(bb, pp); iv_re = 1; @(negedge clk); iv_re = 0;
        while (!iv_rv) @(negedge clk);
        checks = checks + 1;
        if ({iv_rt, iv_ri} !== riv[bb * 8 + pp]) begin fails = fails + 1; if (fails < 5) $display("FAIL IV bucket %0d pos %0d", bb, pp); end
    end endtask
    task open_chk; input integer bb; begin
        @(negedge clk); bm_rb = bb; bm_re = 1; @(negedge clk); bm_re = 0;
        while (!bm_rv) @(negedge clk);
        checks = checks + 1;
        if ({bm_rl, bm_rf} !== rbm[bb]) begin fails = fails + 1; if (fails < 5) $display("FAIL metadata bucket %0d", bb); end
    end endtask
    task rounds; input integer n; begin
        for (k = 0; k < n; k = k + 1) begin
            if (k == 0 || (rnd(0) & 1)) b = rnd(0) % B;   // else: reopen the bucket just written
            open_chk(b);
            for (p = 0; p < Z; p = p + 1) ordr[p] = p;
            for (p = Z - 1; p > 0; p = p - 1) begin j = rnd(0) % (p + 1); t = ordr[p]; ordr[p] = ordr[j]; ordr[j] = t; end
            for (p = 0; p < Z; p = p + 1) r_iv(b, ordr[p]);                       // verify-like reads, any order
            for (p = 0; p < Z; p = p + 1) if (rnd(0) & 1) w_iv(b, p);      // re-encryption-like writes
            if (rnd(0) & 1) r_iv(b, rnd(0) % Z);           // read back a just-written beat
            w_bm(b);                                                                  // end-of-access metadata
            if ((rnd(0) & 7) == 0) r_iv((rnd(0) % B), rnd(0) % Z);  // fallback read
        end
    end endtask
    initial begin
        mem.slow_pct = 2; mem.slow_extra = 105; mem.wlat = 26;
        repeat (8) @(posedge clk); rst_n = 1;
        for (b = 0; b < B; b = b + 1) begin for (p = 0; p < Z; p = p + 1) w_iv(b, p); w_bm(b); end   // boot: everything written
        rounds(1500);
        mem.wlat = 200; rounds(300);                                            // writes land late
        repeat (500) @(negedge clk);
        if (!quiet) begin $display("FAIL: not quiet at the end"); fails = fails + 1; end
        if (err) begin $display("FAIL: error flagged"); fails = fails + 1; end
        if (mem.perr != 0) begin $display("FAIL: AXI protocol violations"); fails = fails + 1; end
        $display("bucket_rec_hbm: %0d checks, %0d mismatches", checks, fails);
        if (fails == 0) $display("*** BUCKET_REC_HBM: ALL CHECKS PASSED ***");
        $finish;
    end
    initial begin #80000000; $display("FAIL: TIMEOUT"); $finish; end
endmodule
