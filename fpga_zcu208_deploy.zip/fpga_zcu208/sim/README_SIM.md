# Simulating the ZCU208 ORAM

The regression runs the single-client build by default. Use `ORAM_CONFIG=two bash run_verilator.sh` for the
two-client build. Cached builds are cleared automatically when the configuration changes. In the
single-client configuration the non-interference and over-grant tests are skipped, because they need
a second client; the same traffic, stress, calibration, backpressure, production and worst-case checks
run for client 0.

All scripts run from this `sim/` directory: synthesis sources come from `../rtl`, testbenches from here. Build products and logs go to `sim/build/`.

| Script | Simulator | Purpose |
|---|---|---|
| `run_verilator.sh` | Verilator 5.x (`--timing`) | **Full regression**, with PASS/FAIL per check and an exit code (0 = all passed). About 10 minutes on a laptop, mostly building. |
| `run_icarus.sh` | Icarus Verilog (`-g2012`) | Compile check of both testbenches and the production configuration. Icarus is far too slow to run the suite; `RUN=1` runs the self-test anyway. |
| `run_xsim.sh` | Vivado XSim | Self-test, tamper and non-interference. **Not run where these files were written (no Vivado), so the first run is a bring-up.** |
| `Makefile` | — | `make` (all checks), `make selftest`, `ni`, `stress`, `bp`, `secure`, `icarus`, `xsim`, `clean` |

`run_verilator.sh` takes a group name (`selftest`, `ni`, `stress`, `bp` or `secure`) to run one part. It reuses existing builds; set `REBUILD=1` after RTL edits.

## What the checks prove

| Check | Testbench | Pass criterion |
|---|---|---|
| Self-test | `tb_onboard_test_top`, single client (default) | `ALL 50 RUN TESTS PASSED (3 skipped`. Every window belongs to client 0, so the paper's workload runs without dummy accesses. T43, T44 and T48 need client 1 and are skipped. |
| Self-test, two clients | same, `-DSELFTEST_CLIENTS=2` | `ALL 53 TESTS PASSED`. The performance phase is the paper's workload: `SELFTEST_PERF_N` random writes (default 200), then the same number of reads of the same slots. Set `SELFTEST_PERF_N=100` for the paper's original 100 + 100. Includes real lease checks: T46 wrong token, T47 revoked lease, then a re-grant. |
| Tamper, hole | same, `+tamper_hole` | One bit flipped in a hole of the first test slot's bucket gives `TAMPER RESULT: DETECTED`, with the controller halted (`S_HALT`). |
| Tamper, target | same, `+tamper_target` | Same, at position 0. |
| Non-interference | `tb_ni` (`ORAM_DEBUG_PORTS`), `+ni=0..3` | Client 1 replays a fixed trace while client 0 is idle, saturating, random or bursty. All four `trace-hash` values must be identical, with `errors=0` for both clients. |
| Worst case, gated | `tb_ni +stress` | 8 evictions in one access, `ct_overrun=0`, `data_errors=0`. |
| Worst case, calibration | `tb_ni +stress` **and** the full self-test, both built with `ORAM_CT_*=0` | Worst encryption end over both ≤ `ORAM_CT_WB` + 896: the streaming write-back never has to wait. With eviction overlap the self-test's two-copy paths are the worst case. |
| Negative control, streaming | `tb_ni +stress`, `ORAM_CT_WB` 1,500 too early | Must report `ct_overrun=1` with no `SAFETY VIOLATION`: caught, and no plaintext ever read. |
| Safety scan | all logs | No `SAFETY VIOLATION` or `SCRATCH: bank conflict` anywhere. |
| AXI backpressure | calibration build, `+bp=30` | 30% ready-low plus read-data gaps, both clients active: no data or integrity error. |
| Production configuration | `tb_ni` built with `ORAM_SECURE_BUILD` | Same trace hash as the debug build, `errors=0`, so removing the debug ports changes nothing functionally. |

## Padding report (self-test)

After the performance counters, the self-test prints a padding table for the performance-phase
accesses. It shows how every access ends up with the same total. Each access is pinned to fixed
points, counted from its start:
- read issued at `ORAM_CT_RD`;
- write-back starts at `ORAM_CT_WB`;
- completion at `ORAM_CT_DONE`.

| Column | Meaning |
|---|---|
| work done (min/avg/max) | When the path-dependent work actually finished: all 8 positions re-encrypted |
| slack absorbed | `ORAM_CT_WB + 7*128` − work done: how early the encryption finished before the write-back needed the last position. Must stay > 0 |
| write-back done | When the write-back that started at `ORAM_CT_WB` finished (depends on memory timing, not on the path) |
| pad at read / at completion | Idle cycles waiting at the read gate and the completion gate |

## Derived worst case (`worst` group, `worst_case.py`)

The timing budgets must cover the latest possible encryption end, not just the slowest access seen
in some test. Every testbench build includes `oram_timing_monitor.v`, which writes one CSV line per
access with `+timing_log=<file>`. `tb_ni +worst` builds every candidate worst path on purpose:
- two copies (compaction) + 7 evictions, for a read and a write;
- 1 copy + 1 to 8 evictions into an empty bucket;
- a bucket hit that leaves the bucket empty;
- a write to a block in the stash, and reads of never-written slots.

`python3 worst_case.py --params ../rtl/oram_params.vh TRACE.csv ...` (Python 3, standard library):
1. Checks that every on-chip segment is determined by the path features alone (operation phase by
   path and copies, eviction decisions by count, first-copy wait, encryption), and that the
   controller's structural rules hold on every access.
2. Enumerates every feature combination the controller allows.
3. Reports the derived worst encryption end per memory model, and whether a traced access reached
   it.

It fails if any segment is not explained, any combination is unmeasured, or the bound exceeds
`CT_WB + 7*128`.

The same run also logs bus timing per window (`tb_ni +bus_log=<file>`). The check requires every
window, real or dummy and for every client, to present the bucket read (AR) and the write-back (AW)
on the AXI bus at the same offset from the window start.

## Running `tb_ni` in Vivado XSim

`tb_ni` formats all buckets before the first request (about 222,000 cycles, ready at 888.5 µs of
simulated time). It prints a banner, a ready message and a heartbeat every 50,000 cycles
(`+heartbeat=N`, 0 turns it off), then one result line before `$finish`. Simulated time each mode
needs:

| Mode | Simulated time |
|---|---|
| default (`+ni=0`, 12 operations) | about 1.5 ms |
| `+stress` | about 2.5 ms |
| `+worst` | about 12 ms |

In project mode:
- **Set plusargs** before launching:
  `set_property -name {xsim.simulate.xsim.more_options} -value {-testplusarg ni=1} -objects [get_filesets sim_1]`
- **Use `run all`**, which stops at `$finish`, instead of a fixed run time.
- **Leave wave logging off** (`xsim.simulate.log_all_signals` false) for speed.

Expected default result, identical in Verilator and XSim:

    NI: variant=0 client1 ops=12 errors=0 trace-hash=af7332f1b0a17353 latency min/mean/max=10149/11410/12820 | client0 ops=0 errors=0 | slots real=12 dummy=12

For the non-interference check, `+ni=1`, `+ni=2` and `+ni=3` must print the same `trace-hash` and
`latency` values for client 1.

## `tb_ni` options

| Option | Meaning |
|---|---|
| `+ni=V` | Client-0 behavior: 0 idle, 1 saturating, 2 random gaps, 3 bursty |
| `+ops=N` | Number of client-1 operations (default 12) |
| `+bp=P` | AXI backpressure: ready-low and read gaps, P% of cycles |
| `+stress` | Worst-case eviction test (needs debug ports: steers remaps) |
| `+limit=N` | Stop N cycles after `oram_ready` |

Both testbenches are plain Verilog-2001, so they compile whether a tool treats them as Verilog or SystemVerilog.

`tb_ni` drives `secure_oram_top` directly through a simple in-order AXI memory model. The model buffers write data that arrives before its address, as a real controller does.

## Debug ports in simulation

Any simulation build (where `SYNTHESIS` is undefined, as in every simulator) turns on `ORAM_DEBUG_PORTS` automatically through `oram_params.vh`, so the self-test's performance counters work without extra defines. Production builds (`ORAM_SECURE_BUILD`) never get them. Synthesis gets them only when `ORAM_DEBUG_PORTS` is defined explicitly, which `vivado/add_sources.tcl` does for the self-test and calibration bitstreams.

## Other defines

| Define | Effect |
|---|---|
| `DUMP_VCD` | Waveforms from `tb_onboard_test_top` (about 700 MB per run). Off by default. |
| `XSIM_FORCE_LEASE_VALID` | Bypasses lease checking in the self-test. Workaround only, and T46/T47 will then fail. See `run_xsim.sh`. |
| `ORAM_CT_RD`, `ORAM_CT_WB`, `ORAM_CT_DONE`, `ORAM_TDM_SLOT` | Override the timing budgets and slot length. Set the three `ORAM_CT_*` to 0 for calibration, with a long `ORAM_TDM_SLOT` (for example 20000). |

The budgets in `oram_params.vh` are calibrated against these testbench memory models. On the board, run the calibration build's `+stress` against the real DDR (or read `ct_max_*` with an ILA), then set the budgets with margin.
