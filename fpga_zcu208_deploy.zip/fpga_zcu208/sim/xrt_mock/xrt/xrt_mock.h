// xrt_mock.h -- the part of XRT's native C++ API that host_doma.cpp and host_ycsb.cpp use, backed by a Verilated
// doma_kernel (xrt_mock.cpp) instead of a card. Simulation only: it lets the unmodified host programs run end to end
// against the RTL before card time.
//
// What it models, so host-program mistakes show up here rather than on the card:
//   * buffer objects: device memory and host memory are separate copies, so a missing sync() reads stale or
//     uninitialized data (device memory starts as 0xCD bytes); host_only buffers are shared, as on the card;
//   * every kernel access is checked against the buffers: an access outside every buffer, or crossing a buffer's
//     end, is reported (on the card it would hit other memory or fail);
//   * the kernel is driven through its AXI-Lite control port exactly as XRT does it (arguments, ap_start, then
//     ap_done polling), and its seven AXI masters see memories with the testbench's latencies (tb_doma_kernel.v).
// Memory placement follows MOCK_CFG=doma_hw (default: pages in HBM[8]) or doma (pages in HOST[0]).
#ifndef XRT_MOCK_H
#define XRT_MOCK_H
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <utility>
#include <vector>

enum xclBOSyncDirection { XCL_BO_SYNC_BO_TO_DEVICE = 0, XCL_BO_SYNC_BO_FROM_DEVICE = 1 };

namespace xrt {
namespace mock { struct BoImpl; }

class uuid { public: std::string str; };

class xclbin {
  public:
    class mem {
      public:
        std::string tag; int32_t index = 0;
        std::string get_tag() const { return tag; }
        int32_t get_index() const { return index; }
    };
    class arg {
      public:
        std::vector<mem> mems;
        std::vector<mem> get_mems() const { return mems; }
    };
    class kernel {
      public:
        std::vector<arg> args;
        arg get_arg(int32_t i) const { return args.at(size_t(i)); }
    };
    xclbin() = default;
    explicit xclbin(const std::string& path);
    kernel get_kernel(const std::string& name) const;
    std::string path;
};

class device {
  public:
    device() = default;
    explicit device(unsigned int index);
    explicit device(const std::string& bdf);
    uuid load_xclbin(const xclbin& xb);
    uuid load_xclbin(const std::string& path) { return load_xclbin(xclbin(path)); }
};

class bo {
  public:
    enum class flags : uint32_t { normal = 0, cacheable = 1, device_only = 2, host_only = 3, p2p = 4, svm = 5 };
    bo() = default;
    bo(const device& d, size_t size, int group) : bo(d, size, flags::normal, group) {}
    bo(const device& d, size_t size, flags f, int group);
    template <typename T> T map() { return reinterpret_cast<T>(host_ptr()); }
    void sync(xclBOSyncDirection dir, size_t size, size_t offset);
    void sync(xclBOSyncDirection dir) { sync(dir, size(), 0); }
    size_t size() const;
    uint64_t address() const;
    void* host_ptr();
  private:
    std::shared_ptr<mock::BoImpl> impl_;
};

class run {
  public:
    run() = default;
    void wait();
    void wait(unsigned int /*timeout_ms*/) { wait(); }
  private:
    friend class kernel;
    bool started_ = false;
};

class kernel {
  public:
    kernel() = default;
    kernel(const device& d, const uuid& u, const std::string& name);
    int group_id(int argno) const;
    template <typename... Args> run operator()(Args&&... args) {
        std::vector<uint64_t> v; (push(v, std::forward<Args>(args)), ...); return start(v);
    }
  private:
    static void push(std::vector<uint64_t>& v, const bo& b) { v.push_back(b.address()); }
    static void push(std::vector<uint64_t>& v, bo& b) { v.push_back(b.address()); }
    template <typename T> static void push(std::vector<uint64_t>& v, T x) { v.push_back(uint64_t(x)); }
    run start(const std::vector<uint64_t>& args);
    std::string name_;
};
} // namespace xrt
#endif
