#!/bin/bash
# build_model.sh -- Verilate doma_kernel (the whole Vitis kernel: DOMA plus its XRT-facing wrapper) for the mock XRT.
# Defaults are the card build that vitis/build.sh makes with NMAX=1048576 SCHED=arrival (4 KB blocks):
#   -DORAM_BLOCK_BEATS=128 -DORAM_N=1048576 -DORAM_SCHED_ARRIVAL, and ORAM_SECURE_BUILD for the production
#   configuration (Vivado gets it from SYNTHESIS). Overrides: ORAM_BEATS, ORAM_N, SCHED (arrival|strict).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
RTL="${RTL:-$HERE/../../rtl}"; RTL="$(cd "$RTL" && pwd)"
OUT="${OUT:-$HERE/obj_dir}"
ORAM_BEATS="${ORAM_BEATS:-128}"; ORAM_N="${ORAM_N:-1048576}"; SCHED="${SCHED:-arrival}"
SRCS=""; while read -r f; do f="${f%$'\r'}"; [ -n "$f" ] && SRCS="$SRCS $RTL/$f"; done < "$HERE/../files_rtl.lst"
DEFS="-DORAM_BLOCK_BEATS=$ORAM_BEATS -DORAM_N=$ORAM_N -DORAM_SECURE_BUILD"
[ "$SCHED" = arrival ] && DEFS="$DEFS -DORAM_SCHED_ARRIVAL"
[ "${TRACE:-0}" = 1 ] && DEFS="$DEFS -DORAM_PHASE_TRACE"      # TRACE=1: the phase-trace variant (build.sh TRACE=1)
# the regression's warning flags (sim/run_verilator.sh) and its kernel-group extra
WFLAGS="-Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-BLKANDNBLK"
rm -rf "$OUT"; mkdir -p "$OUT"
echo "== verilating doma_kernel: $DEFS"
verilator --cc --no-timing --top-module doma_kernel -O3 --x-assign fast --x-initial fast $WFLAGS -I"$RTL" $DEFS \
          --Mdir "$OUT" $SRCS "$RTL/doma_kernel.v"
make -C "$OUT" -f Vdoma_kernel.mk -j"$(nproc)" OPT_FAST="-O2" OPT_SLOW="-O1" > "$OUT/make.log"
echo "$DEFS" > "$OUT/defines.txt"
ls -l "$OUT/libVdoma_kernel.a" "$OUT/libverilated.a"
