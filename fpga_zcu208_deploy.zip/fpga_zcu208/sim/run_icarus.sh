#!/bin/bash
# Icarus Verilog (-g2012): compile check of both testbenches. With 16 full-block
# GCM operations per access plus the boot-time format pass, Icarus is far too
# slow for the full suite (hours) -- use run_verilator.sh for regression.
#   bash run_icarus.sh          # compile both testbenches
#   RUN=1 bash run_icarus.sh    # also run the self-test (very slow)
set -u
cd "$(dirname "$0")"
RTL=../rtl
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
mkdir -p build
rc=0
iverilog -g2012 -DSIMULATION -DORAM_DEBUG_PORTS -I$RTL -s tb_onboard_test_top -o build/icarus_selftest.vvp \
    $SRCS $RTL/onboard_test_top.v tb_onboard_test_top.v oram_timing_monitor.v > build/icarus_selftest.log 2>&1 \
    && echo "  PASS  icarus: self-test compiles" || { echo "  FAIL  icarus self-test compile (build/icarus_selftest.log)"; rc=1; }
iverilog -g2012 -DORAM_DEBUG_PORTS -I$RTL -s tb_ni -o build/icarus_ni.vvp $SRCS tb_ni.v oram_timing_monitor.v > build/icarus_ni.log 2>&1 \
    && echo "  PASS  icarus: tb_ni compiles" || { echo "  FAIL  icarus tb_ni compile (build/icarus_ni.log)"; rc=1; }
iverilog -g2012 -DORAM_SECURE_BUILD -I$RTL -s secure_oram_top -o build/icarus_secure.vvp $SRCS > build/icarus_secure.log 2>&1 \
    && echo "  PASS  icarus: production configuration compiles" || { echo "  FAIL  icarus secure compile (build/icarus_secure.log)"; rc=1; }
if [ -n "${RUN:-}" ] && [ $rc = 0 ]; then
    vvp -n build/icarus_selftest.vvp > build/icarus_run.log 2>&1
    grep -E "Fail count|ALL .*PASS|FAILURE" build/icarus_run.log
fi
exit $rc
