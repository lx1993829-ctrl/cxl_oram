// tb_aes_kat.v -- AES-128 pipeline: FIPS-197 Appendix B and C.1 known answers, plus random inputs.
`timescale 1ns/1ps
module tb_kat;
    reg clk = 0, rst_n = 0; always #1 clk = ~clk;
    reg [127:0] key = 0, pt = 0; reg vin = 0;
    wire [127:0] ct; wire vout;
    aes128_encrypt_pipeline_fpga dut (.clk(clk), .rst_n(rst_n), .enable(1'b1), .key(key), .plaintext(pt), .valid_in(vin), .ciphertext(ct), .valid_out(vout));
    task enc; input [127:0] k, p; output [127:0] c; integer n; begin
        key = k; repeat (20) @(posedge clk);                 // let the key schedule settle
        @(negedge clk); pt = p; vin = 1; @(negedge clk); vin = 0;
        n = 0; while (!vout && n < 100) begin @(posedge clk); #0.1; n = n + 1; end
        c = ct;
    end endtask
    reg [127:0] c; integer i; reg [127:0] rk, rp;
    initial begin
        repeat (4) @(posedge clk); rst_n = 1;
        enc(128'h000102030405060708090a0b0c0d0e0f, 128'h00112233445566778899aabbccddeeff, c);
        $display("KAT C.1 : %h %s", c, (c == 128'h69c4e0d86a7b0430d8cdb78070b4c55a) ? "MATCHES FIPS-197" : "WRONG");
        enc(128'h2b7e151628aed2a6abf7158809cf4f3c, 128'h3243f6a8885a308d313198a2e0370734, c);
        $display("KAT B   : %h %s", c, (c == 128'h3925841d02dc09fbdc118597196a0b32) ? "MATCHES FIPS-197" : "WRONG");
        for (i = 0; i < 4; i = i + 1) begin
            rk = {$random, $random, $random, $random}; rp = {$random, $random, $random, $random};
            enc(rk, rp, c); $display("RANDOM %0d: %h", i, c);
        end
        $finish;
    end
endmodule
