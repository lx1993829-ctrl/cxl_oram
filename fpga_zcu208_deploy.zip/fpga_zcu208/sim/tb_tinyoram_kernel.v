// tb_tinyoram_kernel.v -- end-to-end test of the tinyoram_kernel Vitis wrapper, the testbench
// playing XRT (same structure as tb_doma_kernel.v):
//   run 0: size = 0      (init launch: latches pages, reports geometry, touches no memory)
//   [+preload: N sequential PUTs, keys 0..N-1, like host_doma's initialization; the first launch
//    with size > 0 zero-fills the tree and starts Tiny ORAM]
//   run 1: +cmds commands (random GET/PUT over keys 0..N-1), every GET checked
//   run 2: +cmds2 commands, one of them an out-of-range key that must come back rejected
// The tree memory starts full of garbage (stale HBM); the kernel must zero it before use.
// No gmem2 access may happen before the first ap_start.
// Options: +cmds=N +cmds2=N +seed=N +host_lat=N +host_gap=P +host_rdy_gap=P +host_wlat=N
//          (+host_wlat: every write burst lands N cycles after its own last beat)
//          +start_delay=N +preload +hb=N +limit=N
// Build configuration: tinyoram_config.vh on the include path (tinyoram/config/tinyoram_config_<size>.vh).
`timescale 1ns/1ps
`include "tinyoram_config.vh"   // TINYORAM_ORAMB / TINYORAM_ORAML of this build
module tb_tinyoram_kernel;
    localparam integer DW = 256, N = 4 << `TINYORAM_ORAML, REC = `TINYORAM_ORAMB / 256, SLOTW = 4096 / 32;
    localparam [63:0] CMD_BASE = 64'h0000_0040_0000_0000, RESP_BASE = 64'h0000_0040_1000_0000,
                      HOST_BASE = 64'h0000_7f00_0000_0000;
    reg clk = 0, rst_n = 0;
    always #1.667 clk = ~clk;                                  // ~300 MHz

    // ---------------- AXI-Lite master ----------------
    reg  [11:0] awaddr = 0, araddr = 0; reg awvalid = 0, wvalid = 0, bready = 0, arvalid = 0, rready = 0;
    reg  [31:0] wdata = 0; wire awready, wready, bvalid, arready, rvalid; wire [31:0] rdata; wire [1:0] bresp, rresp;
    wire irq;
    // ---------------- AXI masters ----------------
    wire [63:0] g0_araddr, g1_awaddr, g2_araddr, g2_awaddr, g0_awaddr, g1_araddr;
    wire [7:0]  g0_arlen, g1_awlen, g2_arlen, g2_awlen, g0_awlen, g1_arlen;
    wire g0_arvalid, g0_arready, g0_rlast, g0_rvalid, g0_rready, g1_awvalid, g1_awready, g1_wlast, g1_wvalid, g1_wready,
         g1_bvalid, g1_bready, g2_arvalid, g2_arready, g2_rlast, g2_rvalid, g2_rready, g2_awvalid, g2_awready,
         g2_wlast, g2_wvalid, g2_wready, g2_bvalid, g2_bready;
    wire [DW-1:0] g0_rdata, g1_wdata, g2_rdata, g2_wdata; wire [DW/8-1:0] g1_wstrb, g2_wstrb;

    tinyoram_kernel dut (
        .ap_clk(clk), .ap_rst_n(rst_n),
        .s_axi_control_awaddr(awaddr), .s_axi_control_awvalid(awvalid), .s_axi_control_awready(awready),
        .s_axi_control_wdata(wdata), .s_axi_control_wstrb(4'hF), .s_axi_control_wvalid(wvalid), .s_axi_control_wready(wready),
        .s_axi_control_bresp(bresp), .s_axi_control_bvalid(bvalid), .s_axi_control_bready(bready),
        .s_axi_control_araddr(araddr), .s_axi_control_arvalid(arvalid), .s_axi_control_arready(arready),
        .s_axi_control_rdata(rdata), .s_axi_control_rresp(rresp), .s_axi_control_rvalid(rvalid), .s_axi_control_rready(rready),
        .interrupt(irq),
        .m_axi_gmem0_araddr(g0_araddr), .m_axi_gmem0_arlen(g0_arlen), .m_axi_gmem0_arsize(), .m_axi_gmem0_arburst(),
        .m_axi_gmem0_arvalid(g0_arvalid), .m_axi_gmem0_arready(g0_arready), .m_axi_gmem0_rdata(g0_rdata),
        .m_axi_gmem0_rresp(2'b00), .m_axi_gmem0_rlast(g0_rlast), .m_axi_gmem0_rvalid(g0_rvalid), .m_axi_gmem0_rready(g0_rready),
        .m_axi_gmem0_awaddr(g0_awaddr), .m_axi_gmem0_awlen(g0_awlen), .m_axi_gmem0_awsize(), .m_axi_gmem0_awburst(),
        .m_axi_gmem0_awvalid(), .m_axi_gmem0_awready(1'b1), .m_axi_gmem0_wdata(), .m_axi_gmem0_wstrb(), .m_axi_gmem0_wlast(),
        .m_axi_gmem0_wvalid(), .m_axi_gmem0_wready(1'b1), .m_axi_gmem0_bresp(2'b00), .m_axi_gmem0_bvalid(1'b0), .m_axi_gmem0_bready(),
        .m_axi_gmem1_araddr(g1_araddr), .m_axi_gmem1_arlen(g1_arlen), .m_axi_gmem1_arsize(), .m_axi_gmem1_arburst(),
        .m_axi_gmem1_arvalid(), .m_axi_gmem1_arready(1'b1), .m_axi_gmem1_rdata({DW{1'b0}}), .m_axi_gmem1_rresp(2'b00),
        .m_axi_gmem1_rlast(1'b0), .m_axi_gmem1_rvalid(1'b0), .m_axi_gmem1_rready(),
        .m_axi_gmem1_awaddr(g1_awaddr), .m_axi_gmem1_awlen(g1_awlen), .m_axi_gmem1_awsize(), .m_axi_gmem1_awburst(),
        .m_axi_gmem1_awvalid(g1_awvalid), .m_axi_gmem1_awready(g1_awready), .m_axi_gmem1_wdata(g1_wdata),
        .m_axi_gmem1_wstrb(g1_wstrb), .m_axi_gmem1_wlast(g1_wlast), .m_axi_gmem1_wvalid(g1_wvalid), .m_axi_gmem1_wready(g1_wready),
        .m_axi_gmem1_bresp(2'b00), .m_axi_gmem1_bvalid(g1_bvalid), .m_axi_gmem1_bready(g1_bready),
        .m_axi_gmem2_araddr(g2_araddr), .m_axi_gmem2_arlen(g2_arlen), .m_axi_gmem2_arsize(), .m_axi_gmem2_arburst(),
        .m_axi_gmem2_arvalid(g2_arvalid), .m_axi_gmem2_arready(g2_arready), .m_axi_gmem2_rdata(g2_rdata),
        .m_axi_gmem2_rresp(2'b00), .m_axi_gmem2_rlast(g2_rlast), .m_axi_gmem2_rvalid(g2_rvalid), .m_axi_gmem2_rready(g2_rready),
        .m_axi_gmem2_awaddr(g2_awaddr), .m_axi_gmem2_awlen(g2_awlen), .m_axi_gmem2_awsize(), .m_axi_gmem2_awburst(),
        .m_axi_gmem2_awvalid(g2_awvalid), .m_axi_gmem2_awready(g2_awready), .m_axi_gmem2_wdata(g2_wdata),
        .m_axi_gmem2_wstrb(g2_wstrb), .m_axi_gmem2_wlast(g2_wlast), .m_axi_gmem2_wvalid(g2_wvalid), .m_axi_gmem2_wready(g2_wready),
        .m_axi_gmem2_bresp(2'b00), .m_axi_gmem2_bvalid(g2_bvalid), .m_axi_gmem2_bready(g2_bready)
    );
    // HBM buffers for commands and responses, and the tree region (4 MB)
    axi_mem_model #(.DW(DW), .WORDS(1 << 18), .BASE(CMD_BASE), .RLAT(40)) u_cmd (
        .clk(clk), .rst_n(rst_n), .araddr(g0_araddr), .arlen(g0_arlen), .arvalid(g0_arvalid), .arready(g0_arready),
        .rdata(g0_rdata), .rresp(), .rlast(g0_rlast), .rvalid(g0_rvalid), .rready(g0_rready),
        .awaddr(64'd0), .awlen(8'd0), .awvalid(1'b0), .awready(), .wdata({DW{1'b0}}), .wstrb({(DW/8){1'b0}}),
        .wlast(1'b0), .wvalid(1'b0), .wready(), .bresp(), .bvalid(), .bready(1'b1));
    axi_mem_model #(.DW(DW), .WORDS(1 << 18), .BASE(RESP_BASE), .RLAT(40)) u_resp (
        .clk(clk), .rst_n(rst_n), .araddr(64'd0), .arlen(8'd0), .arvalid(1'b0), .arready(), .rdata(), .rresp(), .rlast(), .rvalid(), .rready(1'b1),
        .awaddr(g1_awaddr), .awlen(g1_awlen), .awvalid(g1_awvalid), .awready(g1_awready), .wdata(g1_wdata), .wstrb(g1_wstrb),
        .wlast(g1_wlast), .wvalid(g1_wvalid), .wready(g1_wready), .bresp(), .bvalid(g1_bvalid), .bready(g1_bready));
    axi_mem_model #(.DW(DW), .WORDS(1 << 17), .BASE(HOST_BASE), .RLAT(100)) u_host (
        .clk(clk), .rst_n(rst_n), .araddr(g2_araddr), .arlen(g2_arlen), .arvalid(g2_arvalid), .arready(g2_arready),
        .rdata(g2_rdata), .rresp(), .rlast(g2_rlast), .rvalid(g2_rvalid), .rready(g2_rready),
        .awaddr(g2_awaddr), .awlen(g2_awlen), .awvalid(g2_awvalid), .awready(g2_awready), .wdata(g2_wdata), .wstrb(g2_wstrb),
        .wlast(g2_wlast), .wvalid(g2_wvalid), .wready(g2_wready), .bresp(), .bvalid(g2_bvalid), .bready(g2_bready));

    // ---------------- AXI-Lite tasks (what XRT does), as in tb_doma_kernel ----------------
    task axil_wr; input [11:0] a; input [31:0] d; begin
        @(negedge clk); awaddr = a; wdata = d; awvalid = 1; wvalid = 1;
        while (!bvalid) @(negedge clk);
        awvalid = 0; wvalid = 0; bready = 1;
        @(negedge clk); bready = 0;
    end endtask
    task axil_rd; input [11:0] a; output [31:0] d; begin
        @(negedge clk); araddr = a; arvalid = 1;
        while (!rvalid) @(negedge clk);
        d = rdata; arvalid = 0; rready = 1;
        @(negedge clk); rready = 0;
    end endtask

    // ---------------- host-side state ----------------
    integer last_put [0:N-1];            // command id of the last PUT to each key, -1 = never written
    integer cmd_key [0:4095], cmd_type [0:4095], cmd_id [0:4095];
    integer gid = 0, fails = 0, seed, ncmd1, ncmd2, hl, hg, uninit_gets = 0;
    reg     started = 0;
    function [DW-1:0] pat; input integer id, beat, key; begin
        pat = {8{id[15:0], beat[7:0], key[7:0]}};
    end endfunction

    task prepare; input integer size; input integer bad_at; integer i, j, hcw; begin
        hcw = (((size * 32) + 4095) / 4096) * 4096 / 32;
        for (i = 0; i < size; i = i + 1) begin
            cmd_type[i] = (($random(seed) & 1) == 1) ? 2 : 1;
            cmd_key[i]  = (($random(seed) % N) + N) % N;
            if (i == bad_at) cmd_key[i] = N + 5;
            cmd_id[i] = gid; gid = gid + 1;
            u_cmd.mem[i] = {{(DW-64){1'b0}}, cmd_key[i][31:0], 24'd0, cmd_type[i][7:0]};
            if (cmd_type[i] == 2) for (j = 0; j < SLOTW; j = j + 1) u_cmd.mem[hcw + i*SLOTW + j] = pat(cmd_id[i], j, cmd_key[i]);
        end
    end endtask
    task prepare_seq; input integer size; integer i, j, hcw; begin
        hcw = (((size * 32) + 4095) / 4096) * 4096 / 32;
        for (i = 0; i < size; i = i + 1) begin
            cmd_type[i] = 2; cmd_key[i] = i % N; cmd_id[i] = gid; gid = gid + 1;
            u_cmd.mem[i] = {{(DW-64){1'b0}}, cmd_key[i][31:0], 24'd0, cmd_type[i][7:0]};
            for (j = 0; j < SLOTW; j = j + 1) u_cmd.mem[hcw + i*SLOTW + j] = pat(cmd_id[i], j, cmd_key[i]);
        end
    end endtask

    task run; input integer size; input integer bad_at; input [8*8-1:0] name;
        integer i, j, hrw, t0, t1, bad, gets, puts, rej, ar0, aw0, rb0, wb0, ord, dmin, dmax, wmin, wmax; reg [31:0] v; reg [DW-1:0] exp, got, sum, byt; begin
        hrw = ((((size + 2) * 32) + 4095) / 4096) * 4096 / 32;              // after records [size], [size+1]
        for (i = 0; i <= size + 1; i = i + 1) u_resp.mem[i] = {DW{1'b1}};      // poison the headers and both records
        axil_wr(12'h010, CMD_BASE[31:0]);  axil_wr(12'h014, CMD_BASE[63:32]);
        axil_wr(12'h01C, RESP_BASE[31:0]); axil_wr(12'h020, RESP_BASE[63:32]);
        axil_wr(12'h028, HOST_BASE[31:0]); axil_wr(12'h02C, HOST_BASE[63:32]);
        axil_wr(12'h034, size);
        axil_wr(12'h004, 32'h1); axil_wr(12'h008, 32'h1);
        t0 = u_cmd.cyc; ar0 = ar_host; aw0 = aw_host; rb0 = rbeat_host; wb0 = wbeat_host; ord = 0;
        started = 1;
        axil_wr(12'h000, 32'h1);                                                // ap_start
        v = 0;
        while (!v[1]) begin repeat (200) @(posedge clk); axil_rd(12'h000, v); end
        t1 = u_cmd.cyc;
        if (!irq) begin $display("FAIL %0s: interrupt not raised", name); fails = fails + 1; end
        axil_wr(12'h00C, 32'h1);
        @(posedge clk); @(posedge clk);
        if (irq) begin $display("FAIL %0s: interrupt not cleared", name); fails = fails + 1; end
        axil_rd(12'h000, v);
        if (!v[2] || v[1] || v[0]) begin $display("FAIL %0s: CTRL after done = %h (want idle, done cleared)", name, v); fails = fails + 1; end
        bad = 0; gets = 0; puts = 0; rej = 0; dmin = 32'h7fffffff; dmax = 0; wmin = 32'h7fffffff; wmax = 0;
        for (i = 0; i < size; i = i + 1) begin
            got = u_resp.mem[i];
            if (got[7:0] === 8'h10) begin
                if (got[159:128] < dmin) dmin = got[159:128]; if (got[159:128] > dmax) dmax = got[159:128];
                if (got[191:160] < wmin) wmin = got[191:160]; if (got[191:160] > wmax) wmax = got[191:160];
            end
            if (i == bad_at) begin
                if (got[7:0] !== 8'h11 || got[127:96] !== 32'h4) begin bad = bad + 1;
                    $display("FAIL %0s: cmd %0d (key %0d outside the ORAM) not rejected: type %h status %h", name, i, cmd_key[i], got[7:0], got[127:96]); end
                else rej = rej + 1;
            end else if (got[7:0] === 8'h10 && !(got[159:128] <= got[191:160] && got[191:160] <= got[95:64])) begin
                bad = bad + 1;   // latencies must be ordered: data ready <= last write beat <= acknowledged
                if (ord < 3) $display("FAIL %0s: cmd %0d latencies out of order: data %0d, write beat %0d, ack %0d", name, i, got[159:128], got[191:160], got[95:64]);
                ord = ord + 1;
            end else if (got[7:0] !== 8'h10 || got[63:32] !== cmd_key[i]) begin
                bad = bad + 1;
                if (bad < 4) $display("FAIL %0s: cmd %0d header type %h key %0d status %h", name, i, got[7:0], got[63:32], got[127:96]);
            end else if (cmd_type[i] == 2) begin
                last_put[cmd_key[i]] = cmd_id[i]; puts = puts + 1;
            end else begin
                gets = gets + 1;
                if (last_put[cmd_key[i]] < 0) begin
                    // GET of a never-written key: Tiny ORAM's own behaviour, reported, not checked
                    if (uninit_gets == 0) $display("NOTE %0s: GET of never-written key %0d returned %h...", name, cmd_key[i], u_resp.mem[hrw + i*SLOTW][63:0]);
                    uninit_gets = uninit_gets + 1;
                end else for (j = 0; j < REC; j = j + 1) begin
                    exp = pat(last_put[cmd_key[i]], j, cmd_key[i]);
                    if (u_resp.mem[hrw + i*SLOTW + j] !== exp) begin
                        if (bad < 4) $display("FAIL %0s: GET cmd %0d key %0d beat %0d data mismatch: got %h exp %h", name, i, cmd_key[i], j,
                                              u_resp.mem[hrw + i*SLOTW + j][63:0], exp[63:0]);
                        bad = bad + 1; j = REC;
                    end
                end
            end
        end
        sum = u_resp.mem[size];
        $display("%0s: size=%0d  host cycles=%0d  device total=%0d  completed=%0d  latency min/max=%0d/%0d  errors=%h  gets=%0d puts=%0d rejected=%0d  bad=%0d  tree AR=%0d AW=%0d",
                 name, size, t1 - t0, sum[127:64], sum[255:224], sum[159:128], sum[191:160], sum[223:192], gets, puts, rej, bad,
                 ar_host - ar0, aw_host - aw0);
        if (sum[7:0] !== 8'h5A || sum[255:224] !== size - (bad_at >= 0 ? 1 : 0) || sum[223:192] !== 0) begin
            $display("FAIL %0s: summary record wrong", name); fails = fails + 1; end
        if (size > 0) $display("%0s: latency to data ready %0d..%0d, to last write beat %0d..%0d, to write-back acknowledged %0d..%0d",
                               name, dmin, dmax, wmin, wmax, sum[159:128], sum[191:160]);
        byt = u_resp.mem[size + 1];
        $display("%0s: traffic record: read beats %0d, write beats %0d on the tree port (testbench saw %0d / %0d)",
                 name, byt[127:64], byt[191:128], rbeat_host - rb0, wbeat_host - wb0);
        if (byt[7:0] !== 8'h5B || byt[127:64] !== rbeat_host - rb0 || byt[191:128] !== wbeat_host - wb0 ||
            byt[223:192] !== N || byt[255:224] !== dut.TREE_BURSTS[31:0]) begin
            $display("FAIL %0s: traffic record [size+1] wrong", name); fails = fails + 1; end
        fails = fails + bad;
    end endtask

    initial begin : main
        integer k; reg [31:0] v;
        if (!$value$plusargs("seed=%d", seed)) seed = 7;
        if (!$value$plusargs("cmds=%d", ncmd1)) ncmd1 = 120;
        if (!$value$plusargs("cmds2=%d", ncmd2)) ncmd2 = 40;
        if ($value$plusargs("host_lat=%d", hl)) u_host.lat = hl;
        if ($value$plusargs("host_gap=%d", hg)) u_host.gap_pct = hg;
        if ($value$plusargs("host_wlat=%d", hg)) u_host.wlat = hg;
        if ($value$plusargs("host_rdy_gap=%d", hg)) begin u_host.rdy_gap = hg; u_cmd.rdy_gap = hg; u_resp.rdy_gap = hg; end
        for (k = 0; k < N; k = k + 1) last_put[k] = -1;
        for (k = 0; k < (1 << 17); k = k + 1) u_host.mem[k] = {8{$random(seed)}};   // stale contents of the tree buffer
        $display("tb_tinyoram_kernel | N=%0d record=%0d B | tree read latency %0d cycles, gaps %0d%%, ready gaps %0d%%, writes land after %0d cycles",
                 N, REC * 32, u_host.lat, u_host.gap_pct, u_host.rdy_gap, u_host.wlat);
        $fflush;
        repeat (20) @(posedge clk); rst_n = 1;
        axil_rd(12'h000, v);
        if (!v[2]) begin $display("FAIL: kernel not idle after reset (CTRL=%h)", v); fails = fails + 1; end
        if ($value$plusargs("start_delay=%d", k)) repeat (k) @(posedge clk);
        run(0, -1, "init");
        if (ar_host != 0 || aw_host != 0) begin $display("FAIL: the init launch touched the tree (AR %0d AW %0d)", ar_host, aw_host); fails = fails + 1; end
        if ($test$plusargs("preload")) begin prepare_seq(N); run(N, -1, "preload"); end
        prepare(ncmd1, -1); run(ncmd1, -1, "run1");
        if ($test$plusargs("nobad")) begin prepare(ncmd2, -1); run(ncmd2, -1, "run2"); end
        else begin prepare(ncmd2, ncmd2 / 2); run(ncmd2, ncmd2 / 2, "run2"); end
        if (early_access) begin $display("FAIL: the tree buffer was accessed before the first ap_start"); fails = fails + 1; end
        if (uninit_gets) $display("NOTE: %0d GET(s) of never-written keys (not checked)", uninit_gets);
        if (u_cmd.errors || u_resp.errors || u_host.errors) begin
            $display("FAIL: memory errors (out of range or AXI protocol): cmd %0d resp %0d host %0d (protocol %0d/%0d/%0d)", u_cmd.errors, u_resp.errors, u_host.errors, u_cmd.perr, u_resp.perr, u_host.perr);
            fails = fails + 1; end
        if (fails == 0) $display("*** TINYORAM KERNEL: ALL CHECKS PASSED ***");
        else            $display("*** TINYORAM KERNEL: %0d FAILURE(S) ***", fails);
        $finish;
    end
    integer hb_n, lim, cyc_tb = 0, ar_host = 0, aw_host = 0, rbeat_host = 0, wbeat_host = 0;
    reg early_access = 0;
    reg trace_cmd = 0;
    initial trace_cmd = $test$plusargs("trace_cmd");
    always @(posedge clk) begin
        cyc_tb <= cyc_tb + 1;
        if (g2_arvalid && g2_arready) ar_host <= ar_host + 1;
        if (g2_awvalid && g2_awready) aw_host <= aw_host + 1;
        if (g2_rvalid && g2_rready) rbeat_host <= rbeat_host + 1;
        if (g2_wvalid && g2_wready) wbeat_host <= wbeat_host + 1;
        if (!started && rst_n && (g2_arvalid || g2_awvalid || g2_wvalid)) early_access <= 1;
        if (trace_cmd && dut.t_cmd_valid && dut.t_cmd_ready)
            $display("CMD cyc=%0d idx=%0d %s key=%0d", cyc_tb, dut.idx, dut.t_cmd == 0 ? "PUT" : "GET", dut.t_paddr);
        if (trace_cmd && dut.kst == 5'd18) $display("NEXT cyc=%0d idx=%0d stat=%h lat=%0d", cyc_tb, dut.idx, dut.stat, dut.lat);
        if (hb_n > 0 && cyc_tb % hb_n == 0 && cyc_tb > 0) begin
            $display("HB cyc=%0d kst=%0d core_run=%0d tiny_idle=%0d idx=%0d tree AR=%0d AW=%0d",
                     cyc_tb, dut.kst, dut.core_run, dut.t_idle, dut.idx, ar_host, aw_host);
            $fflush;
        end
        if (cyc_tb == lim) begin $display("FAIL: global limit of %0d cycles reached (kst=%0d)", lim, dut.kst); $fflush; $finish; end
    end
    initial begin
        if (!$value$plusargs("hb=%d", hb_n)) hb_n = 50000;
        if (!$value$plusargs("limit=%d", lim)) lim = 40000000;
    end
endmodule
