# xsim_run.tcl -- run a DOMA testbench in Vivado's simulator (XSim) from the Vivado Tcl shell.
# Works on Windows and Linux (Vivado's project flow handles the paths).  (UNTESTED here)
#   cd <package>/sim
#   vivado -mode batch -source xsim_run.tcl -tclargs kernel      ;# doma_kernel end to end (production build)
#   vivado -mode batch -source xsim_run.tcl -tclargs selftest    ;# onboard self-test (53 tests in two-client builds)
# Add "gui" as a second argument to open the waveform viewer instead of running in batch.
set test [expr {[llength $argv] > 0 ? [lindex $argv 0] : "kernel"}]
set gui  [expr {[llength $argv] > 1 && [lindex $argv 1] eq "gui"}]
set here [file normalize [pwd]]
set rtl  [file normalize [file join $here .. rtl]]

create_project -force xsim_$test [file join $here xsim_$test] -part xcu55c-fsvh2892-2L-e
set_property target_language Verilog [current_project]
foreach f [glob -directory $rtl *.v] { add_files -fileset sim_1 -norecurse $f }
add_files -fileset sim_1 -norecurse [file join $rtl oram_params.vh]
set_property file_type {Verilog Header} [get_files oram_params.vh]
set_property include_dirs [list $rtl] [get_filesets sim_1]

switch $test {
    kernel {
        add_files -fileset sim_1 -norecurse [file join $here axi_mem_model.v] [file join $here tb_doma_kernel.v]
        set top tb_doma_kernel
        set defs {ORAM_SECURE_BUILD}
        set plusargs {-testplusarg hb=0}
    }
    selftest {
        add_files -fileset sim_1 -norecurse [file join $here oram_timing_monitor.v] [file join $here tb_onboard_test_top.v]
        set top tb_onboard_test_top
        set defs {SIMULATION ORAM_DEBUG_PORTS}
        set plusargs {}
    }
    default { puts "unknown test '$test' (kernel | selftest)"; exit 1 }
}
set_property top $top [get_filesets sim_1]
set_property top_lib xil_defaultlib [get_filesets sim_1]
set_property verilog_define $defs [get_filesets sim_1]
set_property -name {xsim.simulate.runtime} -value {-all} -objects [get_filesets sim_1]
if {$plusargs ne ""} { set_property -name {xsim.simulate.xsim.more_options} -value $plusargs -objects [get_filesets sim_1] }
update_compile_order -fileset sim_1
launch_simulation
if {!$gui} {
    # the testbench prints its verdict ("ALL CHECKS PASSED" / "ALL ... TESTS PASSED") in the log
    set log [file join $here xsim_$test xsim_$test.sim sim_1 behav xsim simulate.log]
    puts "simulation log: $log"
    close_sim
    exit
}
