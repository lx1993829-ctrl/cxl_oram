#!/bin/bash
# Full regression with Verilator (5.x, --timing). Run from anywhere:
#   bash run_verilator.sh            # everything (~10 min on a laptop)
#   bash run_verilator.sh selftest   # one group: lint | units | selftest | arrival | ni | stress | bp | secure | worst | kernel | crypto
#   ORAM_BEATS=8 bash run_verilator.sh      # block size in beats (default 128 = 4 KB)
# Exit code 0 = every check passed. Logs: build/*.log, build/run_*.log
set -u
cd "$(dirname "$0")"
RTL=../rtl
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
# DOMA serves one client: one ORAM, accesses on demand, no schedule, no dummy accesses.
if [ "${ORAM_CONFIG:-single}" != single ]; then
    echo "only the single-client build exists (the two-client build and its schedule were removed)"; exit 2
fi
ORAM_CONFIG=single; CFG=""; PIDX=1
# block size in 32-byte beats (128 = 4 KB; 1, 2, 4, 8 = 32-256-byte records)
ORAM_BEATS=${ORAM_BEATS:-128}; export ORAM_BEATS
# measured U55C HBM worst-case read latency to the first position (2M samples): 32-byte read 179, 4 KB burst 307
export MEM_L0_MAX=$( [ "${ORAM_BEATS:-128}" = 1 ] && echo 179 || echo 307 )   # 64 B..4 KB: the 4 KB burst worst (budgets.py)
VFLAGS="--binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -I$RTL $CFG -DORAM_BLOCK_BEATS=$ORAM_BEATS"
# a value from oram_params.vh
pval() { grep -E "^\`define $1 " $RTL/oram_params.vh | tr -d '\r' | awk '{print $3}' | sed -n "${PIDX}p"; }
CT_WB_BUDGET=$(grep -E "^\`define ORAM_CT_WB_B$ORAM_BEATS " $RTL/oram_params.vh | tr -d '\r' | awk '{print $3}')
CT_WB_BUDGET=${CT_WB_BUDGET:-$(grep -E '^`define ORAM_CT_WB_B128 ' $RTL/oram_params.vh | tr -d '\r' | awk '{print $3}')}   # unlisted size: 4 KB budgets
PM_LAT=$(grep -E '^`define ORAM_PM_LAT ' $RTL/oram_params.vh | tr -d '\r' | awk '{print $3}')   # position-map lookup budget (HBM)
CT_WB_BUDGET=$((CT_WB_BUDGET + PM_LAT))
ZPOS=$(grep -E '^`define ORAM_Z ' $RTL/oram_params.vh | awk '{print $3}')
LEAD=$(( (ZPOS - 1) * ORAM_BEATS ))   # the write-back reaches the last position this many cycles after it starts
GROUP=${1:-all}
mkdir -p build
# cached builds belong to one configuration: start clean when it changes
if [ "$(cat build/.config 2>/dev/null)" != "$ORAM_CONFIG beats=$ORAM_BEATS" ]; then rm -rf build; mkdir -p build; echo "$ORAM_CONFIG beats=$ORAM_BEATS" > build/.config; fi
echo "configuration: $ORAM_CONFIG, block = $ORAM_BEATS beats ($((ORAM_BEATS * 32)) bytes)"
FAILS=0
pass() { echo "  PASS  $1"; }
fail() { echo "  FAIL  $1"; FAILS=$((FAILS+1)); }
want() { [ "$GROUP" = all ] || [ "$GROUP" = "$1" ]; }
build() {   # build <name> <top> <tb file> <extra flags...>
    local name=$1 top=$2 tb=$3; shift 3
    [ -x build/$name/V$name ] && [ -z "${REBUILD:-}" ] && return 0
    echo "  building $name ..."
    rm -rf build/$name
    verilator $VFLAGS "$@" --top-module $top ./$tb ./oram_timing_monitor.v ./axi_mem_model.v $SRCS -Mdir build/$name -o V$name \
        > build/$name.build.log 2>&1 || { echo "  BUILD FAILED: $name (build/$name.build.log)"; exit 2; }
}
run() { local name=$1 tag=$2; shift 2; ./build/$name/V$name "$@" > build/run_$tag.log 2>&1; }

if want lint; then
    # Vivado rejects out-of-range part-selects that Verilator only warns about (SELRANGE), e.g. a
    # fixed [6:0] slice of a counter that is narrower for small blocks. Fail on any of them.
    echo "== lint: no out-of-range part-selects at this block size"
    n=$(verilator --lint-only -Wno-fatal -Wall -DORAM_SECURE_BUILD -DORAM_BLOCK_BEATS=$ORAM_BEATS -I$RTL \
          --top-module doma_kernel $SRCS $RTL/doma_kernel.v 2>&1 | tee build/lint.log | grep -c "%Warning-SELRANGE")
    e=$(grep -c "^%Error" build/lint.log)
    [ "$n" = 0 ] && [ "$e" = 0 ] && pass "lint: no out-of-range part-selects or errors ($ORAM_BEATS-beat blocks)" \
        || fail "lint: $n out-of-range part-selects, $e errors (build/lint.log)"
    # Vivado treats a name used before its declaration in an instance's port connection as an implicit wire, and
    # then rejects a later constant (localparam) of that name: "already declared" (a later reg it accepts).
    # Verilator accepts both. iverilog -Wimplicit lists the implicit names.
    if command -v iverilog > /dev/null; then
        bad=""
        while IFS= read -r m; do
            f=$(echo "$m" | cut -d: -f1); n=$(echo "$m" | grep -oE "wire '[A-Za-z_0-9]+'" | cut -d"'" -f2)
            # a constant: on a localparam/parameter line, or "NAME = <sized number>" inside a multi-line list
            [ -n "$n" ] && grep -qE "((localparam|parameter)\b[^;]*\b$n\b[[:space:]]*=)|(^[[:space:]]*$n[[:space:]]*=[[:space:]]*[0-9]+'[bdh])|([,(][[:space:]]*$n[[:space:]]*=[[:space:]]*[0-9]+'[bdh])" "$f" && bad="$bad $(basename $f):$n"
        done < <(iverilog -g2012 -Wimplicit -I$RTL -DORAM_BLOCK_BEATS=$ORAM_BEATS -DORAM_SCHED_ARRIVAL -s doma_kernel -o /dev/null $RTL/*.v 2>&1 | grep "implicit definition")
        bad=$(echo $bad | tr " " "\n" | sort -u | tr "\n" " ")
        [ -z "${bad// /}" ] && pass "lint: no constant is used before its declaration (Vivado would reject it)" \
                           || fail "lint: constant used before its declaration (Vivado: already declared): $bad"
    fi
fi
if want units; then
    # the HBM metadata modules alone, against reference models, with the measured HBM latency profile
    # (including a phase where writes land late: a read that overtook a write would be caught)
    echo "== units: HBM position map, bucket records and stash"
    build pmh tb_pmh tb_pmh.v
    run pmh pmh
    grep -q "POS_MAP_HBM: ALL CHECKS PASSED" build/run_pmh.log \
        && pass "pos_map_hbm: $(grep -oE '[0-9]+ reads checked' build/run_pmh.log), reads never overtake writes" \
        || fail "pos_map_hbm unit test (build/run_pmh.log)"
    build brec tb_brec tb_brec.v
    run brec brec
    grep -q "BUCKET_REC_HBM: ALL CHECKS PASSED" build/run_brec.log \
        && pass "bucket_rec_hbm: $(grep -oE '[0-9]+ checks' build/run_brec.log), record fetches never overtake writes" \
        || fail "bucket_rec_hbm unit test (build/run_brec.log)"
    # stash: windows + chains through a bounded pool, against an exact reference model (eviction order, data,
    # allocated pool indexes, the chain step). Uniform traffic; hot traffic (long chains); a pool smaller than N
    # (free-list recycling); and exhaustion, which must be the ONLY failure and happen exactly when the pool is empty.
    build stash tb_stash tb_stash.v
    run stash stash +acc=3000
    run stash stash_hot +hot=60 +acc=4000
    run stash stash_pool +poolpct=40 +acc=6000
    run stash stash_ovf +pool=60 +hot=60 +acc=4000 +overflow
    run stash stash_dir +directed +acc=2000       # the counterexample for Z candidates: must move in every slot that fits
    st_ok=1; for v in stash stash_hot stash_pool stash_ovf stash_dir; do grep -q "STASH_HBM: ALL CHECKS PASSED" build/run_$v.log || st_ok=0; done
    if [ $st_ok = 1 ] && grep -q "fail-stop exactly there" build/run_stash_ovf.log && grep -q "every waiting slot that fits moved in" build/run_stash_dir.log; then
        pass "stash_hbm: $(grep -oE '[0-9]+ accesses, [0-9]+ evictions' build/run_stash.log); hot: longest chain $(grep -oE 'longest chain [0-9]+' build/run_stash_hot.log | grep -oE '[0-9]+'); pool < N recycles; exhaustion is the only failure, exactly when the pool is empty; no read moves in fewer slots than fit (directed counterexample included)"
    else fail "stash_hbm unit tests (build/run_stash*.log)"; fi
    # bucket addresses past 4 GB (4 KB blocks at N = 1M need 5 GB of buckets): every burst of chosen buckets checked
    build addrw tb_addr_wide tb_addr_wide.v -DORAM_N=1048576
    run addrw addrw
    if grep -q "ALL CHECKS PASSED" build/run_addrw.log; then
        pass "axi_master: bucket addresses at N = 1M exact and page-aligned, $(grep -oE '[0-9]+ bursts above 4 GB checked' build/run_addrw.log)"
    else fail "axi_master: bucket addresses at N = 1M (build/run_addrw.log)"; fi
fi
if want selftest; then
    build selftest tb_onboard_test_top tb_onboard_test_top.v -DSIMULATION -DORAM_DEBUG_PORTS $RTL/onboard_test_top.v
    run selftest selftest +timing_log=build/timing_selftest.csv
    echo "== onboard self-test (one client) and tamper detection"
    grep -q "ALL 50 RUN TESTS PASSED (3 skipped" build/run_selftest.log \
        && pass "self-test, one client: 50 tests passed (3 two-client tests skipped)" \
        || fail "self-test, one client (build/run_selftest.log)"
    for m in tamper_hole tamper_target; do
        run selftest $m +$m
        grep -q "TAMPER RESULT: DETECTED" build/run_$m.log && pass "$m: detected, controller halted" || fail "$m (build/run_$m.log)"
    done
fi
if want ni || want secure; then
    build ni tb_ni tb_ni.v -DORAM_DEBUG_PORTS
fi
if want ni; then
    echo "== one client: two traffic patterns with correct data"
    ok=1
    for v in 0 1; do      # the variant seeds the client's request pattern
        run ni ni$v +ni=$v +ops=10
        L=$(grep "NI:" build/run_ni$v.log); echo "        $L" | cut -c1-150
        echo "$L" | grep -q "errors=0 .*errors=0 " || ok=0
    done
    [ $ok = 1 ] && pass "one client: data correct in both traffic patterns" || fail "one-client traffic (build/run_ni*.log)"
fi
if want stress; then
    echo "== worst case: $ZPOS evictions in one access"
    build ni tb_ni tb_ni.v -DORAM_DEBUG_PORTS
    build cal tb_ni tb_ni.v -DORAM_DEBUG_PORTS -DORAM_CT_RD=0 -DORAM_CT_WB=0 -DORAM_CT_DONE=0 -DORAM_TDM_SLOT=20000
    run ni stress +stress +timing_log=build/timing_stress.csv   # its full-bucket evictions complete the worst-case model
    grep -q "evictions in one access=$ZPOS .*ct_overrun=0  data_errors=0" build/run_stress.log \
        && pass "gated: $ZPOS evictions (a full bucket) in one access, no overrun, data correct" || fail "gated stress (build/run_stress.log)"
    run cal stress_cal +stress
    # Streaming write-back: it starts at CT_WB while encryption finishes, so the
    # worst encryption end may exceed CT_WB by up to 7*128 beats (the master
    # needs that long to reach the last position).
    # The worst case is the max over ALL paths, not just the 8-eviction stress:
    # with eviction overlap, two-copy paths (e.g. bucket-hit write + compaction)
    # are slower. So the full self-test is calibrated too.
    build selfcal tb_onboard_test_top tb_onboard_test_top.v -DSIMULATION -DORAM_DEBUG_PORTS \
          -DORAM_CT_RD=0 -DORAM_CT_WB=0 -DORAM_CT_DONE=0 -DORAM_TDM_SLOT=20000 $RTL/onboard_test_top.v
    run selfcal selftest_cal
    a1=$(grep -oE "ct_max_wb=[0-9]+" build/run_stress_cal.log | cut -d= -f2)
    a2=$(grep -oE "CT arrivals: rd=[0-9]+ wb=[0-9]+" build/run_selftest_cal.log | grep -oE "wb=[0-9]+" | cut -d= -f2)
    arr=$(( ${a1:-999999} > ${a2:-999999} ? ${a1:-999999} : ${a2:-999999} ))
    lim=$((CT_WB_BUDGET + LEAD))
    if [ -n "$a1" ] && [ -n "$a2" ] && [ "$arr" -le "$lim" ] && grep -q "data_errors=0" build/run_stress_cal.log \
       && grep -qE "ALL 53 TESTS PASSED|ALL 50 RUN TESTS PASSED" build/run_selftest_cal.log; then
        pass "calibration: worst encryption end $arr (stress $a1, all paths $a2) <= CT_WB + $LEAD = $lim"
    else fail "calibration: encryption end stress=${a1:-?} all-paths=${a2:-?} vs limit $lim (build/run_*_cal.log)"; fi
    # Negative control: a write-back budget far too early (half the calibrated worst
    # encryption end, before re-encryption even starts, for any block size) must be caught
    # (overrun, fail-stop) without the write-back ever reading an unencrypted position.
    EARLY=$(( ${arr:-$CT_WB_BUDGET} / 2 ))
    build early tb_ni tb_ni.v -DORAM_DEBUG_PORTS -DORAM_CT_WB=$EARLY
    run early stress_early +stress
    if grep -q "ct_overrun=1" build/run_stress_early.log && ! grep -q "SAFETY" build/run_stress_early.log; then
        pass "negative control: write-back at $EARLY (too early) caught, no plaintext read"
    else fail "negative control (build/run_stress_early.log)"; fi
fi
if want bp; then
    echo "== AXI backpressure (30% ready-low and read-data gaps, gates off)"
    build cal tb_ni tb_ni.v -DORAM_DEBUG_PORTS -DORAM_CT_RD=0 -DORAM_CT_WB=0 -DORAM_CT_DONE=0 -DORAM_TDM_SLOT=20000
    ok=1
    for v in 1 2; do
        run cal bp$v +ni=$v +ops=8 +bp=30
        grep -qE "NI: variant=$v client[01] ops=8 errors=0 .*client0 ops=[0-9]* errors=0" build/run_bp$v.log || ok=0
    done
    [ $ok = 1 ] && pass "the client active under backpressure: data correct, no integrity error" || fail "backpressure (build/run_bp*.log)"
fi
if want secure; then
    echo "== production configuration (ORAM_SECURE_BUILD, no debug ports)"
    build sec tb_ni tb_ni.v -DORAM_SECURE_BUILD
    # each run of the production build must match the debug build's run of the same variant
    ok=1; refs=""
    for v in 0 1; do
        [ -f build/run_ni$v.log ] || run ni ni$v +ni=$v +ops=10
        ref=$(grep -oE "trace-hash=[0-9a-f]+" build/run_ni$v.log)
        run sec sec$v +ni=$v +ops=10
        [ -n "$ref" ] && grep -q "$ref" build/run_sec$v.log && grep -q "errors=0 .*errors=0" build/run_sec$v.log || ok=0
        refs="$refs ${ref#trace-hash=}"
    done
    [ $ok = 1 ] && pass "secure build behaves identically (trace-hashes$refs) with debug ports removed" || fail "secure build (build/run_sec*.log)"
fi
if want worst; then
    echo "== derived worst case: cycle model validated on every traced access"
    build ni tb_ni tb_ni.v -DORAM_DEBUG_PORTS
    # gap-free bucket delivery and fixed metadata latencies: the derivation is the on-chip worst case; every
    # memory-dependent effect is measured separately (arrival, combined, hostwait)
    run ni worst +worst +timing_log=build/timing_worst.csv +bus_log=build/bus_worst.csv +meta_slow_pct=0 +brec_slow_pct=0 +stash_slow_pct=0
    # Every window must present the bucket read and the write-back on the AXI bus at the
    # same offset from the window start, and read a bucket inside DOMA's bucket range.
    # BUCKET_ID_W is derived in oram_params.vh ($clog2 of ceil(N / lambda)); compute it the same way here
    NNP=$(pval ORAM_N); CCP=$(pval ORAM_C); NBKP=$(( (NNP + CCP - 1) / CCP ))
    BUCKW=0; while [ $(( 1 << BUCKW )) -lt "$NBKP" ]; do BUCKW=$((BUCKW + 1)); done
    PARTW=$(pval ORAM_PART_W)
    if out=$(python3 - "$BUCKW" "$PARTW" <<'PYEOF'
import csv, sys
bw, pw = int(sys.argv[1]), int(sys.argv[2])
r=[x for x in csv.DictReader(open('build/bus_worst.csv')) if None not in x.values() and int(x['ar_offset'])>=0 and int(x['aw_offset'])>=0]
a={x['ar_offset'] for x in r}; w={x['aw_offset'] for x in r}
bad=[x for x in r if (int(x['bucket']) >> bw) != 0]
if r and len(a)==1 and len(w)==1 and not bad: print(len(r), a.pop(), w.pop())
else: print("FAIL", len(a), len(w), len(bad)); sys.exit(1)
PYEOF
    ); then
        set -- $out; pass "bus timing: all $1 windows read at offset $2, write back at offset $3, every bucket in range"
    else fail "bus timing differs between windows or a bucket is out of range ($out; build/bus_worst.csv)"; fi
    grep -q "data_errors=0, ct_overrun=0" build/run_worst.log || fail "directed worst-case scenarios (build/run_worst.log)"
    if [ ! -f build/timing_selftest.csv ]; then
        build selftest tb_onboard_test_top tb_onboard_test_top.v -DSIMULATION -DORAM_DEBUG_PORTS $RTL/onboard_test_top.v
        run selftest selftest +timing_log=build/timing_selftest.csv
    fi
    if python3 worst_case.py --params $RTL/oram_params.vh build/timing_worst.csv build/timing_selftest.csv $( [ -f build/timing_stress.csv ] && echo build/timing_stress.csv ) > build/worst_case.txt 2>&1; then
        pass "derived worst case fits the budget: $(grep -oE 'derived worst encryption end = [^)]*= [0-9]+' build/worst_case.txt | sed -E 's/.*= //' | tr '\n' ' ')vs deadline $(grep -oE 'deadline [0-9]+' build/worst_case.txt | head -1 | cut -d' ' -f2) (build/worst_case.txt)"
    else fail "worst-case analysis (build/worst_case.txt)"; fi
fi
if want combined; then
    # B.3: HBM buckets (fast bucket read), every position-map / stash / record read slow, and tb_ni's directed
    # worst cases, which include a full stash window (9 waiting blocks, one of them requested): the stash can then
    # finish after verification. Arrival mode; reports the worst work after the last beat (ar_max_wb_h).
    echo "== combined adverse case: HBM buckets, slow metadata, full stash window (arrival mode)"
    build ni_ar tb_ni tb_ni.v -DORAM_DEBUG_PORTS -DORAM_SCHED_ARRIVAL
    MEM_L0_MAX=0 run ni_ar combined +worst +hbm_bkts=255 +meta_lat=200 +stash_lat=200 +brec_lat=200 +meta_slow_pct=0 +stash_slow_pct=0 +brec_slow_pct=0
    l=$(grep -aoE "ar_max_wb=[0-9]+ ar_max_wb_h=[0-9]+" build/run_combined.log)
    grep -q "data_errors=0, ct_overrun=0" build/run_combined.log && pass "combined adverse case: $l" || fail "combined adverse case (build/run_combined.log)"
fi
if want hostwait; then
    # B.5: host buckets must never wait for the stash. Worst case all at once: every bucket in host memory at 240
    # cycles (below the U55C's lowest observed read, 815 ns = 244 cycles at 300 MHz), every metadata read at 200
    # cycles, and tb_ni's directed worst cases including a full stash window. Stash wait = scan start - stash ready.
    echo "== host buckets never wait for the stash (240-cycle host reads, slow metadata, full stash window)"
    build ni_ar tb_ni tb_ni.v -DORAM_DEBUG_PORTS -DORAM_SCHED_ARRIVAL
    MEM_L0_MAX=0 run ni_ar hostwait +worst +hbm_bkts=0 +bkt_lat=240 +meta_lat=200 +stash_lat=200 +brec_lat=200 +meta_slow_pct=0 +stash_slow_pct=0 +brec_slow_pct=0 +timing_log=build/timing_hostwait.csv
    hw=$(python3 -c "
import csv
rows=[r for r in csv.DictReader(open('build/timing_hostwait.csv')) if int(r['t_scan'])>=0]
w=[(int(r['t_op']) if int(r['t_op'])>=0 else int(r['t_scan']))-int(r['t_scan']) for r in rows]
print(len(rows), max(w))" 2>/dev/null)
    n=${hw% *}; w=${hw#* }
    arw=$(grep -aoE "ar_max_wb=[0-9]+" build/run_hostwait.log | grep -oE "[0-9]+$")
    dar=""; [ -f build/worst_case.txt ] && dar=$(sed -n "/^timing_worst.csv/,/^timing_selftest.csv/p" build/worst_case.txt | grep -oE "derived after arrival = [0-9 +]+= [0-9]+" | grep -oE "[0-9]+$")
    grep -q "data_errors=0, ct_overrun=0" build/run_hostwait.log && [ -n "$hw" ] && [ "$w" -le 1 ] && { [ -z "$dar" ] || [ "${arw:-0}" -le "$dar" ]; } \
        && pass "host buckets: no access waited for the stash ($n accesses, worst stash wait $w cycle); work after the last beat $arw <= derived ${dar:-n/a: run the worst group first}" \
        || fail "host buckets with slow metadata: stash wait ${w:-?} cycles, work after the last beat ${arw:-?} vs derived ${dar:-?} (build/run_hostwait.log)"
fi
if want kernel && [ $ORAM_CONFIG = single ]; then
    echo "== Vitis kernel wrapper (doma_kernel): the testbench plays XRT"
    build kern tb_doma_kernel tb_doma_kernel.v -DORAM_SECURE_BUILD -Wno-BLKANDNBLK $RTL/doma_kernel.v
    run kern kernel +hb=0
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel.log \
        && pass "kernel: init launch, two command launches, every GET correct, bad key rejected, interrupt and CTRL as XRT expects" \
        || fail "kernel end-to-end (build/run_kernel.log)"
    run kern kernel_gap +hb=0 +cmds=40 +cmds2=10 +host_gap=30
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_gap.log && pass "kernel: 30% host read gaps, correct and unchanged latency" \
        || fail "kernel with host read gaps (build/run_kernel_gap.log)"
    # XRT launches the kernel long after reset. DOMA must boot only at the first ap_start, into
    # the pages buffer given then (booting earlier lays the buckets out at address 0).
    run kern kernel_late +hb=0 +start_delay=20000 +preload +cmds=20 +cmds2=4
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_late.log \
        && pass "kernel: first launch 20,000 cycles after reset, DOMA boots into the right buffer; 256 sequential PUTs correct" \
        || fail "kernel boot before the first launch (build/run_kernel_late.log)"
    # AXI does not order a read against an unacknowledged write. With writes landing 200 cycles
    # after their data the results must be correct; with 700 the slow acknowledgements must be
    # caught as a timing overrun, never returned as stale data (an integrity failure).
    run kern kernel_wlat +hb=0 +cmds=40 +cmds2=4 +host_wlat=60
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_wlat.log && pass "kernel: writes landing 60 cycles after their data (HBM acknowledges in 28), results correct" \
        || fail "kernel with late-landing writes (build/run_kernel_wlat.log)"
    run kern kernel_wlat_slow +hb=0 +cmds=10 +cmds2=4 +host_wlat=1200   # beyond the completion gap at every size (Z = 10, 4 KB: 1,280 beats + 1,200 > 2,000)
    if grep -q "DOMA HALT: timing overrun" build/run_kernel_wlat_slow.log && ! grep -q "DOMA HALT: integrity" build/run_kernel_wlat_slow.log; then
        pass "kernel: write acknowledgements slower than the budget are an overrun, never stale data"
    else fail "read-after-write ordering (build/run_kernel_wlat_slow.log)"; fi
    # Packed records: R-byte records inside each block, written with byte strobes (a masked write
    # merges into the block in the same access); every GET is compared with a byte-exact image of
    # the whole block, so neighbouring records and untouched bytes are checked too.
    run kern kernel_packed +packed=8 +preload +hb=0
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_packed.log \
        && pass "kernel: packed 8-byte records over preloaded blocks match the block image; bad record range rejected" \
        || fail "kernel packed records (build/run_kernel_packed.log)"
    # (late writes and read-side pauses load separate margins; pausing every channel as well
    #  stretches a 4 KB write-back past its completion budget, an overrun regardless of packing)
    run kern kernel_packed_late +packed=16 +host_wlat=60 +host_gap=30 +hb=0
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_packed_late.log \
        && pass "kernel: packed 16-byte records with late writes and read pauses, correct" \
        || fail "kernel packed records under stress (build/run_kernel_packed_late.log)"
    # run-time size (kernel argument nblk): a build with a 4,096-block maximum, run at n = 1,000 (250
    # buckets, packed records, a bad key inside the build's range) and at its maximum. Per-access cost
    # must not depend on n: the device cycles must equal the default build's.
    build kern_rt tb_doma_kernel tb_doma_kernel.v -DORAM_SECURE_BUILD -Wno-BLKANDNBLK -DORAM_N=4096 $RTL/doma_kernel.v
    run kern_rt kernel_rt1000 +hb=0 +nblk=1000 +packed=8 +preload
    run kern_rt kernel_rt4096 +hb=0 +nblk=4096
    c_def=$(grep -oE "^run1: .*device total=[0-9]+" build/run_kernel.log | grep -oE "[0-9]+$")
    c_rt=$(grep -oE "^run1: .*device total=[0-9]+" build/run_kernel_rt4096.log | grep -oE "[0-9]+$")
    if grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_rt1000.log && grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_rt4096.log \
       && [ -n "$c_def" ] && [ "$c_def" = "$c_rt" ]; then
        pass "kernel: run-time size (4,096-block build at n = 1,000 packed and n = 4,096), correct, same cycles as the default ($c_rt)"
    else fail "kernel run-time size (build/run_kernel_rt1000.log, build/run_kernel_rt4096.log; cycles $c_def vs $c_rt)"; fi
    # buckets split between host memory and HBM (fixed boundary, DOMA_HBM_PCT): 25% in HBM (gmem6), packed records
    run kern kernel_hbm25 +hb=0 +hbm_pct=25 +packed=8 +preload
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_hbm25.log \
        && pass "kernel: 25% of the buckets in HBM (second bucket port), packed records, correct" \
        || fail "kernel with 25% of the buckets in HBM (build/run_kernel_hbm25.log)"
    # bounded stash pool (windows + chains): a 4,096-block build with the host's Claim 1 sizing for that n (1,999
    # entries) and with a much smaller pool; correct, and exhaustion (the only possible overflow) never reached
    PK=""; [ "$ORAM_BEATS" = 1 ] && PK="+packed=8 +preload"      # packed preload: 32-byte blocks only (4 KB exceeds the cycle limit)
    run kern_rt kernel_pool +hb=0 +nblk=4096 +pool=1999 $PK
    run kern_rt kernel_pool_small +hb=0 +nblk=4096 +pool=600
    if grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_pool.log && grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_pool_small.log; then
        pass "kernel: bounded stash pool (1,999 and 600 entries for 4,096 blocks), correct"
    else fail "kernel with a bounded stash pool (build/run_kernel_pool*.log)"; fi
    # re-boot: an init launch on a booted kernel resets DOMA and boots it with new arguments (n 4,096 ->
    # 1,000, pages buffer moved 16 MB), as a new host process does; no 0x20, every block reads as zeros
    run kern_rt kernel_reboot +hb=0 +nblk=4096 +reboot +nblk2=1000 +pagesoff=16777216 +cmds=40 +cmds2=10
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_reboot.log && grep -q "^reinit: " build/run_kernel_reboot.log \
        && pass "kernel: an init launch re-boots DOMA with new arguments (n 4,096 -> 1,000, pages moved), correct" \
        || fail "kernel re-boot on an init launch (build/run_kernel_reboot.log)"
    # PCIe-like latency beyond the budgets: DOMA must halt and the kernel must still finish the run
    run kern kernel_pcie +hb=0 +cmds=10 +cmds2=4 +host_lat=600
    if grep -qE "^run1: size=10 .*errors=00000008" build/run_kernel_pcie.log && grep -qE "^run2: size=4 " build/run_kernel_pcie.log; then
        pass "kernel: budget overrun at 600-cycle host latency ends the run with error 0x8, no hang (budgets need PCIe recalibration)"
    else fail "kernel abort path (build/run_kernel_pcie.log)"; fi
fi
if want arrival; then
    # acknowledgements later than the next read, so the read-behind-write guard must hold it: 1,500 cycles at 32 B,
    # 2,500 at 4 KB (its write-back is 1,280 beats; the host model buffers 8,192 beats until they land)
    WSLOW=$([ "${ORAM_BEATS:-1}" = 128 ] && echo 2500 || echo 1500)
    # arrival-relative scheduling (build option ORAM_SCHED_ARRIVAL, for buckets in host memory): the kernel tests
    # at PCIe-like latencies (reads 263 cycles on average, acknowledgements 98, both measured on the U55C), a read
    # at the measured maximum (950), packed records and slow metadata. The worst on-chip work after the arrival
    # (from the worst group's cycle model, and as measured) must fit AR_WB.
    echo "== arrival: arrival-relative scheduling"
    build kern_ar tb_doma_kernel tb_doma_kernel.v -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -Wno-BLKANDNBLK $RTL/doma_kernel.v
    ar_ok=1; ar_meas=0; ar_meas_h=0
    for v in "pcie:+host_lat=263 +host_wlat=98" "pcie_max:+host_lat=950 +host_wlat=98" "packed:+packed=8 +preload +host_lat=263 +host_wlat=98" \
             "slowmeta:+meta_slow_pct=10 +brec_slow_pct=10 +stash_slow_pct=10 +host_lat=263 +host_wlat=98" \
             "hbm20:+hbm_pct=20 +host_lat=263 +host_wlat=98" "hbm50:+hbm_pct=50 +packed=8 +preload +host_lat=263 +host_wlat=98" \
             "hbm50u:+hbm_pct=50 +host_lat=263 +host_wlat=98" "hbm100max:+hbm_pct=100 +hbmb_lat=179 +host_lat=263 +host_wlat=98" \
             "wlat_slow:+nblk=64 +cmds=300 +host_lat=263 +host_wlat=$WSLOW" \
             "hbmadverse:+hbm_pct=100 +hbmb_lat=52 +meta_lat=200 +stash_lat=200 +brec_lat=200 +meta_slow_pct=0 +stash_slow_pct=0 +brec_slow_pct=0"; do
        nm=${v%%:*}; args=${v#*:}
        run kern_ar kernel_ar_$nm +hb=0 $args
        grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_ar_$nm.log || { ar_ok=0; echo "   $nm failed (build/run_kernel_ar_$nm.log)"; }
        m=$(grep -oE "ar_max_wb=[0-9]+" build/run_kernel_ar_$nm.log | head -1 | cut -d= -f2); [ -n "$m" ] && [ "$m" -gt "$ar_meas" ] && ar_meas=$m
        m=$(grep -oE "ar_max_wb_h=[0-9]+" build/run_kernel_ar_$nm.log | head -1 | cut -d= -f2); [ -n "$m" ] && [ "$m" -gt "${ar_meas_h:-0}" ] && ar_meas_h=$m
    done
    lat=$(grep -oE "^run1: .*latency min/max=[0-9/]+" build/run_kernel_ar_pcie.log | grep -oE "[0-9]+/[0-9]+$")
    [ $ar_ok = 1 ] && pass "arrival: kernel tests correct at PCIe-like latencies (per command $lat cycles), at a 950-cycle read, packed, slow metadata, 20/50/100% of the buckets in HBM" \
                   || fail "arrival-relative kernel tests"
    # GET or PUT must not show in the timing: the same 300 keys as all GETs and as all PUTs, identical bucket-port timing
    for k in kern_ar kern; do
        [ -x build/$k/V$k ] || continue
        la=$([ $k = kern_ar ] && echo "+host_lat=263 +host_wlat=98")     # strict mode: its own (non-PCIe) budgets, default latencies
        run $k uni0_$k   +hb=0 +preload +cmds=300 +cmds2=4 $la +seed=3 +put_pct=0
        run $k uni100_$k +hb=0 +preload +cmds=300 +cmds2=4 $la +seed=3 +put_pct=100
        u0=$(grep -E "^run1: bucket-port" build/run_uni0_$k.log); u1=$(grep -E "^run1: bucket-port" build/run_uni100_$k.log)
        d0=$(grep -oE "^run1: size.*device total=[0-9]+" build/run_uni0_$k.log | grep -oE "[0-9]+$")
        d1=$(grep -oE "^run1: size.*device total=[0-9]+" build/run_uni100_$k.log | grep -oE "[0-9]+$")
        md=$([ $k = kern ] && echo strict || echo arrival)
        if [ -n "$u0" ] && [ "$u0" = "$u1" ] && [ "$d0" = "$d1" ] && grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_uni0_$k.log \
           && grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_uni100_$k.log; then
            pass "$md: GETs and PUTs indistinguishable: same keys, all GETs vs all PUTs, identical bucket-port timing ($(echo "$u0" | grep -oE 'hash [0-9a-f]+'), $d0 cycles)"
        else fail "$md: bucket-port timing differs between all-GET and all-PUT streams (build/run_uni*_$k.log)"; fi
    done
    c0=$(grep -oE "^run1: .*device total=[0-9]+" build/run_kernel_ar_pcie.log | grep -oE "[0-9]+$")
    c50=$(grep -oE "^run1: .*device total=[0-9]+" build/run_kernel_ar_hbm50u.log | grep -oE "[0-9]+$")
    if [ -n "$c0" ] && [ -n "$c50" ] && [ "$c50" -lt "$c0" ]; then pass "arrival: 50% of the buckets in HBM is faster than 0% ($c50 vs $c0 cycles)"
    else fail "arrival: 50% of the buckets in HBM is not faster than 0% ($c50 vs $c0)"; fi
    if [ "$ORAM_BEATS" = 1 ]; then ARWB=$(pval ORAM_AR_WB_B1); elif [ "$ORAM_BEATS" = 128 ]; then ARWB=$(pval ORAM_AR_WB_B128); else ARWB=""; fi
    der=""   # the derived after-arrival bound (worst group, gap-free trace), counted from the last beat
    [ -f build/worst_case.txt ] && der=$(sed -n "/^timing_worst.csv/,/^timing_selftest.csv/p" build/worst_case.txt | grep -oE "derived after arrival = [0-9 +]+= [0-9]+" | grep -oE "[0-9]+$")
    if [ -n "$ARWB" ]; then
        if [ "$ar_meas" -le "$ARWB" ] && { [ -z "$der" ] || [ "$der" -le "$ARWB" ]; }; then
            pass "arrival: worst work after the arrival fits AR_WB = $ARWB (measured $ar_meas, derived ${der:-n/a: run the worst group first})"
        else fail "arrival: worst work after the arrival exceeds AR_WB = $ARWB (measured $ar_meas, derived ${der:-n/a})"; fi
    fi
    if [ "$ORAM_BEATS" = 1 ]; then ARWBH=$(pval ORAM_AR_WB_H_B1); elif [ "$ORAM_BEATS" = 128 ]; then ARWBH=$(pval ORAM_AR_WB_H_B128); else ARWBH=""; fi
    if [ -n "$ARWBH" ]; then
        if [ "${ar_meas_h:-0}" -gt 0 ] && [ "${ar_meas_h:-0}" -le "$ARWBH" ]; then
            pass "arrival: HBM buckets' worst work after the arrival fits AR_WB_H = $ARWBH (measured ${ar_meas_h}, every HBM metadata read at 200 cycles)"
        else fail "arrival: HBM buckets' worst work after the arrival vs AR_WB_H = $ARWBH (measured ${ar_meas_h:-none})"; fi
    fi
fi
if want crypto; then
    echo "== crypto units: AES-128 known answers, GHASH against an independent reference"
    if iverilog -g2001 -s tb_kat -o build/kat.vvp tb_aes_kat.v $RTL/aes128_round_fpga.v $RTL/aes128_key_expansion_fpga.v $RTL/aes_func.v > build/kat.build.log 2>&1; then
        vvp -n build/kat.vvp > build/run_kat.log 2>&1
        [ "$(grep -c 'MATCHES FIPS-197' build/run_kat.log)" = 2 ] && pass "AES-128 pipeline: FIPS-197 Appendix B and C.1 known answers" || fail "AES known answers (build/run_kat.log)"
    else fail "AES known-answer build (build/kat.build.log)"; fi
    if python3 ghash_ref.py build/vec.hex > build/ghash_ref.log 2>&1 && iverilog -g2001 -s tb_ghash -o build/ghash.vvp tb_ghash.v $RTL/ghash_lane3.v $RTL/ghash_single_cycle_fpga.v > build/ghash.build.log 2>&1; then
        (cd build && vvp -n ghash.vvp +gaps=0 > run_ghash0.log 2>&1; vvp -n ghash.vvp +gaps=1 > run_ghash1.log 2>&1)
        grep -q "0 mismatches (gaps=0) PASS" build/run_ghash0.log && grep -q "0 mismatches (gaps=1) PASS" build/run_ghash1.log \
            && pass "GHASH unit: 300 random messages match the reference (self-checked on GCM test case 2), back-to-back and with gaps" \
            || fail "GHASH unit (build/run_ghash*.log)"
    else fail "GHASH test build (build/ghash_ref.log, build/ghash.build.log)"; fi
fi
# no run may report a safety-monitor violation or a scratch bank conflict
if grep -lE "SAFETY VIOLATION|SCRATCH: bank conflict" build/run_*.log 2>/dev/null | grep -q .; then
    fail "safety monitor / bank conflict reported in: $(grep -lE 'SAFETY VIOLATION|SCRATCH: bank conflict' build/run_*.log | tr '\n' ' ')"
else pass "no safety-monitor violations or scratch bank conflicts in any run"; fi
echo
if [ $FAILS = 0 ]; then echo "ALL CHECKS PASSED"; exit 0; else echo "$FAILS CHECK(S) FAILED"; exit 1; fi
