#!/bin/bash
# Full regression with Verilator (5.x, --timing). Run from anywhere:
#   bash run_verilator.sh            # everything (~10 min on a laptop)
#   bash run_verilator.sh selftest   # one group: selftest | ni | stress | bp | secure | worst | kernel
#   ORAM_CONFIG=two bash run_verilator.sh   # the two-client build (default: single, the paper's)
# Exit code 0 = every check passed. Logs: build/*.log, build/run_*.log
set -u
cd "$(dirname "$0")"
RTL=../rtl
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
ORAM_CONFIG=${ORAM_CONFIG:-single}
case $ORAM_CONFIG in
    single) CFG="";                   PIDX=2 ;;   # one client, one ORAM, no dummies
    two)    CFG="-DORAM_TWO_CLIENTS"; PIDX=1 ;;   # two clients, two partitions, schedule
    *) echo "ORAM_CONFIG must be single or two"; exit 2 ;;
esac
VFLAGS="--binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -I$RTL $CFG"
# a value from oram_params.vh for this configuration (two-client values come first)
pval() { grep -E "^\`define $1 " $RTL/oram_params.vh | awk '{print $3}' | sed -n "${PIDX}p"; }
CT_WB_BUDGET=$(grep -E '^`define ORAM_CT_WB ' $RTL/oram_params.vh | awk '{print $3}')
ZPOS=$(grep -E '^`define ORAM_Z ' $RTL/oram_params.vh | awk '{print $3}')
LEAD=$(( (ZPOS - 1) * 128 ))   # the write-back reaches the last position this many cycles after it starts
GROUP=${1:-all}
mkdir -p build
# cached builds belong to one configuration: start clean when it changes
if [ "$(cat build/.config 2>/dev/null)" != "$ORAM_CONFIG" ]; then rm -rf build; mkdir -p build; echo "$ORAM_CONFIG" > build/.config; fi
echo "configuration: $ORAM_CONFIG"
FAILS=0
pass() { echo "  PASS  $1"; }
fail() { echo "  FAIL  $1"; FAILS=$((FAILS+1)); }
want() { [ "$GROUP" = all ] || [ "$GROUP" = "$1" ]; }
build() {   # build <name> <top> <tb file> <extra flags...>
    local name=$1 top=$2 tb=$3; shift 3
    [ -x build/$name/V$name ] && [ -z "${REBUILD:-}" ] && return 0
    echo "  building $name ..."
    rm -rf build/$name
    verilator $VFLAGS "$@" --top-module $top ./$tb ./oram_timing_monitor.v $SRCS -Mdir build/$name -o V$name \
        > build/$name.build.log 2>&1 || { echo "  BUILD FAILED: $name (build/$name.build.log)"; exit 2; }
}
run() { local name=$1 tag=$2; shift 2; ./build/$name/V$name "$@" > build/run_$tag.log 2>&1; }

if want selftest; then
    build selftest tb_onboard_test_top tb_onboard_test_top.v -DSIMULATION -DORAM_DEBUG_PORTS $RTL/onboard_test_top.v
    run selftest selftest +timing_log=build/timing_selftest.csv
    if [ $ORAM_CONFIG = two ]; then
        echo "== onboard self-test (53 tests) and tamper detection"
        grep -q "ALL 53 TESTS PASSED" build/run_selftest.log \
            && pass "self-test, two clients (paper workload first, client 1 idle): all 53 tests" \
            || fail "self-test, two clients (build/run_selftest.log)"
        # the same self-test with a single-client schedule (no dummy windows)
        build selftest1 tb_onboard_test_top tb_onboard_test_top.v -DSIMULATION -DORAM_DEBUG_PORTS -DSELFTEST_CLIENTS=1 $RTL/onboard_test_top.v
        run selftest1 selftest1
        grep -q "ALL 50 RUN TESTS PASSED (3 skipped" build/run_selftest1.log \
            && pass "self-test, single client: 50 tests passed, 3 skipped (need client 1)" || fail "self-test, single client (build/run_selftest1.log)"
    else
        echo "== onboard self-test (one client) and tamper detection"
        grep -q "ALL 50 RUN TESTS PASSED (3 skipped" build/run_selftest.log && grep -q "dummy=0 " build/run_selftest.log \
            && pass "self-test, one client: 50 tests passed (3 need a second client), no dummy accesses" \
            || fail "self-test, one client (build/run_selftest.log)"
    fi
    for m in tamper_hole tamper_target; do
        run selftest $m +$m
        grep -q "TAMPER RESULT: DETECTED" build/run_$m.log && pass "$m: detected, controller halted" || fail "$m (build/run_$m.log)"
    done
fi
if want ni || want secure; then
    build ni tb_ni tb_ni.v -DORAM_DEBUG_PORTS
fi
if want ni && [ $ORAM_CONFIG = two ]; then
    echo "== non-interference: client 1's timing must not depend on client 0"
    H0=""; ok=1
    for v in 0 1 2 3; do
        run ni ni$v +ni=$v +ops=10
        L=$(grep "NI:" build/run_ni$v.log); echo "        $L" | cut -c1-150
        h=$(echo "$L" | grep -oE "trace-hash=[0-9a-f]+" || true)
        echo "$L" | grep -q "errors=0 .*errors=0" || ok=0
        [ -z "$h" ] && ok=0
        [ -z "$H0" ] && H0=$h
        [ "$h" != "$H0" ] && ok=0
    done
    [ $ok = 1 ] && pass "non-interference: identical $H0 for idle/saturating/random/bursty client 0" || fail "non-interference (build/run_ni*.log)"
    # partition isolation against a malicious host: an over-granted lease must not reach
    # the other client's ORAM
    run ni xpart +xpart +heartbeat=0
    grep -q "client 0 reading client 1's slot 300 -> rejected" build/run_xpart.log \
        && pass "partition isolation: client 0 cannot reach client 1's ORAM even with an over-granted lease" \
        || fail "partition isolation (build/run_xpart.log)"
fi
if want ni && [ $ORAM_CONFIG = single ]; then
    echo "== one client: two traffic patterns with correct data and no dummy accesses"
    ok=1
    for v in 0 1; do      # the variant seeds the client's request pattern
        run ni ni$v +ni=$v +ops=10
        L=$(grep "NI:" build/run_ni$v.log); echo "        $L" | cut -c1-150
        echo "$L" | grep -q "errors=0 .*errors=0 .*dummy=0" || ok=0
    done
    [ $ok = 1 ] && pass "one client: data correct in both traffic patterns, no dummy accesses" || fail "one-client traffic (build/run_ni*.log)"
fi
if want stress; then
    echo "== worst case: 8 evictions in one access"
    build ni tb_ni tb_ni.v -DORAM_DEBUG_PORTS
    build cal tb_ni tb_ni.v -DORAM_DEBUG_PORTS -DORAM_CT_RD=0 -DORAM_CT_WB=0 -DORAM_CT_DONE=0 -DORAM_TDM_SLOT=20000
    run ni stress +stress
    grep -q "evictions in one access=$ZPOS .*ct_overrun=0  data_errors=0" build/run_stress.log \
        && pass "gated: $ZPOS evictions (a full bucket) in one access, no overrun, data correct" || fail "gated stress (build/run_stress.log)"
    run cal stress_cal +stress
    # Streaming write-back: it starts at CT_WB while encryption finishes, so the
    # worst encryption end may exceed CT_WB by up to 7*128 beats (the master
    # needs that long to reach the last position).
    # The worst case is the max over ALL paths, not just the 8-eviction stress:
    # with eviction overlap, two-copy paths (e.g. bucket-hit write + compaction)
    # are slower. So the full self-test is calibrated too.
    build selfcal tb_onboard_test_top tb_onboard_test_top.v -DSIMULATION -DORAM_DEBUG_PORTS \
          -DORAM_CT_RD=0 -DORAM_CT_WB=0 -DORAM_CT_DONE=0 -DORAM_TDM_SLOT=20000 $RTL/onboard_test_top.v
    run selfcal selftest_cal
    a1=$(grep -oE "ct_max_wb=[0-9]+" build/run_stress_cal.log | cut -d= -f2)
    a2=$(grep -oE "CT arrivals: rd=[0-9]+ wb=[0-9]+" build/run_selftest_cal.log | grep -oE "wb=[0-9]+" | cut -d= -f2)
    arr=$(( ${a1:-999999} > ${a2:-999999} ? ${a1:-999999} : ${a2:-999999} ))
    lim=$((CT_WB_BUDGET + LEAD))
    if [ -n "$a1" ] && [ -n "$a2" ] && [ "$arr" -le "$lim" ] && grep -q "data_errors=0" build/run_stress_cal.log \
       && grep -qE "ALL 53 TESTS PASSED|ALL 50 RUN TESTS PASSED" build/run_selftest_cal.log; then
        pass "calibration: worst encryption end $arr (stress $a1, all paths $a2) <= CT_WB + $LEAD = $lim"
    else fail "calibration: encryption end stress=${a1:-?} all-paths=${a2:-?} vs limit $lim (build/run_*_cal.log)"; fi
    # Negative control: a write-back budget 1,500 cycles too early must be caught
    # (overrun, fail-stop) without the write-back ever reading an unencrypted position.
    build early tb_ni tb_ni.v -DORAM_DEBUG_PORTS -DORAM_CT_WB=$((CT_WB_BUDGET - 1500))
    run early stress_early +stress
    if grep -q "ct_overrun=1" build/run_stress_early.log && ! grep -q "SAFETY" build/run_stress_early.log; then
        pass "negative control: too-early write-back caught, no plaintext read"
    else fail "negative control (build/run_stress_early.log)"; fi
fi
if want bp; then
    echo "== AXI backpressure (30% ready-low and read-data gaps, gates off)"
    build cal tb_ni tb_ni.v -DORAM_DEBUG_PORTS -DORAM_CT_RD=0 -DORAM_CT_WB=0 -DORAM_CT_DONE=0 -DORAM_TDM_SLOT=20000
    ok=1
    for v in 1 2; do
        run cal bp$v +ni=$v +ops=8 +bp=30
        grep -qE "NI: variant=$v client[01] ops=8 errors=0 .*client0 ops=[0-9]* errors=0" build/run_bp$v.log || ok=0
    done
    [ $ok = 1 ] && pass "$([ $ORAM_CONFIG = two ] && echo both clients || echo the client) active under backpressure: data correct, no integrity error" || fail "backpressure (build/run_bp*.log)"
fi
if want secure; then
    echo "== production configuration (ORAM_SECURE_BUILD, no debug ports)"
    build sec tb_ni tb_ni.v -DORAM_SECURE_BUILD
    # each run of the production build must match the debug build's run of the same variant
    ok=1; refs=""
    for v in 0 1; do
        [ -f build/run_ni$v.log ] || run ni ni$v +ni=$v +ops=10
        ref=$(grep -oE "trace-hash=[0-9a-f]+" build/run_ni$v.log)
        run sec sec$v +ni=$v +ops=10
        [ -n "$ref" ] && grep -q "$ref" build/run_sec$v.log && grep -q "errors=0 .*errors=0" build/run_sec$v.log || ok=0
        refs="$refs ${ref#trace-hash=}"
    done
    [ $ok = 1 ] && pass "secure build behaves identically (trace-hashes$refs) with debug ports removed" || fail "secure build (build/run_sec*.log)"
fi
if want worst; then
    echo "== derived worst case: cycle model validated on every traced access"
    build ni tb_ni tb_ni.v -DORAM_DEBUG_PORTS
    run ni worst +worst +timing_log=build/timing_worst.csv +bus_log=build/bus_worst.csv
    # every window, real or dummy, must present the bucket read and the write-back
    # on the AXI bus at the same offset from the window start
    # Every window, real or dummy, must present the bucket read and the write-back at the
    # same offset from the window start, and read a bucket in its owner's partition.
    BUCKW=$(pval BUCKET_ID_W)
    PARTW=$(pval ORAM_PART_W)
    if out=$(python3 - "$BUCKW" "$PARTW" <<'PYEOF'
import csv, sys
bw, pw = int(sys.argv[1]), int(sys.argv[2])
r=[x for x in csv.DictReader(open('build/bus_worst.csv')) if None not in x.values() and int(x['ar_offset'])>=0 and int(x['aw_offset'])>=0]
a={x['ar_offset'] for x in r}; w={x['aw_offset'] for x in r}
bad=[x for x in r if (int(x['bucket']) >> (bw-pw)) != int(x['owner'])]
d=sum(x['kind']=='9' for x in r)
if r and len(a)==1 and len(w)==1 and not bad: print(len(r), d, a.pop(), w.pop())
else: print("FAIL", len(a), len(w), len(bad)); sys.exit(1)
PYEOF
    ); then
        set -- $out; pass "bus timing: all $1 windows ($2 dummy) read at offset $3, write back at offset $4, each in its owner's partition"
    else fail "bus timing or partition differs between windows ($out; build/bus_worst.csv)"; fi
    grep -q "data_errors=0, ct_overrun=0" build/run_worst.log || fail "directed worst-case scenarios (build/run_worst.log)"
    if [ ! -f build/timing_selftest.csv ]; then
        build selftest tb_onboard_test_top tb_onboard_test_top.v -DSIMULATION -DORAM_DEBUG_PORTS $RTL/onboard_test_top.v
        run selftest selftest +timing_log=build/timing_selftest.csv
    fi
    if python3 worst_case.py --params $RTL/oram_params.vh build/timing_worst.csv build/timing_selftest.csv > build/worst_case.txt 2>&1; then
        pass "derived worst case fits the budget: $(grep -oE 'derived worst encryption end = [^)]*= [0-9]+' build/worst_case.txt | sed -E 's/.*= //' | tr '\n' ' ')vs deadline $(grep -oE 'deadline [0-9]+' build/worst_case.txt | head -1 | cut -d' ' -f2) (build/worst_case.txt)"
    else fail "worst-case analysis (build/worst_case.txt)"; fi
fi
if want kernel && [ $ORAM_CONFIG = single ]; then
    echo "== Vitis kernel wrapper (doma_kernel): the testbench plays XRT"
    build kern tb_doma_kernel tb_doma_kernel.v -DORAM_SECURE_BUILD -Wno-BLKANDNBLK $RTL/doma_kernel.v ./axi_mem_model.v
    run kern kernel +hb=0
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel.log \
        && pass "kernel: init launch, two command launches, every GET correct, bad key rejected, interrupt and CTRL as XRT expects" \
        || fail "kernel end-to-end (build/run_kernel.log)"
    run kern kernel_gap +hb=0 +cmds=40 +cmds2=10 +host_gap=30
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_gap.log && pass "kernel: 30% host read gaps, correct and unchanged latency" \
        || fail "kernel with host read gaps (build/run_kernel_gap.log)"
    # AXI does not order a read against an unacknowledged write. With writes landing 200 cycles
    # after their data the results must be correct; with 700 the slow acknowledgements must be
    # caught as a timing overrun, never returned as stale data (an integrity failure).
    run kern kernel_wlat +hb=0 +cmds=40 +cmds2=4 +host_wlat=200
    grep -q "DOMA KERNEL: ALL CHECKS PASSED" build/run_kernel_wlat.log && pass "kernel: writes landing 200 cycles after their data, results correct" \
        || fail "kernel with late-landing writes (build/run_kernel_wlat.log)"
    run kern kernel_wlat_slow +hb=0 +cmds=10 +cmds2=4 +host_wlat=700
    if grep -q "DOMA HALT: timing overrun" build/run_kernel_wlat_slow.log && ! grep -q "DOMA HALT: integrity" build/run_kernel_wlat_slow.log; then
        pass "kernel: write acknowledgements slower than the budget are an overrun, never stale data"
    else fail "read-after-write ordering (build/run_kernel_wlat_slow.log)"; fi
    # PCIe-like latency beyond the budgets: DOMA must halt and the kernel must still finish the run
    run kern kernel_pcie +hb=0 +cmds=10 +cmds2=4 +host_lat=600
    if grep -qE "^run1: size=10 .*errors=00000008" build/run_kernel_pcie.log && grep -qE "^run2: size=4 " build/run_kernel_pcie.log; then
        pass "kernel: budget overrun at 600-cycle host latency ends the run with error 0x8, no hang (budgets need PCIe recalibration)"
    else fail "kernel abort path (build/run_kernel_pcie.log)"; fi
fi
# no run may report a safety-monitor violation or a scratch bank conflict
if grep -lE "SAFETY VIOLATION|SCRATCH: bank conflict" build/run_*.log 2>/dev/null | grep -q .; then
    fail "safety monitor / bank conflict reported in: $(grep -lE 'SAFETY VIOLATION|SCRATCH: bank conflict' build/run_*.log | tr '\n' ' ')"
else pass "no safety-monitor violations or scratch bank conflicts in any run"; fi
echo
if [ $FAILS = 0 ]; then echo "ALL CHECKS PASSED"; exit 0; else echo "$FAILS CHECK(S) FAILED"; exit 1; fi
