// axi_mem_model.v -- AXI4 slave memory for the doma_kernel testbench (simulation only).
// INCR bursts, up to 16 reads outstanding (each served RLAT cycles after its address),
// optional random read-data gaps, write data accepted before its address (W FIFO).
`timescale 1ns/1ps
module axi_mem_model #(
    parameter integer DW    = 256,
    parameter integer WORDS = 65536,             // memory size in DW-bit words
    parameter [63:0]  BASE  = 64'd0,             // byte address of word 0
    parameter integer RLAT  = 40                 // cycles from address to first read beat
) (
    input  wire              clk,
    input  wire              rst_n,              // the bus is ignored while reset is held, as a real interconnect does
    input  wire [63:0]       araddr,  input wire [7:0] arlen, input wire arvalid, output wire arready,
    output reg  [DW-1:0]     rdata,   output wire [1:0] rresp, output reg rlast, output reg rvalid, input wire rready,
    input  wire [63:0]       awaddr,  input wire [7:0] awlen, input wire awvalid, output wire awready,
    input  wire [DW-1:0]     wdata,   input wire [DW/8-1:0] wstrb, input wire wlast, input wire wvalid, output wire wready,
    output wire [1:0]        bresp,   output reg bvalid, input wire bready
);
    reg [DW-1:0] mem [0:WORDS-1];
    integer      lat = RLAT;             // may be changed by the testbench
    integer      gap_pct = 0;            // percent of cycles with no read beat
    integer      wlat = 0;               // cycles before a write lands; reads meanwhile see the old data
    integer      errors = 0;
    integer      cyc = 0;
    always @(posedge clk) cyc <= cyc + 1;
    function integer widx; input [63:0] a; begin widx = (a - BASE) >> $clog2(DW/8); end endfunction

    // ---------------- reads ----------------
    reg [63:0] rq_addr [0:15]; reg [7:0] rq_len [0:15]; integer rq_t [0:15];
    integer rq_wp = 0, rq_rp = 0, rq_n = 0, rbeat = 0; reg rbusy = 0;
    assign arready = rst_n && (rq_n < 16);
    assign rresp = 2'b00;
    initial begin rvalid = 0; rlast = 0; rdata = 0; bvalid = 0; end
    always @(posedge clk) begin : rd
        integer w;
        if (!rst_n) begin rvalid <= 0; rlast <= 0; end
        else begin
        if (arvalid && arready) begin
            rq_addr[rq_wp] = araddr; rq_len[rq_wp] = arlen; rq_t[rq_wp] = cyc;
            rq_wp = (rq_wp + 1) % 16; rq_n = rq_n + 1;
        end
        if (rvalid && rready) begin
            rvalid <= 0;
            if (rlast) begin rbusy = 0; rq_rp = (rq_rp + 1) % 16; rq_n = rq_n - 1; rbeat = 0; end
            else rbeat = rbeat + 1;
        end
        if ((!rvalid || rready) && rq_n > 0 && !(rvalid && rready && rlast) && cyc >= rq_t[rq_rp] + lat
            && (gap_pct == 0 || ($random % 100 + 100) % 100 >= gap_pct)) begin
            w = widx(rq_addr[rq_rp]) + rbeat;
            if (w < 0 || w >= WORDS) begin errors = errors + 1; rdata <= {DW{1'b0}}; end
            else rdata <= mem[w];
            rlast  <= (rbeat == rq_len[rq_rp]);
            rvalid <= 1;
        end
        end
    end

    // ---------------- writes ----------------
    reg [DW-1:0] wf_d [0:1023]; reg [DW/8-1:0] wf_s [0:1023]; integer wf_wp = 0, wf_rp = 0, wf_n = 0;
    reg [63:0] aw_addr [0:15]; reg [7:0] aw_len [0:15]; integer aw_t [0:15]; integer head_arm = -1; integer aw_wp = 0, aw_rp = 0, aw_n = 0, b_pend = 0;
    assign wready  = rst_n && (wf_n < 1000);
    assign awready = rst_n && (aw_n < 16);
    assign bresp   = 2'b00;
    always @(posedge clk) begin : wr
        integer k, w, by;
        if (!rst_n) bvalid <= 0;
        else begin
        if (wvalid && wready) begin wf_d[wf_wp] = wdata; wf_s[wf_wp] = wstrb; wf_wp = (wf_wp + 1) % 1024; wf_n = wf_n + 1; end
        if (awvalid && awready) begin aw_addr[aw_wp] = awaddr; aw_len[aw_wp] = awlen; aw_t[aw_wp] = cyc; aw_wp = (aw_wp + 1) % 16; aw_n = aw_n + 1; end
        // a burst lands wlat cycles after its last data beat has arrived
        if (aw_n > 0 && wf_n >= aw_len[aw_rp] + 1 && head_arm < 0) head_arm = cyc;
        if (aw_n > 0 && wf_n >= aw_len[aw_rp] + 1 && cyc >= head_arm + wlat) begin
            head_arm = -1;
            for (k = 0; k <= aw_len[aw_rp]; k = k + 1) begin
                w = widx(aw_addr[aw_rp]) + k;
                if (w < 0 || w >= WORDS) errors = errors + 1;
                else for (by = 0; by < DW/8; by = by + 1)
                    if (wf_s[wf_rp][by]) mem[w][by*8 +: 8] = wf_d[wf_rp][by*8 +: 8];
                wf_rp = (wf_rp + 1) % 1024; wf_n = wf_n - 1;
            end
            aw_rp = (aw_rp + 1) % 16; aw_n = aw_n - 1; b_pend = b_pend + 1;
        end
        if (bvalid && bready) begin bvalid <= 0; b_pend = b_pend - 1; end
        else if (b_pend > 0) bvalid <= 1;
        end
    end
endmodule
