#!/bin/bash
# run_xsim_tinyoram.sh -- the tinyoram_kernel end-to-end test in Vivado's simulator (xvlog/xelab/xsim).
# NOT run where this was written (no Vivado there): treat the first run as a bring-up.
#   bash run_xsim_tinyoram.sh            # 4 KB and 64 B builds
#   SIZES="4k" bash run_xsim_tinyoram.sh
# Needs Tiny ORAM fetched and patched (bash ../tinyoram/fetch_tinyoram.sh; done here if missing).
# Pass criterion: "*** TINYORAM KERNEL: ALL CHECKS PASSED ***" in each build/xsim_tinyoram_*.log.
set -u
cd "$(dirname "$0")"
TOR=../tinyoram
[ -f $TOR/build/src/files.f ] || bash $TOR/fetch_tinyoram.sh 4k || exit 2
SRC=$(cd $TOR/build/src && pwd)
SIZES=${SIZES:-"4k 64"}
mkdir -p build_xsim && cd build_xsim
FILES=$(sed "s#^#$SRC/#" $SRC/files.f | tr '\n' ' ')
for sz in $SIZES; do
    mkdir -p cfg_$sz && cp ../$TOR/config/tinyoram_config_$sz.vh cfg_$sz/tinyoram_config.vh
    lib=work_$sz
    xvlog -work $lib -i cfg_$sz -i $SRC -d SIMULATION $FILES ../../tinyoram/rtl/tinyoram_kernel.v ../../tinyoram/rtl/tinyoram_axi_adapter.v \
          ../axi_mem_model.v ../tb_tinyoram_kernel.v > xvlog_$sz.log 2>&1 || { echo "xvlog failed ($sz): build_xsim/xvlog_$sz.log"; continue; }
    xelab -debug off -L $lib -top $lib.tb_tinyoram_kernel -snapshot tiny_$sz > xelab_$sz.log 2>&1 || { echo "xelab failed ($sz): build_xsim/xelab_$sz.log"; continue; }
    if [ $sz = 4k ]; then A="-testplusarg cmds=24 -testplusarg cmds2=8"; else A="-testplusarg cmds=80 -testplusarg cmds2=20"; fi
    xsim tiny_$sz -R -testplusarg hb=0 $A > xsim_tinyoram_$sz.log 2>&1
    echo "$sz: $(grep -E 'TINYORAM KERNEL' xsim_tinyoram_$sz.log || echo 'no verdict (see build_xsim/xsim_tinyoram_'$sz'.log)')"
done
