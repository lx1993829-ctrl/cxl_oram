#!/bin/bash
# setup_wsl.sh -- install the simulation tools the regression results were produced with
# (Verilator 5.020, Icarus Verilog), on Ubuntu 22.04 or 24.04, including under WSL2.
# Ubuntu 24.04 ships Verilator 5.020; Ubuntu 22.04 ships 4.038, which is too old (no --timing),
# so on 22.04 Verilator 5.020 is built from source (about 10 minutes).
set -euo pipefail
sudo apt-get update
sudo apt-get install -y git make autoconf g++ flex bison help2man perl python3 libfl2 libfl-dev \
                        zlib1g-dev ccache iverilog unzip
if verilator --version 2>/dev/null | grep -q "Verilator 5.020"; then
    echo "Verilator 5.020 already installed"
elif apt-cache policy verilator | grep -q "Candidate: 5.020"; then
    sudo apt-get install -y verilator
else
    tmp=$(mktemp -d)
    git clone --depth 1 --branch v5.020 https://github.com/verilator/verilator "$tmp/verilator"
    cd "$tmp/verilator" && autoconf && ./configure && make -j"$(nproc)" && sudo make install
fi
verilator --version
iverilog -V 2>&1 | head -1
