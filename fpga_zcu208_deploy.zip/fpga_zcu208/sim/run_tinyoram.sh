#!/bin/bash
# run_tinyoram.sh -- regression for the tinyoram_kernel Vitis wrapper with Verilator 5 (--timing).
#   bash run_tinyoram.sh                 # all four block sizes (64, 128, 256 B and 4 KB)
#   SIZES="4k" bash run_tinyoram.sh      # one size
# Needs Tiny ORAM fetched and patched: bash ../tinyoram/fetch_tinyoram.sh (done here if missing).
# Exit code 0 = every check passed. Logs: build_tinyoram/*.log
#
# Per size, the testbench (tb_tinyoram_kernel.v) plays XRT against strict AXI memory models:
#   e2e      init launch (reports the geometry, touches no memory), two command launches (the first
#            zero-fills the tree), every GET checked, an out-of-range key rejected, interrupt and
#            CTRL as XRT expects; stale garbage in the tree buffer before init
#   late     first launch 20,000 cycles after reset, then 256 sequential PUTs (the host's preload)
#   gaps     30% ready-low on every AXI channel and 30% read-data gaps; wlast and 4 KB checked
#   wlat     writes land 200 cycles after their data: reads must never see stale data
#   xinit    random initial values everywhere (Verilator --x-initial unique, +verilator+rand+reset+2),
#            Tiny ORAM built without its simulation self-checks (they fire on the first clock edge,
#            before reset takes effect)
#   packed8  (64 B and 4 KB) 8-byte records packed into preloaded blocks (header offset/length, Tiny ORAM's
#            WMask): byte-exact against an image of every block, GETs return only their record, whole-block
#            GETs at the end; a PUT and a GET whose range runs past the block come back 0x40
#   packed16 (64 B and 4 KB) 16-byte records with writes landing 200 cycles late and 30% read-data gaps,
#            no preload (records written into never-written blocks: zeros around them)
#   ranges   (every size) records at random byte offsets and lengths, crossing beats anywhere, mixed with
#            whole-block commands; four differently shaped bad ranges, each rejected with its slot untouched
set -u
cd "$(dirname "$0")"
here=$(pwd)
TOR=../tinyoram
[ -f $TOR/build/src/files.f ] || bash $TOR/fetch_tinyoram.sh 4k || exit 2
SRC=$TOR/build/src
SIZES=${SIZES:-"64 128 256 4k"}
B=build_tinyoram
mkdir -p $B
VFLAGS="--binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-WIDTH -Wno-ZERODLY -Wno-BLKANDNBLK"
FILES="$(sed "s#^#$SRC/#" $SRC/files.f | tr '\n' ' ')"
FAILS=0
pass() { echo "  PASS  $1"; }
fail() { echo "  FAIL  $1"; FAILS=$((FAILS+1)); }
build() {   # build <name> <size> <extra flags...>
    local name=$1 sz=$2; shift 2
    mkdir -p $B/cfg_$sz && cp $TOR/config/tinyoram_config_$sz.vh $B/cfg_$sz/tinyoram_config.vh
    [ -x $B/$name/Vtb ] && [ -z "${REBUILD:-}" ] && return 0
    echo "  building $name ..."
    rm -rf $B/$name
    verilator $VFLAGS -I$B/cfg_$sz -I$SRC "$@" --top-module tb_tinyoram_kernel ./tb_tinyoram_kernel.v ./axi_mem_model.v \
        ../tinyoram/rtl/tinyoram_kernel.v ../tinyoram/rtl/tinyoram_axi_adapter.v $FILES -Mdir $B/$name -o Vtb > $B/$name.build.log 2>&1 \
        || { echo "  BUILD FAILED: $name ($B/$name.build.log)"; exit 2; }
}
run() { local name=$1 tag=$2; shift 2; ( ulimit -s unlimited 2>/dev/null; ./$B/$name/Vtb "$@" > $B/run_$tag.log 2>&1 ); }
ok() { grep -q "TINYORAM KERNEL: ALL CHECKS PASSED" $B/run_$1.log && ! grep -qE "ERROR|Error:" $B/run_$1.log; }
summ() { grep -E "^(run1|preload): " $B/run_$1.log | sed -E 's/.*(latency min\/max=[0-9]+\/[0-9]+).*(tree AR=[0-9]+ AW=[0-9]+).*/\1 \2/' | tr '\n' ' '; }

for sz in $SIZES; do
    echo "== tinyoram_kernel, $sz-byte blocks"
    # 4 KB accesses are ~20x longer: fewer commands keep the run time reasonable
    if [ $sz = 4k ]; then C1="+cmds=40 +cmds2=12"; C2="+cmds=12 +cmds2=4"; else C1="+cmds=120 +cmds2=40"; C2="+cmds=40 +cmds2=10"; fi
    build k_$sz $sz -DSIMULATION
    run k_$sz e2e_$sz +hb=0 $C1
    ok e2e_$sz && pass "e2e: init, two launches, GETs correct, bad key rejected, CTRL/interrupt ($(summ e2e_$sz))" || fail "e2e ($B/run_e2e_$sz.log)"
    run k_$sz late_$sz +hb=0 +start_delay=20000 +preload $C2
    ok late_$sz && pass "late first launch + 256 sequential PUTs ($(summ late_$sz))" || fail "late start / preload ($B/run_late_$sz.log)"
    run k_$sz gaps_$sz +hb=0 +host_rdy_gap=30 +host_gap=30 $C2
    ok gaps_$sz && pass "30% ready and read-data gaps on every channel, wlast/4 KB checked" || fail "AXI gaps ($B/run_gaps_$sz.log)"
    run k_$sz wlat_$sz +hb=0 +host_wlat=200 $C2
    ok wlat_$sz && pass "writes land 200 cycles late: no stale reads" || fail "late writes ($B/run_wlat_$sz.log)"
    build kx_$sz $sz --x-assign unique --x-initial unique
    run kx_$sz xinit_$sz +hb=0 +verilator+rand+reset+2 +verilator+seed+11 $C2
    ok xinit_$sz && pass "random initial values" || fail "random initial values ($B/run_xinit_$sz.log)"
    if [ $sz = 64 ] || [ $sz = 4k ]; then
        run k_$sz packed8_$sz +hb=0 +packed=8 +preload $C2
        ok packed8_$sz && pass "packed 8-byte records over preloaded blocks match the block image; bad record ranges rejected" \
            || fail "packed records ($B/run_packed8_$sz.log)"
        run k_$sz packed16_$sz +hb=0 +packed=16 +host_wlat=200 +host_gap=30 $C2
        ok packed16_$sz && pass "packed 16-byte records with late writes and read pauses, correct" || fail "packed records under stress ($B/run_packed16_$sz.log)"
    fi
    run k_$sz ranges_$sz +hb=0 +ranges +preload +host_gap=30 $C2
    ok ranges_$sz && pass "records at any byte offset and length, mixed with whole blocks; four bad range shapes rejected" || fail "byte ranges ($B/run_ranges_$sz.log)"
done
echo
if [ $FAILS = 0 ]; then echo "ALL CHECKS PASSED"; exit 0; else echo "$FAILS CHECK(S) FAILED"; exit 1; fi
