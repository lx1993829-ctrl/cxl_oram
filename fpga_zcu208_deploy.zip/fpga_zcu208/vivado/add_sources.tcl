# add_sources.tcl -- add the ZCU208 ORAM sources to the OPEN Vivado project.
#
# In the Vivado Tcl console, with your project (MIG / block design / XDC) open:
#     set ORAM_BUILD selftest        ;# or calibration | production  (default: selftest)
#     source <package>/vivado/add_sources.tcl
#
#   selftest     onboard_test_top + debug ports (the self-test steers remaps and
#                reads perf counters through them). NOT a production image: it
#                carries the public test key.
#   calibration  as selftest, timing gates OFF and a long slot: run on the board
#                and read ct_max_rd/wb/done (mark_debug -> ILA) to size the budgets.
#   production   ORAM_SECURE_BUILD, no debug ports. Top = YOUR production top
#                (onboard_test_top refuses to build in this mode, by design).
#
# Files already in the project with the same names (e.g. the pre-fix versions)
# are reported; set ORAM_REPLACE 1 before sourcing to remove them first.
# Not run in the environment where it was written (no Vivado there).

if {![info exists ORAM_BUILD]}   { set ORAM_BUILD selftest }
if {![info exists ORAM_REPLACE]} { set ORAM_REPLACE 0 }
set here [file dirname [file normalize [info script]]]
set root [file dirname $here]
set rtl_dir "$root/rtl"
set sim_dir "$root/sim"

switch -- $ORAM_BUILD {
    selftest    { set defs {ORAM_DEBUG_PORTS}; set top onboard_test_top }
    calibration { set defs {ORAM_DEBUG_PORTS ORAM_CT_RD=0 ORAM_CT_WB=0 ORAM_CT_DONE=0 ORAM_TDM_SLOT=30000}
                  set top onboard_test_top }
    production  { set defs {ORAM_SECURE_BUILD}; set top "" }
    default     { error "ORAM_BUILD must be selftest, calibration or production (got '$ORAM_BUILD')" }
}

set srcs [lsort [glob -directory $rtl_dir *.v]]
set hdr  "$rtl_dir/oram_params.vh"
set tbs  [list "$sim_dir/tb_onboard_test_top.v" "$sim_dir/tb_ni.v" "$sim_dir/oram_timing_monitor.v"]

# -- refuse to create silent duplicates of files already in the project
set clash {}
foreach f [concat $srcs [list $hdr] $tbs] {
    foreach g [get_files -quiet -all "*/[file tail $f]"] {
        if {[file normalize $g] ne [file normalize $f]} { lappend clash $g }
    }
}
if {[llength $clash] > 0} {
    if {$ORAM_REPLACE} {
        puts "ORAM: removing [llength $clash] older copies: $clash"
        remove_files $clash
    } else {
        error "ORAM: the project already has files with these names:\n  [join $clash "\n  "]\nset ORAM_REPLACE 1 and source again to replace them."
    }
}

add_files -norecurse -fileset sources_1 $srcs
add_files -norecurse -fileset sources_1 $hdr
set_property file_type {Verilog Header} [get_files $hdr]
set_property include_dirs [list $rtl_dir] [get_filesets sources_1]
set_property verilog_define $defs [get_filesets sources_1]
if {$top ne ""} { set_property top $top [get_filesets sources_1] }

add_files -norecurse -fileset sim_1 $tbs
# testbenches are plain Verilog-2001: no file_type change needed
set_property include_dirs [list $rtl_dir] [get_filesets sim_1]
set_property verilog_define [concat $defs SIMULATION] [get_filesets sim_1]
set_property top tb_onboard_test_top [get_filesets sim_1]
set_property top_lib xil_defaultlib [get_filesets sim_1]

update_compile_order -fileset sources_1
puts "ORAM: added [llength $srcs] sources + header for build '$ORAM_BUILD' (defines: $defs)"
if {$ORAM_BUILD eq "production"} {
    puts "ORAM: production build -- set your own top; do not include onboard_test_top.v in it."
}
