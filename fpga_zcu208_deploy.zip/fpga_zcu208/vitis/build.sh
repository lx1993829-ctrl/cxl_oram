#!/bin/bash
# build.sh -- doma_kernel.xo -> doma.xclbin -> host program  (UNTESTED here)
# Needs Vitis 2024.1 (the version BOLT used), XRT, and the U55C platform installed.
#   TARGET=hw      bash build.sh   # board bitstream (hours)
#   TARGET=hw_emu  bash build.sh   # hardware emulation, no card needed
set -euo pipefail
cd "$(dirname "$0")"
PLATFORM=${PLATFORM:-xilinx_u55c_gen3x16_xdma_3_202210_1}     # BOLT's xclbins use this platform
TARGET=${TARGET:-hw}
CFG=${CFG:-doma.cfg}                  # CFG=doma_emu.cfg if hw_emu cannot use host memory
vivado -mode batch -nojournal -nolog -source package_kernel.tcl -tclargs ../rtl doma_kernel.xo
v++ -l -t $TARGET --platform $PLATFORM --kernel_frequency 300 --config $CFG \
    --save-temps -o doma_$TARGET.xclbin doma_kernel.xo
g++ -std=c++17 -O2 host_doma.cpp -I$XILINX_XRT/include -L$XILINX_XRT/lib -lxrt_coreutil -pthread -o host_doma
if [ "$TARGET" = hw_emu ]; then emconfigutil --platform $PLATFORM; echo "run: XCL_EMULATION_MODE=hw_emu ./host_doma doma_hw_emu.xclbin"; fi
