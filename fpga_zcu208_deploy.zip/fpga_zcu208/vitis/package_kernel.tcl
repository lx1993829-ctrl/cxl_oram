# package_kernel.tcl -- package rtl/ as the Vitis RTL kernel doma_kernel.xo  (UNTESTED here)
# Usage: vivado -mode batch -source package_kernel.tcl -tclargs <rtl dir> <output .xo>
# Follows AMD's Vitis RTL-kernel flow (Vitis_Accel_Examples rtl_kernels/*/scripts/package_kernel.tcl).
# Synthesis defines SYNTHESIS, so oram_params.vh builds the production configuration (no debug ports).
set rtl_dir [lindex $argv 0]
set xo_path [lindex $argv 1]
set part    xcu55c-fsvh2892-2L-e
set ip_dir  ./doma_ip

create_project -force doma_pack ./doma_pack -part $part
add_files -norecurse [glob $rtl_dir/*.v $rtl_dir/*.vh]
# the self-test top is for the ZCU208 board, not part of the kernel
remove_files -quiet [get_files -quiet */onboard_test_top.v]
set_property file_type {Verilog Header} [get_files *.vh]
set_property top doma_kernel [current_fileset]
update_compile_order -fileset sources_1

ipx::package_project -root_dir $ip_dir -vendor user.org -library kernel -taxonomy /KernelIP -import_files -set_current false
ipx::unload_core $ip_dir/component.xml
ipx::edit_ip_in_project -upgrade true -name tmp_edit_project -directory $ip_dir $ip_dir/component.xml
set core [ipx::current_core]
set_property core_revision 1 $core
foreach up [ipx::get_user_parameters] { ipx::remove_user_parameter [get_property NAME $up] $core }

foreach bif {s_axi_control m_axi_gmem0 m_axi_gmem1 m_axi_gmem2} {
    ipx::associate_bus_interfaces -busif $bif -clock ap_clk $core
}
set clkbif [ipx::get_bus_interfaces -of $core ap_clk]
set_property value 300000000 [ipx::add_bus_parameter -quiet FREQ_HZ $clkbif]

# control register map; pointer registers name the AXI master they address
set mm [ipx::add_memory_map -quiet s_axi_control $core]
set ab [ipx::add_address_block -quiet reg0 $mm]
foreach {name off sz bif} {CTRL 0x000 32 {} GIER 0x004 32 {} IP_IER 0x008 32 {} IP_ISR 0x00C 32 {}
                           cmd_input 0x010 64 m_axi_gmem0 resp_output 0x01C 64 m_axi_gmem1
                           pages 0x028 64 m_axi_gmem2 size 0x034 32 {}} {
    set r [ipx::add_register $name $ab]
    set_property address_offset $off $r
    set_property size $sz $r
    if {$bif ne ""} { set_property value $bif [ipx::add_register_parameter ASSOCIATED_BUSIF $r] }
}
set_property slave_memory_map_ref s_axi_control [ipx::get_bus_interfaces -of $core s_axi_control]

set_property xpm_libraries {XPM_CDC XPM_MEMORY XPM_FIFO} $core
set_property sdx_kernel true $core
set_property sdx_kernel_type rtl $core
set_property supported_families { } $core
set_property auto_family_support_level level_2 $core
ipx::create_xgui_files $core
ipx::update_checksums $core
ipx::check_integrity -kernel $core
ipx::save_core $core
close_project -delete

package_xo -force -xo_path $xo_path -kernel_name doma_kernel -ip_directory $ip_dir -kernel_xml ./kernel.xml
