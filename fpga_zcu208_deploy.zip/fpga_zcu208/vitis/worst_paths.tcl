# worst_paths.tcl -- the 40 worst setup paths into worst_paths.txt, and the worst path of each
# failing register group into worst_groups.txt: from a v++ implementation
# checkpoint if one exists, otherwise by synthesizing ../rtl out of context at 300 MHz
# (no placement, so delays are estimates; logic levels and endpoints are exact).
#   vivado -mode batch -nojournal -nolog -source worst_paths.tcl
set all [lsort [glob -nocomplain -types f _x/link/vivado/vpl/prj/prj.runs/*/*.dcp]]
puts "checkpoints: [llength $all]"
set pick ""
foreach pat {*routed* *physopt* *place* *opt*} {
  foreach d $all { if {[string match $pat [file tail $d]]} { set pick $d } }
  if {$pick ne ""} break
}
if {$pick ne ""} {
  puts "using checkpoint: $pick"
  open_checkpoint $pick
} else {
  puts "no implementation checkpoint: synthesizing ../rtl out of context at 300 MHz"
  foreach f [glob ../rtl/*.v] { if {![string match *onboard_test_top.v $f]} { read_verilog $f } }
  set x [open clk.xdc w]; puts $x {create_clock -period 3.333 -name ap_clk [get_ports ap_clk]}; close $x
  read_xdc -mode out_of_context clk.xdc
  synth_design -top doma_kernel -part xcu55c-fsvh2892-2L-e -mode out_of_context -include_dirs ../rtl -flatten_hierarchy rebuilt
  report_utilization -hierarchical -file worst_paths_util.txt
}
write_checkpoint -force worst_paths.dcp
# worst failing path per register group (bit indices and replication suffixes removed), so every
# problem area shows up in one run, with how many of its endpoints fail
set g [open worst_groups.txt w]
array set worst {}; array set cnt {}; array set lv {}; array set sp {}
foreach p [get_timing_paths -setup -max_paths 5000 -nworst 1 -slack_lesser_than 0] {
  set e [get_property ENDPOINT_PIN $p]
  regsub {/[^/]+$} $e {} e
  regsub -all {\[[0-9]+\]} $e {} e
  regsub -all {_rep(__[0-9]+)?} $e {} e
  regsub {^level0_i/ulp/doma_kernel_1/inst/} $e {} e
  set s [get_property SLACK $p]
  if {![info exists worst($e)] || $s < $worst($e)} { set worst($e) $s; set lv($e) [get_property LOGIC_LEVELS $p]; set sp($e) [get_property STARTPOINT_PIN $p] }
  if {[info exists cnt($e)]} { incr cnt($e) } else { set cnt($e) 1 }
}
set lst {}
foreach k [array names worst] { lappend lst [list $worst($k) $k] }
foreach item [lrange [lsort -real -index 0 $lst] 0 29] {
  set s [lindex $item 0]; set k [lindex $item 1]
  puts $g [format "%8.3f slack | %2d levels | %4d failing | %s   (from %s)" $s $lv($k) $cnt($k) $k $sp($k)]
}
close $g
puts "wrote worst_groups.txt ([llength $lst] failing register groups)"
set f [open worst_paths.txt w]
foreach p [get_timing_paths -setup -max_paths 40 -nworst 1 -unique_pins] {
  puts $f [format "%8.3f slack | %2d levels | %7.3f ns | %s  ->  %s" [get_property SLACK $p] [get_property LOGIC_LEVELS $p] [get_property DATAPATH_DELAY $p] [get_property STARTPOINT_PIN $p] [get_property ENDPOINT_PIN $p]]
}
close $f
puts "wrote worst_paths.txt"
