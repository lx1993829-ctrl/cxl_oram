# worst_paths.tcl -- the 40 worst setup paths into worst_paths.txt: from a v++ implementation
# checkpoint if one exists, otherwise by synthesizing ../rtl out of context at 300 MHz
# (no placement, so delays are estimates; logic levels and endpoints are exact).
#   vivado -mode batch -nojournal -nolog -source worst_paths.tcl
set all [lsort [glob -nocomplain -types f _x/link/vivado/vpl/prj/prj.runs/*/*.dcp]]
puts "checkpoints: [llength $all]"
set pick ""
foreach pat {*routed* *physopt* *place* *opt*} {
  foreach d $all { if {[string match $pat [file tail $d]]} { set pick $d } }
  if {$pick ne ""} break
}
if {$pick ne ""} {
  puts "using checkpoint: $pick"
  open_checkpoint $pick
} else {
  puts "no implementation checkpoint: synthesizing ../rtl out of context at 300 MHz"
  foreach f [glob ../rtl/*.v] { if {![string match *onboard_test_top.v $f]} { read_verilog $f } }
  set x [open clk.xdc w]; puts $x {create_clock -period 3.333 -name ap_clk [get_ports ap_clk]}; close $x
  read_xdc -mode out_of_context clk.xdc
  synth_design -top doma_kernel -part xcu55c-fsvh2892-2L-e -mode out_of_context -include_dirs ../rtl -flatten_hierarchy rebuilt
  report_utilization -hierarchical -file worst_paths_util.txt
}
set f [open worst_paths.txt w]
foreach p [get_timing_paths -setup -max_paths 40 -nworst 1 -unique_pins] {
  puts $f [format "%8.3f slack | %2d levels | %7.3f ns | %s  ->  %s" [get_property SLACK $p] [get_property LOGIC_LEVELS $p] [get_property DATAPATH_DELAY $p] [get_property STARTPOINT_PIN $p] [get_property ENDPOINT_PIN $p]]
}
close $f
puts "wrote worst_paths.txt"
