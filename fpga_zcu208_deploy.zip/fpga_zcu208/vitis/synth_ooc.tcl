# synth_ooc.tcl -- out-of-context synthesis + place & route of one module, for resources and timing
# without a board or a platform.  (UNTESTED here)
#   vivado -mode batch -source synth_ooc.tcl -tclargs ../rtl                                  ;# doma_kernel, U55C, 300 MHz
#   vivado -mode batch -source synth_ooc.tcl -tclargs ../rtl xczu48dr-fsvg1517-2-e secure_oram_top clk 3.333   ;# ZCU208
set rtl_dir [lindex $argv 0]
set part    [expr {[llength $argv] > 1 ? [lindex $argv 1] : "xcu55c-fsvh2892-2L-e"}]
set top     [expr {[llength $argv] > 2 ? [lindex $argv 2] : "doma_kernel"}]
set clkport [expr {[llength $argv] > 3 ? [lindex $argv 3] : "ap_clk"}]
set period  [expr {[llength $argv] > 4 ? [lindex $argv 4] : 3.333}]
set out ooc_$top
file mkdir $out
foreach f [glob $rtl_dir/*.v] { if {![string match *onboard_test_top.v $f]} { read_verilog $f } }
set xdc [open $out/clk.xdc w]
puts $xdc "create_clock -period $period -name $clkport \[get_ports $clkport\]"
close $xdc
read_xdc -mode out_of_context $out/clk.xdc
synth_design -top $top -part $part -mode out_of_context -include_dirs $rtl_dir -flatten_hierarchy rebuilt
report_utilization -hierarchical -file $out/util_synth.rpt
opt_design
place_design
route_design
report_utilization -hierarchical -file $out/util_routed.rpt
report_timing_summary -max_paths 20 -file $out/timing_routed.rpt
report_design_analysis -logic_level_distribution -file $out/logic_levels.rpt
puts "WNS: [get_property SLACK [get_timing_paths -max_paths 1 -nworst 1 -setup]] ns at $period ns ($top on $part)"
