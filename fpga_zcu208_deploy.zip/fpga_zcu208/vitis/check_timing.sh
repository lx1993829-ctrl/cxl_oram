#!/bin/bash
# check_timing.sh -- after "TARGET=hw ./build.sh": did timing close at 300 MHz?
# Reads the FINAL routed timing (after post-route optimization) and lists every clock's worst slack. When timing
# fails at 300 MHz, v++ lowers the kernel clock to where the paths fit: such a bitstream is reported as usable at
# that clock (DOMA's budgets are in cycles, so it runs correctly), but it is not a 300 MHz result (exit 1).
cd "$(dirname "$0")"
WANT_MHZ=${WANT_MHZ:-300}
# other builds (build_tinyoram.sh): XCLBIN=<file> XDIR=<v++ temp dir>; defaults are doma_kernel's
XCLBIN=${XCLBIN:-doma_hw.xclbin}
XDIR=${XDIR:-_x}
R=$(find $XDIR -name "*timing_summary_postroute_physopted*.rpt" 2>/dev/null | head -1)
[ -z "$R" ] && R=$(find $XDIR -name "*timing_summary_routed*.rpt" 2>/dev/null | head -1)
[ -z "$R" ] && { echo "FAIL: no routed timing report under $XDIR/ (did the hw build finish?)"; exit 2; }
read -r WNS TNS WHS THS < <(awk '/WNS\(ns\)/{getline; getline; print $1, $2, $5, $6; exit}' "$R")
echo "final routed timing (at the requested clocks): WNS=$WNS ns  TNS=$TNS ns  WHS=$WHS ns  THS=$THS ns"
echo "  report: $R"
MHZ=$(xclbinutil --info -i $XCLBIN 2>/dev/null | awk '/Name:.*DATA_CLK/{f=1} f && /Frequency:/{print $2; exit}')
echo "kernel clock in $XCLBIN: ${MHZ:-unknown} MHz"
[ -z "$MHZ" ] && { echo "FAIL: cannot read the kernel clock from the bitstream"; exit 2; }
ok=1; kslack=""
awk -v v="$WHS" 'BEGIN{exit !(v+0 >= 0)}' || { echo "FAIL: hold timing not met (WHS < 0)"; ok=0; }
while read -r name wns; do
    if [[ $name == clk_kernel_00* ]]; then
        kslack=$(awk -v w="$wns" -v m="$MHZ" -v t="$WANT_MHZ" 'BEGIN{printf "%.3f", w + 1000/m - 1000/t}')
        echo "  kernel clock $name: WNS $wns ns at $WANT_MHZ MHz -> $kslack ns at $MHZ MHz"
        awk -v v="$kslack" 'BEGIN{exit !(v+0 >= 0)}' || { echo "FAIL: the kernel clock misses timing even at $MHZ MHz"; ok=0; }
    else
        awk -v v="$wns" 'BEGIN{exit !(v+0 >= 0)}' || { echo "FAIL: clock $name misses timing ($wns ns)"; ok=0; }
    fi
done < <(awk '/Intra Clock Table/{f=1; next} f && /Inter Clock Table/{exit} f && NF >= 3 && $2 ~ /^-?[0-9]+\.[0-9]+$/ {print $1, $2}' "$R")
[ $ok = 1 ] || exit 1
if [ "$MHZ" = "$WANT_MHZ" ]; then echo "PASS: timing closed at $WANT_MHZ MHz"
else echo "NOT AT $WANT_MHZ MHz: timing met at $MHZ MHz (v++ lowered the kernel clock); runs correctly but slower. Run"
     echo "  vivado -mode batch -nojournal -nolog -source worst_paths.tcl   and see worst_groups.txt for the failing paths."; exit 1; fi
