#!/bin/bash
# check_timing.sh -- after "TARGET=hw ./build.sh": pass only if timing closed and the kernel runs at 300 MHz
cd "$(dirname "$0")"
WANT_MHZ=${WANT_MHZ:-300}
R=$(find _x -name "*timing_summary_routed*.rpt" 2>/dev/null | head -1)
[ -z "$R" ] && { echo "FAIL: no routed timing report under _x/ (did the hw build finish?)"; exit 2; }
read -r WNS TNS WHS THS < <(awk '/WNS\(ns\)/{getline; getline; print $1, $2, $5, $6; exit}' "$R")
echo "routed timing: WNS=$WNS ns  TNS=$TNS ns  WHS=$WHS ns  THS=$THS ns"
echo "  report: $R"
MHZ=$(xclbinutil --info -i doma_hw.xclbin 2>/dev/null | awk '/Name:.*DATA_CLK/{f=1} f && /Frequency:/{print $2; exit}')
echo "kernel clock in doma_hw.xclbin: ${MHZ:-unknown} MHz"
ok=1
awk -v v="$WNS" 'BEGIN{exit !(v+0 >= 0)}' || { echo "FAIL: setup timing not met (WNS < 0)"; ok=0; }
awk -v v="$WHS" 'BEGIN{exit !(v+0 >= 0)}' || { echo "FAIL: hold timing not met (WHS < 0)"; ok=0; }
[ "$MHZ" = "$WANT_MHZ" ] || { echo "FAIL: kernel clock is ${MHZ:-unknown} MHz, not $WANT_MHZ (v++ scaled it down)"; ok=0; }
[ $ok = 1 ] && echo "PASS: timing closed at $WANT_MHZ MHz" || exit 1
