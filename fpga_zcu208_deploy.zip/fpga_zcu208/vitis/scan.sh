#!/bin/bash
# scan.sh -- DOMA throughput and latency over N and the HBM share, one CSV row per run.
#   bash scan.sh doma_hw.xclbin [commands]          (run in the directory with host_doma)
#   NS="65536 262144 1048576" HBMS="0 20 50" bash scan.sh doma_hw.xclbin 20000
# N is in records (DOMA_N); each must be at most the build's NMAX. Every response is verified by host_doma.
X=${1:?usage: scan.sh <xclbin> [commands]}; C=${2:-20000}
NS=${NS:-"16384 65536 262144 1048576 4194304"}
HBMS=${HBMS:-"0 10 20 30 50 100"}
OUT=${OUT:-scan_$(basename $X .xclbin)_$(date +%m%d%H%M).csv}
echo "n,hbm_pct,commands,kqps,device_cycles,lat_min_cyc,lat_max_cyc,completed,errors,bad,pool,init_s,note" > $OUT
for n in $NS; do for h in $HBMS; do
    log=$(DOMA_N=$n DOMA_HBM_PCT=$h ./host_doma $X $C 2>&1)
    kq=$(echo "$log" | awk '/^query:/{print $(NF-1)}')
    dev=$(echo "$log" | awk '/^device:/{gsub(/\.\./," "); gsub(/,/,""); print $2","$7","$8","$11","$13}')
    bad=$(echo "$log" | grep -cE "bad header|wrong data")
    pool=$(echo "$log" | awk '/^stash pool:/{print $3}')
    init=$(echo "$log" | awk '/^init:/{print $2}')
    note=""; [ -z "$kq" ] && note=$(echo "$log" | grep -m1 -iE "error|must|fail|exceed|could not" | tr ',' ';' | cut -c1-120)
    echo "$n,$h,$C,${kq:-},${dev:-,,,,},$bad,${pool:-},${init:-},$note" >> $OUT
    printf "N=%-8s HBM=%3s%%  %s KQPS  %s\n" "$n" "$h" "${kq:-FAILED}" "${note:-$(echo "$log" | grep -m1 '^device:' | cut -c1-90)}"
done; done
echo "written $OUT"
