#!/bin/bash
# build_tinyoram.sh -- tinyoram_kernel.xo -> tinyoram_<size>_<target>.xclbin -> host program  (UNTESTED here)
# Needs Vitis/Vivado 2024.1, XRT and the U55C platform (source both setup scripts first).
#   SIZE=4k TARGET=hw_emu bash build_tinyoram.sh   # hardware emulation, no card needed
#   SIZE=4k TARGET=hw     bash build_tinyoram.sh   # board bitstream (hours); run synth_ooc_tinyoram.tcl first
#   SIZE = 64 | 128 | 256 | 4k   (block size; 64 also serves 8-32 B records)
#   N    = records (default 256). Tiny ORAM's tree depth is fixed per build: L is the smallest with
#          4 * 2^L >= N, e.g. N=1000000 -> L=18 (1,048,576 blocks). Run the host with the same DOMA_N.
#   CFG  = tinyoram_hw.cfg (tree in HBM[8], default) | tinyoram_host.cfg (tree in HOST[0])
#   FREQ = kernel clock in MHz (default 300). If 300 does not close, rebuild with a lower FREQ and
#          report results in both cycles and time; check_timing.sh then checks against FREQ.
# Each size and N is its own xclbin, built in its own v++ temp directory (_x_<tag>).
set -euo pipefail
cd "$(dirname "$0")"
PLATFORM=${PLATFORM:-xilinx_u55c_gen3x16_xdma_3_202210_1}
TARGET=${TARGET:-hw}
SIZE=${SIZE:-4k}
CFG=${CFG:-tinyoram_hw.cfg}
FREQ=${FREQ:-300}
N=${N:-256}
L=6; while [ $((4 << L)) -lt $N ]; do L=$((L + 1)); done
TAG=tinyoram_${SIZE}; [ "$N" = 256 ] || TAG=${TAG}_n${N}; [ "$FREQ" = 300 ] || TAG=${TAG}_${FREQ}mhz
bash ../tinyoram/fetch_tinyoram.sh $SIZE $L
vivado -mode batch -nojournal -nolog -source package_tinyoram.tcl -tclargs ../tinyoram/rtl ../tinyoram/build/src $TAG.xo $FREQ
# hardware builds: the same post-placement hook as build.sh (post_place.tcl: placed checkpoint, congestion,
# utilization per module, post-placement timing in _x_$TAG/link/vivado/vpl/prj/prj.runs/impl_1/)
HOOK=""
if [ "$TARGET" = "hw" ]; then HOOK="--vivado.prop run.impl_1.STEPS.PLACE_DESIGN.TCL.POST=$(pwd)/post_place.tcl"; fi
v++ -l -t $TARGET --platform $PLATFORM --kernel_frequency $FREQ --config $CFG $HOOK \
    --save-temps --temp_dir _x_$TAG -o ${TAG}_$TARGET.xclbin $TAG.xo
g++ -std=c++17 -O2 host_doma.cpp -I$XILINX_XRT/include -L$XILINX_XRT/lib -lxrt_coreutil -pthread -o host_doma
BB=$SIZE; [ "$SIZE" = 4k ] && BB=4096
ENV="DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=$BB DOMA_N=$N"   # host settings for this bitstream
[ "$CFG" = tinyoram_host.cfg ] || ENV="$ENV DOMA_PAGES_HBM=1"   # tree buffer in HBM (tinyoram_hw.cfg)
if [ "$TARGET" = hw ]; then
    WANT_MHZ=$FREQ XCLBIN=${TAG}_hw.xclbin XDIR=_x_$TAG ./check_timing.sh || echo "*** TIMING NOT CLOSED: do not use ${TAG}_hw.xclbin for measurements ***"
    echo "run: $ENV ./host_doma ${TAG}_hw.xclbin 5000"
fi
if [ "$TARGET" = hw_emu ]; then
    emconfigutil --platform $PLATFORM
    echo "run: XCL_EMULATION_MODE=hw_emu $ENV ./host_doma ${TAG}_hw_emu.xclbin 20"
fi
