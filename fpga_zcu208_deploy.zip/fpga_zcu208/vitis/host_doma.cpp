// host_doma.cpp -- XRT host program for doma_kernel, built to match BOLT's benchmark host
// (BOLT-benchmark/BOLT/*/host.cpp) so the two are measured the same way:
//   * same workload generator: std::mt19937 seed 1, 50% PUT, keys uniform over the dataset,
//     VALUE_SIZE random bytes per PUT (DOMA stores them at the start of a 4 KB block)
//   * keys are dense: key index i is DOMA slot i (BOLT looks keys up through its hash map)
//   * commands are converted and copied to the card BEFORE timing starts, as BOLT does
//   * query time = one kernel launch processing all CMD_SIZE commands, plus wait()
//   * init time = boot run (key load, bucket layout, lease) + preloading every slot,
//     the analogue of BOLT's data preparation and loading
// Usage: ./host_doma <xclbin> [CMD_SIZE]
#include <xrt/xrt_bo.h>
#include <xrt/xrt_device.h>
#include <xrt/xrt_kernel.h>
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <random>
#include <string>
#include <vector>

// must match the hardware build (rtl/oram_params.vh, single-client default)
static const uint32_t ORAM_N     = 256;              // slots
static const uint32_t ORAM_B     = 64;               // buckets
static const size_t   BLOCK      = 4096;             // bytes per slot (128 beats x 32 B)
static const size_t   BUCKET_STRIDE = 32768;         // bucket spacing in DOMA's memory map
static const int      VALUE_SIZE = 8;                // BOLT's default value size (bytes)
static const uint8_t  T_GET = 0x01, T_PUT = 0x02, T_ACK = 0x10, T_SUM = 0x5A;

static size_t roundup4k(size_t x) { return (x + 4095) & ~size_t(4095); }

struct Cmd { uint8_t type; uint32_t key; uint8_t value[VALUE_SIZE]; };

// BOLT's generate_uniform_commands(), with the key index used directly as the key
static std::vector<Cmd> generate_uniform_commands(int size) {
    std::vector<Cmd> cmds;
    uint32_t seed = 1;
    std::mt19937 gen(seed);
    std::uniform_real_distribution<double> op_dis(0.0, 1.0);
    std::uniform_int_distribution<int> key_dis(0, ORAM_N - 1);
    std::uniform_int_distribution<int> value_dis(0, 255);
    for (int i = 0; i < size; i++) {
        Cmd c{};
        double rw = op_dis(gen);
        c.key = key_dis(gen);
        if (rw < 0.5) { c.type = T_PUT; for (int j = 0; j < VALUE_SIZE; j++) c.value[j] = (uint8_t)value_dis(gen); }
        else c.type = T_GET;
        cmds.push_back(c);
    }
    return cmds;
}

struct Buffers {
    xrt::bo cmd, resp, pages;
    size_t hc = 0, hr = 0;
};

// lay commands out as doma_kernel expects: 32-byte headers, then PUT data on 4 KB boundaries
static void stage(Buffers& b, const std::vector<Cmd>& cmds) {
    size_t n = cmds.size();
    b.hc = roundup4k(n * 32);
    b.hr = roundup4k((n + 1) * 32);
    auto p = b.cmd.map<uint8_t*>();
    std::memset(p, 0, b.hc + n * BLOCK);
    for (size_t i = 0; i < n; i++) {
        p[i * 32] = cmds[i].type;
        std::memcpy(p + i * 32 + 4, &cmds[i].key, 4);
        if (cmds[i].type == T_PUT) std::memcpy(p + b.hc + i * BLOCK, cmds[i].value, VALUE_SIZE);
    }
    b.cmd.sync(XCL_BO_SYNC_BO_TO_DEVICE, b.hc + n * BLOCK, 0);
}

struct Summary { uint64_t total; uint32_t lat_min, lat_max, errors, done; bool ok; };

static Summary read_summary(Buffers& b, size_t n) {
    b.resp.sync(XCL_BO_SYNC_BO_FROM_DEVICE, b.hr + n * BLOCK, 0);
    auto r = b.resp.map<uint8_t*>() + n * 32;
    Summary s{};
    s.ok = (r[0] == T_SUM);
    std::memcpy(&s.total, r + 8, 8);   std::memcpy(&s.lat_min, r + 16, 4); std::memcpy(&s.lat_max, r + 20, 4);
    std::memcpy(&s.errors, r + 24, 4); std::memcpy(&s.done, r + 28, 4);
    return s;
}

int main(int argc, char** argv) {
    if (argc < 2) { std::printf("usage: %s <xclbin> [CMD_SIZE]\n", argv[0]); return 1; }
    const int CMD_SIZE = (argc > 2) ? std::stoi(argv[2]) : 5000;          // BOLT: 5000
    auto device = xrt::device(0);
    auto uuid   = device.load_xclbin(argv[1]);
    auto krnl   = xrt::kernel(device, uuid, "doma_kernel");

    const size_t max_cmds = std::max<size_t>(CMD_SIZE, ORAM_N);
    Buffers b;
    b.cmd   = xrt::bo(device, roundup4k(max_cmds * 32) + max_cmds * BLOCK, krnl.group_id(0));
    b.resp  = xrt::bo(device, roundup4k((max_cmds + 1) * 32) + max_cmds * BLOCK, krnl.group_id(1));
    b.pages = xrt::bo(device, ORAM_B * BUCKET_STRIDE, xrt::bo::flags::host_only, krnl.group_id(2));

    // ---- init: boot run + preload every slot (BOLT's init includes loading its dataset)
    std::vector<uint8_t> ref(size_t(ORAM_N) * VALUE_SIZE);
    std::vector<Cmd> preload;
    std::mt19937 vgen(16);                                                // BOLT seeds its dataset with 16
    std::uniform_int_distribution<int> vdis(0, 255);
    for (uint32_t k = 0; k < ORAM_N; k++) {
        Cmd c{}; c.type = T_PUT; c.key = k;
        for (int j = 0; j < VALUE_SIZE; j++) c.value[j] = (uint8_t)vdis(vgen);
        std::memcpy(&ref[k * VALUE_SIZE], c.value, VALUE_SIZE);
        preload.push_back(c);
    }
    auto init_start = std::chrono::system_clock::now();
    auto r0 = krnl(b.cmd, b.resp, b.pages, 0u);                           // key load, layout, lease
    r0.wait();
    stage(b, preload);
    auto r1 = krnl(b.cmd, b.resp, b.pages, (uint32_t)preload.size());
    r1.wait();
    auto init_end = std::chrono::system_clock::now();
    Summary s1 = read_summary(b, preload.size());
    std::printf("init: %.6f s (boot + preload of %u slots), preload errors=0x%x\n",
                std::chrono::duration<double>(init_end - init_start).count(), ORAM_N, s1.errors);

    // ---- query run, timed exactly like BOLT: launch + wait, commands already on the card
    auto cmds = generate_uniform_commands(CMD_SIZE);
    stage(b, cmds);
    auto start = std::chrono::system_clock::now();
    auto run = krnl(b.cmd, b.resp, b.pages, (uint32_t)cmds.size());
    run.wait();
    auto end = std::chrono::system_clock::now();
    double t = std::chrono::duration<double>(end - start).count();
    Summary s = read_summary(b, cmds.size());

    // ---- verify every response against the reference
    auto resp = b.resp.map<uint8_t*>();
    int bad = 0, gets = 0, puts = 0;
    for (size_t i = 0; i < cmds.size(); i++) {
        const uint8_t* h = resp + i * 32;
        uint32_t key; std::memcpy(&key, h + 4, 4);
        if (h[0] != T_ACK || key != cmds[i].key) { if (bad++ < 5) std::printf("cmd %zu: bad header 0x%02x key %u\n", i, h[0], key); continue; }
        if (cmds[i].type == T_PUT) { std::memcpy(&ref[key * VALUE_SIZE], cmds[i].value, VALUE_SIZE); puts++; }
        else {
            gets++;
            if (std::memcmp(resp + b.hr + i * BLOCK, &ref[key * VALUE_SIZE], VALUE_SIZE) != 0)
                if (bad++ < 5) std::printf("cmd %zu: GET key %u returned wrong data\n", i, key);
        }
    }
    std::printf("query: %d commands (%d GET, %d PUT) in %.6f s = %.1f KQPS\n", CMD_SIZE, gets, puts, t, CMD_SIZE / t / 1e3);
    std::printf("device: %llu cycles total, per-command latency %u..%u cycles, completed %u, errors 0x%x, summary %s\n",
                (unsigned long long)s.total, s.lat_min, s.lat_max, s.done, s.errors, s.ok ? "ok" : "MISSING");
    std::printf("%s\n", (bad == 0 && s.ok && s.errors == 0) ? "ALL RESPONSES CORRECT" : "ERRORS FOUND");
    return (bad == 0 && s.ok && s.errors == 0) ? 0 : 1;
}
