#!/bin/bash
# run_ycsb.sh -- YCSB workloads A-F on the U55C with host_ycsb (doma_kernel). No sudo; the card's configuration is
# not touched (host_ycsb only loads the xclbin and allocates buffers, as host_doma does).
#   bash run_ycsb.sh <xclbin> [smoke|mid|full|all]          (default: smoke)
# smoke: oram_ycsb.c's default size, every workload in one process (n_iters 100, 128 slots, init_occ 64, scan_len 10);
#        the same run was simulated against the Verilated kernel (sim/xrt_mock/results/ycsb_smoke_sim.log). Any build.
# mid:   32,768 slots (oram_ycsb.c's maximum), init_occ 16,384, n_iters 100,000. Fits doma_hw.cfg; needs NMAX >= 32768.
# full:  host_ycsb's defaults: 1,048,576 slots, init_occ 524,288, n_iters 1,000,000 (E: up to 10 reads per scan, about
#        5.3 M ops). Needs NMAX = 1048576 and a large-layout build (doma_big_hbm.cfg, or doma_big.cfg with host memory);
#        DOMA_HBM_PCT defaults to 75 here. About 8 minutes of card time.
# all:   smoke, mid, full.
# Overrides: INST (instance_id, seeds the generator; default 0), NS, OCC, ITERS, SCAN, OUT (result dir),
#            CSV=0/1 (per-command CSV; default on, off for full: about 12 M lines).
# Results: $OUT/<mode>_<workload>.log and .csv (per command: latency in cycles, status).
set -u
cd "$(dirname "$0")"
X=${1:?usage: run_ycsb.sh <xclbin> [smoke|mid|full|all]}
MODE=${2:-smoke}
[ -x ./host_ycsb ] || { echo "build host_ycsb first:"; echo "  g++ -std=c++17 -O2 -ffp-contract=off host_ycsb.cpp -I\$XILINX_XRT/include -L\$XILINX_XRT/lib -lxrt_coreutil -pthread -o host_ycsb"; exit 1; }
[ -f "$X" ] || { echo "no xclbin $X"; exit 1; }
case "$MODE" in smoke|mid|full|all) ;; *) echo "mode must be smoke, mid, full or all"; exit 1;; esac
OUT=${OUT:-ycsb_results}; mkdir -p "$OUT"
INST=${INST:-0}; SCAN=${SCAN:-10}
fails=0
run() {   # run <tag> <workload(s)> <n_iters> <num_slots> <init_occ> <scan_len> <csv 0|1>
    local tag=$1 w=$2 log="$OUT/$1_$2.log" csv=""
    [ "$7" = 1 ] && csv="$OUT/$1_$2.csv"
    echo "== $tag $w: n_iters=$3 num_slots=$4 init_occ=$5 scan_len=$6 instance_id=$INST${DOMA_HBM_PCT:+ DOMA_HBM_PCT=$DOMA_HBM_PCT}"
    YCSB_CSV="$csv" ./host_ycsb "$X" 1 "$INST" "$3" "$4" "$w" "$5" "$6" > "$log" 2>&1
    local rc=$?
    # the run phase's lines, the gem5-style summary line and the verdict (several workloads: the summary table)
    awk '/^summary/{t=1} t{print; next} /^RUN /{n=3} n>0{print; n--; next}
         /^oram_ycsb:|^WORKLOAD FAILED|^ERRORS|errors 0x|MISMATCH|failed|cannot|^MOCK: /{print}' "$log"
    [ $rc = 0 ] || { fails=$((fails + 1)); echo "   FAILED (exit $rc): see $log"; }
}
if [ "$MODE" = smoke ] || [ "$MODE" = all ]; then
    run smoke ABCDEF 100 128 64 10 "${CSV:-1}"
fi
if [ "$MODE" = mid ] || [ "$MODE" = all ]; then
    ns=${NS:-32768}
    for w in A B C D E F; do run mid $w "${ITERS:-100000}" "$ns" "${OCC:-$((ns / 2))}" "$SCAN" "${CSV:-1}"; done
fi
if [ "$MODE" = full ] || [ "$MODE" = all ]; then
    export DOMA_HBM_PCT=${DOMA_HBM_PCT:-75}
    ns=${NS:-1048576}
    for w in A B C D E F; do run full $w "${ITERS:-1000000}" "$ns" "${OCC:-$((ns / 2))}" "$SCAN" "${CSV:-0}"; done
fi
echo
echo "kernel clock in $X: $(xclbinutil --info -i "$X" 2>/dev/null | awk '/Name:.*DATA_CLK/{f=1} f && /Frequency:/{print $2; exit}') MHz (host_ycsb's microseconds assume DOMA_MHZ=${DOMA_MHZ:-300})"
[ $fails = 0 ] && echo "run_ycsb: every run PASSED (logs in $OUT/)" || echo "run_ycsb: $fails run(s) FAILED (logs in $OUT/)"
exit $fails
