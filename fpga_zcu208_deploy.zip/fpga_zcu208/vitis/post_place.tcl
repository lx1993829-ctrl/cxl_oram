# post_place.tcl -- run by the v++ implementation right after placement (build.sh adds the hook for TARGET=hw).
# Leaves evidence even if the build is stopped later: the placed checkpoint, where routing will be congested
# (with the cells in each congested window), utilization per module, and the post-placement timing.
# Every command is wrapped in catch, so a reporting problem can never fail the build.
# Files land in _x/link/vivado/vpl/prj/prj.runs/impl_1/.
catch { write_checkpoint -force post_place.dcp }
catch { report_design_analysis -congestion -file post_place_congestion.rpt }
catch { report_utilization -hierarchical -hierarchical_depth 8 -file post_place_util_hier.rpt }
catch { report_timing_summary -max_paths 20 -file post_place_timing.rpt }
