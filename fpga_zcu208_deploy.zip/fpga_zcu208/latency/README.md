
## PCIe calibration sweep (`lat_pcie.cfg`)

The kernel also measures, for fitting a PCIe model of the host-memory path (registers `beats` 0x38, `outst` 0x40,
`span` 0x48, `seed` 0x50; all 0 keeps modes 0-2 exactly as before):
- **dependent reads of any size** (mode 0, `beats` = S / 32, up to 32 KB; above 4 KB as back-to-back 4 KB bursts, as a
  bucket read is), timed to the last beat;
- **independent reads / writes** (modes 3 / 4): `outst` = K (1..64) requests in flight to random blocks of the buffer
  (`span` blocks, a power of two); each sample runs from the address handshake to the last beat (reads) or the write
  response (writes), and the total time gives the bandwidth. Writes with K = 1 give the unloaded acknowledgement of a burst.
Sizes are rounded down to a power of two, so no burst crosses a 4 KB boundary.

```
CFG=lat_pcie.cfg OUT=lat_pcie bash build_lat.sh          # about an hour; check_timing must PASS (if v++ scaled the
                                                          # clock, e.g. to 299 MHz, add LAT_MHZ=299 to the runs)
# cold (DRAM-served) runs: the chains span far more than the CPU's last-level cache
LAT_CHAIN_HOST=1 LAT_CU=lat_1 LAT_SPAN_MB=1500 LAT_SWEEP=1 LAT_CSV=pcie_cold.csv ./host_lat lat_pcie.xclbin
# aggregate bandwidth with both instances (each its own buffer: both must fit the 2 GB host-memory region)
LAT_CHAIN_HOST=1 LAT_CU=lat_1 LAT_CU2=lat_2 LAT_SPAN_MB=900 LAT_SWEEP=1 LAT_CSV=pcie_dual.csv ./host_lat lat_pcie.xclbin
# cache-resident comparison
LAT_CHAIN_HOST=1 LAT_CU=lat_1 LAT_SPAN_MB=16 LAT_SWEEP=1 LAT_CSV=pcie_llc.csv ./host_lat lat_pcie.xclbin
```
The sweep: dependent reads of 32 B, 256 B, 1 KB, 4 KB and 32 KB; write acknowledgements of 32 B, 256 B and 4 KB bursts;
independent writes, then reads, of 256 B and 4 KB with K = 1, 2, 4 .. 64. Each result is printed and written as a CSV row
(kind, instances, bytes, outstanding, samples, min / avg / p50 / p99 / p99.9 / max cycles, total cycles, GB/s, MHz).
Dependent samples include the kernel's 2 cycles; independent ones are measured from the handshake (about 1 cycle less).
Simulation (`run_sim.sh`) checks every mode against the AXI memory model, including Little's law under load.
