# HBM / host-memory latency benchmark (`hbm_lat_kernel`)

A small Vitis RTL kernel that measures the memory latencies DOMA's design depends on, in kernel
cycles at 300 MHz:

| Mode | What one sample is | Why DOMA cares |
|---|---|---|
| 0 dependent 32-byte reads | read a line; the next address comes from its data, so reads never overlap | a position-map lookup must finish before the bucket read can start |
| 1 write acknowledgements | write the line just read back unchanged; time from issue to its response | an access counts as done only when its writes are acknowledged |
| 2 dependent 4 KB bursts | read a 4 KB page, timed to its last beat | a bucket read |

The chain is one random cycle over all lines (Sattolo's algorithm), so every access lands somewhere
unpredictable. Each sample includes 2 cycles of the kernel itself; the host prints the memory's share
in nanoseconds. Results are min/avg/max and percentiles from a 128-bin histogram. The host widens the
bins automatically until no sample overflows, so the tail is always captured.

**Run on the card:**
```
source /tools/Xilinx/Vitis/2024.1/settings64.sh && source /opt/xilinx/xrt/setup.sh
cd ~/fpga_zcu208/latency
bash build_lat.sh                 # about an hour; ends with check_timing (must print PASS)
./host_lat lat_hw.xclbin          # chain in HBM[8], DOMA's bucket bank
```
**Host memory over PCIe**, once it is enabled on the card:
`CFG=lat_host.cfg OUT=lat_host bash build_lat.sh`, then `LAT_CHAIN_HOST=1 ./host_lat lat_host.xclbin`.

**Simulation:** `bash run_sim.sh`. With the memory model at 40 and 100 cycles, every sample reads 42
and 102; writes landing after 50 cycles read 52, with the chain intact; 4 KB bursts read 169
(42 + 127 beats).
