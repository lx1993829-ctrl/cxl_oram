
## PCIe calibration sweep (`lat_pcie.cfg`)

The kernel also measures, for fitting a PCIe model of the host-memory path (registers `beats` 0x38, `outst` 0x40,
`span` 0x48, `seed` 0x50; all 0 keeps modes 0-2 exactly as before):
- **dependent reads of any size** (mode 0, `beats` = S / 32, up to 32 KB; above 4 KB as back-to-back 4 KB bursts, as a
  bucket read is), timed to the last beat;
- **independent reads / writes** (modes 3 / 4): `outst` = K (1..64) requests in flight to random blocks of the buffer
  (`span` blocks, a power of two); each sample runs from the address handshake to the last beat (reads) or the write
  response (writes), and the total time gives the bandwidth. Writes with K = 1 give the unloaded acknowledgement of a burst.
Sizes are rounded down to a power of two, so no burst crosses a 4 KB boundary.

```
CFG=lat_pcie.cfg OUT=lat_pcie bash build_lat.sh          # about an hour; check_timing must PASS (if v++ scaled the
                                                          # clock, e.g. to 299 MHz, add LAT_MHZ=299 to the runs)
# cold (DRAM-served) runs: the chains span far more than the CPU's last-level cache
LAT_CHAIN_HOST=1 LAT_CU=lat_1 LAT_SPAN_MB=1500 LAT_SWEEP=1 LAT_CSV=pcie_cold.csv ./host_lat lat_pcie.xclbin
# aggregate bandwidth with both instances (each its own buffer: both must fit the 2 GB host-memory region)
LAT_CHAIN_HOST=1 LAT_CU=lat_1 LAT_CU2=lat_2 LAT_SPAN_MB=900 LAT_SWEEP=1 LAT_CSV=pcie_dual.csv ./host_lat lat_pcie.xclbin
# cache-resident comparison
LAT_CHAIN_HOST=1 LAT_CU=lat_1 LAT_SPAN_MB=16 LAT_SWEEP=1 LAT_CSV=pcie_llc.csv ./host_lat lat_pcie.xclbin
```
The sweep: dependent reads of 32 B, 256 B, 1 KB, 4 KB and 32 KB; write acknowledgements of 32 B, 256 B and 4 KB bursts;
independent writes, then reads, of 256 B and 4 KB with K = 1, 2, 4 .. 64. Each result is printed and written as a CSV row
(kind, instances, bytes, outstanding, samples, min / avg / p50 / p99 / p99.9 / max cycles, total cycles, GB/s, MHz).
Dependent samples include the kernel's 2 cycles; independent ones are measured from the handshake (about 1 cycle less).
Simulation (`run_sim.sh`) checks every mode against the AXI memory model, including Little's law under load.

## Read after write, 768-byte bursts, reads and writes at once

- **Mode 5, read after write**: write `wbeats` (up to 32 KB, as 4 KB bursts) and wait for every B response, wait `gap`
  cycles, then read `beats`, timed like a dependent read (ARVALID to the last beat). Mode bit 16 = read the block just
  written; otherwise DOMA's pattern (write back the block just read, then read a new random block). `wbeats` = 0 is
  the baseline. Registers `wbeats` 0x58, `gap` 0x60.
- **Bursts of any length up to 4 KB** in modes 3-5 (e.g. 768 B = 24 beats), placed in blocks of the next power of two,
  so no burst crosses a 4 KB boundary.
- Simulation checks: 768-byte reads and writes (constant unloaded latency, writes stream at 1 cycle per beat, no 4 KB
  crossings); mode 5 equal to a plain read on the fixed-latency memory model; 32 KB write + gap + 4 KB read in order.

After rebuilding `lat_pcie` with this kernel (`CFG=lat_pcie.cfg OUT=lat_pcie bash build_lat.sh`), set `MHZ` to the
kernel clock the build achieved (v++ may scale it below 300; the previous build ran at 293). It is in the bitstream's
clock list: `xclbinutil --info --input lat_pcie.xclbin` (the kernel clock's frequency). **Every command needs
`LAT_MHZ`**: without it all ns and GB/s figures are computed for 300 MHz.
```
MHZ=293      # replace with this build's kernel clock
g++ -std=c++17 -O2 host_lat.cpp -I$XILINX_XRT/include -L$XILINX_XRT/lib -lxrt_coreutil -pthread -o host_lat_pcie
# 1. read after write: 32 B and 4 KB reads after 4 KB / 32 KB writes, same or other block, gaps 0-600 cycles,
#    waiting for every B (as DOMA does) and not (read at the last W beat)
LAT_MHZ=$MHZ LAT_CHAIN_HOST=1 LAT_CU=lat_1 LAT_SPAN_MB=1500 LAT_RAW=1 LAT_CSV=pcie_raw.csv \
  ./host_lat_pcie lat_pcie.xclbin | tee pcie_raw.txt
# 2. 768-byte bursts, two masters (256 and 4096 for reference). Judge by the WRITE plateau: 14.31 GB/s = 256-byte
#    packets, 14.10 = 512-byte. The read plateau cannot decide: FPGA-side limits sit at or below both predictions
#    (burst gaps: 2 x 9.38 x 24/32 = 14.07 GB/s if ~8 idle cycles per burst; request rate: 18.9 M/s x 768 = 14.5)
LAT_MHZ=$MHZ LAT_CHAIN_HOST=1 LAT_CU=lat_1 LAT_CU2=lat_2 LAT_SPAN_MB=3000 LAT_SWEEP=1 LAT_DEP_SIZES=32 \
  LAT_IND_SIZES=256,768,4096 LAT_CSV=pcie_768.csv ./host_lat_pcie lat_pcie.xclbin | tee pcie_768.txt
# 3. 768-byte bursts, one master: does the read gap come per burst (~7.0 GB/s) or scale with the burst (~8.8 GB/s)?
LAT_MHZ=$MHZ LAT_CHAIN_HOST=1 LAT_CU=lat_1 LAT_SPAN_MB=3000 LAT_SWEEP=1 LAT_DEP_SIZES=32 \
  LAT_IND_SIZES=768 LAT_CSV=pcie_768_one.csv ./host_lat_pcie lat_pcie.xclbin | tee pcie_768_one.txt
# 4. one master reading while the other writes, each against its rate alone
LAT_MHZ=$MHZ LAT_CHAIN_HOST=1 LAT_CU=lat_1 LAT_CU2=lat_2 LAT_SPAN_MB=3000 LAT_DUPLEX=1 LAT_IND_SIZES=256,4096 \
  LAT_CSV=pcie_duplex.csv ./host_lat_pcie lat_pcie.xclbin | tee pcie_duplex.txt
```
Buffers: each instance allocates `LAT_SPAN_MB` of host memory, so two-master runs need twice that. HOST[0] is now
8 GB (resized with `xrt-smi configure --host-mem`), so two 3,000 MB buffers fit; if a buffer does not, the program
says so and stops. The 768-byte bursts sit at a 1 KB stride (blocks of the next power of two), so none crosses a
4 KB boundary; the simulation memory model flags any burst that does, and the 768-byte runs show none.
Options: `LAT_RAW_READS`, `LAT_RAW_WRITES` (bytes), `LAT_RAW_GAPS` (cycles), `LAT_RAW_N`, `LAT_RAW_NOWAIT` (0,1). The CSV gains two columns,
`write_bytes` and `gap_cyc`. `pcie_fit.py` ignores the read-after-write and duplex rows. With 8 GB of host memory, two
3,000 MB buffers fit. The host program now passes 10 kernel arguments, so it needs a bitstream built from this kernel.
