#!/bin/bash
# run_sim.sh -- hbm_lat_kernel against the AXI memory model (Verilator): every sample must equal the
# model's latency + 2 cycles, the write mode must leave the chain intact, the histogram must add up.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
verilator --binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-STMTDLY -Wno-INITIALDLY \
    --top-module tb_lat tb_lat.v ../sim/axi_mem_model.v hbm_lat_kernel.v -Mdir build/obj -o Vlat > build/build.log 2>&1
./build/obj/Vlat | tee build/run.log | grep -vE "^-"
grep -q "ALL CHECKS PASSED" build/run.log
