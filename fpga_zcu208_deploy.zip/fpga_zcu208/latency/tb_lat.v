// tb_lat.v -- hbm_lat_kernel against the AXI memory model: the measured latency must follow the
// model's latency exactly (every sample equal), the write mode must leave the chain intact, and the
// histogram must account for every sample.
`timescale 1ns/1ps
module tb_lat;
    localparam DW = 256, L = 2048;                       // chain length (lines)
    localparam [63:0] BUF_BASE = 64'h0000_0040_0000_0000, RES_BASE = 64'h0000_0050_0000_0000;
    reg clk = 0, rst_n = 0; always #1.667 clk = ~clk;
    reg [11:0] awaddr = 0, araddr = 0; reg awvalid = 0, wvalid = 0, bready = 0, arvalid = 0, rready = 0; reg [31:0] wdata = 0;
    wire awready, wready, bvalid, arready, rvalid; wire [1:0] bresp, rresp; wire [31:0] rdata; wire irq;
    wire [63:0] g0_araddr, g0_awaddr, g1_araddr, g1_awaddr; wire [7:0] g0_arlen, g0_awlen, g1_arlen, g1_awlen;
    wire g0_arvalid, g0_arready, g0_rvalid, g0_rlast, g0_rready, g0_awvalid, g0_awready, g0_wvalid, g0_wready, g0_wlast, g0_bvalid, g0_bready;
    wire g1_arvalid, g1_awvalid, g1_awready, g1_wvalid, g1_wready, g1_wlast, g1_bvalid, g1_bready;
    wire [DW-1:0] g0_rdata, g0_wdata, g1_wdata; wire [DW/8-1:0] g0_wstrb, g1_wstrb;
    hbm_lat_kernel dut (.ap_clk(clk), .ap_rst_n(rst_n),
        .s_axi_control_awaddr(awaddr), .s_axi_control_awvalid(awvalid), .s_axi_control_awready(awready),
        .s_axi_control_wdata(wdata), .s_axi_control_wstrb(4'hF), .s_axi_control_wvalid(wvalid), .s_axi_control_wready(wready),
        .s_axi_control_bresp(bresp), .s_axi_control_bvalid(bvalid), .s_axi_control_bready(bready),
        .s_axi_control_araddr(araddr), .s_axi_control_arvalid(arvalid), .s_axi_control_arready(arready),
        .s_axi_control_rdata(rdata), .s_axi_control_rresp(rresp), .s_axi_control_rvalid(rvalid), .s_axi_control_rready(rready),
        .interrupt(irq),
        .m_axi_gmem0_araddr(g0_araddr), .m_axi_gmem0_arlen(g0_arlen), .m_axi_gmem0_arsize(), .m_axi_gmem0_arburst(),
        .m_axi_gmem0_arvalid(g0_arvalid), .m_axi_gmem0_arready(g0_arready), .m_axi_gmem0_rdata(g0_rdata), .m_axi_gmem0_rresp(2'b00),
        .m_axi_gmem0_rlast(g0_rlast), .m_axi_gmem0_rvalid(g0_rvalid), .m_axi_gmem0_rready(g0_rready),
        .m_axi_gmem0_awaddr(g0_awaddr), .m_axi_gmem0_awlen(g0_awlen), .m_axi_gmem0_awsize(), .m_axi_gmem0_awburst(),
        .m_axi_gmem0_awvalid(g0_awvalid), .m_axi_gmem0_awready(g0_awready), .m_axi_gmem0_wdata(g0_wdata), .m_axi_gmem0_wstrb(g0_wstrb),
        .m_axi_gmem0_wlast(g0_wlast), .m_axi_gmem0_wvalid(g0_wvalid), .m_axi_gmem0_wready(g0_wready),
        .m_axi_gmem0_bresp(2'b00), .m_axi_gmem0_bvalid(g0_bvalid), .m_axi_gmem0_bready(g0_bready),
        .m_axi_gmem1_araddr(g1_araddr), .m_axi_gmem1_arlen(g1_arlen), .m_axi_gmem1_arsize(), .m_axi_gmem1_arburst(),
        .m_axi_gmem1_arvalid(g1_arvalid), .m_axi_gmem1_arready(1'b0), .m_axi_gmem1_rdata({DW{1'b0}}), .m_axi_gmem1_rresp(2'b00),
        .m_axi_gmem1_rlast(1'b0), .m_axi_gmem1_rvalid(1'b0), .m_axi_gmem1_rready(),
        .m_axi_gmem1_awaddr(g1_awaddr), .m_axi_gmem1_awlen(g1_awlen), .m_axi_gmem1_awsize(), .m_axi_gmem1_awburst(),
        .m_axi_gmem1_awvalid(g1_awvalid), .m_axi_gmem1_awready(g1_awready), .m_axi_gmem1_wdata(g1_wdata), .m_axi_gmem1_wstrb(g1_wstrb),
        .m_axi_gmem1_wlast(g1_wlast), .m_axi_gmem1_wvalid(g1_wvalid), .m_axi_gmem1_wready(g1_wready),
        .m_axi_gmem1_bresp(2'b00), .m_axi_gmem1_bvalid(g1_bvalid), .m_axi_gmem1_bready(g1_bready));
    axi_mem_model #(.DW(DW), .WORDS(L * 128), .BASE(BUF_BASE), .RLAT(40)) u_buf (
        .clk(clk), .rst_n(rst_n), .araddr(g0_araddr), .arlen(g0_arlen), .arvalid(g0_arvalid), .arready(g0_arready),
        .rdata(g0_rdata), .rresp(), .rlast(g0_rlast), .rvalid(g0_rvalid), .rready(g0_rready),
        .awaddr(g0_awaddr), .awlen(g0_awlen), .awvalid(g0_awvalid), .awready(g0_awready), .wdata(g0_wdata), .wstrb(g0_wstrb),
        .wlast(g0_wlast), .wvalid(g0_wvalid), .wready(g0_wready), .bresp(), .bvalid(g0_bvalid), .bready(g0_bready));
    axi_mem_model #(.DW(DW), .WORDS(64), .BASE(RES_BASE), .RLAT(40)) u_res (
        .clk(clk), .rst_n(rst_n), .araddr(64'd0), .arlen(8'd0), .arvalid(1'b0), .arready(), .rdata(), .rresp(), .rlast(), .rvalid(), .rready(1'b1),
        .awaddr(g1_awaddr), .awlen(g1_awlen), .awvalid(g1_awvalid), .awready(g1_awready), .wdata(g1_wdata), .wstrb(g1_wstrb),
        .wlast(g1_wlast), .wvalid(g1_wvalid), .wready(g1_wready), .bresp(), .bvalid(g1_bvalid), .bready(g1_bready));

    task axil_wr; input [11:0] a; input [31:0] d; begin
        @(negedge clk); awaddr = a; wdata = d; awvalid = 1; wvalid = 1;
        while (!bvalid) @(negedge clk);
        awvalid = 0; wvalid = 0; bready = 1; @(negedge clk); bready = 0;
    end endtask
    task axil_rd; input [11:0] a; output [31:0] d; begin
        @(negedge clk); araddr = a; arvalid = 1;
        while (!rvalid) @(negedge clk);
        d = rdata; arvalid = 0; rready = 1; @(negedge clk); rready = 0;
    end endtask

    integer fails = 0, perm [0:L-1], k, j, t, seed = 11;
    reg [31:0] v; reg [DW-1:0] hdr; reg [31:0] lmin, lmax, cnt; reg [63:0] lsum; integer hsum, nz, hb;
    task build_chain; input integer stride; begin          // Sattolo: one random cycle over all L lines
        for (k = 0; k < L; k = k + 1) perm[k] = k;
        for (k = L - 1; k > 0; k = k - 1) begin j = $unsigned($random(seed)) % k; t = perm[k]; perm[k] = perm[j]; perm[j] = t; end
        for (k = 0; k < L * 128; k = k + 1) u_buf.mem[k] = {DW{1'b0}};
        for (k = 0; k < L; k = k + 1) u_buf.mem[k * stride] = {224'hA5A5, perm[k][31:0]};
    end endtask
    task run; input integer n, mode, shift; input [8*16-1:0] name; input integer expect_lat; begin
        axil_wr(12'h10, BUF_BASE[31:0]); axil_wr(12'h14, BUF_BASE[63:32]);
        axil_wr(12'h1C, RES_BASE[31:0]); axil_wr(12'h20, RES_BASE[63:32]);
        axil_wr(12'h28, n); axil_wr(12'h30, mode | (shift << 8));
        axil_wr(12'h00, 32'h1);
        v = 0; while (!v[1]) begin repeat (20) @(negedge clk); axil_rd(12'h00, v); end
        hdr = u_res.mem[0];
        lmin = hdr[63:32]; lmax = hdr[95:64]; cnt = hdr[127:96]; lsum = hdr[191:128];
        hsum = 0; nz = 0;
        for (hb = 0; hb < 128; hb = hb + 1) begin
            t = u_res.mem[1 + hb / 8][32 * (hb % 8) +: 32]; hsum = hsum + t; if (t != 0) nz = nz + 1; end
        $display("%0s: n=%0d min=%0d max=%0d avg=%0d cycles, histogram total %0d in %0d bin(s), magic %h",
                 name, cnt, lmin, lmax, (cnt > 0) ? lsum / cnt : 0, hsum, nz, hdr[31:0]);
        if (hdr[31:0] !== 32'h1A7E0001 || cnt !== n || hsum !== n) begin
            $display("FAIL %0s: header or histogram does not account for every sample", name); fails = fails + 1; end
        if (expect_lat >= 0 && (lmin !== lmax || lmin !== expect_lat)) begin
            $display("FAIL %0s: expected every sample = %0d cycles", name, expect_lat); fails = fails + 1; end
    end endtask

    integer base40, chain_ok;
    initial begin
        repeat (8) @(posedge clk); rst_n = 1;
        build_chain(1);
        u_buf.lat = 40;  run(1000, 0, 3, "read @40", -1); base40 = lmin;
        if (lmin !== lmax) begin $display("FAIL: dependent reads vary on a fixed-latency memory"); fails = fails + 1; end
        u_buf.lat = 100; run(1000, 0, 3, "read @100", base40 + 60);   // must move by exactly the 60 cycles added
        u_buf.lat = 40;  u_buf.wlat = 50; run(500, 1, 3, "write ack", -1);
        chain_ok = 1; for (k = 0; k < L; k = k + 1) if (u_buf.mem[k][31:0] !== perm[k]) chain_ok = 0;
        if (!chain_ok) begin $display("FAIL: write mode changed the chain"); fails = fails + 1; end
        else $display("write mode left the chain intact");
        u_buf.wlat = 0; build_chain(128); run(200, 2, 4, "4KB burst @40", -1);
        if (u_buf.perr != 0 || u_res.perr != 0) begin $display("FAIL: AXI protocol violations"); fails = fails + 1; end
        if (fails == 0) $display("*** LATENCY KERNEL: ALL CHECKS PASSED ***"); else $display("*** LATENCY KERNEL: %0d FAILURE(S) ***", fails);
        $finish;
    end
    initial begin #20000000; $display("FAIL: timeout"); $finish; end
endmodule
