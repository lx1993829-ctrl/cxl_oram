// host_lat.cpp -- runs hbm_lat_kernel and prints memory latency statistics.
//   ./host_lat lat_hw.xclbin [n]     n = samples per mode (default 1000000; writes and bursts use n/5)
//   LAT_CHAIN_HOST=1 ./host_lat lat_host.xclbin   the chain in host memory (lat_host.cfg build)
// Modes: dependent 32-byte reads, write acknowledgements, dependent 4 KB bursts (to the last beat).
// The kernel adds a constant 2 cycles (issue, then registering the data); "memory" subtracts them.
#include <xrt/xrt_bo.h>
#include <xrt/xrt_device.h>
#include <xrt/xrt_kernel.h>
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <numeric>
#include <random>
#include <string>
#include <vector>

static const uint32_t LINES = 1u << 16;          // 32-byte lines in the read/write chain (2 MB)
static const uint32_t PAGES = 1u << 12;          // 4 KB pages in the burst chain (16 MB)
static const size_t   BUF   = size_t(PAGES) * 4096;
static const double   MHZ   = 300.0;             // kernel clock (check_timing.sh confirms 300 MHz)
static const int      KOVH  = 2;                 // cycles the kernel itself adds to each sample

struct Res { uint32_t magic, min, max, cnt; uint64_t sum, total; uint32_t hist[128]; };

// one random cycle over all entries (Sattolo), so every access lands somewhere unpredictable
static void build_chain(uint8_t* p, uint32_t n, size_t stride, uint32_t seed) {
    std::vector<uint32_t> perm(n); std::iota(perm.begin(), perm.end(), 0u);
    std::mt19937 g(seed);
    for (uint32_t k = n - 1; k > 0; k--) { std::uniform_int_distribution<uint32_t> d(0, k - 1); std::swap(perm[k], perm[d(g)]); }
    std::memset(p, 0, size_t(n) * stride);
    for (uint32_t k = 0; k < n; k++) std::memcpy(p + size_t(k) * stride, &perm[k], 4);
}

static Res run(xrt::kernel& k, xrt::bo& chain, xrt::bo& res, uint32_t n, uint32_t mode, uint32_t shift) {
    auto r = k(chain, res, n, mode | (shift << 8)); r.wait();
    res.sync(XCL_BO_SYNC_BO_FROM_DEVICE, 17 * 32, 0);
    const uint8_t* q = res.map<uint8_t*>(); Res o;
    std::memcpy(&o.magic, q, 4); std::memcpy(&o.min, q + 4, 4); std::memcpy(&o.max, q + 8, 4); std::memcpy(&o.cnt, q + 12, 4);
    std::memcpy(&o.sum, q + 16, 8); std::memcpy(&o.total, q + 24, 8); std::memcpy(o.hist, q + 32, 512);
    return o;
}

// percentile from the histogram: upper edge of the bin holding it (bin 127 = at least its lower edge)
static std::string pct(const Res& o, uint32_t shift, double p) {
    uint64_t want = uint64_t(p * o.cnt + 0.999999), c = 0;
    for (int b = 0; b < 128; b++) {
        c += o.hist[b];
        if (c >= want) {
            char s[64];
            if (b == 127) std::snprintf(s, sizeof s, ">=%u", 127u << shift);
            else std::snprintf(s, sizeof s, "<=%u", ((uint32_t(b) + 1) << shift) - 1);
            return s;
        }
    }
    return "?";
}

static void report(const char* name, const Res& o, uint32_t shift) {
    double avg = o.cnt ? double(o.sum) / o.cnt : 0;
    std::printf("%-28s %8u samples  min %5u  avg %8.1f  max %6u cycles   (memory: min %.0f ns, avg %.0f ns, max %.0f ns)\n",
                name, o.cnt, o.min, avg, o.max, (o.min - KOVH) * 1e3 / MHZ, (avg - KOVH) * 1e3 / MHZ, (o.max - KOVH) * 1e3 / MHZ);
    std::printf("%-28s percentiles (cycles, bins of %u): p50 %s  p99 %s  p99.9 %s  p99.99 %s\n", "",
                1u << shift, pct(o, shift, 0.50).c_str(), pct(o, shift, 0.99).c_str(), pct(o, shift, 0.999).c_str(), pct(o, shift, 0.9999).c_str());
    if (o.magic != 0x1A7E0001u) std::printf("  WARNING: bad result header 0x%08x\n", o.magic);
}

// run a mode, widening the histogram bins until no sample overflows its last bin
static void measure(xrt::kernel& k, xrt::bo& chain, xrt::bo& res, uint32_t n, uint32_t mode, uint32_t shift, const char* name) {
    Res o;
    for (;;) {
        o = run(k, chain, res, n, mode, shift);
        if (o.hist[127] == 0 || shift >= 10) break;
        shift++;                                                    // some samples beyond 127 bins: wider bins
    }
    report(name, o, shift);
}

int main(int argc, char** argv) {
    if (argc < 2) { std::printf("usage: %s <xclbin> [samples]\n", argv[0]); return 1; }
    uint32_t n = (argc > 2) ? uint32_t(std::atoi(argv[2])) : 1000000u;
    bool host = std::getenv("LAT_CHAIN_HOST") != nullptr;
    xrt::device device(0);
    auto uuid = device.load_xclbin(argv[1]);
    xrt::kernel krnl(device, uuid, "hbm_lat_kernel");
    xrt::bo chain = host ? xrt::bo(device, BUF, xrt::bo::flags::host_only, krnl.group_id(0))
                         : xrt::bo(device, BUF, krnl.group_id(0));
    xrt::bo res(device, 4096, krnl.group_id(1));
    std::printf("chain in %s; %u samples per read run; kernel clock assumed %.0f MHz; the kernel adds %d cycles per sample\n",
                host ? "host memory (PCIe)" : "HBM", n, MHZ, KOVH);
    uint8_t* p = chain.map<uint8_t*>();
    build_chain(p, LINES, 32, 7);
    chain.sync(XCL_BO_SYNC_BO_TO_DEVICE, size_t(LINES) * 32, 0);
    measure(krnl, chain, res, n, 0, 2, "dependent 32-byte reads");
    measure(krnl, chain, res, n / 5, 1, 2, "write acknowledgements");
    build_chain(p, PAGES, 4096, 9);
    chain.sync(XCL_BO_SYNC_BO_TO_DEVICE, BUF, 0);
    measure(krnl, chain, res, n / 5, 2, 3, "dependent 4 KB bursts");
    return 0;
}
