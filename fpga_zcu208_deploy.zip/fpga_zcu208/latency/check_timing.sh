#!/bin/bash
# check_timing.sh -- after "build_lat.sh": is the bitstream usable, and at which kernel clock?
# Reads the FINAL routed timing (after post-route optimization), and judges the kernel clock's slack at the clock
# v++ chose: when timing fails at 300 MHz, v++ scales the kernel clock down to where the paths fit. Platform clocks
# must meet timing as they are, and hold must be met everywhere.
cd "$(dirname "$0")"
WANT_MHZ=${WANT_MHZ:-300}
R=$(find _x -name "*timing_summary_postroute_physopted*.rpt" 2>/dev/null | head -1)
[ -z "$R" ] && R=$(find _x -name "*timing_summary_routed*.rpt" 2>/dev/null | head -1)
[ -z "$R" ] && { echo "FAIL: no routed timing report under _x/ (did the hw build finish?)"; exit 2; }
read -r WNS TNS WHS THS < <(awk '/WNS\(ns\)/{getline; getline; print $1, $2, $5, $6; exit}' "$R")
echo "final routed timing (at the requested clocks): WNS=$WNS ns  TNS=$TNS ns  WHS=$WHS ns  THS=$THS ns"
echo "  report: $R"
MHZ=$(xclbinutil --info -i ${XCLBIN:-lat_hw.xclbin} 2>/dev/null | awk '/Name:.*DATA_CLK/{f=1} f && /Frequency:/{print $2; exit}')
echo "kernel clock in ${XCLBIN:-lat_hw.xclbin}: ${MHZ:-unknown} MHz"
[ -z "$MHZ" ] && { echo "FAIL: cannot read the kernel clock from the bitstream"; exit 2; }
ok=1
awk -v v="$WHS" 'BEGIN{exit !(v+0 >= 0)}' || { echo "FAIL: hold timing not met (WHS < 0)"; ok=0; }
# per clock (Intra Clock Table): the kernel clock (clk_kernel_00) at the scaled clock, every other clock as it is
while read -r name wns; do
    if [[ $name == clk_kernel_00* ]]; then
        s=$(awk -v w="$wns" -v m="$MHZ" -v t="$WANT_MHZ" 'BEGIN{printf "%.3f", w + 1000/m - 1000/t}')
        echo "  $name: WNS $wns ns at $WANT_MHZ MHz -> $s ns at $MHZ MHz"
        awk -v v="$s" 'BEGIN{exit !(v+0 >= 0)}' || { echo "FAIL: the kernel clock misses timing even at $MHZ MHz"; ok=0; }
    else
        awk -v v="$wns" 'BEGIN{exit !(v+0 >= 0)}' || { echo "FAIL: clock $name misses timing ($wns ns)"; ok=0; }
    fi
done < <(awk '/Intra Clock Table/{f=1; next} f && /Inter Clock Table/{exit} f && NF >= 3 && $2 ~ /^-?[0-9]+\.[0-9]+$/ {print $1, $2}' "$R")
if [ $ok = 1 ]; then
    if [ "$MHZ" = "$WANT_MHZ" ]; then echo "PASS: timing closed at $WANT_MHZ MHz"
    else echo "PASS (scaled): timing met at $MHZ MHz; v++ lowered the kernel clock from $WANT_MHZ. Use LAT_MHZ=$MHZ."; fi
else exit 1; fi
