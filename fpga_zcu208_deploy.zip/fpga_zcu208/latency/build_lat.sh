#!/bin/bash
# build_lat.sh -- hbm_lat_kernel.v -> hbm_lat_kernel.xo -> lat_<target>.xclbin -> host_lat
#   bash build_lat.sh                      chain in HBM[8] (lat_hbm.cfg)
#   CFG=lat_host.cfg OUT=lat_host bash build_lat.sh   chain in host memory (needs host memory enabled)
set -euo pipefail
cd "$(dirname "$0")"
PLATFORM=${PLATFORM:-xilinx_u55c_gen3x16_xdma_3_202210_1}
TARGET=${TARGET:-hw}
CFG=${CFG:-lat_hbm.cfg}
OUT=${OUT:-lat_$TARGET}
vivado -mode batch -nojournal -nolog -source package_lat.tcl -tclargs . hbm_lat_kernel.xo
v++ -l -t $TARGET --platform $PLATFORM --kernel_frequency 300 --config $CFG --save-temps -o $OUT.xclbin hbm_lat_kernel.xo
g++ -std=c++17 -O2 host_lat.cpp -I$XILINX_XRT/include -L$XILINX_XRT/lib -lxrt_coreutil -pthread -o host_lat
if [ "$TARGET" = hw ]; then XCLBIN=$OUT.xclbin ./check_timing.sh || echo "*** TIMING NOT CLOSED: do not use $OUT.xclbin for measurements ***"; fi
