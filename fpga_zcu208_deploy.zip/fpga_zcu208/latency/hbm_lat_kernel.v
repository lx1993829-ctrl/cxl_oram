// hbm_lat_kernel.v -- memory latency benchmark for the U55C (Vitis RTL kernel, ap_ctrl_hs).
//
// Measures, in kernel clock cycles, the latency DOMA's design depends on:
//   mode 0  dependent 32-byte reads: read buf + idx*32; the next idx is bits [31:0] of the data,
//           so no two reads overlap (a position-map lookup).
//   mode 1  write acknowledgements: as mode 0, then the line just read is written back unchanged
//           (the chain stays intact); each sample is the write, from AW issue to its B response.
//   mode 2  dependent 4 KB bursts: read buf + idx*4096 (128 beats), timed to the LAST beat
//           (a bucket read); the next idx comes from the first beat.
//   mode 0 with beats = B: dependent reads of B beats (32 B .. 32 KB); above 128 beats issued as
//           back-to-back 4 KB bursts (as a bucket read is), timed to the last beat of the last burst.
//   mode 3  independent reads: up to `outst` (1..64) requests in flight, each `beats` (1..128, a power
//           of two) at a random block of the buffer (span blocks, a power of two). Each sample runs from
//           the AR handshake to the request's last beat; total cycles give the bandwidth.
//   mode 4  independent writes: as mode 3, writes of a pattern; each sample runs from the AW handshake
//           to the B response (outst = 1: the unloaded write acknowledgement of a burst).
//           Modes 3 and 4 (and 5) accept any beats up to 128 (e.g. 24 = 768 B): blocks are the next power of two,
//           so no burst crosses 4 KB.
//   mode 5  read after write: write `wbeats` (up to 1024 = 32 KB, as 4 KB bursts) and wait for every B, wait `gap`
//           cycles, then read `beats` (timed like mode 0: ARVALID to the last beat). mode bit 16 = same address
//           (read the block just written); else DOMA's pattern (write back the block just read, read a new random
//           block). wbeats = 0: the baseline (no write).
// A read sample runs from asserting arvalid to rvalid (last beat for mode 2); a write sample from
// asserting awvalid/wvalid to bvalid. The host builds the chain (one random cycle over all lines).
//
// mode[2:0] = mode; mode[11:8] = histogram bin shift: 128 bins of 2^shift cycles, bin 127 also
// collects everything longer.
// Results (res, 17 beats of 256 bits):
//   beat 0: [31:0] magic 0x1A7E0001 | [63:32] min | [95:64] max | [127:96] count |
//           [191:128] sum of latencies | [255:192] total cycles of the run
//   beats 1..16: histogram, bin k at beat 1 + k/8, bits 32*(k%8) +: 32
// Control registers: 0x00 CTRL, 0x04 GIE, 0x08 IER, 0x0C ISR, 0x10 buf, 0x1C res, 0x28 n, 0x30 mode,
//                    0x38 beats, 0x40 outst, 0x48 span, 0x50 seed, 0x58 wbeats, 0x60 gap (0 = defaults: modes 0-2 unchanged).
`timescale 1ns/1ps
module hbm_lat_kernel #(
    parameter integer C_S_AXI_CONTROL_ADDR_WIDTH = 12,
    parameter integer C_M_AXI_ADDR_WIDTH         = 64,
    parameter integer C_M_AXI_DATA_WIDTH         = 256
) (
    input  wire                                    ap_clk,
    input  wire                                    ap_rst_n,
    input  wire [C_S_AXI_CONTROL_ADDR_WIDTH-1:0]   s_axi_control_awaddr,
    input  wire                                    s_axi_control_awvalid,
    output wire                                    s_axi_control_awready,
    input  wire [31:0]                             s_axi_control_wdata,
    input  wire [3:0]                              s_axi_control_wstrb,
    input  wire                                    s_axi_control_wvalid,
    output wire                                    s_axi_control_wready,
    output wire [1:0]                              s_axi_control_bresp,
    output reg                                     s_axi_control_bvalid,
    input  wire                                    s_axi_control_bready,
    input  wire [C_S_AXI_CONTROL_ADDR_WIDTH-1:0]   s_axi_control_araddr,
    input  wire                                    s_axi_control_arvalid,
    output wire                                    s_axi_control_arready,
    output reg  [31:0]                             s_axi_control_rdata,
    output wire [1:0]                              s_axi_control_rresp,
    output reg                                     s_axi_control_rvalid,
    input  wire                                    s_axi_control_rready,
    output wire                                    interrupt,
    // gmem0: the memory under test
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem0_araddr,
    output wire [7:0]                              m_axi_gmem0_arlen,
    output wire [2:0]                              m_axi_gmem0_arsize,
    output wire [1:0]                              m_axi_gmem0_arburst,
    output reg                                     m_axi_gmem0_arvalid,
    input  wire                                    m_axi_gmem0_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem0_rdata,
    input  wire [1:0]                              m_axi_gmem0_rresp,
    input  wire                                    m_axi_gmem0_rlast,
    input  wire                                    m_axi_gmem0_rvalid,
    output wire                                    m_axi_gmem0_rready,
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem0_awaddr,
    output wire [7:0]                              m_axi_gmem0_awlen,
    output wire [2:0]                              m_axi_gmem0_awsize,
    output wire [1:0]                              m_axi_gmem0_awburst,
    output reg                                     m_axi_gmem0_awvalid,
    input  wire                                    m_axi_gmem0_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem0_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem0_wstrb,
    output wire                                    m_axi_gmem0_wlast,
    output reg                                     m_axi_gmem0_wvalid,
    input  wire                                    m_axi_gmem0_wready,
    input  wire [1:0]                              m_axi_gmem0_bresp,
    input  wire                                    m_axi_gmem0_bvalid,
    output wire                                    m_axi_gmem0_bready,
    // gmem1: results (write only)
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem1_araddr,
    output wire [7:0]                              m_axi_gmem1_arlen,
    output wire [2:0]                              m_axi_gmem1_arsize,
    output wire [1:0]                              m_axi_gmem1_arburst,
    output wire                                    m_axi_gmem1_arvalid,
    input  wire                                    m_axi_gmem1_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem1_rdata,
    input  wire [1:0]                              m_axi_gmem1_rresp,
    input  wire                                    m_axi_gmem1_rlast,
    input  wire                                    m_axi_gmem1_rvalid,
    output wire                                    m_axi_gmem1_rready,
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem1_awaddr,
    output wire [7:0]                              m_axi_gmem1_awlen,
    output wire [2:0]                              m_axi_gmem1_awsize,
    output wire [1:0]                              m_axi_gmem1_awburst,
    output reg                                     m_axi_gmem1_awvalid,
    input  wire                                    m_axi_gmem1_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem1_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem1_wstrb,
    output wire                                    m_axi_gmem1_wlast,
    output reg                                     m_axi_gmem1_wvalid,
    input  wire                                    m_axi_gmem1_wready,
    input  wire [1:0]                              m_axi_gmem1_bresp,
    input  wire                                    m_axi_gmem1_bvalid,
    output wire                                    m_axi_gmem1_bready
);
    localparam integer DW = C_M_AXI_DATA_WIDTH;
    wire rst = !ap_rst_n;

    // =====================================================================
    // AXI4-Lite control registers (as doma_kernel)
    // =====================================================================
    reg        ap_start_r, ap_done_r, ap_ready_r, auto_restart_r, gie_r;
    reg  [1:0] ier_r, isr_r;
    reg [63:0] arg_buf, arg_res;
    reg [31:0] arg_n, arg_mode, arg_beats, arg_outst, arg_span, arg_seed, arg_wbeats, arg_gap;
    wire       ap_idle;
    reg        done_pulse;

    wire wr_hs = s_axi_control_awvalid && s_axi_control_wvalid && !s_axi_control_bvalid;
    assign s_axi_control_awready = wr_hs;
    assign s_axi_control_wready  = wr_hs;
    assign s_axi_control_bresp   = 2'b00;
    assign s_axi_control_arready = !s_axi_control_rvalid;
    assign s_axi_control_rresp   = 2'b00;
    wire [7:0] wa = s_axi_control_awaddr[7:0];
    wire [7:0] ra = s_axi_control_araddr[7:0];
    function [31:0] wmask; input [31:0] oldv, newv; input [3:0] strb; integer b;
        begin wmask = oldv; for (b = 0; b < 4; b = b + 1) if (strb[b]) wmask[b*8 +: 8] = newv[b*8 +: 8]; end
    endfunction

    always @(posedge ap_clk) begin
        if (rst) begin
            ap_start_r <= 1'b0; ap_done_r <= 1'b0; ap_ready_r <= 1'b0; auto_restart_r <= 1'b0;
            gie_r <= 1'b0; ier_r <= 2'b00; isr_r <= 2'b00;
            arg_buf <= 64'd0; arg_res <= 64'd0; arg_n <= 32'd0; arg_mode <= 32'd0;
            arg_beats <= 32'd0; arg_outst <= 32'd0; arg_span <= 32'd0; arg_seed <= 32'd0; arg_wbeats <= 32'd0; arg_gap <= 32'd0;
            s_axi_control_bvalid <= 1'b0; s_axi_control_rvalid <= 1'b0; s_axi_control_rdata <= 32'd0;
        end else begin
            if (wr_hs) begin
                s_axi_control_bvalid <= 1'b1;
                case (wa)
                    8'h00: begin
                        if (s_axi_control_wstrb[0] && s_axi_control_wdata[0]) ap_start_r <= 1'b1;
                        if (s_axi_control_wstrb[0]) auto_restart_r <= s_axi_control_wdata[7];
                    end
                    8'h04: if (s_axi_control_wstrb[0]) gie_r <= s_axi_control_wdata[0];
                    8'h08: if (s_axi_control_wstrb[0]) ier_r <= s_axi_control_wdata[1:0];
                    8'h0C: if (s_axi_control_wstrb[0]) isr_r <= isr_r ^ s_axi_control_wdata[1:0];
                    8'h10: arg_buf[31:0]  <= wmask(arg_buf[31:0],  s_axi_control_wdata, s_axi_control_wstrb);
                    8'h14: arg_buf[63:32] <= wmask(arg_buf[63:32], s_axi_control_wdata, s_axi_control_wstrb);
                    8'h1C: arg_res[31:0]  <= wmask(arg_res[31:0],  s_axi_control_wdata, s_axi_control_wstrb);
                    8'h20: arg_res[63:32] <= wmask(arg_res[63:32], s_axi_control_wdata, s_axi_control_wstrb);
                    8'h28: arg_n          <= wmask(arg_n,          s_axi_control_wdata, s_axi_control_wstrb);
                    8'h30: arg_mode       <= wmask(arg_mode,       s_axi_control_wdata, s_axi_control_wstrb);
                    8'h38: arg_beats      <= wmask(arg_beats,      s_axi_control_wdata, s_axi_control_wstrb);
                    8'h40: arg_outst      <= wmask(arg_outst,      s_axi_control_wdata, s_axi_control_wstrb);
                    8'h48: arg_span       <= wmask(arg_span,       s_axi_control_wdata, s_axi_control_wstrb);
                    8'h50: arg_seed       <= wmask(arg_seed,       s_axi_control_wdata, s_axi_control_wstrb);
                    8'h58: arg_wbeats     <= wmask(arg_wbeats,     s_axi_control_wdata, s_axi_control_wstrb);
                    8'h60: arg_gap        <= wmask(arg_gap,        s_axi_control_wdata, s_axi_control_wstrb);
                    default: ;
                endcase
            end
            if (s_axi_control_bvalid && s_axi_control_bready) s_axi_control_bvalid <= 1'b0;
            if (s_axi_control_arvalid && !s_axi_control_rvalid) begin
                s_axi_control_rvalid <= 1'b1;
                case (ra)
                    8'h00: begin
                        s_axi_control_rdata <= {24'd0, auto_restart_r, 3'd0, ap_ready_r, ap_idle, ap_done_r, ap_start_r};
                        ap_done_r <= 1'b0; ap_ready_r <= 1'b0;
                    end
                    8'h04: s_axi_control_rdata <= {31'd0, gie_r};
                    8'h08: s_axi_control_rdata <= {30'd0, ier_r};
                    8'h0C: s_axi_control_rdata <= {30'd0, isr_r};
                    8'h10: s_axi_control_rdata <= arg_buf[31:0];
                    8'h14: s_axi_control_rdata <= arg_buf[63:32];
                    8'h1C: s_axi_control_rdata <= arg_res[31:0];
                    8'h20: s_axi_control_rdata <= arg_res[63:32];
                    8'h28: s_axi_control_rdata <= arg_n;
                    8'h30: s_axi_control_rdata <= arg_mode;
                    8'h38: s_axi_control_rdata <= arg_beats;
                    8'h40: s_axi_control_rdata <= arg_outst;
                    8'h48: s_axi_control_rdata <= arg_span;
                    8'h50: s_axi_control_rdata <= arg_seed;
                    8'h58: s_axi_control_rdata <= arg_wbeats;
                    8'h60: s_axi_control_rdata <= arg_gap;
                    default: s_axi_control_rdata <= 32'd0;
                endcase
            end
            if (s_axi_control_rvalid && s_axi_control_rready) s_axi_control_rvalid <= 1'b0;
            if (done_pulse) begin
                ap_done_r  <= 1'b1;
                ap_ready_r <= 1'b1;
                ap_start_r <= auto_restart_r;
                if (ier_r[0]) isr_r[0] <= 1'b1;
            end
        end
    end
    assign interrupt = gie_r && |(isr_r & ier_r);

    // =====================================================================
    // Measurement engine
    // =====================================================================
    localparam [3:0] S_IDLE = 4'd0, S_CLR = 4'd1, S_RUN = 4'd2, S_RWAIT = 4'd3, S_WISSUE = 4'd4,
                     S_WWAIT = 4'd5, S_RES_AW = 4'd6, S_RES_W = 4'd7, S_RES_B = 4'd8, S_IND = 4'd9,
                     S_R5 = 4'd10, S_R5W = 4'd11, S_R5G = 4'd12;
    localparam integer MAXO = 64;                          // independent modes: requests in flight
    reg  [3:0]    st;
    reg  [63:0]   buf_q, res_q, cyc, t0, t_start, lsum, total;
    reg  [31:0]   n_q, mode_q, i, idx, nidx, lmin, lmax, cnt;
    reg  [DW-1:0] line_q;
    reg           first;
    reg  [6:0]    hclr;
    reg  [4:0]    rbeat;
    reg  [31:0]   hist [0:127];
    wire [2:0]    md  = mode_q[2:0];
    wire [3:0]    hsh = mode_q[11:8];
    reg  [10:0]   beats_q;                                 // beats per access (S / 32)
    reg  [3:0]    nb_q, nb_iss, nb_done;                   // dependent reads: 4 KB bursts per access
    reg  [6:0]    outst_q;
    reg  [31:0]   span_mask, rng;
    reg  [4:0]    sshift;                                  // independent modes: log2(S bytes)
    reg  [63:0]   ar_addr, aw_addr;
    reg  [7:0]    ar_len, wbeat;
    reg  [31:0]   issued, completed;
    reg  [31:0]   ts [0:MAXO-1];
    reg  [5:0]    ts_wp, ts_rp;
    reg  [7:0]    w_pend;
    // mode 5 (read after write)
    reg  [10:0]   wbeats_q, w_sent;
    reg  [3:0]    wnb_q, w_aw_iss, w_b_cnt;
    reg  [31:0]   gap_q, gap_cnt;
    reg  [63:0]   r5_p, r5_a;                              // the last block read; the block written (same mode)
    wire          same5    = mode_q[16];
    wire [7:0]    r5_awlen = (wbeats_q > 11'd128) ? 8'd127 : wbeats_q[7:0] - 8'd1;

    // recording pipeline: the latency travels with its sample (samples may arrive every cycle)
    reg           rec_v, rec_v2;
    reg  [31:0]   rec_lat, rec_lat2;
    reg  [6:0]    rec_bin;
    wire [31:0]   rec_shift = rec_lat >> hsh;
    always @(posedge ap_clk) begin
        if (rst) begin rec_v2 <= 1'b0; rec_bin <= 7'd0; rec_lat2 <= 32'd0; end
        else begin
            rec_v2 <= rec_v; rec_lat2 <= rec_lat;
            if (rec_v) rec_bin <= (rec_shift > 32'd127) ? 7'd127 : rec_shift[6:0];
            if (rec_v2) hist[rec_bin] <= hist[rec_bin] + 32'd1;
            if (st == S_CLR) hist[hclr] <= 32'd0;
        end
    end

    assign ap_idle = (st == S_IDLE);
    always @(posedge ap_clk) cyc <= rst ? 64'd0 : cyc + 64'd1;

    function [31:0] xs32; input [31:0] x; reg [31:0] a; begin
        a = x ^ (x << 13); a = a ^ (a >> 17); xs32 = a ^ (a << 5); end endfunction
    wire [63:0] rnd_addr  = buf_q + ({32'd0, rng & span_mask} << sshift);
    wire [63:0] rnd_addr1 = buf_q + ({32'd0, xs32(rng) & span_mask} << sshift);
    wire [63:0] dep_addr  = buf_q + {32'd0, idx} * {53'd0, beats_q, 5'd0};
    wire        ind   = (md == 3'd3) || (md == 3'd4);

    // gmem0
    assign m_axi_gmem0_araddr  = ar_addr;
    assign m_axi_gmem0_arlen   = ar_len;
    assign m_axi_gmem0_arsize  = 3'b101;            // 32 bytes per beat
    assign m_axi_gmem0_arburst = 2'b01;
    assign m_axi_gmem0_rready  = 1'b1;
    assign m_axi_gmem0_awaddr  = aw_addr;
    assign m_axi_gmem0_awlen   = (md == 3'd4) ? beats_q[7:0] - 8'd1 : (md == 3'd5) ? r5_awlen : 8'd0;
    assign m_axi_gmem0_awsize  = 3'b101;
    assign m_axi_gmem0_awburst = 2'b01;
    assign m_axi_gmem0_wdata   = (md == 3'd4 || md == 3'd5) ? {(DW/32){24'hC0DE00, wbeat}} : line_q;   // mode 1: the line read
    assign m_axi_gmem0_wstrb   = {(DW/8){1'b1}};
    assign m_axi_gmem0_wlast   = (md == 3'd4) ? (wbeat == beats_q[7:0] - 8'd1) : (md == 3'd5) ? (wbeat == r5_awlen) : 1'b1;
    assign m_axi_gmem0_bready  = 1'b1;
    // gmem1: results
    assign m_axi_gmem1_araddr  = 64'd0;
    assign m_axi_gmem1_arlen   = 8'd0;
    assign m_axi_gmem1_arsize  = 3'b101;
    assign m_axi_gmem1_arburst = 2'b01;
    assign m_axi_gmem1_arvalid = 1'b0;
    assign m_axi_gmem1_rready  = 1'b1;
    assign m_axi_gmem1_awaddr  = res_q;
    assign m_axi_gmem1_awlen   = 8'd16;             // 17 beats
    assign m_axi_gmem1_awsize  = 3'b101;
    assign m_axi_gmem1_awburst = 2'b01;
    assign m_axi_gmem1_wstrb   = {(DW/8){1'b1}};
    assign m_axi_gmem1_wlast   = (rbeat == 5'd16);
    assign m_axi_gmem1_bready  = 1'b1;
    wire [6:0] hb = {rbeat[3:0] - 4'd1, 3'b000};     // first bin of histogram beat rbeat (1..16)
    assign m_axi_gmem1_wdata = (rbeat == 5'd0) ? {total, lsum, cnt, lmax, lmin, 32'h1A7E0001} :
        {hist[hb + 7], hist[hb + 6], hist[hb + 5], hist[hb + 4], hist[hb + 3], hist[hb + 2], hist[hb + 1], hist[hb]};

    function [4:0] log2b; input [10:0] b; integer q; begin log2b = 0; for (q = 0; q < 11; q = q + 1) if (b[q]) log2b = q[4:0]; end endfunction
    function [4:0] clog2b; input [10:0] b; begin clog2b = log2b(b) + (((11'd1 << log2b(b)) != b) ? 5'd1 : 5'd0); end endfunction

    always @(posedge ap_clk) begin
        if (rst) begin
            st <= S_IDLE; done_pulse <= 1'b0; rec_v <= 1'b0; rec_lat <= 32'd0;
            m_axi_gmem0_arvalid <= 1'b0; m_axi_gmem0_awvalid <= 1'b0; m_axi_gmem0_wvalid <= 1'b0;
            m_axi_gmem1_awvalid <= 1'b0; m_axi_gmem1_wvalid <= 1'b0;
            buf_q <= 64'd0; res_q <= 64'd0; n_q <= 32'd0; mode_q <= 32'd0; i <= 32'd0; idx <= 32'd0; nidx <= 32'd0;
            t0 <= 64'd0; t_start <= 64'd0; lsum <= 64'd0; total <= 64'd0; lmin <= 32'hFFFFFFFF; lmax <= 32'd0; cnt <= 32'd0;
            line_q <= {DW{1'b0}}; first <= 1'b0; hclr <= 7'd0; rbeat <= 5'd0;
            beats_q <= 11'd1; nb_q <= 4'd1; nb_iss <= 4'd0; nb_done <= 4'd0; outst_q <= 7'd1; span_mask <= 32'd0;
            rng <= 32'h9E3779B9; sshift <= 5'd5; ar_addr <= 64'd0; aw_addr <= 64'd0; ar_len <= 8'd0; wbeat <= 8'd0;
            issued <= 32'd0; completed <= 32'd0; ts_wp <= 6'd0; ts_rp <= 6'd0; w_pend <= 8'd0;
        end else begin
            done_pulse <= 1'b0;
            rec_v      <= 1'b0;
            if (rec_v2) begin                                   // statistics, from the latency that came with the sample
                if (rec_lat2 < lmin) lmin <= rec_lat2;
                if (rec_lat2 > lmax) lmax <= rec_lat2;
                lsum <= lsum + {32'd0, rec_lat2};
                cnt  <= cnt + 32'd1;
            end
            case (st)
                S_IDLE: if (ap_start_r && !done_pulse) begin      // not in the cycle the last run's done lands
                    begin : setup
                        reg [10:0] b, w; reg shortok;
                        b = (arg_mode[2:0] == 3'd1) ? 11'd1 :
                            (arg_beats == 32'd0) ? ((arg_mode[2:0] == 3'd2) ? 11'd128 : 11'd1) :
                            (arg_beats > 32'd1024) ? 11'd1024 : arg_beats[10:0];
                        shortok = (arg_mode[2:0] == 3'd3 || arg_mode[2:0] == 3'd4 || arg_mode[2:0] == 3'd5);
                        if ((arg_mode[2:0] == 3'd3 || arg_mode[2:0] == 3'd4) && b > 11'd128) b = 11'd128;
                        // a power of two, except bursts up to 128 beats in modes 3-5, which go in blocks of the next
                        // power of two: either way no burst crosses 4 KB
                        if (!shortok || b > 11'd128) b = 11'd1 << log2b(b);
                        w = (arg_mode[2:0] != 3'd5) ? 11'd0 : (arg_wbeats > 32'd1024) ? 11'd1024 : arg_wbeats[10:0];
                        if (w > 11'd128) w = 11'd1 << log2b(w);
                        beats_q <= b; wbeats_q <= w;
                        nb_q    <= (b + 11'd127) >> 7;
                        wnb_q   <= (w + 11'd127) >> 7;
                        sshift  <= clog2b((w > b) ? w : b) + 5'd5;
                        gap_q   <= arg_gap;
                        outst_q <= (arg_outst == 32'd0) ? 7'd1 : (arg_outst > MAXO) ? MAXO[6:0] : arg_outst[6:0];
                        span_mask <= (arg_span == 32'd0) ? 32'd0 : arg_span - 32'd1;
                        rng     <= (arg_seed == 32'd0) ? 32'h9E3779B9 : arg_seed;
                    end
                    buf_q <= arg_buf; res_q <= arg_res; n_q <= arg_n; mode_q <= arg_mode;
                    i <= 32'd0; idx <= 32'd0; lmin <= 32'hFFFFFFFF; lmax <= 32'd0; lsum <= 64'd0; cnt <= 32'd0;
                    hclr <= 7'd0; t_start <= cyc; st <= S_CLR;
                end
                S_CLR: begin
                    hclr <= hclr + 7'd1;
                    if (hclr == 7'd127) begin
                        st <= ind ? S_IND : (md == 3'd5) ? S_R5 : S_RUN;
                        r5_p <= rnd_addr1;                      // DOMA pattern: the first write-back target
                        issued <= 32'd0; completed <= 32'd0; ts_wp <= 6'd0; ts_rp <= 6'd0; w_pend <= 8'd0; wbeat <= 8'd0;
                        ar_addr <= rnd_addr; aw_addr <= rnd_addr; ar_len <= beats_q[7:0] - 8'd1;
                    end
                end
                // ---------------- dependent accesses (modes 0, 1, 2) ----------------
                S_RUN: begin
                    if (i == n_q) st <= S_RES_AW;
                    else begin
                        ar_addr <= dep_addr; aw_addr <= dep_addr;
                        ar_len  <= (beats_q > 11'd128) ? 8'd127 : beats_q[7:0] - 8'd1;
                        nb_iss <= 4'd0; nb_done <= 4'd0;
                        m_axi_gmem0_arvalid <= 1'b1; t0 <= cyc; first <= 1'b1; st <= S_RWAIT;
                    end
                end
                S_RWAIT: begin
                    if (m_axi_gmem0_arvalid && m_axi_gmem0_arready) begin
                        if (nb_iss + 4'd1 == nb_q) m_axi_gmem0_arvalid <= 1'b0;
                        else begin                                  // the next 4 KB burst of this access
                            ar_addr <= ar_addr + 64'd4096;
                            begin : nxt
                                reg [10:0] rem;                 // beats left after the bursts issued so far
                                rem = beats_q - {nb_iss + 4'd1, 7'd0};
                                ar_len <= (rem >= 11'd128) ? 8'd127 : rem[7:0] - 8'd1;
                            end
                        end
                        nb_iss <= nb_iss + 4'd1;
                    end
                    if (m_axi_gmem0_rvalid) begin
                        if (first) begin nidx <= m_axi_gmem0_rdata[31:0]; line_q <= m_axi_gmem0_rdata; first <= 1'b0; end
                        if (m_axi_gmem0_rlast) begin
                            nb_done <= nb_done + 4'd1;
                            if (nb_done + 4'd1 == nb_q) begin
                                if (md != 3'd1) begin rec_v <= 1'b1; rec_lat <= cyc[31:0] - t0[31:0]; end
                                if (md == 3'd1) st <= S_WISSUE;
                                else begin
                                    idx <= first ? m_axi_gmem0_rdata[31:0] : nidx;
                                    i <= i + 32'd1; st <= (md == 3'd5) ? S_R5 : S_RUN;
                                end
                            end
                        end
                    end
                end
                S_WISSUE: begin
                    m_axi_gmem0_awvalid <= 1'b1; m_axi_gmem0_wvalid <= 1'b1; t0 <= cyc; st <= S_WWAIT;
                end
                S_WWAIT: begin
                    if (m_axi_gmem0_awvalid && m_axi_gmem0_awready) m_axi_gmem0_awvalid <= 1'b0;
                    if (m_axi_gmem0_wvalid && m_axi_gmem0_wready)   m_axi_gmem0_wvalid  <= 1'b0;
                    if (m_axi_gmem0_bvalid) begin
                        rec_v <= 1'b1; rec_lat <= cyc[31:0] - t0[31:0];
                        idx <= nidx; i <= i + 32'd1; st <= S_RUN;
                    end
                end
                // ---------------- independent accesses (modes 3, 4) ----------------
                S_IND: begin : indep
                    reg hs, done1, wl;
                    reg [31:0] iss_n, cmp_n;
                    hs    = (md == 3'd3) ? (m_axi_gmem0_arvalid && m_axi_gmem0_arready)
                                         : (m_axi_gmem0_awvalid && m_axi_gmem0_awready);
                    done1 = (md == 3'd3) ? (m_axi_gmem0_rvalid && m_axi_gmem0_rlast) : m_axi_gmem0_bvalid;
                    wl    = m_axi_gmem0_wvalid && m_axi_gmem0_wready && m_axi_gmem0_wlast;
                    iss_n = issued + (hs ? 32'd1 : 32'd0);
                    cmp_n = completed + (done1 ? 32'd1 : 32'd0);
                    issued <= iss_n; completed <= cmp_n;
                    if (hs) begin ts[ts_wp] <= cyc[31:0]; ts_wp <= ts_wp + 6'd1; rng <= xs32(rng); end
                    if (done1) begin rec_v <= 1'b1; rec_lat <= cyc[31:0] - ts[ts_rp]; ts_rp <= ts_rp + 6'd1; end
                    // a request is on the bus while more remain and the window allows (never withdrawn unaccepted)
                    if (md == 3'd3) begin
                        m_axi_gmem0_arvalid <= (iss_n < n_q) && (iss_n - cmp_n < {25'd0, outst_q});
                        if (hs) ar_addr <= rnd_addr1;
                    end else begin
                        m_axi_gmem0_awvalid <= (iss_n < n_q) && (iss_n - cmp_n < {25'd0, outst_q});
                        if (hs) aw_addr <= rnd_addr1;
                        begin : wch
                            reg [7:0] wp_n;
                            wp_n = w_pend + (hs ? 8'd1 : 8'd0) - (wl ? 8'd1 : 8'd0);
                            w_pend <= wp_n;
                            m_axi_gmem0_wvalid <= (wp_n != 8'd0);
                            if (m_axi_gmem0_wvalid && m_axi_gmem0_wready) wbeat <= wl ? 8'd0 : wbeat + 8'd1;
                        end
                    end
                    if (cmp_n == n_q) begin
                        m_axi_gmem0_arvalid <= 1'b0; m_axi_gmem0_awvalid <= 1'b0; m_axi_gmem0_wvalid <= 1'b0;
                        st <= S_RES_AW;
                    end
                end
                // ---------------- read after write (mode 5) ----------------
                S_R5: begin
                    if (i == n_q) st <= S_RES_AW;
                    else if (wbeats_q == 11'd0) begin gap_cnt <= gap_q; st <= S_R5G; end     // baseline: no write
                    else begin
                        if (same5) begin aw_addr <= rnd_addr; r5_a <= rnd_addr; rng <= xs32(rng); end
                        else aw_addr <= r5_p;                    // write back the block just read
                        w_aw_iss <= 4'd0; w_b_cnt <= 4'd0; w_sent <= 11'd0; wbeat <= 8'd0;
                        m_axi_gmem0_awvalid <= 1'b1; m_axi_gmem0_wvalid <= 1'b1; st <= S_R5W;
                    end
                end
                S_R5W: begin                                     // the write: 4 KB bursts back to back, every B awaited
                    if (m_axi_gmem0_awvalid && m_axi_gmem0_awready) begin
                        if (w_aw_iss + 4'd1 == wnb_q) m_axi_gmem0_awvalid <= 1'b0;
                        else aw_addr <= aw_addr + 64'd4096;
                        w_aw_iss <= w_aw_iss + 4'd1;
                    end
                    if (m_axi_gmem0_wvalid && m_axi_gmem0_wready) begin
                        wbeat <= m_axi_gmem0_wlast ? 8'd0 : wbeat + 8'd1;
                        if (w_sent + 11'd1 == wbeats_q) m_axi_gmem0_wvalid <= 1'b0;
                        w_sent <= w_sent + 11'd1;
                    end
                    if (m_axi_gmem0_bvalid) begin
                        w_b_cnt <= w_b_cnt + 4'd1;
                        if (w_b_cnt + 4'd1 == wnb_q) begin gap_cnt <= gap_q; st <= S_R5G; end
                    end
                end
                S_R5G: begin                                     // the gap, then the timed read
                    if (gap_cnt != 32'd0) gap_cnt <= gap_cnt - 32'd1;
                    else begin : rd5
                        reg sameblk; reg [63:0] q;
                        sameblk = same5 && (wbeats_q != 11'd0);
                        q = sameblk ? r5_a : rnd_addr;
                        if (!sameblk) rng <= xs32(rng);
                        ar_addr <= q; r5_p <= q;
                        ar_len  <= (beats_q > 11'd128) ? 8'd127 : beats_q[7:0] - 8'd1;
                        nb_iss <= 4'd0; nb_done <= 4'd0;
                        m_axi_gmem0_arvalid <= 1'b1; t0 <= cyc; first <= 1'b1; st <= S_RWAIT;
                    end
                end
                S_RES_AW: begin
                    // the recording pipeline has drained: its last stage ran at least two cycles ago
                    if (!m_axi_gmem1_awvalid) begin m_axi_gmem1_awvalid <= 1'b1; total <= cyc - t_start; end
                    else if (m_axi_gmem1_awready) begin
                        m_axi_gmem1_awvalid <= 1'b0; rbeat <= 5'd0; m_axi_gmem1_wvalid <= 1'b1; st <= S_RES_W;
                    end
                end
                S_RES_W: if (m_axi_gmem1_wready) begin
                    if (rbeat == 5'd16) begin m_axi_gmem1_wvalid <= 1'b0; st <= S_RES_B; end
                    else rbeat <= rbeat + 5'd1;
                end
                S_RES_B: if (m_axi_gmem1_bvalid) begin done_pulse <= 1'b1; st <= S_IDLE; end
                default: st <= S_IDLE;
            endcase
        end
    end
endmodule
