// hbm_lat_kernel.v -- memory latency benchmark for the U55C (Vitis RTL kernel, ap_ctrl_hs).
//
// Measures, in kernel clock cycles, the latency DOMA's design depends on:
//   mode 0  dependent 32-byte reads: read buf + idx*32; the next idx is bits [31:0] of the data,
//           so no two reads overlap (a position-map lookup).
//   mode 1  write acknowledgements: as mode 0, then the line just read is written back unchanged
//           (the chain stays intact); each sample is the write, from AW issue to its B response.
//   mode 2  dependent 4 KB bursts: read buf + idx*4096 (128 beats), timed to the LAST beat
//           (a bucket read); the next idx comes from the first beat.
// A read sample runs from asserting arvalid to rvalid (last beat for mode 2); a write sample from
// asserting awvalid/wvalid to bvalid. The host builds the chain (one random cycle over all lines).
//
// mode[1:0] = mode; mode[11:8] = histogram bin shift: 128 bins of 2^shift cycles, bin 127 also
// collects everything longer.
// Results (res, 17 beats of 256 bits):
//   beat 0: [31:0] magic 0x1A7E0001 | [63:32] min | [95:64] max | [127:96] count |
//           [191:128] sum of latencies | [255:192] total cycles of the run
//   beats 1..16: histogram, bin k at beat 1 + k/8, bits 32*(k%8) +: 32
// Control registers: 0x00 CTRL, 0x04 GIE, 0x08 IER, 0x0C ISR, 0x10 buf, 0x1C res, 0x28 n, 0x30 mode.
`timescale 1ns/1ps
module hbm_lat_kernel #(
    parameter integer C_S_AXI_CONTROL_ADDR_WIDTH = 12,
    parameter integer C_M_AXI_ADDR_WIDTH         = 64,
    parameter integer C_M_AXI_DATA_WIDTH         = 256
) (
    input  wire                                    ap_clk,
    input  wire                                    ap_rst_n,
    input  wire [C_S_AXI_CONTROL_ADDR_WIDTH-1:0]   s_axi_control_awaddr,
    input  wire                                    s_axi_control_awvalid,
    output wire                                    s_axi_control_awready,
    input  wire [31:0]                             s_axi_control_wdata,
    input  wire [3:0]                              s_axi_control_wstrb,
    input  wire                                    s_axi_control_wvalid,
    output wire                                    s_axi_control_wready,
    output wire [1:0]                              s_axi_control_bresp,
    output reg                                     s_axi_control_bvalid,
    input  wire                                    s_axi_control_bready,
    input  wire [C_S_AXI_CONTROL_ADDR_WIDTH-1:0]   s_axi_control_araddr,
    input  wire                                    s_axi_control_arvalid,
    output wire                                    s_axi_control_arready,
    output reg  [31:0]                             s_axi_control_rdata,
    output wire [1:0]                              s_axi_control_rresp,
    output reg                                     s_axi_control_rvalid,
    input  wire                                    s_axi_control_rready,
    output wire                                    interrupt,
    // gmem0: the memory under test
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem0_araddr,
    output wire [7:0]                              m_axi_gmem0_arlen,
    output wire [2:0]                              m_axi_gmem0_arsize,
    output wire [1:0]                              m_axi_gmem0_arburst,
    output reg                                     m_axi_gmem0_arvalid,
    input  wire                                    m_axi_gmem0_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem0_rdata,
    input  wire [1:0]                              m_axi_gmem0_rresp,
    input  wire                                    m_axi_gmem0_rlast,
    input  wire                                    m_axi_gmem0_rvalid,
    output wire                                    m_axi_gmem0_rready,
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem0_awaddr,
    output wire [7:0]                              m_axi_gmem0_awlen,
    output wire [2:0]                              m_axi_gmem0_awsize,
    output wire [1:0]                              m_axi_gmem0_awburst,
    output reg                                     m_axi_gmem0_awvalid,
    input  wire                                    m_axi_gmem0_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem0_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem0_wstrb,
    output wire                                    m_axi_gmem0_wlast,
    output reg                                     m_axi_gmem0_wvalid,
    input  wire                                    m_axi_gmem0_wready,
    input  wire [1:0]                              m_axi_gmem0_bresp,
    input  wire                                    m_axi_gmem0_bvalid,
    output wire                                    m_axi_gmem0_bready,
    // gmem1: results (write only)
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem1_araddr,
    output wire [7:0]                              m_axi_gmem1_arlen,
    output wire [2:0]                              m_axi_gmem1_arsize,
    output wire [1:0]                              m_axi_gmem1_arburst,
    output wire                                    m_axi_gmem1_arvalid,
    input  wire                                    m_axi_gmem1_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem1_rdata,
    input  wire [1:0]                              m_axi_gmem1_rresp,
    input  wire                                    m_axi_gmem1_rlast,
    input  wire                                    m_axi_gmem1_rvalid,
    output wire                                    m_axi_gmem1_rready,
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem1_awaddr,
    output wire [7:0]                              m_axi_gmem1_awlen,
    output wire [2:0]                              m_axi_gmem1_awsize,
    output wire [1:0]                              m_axi_gmem1_awburst,
    output reg                                     m_axi_gmem1_awvalid,
    input  wire                                    m_axi_gmem1_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem1_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem1_wstrb,
    output wire                                    m_axi_gmem1_wlast,
    output reg                                     m_axi_gmem1_wvalid,
    input  wire                                    m_axi_gmem1_wready,
    input  wire [1:0]                              m_axi_gmem1_bresp,
    input  wire                                    m_axi_gmem1_bvalid,
    output wire                                    m_axi_gmem1_bready
);
    localparam integer DW = C_M_AXI_DATA_WIDTH;
    wire rst = !ap_rst_n;

    // =====================================================================
    // AXI4-Lite control registers (as doma_kernel)
    // =====================================================================
    reg        ap_start_r, ap_done_r, ap_ready_r, auto_restart_r, gie_r;
    reg  [1:0] ier_r, isr_r;
    reg [63:0] arg_buf, arg_res;
    reg [31:0] arg_n, arg_mode;
    wire       ap_idle;
    reg        done_pulse;

    wire wr_hs = s_axi_control_awvalid && s_axi_control_wvalid && !s_axi_control_bvalid;
    assign s_axi_control_awready = wr_hs;
    assign s_axi_control_wready  = wr_hs;
    assign s_axi_control_bresp   = 2'b00;
    assign s_axi_control_arready = !s_axi_control_rvalid;
    assign s_axi_control_rresp   = 2'b00;
    wire [7:0] wa = s_axi_control_awaddr[7:0];
    wire [7:0] ra = s_axi_control_araddr[7:0];
    function [31:0] wmask; input [31:0] oldv, newv; input [3:0] strb; integer b;
        begin wmask = oldv; for (b = 0; b < 4; b = b + 1) if (strb[b]) wmask[b*8 +: 8] = newv[b*8 +: 8]; end
    endfunction

    always @(posedge ap_clk) begin
        if (rst) begin
            ap_start_r <= 1'b0; ap_done_r <= 1'b0; ap_ready_r <= 1'b0; auto_restart_r <= 1'b0;
            gie_r <= 1'b0; ier_r <= 2'b00; isr_r <= 2'b00;
            arg_buf <= 64'd0; arg_res <= 64'd0; arg_n <= 32'd0; arg_mode <= 32'd0;
            s_axi_control_bvalid <= 1'b0; s_axi_control_rvalid <= 1'b0; s_axi_control_rdata <= 32'd0;
        end else begin
            if (wr_hs) begin
                s_axi_control_bvalid <= 1'b1;
                case (wa)
                    8'h00: begin
                        if (s_axi_control_wstrb[0] && s_axi_control_wdata[0]) ap_start_r <= 1'b1;
                        if (s_axi_control_wstrb[0]) auto_restart_r <= s_axi_control_wdata[7];
                    end
                    8'h04: if (s_axi_control_wstrb[0]) gie_r <= s_axi_control_wdata[0];
                    8'h08: if (s_axi_control_wstrb[0]) ier_r <= s_axi_control_wdata[1:0];
                    8'h0C: if (s_axi_control_wstrb[0]) isr_r <= isr_r ^ s_axi_control_wdata[1:0];
                    8'h10: arg_buf[31:0]  <= wmask(arg_buf[31:0],  s_axi_control_wdata, s_axi_control_wstrb);
                    8'h14: arg_buf[63:32] <= wmask(arg_buf[63:32], s_axi_control_wdata, s_axi_control_wstrb);
                    8'h1C: arg_res[31:0]  <= wmask(arg_res[31:0],  s_axi_control_wdata, s_axi_control_wstrb);
                    8'h20: arg_res[63:32] <= wmask(arg_res[63:32], s_axi_control_wdata, s_axi_control_wstrb);
                    8'h28: arg_n          <= wmask(arg_n,          s_axi_control_wdata, s_axi_control_wstrb);
                    8'h30: arg_mode       <= wmask(arg_mode,       s_axi_control_wdata, s_axi_control_wstrb);
                    default: ;
                endcase
            end
            if (s_axi_control_bvalid && s_axi_control_bready) s_axi_control_bvalid <= 1'b0;
            if (s_axi_control_arvalid && !s_axi_control_rvalid) begin
                s_axi_control_rvalid <= 1'b1;
                case (ra)
                    8'h00: begin
                        s_axi_control_rdata <= {24'd0, auto_restart_r, 3'd0, ap_ready_r, ap_idle, ap_done_r, ap_start_r};
                        ap_done_r <= 1'b0; ap_ready_r <= 1'b0;
                    end
                    8'h04: s_axi_control_rdata <= {31'd0, gie_r};
                    8'h08: s_axi_control_rdata <= {30'd0, ier_r};
                    8'h0C: s_axi_control_rdata <= {30'd0, isr_r};
                    8'h10: s_axi_control_rdata <= arg_buf[31:0];
                    8'h14: s_axi_control_rdata <= arg_buf[63:32];
                    8'h1C: s_axi_control_rdata <= arg_res[31:0];
                    8'h20: s_axi_control_rdata <= arg_res[63:32];
                    8'h28: s_axi_control_rdata <= arg_n;
                    8'h30: s_axi_control_rdata <= arg_mode;
                    default: s_axi_control_rdata <= 32'd0;
                endcase
            end
            if (s_axi_control_rvalid && s_axi_control_rready) s_axi_control_rvalid <= 1'b0;
            if (done_pulse) begin
                ap_done_r  <= 1'b1;
                ap_ready_r <= 1'b1;
                ap_start_r <= auto_restart_r;
                if (ier_r[0]) isr_r[0] <= 1'b1;
            end
        end
    end
    assign interrupt = gie_r && |(isr_r & ier_r);

    // =====================================================================
    // Measurement engine
    // =====================================================================
    localparam [3:0] S_IDLE = 4'd0, S_CLR = 4'd1, S_RUN = 4'd2, S_RWAIT = 4'd3, S_WISSUE = 4'd4,
                     S_WWAIT = 4'd5, S_RES_AW = 4'd6, S_RES_W = 4'd7, S_RES_B = 4'd8;
    reg  [3:0]    st;
    reg  [63:0]   buf_q, res_q, cyc, t0, t_start, lsum, total;
    reg  [31:0]   n_q, mode_q, i, idx, nidx, lmin, lmax, cnt;
    reg  [DW-1:0] line_q;
    reg           first;
    reg  [6:0]    hclr;
    reg  [4:0]    rbeat;
    reg  [31:0]   hist [0:127];
    wire [1:0]    md  = mode_q[1:0];
    wire [3:0]    hsh = mode_q[11:8];

    // recording pipeline: latch the sample, then min/max/sum and its bin, then the bin's count
    reg           rec_v, rec_v2;
    reg  [31:0]   rec_lat;
    reg  [6:0]    rec_bin;
    wire [31:0]   rec_shift = rec_lat >> hsh;
    always @(posedge ap_clk) begin
        if (rst) begin rec_v2 <= 1'b0; rec_bin <= 7'd0; end
        else begin
            rec_v2 <= rec_v;
            if (rec_v) rec_bin <= (rec_shift > 32'd127) ? 7'd127 : rec_shift[6:0];
            if (rec_v2) hist[rec_bin] <= hist[rec_bin] + 32'd1;
            if (st == S_CLR) hist[hclr] <= 32'd0;
        end
    end

    assign ap_idle = (st == S_IDLE);
    always @(posedge ap_clk) cyc <= rst ? 64'd0 : cyc + 64'd1;

    // gmem0 read address / write
    wire [63:0] line_addr = buf_q + ((md == 2'd2) ? ({32'd0, idx} << 12) : ({32'd0, idx} << 5));
    assign m_axi_gmem0_araddr  = line_addr;
    assign m_axi_gmem0_arlen   = (md == 2'd2) ? 8'd127 : 8'd0;
    assign m_axi_gmem0_arsize  = 3'b101;            // 32 bytes per beat
    assign m_axi_gmem0_arburst = 2'b01;
    assign m_axi_gmem0_rready  = 1'b1;
    assign m_axi_gmem0_awaddr  = line_addr;
    assign m_axi_gmem0_awlen   = 8'd0;
    assign m_axi_gmem0_awsize  = 3'b101;
    assign m_axi_gmem0_awburst = 2'b01;
    assign m_axi_gmem0_wdata   = line_q;            // write back what was read: the chain stays intact
    assign m_axi_gmem0_wstrb   = {(DW/8){1'b1}};
    assign m_axi_gmem0_wlast   = 1'b1;
    assign m_axi_gmem0_bready  = 1'b1;
    // gmem1: results
    assign m_axi_gmem1_araddr  = 64'd0;
    assign m_axi_gmem1_arlen   = 8'd0;
    assign m_axi_gmem1_arsize  = 3'b101;
    assign m_axi_gmem1_arburst = 2'b01;
    assign m_axi_gmem1_arvalid = 1'b0;
    assign m_axi_gmem1_rready  = 1'b1;
    assign m_axi_gmem1_awaddr  = res_q;
    assign m_axi_gmem1_awlen   = 8'd16;             // 17 beats
    assign m_axi_gmem1_awsize  = 3'b101;
    assign m_axi_gmem1_awburst = 2'b01;
    assign m_axi_gmem1_wstrb   = {(DW/8){1'b1}};
    assign m_axi_gmem1_wlast   = (rbeat == 5'd16);
    assign m_axi_gmem1_bready  = 1'b1;
    wire [6:0] hb = {rbeat[3:0] - 4'd1, 3'b000};     // first bin of histogram beat rbeat (1..16)
    assign m_axi_gmem1_wdata = (rbeat == 5'd0) ? {total, lsum, cnt, lmax, lmin, 32'h1A7E0001} :
        {hist[hb + 7], hist[hb + 6], hist[hb + 5], hist[hb + 4], hist[hb + 3], hist[hb + 2], hist[hb + 1], hist[hb]};

    always @(posedge ap_clk) begin
        if (rst) begin
            st <= S_IDLE; done_pulse <= 1'b0; rec_v <= 1'b0; rec_lat <= 32'd0;
            m_axi_gmem0_arvalid <= 1'b0; m_axi_gmem0_awvalid <= 1'b0; m_axi_gmem0_wvalid <= 1'b0;
            m_axi_gmem1_awvalid <= 1'b0; m_axi_gmem1_wvalid <= 1'b0;
            buf_q <= 64'd0; res_q <= 64'd0; n_q <= 32'd0; mode_q <= 32'd0; i <= 32'd0; idx <= 32'd0; nidx <= 32'd0;
            t0 <= 64'd0; t_start <= 64'd0; lsum <= 64'd0; total <= 64'd0; lmin <= 32'hFFFFFFFF; lmax <= 32'd0; cnt <= 32'd0;
            line_q <= {DW{1'b0}}; first <= 1'b0; hclr <= 7'd0; rbeat <= 5'd0;
        end else begin
            done_pulse <= 1'b0;
            rec_v      <= 1'b0;
            if (rec_v2) begin                                   // second pipeline stage (same cycle as the bin)
                if (rec_lat < lmin) lmin <= rec_lat;
                if (rec_lat > lmax) lmax <= rec_lat;
                lsum <= lsum + {32'd0, rec_lat};
                cnt  <= cnt + 32'd1;
            end
            case (st)
                S_IDLE: if (ap_start_r && !done_pulse) begin      // not in the cycle the last run's done lands
                    buf_q <= arg_buf; res_q <= arg_res; n_q <= arg_n; mode_q <= arg_mode;
                    i <= 32'd0; idx <= 32'd0; lmin <= 32'hFFFFFFFF; lmax <= 32'd0; lsum <= 64'd0; cnt <= 32'd0;
                    hclr <= 7'd0; t_start <= cyc; st <= S_CLR;
                end
                S_CLR: begin
                    hclr <= hclr + 7'd1;
                    if (hclr == 7'd127) st <= S_RUN;
                end
                S_RUN: begin
                    if (i == n_q) st <= S_RES_AW;
                    else begin m_axi_gmem0_arvalid <= 1'b1; t0 <= cyc; first <= 1'b1; st <= S_RWAIT; end
                end
                S_RWAIT: begin
                    if (m_axi_gmem0_arvalid && m_axi_gmem0_arready) m_axi_gmem0_arvalid <= 1'b0;
                    if (m_axi_gmem0_rvalid) begin
                        if (first) begin nidx <= m_axi_gmem0_rdata[31:0]; line_q <= m_axi_gmem0_rdata; first <= 1'b0; end
                        if (m_axi_gmem0_rlast) begin
                            if (md != 2'd1) begin rec_v <= 1'b1; rec_lat <= cyc[31:0] - t0[31:0]; end
                            if (md == 2'd1) st <= S_WISSUE;
                            else begin
                                idx <= first ? m_axi_gmem0_rdata[31:0] : nidx;
                                i <= i + 32'd1; st <= S_RUN;
                            end
                        end
                    end
                end
                S_WISSUE: begin
                    m_axi_gmem0_awvalid <= 1'b1; m_axi_gmem0_wvalid <= 1'b1; t0 <= cyc; st <= S_WWAIT;
                end
                S_WWAIT: begin
                    if (m_axi_gmem0_awvalid && m_axi_gmem0_awready) m_axi_gmem0_awvalid <= 1'b0;
                    if (m_axi_gmem0_wvalid && m_axi_gmem0_wready)   m_axi_gmem0_wvalid  <= 1'b0;
                    if (m_axi_gmem0_bvalid) begin
                        rec_v <= 1'b1; rec_lat <= cyc[31:0] - t0[31:0];
                        idx <= nidx; i <= i + 32'd1; st <= S_RUN;
                    end
                end
                S_RES_AW: begin
                    // the recording pipeline has drained: its last stage ran at least two cycles ago
                    if (!m_axi_gmem1_awvalid) begin m_axi_gmem1_awvalid <= 1'b1; total <= cyc - t_start; end
                    else if (m_axi_gmem1_awready) begin
                        m_axi_gmem1_awvalid <= 1'b0; rbeat <= 5'd0; m_axi_gmem1_wvalid <= 1'b1; st <= S_RES_W;
                    end
                end
                S_RES_W: if (m_axi_gmem1_wready) begin
                    if (rbeat == 5'd16) begin m_axi_gmem1_wvalid <= 1'b0; st <= S_RES_B; end
                    else rbeat <= rbeat + 5'd1;
                end
                S_RES_B: if (m_axi_gmem1_bvalid) begin done_pulse <= 1'b1; st <= S_IDLE; end
                default: st <= S_IDLE;
            endcase
        end
    end
endmodule
