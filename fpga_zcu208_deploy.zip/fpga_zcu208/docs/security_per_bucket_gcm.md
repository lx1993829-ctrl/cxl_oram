# Per-bucket authentication: text for security_analysis.tex

Replaces the per-position integrity argument. Suggested wording; adapt notation to the paper.

**Construction.** Each bucket $b$ is stored off-package as one AES-GCM ciphertext $C_b$ of its $Z$ positions,
with associated data $A_b = b$. Its IV $v_b$ and tag $t_b$ are kept in the bucket's record in trusted HBM.
Every access to $b$ reads all of $C_b$, verifies $t_b$, decrypts, edits the plaintext on chip (removal of the
requested block, insertion of evicted blocks), re-encrypts all $Z$ positions under a fresh IV
$v_b' \neq v_b$, and writes $C_b'$ back with $t_b'$; the record is then updated to $(v_b', t_b')$.

**IV uniqueness.** IVs come from a 96-bit maximal-length LFSR stepped once per bucket write-back, so they never
repeat within a boot (period $(2^{96}-1)/3$). Cross-boot uniqueness needs a per-boot key, as before.

**Integrity and freshness.** Because $(v_b, t_b)$ live in trusted memory, the only valid ciphertext for $b$ is
the one most recently written. Any modification of any position, any reordering of positions, any substitution
of another bucket's ciphertext (different IV, different associated data) or any replay of an older $C_b$ (whose
tag was computed under an older IV) fails verification, except with probability at most the GCM forgery bound
for one message of $Z \cdot$ block bytes. On failure DOMA halts (fail-stop).

**No use before verification.** The controller makes its decisions (stash hit, compaction, evictions) only after
the bucket's tag has verified, and every visible action (the write-back, at its fixed time, and the GET result)
follows those decisions. Decryption streams position by position, but no plaintext influences anything
observable, and nothing leaves the chip, until the whole bucket has verified.

**Confidentiality.** Every write-back re-encrypts all $Z$ positions, real and dummy, under a fresh IV, so a
bucket's ciphertext reveals neither which positions changed nor how many real blocks it holds.

**Compared with per-position tags:** the same integrity guarantee with one tag per bucket instead of $Z$. The
records shrink from 256 to 64 bytes, and per-access crypto work roughly halves (fewer GCM messages, one IV set-up
and one tag computation per bucket).
