# DOMA stash in HBM: per-bucket windows + chains through a bounded pool

**Requirement:** the ONLY capacity that can be exceeded is the stash pool itself (P entries, sized by the stash
bound). Nothing else may overflow. Every access does the same, fixed amount of HBM work.

## Layout (stash buffer in HBM; bases set at boot from the run-time bucket count and pool size)
- **heads:** bucket b at b * 32 * HB B (HB beats, HB = ceil((W + 1)(PW + 1) / 256): 1 at small builds, 2 at the 2^22 build with Z = 10): W + 1 packed entries of PW + 1 bits, {valid, pool index}. Entries 0..W-1
  are the candidate list C_b (W = Z + 1 = 9), kept compact: the first waiting slots of b, its eviction candidates.
  Entry W is the head of the overflow list L_b, b's further waiting slots. At the 2^22 build: 10 x 23 = 230 bits (up
  to 2^24: 10 x 25 = 250). With Z = 10, W = Z + 1 = 11 and the head holds 12 entries (276 bits at the 2^22 build: two beats). A generate-time check fails elaboration if W < Z + 1 or HB > 4.
- **meta:** pool entry p at meta_base + p * 16 B. Word 0 slot, word 1 next {valid[31], index}, word 2 prev. Chain
  entries are doubly linked (prev of the first: none); free entries are singly linked by next (the free list).
- **data:** pool entry p at data_base + p * BLOCK_BYTES.
- **free list:** head register on chip, its next prefetched; a never-used counter `fresh` (allocate fresh++ until P,
  then pop the free list).
- **position map:** a stashed block's entry holds its pool index: 48-bit entries {pool index, status, bucket}, 5 per
  32-byte beat.

## The only overflow
Allocating a pool entry when fresh == P and the free list is empty: `ins_full`, and a fail-stop. Windows are a
cache, chains live in the pool, the free list holds exactly the unused entries, staging holds at most 1 + 7 + 1
blocks per access: none of them can overflow.

## Per access (b = the bucket read, bt = the new target, pr = the requested block's pool index if stashed)
Fixed reads, every access:
1. **level 1 (at open):** head(b), head(bt) (unless bt == b), meta[pr] + data[pr] (if stashed), meta[free head]
   (its next, unless already known);
2. **level 2 (when head(b) lands):** meta + data of b's window entries (the eviction candidates), meta[chain(b)] (the
   chain step).

On chip, after `ready`:
- **remap** (a stashed requested block): unlink it from b (out of the window, or off the chain via its prev/next) and
  link it into bt (the window if it has room, else the head of bt's chain). Its pool index stays. When bt == b,
  nothing moves.
- **insert** (the requested block came from the bucket): allocate a pool entry and link it into bt. The controller
  stores the pool index in the position map.
- **evictions** into b: window entries, first first, up to the bucket's free positions. Their pool entries are freed.
- **commit:** the chain step, then write back.
  - The chain step moves exactly one entry from b's chain into b's window, if there is room and b's chain head is
    still the one read at open.
  - The write-back covers head(b), head(bt), the changed meta fields (byte-strobed writes: no read-modify-write) and
    dirty staged blocks.

## Why W = Z + 1: every read moves in every waiting slot that fits

Per access (requested slot q, read bucket b, q's new bucket b'), in order:
1. **The requested slot.** If q was in bucket b it leaves the bucket. If b' != b, q moves to b''s lists (out of C_b or
   L_b if it was stashed; into C_b' if it has room, else onto the head of L_b'). If b' = b, a stashed q stays where it
   is, and a q that came from the bucket joins C_b if it has room, else L_b.
2. **Eviction.** The first min(free, |C_b|) entries of C_b move into b's free positions.
3. **Promotion.** If L_b is non-empty and C_b has room, L_b's head moves into C_b, provided L_b's head did not change
   during this access.

Accesses that read other buckets only add to C_b and L_b (removing a slot assigned to b requires requesting it, and
every request reads its slot's bucket).

**Lemma.** If W >= Z + 1, every read of b moves in exactly min(free_b, |C_b| + |L_b|) slots: the count an unbounded
per-bucket list (or the original parallel search) gives.

**Invariant J(b), after every access:** if L_b is non-empty, then |C_b| = W, or bucket b is full and |C_b| >= 1.
- Accesses that do not read b preserve J(b): b's contents do not change, C_b and L_b only grow, and L_b becomes
  non-empty only when C_b is full.
- At a read of b, if L_b is non-empty after step 1 then |C_b| >= free, so step 2 moves the right count. If C_b was
  full, |C_b| >= W - 1 >= Z >= free (at most q leaves C_b; **this is where W >= Z + 1 is needed**). If b was full and
  |C_b| >= 1, then free <= 1, with free = 1 only when q came out of the bucket, in which case C_b is untouched.
- J(b) holds afterwards: the eviction filled b. C_b can end empty only when q did not come from L_b's head and no slot
  was pushed onto L_b, so L_b's head is unchanged and promotion restores |C_b| >= 1. (This covers both ways C_b can
  empty: C_b full, q taken from C_b and b empty; and b full, |C_b| = 1, q taken from the bucket.)
- Base case: the stash starts empty.

**Consequence.** Per-bucket counts evolve exactly as in the analysis: at each read of bucket j the slots left behind
number (h_j(t_j) - Z)+. Which waiting slots move in can differ, but the argument uses only counts, so F_t <= O_t and
S_t <= R_t + O_t hold for the hardware and Claim 1 applies with no extra margin.

**With W = Z (the previous 8) it fails:** bucket b empty, C_b full, L_b non-empty, and a candidate is requested and
remapped away: W - 1 = 7 candidates for 8 free positions, while a slot already mapped to b stays behind (F_t > O_t for
that bucket). A second path: requesting L_b's head while b is empty leaves C_b empty with L_b non-empty, and a later
read can under-fill.

## Verification
`tb_stash.v` checks against an exact reference model of candidate lists, overflow lists and the free list, and counts
every read that moves in fewer slots than fit (a failure). `+directed` constructs the counterexample above: with W = 8
it is one slot short, with W = Z + 1 every waiting slot that fits moves in (W = 9 at Z = 8; W = 11 at Z = 10). It covers eviction order,
data after HBM round trips, every allocated pool index and the chain step. It runs on uniform traffic, hot traffic
(chains up to 89 entries), a pool smaller than N, and deliberate exhaustion: there `ins_full` and the fail-stop
happen exactly when the model's pool is empty, and nothing else ever fails.

## Z = 10 (revision)

W is now derived, `W = Z + 1` (11 at Z = 10). The head grows to W + 1 = 12 entries; at the 2^22 build (PW = 22,
23-bit entries) that is 276 bits, more than one 256-bit beat, so heads span HB beats: heads at b * 32 * HB, read and
written as HB-beat bursts, landed beat by beat and decoded at the last beat, and zeroed at boot beat by beat. Small
builds keep HB = 1. The unit tests pass with HB = 1 and with HB = 2 forced (`-DSTASH_HEAD_BEATS=2`), including the
directed counterexample (every waiting slot that fits moves in) and pool exhaustion. Staging (16) and the meta-write
queue (16) still suffice: 1 + 11 + 1 = 13 staged blocks, at most 4 + 10 + 1 = 15 meta writes per access.
