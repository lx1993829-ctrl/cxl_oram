# DOMA stash in HBM: per-bucket windows + chains through a bounded pool

**Requirement:** the ONLY capacity that can be exceeded is the stash pool itself (P entries, sized by the stash
bound). Nothing else may overflow. Every access does the same, fixed amount of HBM work.

## Layout (stash buffer in HBM; bases set at boot from the run-time bucket count and pool size)
- **heads:** bucket b at b * 32 B (one beat): W + 1 packed entries of PW + 1 bits, {valid, pool index}. Entries 0..W-1
  are the window (W = 8 >= Z, so a full bucket's evictions are always in it), kept compact: the first waiting blocks
  of b, its eviction candidates. Entry W is the chain head, b's further waiting blocks. At the 2^22 build: 9 x 23 =
  207 bits.
- **meta:** pool entry p at meta_base + p * 16 B. Word 0 slot, word 1 next {valid[31], index}, word 2 prev. Chain
  entries are doubly linked (prev of the first: none); free entries are singly linked by next (the free list).
- **data:** pool entry p at data_base + p * BLOCK_BYTES.
- **free list:** head register on chip, its next prefetched; a never-used counter `fresh` (allocate fresh++ until P,
  then pop the free list).
- **position map:** a stashed block's entry holds its pool index: 48-bit entries {pool index, status, bucket}, 5 per
  32-byte beat.

## The only overflow
Allocating a pool entry when fresh == P and the free list is empty: `ins_full`, and a fail-stop. Windows are a
cache, chains live in the pool, the free list holds exactly the unused entries, staging holds at most 1 + 7 + 1
blocks per access: none of them can overflow.

## Per access (b = the bucket read, bt = the new target, pr = the requested block's pool index if stashed)
Fixed reads, every access:
1. **level 1 (at open):** head(b), head(bt) (unless bt == b), meta[pr] + data[pr] (if stashed), meta[free head]
   (its next, unless already known);
2. **level 2 (when head(b) lands):** meta + data of b's window entries (the eviction candidates), meta[chain(b)] (the
   chain step).

On chip, after `ready`:
- **remap** (a stashed requested block): unlink it from b (out of the window, or off the chain via its prev/next) and
  link it into bt (the window if it has room, else the head of bt's chain). Its pool index stays. When bt == b,
  nothing moves.
- **insert** (the requested block came from the bucket): allocate a pool entry and link it into bt. The controller
  stores the pool index in the position map.
- **evictions** into b: window entries, first first, up to the bucket's free positions. Their pool entries are freed.
- **commit:** the chain step, then write back.
  - The chain step moves exactly one entry from b's chain into b's window, if there is room and b's chain head is
    still the one read at open.
  - The write-back covers head(b), head(bt), the changed meta fields (byte-strobed writes: no read-modify-write) and
    dirty staged blocks.

## Effect on the stash bound
Evictions only take window entries, so an access evicts fewer blocks than would fit only if b's window runs dry while
its chain is non-empty. Assignments of blocks to buckets do not depend on the stash, so
stash_window(t) = stash_ideal(t) + sum_b d_b(t), with d_b <= Z, and d_b > 0 only if b's chain was non-empty at b's
last read:
- P(pool overflow) <= P(ideal stash > P - D) + P(sum_b d_b > D);
- the first term is Claim 1 (the host evaluates it exactly for the run's n, at 2^-64 per access);
- the second term's formal Chernoff bound is still to be written. Until then the host adds a PROVISIONAL D of 1% of
  n + 64 entries.

In simulation (at lambda 4, Z 6, with a window of 8; about 1M accesses each, uniform and scan), no access ever evicted fewer blocks than
would fit with an 8-entry window. The window effect is therefore expected to be negligible.

## Verification
`tb_stash.v` checks against an exact reference model of windows, chains and the free list. It covers eviction order,
data after HBM round trips, every allocated pool index and the chain step. It runs on uniform traffic, hot traffic
(chains up to 89 entries), a pool smaller than N, and deliberate exhaustion: there `ins_full` and the fail-stop
happen exactly when the model's pool is empty, and nothing else ever fails.
