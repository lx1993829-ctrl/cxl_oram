# ZCU208 ORAM: deployment package

Everything needed to build, simulate and bring up the secured ORAM on the ZCU208, with all fixes
through the post-Phase-3 audit.

| Folder | Contents |
|---|---|
| `rtl/` | **Synthesis sources** (CRLF, like your originals): the ORAM, `onboard_test_top.v` (self-test top), `oram_params.vh`, and your unchanged `ddr_pattern_init.v` / `pulse_generator.v` (not used by the ORAM; kept for your block design) |
| `sim/` | Testbenches (`tb_onboard_test_top.v`, `tb_ni.v`) and simulation scripts; see `sim/README_SIM.md` |
| `vivado/add_sources.tcl` | Adds the sources to your open Vivado project for a self-test, calibration or production build |
| `patches/` | Per-phase patches and a cumulative patch against your original files (LF) |
| `docs/` | This guide, plus `README_FPGA.md` (audit, phases, design details) |
| `MANIFEST.sha256` | Checksums of every file |

## Configuration

**Default: one client with one ORAM** (256 slots, 64 buckets of Z = 6 at λ = 4, one 128-entry stash).
Accesses start on demand with no dummy accesses, and every access takes 5,292 cycles (17.6 µs at
300 MHz) with the budgets in `oram_params.vh`. Recalibrate those budgets on the board as below.

**Two clients:** add the Verilog define `ORAM_TWO_CLIENTS` to the project (synthesis and simulation).
That gives one ORAM per client (slots 0–255 and 256–511, buckets 0–63 and 64–127) and the fixed window
schedule with dummy accesses.

## What changed at the interfaces

**`onboard_test_top`: port list unchanged.** Your block design and XDC still apply. It runs the paper's
Table IV workload first, from the fresh boot state, latches the counter outputs, then runs T1–T48.
Internally it also:
- pulses `key_load` after reset;
- waits for `oram_ready` before its first test;
- runs a two-slot schedule (client 0, client 1).

**`secure_oram_top`: new ports** (matter only for your own production top):

| Port | Direction | Purpose |
|---|---|---|
| `key_load` | in | Pulse once per boot; latches `aes_key` / `aes_iv_seed` (all-zero key refused) |
| `key_ready` | out | Key loaded |
| `oram_ready` | out | Key loaded **and** DDR formatted **and** layout done. Clients must wait for it. |
| `client_lockout[i]` | out | Client locked after 4 rejected requests; cleared by GRANT/RENEW |
| `err_ct_overrun` | out | Sticky, fatal: a timing gate was missed |
| `cfg_tdm_slot_cycles`, `cfg_tdm_frame_len`, `cfg_tdm_owner`, `cfg_tdm_owner_valid` | in | Slot schedule, latched once after reset |
| `client_ready[i]` | out | Client may issue its (single outstanding) request |
| `client_wbeat_req[i]` | out | Write beat that client should present while filling |
| `err_slot_overrun` | out | Sticky, fatal: controller still busy at a slot start |
| `dbg_slot_*`, `dbg_real_cnt`, `dbg_dummy_cnt` | out | Debug builds only (0 otherwise) |

Behavior changes:
- `oram_busy` now means "a client request is pending".
- `init_mode` is ignored in production builds, because the controller owns the random layout.

## Debug ports

Simulation builds enable `ORAM_DEBUG_PORTS` automatically (whenever `SYNTHESIS` is undefined, unless `ORAM_SECURE_BUILD` is set). For synthesis it must be defined explicitly: `add_sources.tcl` does this for the `selftest` and `calibration` builds, and never for `production`.

## If simulation shows old behavior

The self-test prints a banner first, for example:

    tb_onboard_test_top | package 2026-10-04 streaming + eviction overlap | ORAM_CT_WB=4700 ORAM_CT_DONE=6300

- **No banner** (or a syntax error about `join_any`): Vivado is compiling an **old testbench**.
- **"an OLD oram_params.vh is being compiled"**: an old header is being used.

The usual cause is "Copy sources into project". Vivado then compiles its own copies under
`<project>.srcs/`, and extracting a new package does not update them. To fix it:

- **Check which file is used:** `get_files -all tb_onboard_test_top.v` and
  `report_compile_order -fileset sim_1`.
- **Replace the old copies:** `set ORAM_REPLACE 1; source vivado/add_sources.tcl`.

## Bring-up order on the board

1. **Simulate first:** `cd sim && bash run_verilator.sh` must end with `ALL CHECKS PASSED`. Optionally
   run `bash run_xsim.sh` for Vivado's simulator (its first run is a bring-up; see the script header).
2. **Calibration bitstream.** In Vivado: `set ORAM_BUILD calibration; source vivado/add_sources.tcl`.
   - Use *Set Up Debug* to attach the `mark_debug` nets `ct_max_rd`, `ct_max_wb` and `ct_max_done`
     (in `u_oram`) to an ILA.
   - Run the self-test on the board and read the worst arrivals.
3. **Set the budgets** in `rtl/oram_params.vh`:
   - `ORAM_CT_RD` = measured read arrival + margin;
   - `ORAM_CT_WB` = measured worst *encryption end* (`ct_max_wb`) − 896 + margin. Measure it over the
     **full self-test**, not just heavy-eviction cases: with eviction overlap the slowest accesses are
     the two-copy paths. The write-back
     streams while encryption finishes; a too-early value fails safely (overrun, never plaintext);
   - `ORAM_CT_DONE` = `CT_WB` + measured write duration + about 15%.

   **Use the derived worst case** (see `README_FPGA.md`, "Derived worst case"). The on-chip part
   (299 cycles of worst-case operation and eviction, plus fixed verification and encryption) does not
   depend on memory. Only the first-position landing time and the write-back duration need measuring
   on the board:
   `CT_WB >= 17 + max landing + 2,416 + 299 + 2,399 - 896 (+ margin)`, and
   `CT_DONE >= CT_WB + max write-back duration (+ margin)`. The slot length follows automatically
   (`ORAM_TDM_SLOT`).
4. **Self-test bitstream:** `set ORAM_BUILD selftest; source vivado/add_sources.tcl`. The self-test
   reports 53 results as before. An undersized budget makes the controller **halt** (`err_ct_overrun`)
   instead of leaking timing, which shows up as failing tests.
5. **Production:** your own top with `set ORAM_BUILD production`. Follow the integration checklist in
   `README_FPGA.md`. In short:
   - provision the key and per-boot seed and pulse `key_load`;
   - drive the slot configuration;
   - wait for `oram_ready`;
   - each client: one outstanding request, gated by `client_ready[i]`;
   - treat every `err_*` output as fatal.

## Not verified here

- **No synthesis, place-and-route or timing analysis was run here; no Vivado was available.** The
  added logic is:
  - the 3-lane GHASH;
  - a 4 KB result buffer, written in its own clocked block so it can map to BRAM;
  - two 4 KB per-client write buffers with combinational reads, which map to LUT-RAM;
  - the slot logic.

  Check timing at your clock.
- **Crypto streaming** (see `README_FPGA.md`): the scratch buffer is now 8 banks, about 32 BRAM36
  instead of about 8.
- The stash data memory is tagged `ram_style = "ultra"`. UltraRAM cannot be initialized from the
  bitstream, so Vivado will drop that memory's `initial` loop with a warning. This is harmless: the
  boot-time format pass initializes everything that is read.
- XSim was not run. Verilator (full regression) and Icarus (compile) were.
- **LFSR stand-ins, as agreed:** the remap PRNG, 32-bit lease tokens and the IV seed. Within a boot,
  IVs never repeat; across boots, the same IV sequence replays.
