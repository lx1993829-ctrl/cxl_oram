# Tiny ORAM Phase 1: port onto step 5.2, change list (2026-10-13)

Base: `fpga_zcu208_deploy.zip`, step 5.2. Unzip this archive over the package root; nothing is
deleted.

## Shared files (changed; defaults leave DOMA unchanged)

| File | Change |
|---|---|
| `vitis/host_doma.cpp` | Kernel selection: `--kernel tinyoram_kernel` or `DOMA_KERNEL=tinyoram_kernel` (default `doma_kernel`). DOMA keeps its 8-argument launch; Tiny ORAM launches with 4 (cmd, resp, pages, size), and meta/brec/stash are allocated only for DOMA. `DOMA_N` = records for both kernels; for Tiny ORAM it must match the bitstream's N (reported at init), otherwise the host stops and names the L it needs. Tiny ORAM's tree buffer is sized from `DOMA_N` and `DOMA_BLOCK` (a port of its `BucketLocal.vh` formula). `DOMA_PACK` is refused for Tiny ORAM (until Phase 2). Prints Tiny ORAM's geometry and its three latencies; the traffic line prints for both kernels. Adds `#include <initializer_list>`. |
| `vitis/check_timing.sh` | `XCLBIN` and `XDIR` overrides, defaults `doma_hw.xclbin` and `_x`. |
| `vitis/worst_paths.tcl` | `XDIR` override (default `_x`); the instance prefix stripped from path names matches any `*_kernel_1`. |
| `sim/axi_mem_model.v` | **Not changed.** Step 5.2's model already lands each write burst `wlat` cycles after its own last beat, which is what `wlat_pipe` did on the old base. |

DOMA's `rtl/` and `sim/` are byte-identical to step 5.2.

## New files (Tiny ORAM only)

| File | What |
|---|---|
| `tinyoram/rtl/tinyoram_kernel.v` | The kernel. **Moved from `rtl/`**: DOMA's `package_kernel.tcl`, `synth_ooc.tcl` and `worst_paths.tcl` read every `rtl/*.v`, and these files need Tiny ORAM's headers. |
| `tinyoram/rtl/tinyoram_axi_adapter.v` | The 1:1 AXI adapter (moved likewise). |
| `tinyoram/fetch_tinyoram.sh` | Upstream 18ece07 + patches 01–06. New optional second argument: tree depth L (6..26). |
| `tinyoram/patches/01..06_*.diff` | Unchanged. |
| `tinyoram/config/tinyoram_config_{64,128,256,4k}.vh` | Comment only (N depends on L). |
| `tinyoram/study/run_study.sh`, `tb_core.sv` | Unchanged. |
| `sim/tb_tinyoram_kernel.v`, `sim/run_tinyoram.sh`, `sim/run_xsim_tinyoram.sh` | Regression; paths to `tinyoram/rtl/`. |
| `vitis/build_tinyoram.sh` | `N=<records>` picks L; same post-placement hook as `build.sh`; prints the merged host's run line. |
| `vitis/package_tinyoram.tcl`, `synth_ooc_tinyoram.tcl`, `kernel_tinyoram.xml`, `tinyoram_hw.cfg`, `tinyoram_host.cfg` | Packaging and link; paths to `tinyoram/rtl/`. |
| `docs/tinyoram_phase1_shared_files.diff` | Unified diff of the three shared files against step 5.2, for review. |
| `docs/README_TINYORAM.md` | §10 describes this phase; B6 is recorded as a stated limitation (end of §9). |
| `docs/tinyoram_regression_2026-10-13.txt` | `bash run_tinyoram.sh` log on this tree. It replaces `tinyoram_regression_2026-10-12.txt`, which you can delete. |

## Kernel behaviour changed in this phase (`tinyoram_kernel.v`)

* GET data at HR = roundup((size+2)·32, 4 KB), as DOMA.
* The init launch (size = 0) latches the pages address and reports the geometry. It touches no
  memory. The tree zero-fill moved to the first launch with size > 0 (the first preload batch).
* Record [size+1]: bytes 24–27 N (blocks), bytes 28–31 tree size in 64-byte bursts (both zero
  for DOMA).

## Acceptance

* DOMA: `ORAM_BEATS=1` and `ORAM_BEATS=128 bash run_verilator.sh all` each give 27/27, with
  trace hashes 1d0cbb36268422ce/886ed1a80f3e4fae (32 B) and 11f8bfc8e4d73473/61fc9e15ed9aea5b (4 KB).
* Tiny ORAM: `bash run_tinyoram.sh` gives 20/20.
* Host: no Vitis/XRT here. Checked against a functional mock of XRT. DOMA's output is
  identical to the step 5.2 host with and without `DOMA_N`, `DOMA_BLOCK`, `DOMA_PACK` and
  `DOMA_PAGES_HBM`. Tiny ORAM's paths were exercised (correct run, `DOMA_N` mismatch, buffer
  too small, `DOMA_PACK` refused, env and option selection). The tree formula matches the RTL
  at 16 points (4 block sizes × L = 6, 14, 18, 22).
