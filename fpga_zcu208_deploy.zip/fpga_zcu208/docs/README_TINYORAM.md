# Tiny ORAM as a U55C kernel — Step 1 notes and Step 2 configuration

Status 2026-10-13: Phase 1 (port onto the step 5.2 package) done, §10. Tiny ORAM regression 20/20
and DOMA's regressions unchanged. Packaging, host program and build scripts are written but
untested on Vitis: no Vivado/Vitis/XRT where they were written (the host was checked against a
functional mock of XRT, §10). Next: Phase 2 (packing).

Source studied: `github.com/ascend-secure-processor/oram`, branch `oram_fpga_public`,
commit `18ece07` (2017-07-12). Simulator: Verilator 5.020. The harness and patches used
below are in `tinyoram/study/` (`run_study.sh setup` fetches the source and applies
`sim_patches.diff`; no Tiny ORAM source is copied into this package).

## 1. Summary

* **One RTL tree, not an FPGA/ASIC split.** `oram_fpga_public` is `master` plus two
  README commits. The RTL is the MIT "chip" snapshot (2014–15). FPGA and ASIC builds
  share it through `` `ifdef FPGA ``. The board files, Xilinx IP and test scripts the README
  refers to (`../boards`, `../tests`) are not in the repository.
* **4 KB blocks work.** N = 256, 4 KB blocks, encryption and PMMAC integrity on: random
  GET/PUT traffic matched a reference model with BEDWidth 128 and with 256.
* **Read-after-write ordering is required.** Tiny ORAM assumes a MIG-style in-order DRAM.
  When writes become visible late, the harness fails ("block already present in stash").
  The AXI adapter must hold reads until earlier writes are acknowledged.
* **Random initial values are fine; never-written tree memory must read as zeros.**
  (Corrected 2026-10-10: the "hang with random initial values" reported here first was a bug
  in my testbench's memory model, which returned random data for never-written memory under
  `--x-initial unique`. With that fixed, Tiny ORAM passes with `+verilator+rand+reset+2`.)
* **Only one secure configuration works.** That is the Path ORAM backend with AES and
  PMMAC. RAW Path ORAM (`EnableREW=1`) does not work in this snapshot.
* **License:** the MIT-written files carry no license and the repository has no LICENSE
  file (§6).

## 2. Interfaces

### Frontend (user side of `TinyORAMCore`)

| Signal | Meaning |
|---|---|
| `Cmd[1:0]` + `PAddr[31:0]`, `CmdValid/CmdReady` | Commands: `0` Update (write), `2` Read. `1` Append and `3` ReadRmv are internal (PosMap). An Update to a never-written block works, because the frontend turns it into an Append. `PAddr` is the block index and must be < N. |
| `WMask[ORAMB/8-1:0]` | Byte write mask, 4096 bits at 4 KB. Tie it to all ones. |
| `DataIn[FEDWidth]`, valid/ready | Write data. After an accepted Update, ORAMB/FEDWidth beats (512 at 4 KB). |
| `DataOut[FEDWidth]`, valid/ready | Read data, same beat count. |

* **One command at a time.** `CmdReady` stays low until the frontend is free again.
* **No write acknowledgement.** `CmdReady` going high again does not mean the access has
  finished. A trace of one 4 KB access with BEDWidth = 256 (`-DTRACE`), in cycles from the
  command:

  | Phase | GET | PUT |
  |---|---|---|
  | Path read: commands | 39–2040 | |
  | Path read: data | 80–4083 | |
  | Data returned to the user | 4883–5394 | |
  | `CmdReady` high again | | 546 |
  | Path writeback | 4769–8744 | ~8800 (ends) |

  So the user sees a GET finish about 3.4k cycles before the writeback ends, and a PUT
  finish about 8k cycles before it ends.
* **Out-of-range `PAddr` is not handled.** It only sets a sticky error flag (simulation
  calls `$finish`). The wrapper must reject keys ≥ N itself (status 0x4).

### DRAM side ("MIG-like")

* **Command channel:** `DRAMAddress[DDRAWidth]`, `DRAMCommand[2:0]` (0 = write, 1 = read),
  valid/ready.
  * The address counts 64-bit words and is always a multiple of 8. Each command is one
    64-byte burst.
  * A bucket is a run of consecutive bursts. Buckets are laid out in subtrees of height 2
    (at 4 KB), which keeps each subtree within one DDR3 row.
  * The adapter can merge consecutive commands into AXI bursts, but must split them at
    4 KB boundaries. A 4 KB-block bucket is 16,512 B, so it is not 4 KB-aligned.
* **Write data:** `BEDWidth` beats with valid/ready, 512/BEDWidth beats per write command,
  in command order.
* **Read data:** `BEDWidth` beats with **no ready**, in command order.
  * The AES engine must take a beat every cycle. Overflow only sets an error flag
    (`ERROR_OF1`, "Lose ciphertexts").
  * So the adapter buffers the AXI R channel. It pushes at most one beat per cycle into
    the core, and throttles `rready` on its own FIFO.
* **Ordering:** the core issues a whole path of reads, then a whole path of writes. The
  next access's reads start with the root bucket that was just written. The adapter
  therefore needs a single ID with in-order reads, and must hold reads until every
  earlier write has its B response. The `WR_LAG=20000` run shows what happens without
  this.
* **Initial memory contents:** there is no DRAM initialiser ("we got rid of DRAMInit").
  * A bucket whose stored IV is 0 is treated as empty.
  * The tree region must be zero before first use. Garbage happened to pass in simulation,
    but it can turn into fake blocks.
  * Proposal: the kernel zero-fills the tree at the first (size = 0) launch, counted as
    initialization. This matches DOMA formatting its buckets at boot.

## 3. Parameters

| Parameter | Default | Notes |
|---|---|---|
| `ORAMB` (block size, bits) | 512 (64 B) | The FCCM'15 paper claims 64 B–4 KB. 32768 tested here. |
| `ORAMZ` | 4 | Effectively fixed: the frontend assumes Z = 4. N = 4·2^L, so the tree is 50 % full. |
| `ORAML` | 23 (19 in sim) | Number of levels = L + 1. N = 256 gives L = 6: 127 buckets, 508 slots. |
| `ORAMC` (stash) | 10 | Extra entries on top of one path: 10 + 4·7 = 38 entries (152 KB at 4 KB). The backend does background eviction (dummy accesses) when the stash fills. |
| `FEDWidth` | 64 | Only 64 works. 128 and 256 hang at 4 KB. |
| `BEDWidth` | 128 | Must divide 512. 128 and 256 both pass. |
| `Overclock` | 1 | Extra stash pipelining "needed for 200 MHz". |
| PosMap | Unified frontend, PLB 8 KB, `PRFPosMap=1` | Recursion = ⌈(L+2−10)/3⌉+1, which is 1 at N = 256. The whole PosMap (256 counters) is on chip, so there are no PosMap ORAMs and the PLB does nothing. Recursion only appears at large N with small blocks. |
| `EnableAES` | 1 | AES-128 counter mode. Each bucket gets a 64-bit IV from a global counter, stored in clear. Pipelined tiny_aes (21-cycle latency), with BEDWidth/128 lanes running at line rate. |
| `EnableIV` (PMMAC) | 1 | Keyed SHA-3 (Keccak, 224-bit digest truncated to 128) over (counter, address, data). It is checked in the frontend; the counter in the PosMap gives freshness. Leaves are AES-PRF(counter). The MACs grow the bucket header from 1 to 2 bursts. |
| `EnableREW` | 0 | RAW Path ORAM. **Not usable**, see below. |
| Keys | hard-coded | AES key all ones, PRF and MAC keys fixed. This is the same situation as DOMA's stand-in keys. |

Which security switches actually work in this snapshot:

* **AES on, PMMAC on: works.** This contradicts the README, which says integrity needs
  the RAW backend.
* **AES on, PMMAC off: works** with `PRFPosMap=0`. With `PRFPosMap=1` and no PMMAC, the
  leaves would be the raw counters.
* **RAW backend: does not work.**
  * With PMMAC it stops with "Not supported yet" (it needs a 1-burst header).
  * Without PMMAC it stops with "Path buffer overflow". The source itself says
    "this won't work right now".

Geometry and traffic at N = 256 and 4 KB, with PMMAC:

* **Bucket:** 258 bursts = 16,512 B.
* **Path:** 7 buckets = 115,584 B.
* **Per access:** 231,168 B moved (56× the block), plus occasional background evictions.
* **Tree:** 2.0 MB in use. The address span is 3.35 MB because of the subtree padding.
  DOMA's pages buffer is 2 MB, so the host must size the pages buffer per kernel.

## 4. Dependencies and porting to UltraScale+ / Vivado 2024.1

* **Xilinx IP is not needed** for the proposed configuration.
  * The only IP instances are `ClkCross512x{128,144,512}` (async FIFOs, RAW backend with
    `FPGA` defined) and `aes_clock` (MMCM, only when `SlowAESClock=0`). Neither is used.
  * There are no Xilinx primitives. RAMs are behavioural (`gatelib/RAM.v`).
  * `FPGA_MEMORY` must be defined. Otherwise the RAMs map to IBM 32SOI SRAM wrappers.
* **Two build flows:**
  * **`FPGA` defined:** parameters are passed down the hierarchy. The backend and AES
    resets are tied to 0, and their FSMs depend on `initial` blocks. `Const.vh` also needs
    `SYNTHESIS` (Vivado synth) or `MODELSIM` (simulation) defined, or its macros
    disappear.
  * **Without `FPGA` (the "ASIC" flow):** resets are real, but `Frontend`,
    `PathORAMBackendCore` and `AESPathORAM` take their parameters from `PathORAM.vh`
    instead of from the parent. One instance per build, configured by editing that file.
  * Both flows gave identical results at 4 KB. **I'd use the ASIC flow plus
    `FPGA_MEMORY`**, because its resets are real.
* **Old-Verilog issues:**
  * Zero-width replications in gatelib parameter defaults (`{Width{1'b0}}` with Width = 0):
    errors in Verilator 5 and Icarus 12. Vivado's behaviour still needs checking with
    `synth_ooc.tcl`.
  * `PrioritySelect.v` has an unnamed instance, which is a syntax error. It is unused, so
    I excluded it.
  * `ClockSource.v` starts the clock on `posedge` of a constant, so it never starts in
    Verilator.
  * 233 `(* mark_debug = "TRUE" *)` attributes. They should be stripped so they don't pin
    nets.
  * Many simulation-only checks are not gated by reset.
* **Random initial values:** Tiny ORAM's logic passes (corrected 2026-10-10, see §1). Only
  its simulation-only self-checks fire on the first clock edge, before reset takes effect,
  so the random-init run compiles Tiny ORAM without `SIMULATION`.
* **Timing:** the original target was 200 MHz on a Virtex-7 (XC7VX485T). Likely long
  paths at 300 MHz:
  * Keccak `round2in1` (two rounds per cycle);
  * the tiny_aes table rounds;
  * the stash scan logic.

  I can't estimate slack without Vivado. That is the first `worst_paths.tcl` job.

## 5. Its own tests

* **The shipped test** is `frontend/test/testUORAM.v`, driving `TinyORAMASICWrap` and
  `TrafficGenASIC`. The README says the per-module testbenches are out of date.
  * It needs files that are not in the repository (`tests/software/testORAM.v`,
    `network_define.v`). `+define+SIMULATION_VIVADO` avoids them.
  * Its dummy generator hard-fails on any configuration other than the default one
    (64 B blocks, Z = 4, PMMAC on).
* **Icarus 12:** does not elaborate (indefinite-width concatenations). Not pursued.
* **Verilator 5.020:** needed four simulation-only patches:
  * zero-width defaults;
  * a nonblocking assignment in a loop in an AddrGen checker;
  * the clock start;
  * an `ORAML` override, since L = 19 is too slow.

  With those it gives **"TrafficGen: ALL TESTS PASSED"**: default configuration, L = 10,
  6,144 accesses.
* **My harness** (`tinyoram/study/tb_core.sv`) drives `TinyORAMCore` directly.
  * Preload of all N blocks, then 200 random commands (50 % PUT), every GET checked.
  * DRAM model: in-order, 40-cycle read latency, 10 % random gaps on every DRAM channel,
    never-written memory reads as zeros.

| Configuration | Result | Cycles/cmd | Read + written per cmd |
|---|---|---|---|
| 64 B, L = 10 (N = 4096), FED 64, BED 128, AES + PMMAC | PASS | 1,328 | 7.3 + 7.2 KB |
| 64 B, L = 10, BED 256 | PASS | 824 | 7.4 + 7.4 KB |
| **4 KB, L = 6 (N = 256), FED 64, BED 128, AES + PMMAC** | PASS | 18,364 | 112.5 + 112.3 KB |
| **4 KB, L = 6, FED 64, BED 256, AES + PMMAC** | PASS | 9,636 | 112.9 + 112.4 KB |
| 4 KB, BED 256, AES only (`PRFPosMap=0`) | PASS | 8,962 | 112.9 + 112.4 KB |
| 4 KB, same with `FPGA` defined | PASS, identical | 9,636 | |
| 4 KB, FED 128 or 256 | hang | | |
| 4 KB, writes visible 20k cycles late | FAIL (duplicate block in stash) | | |
| 4 KB, random initial values | PASS (the first "hang" was a testbench bug) | 9,613 | |
| 64 B, RAW backend, no PMMAC | FAIL (path buffer overflow) | | |

The cycles-per-command figures come from an idealised DRAM. HBM, and later host memory,
will be slower. At 300 MHz, 9,636 cycles is 32 µs, about 31 k commands/s, as an upper
bound.

## 6. License

* **Third-party cores** carry permissive notices: UC Berkeley GateLib (BSD-3),
  tiny_aes and the Keccak core by Homer Hsing (Apache-2.0), and the OpenCores AES by
  R. Usselmann (BSD-style).
* **The MIT-written files** (frontend, backend, stash, addr, integrity, `TinyORAMCore`,
  `include/`) have no license header, and there is no LICENSE file.
* By default that means all rights reserved, so redistributing modified copies is not
  clearly allowed. Until that's settled, I'd ship Tiny ORAM changes only as patches plus a
  fetch script, as `tinyoram/study/` does now.
* The authors to ask are C. Fletcher, L. Ren and A. Kwon (commit authors).

## 7. Step 2 configuration (agreed 2026-10-09)

**Baseline A, same N and block size as DOMA:**

* **Protocol:** Path ORAM backend, Z = 4, L = 6, N = 256, 4 KB blocks, C = 10.
* **Security:** AES-128 counter mode on, PMMAC integrity on, `PRFPosMap=1`. The PLB is
  configured but idle.
* **Widths:** FEDWidth 64, BEDWidth 256, so a 256-bit AXI beat is one core beat.
* **Clock:** the same 300 MHz kernel clock, with the AES on that clock
  (`SlowAESClock=1`). If timing fails, report the achieved frequency rather than lowering
  the target.
* **Tree:** in `m_axi_gmem2`, HBM[8] first, then HOST[0]. The pages buffer is at least
  3.35 MB and zero-filled by the kernel at the first launch.
* **Build:** ASIC flow plus `FPGA_MEMORY`, `mark_debug` stripped, minimal fixes for
  Vivado and for random initial values, each one recorded in the README.

Baseline A is the most comparable to DOMA. It is also not Tiny ORAM's favourable regime:
its 2-burst headers and 56× path traffic dominate. A second configuration (B) would cover
BOLT-like sizes:

* 64 B blocks (Tiny ORAM's native and minimum size); 8–256 B records fit in one block;
* N sized like BOLT's key space, which brings in PosMap recursion and the PLB as Tiny
  ORAM was designed;
* later, also 256 B.

**Latency definition.** DOMA's `client_done` fires after its writeback is acknowledged.
For a fair comparison I propose:

* a command is done when its data is back (GET) **and** the backend is idle **and** the
  adapter has no outstanding writes;
* the next command is issued only after that.

This needs one internal tap (the backend controller's idle state). I would also record
"data ready" time as a second figure.

**Decided:**

* 2026-10-09: keep Tiny ORAM's own cryptography; do not swap in DOMA's AES-GCM. That
  means tiny_aes (pipelined AES-128 in counter mode) for bucket encryption, the OpenCores
  AES as the counter-to-leaf PRF, and keyed SHA-3 for PMMAC. The comparison is against
  Tiny ORAM as published. The README for the results will state the primitive
  difference: AES-CTR plus SHA-3 MAC versus DOMA's AES-GCM.
* 2026-10-09: integrity (PMMAC) stays on.
* 2026-10-09: latency definition.
  * A command's latency ends when its path writeback has been fully sent: the last write
    data beat has been accepted on `m_axi_gmem2`. The kernel does not wait for the write
    responses (B) before stopping the latency counter.
  * For correctness, the adapter still holds later reads until earlier writes are
    acknowledged (§2). Any wait for B responses therefore shows up in the next command's
    latency and in the total query time, not in this command's latency.
  * A GET's data-ready time is recorded as a second figure.
* 2026-10-09: add reset-time clears to Tiny ORAM's uninitialised RAMs and registers, so the
  random-initial-value test passes. **Superseded 2026-10-10:** no clears are needed; the hang
  was a testbench bug (§1), and Tiny ORAM passes the random-init test unchanged.
* 2026-10-09: no license request to the authors. Tiny ORAM will be cited (Fletcher et al.,
  FCCM 2015). Since the MIT files carry no license, the package keeps shipping Tiny ORAM as
  the upstream commit plus our patches and a fetch script, not as copied sources.
* 2026-10-10: record sizes. Both are kept: BOLT-like records of 8–256 B, and 4 KB (DOMA's
  size). All use N = 256 with AES and PMMAC on.
  * Tiny ORAM's block size `ORAMB` is fixed at build time, so each block size is its own
    xclbin.
  * In simulation (harness, BEDWidth 256, 400 random commands after preload), 64 B and up
    pass. 8, 16 and 32 B blocks hang before the first PUT completes, which matches the
    paper's 64 B minimum.
  * So 8–64 B records are stored in 64 B blocks, padded. This costs nothing in memory
    traffic, because Tiny ORAM pads every block to a whole 64 B burst anyway. 128 B,
    256 B and 4 KB are native blocks.
  * That makes four builds:

    | Records | `ORAMB` | Bucket | Path (read, = written) | Sim cycles/cmd |
    |---|---|---|---|---|
    | 8, 16, 32, 64 B | 512 (64 B) | 6 bursts = 384 B | 2,688 B | 351 |
    | 128 B | 1024 | 10 bursts = 640 B | 4,480 B | 499 |
    | 256 B | 2048 | 18 bursts = 1,152 B | 8,064 B | 777 |
    | 4 KB | 32768 | 258 bursts = 16,512 B | 115,584 B | 9,636 |

    The cycle counts come from the idealised DRAM model (40-cycle reads, 10 % gaps), so
    they are upper bounds on speed.
  * The kernel takes the first `ORAMB` bits of each 4 KB PUT slot in the command buffer
    and writes the record (`ORAMB` bits) at the start of the GET slot, so the host layout
    stays the same as DOMA's.

## 8. Step 3 (adapter and kernel) and Step 4 (simulation) — 2026-10-10

### What was built

| File | What it is |
|---|---|
| `tinyoram/rtl/tinyoram_kernel.v` | The Vitis kernel. Same arguments, control registers, buffer layout, response and summary records as `doma_kernel.v`, with Tiny ORAM in DOMA's place. |
| `tinyoram/rtl/tinyoram_axi_adapter.v` | Tiny ORAM's DDR3-controller-style memory port to `m_axi_gmem2`. |
| `tinyoram/fetch_tinyoram.sh` | Downloads Tiny ORAM at commit 18ece07 and applies `tinyoram/patches/`. It writes a flat source directory, `tinyoram/build/src/`, with the configuration header for one block size. |
| `tinyoram/config/tinyoram_config_{64,128,256,4k}.vh` | One configuration header per block size (each size is its own xclbin). |
| `sim/tb_tinyoram_kernel.v`, `sim/run_tinyoram.sh` | Kernel regression (the testbench plays XRT), run with Verilator. |
| `sim/run_xsim_tinyoram.sh` | The same test in Vivado's simulator (untested here). |
| `vitis/synth_ooc_tinyoram.tcl` | Out-of-context synthesis and place & route on the U55C part at 300 MHz. Run this first. |
| `vitis/package_tinyoram.tcl`, `kernel_tinyoram.xml`, `tinyoram_hw.cfg`, `tinyoram_host.cfg`, `build_tinyoram.sh` | Packaging and v++ link, mirroring the DOMA files. |
| `vitis/host_doma.cpp` | Shared with DOMA. Selects the kernel with `--kernel tinyoram_kernel` or `DOMA_KERNEL`; see §10. |

### Changes to Tiny ORAM (patches against 18ece07)

| Patch | Change | Why |
|---|---|---|
| 01 | `Const.vh`/`PathORAM.vh` include `tinyoram_config.vh`. `ORAMB`, `ORAML` and `BEDWidth` defaults can be overridden; `FPGA_MEMORY` is defined. | Per-build configuration. |
| 02 | New `Idle` output, passed up from the backend controller and the integrity verifier. | Status only, for the agreed latency definition. No behaviour change. |
| 03 | gatelib parameter defaults `{Width{…}}` → `{(Width>0?Width:1){…}}`. | Zero-width replication is illegal in current tools. The values are unchanged. |
| 04 | Three simulation-only self-checks: one no longer runs during reset, one fixes a Verilator loop construct. | Inside `ifdef SIMULATION`; no effect on hardware. |
| 05 | `PosMapPLB.v`: `OldLeafOut <= PosMapOut[LeafOutWidth-1:0]` (was `[ORAML-1:0]`). | **Bug fix.** See below. |
| 06 | Remove all 233 `(* mark_debug = ... *)` attributes (14 files). | They pin nets, which costs resources and timing; DOMA has none. Plan step B4: 20/20 with identical cycle counts. |

The patch 05 bug, in more detail:

* In PRF mode the PosMap holds a 64-bit access counter per block, and the leaf is
  AES(address ‖ counter).
* The old counter was cut to `ORAML` bits while the new one kept all 64. So after 2^`ORAML`
  accesses to one block, the old and new leaves disagree, and Tiny ORAM stops on its own
  check ("block being accessed didn't have correct leaf").
* At the authors' `ORAML` = 23 that needs 8 M accesses to one block. At ours (6) it needs 64.
  A uniform 5,000-command run would rarely reach that, but repeated runs without reloading
  the xclbin would.
* Reproduced on the unpatched source: it fails on the 64th access to one key. With the fix,
  300 consecutive accesses to one key pass.

No reset-time clears were needed (§1). Crypto and keys are as published.

### Adapter (1:1, as agreed)

* **Translation:** one Tiny ORAM command (64 B) becomes one 2-beat AXI burst, with a single
  ID. A 64-byte-aligned 2-beat burst can't cross a 4 KB boundary.
* **Ordering:** a read is not issued while any write lacks its B response. A write is not
  issued while any read still has data to return. This is the ordering of the DDR3
  controller Tiny ORAM was built for.
* **Read buffer:** 512 beats; an AR is issued only when there is room for all its data.
  This is needed because Tiny ORAM can't apply backpressure on read data.
* **Write buffer:** 512 beats, and a beat leaves only after its AW. This is needed because
  Tiny ORAM's AES has about two buckets of keystream buffering and no stall. Without the
  buffer, a long W stall loses keystream (Tiny ORAM's own "Lose Masks!" check). A memory
  controller's write FIFO plays the same role in the original setup.
* **Address check:** an address outside the tree raises the kernel's error flag (0x8).

### Kernel specifics

* **First launch:** latches the pages address and zero-fills the tree. An all-zero bucket is
  Tiny ORAM's "never written" bucket, and Tiny ORAM has no DRAM initialiser of its own. Only
  then is Tiny ORAM released from reset; nothing touches memory before the first `ap_start`.
* **Tree size:** the zero-fill covers 49,536 B / 123,520 B / 185,472 B / 3,517,056 B for
  64 B / 128 B / 256 B / 4 KB blocks at L = 6. The host sizes the pages buffer from
  `DOMA_N` and `DOMA_BLOCK` (§10).
* **Key range:** keys ≥ N are rejected (0x4).
* **Changed 2026-10-13 (§10):** the zero-fill moved from the init launch to the first launch
  with size > 0, so the host can check the geometry first.
* **Latency end:** superseded on 2026-10-12 by plan step B1 (§9): the primary figure now ends
  at write-back acknowledged, and "data ready" and "last write beat" are secondary figures.

### Simulation results (Verilator 5.020, `sim/run_tinyoram.sh`, log in `docs/tinyoram_regression_2026-10-12.txt`)

All 20 checks pass: four block sizes × five tests (e2e, late start + 256 PUTs, 30 % gaps, late
writes, random initial values).

Per-command latency at the testbench's 100-cycle tree latency:

| Block size | Latency (cycles) |
|---|---|
| 64 B | 571 |
| 128 B | 834 |
| 256 B | 1,318 |
| 4 KB | 16,936 |

The testbench's memory model accepts at most 16 outstanding reads. With 64-byte bursts that
caps reads at 16 × 2 beats per 100 cycles. So simulated 4 KB latency is mostly that limit,
not Tiny ORAM; HBM's real outstanding-read limit will set the board number.

Memory model: `+host_wlat=200` lands each burst 200 cycles after its own last beat. The
current `sim/axi_mem_model.v` does this itself (bursts land pipelined), so the `wlat_pipe`
option this test used on the old base is no longer needed and `axi_mem_model.v` is unchanged.

### Next on the U55C machine

Superseded by §10 (host usage) and the Phase 3 instructions.

## 9. Modification plan, 2026-10-12

Status of the plan's steps:

| Step | Status |
|---|---|
| A (port onto the current package) | **Waiting for the current `fpga_zcu208_deploy.zip`** (step 4, 26/26). Everything below was done on Tiny ORAM's own files, ready to port. |
| B1 latency | Done, using the recommended definition. |
| B2 byte counters | Done (Tiny ORAM side). |
| B3 packing | `WMask` verified; packing itself not yet started. |
| B4 `mark_debug` | Done (patch 06). |
| B5 clock | Done. |
| B6 burst merging | Decided 2026-10-12: decide after the first 4 KB card results (see below). |
| C | Needs the card. |
| D | Recursion and PLB tested; tree-size table below. |

### B1: latency ends at write-back acknowledged

The response header now carries three figures, all counted from issuing the command to Tiny
ORAM:

| Header bytes | Figure | Ends when |
|---|---|---|
| 8–11 (primary, and the summary min/max) | write-back acknowledged | data done, Tiny ORAM `Idle`, and every write's B response received (adapter idle). This is the same end point as DOMA's `client_done`. |
| 16–19 | data ready | GET record received, or PUT record sent. |
| 20–23 | last write beat | Tiny ORAM `Idle` and every write beat on the bus. |

The testbench checks data ready ≤ last write beat ≤ acknowledged for every command. DOMA's
header bytes 16–31 are zero today; the host can read these two fields for Tiny ORAM only.

### B2: record [size+1]

Format, as in the plan:
* byte 0: `0x5B`;
* bytes 8–15: read beats on gmem2 during the launch;
* bytes 16–23: write beats on gmem2;
* bytes 24–31: zero (DOMA). Since 2026-10-13 Tiny ORAM puts its geometry there (§10).

The init launch counts the zero-fill (64 B tree: 1,548 write beats = 49,536 B). The testbench
compares both counts with its own beat counters on gmem2: exact in all 20 runs. Per command
(run 1, 64 B blocks): 84 read + 84 write beats = 2,688 B each way, exactly one path.

**Layout edge case: settled.** DOMA moved GET data to HR = roundup((size+2)·32, 4 KB) in step
5.2; Tiny ORAM does the same (§10).

### B3 (check): `WMask` works

Test (`tinyoram/study/tb_core.sv -DMASK_TEST`): three quarters of the PUTs to existing blocks
get a partial byte mask, either a random byte range (any offset and length) or an aligned
8-byte slot, against a byte-level reference.

| Configuration | Partial PUTs | Commands | Result |
|---|---|---|---|
| 64 B | 126 | 300 | PASS |
| 4 KB | 48 | 120 | PASS |
| N = 16K, 64 B | 1,124 | 3,000 | PASS |
| N = 64K, 64 B | 1,116 | 3,000 | PASS |

Packing through `WMask` is therefore feasible. The kernel changes it needs (header bytes 8–15,
status 0x40, block-sized slots, block size in summary bytes 4–7) wait for step A, so they
match the current DOMA layout.

### B5: clock

* `FREQ=<MHz> bash build_tinyoram.sh`: `--kernel_frequency`, the packaged `FREQ_HZ` and
  `check_timing.sh`'s `WANT_MHZ` all follow it.
* For `FREQ` ≠ 300 the xclbin is named `tinyoram_<size>_<FREQ>mhz_<target>.xclbin`.
* `synth_ooc_tinyoram.tcl -tclargs route <MHz>` checks another clock out of context.

### D: recursion and the PLB at large N (harness, 64 B blocks, AES and PMMAC on, random partial writes)

| N (blocks) | L | Recursion levels | Preload | 3,000 random commands | Traffic per command |
|---|---|---|---|---|---|
| 16,384 | 12 | 3 | 16,384 PUTs | PASS, 1,398 cycles/cmd | 13.2 KB read + 13.2 KB written: ~2.6 paths (one path = 4,992 B), the extra from PosMap blocks missing the PLB |
| 65,536 | 14 | 3 | 65,536 PUTs | PASS, 1,669 cycles/cmd | 16.5 KB each way: ~2.9 paths (one path = 5,760 B) |

So at large N, PosMap recursion multiplies Tiny ORAM's traffic. The byte counters (B2) will
show this on the card.

Tree size per N, packed 8-byte records (8 per 64 B block). Choose L as the smallest value
with 4·2^L ≥ blocks. The tree span includes the subtree-padding buckets.

| Records | Blocks | L | Blocks held | Recursion | Tree span | One path, each way |
|---|---|---|---|---|---|---|
| 2,048 | 256 | 6 | 256 | 1 | 48 KB | 2,688 B |
| 16,384 | 2,048 | 9 | 2,048 | 2 | 0.4 MB | 3,840 B |
| 131,072 | 16,384 | 12 | 16,384 | 3 | 3.0 MB | 4,992 B |
| 1,048,576 | 131,072 | 15 | 131,072 | 4 | 30 MB | 6,144 B |
| 10,000,000 | 1,250,000 | 19 | 2,097,152 | 5 | 390 MB | 7,680 B |

10M records fit an HBM bank (512 MB), with about 120 MB to spare. The kernel already derives
its key-range check and zero-fill size from the geometry; once packing is in, the host's
`--n` must name records and the matching build.

### B6: burst merging, decided after the card results (2026-10-12)

The 1:1 adapter stays the default and the faithful baseline. After the first 4 KB run with the
tree in HBM[8], compute Tiny ORAM's effective tree bandwidth:

    (read beats + write beats from record [size+1]) x 32 B / query time

Compare it with what the same HBM bank delivers to DOMA's 4 KB bursts. If Tiny ORAM is clearly
limited by per-transaction cost (2-beat bursts) rather than by its own path traffic, add the
merged variant and report both. The merged variant combines consecutive commands into longer
bursts, split at 4 KB boundaries, adapter only, nothing inside Tiny ORAM. Otherwise report 1:1
only.

**Stated limitation (2026-10-13 status note: "not now").** The adapter is 1:1: every Tiny ORAM
memory command is its own 64-byte, 2-beat AXI burst, as with the DDR3 controller Tiny ORAM was
built for. DOMA moves whole blocks in long bursts. The board numbers for Tiny ORAM therefore
include HBM's per-transaction cost of 64-byte bursts; merging consecutive commands into longer
bursts (adapter only) could lower it, and is not done.

## 10. Phase 1: port onto the step 5.2 package (2026-10-13)

### Layout

* Tiny ORAM's kernel and adapter moved from `rtl/` to **`tinyoram/rtl/`**. DOMA's
  `package_kernel.tcl`, `synth_ooc.tcl` and `worst_paths.tcl` read every `rtl/*.v`, and Tiny
  ORAM's files need its headers, so leaving them in `rtl/` would break DOMA's builds. DOMA's
  `rtl/` is now byte-identical to the step 5.2 package.
* Response data at HR = roundup((size+2)·32, 4 KB), after the summary record [size] and the
  traffic record [size+1], as DOMA.

### Init launch and geometry

* **The init launch (size = 0) only latches the pages address and reports the geometry.** It
  touches no memory. The zero-fill of the tree moved to the first launch with size > 0 (in the
  host flow, the first preload batch, so it still counts as initialization), followed by Tiny
  ORAM's release from reset.
* **Record [size+1] bytes 24–31** (zero for DOMA): bytes 24–27 the build's N (blocks), bytes
  28–31 the tree size in 64-byte bursts (a 32-bit byte count would overflow above 4 GB).
* The testbench checks both fields, and that the init launch issued no AR or AW on the tree port.

### Host (`vitis/host_doma.cpp`, shared)

Additive; without the new option or variable the DOMA path is unchanged (checked: identical
output to the step 5.2 host against a functional mock of XRT, with and without `DOMA_N`,
`DOMA_BLOCK`, `DOMA_PACK`, `DOMA_PAGES_HBM`).

| Item | Behaviour |
|---|---|
| Kernel selection | `./host_doma <xclbin> [CMD_SIZE] [--kernel tinyoram_kernel]`, or `DOMA_KERNEL=tinyoram_kernel`. Default `doma_kernel`. |
| Arguments | DOMA: 8 (cmd, resp, pages, size, meta, brec, stash, nblk). Tiny ORAM: 4 (cmd, resp, pages, size). meta/brec/stash are allocated only for DOMA. |
| `DOMA_N` | Records, for both kernels. For Tiny ORAM the host derives L (smallest with 4·2^L ≥ N) and refuses a bitstream with a different N, naming the L it needs. Unset: the bitstream's N. |
| `DOMA_BLOCK` | Sizes Tiny ORAM's tree buffer before the first launch (default 4096, which covers every block size at the same L). If the bitstream's tree is larger than the buffer, the host stops and prints the `DOMA_N`/`DOMA_BLOCK` to use. |
| `DOMA_PACK` | Refused for Tiny ORAM until Phase 2. |
| Output | Tiny ORAM prints its geometry after init, and per run the three latencies: data ready, last write-back beat, write-back acknowledged (min..max). The traffic line prints for both kernels. |

The host's tree-size formula is a port of Tiny ORAM's `BucketLocal.vh`; it matches the RTL's
own value at 64 B, 128 B, 256 B and 4 KB for L = 6, 14, 18 and 22 (16 points).

### Build scripts

* `fetch_tinyoram.sh <size> [L]`: optional tree depth (6..26), written into the build's
  configuration header. The default stays L = 6.
* `build_tinyoram.sh`: `N=<records>` picks L (one bitstream per N; xclbin
  `tinyoram_<size>_n<N>_<target>.xclbin`), passes the same post-placement hook as `build.sh`
  (`post_place.tcl`, hardware builds only), and prints the host command with the matching
  `DOMA_KERNEL`, `DOMA_BLOCK`, `DOMA_N` and (for `tinyoram_hw.cfg`) `DOMA_PAGES_HBM=1`.
* `check_timing.sh` / `worst_paths.tcl` (shared): `XCLBIN` and `XDIR` overrides (defaults
  `doma_hw.xclbin`, `_x`), kernel-name-neutral path names; `WANT_MHZ` was already there.

### Tree sizes (bytes, from the RTL)

| Block | L = 6 | L = 14 | L = 18 | L = 22 |
|---|---|---|---|---|
| 64 B | 49,536 | 18,923,904 | 207,667,584 | 4,032,872,832 |
| 128 B | 123,520 | 23,634,560 | 505,979,520 | 5,539,144,320 |
| 256 B | 185,472 | 38,966,400 | 642,946,176 | 10,910,602,368 |
| 4 KB | 3,517,056 | 901,769,856 | 14,428,400,256 | 230,854,486,656 |

An HBM pseudo-channel holds 512 MB, so with the tree in HBM[8] the unpacked 64 B build tops
out at L = 18 (1M blocks). With 8 records per block (Phase 2), 1M records need L = 15 and 10M
records L = 19, both within one bank.
