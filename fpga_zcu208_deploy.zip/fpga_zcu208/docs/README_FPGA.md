# ZCU208 ORAM: security fixes

The ZCU208 set is a smaller, earlier architecture than the gem5 RTL:
- on-chip BRAM stash, position map, IV table and bucket metadata;
- one AXI master to DDR4;
- 512 slots × 4 KB, 8 slots per bucket, 64 buckets.

The crypto engine, AXI master, bucket metadata and lease table are byte-identical to the gem5
originals. The controller and top level are different code. So the gem5 fixes are ported here, not
patched in.

Work proceeds in phases. Each phase is verified with your `tb_onboard_test_top` (53 tests) under
Icarus. The baseline (unmodified) passes all 53.

## Security audit

**Critical: crypto and integrity**

| # | Finding | Status |
|---|---|---|
| F1 | Public NIST test key `2b7e1516…09cf4f3c` hard-coded in `onboard_test_top`, plus a fixed IV seed. The GCM engine derives every IV from the seed (internal LFSR), so every boot replays the same IV sequence. | **Phase 1:** key/seed now enter through `key_load` (latched once per boot; nothing runs before it). Per your decision, LFSRs stand in for a TRNG for now, so the seed stays deterministic and the cross-boot IV repeat remains a known limitation of the evaluation build (see below). |
| F2 | GHASH pending-FIFO overflow (same engine as gem5): most of each 4 KB block is left out of the tag, so tags are not standard GCM and most of each block is unauthenticated. | **Phase 1: fixed** |
| F3 | Decrypted plaintext is streamed to the client and the stash before the tag is checked. | **Phase 2: fixed** (results buffered; released only after all 8 positions verify, at a fixed time) |
| F4 | `err_tag_mismatch` is cleared at the start of every access, and the controller keeps running. | **Phase 1: fixed** (sticky, fail-stop) |
| F5 | Only the target slot is verified: tampered holes or other slots go unnoticed (occupancy oracle). | **Phase 2: fixed** (all 8 positions verified every access) |
| F6 | Only changed slots are re-encrypted, so the ciphertext diff reveals what changed. | **Phase 2: fixed** (all 8 positions re-encrypted with fresh IVs; whole bucket written back) |
| F7 | DDR is initialized with a plaintext counter pattern, not ciphertext. | **Phase 2: fixed** (boot-time encrypted format pass) |
| F8 | Latency differs per access path (read/write × bucket/stash hit). | **Phase 2: fixed** (every path 10,232 cycles in simulation) |

**Medium**

| # | Finding | Status |
|---|---|---|
| F9 | Fixed-priority client arbiter: starvation and a cross-client timing channel. | **Phase 3: fixed** (time-division arbiter + dummies; non-interference verified) |
| F10 | No lease lock-out. | **Phase 1: fixed** |
| F11 | Per-path perf counters, live FSM state, and PRNG override inputs exposed. | **Phase 1: fixed** (secure-build switch) |
| F12 | 9-bit slot IDs with N = 512: possible top-slot / empty-marker aliasing. | **Phase 2: verified not an issue** (slot list is compacted by fill count; no zero marker; 9 bits cover 0–511) |
| F13 | LFSR for remaps and 32-bit LFSR lease tokens. | Deferred, as on gem5 (needs a CSPRNG/TRNG) |

**Test integrity**
- The testbench forced `val_valid = client_req`, so lease validation never ran in simulation.
- T46 (wrong token) and T47 (revoked lease) were auto-passed without running.
- **Phase 1: fixed.** Both now run against the real lease table.

## Phase 1 changes

| File | Change |
|---|---|
| `aes_gcm_pipelined.v`, new `ghash_lane3.v` | The fixed engine from gem5 Rev 4 (GHASH FIFO fix with input backpressure, 3-lane GHASH, cached H). Same ports. |
| `flat_oram_gcm.v` | Tag mismatch sets a sticky error and enters `S_HALT` (code 28): no completion, no data, until reset. Stash overflow is sticky too, and no access is accepted after either error. |
| `secure_oram_top.v` | **F1:** new `key_load` input and `key_ready` output. Key and seed are latched once per boot; an all-zero key is refused; nothing is accepted until loaded. **F10:** new `client_lockout` output; lock-out after 4 rejected requests, cleared by GRANT/RENEW. **F11:** without `ORAM_DEBUG_PORTS`, all `perf_*` outputs, `dbg_oram_state` and `dbg_gcm_tag_*` read 0, and `dbg_prng_override` / `dbg_force_same_bucket` are ignored. |
| `onboard_test_top.v` | Pulses `key_load` after reset. Refuses to compile with `ORAM_SECURE_BUILD` (it carries the public test key). T46 and T47 are real tests. A new re-grant step restores client 0's lease after T47 so later tests can use it. |
| `tb_onboard_test_top.v` | The lease-bypass force now exists only under `XSIM_FORCE_LEASE_VALID`. That define disables lease checking, so prefer fixing the XSim issue to using it. |

## Build defines

- **Self-test / simulation:** `SIMULATION ORAM_DEBUG_PORTS`. The self-test steers remaps with
  `dbg_prng_override` and reports perf counters, so it needs the debug ports.
- **Production:** `ORAM_SECURE_BUILD`, without `ORAM_DEBUG_PORTS`, and a production top in place of
  `onboard_test_top`.

## Verification (Icarus, `-DSIMULATION -DORAM_DEBUG_PORTS`)

- **Baseline:** 53/53.
- **Phase 1:** 53/53, now including real lease validation and the real T46/T47.
- **Production configuration** (`ORAM_SECURE_BUILD`, ORAM only): compiles with Icarus and Verilator
  lint (0 errors).
- **The onboard test top in secure mode fails to compile, by design.**

Not done here: Vivado synthesis and timing. The new GHASH lanes and the key latch add logic, so
re-check timing at your target clock.

## Key and IV seed (F1): LFSR stand-in

There is no entropy source on this platform, so (as decided for the gem5 work) LFSRs stand in for a
TRNG for now: for the remap bucket choice, for lease tokens, and for the key/IV seed.

- **Within a boot:** IVs are unique. The engine's 96-bit IV LFSR advances once per encryption.
- **Across boots:** the seed is deterministic, so the same IV sequence repeats under the same key. This
  is a known limitation of the evaluation build. It matters only to an adversary who keeps ciphertext
  from an earlier boot. State it in the paper alongside the LFSR stand-in.
- **What Phase 1 changed:** the key and seed now enter through one place (`key_load`, latched once per
  boot). A real TRNG, or a persistent boot counter mixed into the seed, can later replace the stand-in
  there without touching the controller.
- **The `ORAM_SECURE_BUILD` guard** only stops the onboard test top, with its public key, from being
  built as a production image. It does not affect the self-test build.

## Next phases

- **Phase 2: done**, including the random initial layout (see below).
- **Phase 3:** the time-division arbiter with dummy accesses, plus the non-interference test (gem5 Rev 9).

## Phase 2: controller restructure (F3, F5–F8)

`flat_oram_gcm.v` has a new FSM, modeled on gem5 Revs 1–2. The module ports are unchanged apart from
two new outputs, and the submodules are reused as they are.

### Access flow

1. **Accept** the request and start the cycle counter.
2. **Position lookup.**
3. **At `CT_RD`:** read bucket metadata and the whole bucket (8 × 4 KB) into the scratch buffer.
4. **Decrypt and verify all 8 positions in place.** The IV and tag come from the IV table, now keyed
   per (bucket, position) through the pseudo-address `(b·8 + pos) << 12`, so holes are covered too.
   Any mismatch sets `err_tag_mismatch` and halts.
5. **Operation on plaintext.**
   - The target always moves to the stash, remapped; the vacated position is filled by moving the last
     valid entry into it.
   - Reads copy the data into a 4 KB result buffer; writes take client data into the stash.
6. **Evict** stash entries that target this bucket into the free positions.
7. **Re-encrypt all 8 positions** with fresh engine IVs and record each IV and tag.
8. **At `CT_WB`:** write back the whole bucket.
9. **At `CT_DONE`:** stream the result buffer (a silent window of the same length for writes), then
   signal completion.

### Boot-time format pass (F7)

Once a key is loaded, every position of every bucket gets an encrypted zero block and an IV/tag entry,
replacing the plaintext DDR pattern. The new output `oram_ready` (= key loaded and formatted) gates
client accesses. It takes a few milliseconds at boot.

### Fail-stop

Tag mismatch, stash overflow and timing-gate overrun are all sticky and all halt the controller
(`S_HALT`). Overrun is reported on the new output `err_ct_overrun`.

### Timing budgets (`oram_params.vh`, override with `-D`)

| Gate | Value | Basis |
|---|---|---|
| `ORAM_CT_RD` | 16 | Arrival 2 |
| `ORAM_CT_WB` | 8,500 | Analytic worst case ~7,690 with 8 evictions, plus margin |
| `ORAM_CT_DONE` | 10,100 | `CT_WB` + write-back ~1,387, plus margin |

**These are calibrated on the testbench's DDR model. Recalibrate on the board:** build with all three
set to 0, run a stress workload, and read the internal maxima `ct_max_rd`, `ct_max_wb` and
`ct_max_done` (for example via ILA). An undersized budget halts with `err_ct_overrun` instead of leaking
timing.

### Cost

| Design | Per-access latency (simulation cycles) |
|---|---|
| Original | 2,946 to 3,515, depending on path (the leak) |
| Phase 2 | 10,232 on every path |

About 3× slower: every access now does 16 full-block GCM operations instead of 1–2, plus padding.

### Self-test and testbench changes

- `onboard_test_top` waits for `oram_ready` before its first test. Its first request used to arrive
  during the format pass and be dropped; real clients must wait for `oram_ready` the same way.
- The testbench prints gate arrivals and error flags at the end of a run.
- New tamper modes: `+tamper_hole` (flip one bit in bucket 0, position 5, a hole) and `+tamper_target`
  (bucket 0, position 0).
- Waveform dumping now requires `+define+DUMP_VCD`. Each run otherwise wrote a ~700 MB VCD.
- The long timeout delay is now 64-bit, so the testbench also runs under Verilator.

**Use Verilator for the full suite.** With 16 crypto operations per access, Icarus is now too slow
(hours). The command:

```
verilator --binary --timing -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY \
  -Wno-INITIALDLY -DSIMULATION -DORAM_DEBUG_PORTS --top-module tb_onboard_test_top -I. *.v -Mdir vobj -o Vtb
./vobj/Vtb                   # 53 tests
./vobj/Vtb +tamper_hole      # must print TAMPER RESULT: DETECTED
./vobj/Vtb +tamper_target    # must print TAMPER RESULT: DETECTED
```

### Phase 2 verification (Verilator)

- **Original design:** 53/53 under Verilator as well, confirming Verilator as a reference.
- **Phase 2, gates off:** 53/53. No tag errors, no stash overflow, format complete.
- **Phase 2, gates on:** 53/53, no overrun, and every access path takes 10,232 cycles.
- **`+tamper_hole`:** detected, halted. **`+tamper_target`:** detected, halted.
- **Production configuration** (`ORAM_SECURE_BUILD`): Verilator lint 0 errors; Icarus compiles.
- **Not done:** Vivado synthesis and timing. The new 4 KB result buffer is written in its own clocked
  block so it can map to BRAM.

### Still open (after Phase 2)

Superseded: the random layout and Phase 3 are both done; see the sections below.

### Files

- `rtl/`: the full set, with CRLF line endings.
- `fpga_phase2.patch`: on top of Phase 1.
- `fpga_cumulative.patch`: against your originals.

All patches use LF line endings and were apply-tested.

## Phase 2b: random initial layout

The controller now owns the layout. After the format pass, a new state `S_LAYOUT` gives every slot an
independent random bucket in the position map, with status "never written", and clears all bucket
metadata. This is **lazy placement**:
- a slot occupies a real position only once it is written (through the stash and eviction);
- utilization starts at zero;
- no permutation table is needed;
- every slot's first access reads a random, secret bucket.

Whatever a top wrote through `init_mode` beforehand is overwritten. In secure builds `init_mode` is
ignored altogether.

Fixed along the way:
- **Read-miss linkability (a bug in my Phase 2).** A read of a never-written slot returned zeros but
  did not remap the slot, so a second read touched the same bucket and revealed the repeat. It now
  remaps.
- **PRNG decorrelation.** The 12-bit LFSR (the agreed TRNG stand-in) is stepped 6 extra times after
  every use, so consecutive bucket choices don't share bits. 512 slots × 6 steps stays within its
  period of 4,095.

Self-test: the 33 test slots land in 29 distinct buckets (a uniform random assignment gives ≈ 27);
53/53 pass. The tamper modes now locate the bucket of the first test's slot in the position map.

## Phase 3: static time-division arbiter with dummy accesses (F9)

This is gem5 Rev 9, including its audit fixes, ported to the ZCU208 top.

**Top level**
- The fixed-priority arbiter is replaced.
- **Frame configuration** (`cfg_tdm_slot_cycles`, `cfg_tdm_frame_len`, `cfg_tdm_owner`,
  `cfg_tdm_owner_valid`) is latched once, on the first cycle after reset.
- **Slots start automatically when `oram_ready` rises** and never stop.
- **Per-client intake.** The lease check and lock-out happen on arrival. Each client has its own 4 KB
  write buffer with its own write port, and a write becomes eligible only once its buffer is full.
- **Slot-start decision:** the owner's request runs if, and only if, that owner has one complete;
  otherwise a dummy runs. The decision reads nothing else.
- `err_slot_overrun` (sticky): the controller was busy at a slot start.

**Controller:** a new `client_dummy` request type.
- It picks a random bucket at accept.
- It then runs the identical path: read gate, verify all 8, evict, re-encrypt all 8, write-back and
  completion gates.
- It returns no data, no completion and no performance counts.

**New outputs**
- `client_ready[i]`, `client_wbeat_req[i]`.
- `oram_beat_cnt` keeps its single-client meaning: the beat the filling client should present.
- `oram_busy` now means "a client request is pending".
- `dbg_slot_*` and the real/dummy counters exist only in debug builds.

**Slot length:** default `ORAM_TDM_SLOT` = `CT_DONE` + 2·128 + 48 = 10,404 cycles. With K = 2, an
unloaded client waits about T on average for its slot, plus about T of service.

**Self-test fix (important):** in simulation, `onboard_test_top` took its write-data beat from a
hierarchical reference to the controller's internal `beat_cnt`, while hardware used the
`oram_beat_cnt` port. **The simulation was exercising a different path from the hardware.** Both now
use the port, which under Phase 3 is the only correct source.

### Non-interference test (`tb_ni.v`, new)

Two clients drive `secure_oram_top` directly through an in-order AXI memory model.
- Client 1 replays a fixed trace: each request is issued a fixed, seeded gap after its own previous
  completion.
- Client 0 is idle (`+ni=0`), saturating (`+ni=1`), random (`+ni=2`) or bursty (`+ni=3`).
- Every read is checked against the last value written. Client 1's request and completion cycles,
  relative to `oram_ready`, are hashed.

| Client 0 | Phase 2 (fixed priority, `-DOLD_ARBITER`): client-1 latency min/mean/max | Phase 3 |
|---|---|---|
| idle | 10,234 / 10,234 / 10,234, hash `29873036…` | 17,749 / 19,018 / 20,420, hash `4e88d80d…` |
| saturating | **starved**: 0 ops in 2M cycles while client 0 did 195 | identical |
| random | 10,234 / 14,654 / 20,429, hash `91b3247d…` | identical |
| bursty | 10,234 / 17,089 / 50,973, hash `e745541a…` | identical |

Phase 3 gives the same hash for all four behaviors, with 0 data errors for both clients.

```
verilator --binary --timing -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY \
  -Wno-INITIALDLY -DORAM_DEBUG_PORTS --top-module tb_ni -I. tb_ni.v <synthesizable .v files> -Mdir vni -o Vni
for v in 0 1 2 3; do ./vni/Vni +ni=$v +ops=10; done      # identical trace-hash = pass
```

### Phase 3 verification (Verilator)

- **Self-test:** 53/53. 86 real and 87 dummy slots, no slot overrun, every path 10,232 cycles of
  service.
- **Tamper:** both modes detected and halted, with dummies running.
- **Non-interference:** as above, with the negative control showing both the starvation and the
  timing channel on the old arbiter.
- **Production configuration** (`ORAM_SECURE_BUILD`): Verilator lint 0 errors; Icarus compiles.
- **Not done:** Vivado synthesis and timing. The two 4 KB intake buffers read combinationally, so they
  map to LUT-RAM.

### Integration checklist for a production top

1. Provision the key and IV seed and pulse `key_load` once per boot (LFSR stand-in for now).
2. Drive the frame configuration before reset is released. Do not drive `init_mode`; the controller
   owns the layout.
3. Wait for `oram_ready` (format and layout take a few ms), then let clients issue requests.
4. Each client: one outstanding request; check `client_ready[i]` before pulsing `client_req[i]`;
   present write data for beat `client_wbeat_req[i]` while holding `client_wdata_valid[i]`.
5. Treat `err_tag_mismatch`, `err_stash_overflow`, `err_ct_overrun` and `err_slot_overrun` as fatal.
6. Recalibrate `ORAM_CT_*` on the board (and with them `ORAM_TDM_SLOT`).
7. The deferred limitation stays: LFSR stand-ins for the PRNG, tokens and seed.

### Files (final)

- `rtl/`: full set, CRLF, now including `tb_ni.v`.
- Patches: `fpga_phase1.patch`, `fpga_phase2.patch`, `fpga_phase2b_layout.patch`,
  `fpga_phase3.patch`, and `fpga_cumulative.patch` (against your originals). All use LF line endings;
  the chain and the cumulative patch were both apply-tested to reproduce the tested files.

## Audit (after Phase 3)

Method:
- Full-warning lint of the lines changed from your originals, in debug, production and 3-client builds.
- A check that every register feeding a submodule is still driven by the new FSM.
- New dynamic tests: AXI backpressure, a forced 8-eviction worst case, and a functional run of the
  production configuration.

### Bugs found and fixed (`fpga_audit.patch`)

1. **Stash data addressing (pre-existing in your `stash.v`; corrupts data on hardware).**
   - The data address was `{entry, beat}` with the beat field `BEAT_W = BEAT_CNT_W` = 10 bits, so the
     address was `entry × 1024 + beat`. The memory is `DEPTH × BEATS` = 8,192 beats.
   - For entries 8 and up, the address runs off the end and wraps: entry 8 aliased entry 0, entry 9
     entry 1, and so on. **The stash could hold the data of only 8 blocks, although its metadata tracks
     64.** A 9th block silently overwrote another block's data.
   - Your original self-test never had more than 8 blocks in the stash, so it never showed. Found with
     the new stress test: a read of slot 1 returned slot 9's data.
   - Fixed: the address uses only the low `$clog2(BEATS)` = 7 beat bits.
2. **Eviction stopped after one block (my Phase 2 code).**
   - After each eviction the stash masks the evicted entry for one cycle (`cam_bkt_inhibit_busy`). My
     loop took that as "no more candidates" and stopped.
   - So at most one block was evicted per access. The stash drained far too slowly and, over time,
     could overflow, which is fail-stop.
   - Fixed: the loop waits out the inhibit cycle. The stress test now sees 8 evictions in one access.
3. **Testbench memory model (my `tb_ni.v`).** It applied write data to the oldest pending address.
   Under backpressure, data can be accepted before its address, and the model then wrote to the wrong
   place, producing a false tag mismatch. It now buffers write data as a real controller does.

With both RTL fixes, the worst-case write-back arrival (8 evictions) is **7,239 cycles**, within the
8,500 budget (the analytic estimate was about 7,690).

### Verified clean

- **Lint:** only benign warnings on changed lines (implicit widenings, intentional blocking
  temporaries). The 3-client build elaborates.
- **Submodule inputs:** none is left wired to a register only the old FSM drove. The slot CAM is fed
  directly by `req_slot_addr`.
- **Backpressure:** 30% ready-low plus read gaps, with both clients active: no data or integrity errors.
- **Production configuration:** behaves identically to the debug build (same non-interference hash).

### Parameter limits to keep in mind

- The layout pass's slot counter is 10 bits (N ≤ 1024).
- The stash data address assumes `BEATS` is a power of two.

Both hold for this configuration (N = 512, 128 beats per block).

## Simulation kit (`sim/`)

`sim/README_SIM.md` describes every check. In short:

```
cd sim
bash run_verilator.sh      # full regression, PASS/FAIL per check, exit code (about 5-10 min)
bash run_icarus.sh         # compile check (Icarus is too slow to run the suite)
bash run_xsim.sh           # Vivado XSim flow (not run here; first run is a bring-up)
```

Final regression on the shipped files (CRLF RTL, run through `run_verilator.sh`): **ALL CHECKS
PASSED.** That covers:
- self-test 53/53;
- both tamper modes;
- non-interference (identical hash `4e88d80d…` across four client-0 behaviors);
- the worst case, gated and calibrated;
- backpressure;
- the production configuration.

## Crypto streaming (after the audit)

Each access used to wait for the whole 32 KB bucket before decrypting, and for all 8 positions to
be encrypted before writing back. Both now overlap.

**Read side.** Decryption starts at the read gate. Position *p* is verified as soon as its 128
beats have landed (`landed_beats`), while the rest of the bucket is still arriving. This is purely
on-chip, so the DDR trace is unchanged.

**Write side.** The write-back starts at exactly `CT_WB` while later positions are still being
encrypted. Safety does not depend on the budget being right:
- **No plaintext can reach DDR.** The AXI master has a new `wdata_hold` input and never issues a
  scratch read for a position that isn't fully re-encrypted (`enc_pos_done`). This holds by
  construction, even with a wrong budget.
- **A budget that is too early fails loudly.** If the write-back ever has to wait for the
  encryption, the master reports `wdata_stall`, which sets `err_ct_overrun` (fail-stop), because a
  gap would make the W-channel timing depend on hidden work.
- **Scratch banking.** The scratch buffer is now 8 per-position banks, each with its own read and
  write port, so the DDR stream, the crypto engine and the write-back can use different positions in
  the same cycle. A bank conflict is impossible by design; if one ever happened it would also be
  fail-stop (`bank_conflict`).
- **Simulation safety monitor.** It reports any write-back read of a position that isn't yet
  encrypted. The regression fails on any such report.

**Budget rule for `CT_WB`.** The write-back may start up to 7 × 128 = 896 cycles before the worst
encryption end, because the master needs that long to reach the last position:

    CT_WB >= worst encryption end - 896  (+ margin)

**Results (simulation DDR model, 300 MHz):**

| | Before | Streaming |
|---|---|---|
| Worst encryption end (8 evictions, gates off) | 7,239 | 6,188 |
| `CT_WB` / `CT_DONE` | 8,500 / 10,100 | 5,650 / 7,250 |
| Every access path | 10,232 cycles | **7,382 cycles (-28%)** |
| Slot length (`ORAM_TDM_SLOT`) | 10,404 (34.7 µs) | 7,554 (25.2 µs) |

All regression checks pass. That includes a **negative control**: a write-back budget 1,500 cycles
too early is caught as an overrun, and the write-back never reads an unencrypted position.

**Cost.** The banked scratch uses about 32 BRAM36 instead of about 8, because 128-deep banks
underuse each BRAM.

The **gem5 RTL does not have this change yet.**

## Eviction overlap

Each eviction used to copy its 4 KB block from the stash into the bucket (~135 cycles) before the
next eviction, and encryption waited for all of them. Now:

- **The eviction loop only decides**: which stash entry goes to which position, plus the slot-list,
  position-map and stash updates. That takes about 4 cycles per eviction.
- **A background engine performs the copies**, one beat per cycle, through a new eviction write port
  on the scratch buffer.
- **Encryption of a position waits only for that position's own copy** (`ev_pending`). Copies (~135
  cycles each) are faster than encryption (~302 per position), so after the first position
  encryption effectively never waits.
- **Reading freed stash entries is safe.** The engine reads entries the eviction loop already marked
  free. Nothing is inserted into the stash between eviction and the end of the access, and the access
  cannot finish before every copy has.

This is on-chip only. DDR traffic and the fixed timing gates are unchanged.

**The worst case moved.** With copies hidden, the 8-eviction access is no longer the slowest. The
slowest accesses now do two data copies before eviction can start (for example, a bucket-hit write
with compaction). So the regression now calibrates against the worse of the 8-eviction stress test
and the full self-test.

| Worst encryption end (gates off) | Streaming only | + eviction overlap |
|---|---|---|
| 8-eviction stress | 6,188 | 5,245 |
| All paths (self-test) | below stress | **5,300** (now the worst) |

**Results (simulation DDR model, 300 MHz):**

| | Before streaming | Streaming | + Eviction overlap |
|---|---|---|---|
| `CT_WB` / `CT_DONE` | 8,500 / 10,100 | 5,650 / 7,250 | **4,700 / 6,300** |
| Every access path | 10,232 cycles | 7,382 | **6,432** |
| Slot length | 10,404 (34.7 µs) | 7,554 (25.2 µs) | **6,604 (22.0 µs)** |

All regression checks pass, including the early-budget negative control and the safety scan.

## Performance phase = the paper's FPGA workload

The self-test's performance phase (T49–T53) now runs the workload of the paper's Section IV-B and
Table IV:
- **100 random slot writes, then 100 reads of the same slots,** through client 0.
- **Slots are 100 distinct indices in 1–255**, inside client 0's lease. They come from an 8-bit
  maximal-length LFSR with seed `0xA5`, so the run is reproducible.
- **`PERF_N` in `onboard_test_top.v`** sets the count.

It replaces the earlier 40-operation phase (20 reads, then 20 writes over 10 fixed slots).

**Result (simulation DDR model, 300 MHz):**
- **All 200 operations take 6,432 cycles (21.4 µs)**, identical on every path. The original design
  averaged 2,899 cycles (9.7 µs) on hardware (Table IV).
- **Split, by where each block was found:** reads 100 (97 in a bucket, 3 in the stash); writes 100
  (3 in a bucket: slots 7, 9 and 11, written earlier by tests T1–T48; 97 to never-written slots).
- **Categories now distinguish never-written slots** (WRITE/NEW, READ/NEW). Earlier reports counted
  them under "stash", which made "WRITE/STASH 97" look like 97 stash hits. In the original design
  never-written slots were pre-placed in buckets, so the same writes appeared as Wr/Bkt (86 in
  Table IV).
- **Why only 3 reads find the block in the stash:** a block leaves the stash when any access (real
  or dummy) touches its target bucket. With about 200 accesses between a write and its read, about
  (63/64)^200 ≈ 4% are expected to still be in the stash.

**For the paper:**
- **Report one per-access number,** since every path now takes the same time. The per-phase rows
  attribute overlapped work to the controller state it happens in, so they no longer mean what their
  labels say.
- **Crypto counts:** every access now decrypts and encrypts all 8 positions, so 1,600 of each over
  200 operations, plus the dummies' (the paper's text says 76 encryptions and 40 decryptions).

**Configuration differs from Table II:** `oram_params.vh` has N = 512 and stash depth 64; the paper
lists N = 256 and stash 128. The workload stays within 256 slots.

## Derived worst case for the timing budgets

The budgets are now justified by a derivation, not by the slowest access seen in some test.

**Method (`sim/worst_case.py`, `sim/oram_timing_monitor.v`).** Every access is cut into segments
at fixed milestones. A cycle model states that each on-chip segment depends only on the access's
path features, and it is **checked against every traced access**: 912 accesses from the self-test
(the paper workload) and from directed constructions of every candidate worst path. Then every
feature combination the controller allows is enumerated.

**The validated cycle model** (cycles from access start):

| Segment | Cycles | Determined by |
|---|---|---|
| read issued | 17 | gate (`CT_RD`) |
| first position landed | memory-dependent (`tb_ni` model 153, self-test model 151–240) | memory |
| rest of verification | 2,416 | fixed: crypto-bound, 8 × ~302 |
| operation phase | 2 (dummy, read of a never-written slot), 132–136 (1 copy), 265–267 (2 copies) | path, copies |
| eviction decisions | 2 + 4 × evictions | eviction count |
| wait for the first eviction copy | 133 − 4 × evictions if position 0 receives an eviction, else 2 | fill, evictions |
| encryption | 2,399 | fixed |

**Worst on-chip combination: 299 cycles.** It is a read (or write) that finds its block at
position 0 of a bucket holding 2 blocks (compaction, so 2 copies), followed by 7 evictions. This
beats the bucket-left-empty cases (1 copy + 8 evictions + the first-copy wait = 271).

**Derived worst encryption end:**

| Memory model | Derived bound | Slowest traced access | Deadline (`CT_WB` + 896) | Margin |
|---|---|---|---|---|
| `tb_ni` model | **5,284** | 5,284 (directed test reaches the bound) | 5,596 | 312 |
| self-test DDR model | **5,371** | 5,343 | 5,596 | 225 |

On the self-test's model the bound is 28 cycles above anything a single run produced: the slowest
memory timing and the slowest on-chip path never coincided. A purely empirical calibration would
have missed this.

**On the board**, only the memory terms change; the on-chip model does not depend on memory.
Measure the worst first-position landing time and the write-back duration (ILA), then:

    CT_WB   >= 17 + (max first-position landing) + 2,416 + 299 + 2,399 - 896  (+ margin)
    CT_DONE >= CT_WB + (max write-back duration)                               (+ margin)

The verification term (2,416) assumes DDR delivers each 4 KB position within one position's
decryption time (~302 cycles), which the ZCU208's DDR4 does with large headroom.

## Paper configuration and random boot layout

**Configuration.** The RTL now uses the configuration of the paper's Table II and of the board build
that produced Table IV:
- N = 256 slots, 64 buckets of Z = 8 positions;
- `ORAM_C` = 4 real slots per bucket (4 slack), `SLOT_ID_W` = 8;
- stash depth 64.

`ORAM_C` now means real slots per bucket; it used to mean total capacity.

**Random boot layout.** After the format pass, the controller places every slot at a uniformly
random position, 4 per bucket, using an inside-out Fisher–Yates shuffle (`S_SHUFFLE`, then
`S_LAYOUT`). The random numbers come from a 16-bit LFSR seeded from the per-boot IV seed, a stand-in
for the TRNG like the other generators. This replaces the lazy layout, which kept never-written
slots out of the buckets. Now:
- every slot starts valid, and its data reads as zeros until written;
- the starting occupancy matches the paper's configuration (4 slots + 4 slack);
- the initialization is the same as the gem5 version (Fisher–Yates);
- the categories mean the same as in Table IV (a first write finds its slot in a bucket).

**Bug fixed along the way: IV table sizing.** Since Phase 2 the IV table is indexed by
`{bucket, position}` (B × Z = 512 entries), but its depth came from `ORAM_N`. The two were equal only
when N was 512. With N = 256, buckets 32–63 aliased onto 0–31, and the first access failed
authentication and halted. The table is now sized `B * Z`, independent of N.

**Self-test order.** The self-test no longer writes its own layout through `init_mode`, which would
overwrite the random layout. It runs **the paper's Table IV workload first, from the fresh boot
state**, then T1–T48:
- 100 writes to random slots (16-bit LFSR, seed `0xA5C3`, repeats allowed), then 100 reads replaying
  them;
- the counter outputs are latched when the performance phase ends, so the board reports only those
  200 operations.

The same workload on your original board RTL reproduces Table IV exactly in simulation
(40/60/86/14, 40 decryptions, 76 encryptions).

**Result on the secured design.** Every operation takes 6,432 cycles (21.4 µs at 300 MHz). The split
is Rd/Bkt 90, Rd/Stash 10, Wr/Bkt 96, Wr/Stash 4. Dummy accesses in idle windows move waiting blocks
out of the stash faster than in the original design, so fewer accesses find their block there.

**Tests.** `tb_ni`'s stress and directed worst-case scenarios first empty their target bucket
(`drain`). The worst-case analysis treats dummy accesses as having no data operation: with every slot
placed, a dummy's lookup of slot 0 can report a bucket hit, which the controller never acts on. The
derived worst case is unchanged (299 on-chip cycles; bounds 5,284 and 5,371 against 5,596).

## Two clients, one ORAM each (Z = 6, λ = 4)

**Configuration** (`oram_params.vh`):
- each client has its own ORAM: 256 slots, 64 buckets and its own 128-entry stash;
- every bucket has 6 positions: λ = 4 real slots plus 2 slack;
- **the clients never share a bucket**.

| | Client 0 | Client 1 |
|---|---|---|
| Slots (lease range) | 0–255 | 256–511 |
| Buckets | 0–63 | 64–127 |
| Stash | 128 entries | 128 entries |

`ORAM_PART_W = 1` selects two partitions. The access's partition comes from the top bit of its slot
number, which the leases already restrict.

**What the controller does per partition:**
- The boot layout shuffles each client's slots into that client's own buckets.
- Remap targets, and the debug remap override, stay inside the partition.
- Each partition has its own stash instance. The access's partition selects it for every lookup,
  insert, remap, eviction and data transfer.
- **Dummy accesses stay in the window owner's partition.** The top level gives a dummy window the
  first slot of its owner's range. A dummy that touched any bucket would be distinguishable from a
  real access by its bucket number; inside the owner's partition, every window, real or dummy, reads
  a random bucket of its owner. The owner itself is public from the fixed schedule.

**Bugs fixed for Z = 6 and B = 128:**
- **IV table:** it is indexed by the concatenation {bucket, position}, so it needs B × 2^POS_W =
  1,024 entries, not B × Z.
- **Simulated DDR (both testbenches):** sized by the 32 KB bucket stride, not the 24 KB bucket size.
- **Hard-coded 8-position constants** in the monitors, the report, the regression and the stress
  check.
- **`tb_ni`'s bucket-emptying helper** now issues each slot through its owning client.

**Timing (derived worst case, the cycle model checked on every traced access):**
- worst on-chip path 291 cycles; bounds 4,072 (reached) and 4,160;
- `CT_WB` = 3,820, `CT_DONE` = 5,160;
- **every access takes 5,292 cycles (17.6 µs at 300 MHz)**; a window is 5,464 cycles (18.2 µs);
- with two clients, a client gets one access per frame of 10,928 cycles (36.4 µs).

**The paper's workload on client 0's ORAM** (client 1 idle, its windows running dummies in its own
partition):
- Rd/Bkt 67, Rd/Stash 33, Wr/Bkt 92, Wr/Stash 8;
- every operation takes 5,292 cycles.

**Regression:** every check passes. The bus-timing check now also requires each window, real or
dummy, to read a bucket in its owner's partition.

**Resources:** two 128-entry stashes are 1 MB, about 32 of the ZU48DR's 80 UltraRAMs. The IV table
has 1,024 entries; the DDR footprint is 4 MB.

## Longer performance phase (200 writes, then 200 reads)

The self-test's performance phase length is now `SELFTEST_PERF_N` writes then the same number of
reads, defaulting to **200 + 200**. Set `SELFTEST_PERF_N=100` to reproduce the paper's original
workload.

Result on client 0's ORAM (Z = 6, λ = 4, client 1 idle):
- **the workload:** 200 writes to 133 distinct slots, so 67 writes repeat a slot;
- **reads** 149 in a bucket, 51 in the stash; **writes** 169 in a bucket, 31 in the stash;
- **every operation** 5,292 cycles.

**Eviction is complete.** In all 894 eviction loops of the run, none stopped while a block bound for
the bucket was waiting and the bucket had room. The 58 loops that left blocks behind did so because
the bucket was full.

**Stash occupancy.** Client 0's stash peaked at **60 of 128**, against 57 with 100 + 100. Occupancy
settles near (buckets) × (fraction of accesses that take a block out of a bucket) ≈ 64 × 0.8 ≈ 51,
instead of growing with run length. A 128-entry stash is therefore about 2.5× the typical level.
This measured peak is evidence, not a bound on the overflow probability.

## Audit after the two-client partitioning

**1. Cross-client access through an over-granted lease (security, fixed).**
- **The hole:** a client's partition was derived from the slot address, and the only admission check
  was the lease. Leases are created at the host's request, and the host is untrusted. So a host that
  granted client 0 a lease over client 1's slots let client 0 read and write client 1's ORAM.
  Demonstrated on the previous RTL: client 0 read client 1's slot 300 and got all 128 beats of
  client 1's data.
- **Also closed:** slot addresses beyond N aliased onto other slots (slot 512 onto slot 0).
- **The fix:** `secure_oram_top` admits a request from client c only if its slot is below N and in
  partition c, independent of the lease. A failing request counts as a violation, so repeated
  attempts lock the client out. A simulation check also requires NUM_CLIENTS = 2^`ORAM_PART_W`.
- **Regression:** `tb_ni +xpart` repeats the attack and must end with the request rejected.

**2. Boot layout assumed λ = 4 (latent, fixed).** The bucket index was a 2-bit shift
(`lay_i[BL_W+1:2]`), so any other λ would have placed slots in the wrong buckets. It is now `lay_i / C`.

**3. Write-back position decode used fixed bit positions (latent, fixed).** `[9:7]` assumed 128-beat
blocks and at most 8 positions. It now uses `[BEAT_AW +: POS_W]` from the parameters.

**Verified clean.** Lint shows nothing new in the changed code. The review covered:
- dummy addressing per partition;
- the two stashes (selection, overflow);
- eviction-copy completion within each access;
- the per-client slot ranges of every test.

The full regression passes.

## Single-client build (default)

The paper now claims one client, so the default build is one client with one ORAM:
- 256 slots in 64 buckets of Z = 6 positions (λ = 4);
- one 128-entry stash;
- **no arbiter, no window schedule, no dummy accesses.**

`-DORAM_TWO_CLIENTS` (in Vivado: a Verilog define on the project) restores the two-client build described
in the earlier sections.

**How accesses are issued.** An access starts as soon as a request is admitted and the previous access's
window has ended. Each access still occupies a fixed-length window (5,464 cycles), so its result returns a
fixed 5,292 cycles after it starts. A request's response time is therefore its wait for the previous window
plus that fixed time. The wait depends only on when the client's own requests arrive, which the host
already sees.

**What changed in the RTL:**
- **`oram_params.vh`:** the client configuration block (`ORAM_NUM_CLIENTS`, N, B, `ORAM_PART_W`, widths).
- **`secure_oram_top.v`:** with one client a window starts only when a request is ready, with no dummies.
  The client-ID ports are sized safely for one client. The admission check keeps slots inside the ORAM.
  A build whose client count does not match its partitions now stops the simulation.
- **`flat_oram_gcm.v`:** partition arithmetic in base-plus-offset form, which also works with no partitions.
- **`lease_token_table.v`:** the client-ID width is safe for one client.
- **`onboard_test_top.v`:** the client count follows the hardware; leases are granted only to existing
  clients; asking for more active clients than the hardware has stops the simulation.

**Results (single client, simulation):**
- **Self-test:** 50 tests pass, and the 3 that need a second client are skipped. 0 dummy accesses. Every
  access takes 5,292 cycles.
- **Performance phase (200 writes, then 200 reads):** reads 149 in a bucket, 51 in the stash; writes 174 in
  a bucket, 26 in the stash.
- **Full regression** (`bash run_verilator.sh`, single configuration): every check passes.
  - stress: 6 evictions in one access;
  - calibration: worst encryption end 4,124 against 4,460;
  - negative control caught;
  - backpressure clean;
  - production build identical;
  - bus timing: all 240 windows at offsets 20 and 3,824 with 0 dummies;
  - derived worst case 4,072 and 4,160 against 4,460.

## Read-after-write ordering fix (found through hardware emulation)

**The bug.** The AXI master treated a write as finished once its last data beat was accepted, and
drained the write responses in the background ("Opt 2"). The controller then completed the access,
and the next access could issue its bucket read while the previous write-back was unacknowledged.
AXI does not order a read against an unacknowledged write, so that read could return the old
ciphertext. Its tag check would then fail and the controller would halt (kernel error 0x8).

**Why no simulation caught it.** Every testbench memory model applied writes instantly. In hardware
emulation it surfaced as a halt after a few accesses. With writes landing 700 cycles after their
data, the old design reproduces it: 2 accesses complete, then an integrity failure.

**The fix:**
- `flat_oram_gcm.v`: an access reaches its done gate only when the write-back is complete **and**
  every write response has returned (`wr_quiet`). A slow acknowledgement is therefore a late arrival
  at `G_done`, detected as an overrun, so timing stays constant.
- `axi_master.v`: a read request that arrives while write responses are outstanding is held until
  they return. This covers the boot-time format pass.

With normal memory nothing changes: the timing hashes are identical to before the fix.

**Diagnostics.** In simulation and emulation only (excluded from synthesis), the controller prints
`DOMA HALT: <cause>` when it halts: timing overrun (with state, access cycle, budgets and pending
write responses), integrity failure (with bucket), or stash overflow.

**Tests.**
- `axi_mem_model.v` now respects reset, and `+host_wlat=N` makes writes land N cycles after their
  last data beat, so reads can overtake them.
- The kernel regression checks that writes landing 200 cycles late still give correct results, and
  that acknowledgements slower than the budget become an overrun, never stale data.
- Both configurations pass the full regression.

## Kernel boot fix: DOMA boots at the first ap_start (found through hardware emulation)

**The bug.** The wrapper loaded the AES key 8 cycles after reset, and DOMA then wrote its whole
bucket layout to `pages + offset`. That happens right after the xclbin loads, long before the host's
first launch sets the `pages` argument, which still reads 0. The first buckets therefore went to
device address 0 + offset: the wrong memory, possibly another buffer. Every access then worked until
one first read one of those buckets, which failed its tag check.

In emulation that was bucket 3 after 15 accesses. With the host's first launch delayed 20,000 cycles,
the testbench reproduces it exactly (old wrapper): 15 accesses, then an integrity failure on
bucket 3, with 6,144 beats written outside the buffer.

**The fix** (`doma_kernel.v`):
- DOMA's key is loaded, and its boot layout written, only at the **first ap_start**.
- The `pages` address is latched at that first start and used for the kernel's lifetime.
- A later launch naming a different `pages` buffer sets summary error `0x20`; the original buffer is
  kept.

**Why the testbench missed it, now fixed:**
- It launched the kernel about 60 cycles after reset. `+start_delay=N` now delays the first launch,
  and the regression checks a 20,000-cycle delay with 256 sequential PUTs.
- Its memory model truncated addresses before range-checking, so address 0 + offset aliased onto the
  buffer. It now checks the full 64-bit address, on every beat.
- `+host_rdy_gap=P` adds random pauses on the address and write-data channels, and the model now
  checks `wlast` framing and 4 KB crossings. DOMA passes all of them.

## Scratch-buffer banks as block RAM (found through the first U55C build)

The first board build failed timing badly: WNS = −8 ns at 300 MHz. Synthesis reported
`Infeasible attribute ram_style = "block"` for every `u_scratch/g_bank[*].mem`. Each bank was written
from three branches with different addresses and read from two. Synthesis therefore inferred three
write ports and two read ports, which no block RAM has, and built each bank (128 × 256 bits) from
registers with wide multiplexers. Each bank is now one write port and one registered read port (the
simple dual-port template), with the same priorities and the same read-before-write behavior.

The rewrite is behavior-identical: both regressions pass, with unchanged timing hashes, bus offsets
and derived worst case. The other RAMs were already single-write, single-read templates: the IV/tag
table, position map, bucket metadata, result buffer, and the stash data in UltraRAM.

## AES key schedule, one round per clock (second U55C timing run)

With the scratch banks fixed, the worst paths were all `key_reg -> aes_core/rk10_reg`: 37 logic
levels, 7.7 ns, slack −4.3 ns at 300 MHz. The AES core expanded all ten round keys from the key in one
cycle and registered only the outputs.
- **The key schedule is now a chain:** `rk(i)` is computed from the **register** `rk(i-1)`
  (`aes128_key_round`: one SubWord plus XORs per stage). After a key change, `rk10` is correct 11 cycles
  later.
- **The AES core expands the GCM module's stable `key` input,** not `key_reg`, which changes only when
  an operation starts.
- **The controller starts its boot layout only once the key has been stable for 16 cycles.** The key is
  loaded once per boot.

The old and new cores both match FIPS-197 (Appendix B and C.1) and are bit-identical on random inputs.
Both regressions pass with unchanged timing hashes.

## Boot shuffle swap over three cycles (third U55C timing run)

With the key schedule chained, the only failing register group was `u_doma/u_oram/perm_reg`: slack
−0.667 ns, 16 levels, from `shuf_i`. The boot-time Fisher–Yates swap computed
`j = floor(r·(i+1)/2^16)`, read `perm[j]` and wrote `perm[i]` and `perm[j]`, all in one cycle. It now
takes three registered steps once the LFSR has settled: `j`, then the read, then the writes. The LFSR
does not advance during them, so the permutation is bit-identical: the self-test's layout-dependent
counts stay 149/51 and 174/26, and the timing hashes are unchanged. The cost is 2 cycles per slot,
once at boot. Both regressions pass.

## Stash free index registered (first routed U55C build: 279 MHz)

The first complete board build routed with WNS = −0.257 ns, so `v++` scaled the kernel clock to
279 MHz. That bitstream was still valid for functional tests: 105,000 operations, all correct, no
errors, 49.2 K operations per second at 279 MHz. Most failing paths ran from the stash's
`valid_r[*]` to the write enables of `target_r[*]`/`valid_r[*]`: 8 levels, three quarters of the
delay in routing. The 128-entry free-entry priority encoder and the write decode ran in one cycle.
- **The free index is now computed one cycle ahead and registered.** This is exact: inserts come at
  most once per access, so only an eviction can intervene, and it only frees an entry. If the stash
  was full when the index was computed, the entry evicted in that cycle is used.
- **A simulation check flags any insert into an occupied entry** (as `SAFETY VIOLATION`), and the
  regression's safety scan includes it.
- **Behavior is identical:** the self-test counts (149/51, 174/26), timing hashes, bus offsets and
  derived worst case are unchanged.

One GHASH path (`loaded_reg -> prod_q`, −0.255 ns) also failed. If it still fails after this build,
the next step is an operand register in front of the multiplier, verified against AES-GCM test
vectors.

## GHASH operand register (second routed U55C build: 272 MHz)

After the stash fix, TNS fell from −144 ns to −30 ns, but WNS was −0.341 ns (clock scaled to 272 MHz).
All remaining failing endpoints were `ghash_unit/prod_q_reg`: 9–11 levels, from the lane and combine
control registers (`cmb_step`, `l_last`) through operand selection and the 128×128 multiply.
- **`ghash_lane3.v`:** the selected operands are registered before the multiplier (operands, then
  multiply, then reduce). A lane's next product lands exactly when the three-lane round-robin reuses
  the lane, and the combine already waits for its products by count. `start` also drops anything in
  flight; none can be, by protocol.
- **Verification:**
  - The new `crypto` regression group checks the AES pipeline against the FIPS-197 known answers.
  - It checks the GHASH unit against an independent Python reference (`sim/ghash_ref.py`, NIST SP
    800-38D Algorithm 1, self-checked on GCM test case 2): 300 random messages of 1 to 300 blocks,
    back-to-back and with gaps.
  - A deliberately mis-timed variant (one cycle late) fails 226 of 300 messages, so the test does
    detect lane-timing errors.
- **Effect:** the worst encryption end rises by about 12 cycles (derived worst case 4,084 and 4,172
  against the 4,460 deadline). Timing hashes and bus offsets are unchanged, and both regressions pass.

## Block size as a build parameter (32 bytes to 4 KB)

DOMA's block (slot) size is now one build option, `ORAM_BLOCK_BEATS` (32-byte beats). The values are
1, 2, 4 and 8 for 32–256-byte records (the value sizes of BOLT's experiments), and 128 for 4 KB, the
default, which is unchanged. Everything else is derived from it:
- beats per bucket;
- counter widths;
- bucket spacing: the smallest power of two that holds Z blocks.

When a whole bucket fits in 4 KB (blocks up to 512 bytes), it moves as **one AXI burst**; 4 KB blocks
keep one burst per position.

**Timing budgets per block size.** Each size's budgets come from the regression's derived worst case,
with the same margins as 4 KB:
- write-back point = worst encryption end + 300 − (Z−1)·BEATS;
- completion point = write-back point + longest write-back + 250.

| Block | Worst encryption end | Write-back point | Completion point | Access window | At 300 MHz |
|---|---|---|---|---|---|
| 32 B | 655 | 950 | 1,220 | 1,270 cycles | 4.2 µs |
| 64 B | 682 | 980 | 1,270 | 1,322 | 4.4 µs |
| 128 B | 736 | 1,020 | 1,320 | 1,376 | 4.6 µs |
| 256 B | 846 | 1,110 | 1,450 | 1,514 | 5.0 µs |
| 4 KB | 4,172 | 3,820 | 5,160 | 5,464 | 18.2 µs |

`oram_params.vh` holds them as `ORAM_CT_WB_B<beats>` / `ORAM_CT_DONE_B<beats>` and selects by block
size; unlisted sizes fall back to the 4 KB budgets. **These come from the testbench memory model**:
for small blocks the first position lands 10–35 cycles after the read. Real HBM or PCIe is slower, and
small blocks leave little work to hide that behind, so calibrate on the card before relying on them.

**Bugs found while doing this:**
- **`scr_addr` hard-coded a 7-bit beat field** (right only for 128 beats). With smaller blocks,
  encrypted data landed in the wrong scratch locations, and the first read failed its integrity check.
- **The eviction-copy counters were fixed at 8 bits** (a negative replication count for small blocks).
- **Boot declared DOMA ready before its last writes were acknowledged.** A latent deadlock, present at
  4 KB too: the first access's read would be held while its fixed write-back point still arrived. Boot
  now waits for every acknowledgement.
- **1-beat blocks needed masked in-block addresses** in the kernel wrapper, scratch buffer and stash.

**Test infrastructure:**
- the memory model now pipelines late-landing writes per burst (it serialized them);
- the self-test's data pattern, the timing monitor and the tamper target no longer assume 4 KB;
- the negative control's too-early budget scales with the measured encryption time.

**Results:** the full single-client regression passes all 20 checks at every size (32, 64, 128, 256
bytes and 4 KB).

**Configurations:** DOMA serves **one client** (see the next section).

**Usage:**
- simulation: `ORAM_BEATS=8 bash run_verilator.sh all`;
- card: `BEATS=8 TARGET=hw bash build.sh`;
- the kernel reports its block size in its summary record (bytes 4–7), and `host_doma` lays out its
  data accordingly. It prints `block: N bytes per slot` after boot.


## One client: schedule and dummy accesses removed

DOMA serves one client, so everything that existed only for several clients is gone.
- **The two-client build option** (`ORAM_TWO_CLIENTS`). `run_verilator.sh` refuses `ORAM_CONFIG=two`.
- **The window schedule:** the owner table, frame index and frame length, with their configuration
  ports (`cfg_tdm_frame_len`, `cfg_tdm_owner`, `cfg_tdm_owner_valid`).
- **The dummy-access path:**
  - the top level's dummy flag and counter (`dbg_dummy_cnt`);
  - the window debug outputs `dbg_slot_real` and `dbg_slot_owner`;
  - the controller's `client_dummy` input, its dummy branch and data-operation skip;
  - completion is no longer gated on "not a dummy".
- **Two-client tests:** the two-client self-test variant, cross-client non-interference and partition
  isolation.

**Kept:**
- A window starts when the client's request is ready, and lasts the fixed window length
  (`cfg_tdm_slot_cycles`, 0 = `ORAM_TDM_SLOT`), so a result returns a fixed time after its request.
- The client-count and partition-width parameters remain, fixed at 1 and 0; their logic collapses to one
  client in synthesis.
- The self-test's three two-client tests remain in its sequence, reported as skipped, so its timing
  trace is unchanged.
- The timing monitor's trace keeps its `dummy` column, always 0.

**Verification:** single-client behavior is bit-identical. At 4 KB the regression reproduces the timing
hashes (`afa088624bd8ad5f`, `b35c7b2c840d4fbb`), calibration (4,136), bus offsets (20, 3,824) and derived
worst case (4,084/4,172), and all 20 checks pass. At 32 bytes, all 20 checks pass.

**Note:** `run_verilator.sh` reuses compiled testbenches. After editing a testbench or the monitor, run
with `REBUILD=1`.


## Packed small records: masked writes (step 2)

Records smaller than a block are packed into it: with R-byte records, P = block ÷ R share a block, and
key k is record k mod P of block k ÷ P. Every access already reads its block, so a PUT of one record
**merges** into the block within the same single access.
- **Command header:**
  - bytes 8–11: the record's byte offset in the block;
  - bytes 12–15: its length.
  Length 0 means the whole block, so older headers (zeros there) behave as before. A range running past
  the block is answered with status **`0x40`**, without an access.
- **Byte strobes:**
  - the kernel gives each PUT data beat a strobe covering the record's bytes;
  - the top level buffers it beside the data (`client_wstrb`);
  - the controller's copy engine writes `(old & ~strobe) | (new & strobe)`.
  "Old" is the block's copy in the scratch buffer (found in a bucket) or in the stash (merged in place),
  or zeros (never written). Every PUT takes this merge path; a full strobe gives exactly the client's
  data.
- **GET** returns the whole block; the host takes the record's bytes.
- **Host:** `DOMA_PACK=1 ./host_doma ...` packs `block ÷ VALUE_SIZE` records per block (8-byte values:
  4 per 32-byte block, so 1,024 keys at N = 256). The preload runs in batches; initialization is not
  measured.

**Verification:**
- **Kernel testbench, `+packed=R`:** each PUT carries junk outside its record, and every GET is compared
  with a byte-exact image of the **whole** block, so neighbouring records and never-written bytes are
  checked. Two regression tests:
  - packed 8-byte records over preloaded blocks, with a bad range rejected;
  - packed 16-byte records with late writes and read pauses.
  Both pass at 32-byte and 4 KB blocks.
- **Full regressions:**
  - 32 bytes: 20/20;
  - 4 KB: 22/22 with the tests above.
  Timing is unchanged: the timing hashes and derived worst cases are identical at both sizes, and 4 KB
  calibration moved by 1 cycle (4,137).
- **Host program:** run against a software model of the kernel protocol (`STUB_BEATS`, real buffers),
  it reports all responses correct, unpacked and packed, at 32 bytes to 4 KB. With the model
  deliberately ignoring record ranges, it reports the wrong data.


## Out-of-range part-selects at small block sizes (found by Vivado)

Vivado synthesis of the 32-byte build failed: `part-select [6:0] out of range of prefix 'cfill'`. Fixed
`[6:0]` slices (sized for 128-beat blocks) indexed the write buffer (`secure_oram_top.v`: `cfill`,
`ctrl_beat_req`) and the result buffer (`flat_oram_gcm.v`: `cp_wr_beat`, `res_beat`). For smaller blocks
those counters are narrower. Verilator reports this only as a warning, and the earlier lint runs
suppressed warnings. The indexes are now masked (`counter & (BEATS-1)`), the same bits as `[6:0]` at 128
beats.
- **Lint:** with `-Wall`, there are zero out-of-range selects at 1, 2, 4, 8 and 128 beats. The
  regression's new `lint` group fails on any.
- **Kernel tests** pass at 32 bytes (whole blocks, packed over preloaded blocks, packed under stress)
  and at 4 KB.

## Memory latency benchmark (`latency/`)

`latency/hbm_lat_kernel.v` is a small Vitis RTL kernel. It measures, on the card:
- dependent 32-byte reads (a position-map lookup);
- write acknowledgements;
- dependent 4 KB bursts (a bucket read).

It reports min/avg/max and percentiles from a histogram. The chain lives in HBM[8], the bank DOMA's
buckets use, or in host memory with `lat_host.cfg`. Its results fix the HBM latency in the scaled
design's performance bound, and the off-package latency for the final budgets. In simulation, every
sample equals the memory model's latency plus 2 cycles. See `latency/README.md`.


## Step 3.1: the position map in HBM

DOMA's trusted metadata moves from on-chip memory to on-package HBM, starting with the position map
(`rtl/pos_map_hbm.v`, which replaces `pos_map.v`).
- **Layout:** one 32-bit entry per slot at `meta + 4k` (bucket in the low bits, then the 2-bit
  status), so 8 entries per 32-byte line.
- **Reads:** a lookup reads one beat.
- **Writes:** one beat with a 4-byte strobe (no read-modify-write), posted through a 16-entry FIFO.
  `wr_quiet` reports when every write is acknowledged. A read is held until the map is quiet, since
  AXI does not order a read after an unacknowledged write. The unit test shows the hold matters: with
  writes landing 200 cycles late, 0 mismatches in 3,600 reads with it, 126 stale reads without it.
- **Controller:**
  - the lookup at the start of each access waits for the HBM read;
  - completion and the end of boot also wait for the map's acknowledgements;
  - the boot layout pauses while the write FIFO is full;
  - a FIFO overflow is a fail-stop error;
  - the legacy `init_pm_*` inputs no longer write the map (nothing drove them).
- **Budgets:** `ORAM_PM_LAT` (250 cycles) budgets the lookup. HBM measured on the U55C: dependent
  32-byte reads averaged 64 cycles, at most 179 in 2M samples. The read gate is
  `ORAM_CT_RD_BASE + ORAM_PM_LAT` = 266, and the write-back and completion points move out by the
  same 250 (the per-size table keeps its on-chip values; the selection adds `ORAM_PM_LAT`).
- **Kernel:** a fourth master, `m_axi_gmem3`, and argument `meta` (0x3C/0x40), latched at the first
  launch like `pages` (error `0x20` if a later launch names another buffer). The connectivity files map
  `meta` to **HBM[10]**, also in `doma.cfg`, where the buckets are in host memory: the metadata is
  trusted state and stays on-package.
- **Testbenches:** a metadata memory with the measured HBM profile (reads 53 cycles, 2% of them 105
  slower, writes acknowledged after 26), adjustable with `+meta_lat`, `+meta_slow_pct`,
  `+meta_slow_extra` and `+meta_wlat`.

**Constant time with variable HBM latency:** at 32-byte blocks, per-command latency rose by exactly
the 250-cycle budget (1,479–1,522 cycles). The query's device cycles were identical (184,796) with the
normal profile, with late bucket writes, and with five times the measured share of slow metadata
reads. Only boot time changes with slow metadata writes, and boot is not measured.


## Step 3.2: the bucket metadata and the IV/tag table in HBM

With step 3.1, all of DOMA's trusted metadata is in on-package HBM. `rtl/bucket_rec_hbm.v` replaces
`bucket_meta.v` and `iv_slot_table.v` behind the same two interfaces.
- **Records:** each bucket has a 256-byte record at `brec + 256b`. Beat 0 holds the metadata
  `{slot list, fill}`, and beat 1+p holds position p's `{tag, IV}`.
- **Opening a bucket** fetches its whole record in **one burst** into an on-chip buffer. The metadata
  is answered when beat 0 lands; an IV/tag read is answered once its beat has landed.
- **Writes** update the buffer and are posted through a FIFO that takes two pushes per cycle.
  `wr_quiet` reports when all are acknowledged, and HBM reads are issued only while quiet.
- **Fallback:** an IV/tag read of a bucket that isn't open is fetched individually (the controller
  never does this).
- **Unit test:** 13,628 checks, 0 mismatches, including rounds that reopen the bucket just written while
  writes land late. Without the read hold, 586 stale reads.
- **Early fetch:** the controller opens the bucket's record as soon as the position-map lookup returns
  the bucket, not at the fixed read gate. HBM is on-package and its accesses are not observable, so only
  the bucket's own, off-package read waits for the gate. Fetched at the gate, a slow record read could
  delay position 0's verification: the derived worst case at 32 bytes rose from 905 to 1,046 (deadline
  1,205). Fetched early, it is 911/895.
- **Controller:** completion and the end of boot also wait for the record writes. The boot layout pauses
  while either metadata FIFO is full. An overflow is fail-stop, and the legacy `init_bm_*` inputs no
  longer write the metadata.
- **Kernel:** a fifth master, `m_axi_gmem4`, and argument `brec` (0x48/0x4C), latched at the first
  launch (error `0x20` on a different buffer later). It is mapped to **HBM[11]** in every connectivity
  file, and `host_doma` allocates 256 bytes per bucket.
- **Testbenches:** a record memory with the measured HBM profile (`+brec_*` options). `tb_ni`'s bucket
  drain reads metadata from the records.

**Cost: none.** At 32-byte blocks, the timing hashes, bus offsets (270 and 1,204), per-command latency
(1,479–1,522) and query device cycles (184,796) are identical to step 3.1, including with five times
the measured share of slow reads on both metadata memories.


### Step 3.2 revision: record storage as LUT-RAM (routing congestion)

The first card build of step 3.2 routed very slowly: about 40 minutes per routing iteration, against
well under 30 minutes for all of routing before. In the record module, the write FIFO
(16 × 256 bits) accepted two writes per cycle, and the open-record buffer (8 × 256 bits) had three write
sources. Neither could be a RAM, so they became about 6,000 registers. The FIFO's 16-to-1, 256-bit output
multiplexer also drove the AXI write channel directly, all in SLR0 next to the HBM interfaces.
- **Both now have one write port:** metadata, IV/tag and fetched-beat writes never coincide. If they
  did, or if a write hit the record while it was still arriving, `err` stops DOMA. Both are therefore
  distributed RAM.
- **The FIFO's head is registered** before it drives the AXI write channel.
- **Behavior is identical:** the unit test gives the same 13,628 checks, and the mutant without the read
  hold the same 586 stale reads. The regressions reproduce the same timing hashes, bus offsets and
  derived worst cases.

**Unit tests:** `sim/tb_pmh.v` and `sim/tb_brec.v` check the two HBM metadata modules against reference
models, with the measured HBM profile and a late-landing write phase. They run in the new `units`
regression group (part of `all`).


## Step 4: the stash in HBM

`rtl/stash_hbm.v` replaces the on-chip stash (`stash.v`, with its 128-entry parallel search) behind
the same interface, plus open/ready/commit and an AXI master. The organization is BOLT's: per-bucket lists
of pointers into a pool of stash blocks.
- **HBM layout:** bucket b's list at `b * 512`: 64 entries of 64 bits `{valid, slot, pool index}`. Pool
  block i follows at `POOL_BASE + i * block size`.
- **Pool size:** `ORAM_STASH_DEPTH` blocks, max(N/4, 128); 128 at N = 256.
- **List size:** `ORAM_STASH_SLOTS` (64) per bucket. DOMA places each block in one random bucket, so the
  most blocks waiting for a bucket has a geometric tail (simulated: P(at least 8) is about 4e-4 for any N);
  64 makes overflow negligible up to N = 10M.

**Per access.** A stashed block is in the list of its target bucket, and an access reads exactly that
bucket. So the controller opens two buckets at the position lookup, together with the record fetch: the
bucket read (b) and the new random target (b').
1. **Reads, pipelined:** both lists go out back to back. As soon as b's list lands, the requested block
   (if stashed) and the lowest-indexed Z other entries go out back to back into an on-chip staging buffer.
   A tag queue routes the in-order returns.
2. **The eviction loop** takes candidates in the same order, so every eviction of an access (at most Z)
   finds its block staged.
3. **`S_SCAN` waits for `ready`.** Every stash operation after that (slot search, candidates, insert,
   remap, evict, data reads and writes) is served on chip, with the old stash's one-cycle read latency,
   so the copy engines are unchanged.
4. **`S_EA_START` commits:** both lists and the staged blocks written during the access go back to HBM.
   Completion waits for their acknowledgements.
5. **Boot** zeroes every list. It starts at the controller's boot (`init_go`), because the kernel learns
   the stash buffer's address only at the first launch.
6. **Fail-stop errors:** a full list or pool, an entry missing where it must be, or unstaged data.

Free pool indices come from an on-chip free stack plus a never-used counter.

**Kernel:** a sixth master, `m_axi_gmem5`, and argument `stash` (0x54/0x58), latched at the first launch.
It is mapped to **HBM[12]** in every connectivity file. `host_doma` allocates the lists plus a pool sized
for 4 KB blocks.

**Cost: none.** At 32-byte blocks, the timing hashes, bus offsets (270/1,204), per-command latency
(1,479–1,522) and query device cycles (184,796) are identical to step 3.2, including with slow or late
stash memory. The derived worst case is 906/890 against 1,205, slightly better than with the on-chip stash,
since evictions no longer wait out its one-cycle masking.

**Timing analysis.** The monitor now records `t_op`, the cycle the stash became ready. `worst_case.py`
treats the stash wait W = `t_op − t_scan` as a memory-dependent segment, like the bucket's read latency,
and adds its maximum to the bound. That is conservative, since the stash is fetched during verification.
With pipelined reads, W is 1 cycle (the state change) in every traced access. A first version fetched one
burst at a time; there W reached 72 cycles, and the operation segment stopped being deterministic.

**Unit test (`sim/tb_stash.v`, in `units`).** It drives the module like the controller and checks against a
reference model, with exact list contents after every open:
- 4,600 accesses with the HBM profile;
- a growth phase that fills the pool (116 of 128 blocks, up to 47 waiting for one bucket);
- a phase where writes land late and each access opens as soon as the previous commit has issued them.

All block sizes pass with 0 mismatches; without the read hold, stale lists are caught. The test found
three bugs: an unsized mask in the staging address, a write-back reading its first beat from the wrong slot,
and a stale beat counter, plus staging sized for half its address range at 32-byte blocks. The unit tests
now use an xorshift generator, because Verilator's `$random(seed)` produced a degenerate sequence there.


### Step 4 revision: stash timing (no 64-entry search in a single cycle)

The first card build of step 4 spent 25 minutes in "Post Placement Timing Optimization" (a few minutes
in builds that met timing). The stash's single-cycle searches over its 64-entry lists were feeding
decisions and writes in the same cycle, the same kind of path that failed in the old stash's free-index
search. The module is restructured; its behavior at the interface is unchanged apart from two points.
- **Handles:** the index the stash hands the controller is the block's **staging slot**. The controller
  never keeps a stash index beyond the access. Data reads and writes address staging directly, and remap and
  evict use the list position recorded per staging slot, so these paths have no search.
- **Registered searches:** the slot search, the first waiting block and the first free list entries are
  registered from stable lists.
  - In the cycle right after any change to b's list, `cam_bkt_inhibit_busy` is high: the registered
    candidate is stale then. The eviction loop already honored this signal for the old stash, so an
    eviction decision now takes 4 cycles instead of 3.
  - `ready` follows the last list change by two cycles.
- **Two-stage prefetch:** selection is registered, and the burst is issued the next cycle.
- **Registered list write-back data**, like the staging write-back.

A first version raised busy one cycle late (a registered copy of the change flag). The controller then
saw the stale candidate in the cycle after an eviction and evicted the same block twice, which the gated
stress test, the directed worst cases and the kernel tests caught. The unit test missed it because it paused
between evictions. Its eviction loop now matches the controller exactly: it asks again the very next cycle,
honors busy, and reads the evicted blocks afterwards. A mutant with the late busy fails it.

**Result:** 26/26 at both block sizes, with identical timing hashes and bus offsets. At 32 bytes the derived
worst case is 911/895 against 1,205 (C grows by one cycle per eviction).

**Synthesis check and the next free index.** `worst_paths.tcl` on the restructured stash (32-byte blocks,
U55C, 300 MHz, before placement) found no failing path. The worst, at +0.660 ns slack and 9 logic levels,
was the insert path: free-stack pointer, read the free stack, choose it or the never-used counter, then
write the list entry, fanning out to all 64 entries. The next free pool index is now computed one cycle
ahead into a register, which shortens that path to a few levels. Inserts happen long after the free stack
last changed, so the register is always current. It is stale only in the cycle right after an eviction or
insert, and an insert in that cycle raises the error, so DOMA would stop rather than hand out a stale
index. Behavior is identical: the same unit-test counts, regressions, timing hashes and worst case. Step 5
needs the same register anyway: at large N the free stack moves to block RAM, which only reads synchronously.


### GHASH pending queue as LUT-RAM (timing and area)

The placement log of the step-4 build (WNS -0.025 ns after placement) showed the placer replicating
`u_aes_gcm/ghash_pending_rd_ptr` about 48 times. The GHASH pending queue (256 x 128 bits) was written
inside the AES-GCM FSM's asynchronous-reset block, which no RAM can implement. So it was about 32,000
flip-flops plus a 256-to-1, 128-bit read multiplexer driven by that pointer.
- The FSM now registers a write request (enable, address, data), and the queue, marked
  `ram_style = "distributed"`, is written one cycle later in a reset-free block.
- Reads stay asynchronous, so GHASH is fed with the same registered read as before.
- While the head of the queue is the entry being written, it is not read for that cycle
  (`ghash_pending_head_ok`). Push/pop count adjustments use the same condition.

**Behavior:** at 32-byte blocks the kernel tests give identical device cycles (184,796; packed 185,129),
latency and data. Calibration's worst encryption end moved from 828 to 840 cycles (the one-cycle hold), against
a 1,205 deadline. Every authentication tag and data check passes; any error in GHASH's input would break them.


### Step 4 revision: routing congestion (stash lists in LUT-RAM)

The step-4 card build (restructured stash, GHASH queue still in registers) placed at WNS -0.025 ns, then
stalled in routing:
- congestion **level 6** (64 x 64 tiles), in all directions, on long and short wires;
- "Congestion is preventing the router from routing all nets";
- WNS -0.491 ns, TNS -211 ns.

The congested windows (tiles X40-105, Y124-190) are DOMA's own logic cluster in the middle of SLR0, not the
HBM interfaces at the SLR's bottom edge. Yosys estimates (UltraScale+ mapping, 32-byte blocks) located the
growth:

| Stash version | LUTs | Flip-flops |
|---|---|---|
| on-chip stash (step 3.2) | ~8,300 | ~5,000 (+4 URAM) |
| HBM stash, register lists | ~14,200 | ~5,100 |
| **HBM stash, LUT-RAM list fields** | **~3,200** | **~1,500** |

As registers, every list field had several write sources (landing, insert, remap) and 64-way read
multiplexers.

**The change:** the fields `{slot, pool index}` now live in LUT-RAM, one memory per entry position in a
256-bit beat (entry k at column k % 4, row k / 4).
- Landing a list beat writes one row of all four columns, and the write-back reads one row. Insert, remap,
  the eviction candidate and the prefetch selection access one column through a registered index.
- The requested slot is found while b's list lands: 4 comparisons per beat replace 64 comparators.
- Only the valid, staged and staging-slot bits stay in registers.
- An insert and a remap in the same cycle (never in DOMA's flow) is an error, since each column has one
  write port.

The unit test gives identical results at all block sizes (the same check counts), and both mutants still
fail. Together with the GHASH queue in LUT-RAM (~32,000 flip-flops and ~6,000 LUTs removed), the dense
cluster should largely disappear.

**Build hook:** for hardware builds, `build.sh` runs `vitis/post_place.tcl` right after placement. Each
command is wrapped in `catch`, so it can never fail the build. It writes the placed checkpoint
(`post_place.dcp`) and reports on congestion with the cells in each window
(`post_place_congestion.rpt`), utilization per module (`post_place_util_hier.rpt`) and post-placement
timing (`post_place_timing.rpt`), in `_x/link/vivado/vpl/prj/prj.runs/impl_1/`. A stopped build still
leaves this evidence; the v++ flow otherwise keeps no implementation checkpoint until it finishes.


### Traffic record (byte counters) in the kernel

`doma_kernel.v` counts handshaked read and write beats on `gmem2` per launch and writes them as record
`[size+1]` (`0x5B`; bytes 8–15 read, 16–23 write). GET data moves to `roundup((size+2)·32, 4 KB)`. The
format is the one agreed with the Tiny ORAM kernel (its plan item B2); details are in
`vitis/README_VITIS.md`. Device cycles, latency and every other result are unchanged. At 32-byte blocks a
query reads and writes 6 beats (192 B) per command, one bucket each way.


## Step 5.1: target generator and boot layout that scale

**Assumption, as in BOLT and other ORAM hardware:** DOMA's security assumes a cryptographically secure random
source (for example, AES in counter mode seeded from a true random number generator). The prototype uses
statistical generators in its place. They affect security, not performance: random values are drawn
ahead of use, so the timing is the same with any generator. The AES key and IV seed stay fixed across
boots in this prototype. GCM's IVs come from a maximal-length 96-bit LFSR, verified from the RTL's own
update rule: its step map has order exactly 2^96 - 1, and the IV sequence, taking every 96th state, has
period (2^96 - 1)/3. IVs are therefore unique within a boot, but they repeat across boots under the fixed
key. A deployment must load a fresh key per boot.

**Target buckets (`rtl/rng_bucket.v`, replaces `prng_lfsr.v`):**
- The generator is a 64-bit xorshift (Marsaglia's 13/7/17 triple, period 2^64 - 1). The old 12-bit LFSR's
  4,095 states could not cover hundreds of thousands of buckets.
- Draws map onto any number of buckets as (r · B) >> 40, with r the top 40 bits (bias at most B/2^40).
- The generator advances only when an access takes a value, so the sequence of targets does not depend
  on the requests. The output is pipelined: it is valid 3 cycles after a take.
- Checked against a Python model: 2,000 draws match exactly for B = 64 and B = 6,250, with chi-square
  values consistent with uniformity.

**Boot layout (`rtl/slot_perm.v`, replaces the Fisher-Yates array and shuffle):**
- The layout streams P(k) for k = 0..n-1, where f is a keyed bijection of M-bit values (xor a key,
  multiply by an odd constant, xor-shift, add a key, multiply, xor-shift). Cycle-walking makes it a
  bijection of [0, n) for any n.
- The layout places slot P(k) in bucket k/λ. It uses no N-entry array and no shuffle pass, and boot scales
  to millions of slots (about 4 cycles per slot).
- Checked against the Python model for n = 256, 200, 1,000 and 6,250: exactly n values, all distinct, all in
  range.
- The `perm` array (about 2,000 registers plus two 256-to-1 read multiplexers) is gone.

**Regressions:** all checks pass at both block sizes. The bus offsets and the derived worst case are
unchanged, and the kernel tests' device cycles are identical (184,796 and 185,129 at 32 bytes): the random
targets change which buckets are touched, never when.


## Step 5.2: the number of blocks at run time

**One bitstream serves every size up to its maximum.**
- `ORAM_N` is now the build's **maximum** number of blocks. The bucket count ⌈N/λ⌉, the slot and bucket
  widths and the slot-address width derive from it, with identical values at the default N = 256.
- `build.sh NMAX=4194304` builds for 2²² blocks: 10M 8-byte records packed four to a 32-byte block are
  2.5M blocks. That build has 22-bit slots, 20-bit buckets and a 35-bit slot-address width, which also
  holds the IV/tag interface's {bucket, position} encoding.
- The host chooses the actual n through a new kernel argument, **`nblk`** (0x60, latched at the first
  launch; a different value later is error 0x20; 0 means the maximum; above the maximum is error 0x80).

**What uses n:**
- the target generator's range (⌈n/λ⌉ buckets) and the format loop;
- the layout: `slot_perm` now picks its domain width m = ⌈log₂ n⌉ at run time, so cycle-walking stays
  under two applications per slot at any n. Measured in a 22-bit build: exact bijections at n = 1, 2, 3,
  200, 256, 1,000, 6,250, 65,537, 100,001 and 131,072, at 4–7 cycles per slot;
- the stash's list initialization and pool base;
- the key check: an explicit `key < n` in the kernel (status 0x4), plus the lease, now
  `{n, 12'b0}` at the slot-address width. It was a 32-bit `ORAM_N << 12`, which overflows above 2²⁰ slots.

**The stash pool now has one entry per slot** (pool index = slot number), replacing the allocated pool
of `ORAM_STASH_DEPTH` blocks and its free list. There is no allocation and no free stack, and **the pool
can no longer overflow**: only the per-bucket list bound (64) remains. It costs n blocks of HBM, 80 MB at
10M records. HBM accesses are not observable, so addressing by slot leaks nothing.

**Fixes found on the way:**
- the layout counters were 10 bits wide (`lay_i`, `lay_div`), which broke above 1,023 slots and 4,096
  slots respectively;
- a final partial bucket (n not a multiple of λ) got no metadata; it is now written with its true fill,
  and each bucket's slot list starts clean;
- the IV/tag address needed one more bit than the slot address at 2²² (lint at that size found a negative
  replication).

**Host:**
- `DOMA_N=<records>` and `DOMA_BLOCK=<bytes>` (default 4,096): with `DOMA_PACK=1`, n = ⌈records /
  (block/8)⌉ blocks. Every buffer is sized from n and the block size, and `nblk` is passed on every launch.
- The host stops with a clear message if the kernel's block size differs from `DOMA_BLOCK`. Buffers are
  allocated before the boot launch, when the kernel's block size is not yet known.
- Without `DOMA_N` the host uses 256 blocks, as before.

**Verification:**
- The kernel testbench's command, response and stash memories are now sized from the build (a 4,096-slot
  pool of 4 KB blocks is 16 MB), and its preload writes each of the n blocks once. At 4 KB the first
  run of the new test lost slot 4,095's stashed copy beyond a 2 MB model, which the model itself
  flagged as out-of-range accesses.
- A new kernel test: a 4,096-block build run at n = 1,000 (250 buckets, packed records, a bad key inside
  the build's range) and at n = 4,096. All checks pass, with **the same device cycles as the default
  build**: per-access cost does not depend on n.
- The default build's timing hashes are unchanged. The host runs correctly against the protocol model at
  1,000 and 100,000 blocks.

**Sweep build and runs (32-byte blocks, buckets in HBM):**

    NMAX=4194304 BEATS=1 TARGET=hw CFG=doma_hw.cfg ./build.sh
    DOMA_PAGES_HBM=1 DOMA_PACK=1 DOMA_BLOCK=32 DOMA_N=100000   ./host_doma doma_hw.xclbin 5000
    DOMA_PAGES_HBM=1 DOMA_PACK=1 DOMA_BLOCK=32 DOMA_N=1000000  ./host_doma doma_hw.xclbin 5000
    DOMA_PAGES_HBM=1 DOMA_PACK=1 DOMA_BLOCK=32 DOMA_N=10000000 ./host_doma doma_hw.xclbin 5000

The preload writes every record once (as BOLT's initialization does) and is not measured.
