# Tiny ORAM Phases 2–4: change list (2026-10-13)

Base: step 5.2 plus the Phase 1 delivery (`tinyoram_phase1.zip`). Unzip over the package root. No file
is deleted. DOMA's `rtl/` and `sim/` files are not touched; the only shared file changed is
`vitis/host_doma.cpp`.

## Shared file

| File | Change |
|---|---|
| `vitis/host_doma.cpp` | `DOMA_PACK=1` is now accepted for Tiny ORAM. Its command and response buffers are block-sized, as DOMA's. One block-size check (summary bytes 4–7) now runs for both kernels, before Tiny ORAM's geometry check; for DOMA it is the same code. The Tiny ORAM tree depth is now at least 6, as `build_tinyoram.sh` picks it. The `DOMA_N` mismatch message also gives the number of blocks the records need. Diff against Phase 1: `docs/tinyoram_phase2_host.diff`. **DOMA's output is identical** to the step 5.2 host (functional XRT mock, with and without `DOMA_N`, `DOMA_BLOCK`, `DOMA_PACK`, `DOMA_PAGES_HBM`). |

## Tiny ORAM files

| File | Change |
|---|---|
| `tinyoram/rtl/tinyoram_kernel.v` | Phase 2 packing. Header bytes 8–11 hold the offset and 12–15 the length (0 = whole block). A PUT goes through Tiny ORAM's `WMask`, with the data zeroed outside the record. A GET writes only the record (byte strobes). A bad range returns 0x40 with no ORAM access, for GET and PUT. Slots are block-sized, and the block size goes in summary bytes 4–7. A simulation-time check refuses a non-power-of-two block or a build without PMMAC. |
| `sim/tb_tinyoram_kernel.v` | `+packed=R` mirrors DOMA's packed tests. It checks every byte against a block image and checks that GETs leave the rest of their slot untouched. A final launch does whole-block GETs plus four bad-range shapes. `+ranges` adds arbitrary byte ranges mixed with whole blocks. Packed mode has its own random stream (`pseed`). `-DTB_HOST_WORDS=` enlarges the tree buffer for large-N builds. |
| `sim/run_tinyoram.sh` | 28 checks: the 20 from Phase 1, `packed8` and `packed16` at 64 B and 4 KB, and `ranges` at all four sizes. |
| `sim/run_xsim_tinyoram.sh` | Adds a packed run per size. |
| `vitis/build_tinyoram.sh` | `PACK=1`: L is chosen from N / (block/8) blocks, the tag is `tinyoram_<size>_n<N>_p8`, and `DOMA_PACK=1` goes on the printed run line. The build prints its geometry. It also clears the packager's work directories (`tinyoram_ip`, `tinyoram_pack`) before packaging, since every Tiny ORAM configuration shares them. |
| `vitis/synth_ooc_tinyoram.tcl` | The output directory is named after the fetched configuration and clock, for example `ooc_tinyoram_64B_L15_300mhz/`, so runs don't overwrite each other. |
| `docs/TINYORAM_CARD_RUNBOOK.md` | **New.** Phase 3 (64 B bring-up: fetch, out-of-context timing check and the `FREQ=` fallback, `hw_emu` with 20 commands, board build with the post-placement check, runs of 5,000 and 100,000 commands) and Phase 4 (1M records, 8 per block, L = 15). Each step lists the expected output, and the end lists what to report. |
| `docs/tinyoram_l15_sim_2026-10-13.txt` | **New.** Kernel simulation at the Phase 4 geometry (64 B, L = 15, packed, no preload). |
| `docs/README_TINYORAM.md` | §11 covers Phase 2; §12 points to the runbook. |
| `docs/tinyoram_regression_2026-10-13.txt` | `bash run_tinyoram.sh` on this tree: 28/28. |
| `docs/tinyoram_phase2_host.diff` | **New.** Host diff against Phase 1, for review. |

## Acceptance (on this tree)

* DOMA: `ORAM_BEATS=1` and `ORAM_BEATS=128 bash run_verilator.sh all` give 27/27 each, with trace hashes
  1d0cbb36268422ce/886ed1a80f3e4fae and 11f8bfc8e4d73473/61fc9e15ed9aea5b.
* Tiny ORAM: `bash run_tinyoram.sh` gives 28/28 (the 20 Phase 1 checks plus 8 packing checks).
* Review: an independent read of the RTL found no defects at the four block sizes. It did find two
  mutations the packed tests would miss; `+ranges` was added, and it catches both (each mutant was
  built and run).
* Not run here: Vivado, Vitis, XRT and the card. The runbook is written so that the first
  out-of-context run and `hw_emu` will expose any packaging or tool problem before the board build.
