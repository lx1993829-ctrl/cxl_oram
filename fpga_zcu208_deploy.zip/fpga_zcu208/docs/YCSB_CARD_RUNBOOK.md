# YCSB A–F on the U55C: card runbook

`oram_ycsb.c` cannot run on the card. It talks to gem5's ORAM device through gem5's MMIO registers and command ring,
and nothing is at those addresses on the U55C. `vitis/host_ycsb.cpp` contains `oram_ycsb.c`'s generator, unchanged
in logic, and drives `doma_kernel` through XRT command buffers, as `host_doma` does.

Given `oram_ycsb.c`'s arguments, it issues the same operations: same slots, same reads and writes, same order, same
opIdx. It checks every read and reports DOMA's latency for every command.

**Checked before card time:**
- **Same op sequence as gem5.** `sim/ycsb_equiv/` runs `oram_ycsb.c` natively against a stand-in device and diffs
  its op trace with `host_ycsb`'s. They are identical for:
  - workloads A–F;
  - 128, 4,096 and 32,768 slots, with seeds 0, 7, 31 and 3;
  - up to 278,528 ops, with the static musl `-O0` binary gem5 runs (`results.log`).
- **End to end against the RTL.** The unmodified `host_ycsb` ran against the Verilated `doma_kernel` through a mock
  XRT (`sim/xrt_mock/`):
  - A–F pass;
  - 32,768 slots pass;
  - host-memory placement passes;
  - chunked launches pass;
  - padding reads pass;
  - an injected one-bit error in a read is caught;
  - no kernel access fell outside its buffers;
  - the HBM/pages bucket split of the full runs (`DOMA_HBM_PCT=75`) passes, at 64 slots.

  Not simulated: 1 M slots. The mock would need over 10 GB of memory for the buckets, so the largest simulated run
  had 32,768 slots. The RTL sizes bucket offsets for it: `AXI_ADDR_W` is 40 bits, sized for N = 1 M at 4 KB.

None of the steps below needs sudo or changes the card's configuration. `host_ycsb` only loads the xclbin and
allocates buffers, like `host_doma`.

In every shell:

```bash
source /tools/Xilinx/Vitis/2024.1/settings64.sh
source /opt/xilinx/xrt/setup.sh
cd ~/fpga_zcu208/vitis
```

## 1. Files

Commit these files to the `fpga-u55c` branch:
- `vitis/host_ycsb.cpp`
- `vitis/run_ycsb.sh`
- `vitis/build.sh` (now also builds `host_ycsb`)
- this runbook

Then fetch them on the server. Adjust `R` if the package sits elsewhere in the repository.

```bash
R=https://raw.githubusercontent.com/lx1993829-ctrl/cxl_oram/fpga-u55c/fpga_zcu208
wget -q -O host_ycsb.cpp "$R/vitis/host_ycsb.cpp"
wget -q -O run_ycsb.sh   "$R/vitis/run_ycsb.sh"
wget -q -O build.sh      "$R/vitis/build.sh"
```

## 2. The bitstream

`host_ycsb` drives the same `doma_kernel` as `host_doma`, so an existing xclbin from this package works if it meets
two conditions:

- **NMAX at least `num_slots`.** The mid runs below need 32,768 and the full runs (`host_ycsb`'s default size)
  1,048,576. The package default of 512 covers only the smoke run. If NMAX is too small, `host_ycsb` stops at boot
  with `errors 0x80`.
- **Buckets in HBM, in banks large enough for the size.** `doma.cfg` and `doma_big.cfg` put the buckets in
  `HOST[0]`, which needs host memory enabled on the card (`xbutil configure --host-mem`), an admin change. The HBM
  layouts:

  | Config | `pages` | `pages_hbm` | `stash` | Holds |
  |---|---|---|---|---|
  | `doma_hw.cfg` | `HBM[8]` (512 MB) | `HBM[9]` (512 MB) | `HBM[12]` (512 MB) | about 100 K slots (about 200 K with `DOMA_HBM_PCT=50`): smoke and mid |
  | `doma_big_hbm.cfg` (new) | `HBM[24:27]` (2 GB) | `HBM[16:23]` (4 GB) | `HBM[12:14]` (1.5 GB) | 1 M slots with `DOMA_HBM_PCT=75`: every run |

  At 1 M slots the buckets take 5.4 GB and the stash 856 MB. `host_ycsb` prints where the xclbin puts `pages` and,
  if a buffer does not fit, names it and the configuration that holds it.

To check an existing xclbin:

```bash
ls -la *.xclbin
./check_timing.sh                 # if it was built in this directory: PASS at 300 MHz
```

The smoke run in step 4 shows where the xclbin connects `pages`: its second line reads it through XRT
(`pages in HBM[8]` for a `doma_hw.cfg` build). The xclbin does not record its NMAX. The smoke run (128 slots) works
with any NMAX; the mid and full runs stop at boot with `0x80` if NMAX is too small.

If you need a new one, build it with the same RTL configuration as the Verilated gem5 model (4 KB blocks, N = 2^20,
arrival scheduling). It takes hours, so run it under `nohup`. It writes `doma_hw.xclbin` whatever the config, so
copy an existing one aside first if you want to keep it.

For every run, up to 1 M slots, use `doma_big_hbm.cfg`. This file is new and untested: it is `doma_big.cfg` with
`pages` moved from `HOST[0]` to `HBM[24:27]`, and it has not been through `v++` here. Watch the post-placement check
of this build.

```bash
rm -rf doma_ip doma_pack doma_kernel.xo _x .ipcache       # stale IP-packager outputs (README_VITIS.md)
nohup env NMAX=1048576 SCHED=arrival CFG=doma_big_hbm.cfg TARGET=hw bash build.sh > build_big_hbm.log 2>&1 &
tail -f build_big_hbm.log
cp doma_hw.xclbin doma_big_hbm.xclbin                     # after PASS
```

For smoke and mid only, `CFG=doma_hw.cfg` is the layout already used for DOMA's runs on this card.

**Expected end:** `PASS: timing closed at 300 MHz`.

**If it ends with `NOT AT 300 MHz`:** v++ lowered the clock. The bitstream still runs correctly, because DOMA's
budgets are in cycles. Run with `DOMA_MHZ=<that clock>` so the microsecond figures are right, and treat the result as
measured at that clock.

If timing fails at N = 2^20, `NMAX=32768` still covers smoke and mid, which is every `oram_ycsb.c` size (its
MAX_SLOTS is 32,768).

## 3. Build host_ycsb and dry-run it (seconds, no card)

```bash
g++ -std=c++17 -O2 -ffp-contract=off host_ycsb.cpp -I$XILINX_XRT/include -L$XILINX_XRT/lib -lxrt_coreutil -pthread -o host_ycsb
./host_ycsb doma_hw.xclbin 1 0 100 128 all 64 10 --dry-run
```

`-ffp-contract=off` keeps the Zipfian arithmetic bit-identical to gem5's. Expected output, the same lines
`oram_ycsb.c` prints in gem5 for these arguments, apart from pass/fail:

```
oram_ycsb: inst=0 wl=A total_oram_ops=164 run_reads=49 run_writes=51 pass=- fail=- insert_count=64
oram_ycsb: inst=0 wl=B total_oram_ops=164 run_reads=95 run_writes=5 pass=- fail=- insert_count=64
oram_ycsb: inst=0 wl=C total_oram_ops=164 run_reads=100 run_writes=0 pass=- fail=- insert_count=64
oram_ycsb: inst=0 wl=D total_oram_ops=164 run_reads=94 run_writes=6 pass=- fail=- insert_count=70
oram_ycsb: inst=0 wl=E total_oram_ops=635 run_reads=567 run_writes=4 pass=- fail=- insert_count=68
oram_ycsb: inst=0 wl=F total_oram_ops=213 run_reads=100 run_writes=49 pass=- fail=- insert_count=64
```

## 4. Smoke run on the card (seconds)

```bash
xbutil examine                    # the card is listed (if another user's job holds it, wait; do not reset it)
./host_ycsb doma_hw.xclbin 1 0 100 128 all 64 10 | tee ycsb_smoke.log
```

**Expected:**
- each workload prints `WORKLOAD PASSED`;
- then the summary table, then `ALL WORKLOADS PASSED`;
- every `oram_ycsb:` line matches the dry run, now with `fail=0`.

The same run in simulation is `sim/xrt_mock/results/ycsb_smoke_sim.log`, using the testbench's HBM model (53 cycles,
2% at +105):
- every command took 9,326–9,431 cycles, 31.1–31.4 µs at 300 MHz;
- that range was the same for GET and PUT and for all six workloads, as expected of an oblivious ORAM.

The card's own HBM sets the real spread.

## 5. Larger runs

```bash
bash run_ycsb.sh doma_hw.xclbin mid                 # 32,768 slots, about 40 s of card time
bash run_ycsb.sh doma_big_hbm.xclbin full           # 1 M slots (host_ycsb's defaults), about 8 minutes
bash run_ycsb.sh doma_big_hbm.xclbin all            # smoke, mid and full with one bitstream
```

Each workload runs in its own process from a fresh boot. Logs go to `ycsb_results/`, plus per-command CSVs (off for
`full`, about 12 M lines; `CSV=1` turns them on).

- **mid:** `oram_ycsb.c`'s largest size, 32,768 slots with `init_occ` 16,384, and `n_iters` 100,000 for every
  workload.
- **full:** `host_ycsb`'s defaults: 1,048,576 slots, `init_occ` 524,288, `n_iters` 1,000,000. `DOMA_HBM_PCT`
  defaults to 75, which puts 98,304 of the 131,072 buckets in `pages_hbm`. A run phase may issue up to 10 M ORAM ops,
  so E fits at the defaults: a scan reads up to `scan_len` slots.

The generator's op counts for these runs:

| Workload | mid: load | mid: run (GET / PUT) | full: load | full: run (GET / PUT) |
|---|---|---|---|---|
| A | 16,384 PUT | 100,000 (49,898 / 50,102) | 524,288 PUT | 1,000,000 (500,755 / 499,245) |
| B | 16,384 PUT | 100,000 (95,010 / 4,990) | 524,288 PUT | 1,000,000 (950,046 / 49,954) |
| C | 16,384 PUT | 100,000 (100,000 / 0) | 524,288 PUT | 1,000,000 (1,000,000 / 0) |
| D | 16,384 PUT | 100,000 (95,113 / 4,887) | 524,288 PUT | 1,000,000 (950,328 / 49,672) |
| E | 16,384 PUT | 527,375 (522,353 / 5,022) | 524,288 PUT | 5,276,562 (5,226,551 / 50,011) |
| F | 16,384 PUT | 149,898 (100,000 / 49,898) | 524,288 PUT | 1,500,755 (1,000,000 / 500,755) |

The script ends with `run_ycsb: every run PASSED` and the xclbin's kernel clock.

## What each run reports

- **`RUN :` line.** It gives:
  - commands, wall time (launch + `wait()`, as in `host_doma`) and **Kops/s**;
  - device cycles per command. This includes the kernel's command fetch and response write, so it is slightly
    above the latency.
  - For runs longer than 50 ms, device cycles divided by wall time. This should be close to the kernel clock; a much
    lower value means launch overhead dominates.
- **`latency, request to done`**, separately for GET and PUT: n, min, mean, p50, p99 and max in cycles, plus µs at
  `DOMA_MHZ` (default 300). This is the kernel's per-command counter in response bytes 8–11: from DOMA's request to
  its done, including the 4 KB data stream.
- **`verify:`** every run-phase read compared against the block last written to that slot. The whole block is
  compared, not only gem5's two words.
- **`oram_ycsb:`** the line gem5 prints, for a direct comparison with a gem5 run.
- **Per-command CSV** (`YCSB_CSV=file`, set by `run_ycsb.sh`): workload, phase, command, opIdx, slot, op, latency,
  status.

## Matching a gem5 run

The arguments after the xclbin are gem5's argv after the binary:
`<N> <instance_id> <n_iters> <num_slots> <workload> <init_occ> <scan_len>`. The workload can also be a set of
letters (`ABCDEF`, `all`). The same arguments give the same op sequence. Differences that do not change any operation:

- **Leases.** `doma_kernel` has one client and one lease. gem5's split of slots between two leases only routes
  commands.
- **Queueing.** gem5's ring keeps up to 16 commands queued. Here every command of a phase is on the card before the
  launch, so DOMA never waits for the host in either case.
- **Padding (gem5 only).** gem5 pads E and F with slot-0 reads up to a fixed count. Set `YCSB_PAD=1` to issue them
  too; they are reported separately and checked.
- **Block contents.** Beat 0 starts with gem5's payload words. The rest of the block carries opIdx, slot and beat
  index, so a stale block cannot pass: `payload_word(i)` is identical for `i` and `i + 256`. `YCSB_DATA=gem5`
  writes gem5's exact fill instead. DOMA encrypts every block, so the contents do not change timing.
- **Bucket placement.** With `doma_hw.cfg` the buckets are in HBM[8]. These numbers therefore correspond to a gem5
  run with the buckets in HBM, not to the PCIe configuration. Measuring the PCIe path needs host memory on the card
  and `CFG=doma.cfg`.
- **Defaults and limits.** `host_ycsb` defaults to 1,000,000 iterations and 1,048,576 slots, with `init_occ`
  `num_slots/2`. Its maxima are 1,000,000 iterations, 1,048,576 slots and 10 M run-phase ops. `oram_ycsb.c` keeps
  100 / 128 / `num_slots` as defaults (its `init_occ` default fails its own check), with maxima of 131,072
  iterations, 32,768 slots and 262,144 run-phase ops. Pass every argument explicitly when comparing. Within
  `oram_ycsb.c`'s limits the sequences are identical (`sim/ycsb_equiv/results.log`, rerun after this change).
- **Out of free slots.** When D or E needs an insert and every odd slot is already taken, `oram_ycsb.c` loops
  forever. `host_ycsb` stops with an error.

## If something fails

| Message | Meaning |
|---|---|
| `init launch failed ... 0x80` | `num_slots` (or `DOMA_N`) is above the bitstream's NMAX. Rebuild with a larger NMAX, or run smaller. |
| `errors 0x8 ... DOMA HALTED` | Integrity check, stash overflow or timing budget. The run is invalid. Keep the log; this is not expected. |
| `errors 0x10` | Command timeout (2 M cycles). Keep the log. |
| `cannot allocate the pages buffer ... host memory` | The xclbin is a `doma.cfg` or `doma_big.cfg` build and host memory is off. Use an HBM build (table in step 2). |
| `cannot allocate stash` / `pages_hbm` / the pages buffer in device memory | The size does not fit this xclbin's banks (for example 1 M slots on `doma_hw.cfg`). Use `doma_big_hbm.cfg` with `DOMA_HBM_PCT=75`. |
| `cannot allocate cmd_input` / `resp_output` | Lower `YCSB_CHUNK` (default 65,536 commands per launch). |
| `all ... odd slots already hold inserts` | D or E needs more inserts than there are free odd slots. Use a larger `num_slots` or fewer `n_iters`. |
| `MISMATCH ...` | A read returned the wrong block. Keep the log and the CSV. |
| `load_xclbin` fails or the device is busy | Another user's process holds the card. Wait; do not reset it, which needs sudo and affects others. |

## Options (environment)

| Variable | Effect |
|---|---|
| `DOMA_N` | ORAM size in blocks, at least `num_slots` (default `num_slots`). |
| `DOMA_HBM_PCT` | Percentage of buckets kept in HBM, as in `host_doma`. |
| `DOMA_POOL` | Stash pool size, as in `host_doma`. |
| `DOMA_PAGES_HBM=1/0` | Override where `pages` is allocated (default: where the xclbin connects it). |
| `DOMA_MHZ` | Clock used for the µs figures. |
| `DOMA_DEVICE` | Device index or BDF. |
| `YCSB_CHUNK` | Commands per launch. |
| `YCSB_PAD=1` | Issue gem5's padding reads. |
| `YCSB_DATA=gem5` | Write gem5's exact block fill. |
| `YCSB_TRACE=file` | Write the op sequence, as `cmp.sh` compares it. |
| `YCSB_CSV=file` | Write per-command results. |

## Without the card

`sim/xrt_mock/README.md` runs the same host programs against the Verilated `doma_kernel` at about 150 k cycles/s.
Use it to check a change to `host_ycsb.cpp` before card time. `sim/ycsb_equiv/cmp.sh` re-checks the op sequence
against `oram_ycsb.c`.
