# Tiny ORAM on the U55C: card runbook (Phases 3 and 4)

These are the commands, in order, with the output to expect at each step. No step changes the card's
configuration or needs sudo. The tree buffer goes in HBM[8] (`tinyoram_hw.cfg`, host flag
`DOMA_PAGES_HBM=1`), as DOMA's current runs do.

Before starting, in every shell:

```bash
source /tools/Xilinx/Vitis/2024.1/settings64.sh      # or wherever Vitis 2024.1 is installed
source /opt/xilinx/xrt/setup.sh
cd fpga_zcu208/vitis
```

## Phase 3: bring-up at 64 B

### 3.1 Fetch Tiny ORAM

```bash
bash ../tinyoram/fetch_tinyoram.sh 64
```

Expected, last line:

```
Tiny ORAM ready: 72 sources in .../fpga_zcu208/tinyoram/build/src, configuration 64 (ORAMB      512 ORAML      6 )
```

This needs GitHub (it tries `git clone` first, then `wget`/`curl`). If the machine can't reach GitHub,
download `https://github.com/ascend-secure-processor/oram/archive/18ece0764c4feb5b34f568b2bf9e18081a781a06.tar.gz`
elsewhere, copy it over, and run `TINYORAM_TARBALL=<file> bash ../tinyoram/fetch_tinyoram.sh 64`.
Any `patch ... failed` message means the download is not commit 18ece07.

### 3.2 Out-of-context timing check at 300 MHz (about 30–60 minutes, no card needed)

```bash
vivado -mode batch -nojournal -nolog -source synth_ooc_tinyoram.tcl
```

Expected:
* first line: `tinyoram_kernel: 64-byte blocks, L=6, 300 MHz -> ooc_tinyoram_64B_L6_300mhz/`;
* last line: `WNS: <x> ns, WHS: <y> ns at 3.333 ns (tinyoram_kernel on xcu55c-fsvh2892-2L-e)`.

**Pass:** WNS ≥ 0. Then go to 3.3 at 300 MHz.

**If WNS < 0:**

1. Look at `ooc_tinyoram_64B_L6_300mhz/worst_groups.txt` for the failing paths. The likely ones are
   Keccak's two rounds per cycle, the tiny_aes table rounds and the stash scan.
2. Estimate the reachable clock as f ≈ 1000 / (3.333 − WNS) MHz. For example, WNS = −0.8 ns gives
   about 242 MHz.
3. Round down to a multiple of 5 MHz and confirm it out of context, for example:
   ```bash
   vivado -mode batch -nojournal -nolog -source synth_ooc_tinyoram.tcl -tclargs route 240
   ```
   This writes `ooc_tinyoram_64B_L6_240mhz/`. If WNS is still negative, step down by 10 MHz.
4. Use the highest passing clock as `FREQ=` in every build below. Report results both in cycles and in
   time at that clock.

**Also note for the report:** `ooc_tinyoram_*/util_routed.rpt` gives the resources of the whole kernel
(Tiny ORAM `u_tiny`, adapter `u_adapt`, and the wrapper) out of context.

### 3.3 Hardware emulation with 20 commands (no card needed)

```bash
SIZE=64 TARGET=hw_emu bash build_tinyoram.sh            # add FREQ=<MHz> if 3.2 needed it
```

Expected: it prints
`Tiny ORAM build: 64-byte blocks, 256 records, 256 blocks -> L=6 (N=256 blocks), 300 MHz, tag tinyoram_64`,
builds `tinyoram_64_hw_emu.xclbin` and `host_doma`, and ends with its run line. Run it with a small
`DOMA_N`, so the preload stays short in emulation:

```bash
XCL_EMULATION_MODE=hw_emu DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=64 DOMA_N=32 DOMA_PAGES_HBM=1 \
    ./host_doma tinyoram_64_hw_emu.xclbin 20
```

Expected (`T`, `Q`, the cycle counts and latencies vary):

```
size: 32 blocks, Tiny ORAM tree for L=6 (N=256), 64-byte blocks: 53248 bytes
block: 64 bytes per slot
Tiny ORAM bitstream: N=256 blocks (L=6), tree 49536 bytes
records: 32 keys of 8 bytes, 1 per block
init: T s (boot + preload of 32 keys), preload errors=0x0
query: 20 commands (11 GET, 9 PUT) in T s = Q KQPS
device: ... cycles total, per-command latency A..B cycles, completed 20, errors 0x0, summary ok
latency: to data ready ..., to last write-back beat ..., to write-back acknowledged A..B cycles
traffic: bucket port 53760 B read, 53760 B written = 2688 B read, 2688 B written per command
ALL RESPONSES CORRECT
```

* 2,688 B per command each way is exactly one path: 7 buckets × 6 bursts × 64 B. Slightly more means
  Tiny ORAM inserted background evictions, which is legitimate.
* `DOMA_N=32` works because N ≤ 256 records all use the L=6 tree. The host refuses an N that needs
  another tree, and names the L it needs.
* Packed records on the same xclbin:
  ```bash
  XCL_EMULATION_MODE=hw_emu DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=64 DOMA_N=64 DOMA_PACK=1 DOMA_PAGES_HBM=1 \
      ./host_doma tinyoram_64_hw_emu.xclbin 20
  ```
  Expected: `records: 64 keys of 8 bytes, 8 per block` and `ALL RESPONSES CORRECT`.

If emulation reports `errors 0x8`, Tiny ORAM's integrity check or the adapter flagged an error. The
emulation log is under `.run/*/hw_emu/device0/binary_0/behav_waveform/xsim/simulate.log`.

### 3.4 Board build, with the post-placement check about 45 minutes in

```bash
SIZE=64 TARGET=hw bash build_tinyoram.sh 2>&1 | tee build_tinyoram_64_hw.log    # add FREQ=<MHz> if needed
```

About 45 minutes in, placement finishes and the hook (`post_place.tcl`) writes four files:

```bash
R=_x_tinyoram_64/link/vivado/vpl/prj/prj.runs/impl_1      # _x_tinyoram_64_<F>mhz with FREQ=<F>
ls -la $R/post_place.dcp $R/post_place_*.rpt
awk '/WNS\(ns\)/{getline; getline; print "post-place WNS="$1" ns, TNS="$2" ns, WHS="$5" ns"; exit}' $R/post_place_timing.rpt
grep -E "tinyoram_kernel_1|u_tiny|u_adapt" $R/post_place_util_hier.rpt | head
grep -A12 "Congestion" $R/post_place_congestion.rpt | head -30
```

Decision:
* **Post-place WNS ≥ −0.3 ns:** let it run. Physical optimisation and routing usually recover that much.
* **Post-place WNS < −0.5 ns:** stop the build (Ctrl-C in its terminal). Then go back to 3.2 for the
  clock, and rebuild with `FREQ=`.
* **Congestion level ≥ 5** in any direction: send me the congestion report before rebuilding.

At the end, the script runs `check_timing.sh`. Expected:

```
routed timing: WNS=<≥0> ns  TNS=0.000 ns  WHS=<≥0> ns  THS=0.000 ns
kernel clock in tinyoram_64_hw.xclbin: 300 MHz
PASS: timing closed at 300 MHz
run: DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=64 DOMA_N=256 DOMA_PAGES_HBM=1 ./host_doma tinyoram_64_hw.xclbin 5000
```

A `FAIL` line, followed by `*** TIMING NOT CLOSED ***`, means the xclbin must not be used for
measurements. A common cause is that v++ lowered the clock.

### 3.5 Runs on the card

```bash
DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=64 DOMA_N=256 DOMA_PAGES_HBM=1 ./host_doma tinyoram_64_hw.xclbin 5000
DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=64 DOMA_N=256 DOMA_PAGES_HBM=1 ./host_doma tinyoram_64_hw.xclbin 100000
DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=64 DOMA_N=2048 DOMA_PACK=1 DOMA_PAGES_HBM=1 ./host_doma tinyoram_64_hw.xclbin 5000
```

Expected:

| Run | Lines that must match |
|---|---|
| 5,000 | `records: 256 keys of 8 bytes, 1 per block`, `query: 5000 commands (2546 GET, 2454 PUT)`, `completed 5000, errors 0x0, summary ok`, `ALL RESPONSES CORRECT` |
| 100,000 | `query: 100000 commands (49992 GET, 50008 PUT)`, `completed 100000, errors 0x0`, `ALL RESPONSES CORRECT` |
| packed, 5,000 | `records: 2048 keys of 8 bytes, 8 per block`, `query: 5000 commands (2546 GET, 2454 PUT)`, `ALL RESPONSES CORRECT` |

In all three, the traffic line should read about 2,688 B read and 2,688 B written per command.

**Back-to-back runs.** The kernel latches its tree buffer at its first launch after the xclbin is
loaded, and zero-fills the tree at the first command launch, as DOMA's kernel latches its buffers.
If XRT keeps the xclbin loaded between host processes, a later process gets a different buffer and its
summary shows error `0x20` (`preload errors=0x20`, `errors 0x20`). Those numbers are invalid. Note it
and tell me rather than working around it; the same question applies to DOMA's runs.

## Phase 4: 1M records at 64 B, 8 per block

1M records at 8 per block is 125,000 blocks, which gives L = 15 (131,072 blocks) and a 31.5 MB tree,
within one HBM bank. Tiny ORAM's PosMap recursion is active at this size: 4 levels, with its PLB.

### 4.1 Timing check of this geometry

```bash
bash ../tinyoram/fetch_tinyoram.sh 64 15
vivado -mode batch -nojournal -nolog -source synth_ooc_tinyoram.tcl            # -> ooc_tinyoram_64B_L15_300mhz/
```

Expected first line: `tinyoram_kernel: 64-byte blocks, L=15, 300 MHz -> ooc_tinyoram_64B_L15_300mhz/`.
The PosMap and PLB are larger than at L = 6, so check WNS again. Use the same procedure as 3.2 if it
fails.

### 4.2 Board build and runs

```bash
SIZE=64 N=1000000 PACK=1 TARGET=hw bash build_tinyoram.sh 2>&1 | tee build_tinyoram_64_n1M.log
```

Expected: `Tiny ORAM build: 64-byte blocks, 1000000 records, 125000 blocks -> L=15 (N=131072 blocks), 300 MHz, tag tinyoram_64_n1000000_p8`.
Do the post-placement check as in 3.4, under `_x_tinyoram_64_n1000000_p8/`.

```bash
DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=64 DOMA_N=1000000 DOMA_PACK=1 DOMA_PAGES_HBM=1 ./host_doma tinyoram_64_n1000000_p8_hw.xclbin 5000
```

Expected:

```
size: 125000 blocks, Tiny ORAM tree for L=15 (N=131072), 64-byte blocks: 31510528 bytes
block: 64 bytes per slot
Tiny ORAM bitstream: N=131072 blocks (L=15), tree 31506816 bytes
records: 1000000 keys of 8 bytes, 8 per block
init: T s (boot + preload of 1000000 keys), preload errors=0x0
query: 5000 commands (2548 GET, 2452 PUT) in T s = Q KQPS
...
ALL RESPONSES CORRECT
```

* The preload is 1,000,000 PUTs of one record each, in launches of 5,000. It is initialization, as for
  DOMA and BOLT, and is not timed as part of the query.
* Traffic: one data path at L = 15 is 16 buckets × 384 B = 6,144 B each way. With PosMap recursion, a
  command also reads and writes paths of the PosMap ORAMs whenever their blocks miss the PLB, so expect
  roughly 15–20 KB each way per command (about 2.5–3 paths):
  * The kernel testbench at this geometry (`-DTB_HOST_WORDS=1048576`, `+packed=8`, no preload, 100-cycle
    memory, `docs/tinyoram_l15_sim_2026-10-13.txt`) moved 497 read and 497 write beats per command in
    its second launch. That is 15.9 KB each way, 2.6 paths. Latency to write-back acknowledged was
    125..4,051 cycles. A partly filled tree, so only indicative.
  * The core harness at L = 14, fully preloaded (README §9 D), gave 2.9 paths.
  Full preload of 131,072 blocks is too slow to simulate here (hours), so the card gives the real figure.

Then, if time allows:
* **10M records:** `SIZE=64 N=10000000 PACK=1`, which gives L = 19 and a 409 MB tree (408,994,176 B),
  still within one 512 MB HBM bank.
* **100K records:** `SIZE=64 N=100000 PACK=1`, which gives L = 12 and a 3.2 MB tree.

## What to report, per configuration

| Item | Where it comes from |
|---|---|
| Throughput | `query: ... = Q KQPS` (5,000 commands; also 100,000 at L = 6) |
| Latency, min/max, three definitions | the `latency:` line: data ready; last write-back beat; write-back acknowledged (primary, the same end point as DOMA's). In cycles; also µs at the achieved clock. |
| Bytes per command | the `traffic:` line (read and written on the tree port) |
| Achieved clock | `check_timing.sh` (`kernel clock in ...xclbin`) and its WNS |
| Utilization, core plus adapter | `$R/post_place_util_hier.rpt` rows `u_tiny` and `u_adapt` (and the whole `tinyoram_kernel_1`); the routed equivalent is `_x_<tag>/link/vivado/vpl/prj/prj.runs/impl_1/*utilization*routed*.rpt` |
| Initialization time | `init: T s (boot + preload ...)` |

Stated limitation (README §9, B6): the adapter is 1:1, so every Tiny ORAM memory command is one 64-byte
AXI burst. HBM's per-transaction cost is therefore part of Tiny ORAM's numbers.
