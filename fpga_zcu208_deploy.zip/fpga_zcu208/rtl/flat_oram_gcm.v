`timescale 1ns / 1ps
`include "oram_params.vh"

// =============================================================================
// flat_oram_gcm.v - ORAM Top with AES-GCM Encryption (v2 - same-bucket fix)
// =============================================================================

module flat_oram_gcm #(
    parameter N            = `ORAM_N,
    parameter Z            = `ORAM_Z,
    parameter C            = `ORAM_C,
    parameter B            = `ORAM_B,
    parameter STASH_DEPTH  = `ORAM_STASH_DEPTH,
    parameter AXI_DW       = `AXI_DATA_W,
    parameter AXI_AW       = `AXI_ADDR_W,
    parameter AXI_SW       = `AXI_STRB_W,
    parameter AXI_IDW      = `AXI_ID_W,
    parameter AXI_LENW     = `AXI_LEN_W,
    parameter SLOT_AW      = `SLOT_ADDR_W,
    parameter BUCKET_W     = `BUCKET_ID_W,
    parameter SLOT_W       = `SLOT_ID_W,
    parameter FILL_W       = `FILL_CNT_W,
    parameter POS_W        = `POS_IN_BKT_W,
    parameter PTR_W        = `STASH_PTR_W,
    parameter BEATS        = `BEATS_PER_BLOCK,
    parameter BEAT_W       = `BEAT_CNT_W,
    parameter TOTAL_BEATS  = `BEATS_PER_BKT,
    parameter AES_BLK_W    = 128
)(
    input  wire                 clk,
    input  wire                 rst_n,

    // Client Interface
    input  wire                 client_req,
    input  wire                 client_dummy,     // Phase 3: with client_req, run a dummy access (no target)
    input  wire                 client_op,
    input  wire [SLOT_AW-1:0]  client_slot_addr,
    input  wire [AXI_DW-1:0]   client_wdata,
    input  wire                 client_wdata_valid,
    input  wire [BEAT_W-1:0]   client_wdata_beat,
    output wire [BEAT_W-1:0]   client_wdata_beat_req,
    output reg  [AXI_DW-1:0]   client_rdata,
    output reg                  client_rdata_valid,
    output reg  [BEAT_W-1:0]   client_rdata_beat,
    output reg                  client_done,
    output reg                  client_stall,

    output reg                  err_bucket_overflow,
    output reg                  err_stash_overflow,
    output reg                  err_tag_mismatch,
    output wire err_ct_overrun,   // Phase 2: sticky, a timing gate was missed (fail-stop)
    output wire fmt_done,         // Phase 2: boot-time encrypted format complete

    // BRAM Init Interface
    input  wire                     init_mode,
    input  wire [SLOT_AW-1:0]      init_pm_wr_addr,
    input  wire [BUCKET_W-1:0]     init_pm_wr_bucket,
    input  wire [1:0]              init_pm_wr_status,
    input  wire                     init_pm_wr_en,
    input  wire [BUCKET_W-1:0]     init_bm_wr_bucket,
    input  wire [Z*SLOT_W-1:0]    init_bm_wr_slot_list,
    input  wire [FILL_W-1:0]      init_bm_wr_fill,
    input  wire                     init_bm_wr_en,

    // AES-GCM Key
    input  wire [127:0]            aes_key,
    input  wire [95:0]             aes_iv_seed,

    // AXI4 Master -> DDR
    output wire [AXI_IDW-1:0]   m_axi_arid,
    output wire [AXI_AW-1:0]    m_axi_araddr,
    output wire [AXI_LENW-1:0]  m_axi_arlen,
    output wire [2:0]            m_axi_arsize,
    output wire [1:0]            m_axi_arburst,
    output wire                  m_axi_arvalid,
    input  wire                  m_axi_arready,
    input  wire [AXI_IDW-1:0]   m_axi_rid,
    input  wire [AXI_DW-1:0]    m_axi_rdata,
    input  wire [1:0]            m_axi_rresp,
    input  wire                  m_axi_rlast,
    input  wire                  m_axi_rvalid,
    output wire                  m_axi_rready,
    output wire [AXI_IDW-1:0]   m_axi_awid,
    output wire [AXI_AW-1:0]    m_axi_awaddr,
    output wire [AXI_LENW-1:0]  m_axi_awlen,
    output wire [2:0]            m_axi_awsize,
    output wire [1:0]            m_axi_awburst,
    output wire                  m_axi_awvalid,
    input  wire                  m_axi_awready,
    output wire [AXI_DW-1:0]    m_axi_wdata,
    output wire [AXI_SW-1:0]    m_axi_wstrb,
    output wire                  m_axi_wlast,
    output wire                  m_axi_wvalid,
    input  wire                  m_axi_wready,
    input  wire [AXI_IDW-1:0]   m_axi_bid,
    input  wire [1:0]            m_axi_bresp,
    input  wire                  m_axi_bvalid,
    output wire                  m_axi_bready,

    // Debug
    output wire dbg_gcm_tag_valid,

    // Test controls
    input  wire                  dbg_force_same_bucket,  // override req_b_new = req_b
    input  wire [BUCKET_W-1:0]  dbg_prng_override,      // when != 0, replaces prng_bucket
    input  wire                  perf_reset,              // clear all perf counters
    output wire dbg_gcm_tag_match,
    output wire [4:0]            dbg_state,
    output wire                  dbg_client_done,
    output wire                  dbg_client_req,
    output wire [BUCKET_W-1:0]  dbg_req_b,
    output wire [BUCKET_W-1:0]  dbg_req_b_new,
    output wire                  dbg_found_in_bucket,
    output wire                  dbg_found_in_stash,
    output wire                  dbg_same_bucket,
    output wire                  dbg_err_stash_ovf,
    output wire [PTR_W:0]       dbg_stash_occ,

    // Performance counters - 4 categories:
    //   rb = READ,  found in bucket    (needs decrypt + re-encrypt)
    //   rs = READ,  found in stash     (stash read, no decrypt)
    //   wb = WRITE, found in bucket    (encrypt to scratch)
    //   ws = WRITE, found in stash     (stash overwrite)
    // Each category tracks 8 phases + total + ops count.
    output reg  [31:0]  perf_rb_ddr_rd, perf_rb_decrypt, perf_rb_encrypt,
    output reg  [31:0]  perf_rb_compact, perf_rb_evict, perf_rb_ddr_wr,
    output reg  [31:0]  perf_rb_scan, perf_rb_stash,
    output reg  [31:0]  perf_rb_total, perf_rb_ops,

    output reg  [31:0]  perf_rs_ddr_rd, perf_rs_decrypt, perf_rs_encrypt,
    output reg  [31:0]  perf_rs_compact, perf_rs_evict, perf_rs_ddr_wr,
    output reg  [31:0]  perf_rs_scan, perf_rs_stash,
    output reg  [31:0]  perf_rs_total, perf_rs_ops,

    output reg  [31:0]  perf_wb_ddr_rd, perf_wb_decrypt, perf_wb_encrypt,
    output reg  [31:0]  perf_wb_compact, perf_wb_evict, perf_wb_ddr_wr,
    output reg  [31:0]  perf_wb_scan, perf_wb_stash,
    output reg  [31:0]  perf_wb_total, perf_wb_ops,

    output reg  [31:0]  perf_ws_ddr_rd, perf_ws_decrypt, perf_ws_encrypt,
    output reg  [31:0]  perf_ws_compact, perf_ws_evict, perf_ws_ddr_wr,
    output reg  [31:0]  perf_ws_scan, perf_ws_stash,
    output reg  [31:0]  perf_ws_total, perf_ws_ops
);

    // =========================================================================
    // FSM States
    // =========================================================================
    // Phase 2 state machine (full-bucket verify / re-encrypt, constant time)
    localparam [4:0]
        S_IDLE         = 5'd0,
        S_POS_LOOKUP   = 5'd1,
        S_RD_GATE      = 5'd2,
        S_DDR_READ     = 5'd3,
        S_CR_IV        = 5'd4,
        S_CR_IVW       = 5'd5,
        S_CR_START     = 5'd6,
        S_CR_FEED      = 5'd7,
        S_CR_RECV      = 5'd8,
        S_CR_TAG       = 5'd9,
        S_SCAN         = 5'd10,
        S_OP           = 5'd11,
        S_CP           = 5'd12,
        S_COMPACT      = 5'd13,
        S_COMPACT2     = 5'd14,
        S_PM_UPD       = 5'd15,
        S_EVICT        = 5'd16,
        S_EVICT_CHK    = 5'd17,
        S_EVICT_DONE   = 5'd18,
        S_EVICT_WAIT   = 5'd19,
        S_EA_START     = 5'd20,
        S_WB_GATE      = 5'd21,
        S_DDR_WRITE    = 5'd22,
        S_DONE_GATE    = 5'd23,
        S_RES_STREAM   = 5'd24,
        S_FMT_START    = 5'd25,
        S_FMT_WRITE    = 5'd26,
        S_FMT_WAIT     = 5'd27,
        S_HALT         = 5'd28,
        S_LAYOUT       = 5'd29,   // place slot perm[k] at bucket k/C, position k mod C
        S_SHUFFLE      = 5'd30;   // Fisher-Yates shuffle of the slot numbers   // random lazy layout: every slot -> random bucket, all buckets empty   // F4: fail-stop (integrity failure / stash overflow)

    reg [4:0] state;

    // =========================================================================
    // Internal registers
    // =========================================================================
    reg [SLOT_AW-1:0]   req_slot_addr;
    reg                  req_op;
    reg [BUCKET_W-1:0]  req_b, req_b_new;
    reg [Z*SLOT_W-1:0]  bkt_slot_list;
    reg [FILL_W-1:0]    bkt_fill_count;
    reg                  same_bucket;
    reg                  found_in_bucket, found_in_stash;
    reg [POS_W-1:0]     found_pos;
    reg [PTR_W-1:0]     found_stash_idx;
    reg [PTR_W-1:0]     stash_alloc_idx;
    reg [SLOT_AW-1:0]   ev_slot_addr;     // registered copy of st_cam_bkt_slot_addr
    wire [PTR_W:0] stash_occupancy;
    reg [BEAT_W-1:0]    beat_cnt;
    reg [POS_W-1:0]     scan_pos;
    reg [FILL_W-1:0]    evict_slots_remaining;

    // AES-GCM feed control
    reg                  aes_half;
    reg [AXI_DW-1:0]    aes_beat_buf;
    reg [8:0]            aes_blk_cnt;
    reg [BEAT_W-1:0]    aes_out_beat;
    reg                  aes_out_half;
    reg [AES_BLK_W-1:0] aes_out_lo;

    // Same-bucket read: buffer decrypted plaintext for re-encryption
    // We use stash data_mem as temporary storage (at stash_alloc_idx)
    // even though the slot won't be inserted into stash.
    // Alternative: a dedicated 4KB buffer. For simplicity, reuse stash data port.
    // Actually simpler: buffer the 128 plaintext beats in a small BRAM.
    // But we already have the plaintext coming out of GCM - we can pipeline
    // the re-encrypt right after decrypt finishes.
    // Approach: save the decrypted beats into stash data memory (as scratch space),
    // then read them back for re-encryption. This reuses existing stash data ports.
    // OR: pipeline decrypt output directly into encrypt input.
    //
    // Chosen approach: After decrypt finishes and data is returned to client,
    // we start a fresh encrypt. We read the plaintext from the stash data memory
    // where we temporarily stored it during decrypt (using stash_alloc_idx).
    // After encrypt, we DON'T call st_ins_en (don't actually insert into stash).
    // The stash entry is just scratch space.

    // Same-bucket write: we need to feed 128 beats of client data to GCM encrypt.
    // The client provides data beat-by-beat via client_wdata.

    // =========================================================================
    // AES-GCM Instance
    // =========================================================================
    reg          gcm_start;
    reg          gcm_encrypt;
    reg [127:0]  gcm_data_in;
    reg          gcm_data_valid;
    reg          gcm_data_last;
    wire [127:0] gcm_data_out;
    wire         gcm_data_out_valid;
    wire         gcm_data_out_last;
    reg  [127:0] gcm_tag_in;
    wire [127:0] gcm_tag_out;
    wire         gcm_tag_valid;
    wire         gcm_tag_match;
    wire         gcm_ready;
    wire         gcm_busy;
    wire         gcm_input_ready;
    wire [95:0]  gcm_iv_out;
    wire         gcm_iv_updated;
    wire         gcm_counter_overflow;

    (* max_fanout = 32 *) reg  [95:0]  gcm_iv_reg;

    aes_gcm_pipelined u_aes_gcm (
        .clk(clk), .rst_n(rst_n), .enable(1'b1),
        .start(gcm_start), .encrypt(gcm_encrypt),
        .key(aes_key), .iv(gcm_iv_reg),
        .data_in(gcm_data_in), .data_valid(gcm_data_valid),
        .data_last(gcm_data_last), .data_bytes_valid(4'd0),
        .data_out(gcm_data_out), .data_out_valid(gcm_data_out_valid),
        .data_out_last(gcm_data_out_last),
        .tag_in(gcm_tag_in), .tag_out(gcm_tag_out),
        .tag_valid(gcm_tag_valid), .tag_match(gcm_tag_match),
        .ready(gcm_ready), .busy(gcm_busy), .input_ready(gcm_input_ready),
        .iv_out(gcm_iv_out), .iv_updated(gcm_iv_updated),
        .counter_overflow(gcm_counter_overflow)
    );

    // =========================================================================
    // IV Slot Table
    // =========================================================================
    reg  [SLOT_AW-1:0]  ivt_rd_addr;
    reg                  ivt_rd_en;
    wire [95:0]          ivt_rd_iv;
    wire [127:0]         ivt_rd_tag;
    wire                 ivt_rd_valid;
    reg  [SLOT_AW-1:0]  ivt_wr_addr;
    reg  [95:0]          ivt_wr_iv;
    reg  [127:0]         ivt_wr_tag;
    reg                  ivt_wr_en;

    // Indexed by the concatenation {bucket, position}: B * 2^POS_W entries (more than
    // B*Z when Z is not a power of two), independent of the slot count N.
    iv_slot_table #(.N(B << POS_W), .SLOT_W(BUCKET_W + POS_W)) u_iv_table (   // index {b, p}: B * 2^POS_W entries
        .clk(clk), .rst_n(rst_n),
        .rd_slot_addr(ivt_rd_addr), .rd_en(ivt_rd_en),
        .rd_iv(ivt_rd_iv), .rd_tag(ivt_rd_tag), .rd_valid(ivt_rd_valid),
        .wr_slot_addr(ivt_wr_addr), .wr_iv(ivt_wr_iv),
        .wr_tag(ivt_wr_tag), .wr_en(ivt_wr_en)
    );

    // =========================================================================
    // Submodules (unchanged from original)
    // =========================================================================

    // --- pos_map ---
    reg  [SLOT_AW-1:0]  pm_rd_addr;  reg pm_rd_en;
    wire [BUCKET_W-1:0]  pm_rd_bucket; wire [1:0] pm_rd_status; wire pm_rd_valid;
    reg  [SLOT_AW-1:0]  pm_wr_addr;  reg [BUCKET_W-1:0] pm_wr_bucket;
    reg  [1:0]           pm_wr_status; reg pm_wr_en;

    wire [SLOT_AW-1:0]  pm_wr_addr_mux   = init_mode ? init_pm_wr_addr   : pm_wr_addr;
    wire [BUCKET_W-1:0] pm_wr_bucket_mux = init_mode ? init_pm_wr_bucket : pm_wr_bucket;
    wire [1:0]          pm_wr_status_mux = init_mode ? init_pm_wr_status : pm_wr_status;
    wire                pm_wr_en_mux     = init_mode ? init_pm_wr_en     : pm_wr_en;

    pos_map u_pos_map (
        .clk(clk), .rst_n(rst_n),
        .rd_slot_addr(pm_rd_addr), .rd_en(pm_rd_en),
        .rd_bucket(pm_rd_bucket), .rd_status(pm_rd_status), .rd_valid(pm_rd_valid),
        .wr_slot_addr(pm_wr_addr_mux), .wr_bucket(pm_wr_bucket_mux),
        .wr_status(pm_wr_status_mux), .wr_en(pm_wr_en_mux)
    );

    // --- bucket_meta ---
    reg  [BUCKET_W-1:0]  bm_rd_bucket; reg bm_rd_en;
    wire [Z*SLOT_W-1:0]  bm_rd_slot_list; wire [FILL_W-1:0] bm_rd_fill; wire bm_rd_valid;
    reg  [BUCKET_W-1:0]  bm_wr_bucket; reg [Z*SLOT_W-1:0] bm_wr_slot_list;
    reg  [FILL_W-1:0]    bm_wr_fill; reg bm_wr_en;

    wire [BUCKET_W-1:0]  bm_wr_bucket_mux    = init_mode ? init_bm_wr_bucket    : bm_wr_bucket;
    wire [Z*SLOT_W-1:0] bm_wr_slot_list_mux = init_mode ? init_bm_wr_slot_list : bm_wr_slot_list;
    wire [FILL_W-1:0]    bm_wr_fill_mux      = init_mode ? init_bm_wr_fill      : bm_wr_fill;
    wire                  bm_wr_en_mux        = init_mode ? init_bm_wr_en        : bm_wr_en;

    bucket_meta u_bucket_meta (
        .clk(clk), .rst_n(rst_n),
        .rd_bucket(bm_rd_bucket), .rd_en(bm_rd_en),
        .rd_slot_list(bm_rd_slot_list), .rd_fill_count(bm_rd_fill), .rd_valid(bm_rd_valid),
        .wr_bucket(bm_wr_bucket_mux), .wr_slot_list(bm_wr_slot_list_mux),
        .wr_fill_count(bm_wr_fill_mux), .wr_en(bm_wr_en_mux)
    );

    // --- PRNG ---
    reg prng_en;
    wire [BUCKET_W-1:0] prng_bucket;
    prng_lfsr #(.OUT_W(BUCKET_W)) u_prng (
        .clk(clk), .rst_n(rst_n),
        .seed({BUCKET_W{1'b0}}), .seed_valid(1'b0),
        .en(prng_en), .rand_out(), .rand_bucket(prng_bucket)
    );

    // --- scratch_buf ---
    wire [AXI_DW-1:0] scr_stream_in_data; wire scr_stream_in_valid;
    wire [9:0] scr_stream_in_beat_addr;
    reg  [9:0] scr_fsm_rd_addr; reg scr_fsm_rd_en;
    wire [AXI_DW-1:0] scr_fsm_rd_data; wire scr_fsm_rd_valid;
    reg  [9:0] scr_fsm_wr_addr; reg [AXI_DW-1:0] scr_fsm_wr_data; reg scr_fsm_wr_en;
    wire [9:0] scr_stream_out_beat_addr; wire scr_stream_out_rd_en;
    wire [AXI_DW-1:0] scr_stream_out_data; wire scr_stream_out_valid;

    scratch_buf u_scratch (
        .clk(clk), .rst_n(rst_n),
        .stream_in_data(scr_stream_in_data), .stream_in_valid(scr_stream_in_valid),
        .stream_in_beat_addr(scr_stream_in_beat_addr), .stream_in_ready(),
        .fsm_rd_addr(scr_fsm_rd_addr), .fsm_rd_en(scr_fsm_rd_en),
        .fsm_rd_data(scr_fsm_rd_data), .fsm_rd_valid(scr_fsm_rd_valid),
        .fsm_wr_addr(scr_fsm_wr_addr), .fsm_wr_data(scr_fsm_wr_data),
        .fsm_wr_en(scr_fsm_wr_en),
        .ev_wr_addr(scr_ev_wr_addr), .ev_wr_data(scr_ev_wr_data), .ev_wr_en(scr_ev_wr_en),
        .stream_out_beat_addr(scr_stream_out_beat_addr),
        .stream_out_rd_en(scr_stream_out_rd_en),
        .stream_out_data(scr_stream_out_data), .stream_out_valid(scr_stream_out_valid),
        .bank_conflict(scr_bank_conflict)
    );

    // --- stash ---
    reg  [SLOT_AW-1:0] st_ins_slot; reg [BUCKET_W-1:0] st_ins_tgt; reg st_ins_en;
    wire [PTR_W-1:0] st_ins_idx; wire st_ins_full;
    reg  [PTR_W-1:0] st_remap_idx; reg [BUCKET_W-1:0] st_remap_bkt; reg st_remap_en;
    reg  [PTR_W-1:0] st_evict_idx; reg st_evict_en;
    reg  [PTR_W-1:0] st_dwr_entry; reg [BEAT_W-1:0] st_dwr_beat;
    reg  [AXI_DW-1:0] st_dwr_data; reg st_dwr_en;
    reg  [PTR_W-1:0] st_drd_entry; reg [BEAT_W-1:0] st_drd_beat; reg st_drd_en;
    wire [AXI_DW-1:0] st_drd_data; wire st_drd_valid;
    wire st_cam_slot_hit; wire [PTR_W-1:0] st_cam_slot_idx;
    reg  [BUCKET_W-1:0] st_cam_bkt_target; reg st_cam_bkt_en;
    wire st_cam_bkt_hit; wire [PTR_W-1:0] st_cam_bkt_idx;
    wire [SLOT_AW-1:0] st_cam_bkt_slot_addr; wire st_cam_bkt_inhibit_busy;

    // One stash per client partition, STASH_DEPTH entries each. The access's
    // partition (req_part) selects the stash for every lookup, insert, remap,
    // eviction and data transfer; blocks of a partition only target its buckets.
    wire [NP-1:0] stp_cam_slot_hit;
    wire [NP*PTR_W-1:0] stp_cam_slot_idx;
    wire [NP-1:0] stp_cam_bkt_hit;
    wire [NP*PTR_W-1:0] stp_cam_bkt_idx;
    wire [NP*SLOT_AW-1:0] stp_cam_bkt_slot_addr;
    wire [NP-1:0] stp_cam_bkt_inhibit_busy;
    wire [NP*PTR_W-1:0] stp_ins_idx;
    wire [NP-1:0] stp_ins_full;
    wire [NP*AXI_DW-1:0] stp_drd_data;
    wire [NP-1:0] stp_drd_valid;
    genvar gp;
    generate
        for (gp = 0; gp < NP; gp = gp + 1) begin : g_stash
            wire sel = (req_part == gp);
            stash #(.DEPTH(STASH_DEPTH)) u_stash (
                .cam_slot_hit(stp_cam_slot_hit[gp]),
                .cam_slot_idx(stp_cam_slot_idx[gp*PTR_W +: PTR_W]),
                .cam_bkt_hit(stp_cam_bkt_hit[gp]),
                .cam_bkt_idx(stp_cam_bkt_idx[gp*PTR_W +: PTR_W]),
                .cam_bkt_slot_addr(stp_cam_bkt_slot_addr[gp*SLOT_AW +: SLOT_AW]),
                .cam_bkt_inhibit_busy(stp_cam_bkt_inhibit_busy[gp]),
                .ins_idx(stp_ins_idx[gp*PTR_W +: PTR_W]),
                .ins_full(stp_ins_full[gp]),
                .drd_data(stp_drd_data[gp*AXI_DW +: AXI_DW]),
                .drd_valid(stp_drd_valid[gp]),
                .clk(clk),
                .rst_n(rst_n),
                .cam_slot_addr(req_slot_addr),
                .cam_slot_en((1'b1) & sel),
                .cam_bkt_target(st_cam_bkt_target),
                .cam_bkt_en((st_cam_bkt_en) & sel),
                .ins_slot_addr(st_ins_slot),
                .ins_target_bucket(st_ins_tgt),
                .ins_en((st_ins_en) & sel),
                .remap_idx(st_remap_idx),
                .remap_new_bucket(st_remap_bkt),
                .remap_en((st_remap_en) & sel),
                .evict_idx(st_evict_idx),
                .evict_en((st_evict_en) & sel),
                .dwr_entry(st_dwr_entry),
                .dwr_beat(st_dwr_beat),
                .dwr_data(st_dwr_data),
                .dwr_en((st_dwr_en) & sel),
                .drd_entry(st_drd_entry),
                .drd_beat(st_drd_beat),
                .drd_en((st_drd_en) & sel),
                .occupancy(stash_occupancy));
        end
    endgenerate
    assign st_cam_slot_hit = stp_cam_slot_hit[req_part];
    assign st_cam_slot_idx = stp_cam_slot_idx[req_part*PTR_W +: PTR_W];
    assign st_cam_bkt_hit = stp_cam_bkt_hit[req_part];
    assign st_cam_bkt_idx = stp_cam_bkt_idx[req_part*PTR_W +: PTR_W];
    assign st_cam_bkt_slot_addr = stp_cam_bkt_slot_addr[req_part*SLOT_AW +: SLOT_AW];
    assign st_cam_bkt_inhibit_busy = stp_cam_bkt_inhibit_busy[req_part];
    assign st_ins_idx = stp_ins_idx[req_part*PTR_W +: PTR_W];
    assign st_ins_full = stp_ins_full[req_part];
    assign st_drd_data = stp_drd_data[req_part*AXI_DW +: AXI_DW];
    assign st_drd_valid = stp_drd_valid[req_part];

    // --- axi_master ---
    reg axim_cmd_read, axim_cmd_write; reg [BUCKET_W-1:0] axim_cmd_bucket;
    wire axim_read_done, axim_write_done, axim_busy;
    wire [AXI_DW-1:0] axim_rdata_data; wire axim_rdata_valid; wire [9:0] axim_rdata_beat;
    wire [9:0] axim_wdata_beat_req;

    axi_master u_axi_master (
        .clk(clk), .rst_n(rst_n),
        .cmd_read(axim_cmd_read), .cmd_write(axim_cmd_write),
        .cmd_bucket(axim_cmd_bucket),
        .cmd_read_done(axim_read_done), .cmd_write_done(axim_write_done),
        .cmd_busy(axim_busy),
        .rdata_data(axim_rdata_data), .rdata_valid(axim_rdata_valid),
        .rdata_beat_addr(axim_rdata_beat),
        .wdata_data(scr_stream_out_data), .wdata_valid(scr_stream_out_valid),
        .wdata_ready(), .wdata_beat_req(axim_wdata_beat_req),
        .wdata_hold(axim_wdata_hold), .wdata_stall(axim_wdata_stall),
        .m_axi_arid(m_axi_arid), .m_axi_araddr(m_axi_araddr),
        .m_axi_arlen(m_axi_arlen), .m_axi_arsize(m_axi_arsize),
        .m_axi_arburst(m_axi_arburst), .m_axi_arvalid(m_axi_arvalid),
        .m_axi_arready(m_axi_arready),
        .m_axi_rid(m_axi_rid), .m_axi_rdata(m_axi_rdata),
        .m_axi_rresp(m_axi_rresp), .m_axi_rlast(m_axi_rlast),
        .m_axi_rvalid(m_axi_rvalid), .m_axi_rready(m_axi_rready),
        .m_axi_awid(m_axi_awid), .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awlen(m_axi_awlen), .m_axi_awsize(m_axi_awsize),
        .m_axi_awburst(m_axi_awburst), .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awready(m_axi_awready),
        .m_axi_wdata(m_axi_wdata), .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wlast(m_axi_wlast), .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready),
        .m_axi_bid(m_axi_bid), .m_axi_bresp(m_axi_bresp),
        .m_axi_bvalid(m_axi_bvalid), .m_axi_bready(m_axi_bready)
    );

    assign scr_stream_in_data      = axim_rdata_data;
    assign scr_stream_in_valid     = axim_rdata_valid;
    assign scr_stream_in_beat_addr = axim_rdata_beat;
    assign scr_stream_out_beat_addr = axim_wdata_beat_req;
    assign axim_wdata_hold = wb_active && (enc_pos_done < Z) &&
                             ({1'b0, axim_wdata_beat_req[BEAT_AW +: POS_W]} >= enc_pos_done);
    // Write-back streams while later positions are still being encrypted: the
    // master may only read positions already re-encrypted (never plaintext), and
    // the scratch read is suppressed while it is held.
    assign scr_stream_out_rd_en = (wb_active && !axim_wdata_hold) || (state == S_FMT_WAIT);
    assign client_wdata_beat_req = beat_cnt;

    // =========================================================================
    // Helper functions
    // =========================================================================
    function [SLOT_AW-1:0] get_slot_at;
        input [Z*SLOT_W-1:0] list; input [POS_W-1:0] pos;
        integer base;
        begin base = pos * SLOT_W; get_slot_at = list[base +: SLOT_W] << 12; end
    endfunction

    function [Z*SLOT_W-1:0] set_slot_at;
        input [Z*SLOT_W-1:0] list; input [POS_W-1:0] pos; input [SLOT_W-1:0] val;
        integer base;
        begin set_slot_at = list; base = pos * SLOT_W; set_slot_at[base +: SLOT_W] = val; end
    endfunction

    function [9:0] scr_addr;
        input [POS_W-1:0] p; input [BEAT_W-1:0] b;
        begin scr_addr = {p, b[6:0]}; end
    endfunction

    // =========================================================================
    // Debug
    // =========================================================================
    assign dbg_state          = state;
    assign dbg_client_done    = client_done;
    assign dbg_client_req     = client_req;
    assign dbg_req_b          = req_b;
    assign dbg_req_b_new      = req_b_new;
    assign dbg_found_in_bucket = found_in_bucket;
    assign dbg_found_in_stash = found_in_stash;
    assign dbg_same_bucket    = same_bucket;
    assign dbg_err_stash_ovf  = err_stash_overflow;
    assign dbg_stash_occ      = stash_occupancy;
    assign dbg_gcm_tag_valid = gcm_tag_valid;
    assign dbg_gcm_tag_match = gcm_tag_match;
    // =========================================================================
    // Main FSM
    // =========================================================================
    // =========================================================================
    // Phase 2 (F3, F5-F8): full-bucket verify / re-encrypt, constant time
    // =========================================================================
    // Every access: read the whole bucket, decrypt and VERIFY all Z positions
    // (holes included), do the operation on plaintext, evict, RE-ENCRYPT all Z
    // positions with fresh IVs, write the whole bucket back. Bucket read,
    // write-back and result release happen at fixed cycle counts after
    // acceptance (CT_RD / CT_WB / CT_DONE); results are released only after
    // verification. Any integrity failure, stash overflow or timing overrun is
    // sticky and fail-stop. After reset (once a key is loaded) a format pass
    // writes an encrypted zero block to every position of every bucket.
    localparam integer CT_RD   = `ORAM_CT_RD;
    localparam integer CT_WB   = `ORAM_CT_WB;
    localparam integer CT_DONE = `ORAM_CT_DONE;
    localparam [1:0] CR_DA = 2'd0, CR_EA = 2'd1, CR_FMT = 2'd2;
    localparam [1:0] CPS_SCR = 2'd0, CPS_STASH = 2'd1, CPS_CLIENT = 2'd2;
    reg  [31:0]       ct_cnt;
    // Crypto streaming
    reg  [10:0]       landed_beats;    // read-stream beats in scratch for this access
    reg  [3:0]        enc_pos_done;    // positions fully re-encrypted (0..Z)
    reg               wb_pending;      // write-back not yet issued (issued at CT_WB)
    reg               wb_active;       // write-back in progress
    reg               wb_done_seen;
    wire              axim_wdata_hold, axim_wdata_stall, scr_bank_conflict;
    // Eviction overlap: the eviction loop only decides (which stash entry goes to
    // which position); a background engine performs the 128-beat copies while the
    // encryption runs, and encryption of a position waits only for its own copy.
    reg  [PTR_W-1:0]  evq_ent [0:7];   // copy queue: source stash entry
    reg  [POS_W-1:0]  evq_pos [0:7];   //             destination position
    reg  [3:0]        evq_wp, evq_rp;
    reg  [7:0]        ev_pending;      // positions whose eviction copy is not done
    reg               ec_active;
    reg  [PTR_W-1:0]  ec_ent;
    reg  [POS_W-1:0]  ec_pos;
    reg  [7:0]        ec_rd_beat, ec_wr_beat;
    reg  [9:0]        scr_ev_wr_addr; reg [AXI_DW-1:0] scr_ev_wr_data; reg scr_ev_wr_en;
    // Board calibration: in debug builds these are tagged for ILA insertion
    // (Set Up Debug picks up mark_debug nets); they hold the worst arrival seen.
`ifdef ORAM_DEBUG_PORTS
    (* mark_debug = "true" *) reg [31:0] ct_max_rd, ct_max_wb, ct_max_done;
`else
    reg  [31:0]       ct_max_rd, ct_max_wb, ct_max_done;
`endif
    reg               err_ct_overrun_r, fmt_done_r;
    reg  [BUCKET_W:0] fmt_b;
    reg  [9:0]        lay_i;
    // One ORAM per client: partition p owns slots p*N_PART.. and buckets p*B_PART..
    localparam PART_W = `ORAM_PART_W;
    localparam NP     = 1 << PART_W;
    localparam N_PART = N >> PART_W;
    localparam B_PART = B >> PART_W;
    localparam BL_W   = BUCKET_W - PART_W;          // bucket index within a partition
    localparam PW     = (PART_W > 0) ? PART_W : 1;   // register width; a constant 0 when unpartitioned
    localparam [BUCKET_W-1:0] BL_MASK = {BUCKET_W{1'b1}} >> PART_W;
    reg  [PW-1:0]     req_part;                     // partition of the current access
    reg  [PW-1:0]     lay_p;                        // partition being laid out at boot
    wire [9:0]        lay_div   = lay_i / C;        // bucket within the partition (any lambda)
    wire [BL_W-1:0]   lay_bkt   = lay_div[BL_W-1:0];
    localparam BEAT_AW = $clog2(BEATS);             // beat index bits within a block
    wire [PW-1:0]     in_part = (PART_W > 0) ? client_slot_addr[SLOT_W+11 -: PW] : {PW{1'b0}};
    // first bucket / first slot of a partition (0 when there is a single ORAM)
    wire [BUCKET_W-1:0] req_part_w = req_part, in_part_w = in_part, lay_p_w = lay_p;
    wire [SLOT_W-1:0]   lay_p_s    = lay_p;
    wire [BUCKET_W-1:0] req_bbase  = (PART_W > 0) ? (req_part_w << BL_W) : {BUCKET_W{1'b0}};
    wire [BUCKET_W-1:0] in_bbase   = (PART_W > 0) ? (in_part_w  << BL_W) : {BUCKET_W{1'b0}};
    wire [BUCKET_W-1:0] lay_bbase  = (PART_W > 0) ? (lay_p_w    << BL_W) : {BUCKET_W{1'b0}};
    wire [SLOT_W-1:0]   lay_sbase  = (PART_W > 0) ? (lay_p_s << (SLOT_W - PART_W)) : {SLOT_W{1'b0}};
    wire [BUCKET_W-1:0] b_new_sel  = (|dbg_prng_override) ? dbg_prng_override : rnd_bucket_q;
    wire [BUCKET_W-1:0] b_new_part = req_bbase | (b_new_sel & BL_MASK);
    // Boot layout: every slot starts valid at a uniformly random position, C per
    // bucket. An inside-out Fisher-Yates shuffle of 0..N-1 gives the permutation; its random
    // numbers come from a 16-bit LFSR seeded from the per-boot IV seed (a stand-in
    // for the TRNG, like the other generators).
    reg  [SLOT_W-PART_W-1:0] perm [0:N_PART-1];   // one partition at a time
    wire [SLOT_W-1:0] lay_slot = lay_sbase | perm[lay_i[SLOT_W-PART_W-1:0]];   // slot placed at layout step lay_i
    reg  [9:0]        shuf_i;
    reg  [15:0]       shuf_lfsr;
    reg  [4:0]        shuf_steps;
    reg  [C*SLOT_W-1:0] lay_list;
    wire [15:0]       shuf_lfsr_next = {shuf_lfsr[14:0], shuf_lfsr[15] ^ shuf_lfsr[14] ^ shuf_lfsr[12] ^ shuf_lfsr[3]};
    wire [25:0]       shuf_prod = shuf_lfsr * {6'd0, shuf_i + 10'd1};   // j = floor(r * (i+1) / 2^16)
    wire [9:0]        shuf_j    = shuf_prod[25:16];
    reg               req_dummy;          // Phase 3: current access is a dummy
    // PRNG decorrelation (LFSR stand-in for a TRNG): a value is latched when it
    // is used, then the 12-bit LFSR steps BUCKET_W more times before the next
    // use, so consecutive uses do not share bits.
    reg  [3:0]          prng_steps;
    reg  [BUCKET_W-1:0] rnd_bucket_q;
    reg  [1:0]        cr_mode;
    reg  [POS_W:0]    cr_pos;
    reg               cr_zero;
    reg  [1:0]        cr_wait;
    reg               tag_seen, tag_match_q;
    reg  [127:0]      tag_q;
    reg  [95:0]       iv_q;
    reg  [1:0]        cp_src;
    reg               cp_to_stash, cp_to_scr, cp_to_res;
    reg  [POS_W-1:0]  cp_src_pos, cp_dst_pos;
    reg  [PTR_W-1:0]  cp_src_ent, cp_dst_ent;
    reg  [BEAT_W:0]   cp_rd_beat, cp_wr_beat;
    reg  [4:0]        cp_ret;
    reg  [PTR_W-1:0]  tgt_ent, ev_ent;
    reg  [POS_W:0]    fill;
    reg               res_zero;
    reg  [BEAT_W:0]   res_beat, res_out_beat;
    reg  [1:0]        res_pipe;
    // result buffer (BRAM): written by the copy engine, read at release time
    reg  [AXI_DW-1:0] res_buf [0:BEATS-1];
    reg               res_wr_en;
    reg  [6:0]        res_wr_addr, res_rd_addr;
    reg  [AXI_DW-1:0] res_wr_data, res_rd_data;
    always @(posedge clk) begin
        if (res_wr_en) res_buf[res_wr_addr] <= res_wr_data;
        res_rd_data <= res_buf[res_rd_addr];
    end
    assign err_ct_overrun = err_ct_overrun_r;
    assign fmt_done       = fmt_done_r;
    function [SLOT_W-1:0] slot_id_at;
        input [Z*SLOT_W-1:0] list; input [POS_W-1:0] pos;
        begin slot_id_at = list[pos*SLOT_W +: SLOT_W]; end
    endfunction
    function [SLOT_AW-1:0] ivt_addr;          // IV/tag table keyed by (bucket, position)
        input [BUCKET_W-1:0] b; input [POS_W-1:0] p;
        begin ivt_addr = {{(SLOT_AW-BUCKET_W-POS_W-12){1'b0}}, b, p, 12'd0}; end
    endfunction
    wire              cp_data_ok = (cp_src == CPS_SCR)   ? scr_fsm_rd_valid :
                                   (cp_src == CPS_STASH) ? st_drd_valid : client_wdata_valid;
    wire [AXI_DW-1:0] cp_data    = (cp_src == CPS_SCR)   ? scr_fsm_rd_data :
                                   (cp_src == CPS_STASH) ? st_drd_data : client_wdata;
    reg  [31:0] acc_ddr_rd, acc_decrypt, acc_encrypt, acc_compact, acc_evict, acc_ddr_wr,
                acc_scan, acc_stash, acc_total;
    reg         acc_commit;
    always @(posedge clk) begin
        if (!rst_n) begin
            state <= S_IDLE;
            client_done <= 0; client_stall <= 1; client_rdata_valid <= 0;
            client_rdata <= 0; client_rdata_beat <= 0;
            err_bucket_overflow <= 0; err_stash_overflow <= 0; err_tag_mismatch <= 0;
            err_ct_overrun_r <= 0; fmt_done_r <= 0; fmt_b <= 0;
            pm_rd_en <= 0; pm_wr_en <= 0; bm_rd_en <= 0; bm_wr_en <= 0; prng_en <= 0;
            ivt_rd_en <= 0; ivt_wr_en <= 0; axim_cmd_read <= 0; axim_cmd_write <= 0;
            gcm_start <= 0; gcm_data_valid <= 0; gcm_data_last <= 0; gcm_encrypt <= 0; gcm_iv_reg <= 0;
            scr_fsm_rd_en <= 0; scr_fsm_wr_en <= 0; scr_ev_wr_en <= 0;
            st_ins_en <= 0; st_remap_en <= 0; st_evict_en <= 0; st_dwr_en <= 0; st_drd_en <= 0;
            st_cam_bkt_en <= 0; st_cam_bkt_target <= 0;
            res_wr_en <= 0; res_rd_addr <= 0; res_pipe <= 0;
            ct_cnt <= 0; ct_max_rd <= 0; ct_max_wb <= 0; ct_max_done <= 0;
            landed_beats <= 0; enc_pos_done <= 0; wb_pending <= 0; wb_active <= 0; wb_done_seen <= 0;
            evq_wp <= 0; evq_rp <= 0; ev_pending <= 0; ec_active <= 0; ec_rd_beat <= 0; ec_wr_beat <= 0;
            tag_seen <= 0; beat_cnt <= 0; acc_commit <= 0;
            prng_steps <= 0; rnd_bucket_q <= 0; lay_i <= 0; req_dummy <= 0; req_part <= 0; lay_p <= 0;
        end else begin
            client_done <= 0; client_rdata_valid <= 0;
            pm_rd_en <= 0; pm_wr_en <= 0; bm_rd_en <= 0; bm_wr_en <= 0; prng_en <= 0;
            ivt_rd_en <= 0; ivt_wr_en <= 0; axim_cmd_read <= 0; axim_cmd_write <= 0;
            gcm_start <= 0; gcm_data_valid <= 0; gcm_data_last <= 0;
            scr_fsm_rd_en <= 0; scr_fsm_wr_en <= 0; scr_ev_wr_en <= 0;
            st_ins_en <= 0; st_remap_en <= 0; st_evict_en <= 0; st_dwr_en <= 0; st_drd_en <= 0;
            res_wr_en <= 0; acc_commit <= 0;
            if (state != S_IDLE && fmt_done_r) ct_cnt <= ct_cnt + 32'd1;
            // ---- crypto streaming (independent of the FSM state) ----
            if (scr_stream_in_valid) landed_beats <= landed_beats + 11'd1;
            if (bm_rd_valid) begin                       // bucket metadata (read issued at S_RD_GATE)
                bkt_slot_list  <= bm_rd_slot_list;
                bkt_fill_count <= bm_rd_fill;
            end
            // write-back starts at exactly CT_WB, wherever the encryption is
            if (wb_pending && CT_WB != 0 && ct_cnt >= CT_WB) begin
                axim_cmd_bucket <= req_b; axim_cmd_write <= 1'b1;
                wb_pending <= 1'b0; wb_active <= 1'b1;
            end
            if (axim_write_done) begin wb_active <= 1'b0; wb_done_seen <= 1'b1; end
            // the write-back caught up with the encryption (budget too early), or
            // two streams met in one scratch bank: timing violation -> fail-stop
            if (axim_wdata_stall || scr_bank_conflict) err_ct_overrun_r <= 1'b1;
            // ---- background eviction-copy engine: stash entry -> bucket position ----
            // Safe to read entries the eviction loop already marked free: nothing is
            // inserted into the stash between eviction and the end of this access,
            // and encryption (hence the access) cannot finish before every copy.
            if (!ec_active && evq_rp != evq_wp) begin
                ec_active <= 1'b1; ec_ent <= evq_ent[evq_rp[2:0]]; ec_pos <= evq_pos[evq_rp[2:0]];
                ec_rd_beat <= 0; ec_wr_beat <= 0;
            end
            if (ec_active) begin
                if (ec_rd_beat < BEATS) begin
                    st_drd_entry <= ec_ent; st_drd_beat <= {{(BEAT_W-8){1'b0}}, ec_rd_beat};
                    st_drd_en <= 1'b1; ec_rd_beat <= ec_rd_beat + 8'd1;
                end
                if (st_drd_valid && ec_wr_beat < BEATS) begin
                    scr_ev_wr_addr <= scr_addr(ec_pos, {{(BEAT_W-8){1'b0}}, ec_wr_beat});
                    scr_ev_wr_data <= st_drd_data; scr_ev_wr_en <= 1'b1;
                    ec_wr_beat <= ec_wr_beat + 8'd1;
                end
                if (ec_wr_beat == BEATS) begin
                    ec_active <= 1'b0; evq_rp <= evq_rp + 4'd1;
                    ev_pending[ec_pos] <= 1'b0;
                end
            end
            if (prng_steps != 0) begin prng_en <= 1; prng_steps <= prng_steps - 1'b1; end
            if (gcm_tag_valid) begin
                tag_seen <= 1'b1; tag_match_q <= gcm_tag_match;
                tag_q <= gcm_tag_out; iv_q <= gcm_iv_out;
            end
            case (state)
                S_IDLE: begin
                    client_stall <= !fmt_done_r;
                    if (err_tag_mismatch || err_stash_overflow || err_ct_overrun_r) begin
                        client_stall <= 1;
                        state <= S_HALT;                  // fail-stop
                    end else if (!fmt_done_r) begin
                        if (aes_key != 128'd0) begin      // key loaded: format DDR
                            fmt_b <= 0;
                            state <= S_FMT_START;
                        end
                    end else if (client_req && client_dummy) begin
                        // Dummy access: a uniformly random bucket (PRNG stand-in), then the
                        // exact real path -- read gate, verify all Z, evict, re-encrypt all Z,
                        // write-back and release gates -- with no target, data or completion.
                        req_dummy     <= 1'b1;
                        req_op        <= 1'b1;        // silent release window
                        req_slot_addr <= {SLOT_AW{1'b0}};
                        req_part      <= in_part;      // the window owner's partition
                        req_b         <= in_bbase | (prng_bucket & BL_MASK); prng_steps <= BUCKET_W;
                        client_stall  <= 1;
                        ct_cnt        <= 32'd0;
                        res_zero      <= 1'b0;
                        state         <= S_RD_GATE;
                    end else if (client_req) begin
                        req_dummy     <= 1'b0;
                        req_slot_addr <= client_slot_addr;
                        req_part      <= in_part;
                        req_op        <= client_op;
                        client_stall  <= 1;
                        ct_cnt        <= 32'd0;
                        res_zero      <= 1'b0;
                        pm_rd_addr    <= client_slot_addr; pm_rd_en <= 1;
                        rnd_bucket_q  <= prng_bucket; prng_steps <= BUCKET_W;   // use, then decorrelate
                        state         <= S_POS_LOOKUP;
                    end
                end
                S_POS_LOOKUP: begin
                    if (pm_rd_valid) begin
                        req_b       <= pm_rd_bucket;
                        // the new bucket stays inside the access's own partition
                        req_b_new   <= dbg_force_same_bucket ? pm_rd_bucket : b_new_part;
                        same_bucket <= dbg_force_same_bucket ? 1'b1 : (b_new_part == pm_rd_bucket);
                        if (ct_cnt + 1 > ct_max_rd) ct_max_rd <= ct_cnt + 1;
                        if (CT_RD != 0 && ct_cnt + 1 > CT_RD) err_ct_overrun_r <= 1'b1;
                        state <= S_RD_GATE;
                    end
                end
                S_RD_GATE: begin
                    if (CT_RD == 0 || ct_cnt >= CT_RD) begin
                        bm_rd_bucket <= req_b; bm_rd_en <= 1;
                        axim_cmd_bucket <= req_b; axim_cmd_read <= 1;
                        landed_beats <= 0; enc_pos_done <= 0;
                        evq_wp <= 0; evq_rp <= 0; ev_pending <= 0; ec_active <= 0;
                        wb_pending <= 1'b1; wb_active <= 1'b0; wb_done_seen <= 1'b0;
                        // streaming: start the verify loop now; each position waits
                        // only until its own beats have landed (S_CR_IV)
                        cr_mode <= CR_DA; cr_pos <= 0; cr_zero <= 1'b0;
                        state <= S_CR_IV;
                    end
                end
                S_DDR_READ: begin
                    if (bm_rd_valid) begin
                        bkt_slot_list  <= bm_rd_slot_list;
                        bkt_fill_count <= bm_rd_fill;
                    end
                    if (axim_read_done) begin
                        cr_mode <= CR_DA; cr_pos <= 0; cr_zero <= 1'b0;
                        state <= S_CR_IV;
                    end
                end
                S_CR_IV: begin
                    beat_cnt <= 0; aes_half <= 0; aes_out_beat <= 0; aes_out_half <= 0;
                    tag_seen <= 1'b0; cr_wait <= 2'd0;
                    if (cr_mode == CR_DA) begin
                        if (landed_beats >= ({7'd0, cr_pos} + 11'd1) * BEATS) begin
                            ivt_rd_addr <= ivt_addr(req_b, cr_pos[POS_W-1:0]); ivt_rd_en <= 1;
                            state <= S_CR_IVW;
                        end                                 // else: position still landing
                    end else if (!(cr_mode == CR_EA && ev_pending[cr_pos[POS_W-1:0]])) begin
                        gcm_encrypt <= 1'b1; gcm_iv_reg <= aes_iv_seed; gcm_start <= 1'b1;
                        state <= S_CR_START;
                    end                                 // else: eviction copy into this position still running
                end
                S_CR_IVW: begin
                    if (ivt_rd_valid) begin
                        gcm_iv_reg <= ivt_rd_iv; gcm_tag_in <= ivt_rd_tag;
                        gcm_encrypt <= 1'b0; gcm_start <= 1'b1;
                        state <= S_CR_START;
                    end
                end
                S_CR_START: begin
                    if (cr_wait != 2'd3) cr_wait <= cr_wait + 2'd1;
                    else if (gcm_input_ready) state <= S_CR_FEED;
                end
                S_CR_FEED, S_CR_RECV: begin
                    if (state == S_CR_FEED) begin
                        if (!cr_zero) begin
                            if (!scr_fsm_rd_valid && !aes_half) begin
                                scr_fsm_rd_addr <= scr_addr(cr_pos[POS_W-1:0], beat_cnt);
                                scr_fsm_rd_en   <= 1;
                            end
                            if (scr_fsm_rd_valid && gcm_input_ready && !aes_half) begin
                                gcm_data_in <= scr_fsm_rd_data[127:0]; gcm_data_valid <= 1;
                                aes_beat_buf <= scr_fsm_rd_data; aes_half <= 1;
                                if (beat_cnt < BEATS - 1) begin
                                    scr_fsm_rd_addr <= scr_addr(cr_pos[POS_W-1:0], beat_cnt + 1);
                                    scr_fsm_rd_en   <= 1;
                                end
                            end
                        end else if (gcm_input_ready && !aes_half) begin
                            gcm_data_in <= 128'd0; gcm_data_valid <= 1;
                            aes_beat_buf <= {AXI_DW{1'b0}}; aes_half <= 1;
                        end
                        if (gcm_input_ready && aes_half) begin
                            gcm_data_in <= aes_beat_buf[255:128]; gcm_data_valid <= 1;
                            gcm_data_last <= (beat_cnt == BEATS - 1);
                            aes_half <= 0;
                            if (beat_cnt < BEATS - 1) beat_cnt <= beat_cnt + 1;
                            else state <= S_CR_RECV;
                        end
                    end
                    if (gcm_data_out_valid) begin
                        if (!aes_out_half) begin
                            aes_out_lo <= gcm_data_out; aes_out_half <= 1;
                        end else begin
                            scr_fsm_wr_addr <= scr_addr(cr_pos[POS_W-1:0], aes_out_beat);
                            scr_fsm_wr_data <= {gcm_data_out, aes_out_lo};
                            scr_fsm_wr_en   <= 1;
                            aes_out_half <= 0; aes_out_beat <= aes_out_beat + 1;
                        end
                    end
                    if (state == S_CR_RECV && aes_out_beat == BEATS && !aes_out_half)
                        state <= S_CR_TAG;
                end
                S_CR_TAG: begin
                    if (tag_seen) begin
                        if (cr_mode == CR_DA && !tag_match_q) begin
                            err_tag_mismatch <= 1'b1;    // EVERY position must verify
                            client_stall <= 1;
                            state <= S_HALT;
                        end else begin
                            if (cr_mode != CR_DA) begin  // record the fresh IV + tag
                                ivt_wr_addr <= ivt_addr(req_b, cr_pos[POS_W-1:0]);
                                ivt_wr_iv   <= iv_q; ivt_wr_tag <= tag_q; ivt_wr_en <= 1;
                            end
                            if (cr_mode == CR_EA) enc_pos_done <= {1'b0, cr_pos} + 4'd1;
                            if (cr_pos == Z - 1) begin
                                if (cr_mode == CR_EA && ct_cnt > ct_max_wb) ct_max_wb <= ct_cnt;  // encryption end
                                state <= (cr_mode == CR_DA) ? S_SCAN :
                                         (cr_mode == CR_EA) ? ((CT_WB == 0) ? S_WB_GATE : S_DDR_WRITE) :
                                                              S_FMT_WRITE;
                            end
                            else begin
                                cr_pos <= cr_pos + 1'b1;
                                state  <= S_CR_IV;
                            end
                        end
                    end
                end
                S_SCAN: begin
                    begin : scan_block
                        integer i; reg hit; reg [POS_W-1:0] hit_pos;
                        hit = 0; hit_pos = 0;
                        for (i = 0; i < Z; i = i + 1)
                            if (i < bkt_fill_count)
                                if (get_slot_at(bkt_slot_list, i[POS_W-1:0]) == req_slot_addr)
                                    begin hit = 1; hit_pos = i[POS_W-1:0]; end
                        found_in_bucket <= hit;
                        found_pos       <= hit_pos;
                    end
                    found_in_stash  <= st_cam_slot_hit;
                    found_stash_idx <= st_cam_slot_idx;
                    fill <= bkt_fill_count[POS_W:0];
                    state <= S_OP;
                end
                S_OP: begin
                    cp_rd_beat <= 0; cp_wr_beat <= 0; beat_cnt <= 0;
                    cp_to_stash <= 0; cp_to_scr <= 0; cp_to_res <= 0;
                    if (req_dummy) begin
                        state <= S_EVICT;            // dummy: no target -- just evict
                    end else if (found_in_bucket) begin
                        if (st_ins_full) begin
                            err_stash_overflow <= 1'b1; client_stall <= 1; state <= S_HALT;
                        end else begin
                            tgt_ent <= st_ins_idx;
                            st_ins_slot <= req_slot_addr; st_ins_tgt <= req_b_new; st_ins_en <= 1;
                            cp_dst_ent <= st_ins_idx; cp_to_stash <= 1;
                            if (req_op) cp_src <= CPS_CLIENT;
                            else begin cp_src <= CPS_SCR; cp_src_pos <= found_pos; cp_to_res <= 1; end
                            cp_ret <= S_COMPACT;
                            state  <= S_CP;
                        end
                    end else if (found_in_stash) begin
                        tgt_ent <= found_stash_idx;
                        st_remap_idx <= found_stash_idx; st_remap_bkt <= req_b_new; st_remap_en <= 1;
                        if (req_op) begin cp_src <= CPS_CLIENT; cp_dst_ent <= found_stash_idx; cp_to_stash <= 1; end
                        else        begin cp_src <= CPS_STASH; cp_src_ent <= found_stash_idx; cp_to_res <= 1; end
                        cp_ret <= S_PM_UPD;
                        state  <= S_CP;
                    end else if (req_op) begin
                        if (st_ins_full) begin
                            err_stash_overflow <= 1'b1; client_stall <= 1; state <= S_HALT;
                        end else begin
                            tgt_ent <= st_ins_idx;
                            st_ins_slot <= req_slot_addr; st_ins_tgt <= req_b_new; st_ins_en <= 1;
                            cp_src <= CPS_CLIENT; cp_dst_ent <= st_ins_idx; cp_to_stash <= 1;
                            cp_ret <= S_PM_UPD;
                            state  <= S_CP;
                        end
                    end else begin
                        // read of a never-written slot: zeros, but STILL remap it --
                        // otherwise two reads of the same slot touch the same bucket
                        res_zero <= 1'b1;
                        pm_wr_addr <= req_slot_addr; pm_wr_bucket <= req_b_new;
                        pm_wr_status <= `ST_DUMMY; pm_wr_en <= 1;
                        state <= S_EVICT;
                    end
                end
                S_CP: begin
                    if (cp_src == CPS_SCR && cp_rd_beat < BEATS) begin
                        scr_fsm_rd_addr <= scr_addr(cp_src_pos, cp_rd_beat[BEAT_W-1:0]);
                        scr_fsm_rd_en <= 1; cp_rd_beat <= cp_rd_beat + 1'b1;
                    end
                    if (cp_src == CPS_STASH && cp_rd_beat < BEATS) begin
                        st_drd_entry <= cp_src_ent; st_drd_beat <= cp_rd_beat[BEAT_W-1:0];
                        st_drd_en <= 1; cp_rd_beat <= cp_rd_beat + 1'b1;
                    end
                    if (cp_data_ok && cp_wr_beat < BEATS) begin
                        if (cp_to_stash) begin
                            st_dwr_entry <= cp_dst_ent; st_dwr_beat <= cp_wr_beat[BEAT_W-1:0];
                            st_dwr_data <= cp_data; st_dwr_en <= 1;
                        end
                        if (cp_to_scr) begin
                            scr_fsm_wr_addr <= scr_addr(cp_dst_pos, cp_wr_beat[BEAT_W-1:0]);
                            scr_fsm_wr_data <= cp_data; scr_fsm_wr_en <= 1;
                        end
                        if (cp_to_res) begin
                            res_wr_addr <= cp_wr_beat[6:0]; res_wr_data <= cp_data; res_wr_en <= 1;
                        end
                        cp_wr_beat <= cp_wr_beat + 1'b1;
                        if (cp_src == CPS_CLIENT) beat_cnt <= beat_cnt + 1;
                    end
                    if (cp_wr_beat == BEATS) state <= cp_ret;
                end
                S_COMPACT: begin
                    cp_rd_beat <= 0; cp_wr_beat <= 0;
                    if ({1'b0, found_pos} != fill - 1'b1) begin
                        bkt_slot_list <= set_slot_at(bkt_slot_list, found_pos,
                                         slot_id_at(bkt_slot_list, fill[POS_W-1:0] - 1'b1));
                        cp_src <= CPS_SCR; cp_src_pos <= fill[POS_W-1:0] - 1'b1;
                        cp_to_stash <= 0; cp_to_res <= 0; cp_to_scr <= 1; cp_dst_pos <= found_pos;
                        cp_ret <= S_COMPACT2;
                        state  <= S_CP;
                    end else
                        state <= S_COMPACT2;
                end
                S_COMPACT2: begin
                    fill  <= fill - 1'b1;
                    state <= S_PM_UPD;
                end
                S_PM_UPD: begin
                    pm_wr_addr <= req_slot_addr; pm_wr_bucket <= req_b_new;
                    pm_wr_status <= `ST_IN_STASH; pm_wr_en <= 1;
                    state <= S_EVICT;
                end
                S_EVICT: begin
                    st_cam_bkt_target <= req_b; st_cam_bkt_en <= 1;
                    state <= S_EVICT_CHK;
                end
                S_EVICT_CHK: begin
                    cp_rd_beat <= 0; cp_wr_beat <= 0;
                    if (st_cam_bkt_inhibit_busy) begin
                        // the stash masks the entry it just evicted for one cycle:
                        // look again next cycle (stopping here limited eviction to
                        // one block per access -- audit fix)
                    end else if (fill < Z && st_cam_bkt_hit) begin
                        ev_ent <= st_cam_bkt_idx; ev_slot_addr <= st_cam_bkt_slot_addr;
                        // eviction overlap: queue the 128-beat copy; the background
                        // engine runs it while later decisions and encryption proceed
                        evq_ent[evq_wp[2:0]] <= st_cam_bkt_idx;
                        evq_pos[evq_wp[2:0]] <= fill[POS_W-1:0];
                        evq_wp <= evq_wp + 4'd1;
                        ev_pending[fill[POS_W-1:0]] <= 1'b1;
                        state <= S_EVICT_DONE;
                    end else begin
                        st_cam_bkt_en <= 0;
                        state <= S_EA_START;
                    end
                end
                S_EVICT_DONE: begin
                    bkt_slot_list <= set_slot_at(bkt_slot_list, fill[POS_W-1:0], ev_slot_addr[SLOT_W+11:12]);
                    fill <= fill + 1'b1;
                    st_evict_idx <= ev_ent; st_evict_en <= 1;
                    pm_wr_addr <= ev_slot_addr; pm_wr_bucket <= req_b;
                    pm_wr_status <= `ST_VALID; pm_wr_en <= 1;
                    state <= S_EVICT_WAIT;
                end
                S_EVICT_WAIT: state <= S_EVICT_CHK;
                S_EA_START: begin
                    bm_wr_bucket <= req_b; bm_wr_slot_list <= bkt_slot_list;
                    bm_wr_fill <= fill[FILL_W-1:0]; bm_wr_en <= 1;
                    cr_mode <= CR_EA; cr_pos <= 0; cr_zero <= 1'b0;
                    state <= S_CR_IV;
                end
                S_WB_GATE: begin                    // calibration builds only (CT_WB == 0):
                    axim_cmd_bucket <= req_b;       // write back after encryption ends
                    axim_cmd_write <= 1;
                    wb_pending <= 1'b0; wb_active <= 1'b1;
                    state <= S_DDR_WRITE;
                end
                S_DDR_WRITE: begin                  // write-back issued at CT_WB (streaming)
                    if (wb_done_seen || axim_write_done) state <= S_DONE_GATE;
                end
                S_DONE_GATE: begin
                    if (CT_DONE == 0 || ct_cnt >= CT_DONE) begin
                        if (ct_cnt > ct_max_done) ct_max_done <= ct_cnt;
                        if (CT_DONE != 0 && ct_cnt > CT_DONE) err_ct_overrun_r <= 1'b1;
                        res_beat <= 0; res_out_beat <= 0; res_pipe <= 2'b00;
                        state <= S_RES_STREAM;
                    end
                end
                S_RES_STREAM: begin
                    res_pipe <= {res_pipe[0], (res_beat < BEATS)};
                    if (res_beat < BEATS) begin
                        res_rd_addr <= res_beat[6:0]; res_beat <= res_beat + 1'b1;
                    end
                    if (res_pipe[1]) begin
                        if (req_op == 1'b0) begin
                            client_rdata       <= res_zero ? {AXI_DW{1'b0}} : res_rd_data;
                            client_rdata_beat  <= res_out_beat[BEAT_W-1:0];
                            client_rdata_valid <= 1;
                        end
                        res_out_beat <= res_out_beat + 1'b1;
                    end
                    if (res_out_beat == BEATS) begin
                        client_done  <= !req_dummy;   // a dummy completes no request
                        client_stall <= 0;
                        acc_commit   <= !req_dummy;
                        state <= S_IDLE;
                    end
                end
                S_FMT_START: begin
                    req_b <= fmt_b[BUCKET_W-1:0];
                    cr_mode <= CR_FMT; cr_pos <= 0; cr_zero <= 1'b1;
                    state <= S_CR_IV;
                end
                S_FMT_WRITE: begin
                    axim_cmd_bucket <= fmt_b[BUCKET_W-1:0]; axim_cmd_write <= 1;
                    state <= S_FMT_WAIT;
                end
                S_FMT_WAIT: begin
                    if (axim_write_done) begin
                        if (fmt_b == B - 1) begin
                            shuf_i <= 0; shuf_steps <= 5'd16; lay_p <= 0;
                            shuf_lfsr <= (aes_iv_seed[15:0] == 16'd0) ? 16'hACE1 : aes_iv_seed[15:0];
                            lay_i <= 0; state <= S_SHUFFLE;
                        end
                        else begin fmt_b <= fmt_b + 1'b1; state <= S_FMT_START; end
                    end
                end
                S_SHUFFLE: begin
                    if (shuf_steps != 0) begin                  // decorrelate successive draws
                        shuf_lfsr <= shuf_lfsr_next; shuf_steps <= shuf_steps - 1'b1;
                    end else begin
                        // inside-out Fisher-Yates: for i = 0..N-1, j uniform in 0..i,
                        // perm[i] = perm[j], perm[j] = i (no initialization needed;
                        // when j == i the second write wins and perm[i] = i)
                        perm[shuf_i[SLOT_W-PART_W-1:0]] <= perm[shuf_j[SLOT_W-PART_W-1:0]];
                        perm[shuf_j[SLOT_W-PART_W-1:0]] <= shuf_i[SLOT_W-PART_W-1:0];
                        shuf_steps <= 5'd16;
                        if (shuf_i == N_PART - 1) begin lay_i <= 0; state <= S_LAYOUT; end
                        else shuf_i <= shuf_i + 1'b1;
                    end
                end
                S_LAYOUT: begin
                    // slot perm[k] -> bucket k/C, position k mod C; every slot valid,
                    // its data the formatted (encrypted) zeros already in DDR
                    begin : place
                        reg [C*SLOT_W-1:0] lst;
                        lst = lay_list;
                        lst[(lay_i % C)*SLOT_W +: SLOT_W] = lay_slot;
                        lay_list <= lst;
                        pm_wr_addr   <= {{(SLOT_AW-SLOT_W-12){1'b0}}, lay_slot, 12'd0};
                        pm_wr_bucket <= lay_bbase | lay_bkt; pm_wr_status <= `ST_VALID; pm_wr_en <= 1;
                        if (lay_i % C == C - 1) begin
                            bm_wr_bucket    <= lay_bbase | lay_bkt;
                            bm_wr_slot_list <= {{((Z-C)*SLOT_W){1'b0}}, lst};
                            bm_wr_fill      <= C; bm_wr_en <= 1;
                        end
                    end
                    if (lay_i == N_PART - 1) begin
                        if (lay_p == NP - 1) begin fmt_done_r <= 1'b1; state <= S_IDLE; end
                        else begin lay_p <= lay_p + 1'b1; shuf_i <= 0; shuf_steps <= 5'd16; state <= S_SHUFFLE; end
                    end else
                        lay_i <= lay_i + 1'b1;
                end
                S_HALT: begin
                    client_stall <= 1;
                end
                default: state <= S_HALT;
            endcase
        end
    end
    // =========================================================================
    // Performance counters (debug builds only; secure_oram_top zeroes them)
    // =========================================================================
    // where the block was found: bucket, stash, or never written (in neither)
    localparam [2:0] CAT_RB = 3'd0, CAT_RS = 3'd1, CAT_WB = 3'd2, CAT_WS = 3'd3,
                     CAT_RN = 3'd4, CAT_WN = 3'd5;
    // never-written categories: internal counters (read by the testbench), no ports
    reg [31:0] perf_rn_total, perf_rn_ops, perf_rn_ddr_rd, perf_rn_decrypt, perf_rn_encrypt,
               perf_rn_compact, perf_rn_evict, perf_rn_ddr_wr, perf_rn_scan, perf_rn_stash;
    reg [31:0] perf_wn_total, perf_wn_ops, perf_wn_ddr_rd, perf_wn_decrypt, perf_wn_encrypt,
               perf_wn_compact, perf_wn_evict, perf_wn_ddr_wr, perf_wn_scan, perf_wn_stash;
    reg [2:0] perf_cat;
    wire acc_busy = fmt_done_r && state != S_IDLE && state != S_HALT;
    wire in_cr    = (state == S_CR_IV || state == S_CR_IVW || state == S_CR_START ||
                     state == S_CR_FEED || state == S_CR_RECV || state == S_CR_TAG);
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            perf_cat <= CAT_RB;
            acc_ddr_rd <= 0; acc_decrypt <= 0; acc_encrypt <= 0; acc_compact <= 0;
            acc_evict <= 0; acc_ddr_wr <= 0; acc_scan <= 0; acc_stash <= 0; acc_total <= 0;
        end else begin
            if (state == S_OP) perf_cat <= found_in_bucket ? (req_op ? CAT_WB : CAT_RB) :
                                    found_in_stash  ? (req_op ? CAT_WS : CAT_RS) :
                                                      (req_op ? CAT_WN : CAT_RN);
            if (state == S_IDLE) begin
                acc_ddr_rd <= 0; acc_decrypt <= 0; acc_encrypt <= 0; acc_compact <= 0;
                acc_evict <= 0; acc_ddr_wr <= 0; acc_scan <= 0; acc_stash <= 0; acc_total <= 0;
            end else if (acc_busy) begin
                acc_total <= acc_total + 1;
                if (state == S_POS_LOOKUP || state == S_RD_GATE || state == S_DDR_READ) acc_ddr_rd <= acc_ddr_rd + 1;
                if (in_cr && cr_mode == CR_DA) acc_decrypt <= acc_decrypt + 1;
                if ((in_cr && cr_mode == CR_EA) || state == S_EA_START) acc_encrypt <= acc_encrypt + 1;
                if (state == S_SCAN || state == S_OP) acc_scan <= acc_scan + 1;
                if ((state == S_CP && (cp_ret == S_COMPACT || cp_ret == S_PM_UPD)) || state == S_PM_UPD) acc_stash <= acc_stash + 1;
                if (state == S_COMPACT || state == S_COMPACT2 || (state == S_CP && cp_ret == S_COMPACT2)) acc_compact <= acc_compact + 1;
                if (state == S_EVICT || state == S_EVICT_CHK || state == S_EVICT_DONE || state == S_EVICT_WAIT ||
                    (state == S_CP && cp_ret == S_EVICT_DONE)) acc_evict <= acc_evict + 1;
                if (state == S_WB_GATE || state == S_DDR_WRITE || state == S_DONE_GATE || state == S_RES_STREAM)
                    acc_ddr_wr <= acc_ddr_wr + 1;
            end
        end
    end
    `define PERF_COMMIT(cat) \
        perf_``cat``_ddr_rd  <= perf_``cat``_ddr_rd  + acc_ddr_rd;  \
        perf_``cat``_decrypt <= perf_``cat``_decrypt + acc_decrypt; \
        perf_``cat``_encrypt <= perf_``cat``_encrypt + acc_encrypt; \
        perf_``cat``_compact <= perf_``cat``_compact + acc_compact; \
        perf_``cat``_evict   <= perf_``cat``_evict   + acc_evict;   \
        perf_``cat``_ddr_wr  <= perf_``cat``_ddr_wr  + acc_ddr_wr;  \
        perf_``cat``_scan    <= perf_``cat``_scan    + acc_scan;    \
        perf_``cat``_stash   <= perf_``cat``_stash   + acc_stash;   \
        perf_``cat``_total   <= perf_``cat``_total   + acc_total;   \
        perf_``cat``_ops     <= perf_``cat``_ops     + 1;
    `define PERF_CLEAR(cat) \
        perf_``cat``_ddr_rd <= 0; perf_``cat``_decrypt <= 0; perf_``cat``_encrypt <= 0; \
        perf_``cat``_compact <= 0; perf_``cat``_evict <= 0; perf_``cat``_ddr_wr <= 0; \
        perf_``cat``_scan <= 0; perf_``cat``_stash <= 0; perf_``cat``_total <= 0; perf_``cat``_ops <= 0;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            `PERF_CLEAR(rb) `PERF_CLEAR(rs) `PERF_CLEAR(wb) `PERF_CLEAR(ws) `PERF_CLEAR(rn) `PERF_CLEAR(wn)
        end else if (perf_reset) begin
            `PERF_CLEAR(rb) `PERF_CLEAR(rs) `PERF_CLEAR(wb) `PERF_CLEAR(ws) `PERF_CLEAR(rn) `PERF_CLEAR(wn)
        end else if (acc_commit) begin
            case (perf_cat)
                CAT_RB: begin `PERF_COMMIT(rb) end
                CAT_RS: begin `PERF_COMMIT(rs) end
                CAT_WB: begin `PERF_COMMIT(wb) end
                    CAT_RN: begin `PERF_COMMIT(rn) end
                    CAT_WN: begin `PERF_COMMIT(wn) end
                default: begin `PERF_COMMIT(ws) end
            endcase
        end
    end
    `undef PERF_COMMIT
    `undef PERF_CLEAR

`ifndef SYNTHESIS
    // Safety monitor (simulation only): the write-back must never read a beat of
    // a position that is not yet re-encrypted -- that would put plaintext on DDR.
    reg [9:0] mon_req_q; reg [3:0] mon_epd_q; reg mon_act_q;
    always @(posedge clk) begin
        mon_req_q <= axim_wdata_beat_req; mon_epd_q <= enc_pos_done; mon_act_q <= wb_active;
        if (mon_act_q && wb_active && axim_wdata_beat_req == mon_req_q + 10'd1 &&
            {1'b0, mon_req_q[BEAT_AW +: POS_W]} >= mon_epd_q && mon_epd_q < Z)
            $display("[%0t] SAFETY VIOLATION: write-back read beat %0d (position %0d) before it was encrypted (done=%0d)",
                     $time, mon_req_q, mon_req_q[BEAT_AW +: POS_W], mon_epd_q);
    end
`endif
`ifndef SYNTHESIS
    initial if (N != B * C || C > Z)
        $display("ERROR: layout needs N == B*C and C <= Z (N=%0d B=%0d C=%0d Z=%0d)", N, B, C, Z);
`endif
endmodule