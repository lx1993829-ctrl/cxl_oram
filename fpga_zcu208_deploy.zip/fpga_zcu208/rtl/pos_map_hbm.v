`include "oram_params.vh"
// pos_map_hbm.v -- the position map in HBM (on-package, trusted memory), behind the same
// interface as the on-chip pos_map.
//
// Entry k (slot k) is 32 bits at base + 4*k: bits [BUCKET_W-1:0] bucket, [BUCKET_W+1:BUCKET_W]
// status. A read fetches the 32-byte line holding the entry (one beat) and returns it with rd_valid
// after the memory's latency. A write is one beat whose strobe covers only the entry's 4 bytes, so
// no read-modify-write is needed. Writes are posted through a FIFO: the controller never waits for
// them. wr_quiet reports that every write has been acknowledged; the controller completes an access
// (and finishes booting) only when it is, so the next access's read always sees them. As a safety
// net a read is also held until the map is quiet (AXI does not order a read after an unacknowledged
// write). The boot layout writes every entry before the first access, so HBM's initial contents
// never matter.
module pos_map_hbm #(
    parameter N          = `ORAM_N,
    parameter BUCKET_W   = `BUCKET_ID_W,
    parameter ADDR_W     = `SLOT_ADDR_W,
    parameter AXI_DW     = 256,
    parameter FIFO_D     = 16
) (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire [63:0]          base,            // byte address of entry 0 (32-byte aligned)
    input  wire [ADDR_W-1:0]    rd_slot_addr,
    input  wire                 rd_en,
    output reg  [BUCKET_W-1:0]  rd_bucket,
    output reg  [1:0]           rd_status,
    output reg                  rd_valid,
    input  wire [ADDR_W-1:0]    wr_slot_addr,
    input  wire [BUCKET_W-1:0]  wr_bucket,
    input  wire [1:0]           wr_status,
    input  wire                 wr_en,
    output wire                 wr_ready,        // the write FIFO has room
    output wire                 wr_quiet,        // nothing queued, in flight or unacknowledged
    output reg                  err,             // sticky: a write arrived with the FIFO full
    // AXI4 master: single-beat reads, single-beat strobed writes
    output wire [63:0]          m_araddr,
    output wire [7:0]           m_arlen,
    output wire [2:0]           m_arsize,
    output wire [1:0]           m_arburst,
    output reg                  m_arvalid,
    input  wire                 m_arready,
    input  wire [AXI_DW-1:0]    m_rdata,
    input  wire                 m_rlast,
    input  wire                 m_rvalid,
    output wire                 m_rready,
    output wire [63:0]          m_awaddr,
    output wire [7:0]           m_awlen,
    output wire [2:0]           m_awsize,
    output wire [1:0]           m_awburst,
    output reg                  m_awvalid,
    input  wire                 m_awready,
    output wire [AXI_DW-1:0]    m_wdata,
    output wire [AXI_DW/8-1:0]  m_wstrb,
    output wire                 m_wlast,
    output reg                  m_wvalid,
    input  wire                 m_wready,
    input  wire                 m_bvalid,
    output wire                 m_bready
);
    localparam IDX_W = (N > 1) ? $clog2(N) : 1;
    localparam FA_W  = $clog2(FIFO_D);
    localparam LANES = AXI_DW / 32;                    // entries per beat (8)
    localparam LN_W  = $clog2(LANES);

    // ---------------- reads ----------------
    reg  [IDX_W-1:0] r_idx;
    reg              r_pend, r_wait;                   // requested / address issued, awaiting data
    wire [IDX_W-1:0] rd_idx_w = rd_slot_addr[IDX_W+11:12];
    assign m_araddr  = base + {{(64-IDX_W-2){1'b0}}, r_idx[IDX_W-1:LN_W], {(LN_W+2){1'b0}}};
    assign m_arlen   = 8'd0;
    assign m_arsize  = 3'b101;                          // 32 bytes
    assign m_arburst = 2'b01;
    assign m_rready  = 1'b1;
    wire [31:0] r_word = m_rdata[32*r_idx[LN_W-1:0] +: 32];

    // ---------------- writes: FIFO of {index, entry} ----------------
    reg  [IDX_W-1:0] f_idx  [0:FIFO_D-1];
    reg  [31:0]      f_word [0:FIFO_D-1];
    reg  [FA_W:0]    f_n;
    reg  [FA_W-1:0]  f_rp, f_wp;
    reg  [4:0]       outst;                             // writes issued, awaiting their response
    reg              w_busy, aw_done, w_done;           // the head write is on the bus
    wire             push = wr_en;
    wire             pop  = w_busy && (aw_done || (m_awvalid && m_awready)) && (w_done || (m_wvalid && m_wready));
    assign wr_ready = (f_n < FIFO_D - 1);               // one entry of slack for a write already in flight
    assign wr_quiet = (f_n == 0) && !w_busy && (outst == 0);
    wire [IDX_W-1:0] h_idx = f_idx[f_rp];
    assign m_awaddr  = base + {{(64-IDX_W-2){1'b0}}, h_idx[IDX_W-1:LN_W], {(LN_W+2){1'b0}}};
    assign m_awlen   = 8'd0;
    assign m_awsize  = 3'b101;
    assign m_awburst = 2'b01;
    assign m_wdata   = {LANES{f_word[f_rp]}};
    assign m_wstrb   = {{(AXI_DW/8-4){1'b0}}, 4'hF} << (4 * h_idx[LN_W-1:0]);
    assign m_wlast   = 1'b1;
    assign m_bready  = 1'b1;

    always @(posedge clk) begin
        if (push) begin
            f_idx[f_wp]  <= wr_slot_addr[IDX_W+11:12];
            f_word[f_wp] <= {{(32-BUCKET_W-2){1'b0}}, wr_status, wr_bucket};
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            r_idx <= {IDX_W{1'b0}}; r_pend <= 1'b0; r_wait <= 1'b0; m_arvalid <= 1'b0;
            rd_valid <= 1'b0; rd_bucket <= {BUCKET_W{1'b0}}; rd_status <= 2'b00;
            f_n <= 0; f_rp <= 0; f_wp <= 0; outst <= 0; w_busy <= 1'b0; aw_done <= 1'b0; w_done <= 1'b0;
            m_awvalid <= 1'b0; m_wvalid <= 1'b0; err <= 1'b0;
        end else begin
            // reads
            rd_valid <= 1'b0;
            if (rd_en) begin r_idx <= rd_idx_w; r_pend <= 1'b1; end
            if (r_pend && !r_wait && !m_arvalid && wr_quiet) m_arvalid <= 1'b1;   // never ahead of a write
            if (m_arvalid && m_arready) begin m_arvalid <= 1'b0; r_wait <= 1'b1; end
            if (r_wait && m_rvalid) begin
                rd_bucket <= r_word[BUCKET_W-1:0];
                rd_status <= r_word[BUCKET_W+1:BUCKET_W];
                rd_valid  <= 1'b1;
                r_pend <= 1'b0; r_wait <= 1'b0;
            end
            // write FIFO
            if (push) f_wp <= f_wp + 1'b1;
            if (push && f_n == FIFO_D) err <= 1'b1;
            f_n <= f_n + (push && f_n != FIFO_D) - pop;
            if (!w_busy && f_n != 0) begin
                w_busy <= 1'b1; aw_done <= 1'b0; w_done <= 1'b0; m_awvalid <= 1'b1; m_wvalid <= 1'b1;
            end else if (w_busy) begin
                if (m_awvalid && m_awready) begin m_awvalid <= 1'b0; aw_done <= 1'b1; end
                if (m_wvalid && m_wready)   begin m_wvalid  <= 1'b0; w_done  <= 1'b1; end
                if (pop) begin w_busy <= 1'b0; f_rp <= f_rp + 1'b1; end
            end
            outst <= outst + (m_awvalid && m_awready) - m_bvalid;
        end
    end
endmodule
