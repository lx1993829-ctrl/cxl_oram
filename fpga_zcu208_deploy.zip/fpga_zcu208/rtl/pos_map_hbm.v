`include "oram_params.vh"
// pos_map_hbm.v -- the position map in HBM (on-package, trusted memory), behind the same
// interface as the on-chip pos_map.
//
// Entry k (slot k) is 32 bits at base + 4*k: bits [BUCKET_W-1:0] bucket, [BUCKET_W+1:BUCKET_W]
// status. A read fetches the 32-byte line holding the entry (one beat) and returns it with rd_valid
// after the memory's latency. A write is one beat whose strobe covers only the entry's 4 bytes, so
// no read-modify-write is needed. Writes are posted through a FIFO: the controller never waits for
// them. wr_quiet reports that every write has been acknowledged; the controller completes an access
// (and finishes booting) only when it is, so the next access's read always sees them. As a safety
// net a read is also held until the map is quiet (AXI does not order a read after an unacknowledged
// write). The boot layout writes every entry before the first access, so HBM's initial contents
// never matter.
module pos_map_hbm #(
    parameter N          = `ORAM_N,
    parameter BUCKET_W   = `BUCKET_ID_W,
    parameter ADDR_W     = `SLOT_ADDR_W,
    parameter AXI_DW     = 256,
    parameter FIFO_D     = 16
) (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire [63:0]          base,            // byte address of entry 0 (32-byte aligned)
    input  wire [ADDR_W-1:0]    rd_slot_addr,
    input  wire                 rd_en,
    output reg  [BUCKET_W-1:0]  rd_bucket,
    output reg  [1:0]           rd_status,
    output reg  [$clog2(N)-1:0] rd_pidx,         // a stashed block's pool index
    output reg                  rd_valid,
    input  wire [ADDR_W-1:0]    wr_slot_addr,
    input  wire [BUCKET_W-1:0]  wr_bucket,
    input  wire [1:0]           wr_status,
    input  wire [$clog2(N)-1:0] wr_pidx,
    input  wire                 wr_en,
    output wire                 wr_ready,        // the write FIFO has room
    output wire                 wr_quiet,        // nothing queued, in flight or unacknowledged
    output reg                  err,             // sticky: a write arrived with the FIFO full
    // AXI4 master: single-beat reads, single-beat strobed writes
    output wire [63:0]          m_araddr,
    output wire [7:0]           m_arlen,
    output wire [2:0]           m_arsize,
    output wire [1:0]           m_arburst,
    output reg                  m_arvalid,
    input  wire                 m_arready,
    input  wire [AXI_DW-1:0]    m_rdata,
    input  wire                 m_rlast,
    input  wire                 m_rvalid,
    output wire                 m_rready,
    output wire [63:0]          m_awaddr,
    output wire [7:0]           m_awlen,
    output wire [2:0]           m_awsize,
    output wire [1:0]           m_awburst,
    output reg                  m_awvalid,
    input  wire                 m_awready,
    output wire [AXI_DW-1:0]    m_wdata,
    output wire [AXI_DW/8-1:0]  m_wstrb,
    output wire                 m_wlast,
    output reg                  m_wvalid,
    input  wire                 m_wready,
    input  wire                 m_bvalid,
    output wire                 m_bready
);
    localparam IDX_W = (N > 1) ? $clog2(N) : 1;
    localparam FA_W  = $clog2(FIFO_D);
    localparam PW    = $clog2(N);
    // 48-bit entries {pool index [24 +: PW], status [BUCKET_W +: 2], bucket [0 +: BUCKET_W]}, 5 per 32-byte beat:
    // entry k in beat k / 5, lane k mod 5 (6 bytes each, 2 bytes unused). The division by 5 is an exact
    // multiply-and-shift (M = ceil(2^22 / 5), exact for every index < 2^22), pipelined over two registered stages.
    localparam LANES = 5;
    localparam BTW   = (IDX_W > 2) ? IDX_W - 2 : 1;      // beat index width (index / 5 < 2^(IDX_W-2))
    localparam [19:0] DIV5_M = 20'd838861;
    function [BTW-1:0] div5; input [41:0] prod; begin div5 = prod[22 +: BTW]; end endfunction

    // ---------------- reads ----------------
    reg  [IDX_W-1:0] r_idx;
    reg              r_pend, r_wait;                   // requested / address issued, awaiting data
    reg  [1:0]       r_cnt;                            // cycles until r_beat / r_lane are valid
    reg  [41:0]      r_prod;
    reg  [BTW-1:0]   r_beat; reg [2:0] r_lane;
    wire [IDX_W-1:0] rd_idx_w = rd_slot_addr[IDX_W+11:12];
    assign m_araddr  = base + {{(64-BTW-5){1'b0}}, r_beat, 5'd0};
    assign m_arlen   = 8'd0;
    assign m_arsize  = 3'b101;                          // 32 bytes
    assign m_arburst = 2'b01;
    assign m_rready  = 1'b1;
    wire [47:0] r_word = m_rdata[48*r_lane +: 48];

    // ---------------- writes: FIFO of {index, entry} ----------------
    reg  [BTW-1:0]   f_beat [0:FIFO_D-1];
    reg  [2:0]       f_lane [0:FIFO_D-1];
    reg  [47:0]      f_word [0:FIFO_D-1];
    // the write pipeline ahead of the FIFO: A = captured, B = product computed
    reg              pa_v, pb_v;
    reg  [IDX_W-1:0] pa_idx, pb_idx; reg [47:0] pa_word, pb_word; reg [41:0] pb_prod;
    wire [BTW-1:0]   pc_beat = div5(pb_prod);
    wire [2:0]       pc_lane = pb_idx - {pc_beat, 2'b00} - pc_beat;
    reg  [FA_W:0]    f_n;
    reg  [FA_W-1:0]  f_rp, f_wp;
    reg  [4:0]       outst;                             // writes issued, awaiting their response
    reg              w_busy, aw_done, w_done;           // the head write is on the bus
    wire             push = pb_v;                       // into the FIFO, two cycles after wr_en
    wire             pop  = w_busy && (aw_done || (m_awvalid && m_awready)) && (w_done || (m_wvalid && m_wready));
    assign wr_ready = (f_n + pa_v + pb_v < FIFO_D - 1); // slack for writes already in the pipeline
    assign wr_quiet = (f_n == 0) && !pa_v && !pb_v && !w_busy && (outst == 0);
    assign m_awaddr  = base + {{(64-BTW-5){1'b0}}, f_beat[f_rp], 5'd0};
    assign m_awlen   = 8'd0;
    assign m_awsize  = 3'b101;
    assign m_awburst = 2'b01;
    assign m_wdata   = {16'd0, {LANES{f_word[f_rp]}}};
    assign m_wstrb   = {{(AXI_DW/8-6){1'b0}}, 6'h3F} << (6 * f_lane[f_rp]);
    assign m_wlast   = 1'b1;
    assign m_bready  = 1'b1;

    always @(posedge clk) begin
        pa_idx  <= wr_slot_addr[IDX_W+11:12];
        pa_word <= {{(24-PW){1'b0}}, wr_pidx, {(24-BUCKET_W-2){1'b0}}, wr_status, wr_bucket};
        pb_idx  <= pa_idx; pb_word <= pa_word; pb_prod <= {{(42-IDX_W){1'b0}}, pa_idx} * DIV5_M;
        r_prod  <= {{(42-IDX_W){1'b0}}, r_idx} * DIV5_M;
        r_beat  <= div5(r_prod);
        r_lane  <= r_idx - {div5(r_prod), 2'b00} - div5(r_prod);
        if (push) begin
            f_beat[f_wp] <= pc_beat; f_lane[f_wp] <= pc_lane; f_word[f_wp] <= pb_word;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            r_idx <= {IDX_W{1'b0}}; r_pend <= 1'b0; r_wait <= 1'b0; m_arvalid <= 1'b0; r_cnt <= 2'd0; pa_v <= 1'b0; pb_v <= 1'b0;
            rd_valid <= 1'b0; rd_bucket <= {BUCKET_W{1'b0}}; rd_status <= 2'b00; rd_pidx <= {PW{1'b0}};
            f_n <= 0; f_rp <= 0; f_wp <= 0; outst <= 0; w_busy <= 1'b0; aw_done <= 1'b0; w_done <= 1'b0;
            m_awvalid <= 1'b0; m_wvalid <= 1'b0; err <= 1'b0;
        end else begin
            // reads
            rd_valid <= 1'b0;
            if (r_cnt != 0) r_cnt <= r_cnt - 1'b1;
            if (rd_en) begin r_idx <= rd_idx_w; r_pend <= 1'b1; r_cnt <= 2'd2; end
            if (r_pend && !r_wait && !m_arvalid && r_cnt == 0 && !rd_en && wr_quiet) m_arvalid <= 1'b1;   // never ahead of a write
            pa_v <= wr_en; pb_v <= pa_v;
            if (m_arvalid && m_arready) begin m_arvalid <= 1'b0; r_wait <= 1'b1; end
            if (r_wait && m_rvalid) begin
                rd_bucket <= r_word[BUCKET_W-1:0];
                rd_status <= r_word[BUCKET_W+1:BUCKET_W];
                rd_pidx   <= r_word[24 +: PW];
                rd_valid  <= 1'b1;
                r_pend <= 1'b0; r_wait <= 1'b0;
            end
            // write FIFO
            if (push) f_wp <= f_wp + 1'b1;
            if (push && f_n == FIFO_D) err <= 1'b1;
            f_n <= f_n + (push && f_n != FIFO_D) - pop;
            if (!w_busy && f_n != 0) begin
                w_busy <= 1'b1; aw_done <= 1'b0; w_done <= 1'b0; m_awvalid <= 1'b1; m_wvalid <= 1'b1;
            end else if (w_busy) begin
                if (m_awvalid && m_awready) begin m_awvalid <= 1'b0; aw_done <= 1'b1; end
                if (m_wvalid && m_wready)   begin m_wvalid  <= 1'b0; w_done  <= 1'b1; end
                if (pop) begin w_busy <= 1'b0; f_rp <= f_rp + 1'b1; end
            end
            outst <= outst + (m_awvalid && m_awready) - m_bvalid;
        end
    end
endmodule
