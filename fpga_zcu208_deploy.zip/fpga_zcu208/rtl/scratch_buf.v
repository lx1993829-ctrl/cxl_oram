// =============================================================================
// scratch_buf.v - Scratch Buffer (One Bucket = Z × 4K)
// =============================================================================
// Holds one full bucket during processing.
// Written via AXI stream as DDR burst arrives.
// Read by FSM to return data to client or write into stash.
// Written by FSM during stash eviction.
//
// Memory size: Z * 4096 bytes = Z * 128 AXI beats (256-bit bus)
// Addressed by: {slot_pos[POS_W-1:0], beat[BEAT_CNT_W-1:0]}
//
// Two port pairs:
//   Port A: stream_in (write) + stream_out (read)  - tied to AXI burst
//   Port B: FSM write + FSM read                   - FSM-driven address
//
// For Vivado BRAM inference: both write ports are in a single always block.
// Write priority: stream_in > FSM write (they never conflict in practice
// since stream_in is active during DDR_READ and FSM write during EVICT).
// =============================================================================
`include "oram_params.vh"

module scratch_buf #(
    parameter Z            = `ORAM_Z,
    parameter POS_W        = `POS_IN_BKT_W,
    parameter AXI_DATA_W   = `AXI_DATA_W,
    parameter BEATS        = `BEATS_PER_BLOCK,
    parameter BEAT_W       = `BEAT_CNT_W,
    parameter TOTAL_BEATS  = Z * BEATS         // 8 * 128 = 1024
)(
    input  wire                     clk,
    input  wire                     rst_n,

    // --- Stream-in port (from AXI read data channel, DDR -> scratch) ---
    input  wire [AXI_DATA_W-1:0]    stream_in_data,
    input  wire                     stream_in_valid,
    input  wire [9:0]               stream_in_beat_addr,  // 0..TOTAL_BEATS-1
    output wire                     stream_in_ready,      // always ready (BRAM)

    // --- FSM read port (FSM reads a specific slot) ---
    input  wire [9:0]               fsm_rd_addr,          // {slot_pos, beat}
    input  wire                     fsm_rd_en,
    output wire [AXI_DATA_W-1:0]    fsm_rd_data,
    output reg                      fsm_rd_valid,

    // --- FSM write port (FSM writes evicted stash slot into scratch) ---
    input  wire [9:0]               fsm_wr_addr,          // {slot_pos, beat}
    input  wire [AXI_DATA_W-1:0]    fsm_wr_data,
    input  wire                     fsm_wr_en,
    // Eviction-copy write port: background copies from the stash into the
    // bucket, concurrent with the crypto engine (different positions).
    input  wire [9:0]               ev_wr_addr,
    input  wire [AXI_DATA_W-1:0]    ev_wr_data,
    input  wire                     ev_wr_en,

    // --- Stream-out port (to AXI write data channel, scratch -> DDR) ---
    input  wire [9:0]               stream_out_beat_addr, // driven by AXI master
    input  wire                     stream_out_rd_en,
    output wire [AXI_DATA_W-1:0]    stream_out_data,
    output reg                      stream_out_valid,
    output reg                      bank_conflict   // sticky: two accesses hit one bank in one cycle
);

    // -------------------------------------------------------------------------
    // Simple dual-port BRAM with muxed write port
    //
    // stream_in and fsm_wr NEVER fire simultaneously (different ORAM phases):
    //   stream_in_valid: active during S_DDR_READ
    //   fsm_wr_en:       active during eviction/re-encrypt
    //
    // Single write port avoids Vivado TDP inference issues.
    // Two independent read ports (stream_out + fsm_rd).
    // -------------------------------------------------------------------------
    // Crypto streaming: one memory per bucket position, each with its own write
    // and read port, so the DDR read stream, the crypto engine and the write-back
    // stream can work on DIFFERENT positions in the same cycle. (The original
    // single memory had one write port, and a simultaneous FSM write was dropped.)
    localparam BEAT_AW = $clog2(BEATS);
    localparam BAI     = (BEAT_AW > 0) ? BEAT_AW : 1;   // in-bank address width
    wire [POS_W-1:0] in_bank = stream_in_beat_addr[BEAT_AW +: POS_W];
    wire [POS_W-1:0] fw_bank = fsm_wr_addr[BEAT_AW +: POS_W];
    wire [POS_W-1:0] fr_bank = fsm_rd_addr[BEAT_AW +: POS_W];
    wire [POS_W-1:0] so_bank = stream_out_beat_addr[BEAT_AW +: POS_W];
    wire [POS_W-1:0] ev_bank = ev_wr_addr[BEAT_AW +: POS_W];
    reg  [POS_W-1:0] fr_bank_q, so_bank_q;
    wire [AXI_DATA_W-1:0] bank_q [0:Z-1];
    wire [Z-1:0] bank_clash;
    genvar g;
    generate
        for (g = 0; g < Z; g = g + 1) begin : g_bank
            (* ram_style = "block" *)
            reg [AXI_DATA_W-1:0] mem [0:BEATS-1];
            reg [AXI_DATA_W-1:0] q;
            wire in_hit = stream_in_valid  && (in_bank == g);
            wire fw_hit = fsm_wr_en        && (fw_bank == g);
            wire so_hit = stream_out_rd_en && (so_bank == g);
            wire fr_hit = fsm_rd_en        && (fr_bank == g);
            wire ev_hit = ev_wr_en         && (ev_bank == g);
            // One write port and one registered read port (Vivado's simple dual-port block-RAM
            // template). Writing mem from three branches with different addresses, and reading it
            // from two, made synthesis see three write ports and two read ports, which no block RAM
            // has: each bank became registers plus wide multiplexers. Same priorities as before;
            // a read in the cycle of a write to the same beat still returns the old data.
            wire                  wr_en   = in_hit | fw_hit | ev_hit;
            // in-bank address = beat within the block (masked, so a 1-beat block uses address 0)
            wire [BAI-1:0]        wr_addr = (in_hit ? stream_in_beat_addr[BAI-1:0] :
                                             fw_hit ? fsm_wr_addr[BAI-1:0] : ev_wr_addr[BAI-1:0]) & (BEATS - 1);
            wire [AXI_DATA_W-1:0] wr_data = in_hit ? stream_in_data : fw_hit ? fsm_wr_data : ev_wr_data;
            wire                  rd_en   = so_hit | fr_hit;
            wire [BAI-1:0]        rd_addr = (so_hit ? stream_out_beat_addr[BAI-1:0] : fsm_rd_addr[BAI-1:0]) & (BEATS - 1);
            always @(posedge clk) begin
                if (wr_en) mem[wr_addr] <= wr_data;
                if (rd_en) q <= mem[rd_addr];
            end
            assign bank_q[g]     = q;
            assign bank_clash[g] = (in_hit && fw_hit) || (in_hit && ev_hit) || (fw_hit && ev_hit) || (so_hit && fr_hit);
        end
    endgenerate
    always @(posedge clk) begin
        if (fsm_rd_en)        fr_bank_q <= fr_bank;
        if (stream_out_rd_en) so_bank_q <= so_bank;
    end
    assign fsm_rd_data     = bank_q[fr_bank_q];
    assign stream_out_data = bank_q[so_bank_q];
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) bank_conflict <= 1'b0;
        else if (|bank_clash) begin
            bank_conflict <= 1'b1;
`ifndef SYNTHESIS
            $display("[%0t] SCRATCH: bank conflict 0x%02h", $time, bank_clash);
`endif
        end
    end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            stream_out_valid <= 1'b0;
        else
            stream_out_valid <= stream_out_rd_en;
    end

    // Port B read (FSM)

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            fsm_rd_valid <= 1'b0;
        else
            fsm_rd_valid <= fsm_rd_en;
    end

    assign stream_in_ready = 1'b1; // BRAM always accepts

endmodule