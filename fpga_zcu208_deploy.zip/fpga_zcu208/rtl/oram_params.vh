// =============================================================================
// oram_params.vh - ORAM System Parameters (Board Test - Reduced Size)
// =============================================================================
// Proportionally reduced for ZCU208 on-chip memory constraints:
//   STASH_DEPTH = 64    (was 4096)
//   B = 64 buckets      (was 4095)
//   N = 512 slots       (was 16380)
//   Stash data_mem = 64 * 128 * 256b = 2 Mb (fits in ~7 URAMs)
//
// Slot/bucket ratios preserved: stash:buckets ? 1:1

`ifndef ORAM_PARAMS_VH
`define ORAM_PARAMS_VH
`include "oram_build_cfg.vh"      // build-time settings from vitis/build.sh (empty by default)

// Package revision. The self-test testbench prints it at start-up and refuses to
// run without it, so an old copy of this header in the include path (for
// example one imported into a Vivado project earlier) cannot go unnoticed.
`define ORAM_PKG_REV "2026-10-10 one client (no schedule, no dummy accesses), Z=6, lambda=4, block size selectable"

// Simulation builds turn on the debug ports automatically: the self-test steers
// remaps and reads its performance counters through them, and every simulator
// leaves SYNTHESIS undefined (Vivado defines it only in synthesis). Synthesis
// still needs ORAM_DEBUG_PORTS explicitly (self-test bitstream), and production
// builds (ORAM_SECURE_BUILD) never get the debug ports.
`ifndef SYNTHESIS
  `ifndef ORAM_SECURE_BUILD
    `ifndef ORAM_DEBUG_PORTS
      `define ORAM_DEBUG_PORTS
    `endif
  `endif
`endif

// --- ORAM tree geometry ---
// --- Client configuration ---
// One client with one ORAM: accesses start on demand, one at a time, each in a
// fixed-length window; there is no schedule and no dummy access. The client-count
// and partition-width parameters remain, fixed at 1 and 0, so the generic intake
// and partition-check logic collapses to a single client in synthesis.
`define ORAM_NUM_CLIENTS    1
`define ORAM_N              256   // slots
`define ORAM_B              64    // buckets = N / lambda
`define ORAM_PART_W         0     // one ORAM, no partitions
`define BUCKET_ID_W         6
`define SLOT_ID_W           8
`define ORAM_Z              6   // positions per bucket = lambda + slack = 4 + 2
`define ORAM_C              4   // lambda: real slots per bucket
`define ORAM_STASH_DEPTH    128   // entries per ORAM (per client in the two-client build)

// --- Bit widths ---
`define SLOT_ADDR_W         32        // full client address width
`define FILL_CNT_W          4         // ceil(log2(Z+1)) = 4, holds 0..8
`define POS_IN_BKT_W        3         // ceil(log2(Z)) = 3
`define STASH_PTR_W         7   // ceil(log2(STASH_DEPTH))

// --- AXI parameters ---
`define AXI_DATA_W          256       // 256-bit data bus (32 bytes per beat)
`define AXI_ADDR_W          32
`define AXI_STRB_W          32        // AXI_DATA_W / 8
`define AXI_ID_W            4
`define AXI_LEN_W           8         // AXI4 standard: 8-bit ARLEN/AWLEN

// --- Beat/block parameters ---
// Block (ORAM slot) size in 32-byte beats: 1, 2, 4 or 8 for 32-256-byte records (the value
// sizes of BOLT's experiments), 128 for 4 KB pages. Select with -DORAM_BLOCK_BEATS=N.
`ifndef ORAM_BLOCK_BEATS
`define ORAM_BLOCK_BEATS    128
`endif
`define BEATS_PER_BLOCK     `ORAM_BLOCK_BEATS
`define BEATS_PER_BKT       (`ORAM_Z * `BEATS_PER_BLOCK)                 // beats in one bucket
`define BEAT_CNT_W          $clog2(`ORAM_Z * `BEATS_PER_BLOCK + 1)       // holds 0..BEATS_PER_BKT

// --- DDR layout ---
`define DDR_BASE            32'h0000_0000
`define BUCKET_SHIFT        $clog2(`ORAM_Z * `BEATS_PER_BLOCK * 32)     // bucket spacing: smallest power of two holding Z blocks

// --- Slot status encoding ---
`define ST_DUMMY            2'b00
`define ST_VALID            2'b01
`define ST_IN_STASH         2'b10

// --- FSM states ---
`define S_IDLE              4'd0
`define S_POS_LOOKUP        4'd1
`define S_DDR_READ          4'd2
`define S_SCAN              4'd3
`define S_SCAN2             4'd4
`define S_EXTRACT           4'd5
`define S_STASH_SEARCH      4'd6
`define S_STASH_READ        4'd7
`define S_COMPACT           4'd8
`define S_EVICT             4'd9
`define S_DDR_WRITE         4'd10
`define S_RESPOND           4'd11


// Phase 2 constant-time budgets (cycles after an access is accepted): bucket
// read issue, write-back issue, result release. 0 = gate off (calibration).
`ifndef ORAM_CT_RD
`define ORAM_CT_RD   16      // calibrated on the testbench DDR model (arrival 2)
`endif
// Per block size (beats), from the regression's derived worst case on the testbench memory:
//   CT_WB   = worst encryption end + 300 - (Z-1)*BEATS  (the write-back reaches the last position
//             (Z-1)*BEATS cycles after it starts), rounded up
//   CT_DONE = CT_WB + longest write-back + 250, rounded up
// Sizes not listed fall back to the 4 KB budgets (safe, but padded to the 4 KB access time).
`define ORAM_CT_WB_B1      950    // 32 B:  worst encryption end 655,   write-back 20
`define ORAM_CT_DONE_B1    1220
`define ORAM_CT_WB_B2      980    // 64 B:  682, 34
`define ORAM_CT_DONE_B2    1270
`define ORAM_CT_WB_B4      1020   // 128 B: 736, 49
`define ORAM_CT_DONE_B4    1320
`define ORAM_CT_WB_B8      1110   // 256 B: 846, 89
`define ORAM_CT_DONE_B8    1450
`define ORAM_CT_WB_B128    3820   // 4 KB:  4,172 (derived, all paths), 1,082
`define ORAM_CT_DONE_B128  5160
`ifndef ORAM_CT_WB
`define ORAM_CT_WB   (`ORAM_BLOCK_BEATS == 1 ? `ORAM_CT_WB_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_CT_WB_B2 : \
                      `ORAM_BLOCK_BEATS == 4 ? `ORAM_CT_WB_B4 : `ORAM_BLOCK_BEATS == 8 ? `ORAM_CT_WB_B8 : `ORAM_CT_WB_B128)
`endif
`ifndef ORAM_CT_DONE
`define ORAM_CT_DONE (`ORAM_BLOCK_BEATS == 1 ? `ORAM_CT_DONE_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_CT_DONE_B2 : \
                      `ORAM_BLOCK_BEATS == 4 ? `ORAM_CT_DONE_B4 : `ORAM_BLOCK_BEATS == 8 ? `ORAM_CT_DONE_B8 : `ORAM_CT_DONE_B128)
`endif


// Phase 3 time-division arbiter: default slot length = padded access (completion
// gate) + result window + slack so a client that re-requests on completion (and
// must buffer a full write block) makes its next own slot.
`ifndef ORAM_TDM_SLOT
`define ORAM_TDM_SLOT (`ORAM_CT_DONE + 2*`BEATS_PER_BLOCK + 48)
`endif

`endif
