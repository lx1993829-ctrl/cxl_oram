// =============================================================================
// oram_params.vh - ORAM System Parameters (Board Test - Reduced Size)
// =============================================================================
// Proportionally reduced for ZCU208 on-chip memory constraints:
//   STASH_DEPTH = 64    (was 4096)
//   B = 64 buckets      (was 4095)
//   N = 512 slots       (was 16380)
//   Stash data_mem = 64 * 128 * 256b = 2 Mb (fits in ~7 URAMs)
//
// Slot/bucket ratios preserved: stash:buckets ? 1:1

`ifndef ORAM_PARAMS_VH
`define ORAM_PARAMS_VH
`include "oram_build_cfg.vh"      // build-time settings from vitis/build.sh (empty by default)

// Package revision. The self-test testbench prints it at start-up and refuses to
// run without it, so an old copy of this header in the include path (for
// example one imported into a Vivado project earlier) cannot go unnoticed.
`define ORAM_PKG_REV "2026-10-10 one client (no schedule, no dummy accesses), Z=6, lambda=4, block size selectable"

// Simulation builds turn on the debug ports automatically: the self-test steers
// remaps and reads its performance counters through them, and every simulator
// leaves SYNTHESIS undefined (Vivado defines it only in synthesis). Synthesis
// still needs ORAM_DEBUG_PORTS explicitly (self-test bitstream), and production
// builds (ORAM_SECURE_BUILD) never get the debug ports.
`ifndef SYNTHESIS
  `ifndef ORAM_SECURE_BUILD
    `ifndef ORAM_DEBUG_PORTS
      `define ORAM_DEBUG_PORTS
    `endif
  `endif
`endif

// --- ORAM tree geometry ---
// --- Client configuration ---
// One client with one ORAM: accesses start on demand, one at a time, each in a
// fixed-length window; there is no schedule and no dummy access. The client-count
// and partition-width parameters remain, fixed at 1 and 0, so the generic intake
// and partition-check logic collapses to a single client in synthesis.
`define ORAM_NUM_CLIENTS    1
// ORAM_N is the build's MAXIMUM number of blocks (slots); widths derive from it. The host chooses the
// actual number n <= ORAM_N at boot (kernel argument nblk; 0 = ORAM_N), so one bitstream serves every
// size up to the maximum. Select a larger maximum with -DORAM_N=... (build.sh: NMAX=...).
`ifndef ORAM_N
`define ORAM_N              512   // slots (maximum); 64 buckets at lambda = 8, as the test scenarios assume
`endif
`define ORAM_Z              10  // positions per bucket: lambda 8 + 2 slack (on-package minimum at a 20% HBM share)
`define ORAM_C              8   // lambda: real slots per bucket
`define ORAM_B              ((`ORAM_N + `ORAM_C - 1) / `ORAM_C)   // buckets (maximum) = ceil(N / lambda)
`define ORAM_PART_W         0     // one ORAM, no partitions
`define BUCKET_ID_W         $clog2(`ORAM_B)                       // 6 at N = 256
`define SLOT_ID_W           $clog2(`ORAM_N)                       // 8 at N = 256
`define ORAM_STASH_DEPTH    128   // entries per ORAM (per client in the two-client build)
// The stash lives in HBM: each bucket has a list of ORAM_STASH_SLOTS pointers (blocks waiting for it)
// into a pool of ORAM_STASH_DEPTH blocks. DOMA places each block in ONE random bucket, so the most
// blocks waiting for any bucket has a geometric tail; 64 makes overflow negligible up to N = 10M.
`define ORAM_STASH_SLOTS    64

// --- Bit widths ---
// slot addresses are slot << 12; the IV/tag interface uses the same width for {bucket, position} << 12,
// so it must hold both (35 bits at 2^22 slots: 20-bit buckets + 3-bit positions + 12)
`define SLOT_ADDR_W_A      ((`SLOT_ID_W + 13 > 32) ? (`SLOT_ID_W + 13) : 32)   // room for a size of N x 4096 (n = N inclusive)
`define SLOT_ADDR_W         ((`BUCKET_ID_W + `POS_IN_BKT_W + 12 > `SLOT_ADDR_W_A) ? (`BUCKET_ID_W + `POS_IN_BKT_W + 12) : `SLOT_ADDR_W_A)
`define FILL_CNT_W          4         // ceil(log2(Z+1)) = 4, holds 0..10
`define POS_IN_BKT_W        4         // ceil(log2(Z)) = 4
`define STASH_PTR_W         7   // ceil(log2(STASH_DEPTH))

// --- AXI parameters ---
`define AXI_DATA_W          256       // 256-bit data bus (32 bytes per beat)
`define AXI_ADDR_W          40    // bucket byte offsets: 1 TB (32 wrapped at 4 GB: 4 KB blocks, N = 1M needs 5.4 GB)
`define AXI_STRB_W          32        // AXI_DATA_W / 8
`define AXI_ID_W            4
`define AXI_LEN_W           8         // AXI4 standard: 8-bit ARLEN/AWLEN

// --- Beat/block parameters ---
// Block (ORAM slot) size in 32-byte beats: 1, 2, 4 or 8 for 32-256-byte records (the value
// sizes of BOLT's experiments), 128 for 4 KB pages. Select with -DORAM_BLOCK_BEATS=N.
`ifndef ORAM_BLOCK_BEATS
`define ORAM_BLOCK_BEATS    128
`endif
`define BEATS_PER_BLOCK     `ORAM_BLOCK_BEATS
`define BEATS_PER_BKT       (`ORAM_Z * `BEATS_PER_BLOCK)                 // beats in one bucket
`define BEAT_CNT_W          $clog2(`ORAM_Z * `BEATS_PER_BLOCK + 1)       // holds 0..BEATS_PER_BKT

// --- DDR layout ---
`define DDR_BASE            32'h0000_0000
`define BUCKET_BYTES        (`ORAM_Z * `BEATS_PER_BLOCK * 32)            // compact layout: a bucket is exactly Z blocks
`define SCR_AW              (`POS_IN_BKT_W + $clog2(`BEATS_PER_BLOCK))    // a bucket beat's address: {position, beat in block}

// --- Slot status encoding ---
// bucket record in HBM: beat 0 metadata {slot list, fill}, beat 1 the bucket's {tag, IV} (per-bucket GCM): 64 bytes
`define ORAM_REC_BEATS      2
`define ST_DUMMY            2'b00
`define ST_VALID            2'b01
`define ST_IN_STASH         2'b10

// --- FSM states ---
`define S_IDLE              4'd0
`define S_POS_LOOKUP        4'd1
`define S_DDR_READ          4'd2
`define S_SCAN              4'd3
`define S_SCAN2             4'd4
`define S_EXTRACT           4'd5
`define S_STASH_SEARCH      4'd6
`define S_STASH_READ        4'd7
`define S_COMPACT           4'd8
`define S_EVICT             4'd9
`define S_DDR_WRITE         4'd10
`define S_RESPOND           4'd11


// Phase 2 constant-time budgets (cycles after an access is accepted): bucket
// read issue, write-back issue, result release. 0 = gate off (calibration).
// The position map is in HBM: the bucket read can start only once its lookup returns.
// ORAM_PM_LAT is the budget for that lookup; every fixed point moves out by it. Measured on the
// U55C (latency/): dependent 32-byte HBM reads average 64 cycles, at most 179 in 2M samples.
`ifndef ORAM_PM_LAT
`define ORAM_PM_LAT      250
`endif
`define ORAM_CT_RD_BASE  16      // with an on-chip map: calibrated on the testbench DDR model (arrival 2)
`ifndef ORAM_CT_RD
`define ORAM_CT_RD   (`ORAM_CT_RD_BASE + `ORAM_PM_LAT)
`endif
// Per block size (beats), from the regression's derived worst case on the testbench memory, with an
// on-chip position map (the selection below adds ORAM_PM_LAT):
//   CT_WB   = worst encryption end + 300 - (Z-1)*BEATS  (the write-back reaches the last position
//             (Z-1)*BEATS cycles after it starts), rounded up
//   CT_DONE = CT_WB + longest write-back + 250, rounded up
// Sizes not listed fall back to the 4 KB budgets (safe, but padded to the 4 KB access time).
`define ORAM_CT_WB_B1      752    // 32 B, Z = 10, 11 candidates: encryption ends at worst 267 + 179 + 231 + 1 (stash wait) + 52 + 227 = 957 <= 752+250+9 = 1,011
`define ORAM_CT_DONE_B1    854    // write-back (10 beats) + HBM acknowledgement (28): CT_DONE - CT_WB = 102 (measured at most 36)
`define ORAM_CT_WB_B2      980    // Z = 8 value: RECALIBRATE for Z = 10 before use (too small -> overrun, fail-stop)
`define ORAM_CT_DONE_B2    1270    // Z = 8 value: RECALIBRATE for Z = 10 before use (too small -> overrun, fail-stop)
`define ORAM_CT_WB_B4      1020    // Z = 8 value: RECALIBRATE for Z = 10 before use (too small -> overrun, fail-stop)
`define ORAM_CT_DONE_B4    1320    // Z = 8 value: RECALIBRATE for Z = 10 before use (too small -> overrun, fail-stop)
`define ORAM_CT_WB_B8      1110    // Z = 8 value: RECALIBRATE for Z = 10 before use (too small -> overrun, fail-stop)
`define ORAM_CT_DONE_B8    1450    // Z = 8 value: RECALIBRATE for Z = 10 before use (too small -> overrun, fail-stop)
`define ORAM_CT_WB_B128    5070   // 4 KB, Z = 10: encryption ends at worst 267 + 307 (HBM 4 KB burst max) + 2,771 + 1 + 306 + 2,767 = 6,419 <= 5070+250+9*128 = 6,472
`define ORAM_CT_DONE_B128  7070   // write-back of 1,280 beats + acknowledgement + margin: CT_DONE - CT_WB = 2,000 (measured at most 1,795 under backpressure)
`ifndef ORAM_CT_WB
`define ORAM_CT_WB   ((`ORAM_BLOCK_BEATS == 1 ? `ORAM_CT_WB_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_CT_WB_B2 : \
                       `ORAM_BLOCK_BEATS == 4 ? `ORAM_CT_WB_B4 : `ORAM_BLOCK_BEATS == 8 ? `ORAM_CT_WB_B8 : `ORAM_CT_WB_B128) + `ORAM_PM_LAT)
`endif
`ifndef ORAM_CT_DONE
`define ORAM_CT_DONE ((`ORAM_BLOCK_BEATS == 1 ? `ORAM_CT_DONE_B1 : `ORAM_BLOCK_BEATS == 2 ? `ORAM_CT_DONE_B2 : \
                       `ORAM_BLOCK_BEATS == 4 ? `ORAM_CT_DONE_B4 : `ORAM_BLOCK_BEATS == 8 ? `ORAM_CT_DONE_B8 : `ORAM_CT_DONE_B128) + `ORAM_PM_LAT)
`endif

// Arrival-relative scheduling (build option ORAM_SCHED_ARRIVAL, build.sh SCHED=arrival). The write-back and the
// end of an access follow the bucket read's LAST BEAT by these fixed times, instead of fixed offsets from the
// access start: the attacker sees the off-package read's latency anyway, so only hidden work is padded (the
// read still issues at CT_RD, covering the hidden position-map lookup; AR_WB covers the worst-case on-chip work
// after the data arrives: verification, stash, evictions, re-encryption). AR_DONE - AR_WB covers the write-back
// and its acknowledgement (+70 over the HBM-calibrated gap: PCIe acknowledges in 98 cycles, HBM in 28).
// The boot format reads no bucket and keeps the strict offsets. Calibrated from ar_max_wb (see README).
// What stays padded is everything that depends on secrets: the position-map lookup (CT_RD), the requested block's
// own path (stash hit, compaction) and all eviction work and its writes (AR_WB, AR_DONE). A bucket's read latency
// is not: buckets are chosen at random, and the bucket bank serves only buckets. This holds for buckets in HBM
// too, PROVIDED the eviction-related metadata traffic does not interfere with the bucket bank (on the U55C the
// HBM bucket bank sits on a different memory controller from the position map, records and stash).
`define ORAM_AR_WB_B1      554    // 32 B, Z = 10, 11 candidates: worst work after arrival, derived 231 + 1 + 52 + 227 = 511 (measured 486), + 43
`define ORAM_AR_DONE_B1      692    // 32 B: AR_WB + 138 = write-back (10 beats) + PCIe acknowledgement (~115 measured) + 20%
`define ORAM_AR_WB_B128      5899   // 4 KB, Z = 10: bound A + W + B..D + Ec = 2,771 + 1 + 306 + 2,767 = 5,845 (measured 4,668), + 54
`define ORAM_AR_DONE_B128    7825   // + 1,926 (write-back of 1,280 beats, PCIe acknowledgement, margin)
// HBM buckets: their write-back point AR_WB_H covers a later stash. With the bucket read fast (HBM, 52 cycles at
// least), the stash can be ready after verification: it opens only after the position-map lookup, then needs two
// dependent HBM reads (its head, then the candidates). Budgeted at 200 cycles per HBM read (measured worst 191 on the
// U55C, latency/lat_multi). Off-package buckets are unaffected: PCIe's minimum latency exceeds the stash's worst.
`define ORAM_AR_WB_H_B1    598    // 32 B: adverse-latency run (every HBM metadata read 200, bucket 52): 556, + 42
`define ORAM_AR_WB_H_B128    5899   // 4 KB: verification (2,771) outlasts the stash's worst readiness (adverse run 4,668): = AR_WB
`define ORAM_AR_WB_H ((`ORAM_BLOCK_BEATS == 1) ? `ORAM_AR_WB_H_B1 : (`ORAM_BLOCK_BEATS == 128) ? `ORAM_AR_WB_H_B128 : `ORAM_CT_WB)
// HBM buckets (fixed boundary): the same work after arrival; HBM acknowledges writes in 28 cycles (PCIe 98), so their
// completion follows the write-back by the strict-mode allowance (CT_DONE - CT_WB)
`define ORAM_AR_DONE_H_B1    644    // 32 B: AR_WB_H + 46 = write-back (10 beats) + HBM acknowledgement (28) + 20%
`define ORAM_AR_DONE_H_B128  7755   // 4 KB: AR_WB_H + 1,856
`define ORAM_AR_DONE_H ((`ORAM_BLOCK_BEATS == 1) ? `ORAM_AR_DONE_H_B1 : (`ORAM_BLOCK_BEATS == 128) ? `ORAM_AR_DONE_H_B128 : `ORAM_CT_DONE)
`define ORAM_AR_WB   ((`ORAM_BLOCK_BEATS == 1) ? `ORAM_AR_WB_B1   : (`ORAM_BLOCK_BEATS == 128) ? `ORAM_AR_WB_B128   : `ORAM_CT_WB)
`define ORAM_AR_DONE ((`ORAM_BLOCK_BEATS == 1) ? `ORAM_AR_DONE_B1 : (`ORAM_BLOCK_BEATS == 128) ? `ORAM_AR_DONE_B128 : `ORAM_CT_DONE)
// Arrival mode: the access ends (result released, next request accepted) once the write-back's data has been handed
// to the master, not after its acknowledgement: the acknowledgements drain during the next access's lookup, and every
// later read is ordered after them (axi_master holds a read until all earlier writes are acknowledged; pos_map_hbm and
// bucket_rec_hbm never let a read overtake a write; the stash opens only once quiet).
`define ORAM_AR_REL_B1      590    // 32 B: AR_WB + 36 = write-back data handed off (10 beats + handshakes) + 20%
`define ORAM_AR_REL_B128    7459   // 4 KB: AR_WB + 1,560 = 1,280 beats (+ 2 idle per burst) + 20%
`define ORAM_AR_REL_H_B1    634    // 32 B, HBM bucket: AR_WB_H + 36
`define ORAM_AR_REL_H_B128  7459   // 4 KB, HBM bucket: AR_WB_H + 1,560
`define ORAM_AR_REL   ((`ORAM_BLOCK_BEATS == 1) ? `ORAM_AR_REL_B1   : (`ORAM_BLOCK_BEATS == 128) ? `ORAM_AR_REL_B128   : `ORAM_AR_DONE)
`define ORAM_AR_REL_H ((`ORAM_BLOCK_BEATS == 1) ? `ORAM_AR_REL_H_B1 : (`ORAM_BLOCK_BEATS == 128) ? `ORAM_AR_REL_H_B128 : `ORAM_AR_DONE_H)


// Phase 3 time-division arbiter: default slot length = padded access (completion
// gate) + result window + slack so a client that re-requests on completion (and
// must buffer a full write block) makes its next own slot.
`ifndef ORAM_TDM_SLOT
`define ORAM_TDM_SLOT (`ORAM_CT_DONE + 2*`BEATS_PER_BLOCK + 48)
`endif

`endif
