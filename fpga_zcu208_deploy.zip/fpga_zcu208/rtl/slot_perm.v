`include "oram_params.vh"
// slot_perm.v -- the boot layout's permutation of the slots, as a stream: for k = 0, 1, ..., n-1 it gives
// slot = P(k), a bijection of [0, n). It replaces the N-entry Fisher-Yates array, which cannot scale to
// millions of slots. f is a keyed bijection of m-bit values, m = ceil(log2 n) chosen at run time (so
// cycle-walking stays short for any n up to 2^M): xor a key, multiply by an odd constant (mod 2^m),
// xor-shift, add a key, multiply, xor-shift -- every step is a bijection of [0, 2^m), so f is one -- and
// cycle-walking (apply f again until the value is below n) makes it a bijection of [0, n). Like the remap
// generator, this is a STATISTICAL stand-in: the layout's secrecy rests on the assumed secure random
// source. Performance only needs every bucket to start with lambda blocks, which any bijection gives.
// One application of f takes 3 cycles; fewer than 2 applications per slot on average.
// Handshake: `start` restarts at k = 0 (n is sampled then); `valid` with `slot` presents P(k); `take`
// (combinational, from the consumer) consumes it, and P(k+1) follows. After k = n-1 nothing more comes.
module slot_perm #(
    parameter M           = 8,                            // maximum bits of a slot number
    parameter [63:0] KEY  = 64'h6A09_E667_F3BC_C908       // fixed key (a stand-in, like the seed)
) (
    input  wire          clk,
    input  wire          rst_n,
    input  wire [M:0]    n,                               // domain size, 1 .. 2^M
    input  wire          start,
    input  wire          take,
    output reg           valid,
    output reg  [M-1:0]  slot
);
    localparam [31:0]  A1L = 32'h9E37_79B1, A2L = 32'h85EB_CA6B;
    localparam [M-1:0] A1 = A1L[M-1:0] | {{(M-1){1'b0}}, 1'b1};   // odd multipliers
    localparam [M-1:0] A2 = A2L[M-1:0] | {{(M-1){1'b0}}, 1'b1};
    localparam [M-1:0] K0 = KEY[M-1:0];
    localparam [M-1:0] K1 = KEY[63:64-M];
    localparam MW = $clog2(M + 1);
    // run-time domain: m = ceil(log2 n) bits (at least 1), mask = 2^m - 1, shift = ceil(m/2)
    reg  [M:0]    n_q;
    reg  [MW-1:0] m_q, sh_q;
    reg  [M-1:0]  mask_q;
    reg  [M:0]    k;                                      // index being produced
    reg  [M-1:0]  cur;                                    // value being mapped (k, then walked values)
    reg  [M-1:0]  s1, s2;
    reg  [1:0]    ph;                                     // 0 idle, 1..3 the three stages of f
    wire [M-1:0]  t1 = (s1 ^ (s1 >> sh_q)) & mask_q;
    wire [M-1:0]  y  = (s2 ^ (s2 >> sh_q)) & mask_q;
    function [MW-1:0] bits_for; input [M:0] v; integer i; begin   // ceil(log2 v), at least 1
        bits_for = 1; for (i = 1; i <= M; i = i + 1) if ((v - 1) >> i) bits_for = i + 1; end endfunction
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            n_q <= 0; m_q <= 1; sh_q <= 1; mask_q <= 1;
            k <= 0; cur <= 0; s1 <= 0; s2 <= 0; ph <= 2'd0; valid <= 1'b0; slot <= 0;
        end else if (start) begin
            n_q <= n; m_q <= bits_for(n); sh_q <= (bits_for(n) + 1) >> 1;
            mask_q <= {M{1'b1}} >> (M - bits_for(n));
            k <= 0; cur <= 0; ph <= 2'd1; valid <= 1'b0;
        end else begin
            if (take && valid) begin
                valid <= 1'b0;
                if (k + 1'b1 < n_q) begin k <= k + 1'b1; cur <= k[M-1:0] + 1'b1; ph <= 2'd1; end
            end
            case (ph)
                2'd1: begin s1 <= ((cur ^ K0) * A1) & mask_q; ph <= 2'd2; end
                2'd2: begin s2 <= ((t1 + K1) * A2) & mask_q;  ph <= 2'd3; end
                2'd3: if ({1'b0, y} < n_q) begin slot <= y; valid <= 1'b1; ph <= 2'd0; end
                      else begin cur <= y; ph <= 2'd1; end          // cycle-walk
                default: ;
            endcase
        end
    end
endmodule
