`include "oram_params.vh"
// rng_bucket.v -- the new random target bucket of each access (replaces the 12-bit LFSR, whose 4,095
// states cannot cover many buckets). A 64-bit xorshift (Marsaglia's 13/7/17 triple, period 2^64-1) is a
// STATISTICAL generator: DOMA's security assumes a cryptographically secure random source (e.g. AES in
// counter mode seeded from a TRNG), which this stands in for; performance does not depend on which.
// The draw is mapped onto any number of buckets nb with bucket = (r * nb) >> 40, r = the state's top 40
// bits (bias at most nb / 2^40), so nb need not be a power of two. The state advances only when the
// controller takes a value (one per access), so the sequence of targets is the same for any request
// stream. The output is pipelined (state, product, output: valid 3 cycles after a take); an access lasts
// far longer, so a fresh value is always waiting.
module rng_bucket #(
    parameter OUT_W        = `BUCKET_ID_W,
    parameter [63:0] SEED  = 64'h9E37_79B9_7F4A_7C15     // fixed (non-zero); a deployment seeds from a TRNG
) (
    input  wire             clk,
    input  wire             rst_n,
    input  wire [OUT_W:0]   nb,                          // number of buckets, 1 .. 2^OUT_W
    input  wire             take,                        // `bucket` was used: produce the next
    output reg  [OUT_W-1:0] bucket                       // uniform in [0, nb)
);
    reg  [63:0] x;
    wire [63:0] x1 = x  ^ (x  << 13);
    wire [63:0] x2 = x1 ^ (x1 >> 7);
    wire [63:0] x3 = x2 ^ (x2 << 17);
    always @(posedge clk or negedge rst_n)
        if (!rst_n) x <= (SEED == 64'd0) ? 64'd1 : SEED;
        else if (take) x <= x3;
    reg  [39:0]          r_q;
    reg  [OUT_W:0]       nb_q;
    reg  [40+OUT_W:0]    p_q;
    always @(posedge clk) begin
        r_q    <= x[63:24];
        nb_q   <= nb;
        p_q    <= r_q * nb_q;
        bucket <= p_q[40+OUT_W-1:40];
    end
endmodule
