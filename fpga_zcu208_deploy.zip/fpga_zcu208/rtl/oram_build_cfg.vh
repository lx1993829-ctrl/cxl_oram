// oram_build_cfg.vh -- build-time configuration, written by vitis/build.sh (BEATS=N).
// Empty by default: oram_params.vh then uses its defaults (4 KB blocks).
