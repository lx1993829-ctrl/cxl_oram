`include "oram_params.vh"
// bucket_rec_hbm.v -- the bucket metadata and the IV/tag table in HBM (on-package, trusted memory),
// behind the same two interfaces as bucket_meta and iv_slot_table.
//
// Each bucket b has a record of REC_BEATS 32-byte beats at base + b * REC_BEATS * 32:
//   beat 0      bucket metadata {slot list, fill count}   (as bucket_meta's entry)
//   beat 1 + p  position p's {tag, IV}                    (as iv_slot_table's entry)
// A bucket-metadata read "opens" the bucket: its whole record is fetched in ONE burst into an on-chip
// buffer (the controller issues it at the read gate, in parallel with the bucket's own read). The
// metadata is answered when beat 0 lands; an IV/tag read of the open bucket is answered as soon as its
// beat has landed. Writes update the open record's buffer and are posted to HBM through a FIFO (one
// beat each); wr_quiet reports that all of them are acknowledged. The
// controller completes an access only when it is, so the next record fetch sees every write. As a
// safety net, HBM reads are issued only while quiet. An IV/tag read of a bucket that is not open (the
// controller never does this) is fetched individually. Boot writes every metadata and IV/tag entry
// before the first access, so HBM's initial contents never matter.
//
// The record buffer and the write FIFO each have ONE write port (metadata and IV/tag writes never
// coincide; if they did, err is set and DOMA stops), so both are small LUT-RAMs rather than thousands
// of registers, and the FIFO's head is registered before it drives the AXI write channel.
module bucket_rec_hbm #(
    parameter Z          = `ORAM_Z,
    parameter BUCKET_W   = `BUCKET_ID_W,
    parameter SLOT_W     = `SLOT_ID_W,
    parameter FILL_W     = `FILL_CNT_W,
    parameter POS_W      = `POS_IN_BKT_W,
    parameter ADDR_W     = `SLOT_ADDR_W,
    parameter IV_W       = 96,
    parameter TAG_W      = 128,
    parameter AXI_DW     = 256,
    parameter FIFO_D     = 16
) (
    input  wire                     clk,
    input  wire                     rst_n,
    input  wire [63:0]              base,
    // bucket metadata (as bucket_meta)
    input  wire [BUCKET_W-1:0]      bm_rd_bucket,
    input  wire                     bm_rd_en,
    output reg  [Z*SLOT_W-1:0]      bm_rd_slot_list,
    output reg  [FILL_W-1:0]        bm_rd_fill,
    output reg                      bm_rd_valid,
    input  wire [BUCKET_W-1:0]      bm_wr_bucket,
    input  wire [Z*SLOT_W-1:0]      bm_wr_slot_list,
    input  wire [FILL_W-1:0]        bm_wr_fill,
    input  wire                     bm_wr_en,
    // IV/tag (as iv_slot_table; address {bucket, position, 12'b0})
    input  wire [ADDR_W-1:0]        iv_rd_addr,
    input  wire                     iv_rd_en,
    output reg  [IV_W-1:0]          iv_rd_iv,
    output reg  [TAG_W-1:0]         iv_rd_tag,
    output reg                      iv_rd_valid,
    input  wire [ADDR_W-1:0]        iv_wr_addr,
    input  wire [IV_W-1:0]          iv_wr_iv,
    input  wire [TAG_W-1:0]         iv_wr_tag,
    input  wire                     iv_wr_en,
    output wire                     wr_ready,        // the write FIFO has room
    output wire                     wr_quiet,        // nothing queued, in flight or unacknowledged
    output reg                      err,             // sticky: a write arrived with the FIFO full
    // AXI4 master
    output wire [63:0]              m_araddr,
    output wire [7:0]               m_arlen,
    output wire [2:0]               m_arsize,
    output wire [1:0]               m_arburst,
    output reg                      m_arvalid,
    input  wire                     m_arready,
    input  wire [AXI_DW-1:0]        m_rdata,
    input  wire                     m_rlast,
    input  wire                     m_rvalid,
    output wire                     m_rready,
    output wire [63:0]              m_awaddr,
    output wire [7:0]               m_awlen,
    output wire [2:0]               m_awsize,
    output wire [1:0]               m_awburst,
    output reg                      m_awvalid,
    input  wire                     m_awready,
    output wire [AXI_DW-1:0]        m_wdata,
    output wire [AXI_DW/8-1:0]      m_wstrb,
    output wire                     m_wlast,
    output reg                      m_wvalid,
    input  wire                     m_wready,
    input  wire                     m_bvalid,
    output wire                     m_bready
);
    localparam REC_BEATS = 1 << $clog2(Z + 1);         // 8 for Z = 6: a 256-byte record
    localparam RB_W      = $clog2(REC_BEATS);
    localparam BI_W      = BUCKET_W + RB_W;            // beat index in the record area
    localparam BM_W      = Z * SLOT_W + FILL_W;
    localparam FA_W      = $clog2(FIFO_D);

    function [63:0] beat_addr; input [BI_W-1:0] bi; begin beat_addr = base + ({{(64-BI_W){1'b0}}, bi} << 5); end endfunction

    // ---------------- the open record ----------------
    (* ram_style = "distributed" *) reg [AXI_DW-1:0] rec [0:REC_BEATS-1];
    reg  [REC_BEATS-1:0] have;                         // beat k of the open record is valid
    reg  [BUCKET_W-1:0] open_b;
    reg                 open_v;                        // a record is open (possibly still arriving)

    // ---------------- reads: one outstanding at a time ----------------
    reg                 f_pend, f_wait;                // record fetch requested / address issued
    reg  [RB_W:0]       f_beat;                        // beats of the fetch received so far
    reg                 iv_pend;                       // an IV/tag read is waiting
    reg  [BUCKET_W-1:0] iv_b;
    reg  [POS_W-1:0]    iv_p;
    reg                 s_pend, s_wait;                // fallback single-beat read (bucket not open)
    wire [BUCKET_W-1:0] iv_rd_b = iv_rd_addr[BUCKET_W+POS_W+11:POS_W+12];
    wire [POS_W-1:0]    iv_rd_p = iv_rd_addr[POS_W+11:12];
    wire [BUCKET_W-1:0] iv_wr_b = iv_wr_addr[BUCKET_W+POS_W+11:POS_W+12];
    wire [POS_W-1:0]    iv_wr_p = iv_wr_addr[POS_W+11:12];
    wire [RB_W-1:0]     iv_k    = {{(RB_W-POS_W){1'b0}}, iv_p} + 1'b1;   // beat holding position iv_p
    wire                iv_hit  = open_v && (iv_b == open_b);
    assign m_araddr  = f_pend ? beat_addr({open_b, {RB_W{1'b0}}}) : beat_addr({iv_b, iv_k});
    assign m_arlen   = f_pend ? Z[7:0] : 8'd0;         // the record (1 + Z beats) or one beat
    assign m_arsize  = 3'b101;
    assign m_arburst = 2'b01;
    assign m_rready  = 1'b1;

    // ---------------- writes: FIFO of {beat index, data}, one push per cycle ----------------
    (* ram_style = "distributed" *) reg [BI_W-1:0]   q_bi [0:FIFO_D-1];
    (* ram_style = "distributed" *) reg [AXI_DW-1:0] q_d  [0:FIFO_D-1];
    reg  [AXI_DW-1:0]   w_data_q;                       // the write on the bus, registered from the FIFO head
    reg  [BI_W-1:0]     w_bi_q;
    reg  [FA_W:0]       q_n;
    reg  [FA_W-1:0]     q_rp, q_wp;
    reg  [4:0]          outst;
    reg                 w_busy, aw_done, w_done;
    wire                pop  = w_busy && (aw_done || (m_awvalid && m_awready)) && (w_done || (m_wvalid && m_wready));
    wire                push    = iv_wr_en || bm_wr_en;
    wire [AXI_DW-1:0]   iv_word = {{(AXI_DW-TAG_W-IV_W){1'b0}}, iv_wr_tag, iv_wr_iv};
    wire [AXI_DW-1:0]   bm_word = {{(AXI_DW-BM_W){1'b0}}, bm_wr_slot_list, bm_wr_fill};
    wire [RB_W-1:0]     iv_wr_k = {{(RB_W-POS_W){1'b0}}, iv_wr_p} + 1'b1;
    wire [BI_W-1:0]     push_bi = iv_wr_en ? {iv_wr_b, iv_wr_k} : {bm_wr_bucket, {RB_W{1'b0}}};
    wire [AXI_DW-1:0]   push_d  = iv_wr_en ? iv_word : bm_word;
    assign wr_ready  = (q_n < FIFO_D - 2);              // room for one more, plus one in flight
    assign wr_quiet  = (q_n == 0) && !w_busy && (outst == 0);
    assign m_awaddr  = beat_addr(w_bi_q);
    assign m_awlen   = 8'd0;
    assign m_awsize  = 3'b101;
    assign m_awburst = 2'b01;
    assign m_wdata   = w_data_q;
    assign m_wstrb   = {(AXI_DW/8){1'b1}};
    assign m_wlast   = 1'b1;
    assign m_bready  = 1'b1;

    // single-write-port storage (LUT-RAM): one FIFO push, one record-buffer write per cycle
    wire              rec_we = (f_wait && m_rvalid) || (iv_wr_en && open_v && iv_wr_b == open_b) ||
                               (bm_wr_en && open_v && bm_wr_bucket == open_b);
    wire [RB_W-1:0]   rec_wa = (f_wait && m_rvalid) ? f_beat[RB_W-1:0] : iv_wr_en ? iv_wr_k : {RB_W{1'b0}};
    wire [AXI_DW-1:0] rec_wd = (f_wait && m_rvalid) ? m_rdata : iv_wr_en ? iv_word : bm_word;
    always @(posedge clk) begin                        // (no reset needed)
        if (push)   begin q_bi[q_wp] <= push_bi; q_d[q_wp] <= push_d; end
        if (rec_we) rec[rec_wa] <= rec_wd;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            have <= {REC_BEATS{1'b0}}; open_b <= {BUCKET_W{1'b0}}; open_v <= 1'b0;
            f_pend <= 1'b0; f_wait <= 1'b0; f_beat <= 0; iv_pend <= 1'b0; iv_b <= 0; iv_p <= 0;
            s_pend <= 1'b0; s_wait <= 1'b0; m_arvalid <= 1'b0;
            bm_rd_valid <= 1'b0; bm_rd_slot_list <= 0; bm_rd_fill <= 0;
            iv_rd_valid <= 1'b0; iv_rd_iv <= 0; iv_rd_tag <= 0;
            q_n <= 0; q_rp <= 0; q_wp <= 0; outst <= 0; w_busy <= 1'b0; aw_done <= 1'b0; w_done <= 1'b0;
            m_awvalid <= 1'b0; m_wvalid <= 1'b0; err <= 1'b0; w_data_q <= {AXI_DW{1'b0}}; w_bi_q <= {BI_W{1'b0}};
        end else begin
            bm_rd_valid <= 1'b0;
            iv_rd_valid <= 1'b0;
            // open a bucket: fetch its whole record
            if (bm_rd_en) begin
                open_b <= bm_rd_bucket; open_v <= 1'b1; have <= {REC_BEATS{1'b0}};
                f_pend <= 1'b1; f_beat <= 0;
            end
            if (iv_rd_en) begin iv_pend <= 1'b1; iv_b <= iv_rd_b; iv_p <= iv_rd_p; end
            // a waiting IV/tag read of the open bucket: answer once its beat is in
            if (iv_pend && iv_hit && have[iv_k]) begin
                iv_rd_iv <= rec[iv_k][IV_W-1:0]; iv_rd_tag <= rec[iv_k][IV_W+TAG_W-1:IV_W];
                iv_rd_valid <= 1'b1; iv_pend <= 1'b0;
            end else if (iv_pend && !iv_hit && !s_pend && !s_wait && !f_pend && !f_wait) s_pend <= 1'b1;
            // issue one read at a time, only while every write is acknowledged
            if (!m_arvalid && !f_wait && !s_wait && wr_quiet && (f_pend || s_pend)) m_arvalid <= 1'b1;
            if (m_arvalid && m_arready) begin
                m_arvalid <= 1'b0;
                if (f_pend) begin f_pend <= 1'b0; f_wait <= 1'b1; end
                else        begin s_pend <= 1'b0; s_wait <= 1'b1; end
            end
            if (f_wait && m_rvalid) begin
                have[f_beat[RB_W-1:0]] <= 1'b1;
                if (f_beat == 0) begin
                    bm_rd_slot_list <= m_rdata[BM_W-1:FILL_W]; bm_rd_fill <= m_rdata[FILL_W-1:0]; bm_rd_valid <= 1'b1;
                end
                f_beat <= f_beat + 1'b1;
                if (m_rlast) f_wait <= 1'b0;
            end
            if (s_wait && m_rvalid) begin                      // fallback: answer the waiting IV/tag read
                iv_rd_iv <= m_rdata[IV_W-1:0]; iv_rd_tag <= m_rdata[IV_W+TAG_W-1:IV_W];
                iv_rd_valid <= 1'b1; iv_pend <= 1'b0; s_wait <= 1'b0;
            end
            // this access's own IV/tag writes count as present in the open record
            if (iv_wr_en && open_v && iv_wr_b == open_b) have[iv_wr_k] <= 1'b1;
            // write FIFO
            if (push) q_wp <= q_wp + 1'b1;
            // never expected: a full FIFO, two writes in one cycle, or a write into the record while it
            // is still arriving. Any of them stops DOMA (fail-stop) instead of corrupting state.
            if ((push && q_n == FIFO_D) || (iv_wr_en && bm_wr_en) ||
                ((f_wait && m_rvalid) && ((iv_wr_en && open_v && iv_wr_b == open_b) || (bm_wr_en && open_v && bm_wr_bucket == open_b))))
                err <= 1'b1;
            q_n <= q_n + (push && q_n != FIFO_D) - pop;
            if (!w_busy && q_n != 0) begin
                w_busy <= 1'b1; aw_done <= 1'b0; w_done <= 1'b0; m_awvalid <= 1'b1; m_wvalid <= 1'b1;
                w_data_q <= q_d[q_rp]; w_bi_q <= q_bi[q_rp];     // the head, registered onto the bus
            end else if (w_busy) begin
                if (m_awvalid && m_awready) begin m_awvalid <= 1'b0; aw_done <= 1'b1; end
                if (m_wvalid && m_wready)   begin m_wvalid  <= 1'b0; w_done  <= 1'b1; end
                if (pop) begin w_busy <= 1'b0; q_rp <= q_rp + 1'b1; end
            end
            outst <= outst + (m_awvalid && m_awready) - m_bvalid;
        end
    end
endmodule
