`default_nettype none   // implicit nets are errors (catches undeclared / mistyped wires)
// =============================================================================
// ghash_lane3.v — GHASH at one block per cycle (3-way interleaved Horner)
//
// GHASH_H(X_1..X_n) = XOR_i X_i * H^(n+1-i)
//
// The single-accumulator form Y <- (Y ^ X) * H has a loop through the 2-stage
// multiplier, so it accepts a block only every 2-3 cycles. Here blocks are dealt
// round-robin to three lanes, each running Horner with H^3:
//     B_l <- (B_l * H^3) ^ X        (B_l * H^3 is precomputed as P_l)
// A lane is updated at most every 3 cycles and its next product is ready after 3
// (operand register, multiply, reduce),
// so one block can be accepted every cycle. After the block flagged `last`
// (the GCM length block), the lanes are combined:
//     Y = B[lane(n)]*H ^ B[lane(n-1)]*H^2 ^ B[lane(n-2)]*H^3
// Lanes that never received a block are zero, so short messages (n < 3) work;
// that is how the engine derives H^2 = GHASH(H) and H^3 = GHASH(H^2) once per key.
//
// One shared multiplier (gf_pmul_128 + gf_reduce_128), same bit conventions as
// ghash_single_cycle_fpga. ghash_valid pulses once, with the final value.
// =============================================================================
module ghash_lane3 (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         enable,
    input  wire         start,        // load H, H^2, H^3 and clear all lanes
    input  wire [127:0] h_key,
    input  wire [127:0] h2_key,
    input  wire [127:0] h3_key,
    input  wire [127:0] data_in,
    input  wire         data_valid,
    input  wire         last,         // qualifies data_valid: final block of the message
    output reg  [127:0] ghash_out,
    output reg          ghash_valid,
    output wire         ready
);
    function [127:0] reflect128;
        input [127:0] d;
        integer j;
        begin
            for (j = 0; j < 128; j = j + 1)
                reflect128[j] = d[127-j];
        end
    endfunction
    function [1:0] lane_minus;          // (l - k) mod 3, k in {1, 2}
        input [1:0] l;
        input [1:0] k;
        begin
            lane_minus = (l >= k) ? (l - k) : (l + 2'd3 - k);
        end
    endfunction

    reg [127:0] h1_q, h2_q, h3_q;
    reg [127:0] B0, B1, B2;             // lane accumulators
    reg [127:0] P0, P1, P2;             // B_l * H^3 for the lane's next block
    reg [1:0]   ln;                     // lane of the next block
    reg         loaded;
    reg         combining;
    reg [2:0]   cmb_step;               // 1..3: issue combine multiplies, 4: wait
    reg [1:0]   l_last;
    reg [127:0] cmb_acc;
    reg [1:0]   cmb_pending;

    assign ready = loaded && !combining;

    wire accept = data_valid && loaded && !combining && !start;
    wire [127:0] p_sel = (ln == 2'd0) ? P0 : (ln == 2'd1) ? P1 : P2;
    wire [127:0] b_new = p_sel ^ data_in;

    function [127:0] lane_val;
        input [1:0] l;
        begin
            lane_val = (l == 2'd0) ? B0 : (l == 2'd1) ? B1 : B2;
        end
    endfunction

    // ---- operand select for the shared multiplier ----
    reg          m_go;
    reg [127:0]  m_x, m_h;
    reg [2:0]    m_tag;                 // 0..2: P[tag]; 4: combine term
    always @(*) begin
        m_go = 1'b0; m_x = 128'b0; m_h = 128'b0; m_tag = 3'd0;
        if (accept) begin
            m_go = 1'b1; m_x = b_new; m_h = h3_q; m_tag = {1'b0, ln};
        end else if (combining && cmb_step >= 3'd1 && cmb_step <= 3'd3) begin
            m_go = 1'b1; m_tag = 3'd4;
            case (cmb_step)
                3'd1:    begin m_x = lane_val(l_last);                    m_h = h1_q; end
                3'd2:    begin m_x = lane_val(lane_minus(l_last, 2'd1));  m_h = h2_q; end
                default: begin m_x = lane_val(lane_minus(l_last, 2'd2));  m_h = h3_q; end
            endcase
        end
    end

    // Operand register in front of the multiplier: selecting the operands and the 128x128
    // multiply no longer share one cycle (together they missed 300 MHz by ~0.3 ns). A lane's
    // next product now lands one cycle later, exactly when the round-robin reuses the lane.
    reg          m_go_q;
    reg [2:0]    m_tag_q;
    reg [127:0]  m_x_q, m_h_q;
    wire [255:0] prod;
    gf_pmul_128 u_pmul (.a(reflect128(m_h_q)), .b(reflect128(m_x_q)), .p(prod));
    reg  [255:0] prod_q;
    reg          s1_v;
    reg  [2:0]   s1_tag;
    wire [127:0] red;
    gf_reduce_128 u_reduce (.c(prod_q), .r(red));
    wire [127:0] mres = reflect128(red);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            h1_q <= 0; h2_q <= 0; h3_q <= 0;
            B0 <= 0; B1 <= 0; B2 <= 0; P0 <= 0; P1 <= 0; P2 <= 0;
            ln <= 0; loaded <= 0; combining <= 0; cmb_step <= 0; l_last <= 0;
            cmb_acc <= 0; cmb_pending <= 0;
            prod_q <= 0; s1_v <= 0; s1_tag <= 0;
            m_go_q <= 0; m_tag_q <= 0; m_x_q <= 0; m_h_q <= 0;
            ghash_out <= 0; ghash_valid <= 0;
        end else if (enable) begin
            ghash_valid <= 1'b0;

            // stage 0: capture the selected operands
            m_go_q  <= m_go;
            m_tag_q <= m_tag;
            if (m_go) begin m_x_q <= m_x; m_h_q <= m_h; end

            // stage 1: capture product
            s1_v   <= m_go_q;
            s1_tag <= m_tag_q;
            if (m_go_q) prod_q <= prod;

            // stage 2: write back the reduced product
            if (s1_v) begin
                if (s1_tag[2]) begin
                    cmb_acc     <= cmb_acc ^ mres;
                    cmb_pending <= cmb_pending - 2'd1;
                end else if (s1_tag[1:0] == 2'd0) P0 <= mres;
                else if (s1_tag[1:0] == 2'd1)     P1 <= mres;
                else                               P2 <= mres;
            end

            if (accept) begin
                if (ln == 2'd0) B0 <= b_new; else if (ln == 2'd1) B1 <= b_new; else B2 <= b_new;
                ln <= (ln == 2'd2) ? 2'd0 : ln + 2'd1;
                if (last) begin
                    combining   <= 1'b1;
                    cmb_step    <= 3'd1;
                    l_last      <= ln;
                    cmb_acc     <= 128'b0;
                    cmb_pending <= 2'd3;
                end
            end

            if (combining) begin
                if (cmb_step >= 3'd1 && cmb_step <= 3'd3)
                    cmb_step <= cmb_step + 3'd1;
                else if (cmb_step == 3'd4 && cmb_pending == 2'd0) begin
                    ghash_out   <= cmb_acc;
                    ghash_valid <= 1'b1;
                    combining   <= 1'b0;
                    cmb_step    <= 3'd0;
                end
            end

            if (start) begin                       // last assignment wins
                h1_q <= h_key; h2_q <= h2_key; h3_q <= h3_key; loaded <= 1'b1;
                B0 <= 0; B1 <= 0; B2 <= 0; P0 <= 0; P1 <= 0; P2 <= 0;
                ln <= 0; combining <= 0; cmb_step <= 0; cmb_acc <= 0; cmb_pending <= 0;
                m_go_q <= 1'b0; s1_v <= 1'b0;      // drop anything in flight (none is, by protocol)
            end
        end
    end
endmodule
`default_nettype wire
