`timescale 1ns / 1ps
//============================================================================
// AES-128 Single Round Module - FPGA Synthesizable
// Performs one round of AES encryption
// Can be configured for final round (no MixColumns)
//============================================================================

module aes128_round_fpga (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         enable,
    input  wire         is_final_round,
    input  wire [127:0] state_in,
    input  wire [127:0] round_key,
    input  wire         valid_in,
    output reg  [127:0] state_out,
    output reg          valid_out
);

    wire [127:0] after_sub_bytes;
    wire [127:0] after_shift_rows;
    wire [127:0] after_mix_columns;
    wire [127:0] after_add_round_key;

    // SubBytes
    aes_sub_bytes sub_bytes_inst (
        .state_in(state_in),
        .state_out(after_sub_bytes)
    );

    // ShiftRows
    aes_shift_rows shift_rows_inst (
        .state_in(after_sub_bytes),
        .state_out(after_shift_rows)
    );

    // MixColumns
    aes_mix_columns mix_columns_inst (
        .state_in(after_shift_rows),
        .state_out(after_mix_columns)
    );

    // Select based on final round
    wire [127:0] pre_add_key;
    assign pre_add_key = is_final_round ? after_shift_rows : after_mix_columns;

    // AddRoundKey
    aes_add_round_key add_key_inst (
        .state_in(pre_add_key),
        .round_key(round_key),
        .state_out(after_add_round_key)
    );

    // Pipeline register
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_out <= 128'b0;
            valid_out <= 1'b0;
        end else if (enable) begin
            state_out <= after_add_round_key;
            valid_out <= valid_in;
        end
    end

endmodule

//============================================================================
// AES-128 Unrolled Pipeline Encryption Core - FPGA Synthesizable
// 10 rounds fully pipelined - one encryption per clock after initial latency
// Latency: 11 clock cycles (initial round + 10 rounds)
// Throughput: 128 bits per clock cycle
//============================================================================

module aes128_encrypt_pipeline_fpga (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         enable,
    input  wire [127:0] plaintext,
    input  wire [127:0] key,
    input  wire         valid_in,
    output wire [127:0] ciphertext,
    output wire         valid_out
);

    // Round keys, one key-schedule round per clock. rk(i) is computed from the REGISTER
    // rk(i-1), so each stage is one SubWord plus XORs. (Computing all ten rounds from the key
    // in one cycle and registering only the outputs left a 37-level, 7.7 ns path at 300 MHz.)
    // After the key input changes, rk(i) is correct i+1 cycles later: the controller lets its
    // key settle for 16 cycles before the first operation, and the key never changes after boot.
    reg  [127:0] rk0, rk1, rk2, rk3, rk4, rk5, rk6, rk7, rk8, rk9, rk10;
    wire [127:0] rk1_n, rk2_n, rk3_n, rk4_n, rk5_n, rk6_n, rk7_n, rk8_n, rk9_n, rk10_n;
    aes128_key_round #(.RCON(8'h01)) kr1  (.rk_in(rk0), .rk_out(rk1_n));
    aes128_key_round #(.RCON(8'h02)) kr2  (.rk_in(rk1), .rk_out(rk2_n));
    aes128_key_round #(.RCON(8'h04)) kr3  (.rk_in(rk2), .rk_out(rk3_n));
    aes128_key_round #(.RCON(8'h08)) kr4  (.rk_in(rk3), .rk_out(rk4_n));
    aes128_key_round #(.RCON(8'h10)) kr5  (.rk_in(rk4), .rk_out(rk5_n));
    aes128_key_round #(.RCON(8'h20)) kr6  (.rk_in(rk5), .rk_out(rk6_n));
    aes128_key_round #(.RCON(8'h40)) kr7  (.rk_in(rk6), .rk_out(rk7_n));
    aes128_key_round #(.RCON(8'h80)) kr8  (.rk_in(rk7), .rk_out(rk8_n));
    aes128_key_round #(.RCON(8'h1b)) kr9  (.rk_in(rk8), .rk_out(rk9_n));
    aes128_key_round #(.RCON(8'h36)) kr10 (.rk_in(rk9), .rk_out(rk10_n));
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rk0 <= 128'b0; rk1 <= 128'b0; rk2 <= 128'b0; rk3 <= 128'b0;
            rk4 <= 128'b0; rk5 <= 128'b0; rk6 <= 128'b0; rk7 <= 128'b0;
            rk8 <= 128'b0; rk9 <= 128'b0; rk10 <= 128'b0;
        end else begin
            rk0 <= key;   rk1 <= rk1_n; rk2 <= rk2_n; rk3 <= rk3_n; rk4 <= rk4_n; rk5 <= rk5_n;
            rk6 <= rk6_n; rk7 <= rk7_n; rk8 <= rk8_n; rk9 <= rk9_n; rk10 <= rk10_n;
        end
    end

    // Pipeline stages
    wire [127:0] state_0, state_1, state_2, state_3, state_4;
    wire [127:0] state_5, state_6, state_7, state_8, state_9, state_10;
    wire valid_0, valid_1, valid_2, valid_3, valid_4;
    wire valid_5, valid_6, valid_7, valid_8, valid_9, valid_10;

    // Initial AddRoundKey (round 0)
    reg [127:0] state_r0;
    reg         valid_r0;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_r0 <= 128'b0;
            valid_r0 <= 1'b0;
        end else if (enable) begin
            state_r0 <= plaintext ^ rk0;
            valid_r0 <= valid_in;
        end
    end

    assign state_0 = state_r0;
    assign valid_0 = valid_r0;

    // Round 1
    aes128_round_fpga round1 (
        .clk(clk), .rst_n(rst_n), .enable(enable),
        .is_final_round(1'b0),
        .state_in(state_0), .round_key(rk1),
        .valid_in(valid_0),
        .state_out(state_1), .valid_out(valid_1)
    );

    // Round 2
    aes128_round_fpga round2 (
        .clk(clk), .rst_n(rst_n), .enable(enable),
        .is_final_round(1'b0),
        .state_in(state_1), .round_key(rk2),
        .valid_in(valid_1),
        .state_out(state_2), .valid_out(valid_2)
    );

    // Round 3
    aes128_round_fpga round3 (
        .clk(clk), .rst_n(rst_n), .enable(enable),
        .is_final_round(1'b0),
        .state_in(state_2), .round_key(rk3),
        .valid_in(valid_2),
        .state_out(state_3), .valid_out(valid_3)
    );

    // Round 4
    aes128_round_fpga round4 (
        .clk(clk), .rst_n(rst_n), .enable(enable),
        .is_final_round(1'b0),
        .state_in(state_3), .round_key(rk4),
        .valid_in(valid_3),
        .state_out(state_4), .valid_out(valid_4)
    );

    // Round 5
    aes128_round_fpga round5 (
        .clk(clk), .rst_n(rst_n), .enable(enable),
        .is_final_round(1'b0),
        .state_in(state_4), .round_key(rk5),
        .valid_in(valid_4),
        .state_out(state_5), .valid_out(valid_5)
    );

    // Round 6
    aes128_round_fpga round6 (
        .clk(clk), .rst_n(rst_n), .enable(enable),
        .is_final_round(1'b0),
        .state_in(state_5), .round_key(rk6),
        .valid_in(valid_5),
        .state_out(state_6), .valid_out(valid_6)
    );

    // Round 7
    aes128_round_fpga round7 (
        .clk(clk), .rst_n(rst_n), .enable(enable),
        .is_final_round(1'b0),
        .state_in(state_6), .round_key(rk7),
        .valid_in(valid_6),
        .state_out(state_7), .valid_out(valid_7)
    );

    // Round 8
    aes128_round_fpga round8 (
        .clk(clk), .rst_n(rst_n), .enable(enable),
        .is_final_round(1'b0),
        .state_in(state_7), .round_key(rk8),
        .valid_in(valid_7),
        .state_out(state_8), .valid_out(valid_8)
    );

    // Round 9
    aes128_round_fpga round9 (
        .clk(clk), .rst_n(rst_n), .enable(enable),
        .is_final_round(1'b0),
        .state_in(state_8), .round_key(rk9),
        .valid_in(valid_8),
        .state_out(state_9), .valid_out(valid_9)
    );

    // Round 10 (Final)
    aes128_round_fpga round10 (
        .clk(clk), .rst_n(rst_n), .enable(enable),
        .is_final_round(1'b1),
        .state_in(state_9), .round_key(rk10),
        .valid_in(valid_9),
        .state_out(state_10), .valid_out(valid_10)
    );

    // Output
    assign ciphertext = state_10;
    assign valid_out = valid_10;

endmodule