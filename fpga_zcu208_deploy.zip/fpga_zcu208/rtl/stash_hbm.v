`include "oram_params.vh"
// stash_hbm.v -- DOMA's stash in HBM (on-package, trusted), organized like BOLT's eviction buffer:
// per-bucket lists of pointers into a pool of stash blocks. Same interface as the on-chip stash, plus
// open / ready / commit and an AXI master.
//
// HBM layout (addresses relative to the stash buffer):
//   lists  bucket b's list at b * LIST_BYTES: K entries of 64 bits {valid[63], slot[32 +: SLOT_W], index[0 +: PTR_W]}
//   pool   block i at POOL_BASE + i * BLOCK_BYTES
// Invariant: a stashed block is in the list of its TARGET bucket (the position map's bucket for it), and an
// access reads exactly that bucket. So each access OPENS two buckets at the position lookup:
//   b   the bucket read: its list holds the requested block if it is stashed, and every block waiting for b
//   bt  the new random target, where this access's block goes (one list when bt == b)
// Opening fetches both lists, then prefetches into on-chip staging the requested block (if stashed) and the
// lowest-indexed Z other entries of b's list. Reads are pipelined: both list reads go out back to back, and
// every prefetch goes out back to back as soon as b's list has landed; AXI returns them in order (one ID),
// and a tag queue routes each returning burst. The eviction loop takes candidates in that same order (lowest
// index first), so every eviction of the access (at most Z) finds its block staged, including blocks put
// into b's list during the access. `ready` rises when everything has landed. All stash operations of the
// access are then served on chip with the old stash's one-cycle read latency. `commit` (after the
// evictions) writes back both lists and the staged blocks written during the access; wr_quiet reports
// everything acknowledged. HBM reads are issued only while quiet. Boot zeroes every list (init_done).
// Free pool indices: an on-chip free stack plus a never-used counter.
// Errors (fail-stop): a full list or pool, an operation on an entry that is not where it must be, or data
// that was not staged.
module stash_hbm #(
    parameter N          = `ORAM_N,
    parameter B          = `ORAM_B,
    parameter Z          = `ORAM_Z,
    parameter BEATS      = `BEATS_PER_BLOCK,
    parameter K          = `ORAM_STASH_SLOTS,
    parameter P          = `ORAM_STASH_DEPTH,
    parameter BUCKET_W   = `BUCKET_ID_W,
    parameter SLOT_AW    = `SLOT_ADDR_W,
    parameter PTR_W      = `STASH_PTR_W,
    parameter BEAT_W     = `BEAT_CNT_W,
    parameter AXI_DW     = 256
) (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 init_go,                // start zeroing the lists (the controller's boot)
    output reg                  init_done,
    input  wire                 open_en,
    input  wire [BUCKET_W-1:0]  open_b,
    input  wire [BUCKET_W-1:0]  open_bt,
    input  wire [SLOT_AW-1:0]   open_slot,
    output wire                 ready,
    input  wire                 commit,
    input  wire [SLOT_AW-1:0]   cam_slot_addr,
    input  wire                 cam_slot_en,
    output wire                 cam_slot_hit,
    output wire [PTR_W-1:0]     cam_slot_idx,
    input  wire [BUCKET_W-1:0]  cam_bkt_target,
    input  wire                 cam_bkt_en,
    output wire                 cam_bkt_hit,
    output wire [PTR_W-1:0]     cam_bkt_idx,
    output wire [SLOT_AW-1:0]   cam_bkt_slot_addr,
    output wire                 cam_bkt_inhibit_busy,
    input  wire [SLOT_AW-1:0]   ins_slot_addr,
    input  wire [BUCKET_W-1:0]  ins_target_bucket,
    input  wire                 ins_en,
    output wire [PTR_W-1:0]     ins_idx,
    output wire                 ins_full,
    input  wire [PTR_W-1:0]     remap_idx,
    input  wire [BUCKET_W-1:0]  remap_new_bucket,
    input  wire                 remap_en,
    input  wire [PTR_W-1:0]     evict_idx,
    input  wire                 evict_en,
    input  wire [PTR_W-1:0]     dwr_entry,
    input  wire [BEAT_W-1:0]    dwr_beat,
    input  wire [AXI_DW-1:0]    dwr_data,
    input  wire                 dwr_en,
    input  wire [PTR_W-1:0]     drd_entry,
    input  wire [BEAT_W-1:0]    drd_beat,
    input  wire                 drd_en,
    output reg  [AXI_DW-1:0]    drd_data,
    output reg                  drd_valid,
    output wire [PTR_W:0]       occupancy,
    output wire                 wr_quiet,
    output reg                  err,
    output reg  [63:0]          m_araddr,
    output reg  [7:0]           m_arlen,
    output wire [2:0]           m_arsize,
    output wire [1:0]           m_arburst,
    output reg                  m_arvalid,
    input  wire                 m_arready,
    input  wire [AXI_DW-1:0]    m_rdata,
    input  wire                 m_rlast,
    input  wire                 m_rvalid,
    output wire                 m_rready,
    output reg  [63:0]          m_awaddr,
    output reg  [7:0]           m_awlen,
    output wire [2:0]           m_awsize,
    output wire [1:0]           m_awburst,
    output reg                  m_awvalid,
    input  wire                 m_awready,
    output reg  [AXI_DW-1:0]    m_wdata,
    output wire [AXI_DW/8-1:0]  m_wstrb,
    output wire                 m_wlast,
    output reg                  m_wvalid,
    input  wire                 m_wready,
    input  wire                 m_bvalid,
    output wire                 m_bready
);
    localparam SLOT_W      = SLOT_AW - 12;
    localparam KW          = $clog2(K);
    localparam EPB         = 4;                             // list entries per 256-bit beat
    localparam LBEATS      = K / EPB;                       // 16 beats per list
    localparam LB_W        = $clog2(LBEATS);
    localparam LIST_BYTES  = K * 8;
    localparam BLOCK_BYTES = BEATS * 32;
    localparam BAI         = (BEATS > 1) ? $clog2(BEATS) : 1;
    localparam STG         = (Z + 2 <= 8) ? 8 : 16;         // staging: requested + Z candidates + inserted
    localparam SW          = $clog2(STG);
    localparam [63:0] POOL_BASE = ((B * LIST_BYTES + 4095) / 4096) * 4096;
    function [63:0] e_pack; input v; input [SLOT_W-1:0] s; input [PTR_W-1:0] i;
        begin e_pack = 64'd0; e_pack[63] = v; e_pack[32 +: SLOT_W] = s; e_pack[0 +: PTR_W] = i; end endfunction
    localparam [BAI-1:0] BMASK = BEATS - 1;               // beat within the block (0 for 1-beat blocks)
    function [SW+BAI-1:0] gaddr; input [SW-1:0] g; input [BEAT_W-1:0] bt;
        begin gaddr = {g, bt[BAI-1:0] & BMASK}; end endfunction

    // ---------------- open state ----------------
    reg  [BUCKET_W-1:0] ob, obt;
    reg  [SLOT_W-1:0]   os;                                 // the requested slot
    reg                 same, opened, la_in, lt_in, pre_done, c_pend;
    reg  [K-1:0]        la_v, lt_v, la_stg;                 // valid bits; entries of b's list staged
    reg  [SLOT_W-1:0]   la_s [0:K-1];  reg [PTR_W-1:0] la_i [0:K-1];
    reg  [SLOT_W-1:0]   lt_s [0:K-1];  reg [PTR_W-1:0] lt_i [0:K-1];

    // ---------------- staging: 1 write port, 2 registered read ports ----------------
    // slot g's beats at {g, beat}: one beat bit even for 1-beat blocks, so the depth is STG << BAI
    // (STG * BEATS was half the needed depth at 32-byte blocks: slot 4 aliased slot 0)
    reg  [AXI_DW-1:0]   stg [0:(STG << BAI)-1];
    reg  [STG-1:0]      g_used, g_land, g_dirty;
    reg  [PTR_W-1:0]    g_idx [0:STG-1];

    // ---------------- searches (combinational, on chip) ----------------
    reg  cs_hit; reg [KW-1:0] cs_k;                         // cam_slot_addr in b's list
    reg  os_hit; reg [KW-1:0] os_k;                         // the opened (requested) slot in b's list
    reg  cb_hit; reg [KW-1:0] cb_k;                         // lowest valid entry of b's list
    reg  ra_hit; reg [KW-1:0] ra_k;  reg ea_hit; reg [KW-1:0] ea_k;
    reg  fa_ok;  reg [KW-1:0] fa_k;  reg ft_ok;  reg [KW-1:0] ft_k;
    reg  pc_hit; reg [KW-1:0] pc_k;                         // next entry to prefetch
    reg  fg_ok;  reg [SW-1:0] fg;                           // free staging slot
    reg  [SW-1:0] rd_g, wr_g; reg rd_gh, wr_gh;
    reg  [KW:0]  n_cand;                                    // candidates staged so far
    integer ki, gi;
    always @(*) begin
        cs_hit = 0; cs_k = 0; os_hit = 0; os_k = 0; cb_hit = 0; cb_k = 0; ra_hit = 0; ra_k = 0; ea_hit = 0; ea_k = 0;
        fa_ok = 0; fa_k = 0; ft_ok = 0; ft_k = 0; pc_hit = 0; pc_k = 0;
        for (ki = K - 1; ki >= 0; ki = ki - 1) begin
            if (la_v[ki] && la_s[ki] == cam_slot_addr[SLOT_W+11:12]) begin cs_hit = 1; cs_k = ki[KW-1:0]; end
            if (la_v[ki] && la_s[ki] == os)                           begin os_hit = 1; os_k = ki[KW-1:0]; end
            if (la_v[ki])                                             begin cb_hit = 1; cb_k = ki[KW-1:0]; end
            if (la_v[ki] && la_i[ki] == remap_idx)                    begin ra_hit = 1; ra_k = ki[KW-1:0]; end
            if (la_v[ki] && la_i[ki] == evict_idx)                    begin ea_hit = 1; ea_k = ki[KW-1:0]; end
            if (!la_v[ki])                                            begin fa_ok = 1;  fa_k = ki[KW-1:0]; end
            if (!lt_v[ki])                                            begin ft_ok = 1;  ft_k = ki[KW-1:0]; end
            if (la_v[ki] && !la_stg[ki] && la_s[ki] != os)           begin pc_hit = 1; pc_k = ki[KW-1:0]; end
        end
        fg_ok = 0; fg = 0; rd_g = 0; rd_gh = 0; wr_g = 0; wr_gh = 0;
        for (gi = STG - 1; gi >= 0; gi = gi - 1) begin
            if (!g_used[gi])                           begin fg_ok = 1; fg = gi[SW-1:0]; end
            if (g_used[gi] && g_idx[gi] == drd_entry)  begin rd_gh = 1; rd_g = gi[SW-1:0]; end
            if (g_used[gi] && g_idx[gi] == dwr_entry)  begin wr_gh = 1; wr_g = gi[SW-1:0]; end
        end
    end
    assign cam_slot_hit         = opened && cs_hit;
    assign cam_slot_idx         = la_i[cs_k];
    assign cam_bkt_hit          = opened && cb_hit && (cam_bkt_target == ob);
    assign cam_bkt_idx          = la_i[cb_k];
    assign cam_bkt_slot_addr    = {{(SLOT_AW-SLOT_W-12){1'b0}}, la_s[cb_k], 12'd0};
    assign cam_bkt_inhibit_busy = 1'b0;                     // an evicted entry leaves b's list at once

    // ---------------- free pool indices ----------------
    reg  [PTR_W-1:0]    fstk [0:P-1];                       // freed indices (on chip)
    reg  [PTR_W:0]      fsp, fresh, used_n;
    assign ins_full  = (fsp == 0 && fresh == P) || !(same ? fa_ok : ft_ok) || !fg_ok;
    assign ins_idx   = (fsp != 0) ? fstk[fsp - 1'b1] : fresh[PTR_W-1:0];
    assign occupancy = used_n;

    // ---------------- AXI jobs ----------------
    localparam [3:0] J_INIT = 4'd0, J_IDLE = 4'd1, J_RD = 4'd2, J_WLA = 4'd5, J_WLT = 4'd6, J_WSTG = 4'd7;
    // read tags (in issue order = return order): what each outstanding burst is
    localparam [1:0] T_LA = 2'd0, T_LT = 2'd1, T_PRE = 2'd2;
    reg  [1:0]          tq_k [0:15];
    reg  [SW-1:0]       tq_g [0:15];
    reg  [3:0]          tq_rp, tq_wp;
    reg  [4:0]          tq_n;
    reg                 iss_la, iss_lt;                     // list reads issued
    wire [1:0]          hk = tq_k[tq_rp];
    wire [SW-1:0]       hg = tq_g[tq_rp];
    reg  [3:0]          job;
    reg  [BUCKET_W:0]   init_b;
    reg                 init_req;                           // init_go seen
    reg  [7:0]          rbeat, wbeat, wlen;
    reg  [4:0]          outst;
    reg                 aw_sent, w_on;
    reg  [SW-1:0]       fill_g, wg;
    reg                 wg_go;                              // slot chosen; its first beat is read next cycle
    assign m_arsize = 3'b101; assign m_arburst = 2'b01; assign m_rready = 1'b1;
    assign m_awsize = 3'b101; assign m_awburst = 2'b01; assign m_bready = 1'b1;
    assign m_wstrb  = {(AXI_DW/8){1'b1}};
    assign m_wlast  = (wbeat == wlen);
    assign wr_quiet = init_done && (outst == 0) && !c_pend && (job == J_IDLE || job == J_RD) && !w_on && !m_awvalid;
    assign ready    = opened && la_in && lt_in && pre_done && !c_pend;

    // staging write port (prefetch fill or a data write; never in the same cycle) and two read ports
    wire              pre_beat = (job == J_RD) && m_rvalid && (hk == T_PRE);
    wire              s_we = pre_beat || (dwr_en && wr_gh);
    wire [SW+BAI-1:0] s_wa = pre_beat ? gaddr(hg, rbeat) : gaddr(wr_g, dwr_beat);
    wire [AXI_DW-1:0] s_wd = pre_beat ? m_rdata : dwr_data;
    wire              w_hs = m_wvalid && m_wready;
    wire [7:0]        wb_next = w_hs ? wbeat + 1'b1 : wbeat;                 // the beat to present next cycle
    reg  [AXI_DW-1:0] stg_wb;                                                // staging read for the write-back
    always @(posedge clk) begin
        if (s_we) stg[s_wa] <= s_wd;
        drd_data <= stg[gaddr(rd_g, drd_beat)];
        stg_wb   <= stg[gaddr(wg, wb_next)];
    end
    // list beats for the write-back
    reg  [AXI_DW-1:0] lbeat;
    integer e;
    always @(*) begin
        lbeat = {AXI_DW{1'b0}};
        for (e = 0; e < EPB; e = e + 1)
            if (job == J_WLA) lbeat[64*e +: 64] = e_pack(la_v[wbeat*EPB+e], la_s[wbeat*EPB+e], la_i[wbeat*EPB+e]);
            else              lbeat[64*e +: 64] = e_pack(lt_v[wbeat*EPB+e], lt_s[wbeat*EPB+e], lt_i[wbeat*EPB+e]);
    end
    always @(*) m_wdata = (job == J_WSTG) ? stg_wb : (job == J_INIT) ? {AXI_DW{1'b0}} : lbeat;

    // start a write burst
    task wstart; input [63:0] a; input [7:0] len; begin
        m_awaddr <= a; m_awlen <= len; wlen <= len; wbeat <= 0; m_awvalid <= 1'b1; aw_sent <= 1'b0; w_on <= 1'b1; m_wvalid <= 1'b1;
    end endtask

    always @(posedge clk) begin
        if (ins_en && !ins_full && fsp == 0) ;              // (fresh index: nothing to pop)
        if (evict_en && ea_hit) fstk[fsp - ((ins_en && !ins_full && fsp != 0) ? 1 : 0)] <= evict_idx;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            init_done <= 1'b0; init_b <= 0; init_req <= 1'b0; job <= J_INIT; rbeat <= 0; wbeat <= 0; wlen <= 0; outst <= 0;
            aw_sent <= 1'b0; w_on <= 1'b0; m_arvalid <= 1'b0; m_awvalid <= 1'b0; m_wvalid <= 1'b0;
            m_araddr <= 0; m_arlen <= 0; m_awaddr <= 0; m_awlen <= 0;
            ob <= 0; obt <= 0; os <= 0; same <= 1'b0; opened <= 1'b0; la_in <= 1'b0; lt_in <= 1'b0; pre_done <= 1'b0;
            c_pend <= 1'b0; la_v <= 0; lt_v <= 0; la_stg <= 0; g_used <= 0; g_land <= 0; g_dirty <= 0;
            fill_g <= 0; wg <= 0; wg_go <= 1'b0; n_cand <= 0; tq_rp <= 0; tq_wp <= 0; tq_n <= 0; iss_la <= 1'b0; iss_lt <= 1'b0; fsp <= 0; fresh <= 0; used_n <= 0; drd_valid <= 1'b0; err <= 1'b0;
        end else begin
            outst <= outst + ((m_awvalid && m_awready) ? 5'd1 : 5'd0) - (m_bvalid ? 5'd1 : 5'd0);
            // ---- data accesses: staging only ----
            drd_valid <= drd_en && rd_gh && g_land[rd_g];
            if (drd_en && !(rd_gh && g_land[rd_g])) err <= 1'b1;
            if (dwr_en) begin if (wr_gh) g_dirty[wr_g] <= 1'b1; else err <= 1'b1; end
            // ---- list operations (one per cycle from the controller) ----
            if (ins_en) begin
                if (ins_full || !opened) err <= 1'b1;
                else begin
                    if (fsp != 0) fsp <= fsp - 1'b1; else fresh <= fresh + 1'b1;
                    used_n <= used_n + 1'b1;
                    g_used[fg] <= 1'b1; g_land[fg] <= 1'b1; g_dirty[fg] <= 1'b0; g_idx[fg] <= ins_idx;
                    if (same) begin la_v[fa_k] <= 1'b1; la_s[fa_k] <= ins_slot_addr[SLOT_W+11:12]; la_i[fa_k] <= ins_idx; la_stg[fa_k] <= 1'b1; end
                    else      begin lt_v[ft_k] <= 1'b1; lt_s[ft_k] <= ins_slot_addr[SLOT_W+11:12]; lt_i[ft_k] <= ins_idx; end
                end
            end
            if (remap_en) begin                             // b -> bt: the block stays in the pool and in staging
                if (!ra_hit) err <= 1'b1;
                else if (!same) begin
                    if (!ft_ok) err <= 1'b1;
                    else begin la_v[ra_k] <= 1'b0; lt_v[ft_k] <= 1'b1; lt_s[ft_k] <= la_s[ra_k]; lt_i[ft_k] <= la_i[ra_k]; end
                end
            end
            if (evict_en) begin                             // leaves b's list and the pool (its staged copy stays)
                if (!ea_hit) err <= 1'b1;
                else begin
                    la_v[ea_k] <= 1'b0; used_n <= used_n - 1'b1 + ((ins_en && !ins_full && opened) ? 1'b1 : 1'b0);
                    fsp <= fsp + 1'b1 - ((ins_en && !ins_full && opened && fsp != 0) ? 1'b1 : 1'b0);
                end
            end
            // ---- open an access ----
            if (open_en) begin
                if (!init_done || c_pend || job != J_IDLE) err <= 1'b1;
                ob <= open_b; obt <= open_bt; os <= open_slot[SLOT_W+11:12]; same <= (open_b == open_bt);
                opened <= 1'b1; la_in <= 1'b0; lt_in <= 1'b0; pre_done <= 1'b0; la_v <= 0; lt_v <= 0; la_stg <= 0;
                g_used <= 0; g_land <= 0; g_dirty <= 0; n_cand <= 0; iss_la <= 1'b0; iss_lt <= 1'b0;
            end
            if (init_go) init_req <= 1'b1;
            if (commit && opened) c_pend <= 1'b1;           // (the boot format's re-encryption has no open access)
            // ---- the AXI job engine ----
            if (m_awvalid && m_awready) begin m_awvalid <= 1'b0; aw_sent <= 1'b1; end
            if (w_hs) begin
                // back to beat 0 at the end of a burst: the write-back's registered staging read for the
                // next burst then starts at beat 0 (a stale count sent another beat's data as beat 0)
                if (wbeat == wlen) begin m_wvalid <= 1'b0; w_on <= 1'b0; wbeat <= 0; end
                else wbeat <= wbeat + 1'b1;
            end
            case (job)
                J_INIT: if (init_req && !w_on && !m_awvalid) begin         // boot: zero every list
                    if (init_b == B) begin if (outst == 0) begin init_done <= 1'b1; job <= J_IDLE; end end
                    else begin wstart(init_b * LIST_BYTES, LBEATS - 1); init_b <= init_b + 1'b1; end
                end
                J_IDLE: begin
                    if (c_pend && !w_on && !m_awvalid) begin wstart(ob * LIST_BYTES, LBEATS - 1); job <= J_WLA; end
                    else if (opened && !la_in && !iss_la && !open_en && outst == 0 && !m_arvalid) begin
                        job <= J_RD; rbeat <= 0;                       // every earlier write is acknowledged
                    end
                end
                J_RD: begin                                                // pipelined reads
                    // issue: list b, list bt, then (once b's list is in) the requested block and Z candidates
                    if (m_arvalid && m_arready) m_arvalid <= 1'b0;
                    if (!m_arvalid || m_arready) begin : issue
                        reg go; reg [1:0] k; reg [SW-1:0] g; go = 0; k = T_LA; g = 0;
                        if (!iss_la) begin
                            go = 1; k = T_LA; iss_la <= 1'b1; m_araddr <= ob * LIST_BYTES; m_arlen <= LBEATS - 1;
                        end else if (!iss_lt && !same) begin
                            go = 1; k = T_LT; iss_lt <= 1'b1; m_araddr <= obt * LIST_BYTES; m_arlen <= LBEATS - 1;
                        end else if (la_in && os_hit && !la_stg[os_k] && fg_ok) begin
                            go = 1; k = T_PRE; g = fg; la_stg[os_k] <= 1'b1; g_used[fg] <= 1'b1; g_idx[fg] <= la_i[os_k];
                            m_araddr <= POOL_BASE + la_i[os_k] * BLOCK_BYTES; m_arlen <= BEATS - 1;
                        end else if (la_in && pc_hit && n_cand < Z && fg_ok) begin
                            go = 1; k = T_PRE; g = fg; la_stg[pc_k] <= 1'b1; g_used[fg] <= 1'b1; g_idx[fg] <= la_i[pc_k];
                            n_cand <= n_cand + 1'b1; m_araddr <= POOL_BASE + la_i[pc_k] * BLOCK_BYTES; m_arlen <= BEATS - 1;
                        end
                        if (go) begin m_arvalid <= 1'b1; tq_k[tq_wp] <= k; tq_g[tq_wp] <= g; tq_wp <= tq_wp + 1'b1; end
                        if (go && !(m_rvalid && m_rlast)) tq_n <= tq_n + 1'b1;
                        else if (!go && m_rvalid && m_rlast) tq_n <= tq_n - 1'b1;
                        // done: everything selected has been issued and has landed
                        if (!go && la_in && (same || lt_in) && tq_n == 0 && !m_arvalid && !(m_rvalid)) begin
                            pre_done <= 1'b1; lt_in <= 1'b1; job <= J_IDLE;
                        end
                    end else if (m_rvalid && m_rlast) tq_n <= tq_n - 1'b1;
                    // land: route the returning beat by the head tag
                    if (m_rvalid) begin
                        if (hk == T_LA || hk == T_LT)
                            for (e = 0; e < EPB; e = e + 1) begin
                                if (hk == T_LA) begin
                                    la_v[rbeat*EPB+e] <= m_rdata[64*e+63]; la_s[rbeat*EPB+e] <= m_rdata[64*e+32 +: SLOT_W];
                                    la_i[rbeat*EPB+e] <= m_rdata[64*e +: PTR_W];
                                end else begin
                                    lt_v[rbeat*EPB+e] <= m_rdata[64*e+63]; lt_s[rbeat*EPB+e] <= m_rdata[64*e+32 +: SLOT_W];
                                    lt_i[rbeat*EPB+e] <= m_rdata[64*e +: PTR_W];
                                end
                            end
                        rbeat <= rbeat + 1'b1;
                        if (m_rlast) begin
                            rbeat <= 0; tq_rp <= tq_rp + 1'b1;
                            if (hk == T_LA) la_in <= 1'b1;
                            if (hk == T_LT) lt_in <= 1'b1;
                            if (hk == T_PRE) g_land[hg] <= 1'b1;
                        end
                    end
                end
                J_WLA: if (!w_on && !m_awvalid) begin
                    if (!same) begin wstart(obt * LIST_BYTES, LBEATS - 1); job <= J_WLT; end
                    else job <= J_WSTG;
                end
                J_WLT: if (!w_on && !m_awvalid) job <= J_WSTG;
                J_WSTG: if (wg_go) begin                            // the slot's first beat is now in stg_wb
                    wg_go <= 1'b0; wstart(POOL_BASE + g_idx[wg] * BLOCK_BYTES, BEATS - 1);
                end else if (!w_on && !m_awvalid) begin : nd       // dirty staged blocks back to the pool
                    reg f; reg [SW-1:0] g; f = 0; g = 0;
                    for (gi = STG - 1; gi >= 0; gi = gi - 1) if (g_used[gi] && g_dirty[gi]) begin f = 1; g = gi[SW-1:0]; end
                    // choose the slot this cycle and start its burst next cycle: the write-back's staging read
                    // is registered, so it must see the new slot before the first beat goes out
                    if (f) begin wg <= g; g_dirty[g] <= 1'b0; wg_go <= 1'b1; end
                    else begin c_pend <= 1'b0; opened <= 1'b0; job <= J_IDLE; end
                end
                default: job <= J_IDLE;
            endcase
        end
    end
endmodule
