`include "oram_params.vh"
// stash_hbm.v -- DOMA's stash in HBM (on-package, trusted), organized like BOLT's eviction buffer:
// per-bucket lists of pointers into a pool of stash blocks. Same interface as the on-chip stash, plus
// open / ready / commit and an AXI master.
//
// HBM layout (addresses relative to the stash buffer):
//   lists  bucket b's list at b * LIST_BYTES: K entries of 64 bits {valid[63], slot[32 +: SLOT_W], index[0 +: PTR_W]}
//   pool   block i at POOL_BASE + i * BLOCK_BYTES
// Invariant: a stashed block is in the list of its TARGET bucket (the position map's bucket for it), and an
// access reads exactly that bucket. So each access OPENS two buckets at the position lookup:
//   b   the bucket read: its list holds the requested block if it is stashed, and every block waiting for b
//   bt  the new random target, where this access's block goes (one list when bt == b)
// Opening fetches both lists, then prefetches into on-chip staging the requested block (if stashed) and the
// lowest-indexed Z other entries of b's list. Reads are pipelined: both list reads go out back to back, and
// every prefetch goes out back to back as soon as b's list has landed; AXI returns them in order (one ID),
// and a tag queue routes each returning burst. The eviction loop takes candidates in that same order (lowest
// index first), so every eviction of the access (at most Z) finds its block staged, including blocks put
// into b's list during the access. `ready` rises when everything has landed. All stash operations of the
// access are then served on chip with the old stash's one-cycle read latency. `commit` (after the
// evictions) writes back both lists and the staged blocks written during the access; wr_quiet reports
// everything acknowledged. HBM reads are issued only while quiet. Boot zeroes every list (init_done).
// Free pool indices: an on-chip free stack plus a never-used counter.
// Errors (fail-stop): a full list or pool, an operation on an entry that is not where it must be, or data
// that was not staged.
module stash_hbm #(
    parameter N          = `ORAM_N,
    parameter B          = `ORAM_B,
    parameter Z          = `ORAM_Z,
    parameter BEATS      = `BEATS_PER_BLOCK,
    parameter K          = `ORAM_STASH_SLOTS,
    parameter P          = `ORAM_STASH_DEPTH,
    parameter BUCKET_W   = `BUCKET_ID_W,
    parameter SLOT_AW    = `SLOT_ADDR_W,
    parameter PTR_W      = `STASH_PTR_W,
    parameter BEAT_W     = `BEAT_CNT_W,
    parameter AXI_DW     = 256
) (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 init_go,                // start zeroing the lists (the controller's boot)
    output reg                  init_done,
    input  wire                 open_en,
    input  wire [BUCKET_W-1:0]  open_b,
    input  wire [BUCKET_W-1:0]  open_bt,
    input  wire [SLOT_AW-1:0]   open_slot,
    output wire                 ready,
    input  wire                 commit,
    input  wire [SLOT_AW-1:0]   cam_slot_addr,
    input  wire                 cam_slot_en,
    output wire                 cam_slot_hit,
    output wire [PTR_W-1:0]     cam_slot_idx,
    input  wire [BUCKET_W-1:0]  cam_bkt_target,
    input  wire                 cam_bkt_en,
    output wire                 cam_bkt_hit,
    output wire [PTR_W-1:0]     cam_bkt_idx,
    output wire [SLOT_AW-1:0]   cam_bkt_slot_addr,
    output wire                 cam_bkt_inhibit_busy,
    input  wire [SLOT_AW-1:0]   ins_slot_addr,
    input  wire [BUCKET_W-1:0]  ins_target_bucket,
    input  wire                 ins_en,
    output wire [PTR_W-1:0]     ins_idx,
    output wire                 ins_full,
    input  wire [PTR_W-1:0]     remap_idx,
    input  wire [BUCKET_W-1:0]  remap_new_bucket,
    input  wire                 remap_en,
    input  wire [PTR_W-1:0]     evict_idx,
    input  wire                 evict_en,
    input  wire [PTR_W-1:0]     dwr_entry,
    input  wire [BEAT_W-1:0]    dwr_beat,
    input  wire [AXI_DW-1:0]    dwr_data,
    input  wire                 dwr_en,
    input  wire [PTR_W-1:0]     drd_entry,
    input  wire [BEAT_W-1:0]    drd_beat,
    input  wire                 drd_en,
    output reg  [AXI_DW-1:0]    drd_data,
    output reg                  drd_valid,
    output wire [PTR_W:0]       occupancy,
    output wire                 wr_quiet,
    output reg                  err,
    output reg  [63:0]          m_araddr,
    output reg  [7:0]           m_arlen,
    output wire [2:0]           m_arsize,
    output wire [1:0]           m_arburst,
    output reg                  m_arvalid,
    input  wire                 m_arready,
    input  wire [AXI_DW-1:0]    m_rdata,
    input  wire                 m_rlast,
    input  wire                 m_rvalid,
    output wire                 m_rready,
    output reg  [63:0]          m_awaddr,
    output reg  [7:0]           m_awlen,
    output wire [2:0]           m_awsize,
    output wire [1:0]           m_awburst,
    output reg                  m_awvalid,
    input  wire                 m_awready,
    output reg  [AXI_DW-1:0]    m_wdata,
    output wire [AXI_DW/8-1:0]  m_wstrb,
    output wire                 m_wlast,
    output reg                  m_wvalid,
    input  wire                 m_wready,
    input  wire                 m_bvalid,
    output wire                 m_bready
);
    localparam SLOT_W      = SLOT_AW - 12;
    localparam KW          = $clog2(K);
    localparam EPB         = 4;                             // list entries per 256-bit beat
    localparam LBEATS      = K / EPB;                       // 16 beats per list
    localparam LB_W        = $clog2(LBEATS);
    localparam LIST_BYTES  = K * 8;
    localparam BLOCK_BYTES = BEATS * 32;
    localparam BAI         = (BEATS > 1) ? $clog2(BEATS) : 1;
    localparam STG         = (Z + 2 <= 8) ? 8 : 16;         // staging: requested + Z candidates + inserted
    localparam SW          = $clog2(STG);
    localparam [BAI-1:0] BMASK = BEATS - 1;
    localparam [63:0] POOL_BASE = ((B * LIST_BYTES + 4095) / 4096) * 4096;
    function [63:0] e_pack; input v; input [SLOT_W-1:0] sl; input [PTR_W-1:0] ix;
        begin e_pack = 64'd0; e_pack[63] = v; e_pack[32 +: SLOT_W] = sl; e_pack[0 +: PTR_W] = ix; end endfunction
    // TIMING: no 64-entry search feeds a decision or a write in the same cycle.
    // * The index handed to the controller is a HANDLE: the block's staging slot (the controller never
    //   keeps a stash index beyond the access). Data reads/writes address staging by handle; remap and
    //   evict find the list entry from the handle's recorded list position. No search on these paths.
    // * The slot search, the first waiting block and the first free list entries are REGISTERED from
    //   stable lists. After any change to b's list the candidate output is busy for one cycle
    //   (cam_bkt_inhibit_busy, which the eviction loop already honors); `ready` follows the last list
    //   change by two cycles, so the registered results are current when S_SCAN reads them.
    // * Prefetch selection is registered (select one cycle, issue the next); list write-back data is
    //   registered, like the staging write-back.

    // ---------------- open state and the two lists ----------------
    reg  [BUCKET_W-1:0] ob, obt;
    reg  [SLOT_W-1:0]   os;
    reg                 same, opened, la_in, lt_in, pre_done, c_pend;
    reg  [K-1:0]        la_v, lt_v, la_stg;
    reg  [SW-1:0]       la_g [0:K-1];                         // staging slot of each entry of b's list
    // AREA/ROUTING: the entry fields {slot, pool index} live in LUT-RAM, one memory per entry position in a
    // 256-bit beat (entry k at column k % EPB, row k / EPB). Landing a list beat writes one row of all four
    // columns, the write-back reads one row, and every other access touches one column through a registered
    // index. (As registers, with several write sources and 64-way read muxes, these lists added ~5,800
    // densely connected LUTs and were part of a level-6 routing congestion.) Only valid/staged/slot bits stay
    // in registers. The requested slot is found while b's list lands (4 compares per beat).
    localparam FW = SLOT_W + PTR_W;
    reg                 os_hit;  reg [KW-1:0] os_k;           // the requested slot's entry (found at landing)
    reg  [KW-1:0]       cb_k_q;                               // first waiting block's position (registered)
    wire [FW-1:0]       la_cb [0:EPB-1], la_sel [0:EPB-1], la_rm [0:EPB-1], la_wb [0:EPB-1], lt_wb [0:EPB-1];

    // ---------------- staging (slot = handle) ----------------
    reg  [AXI_DW-1:0]   stg [0:(STG << BAI)-1];
    reg  [STG-1:0]      g_used, g_land, g_dirty, g_lt;      // g_lt: the block's entry is in bt's list
    reg  [PTR_W-1:0]    g_idx [0:STG-1];                    // its pool index
    reg  [KW-1:0]       g_k   [0:STG-1];                    // its list position
    function [SW+BAI-1:0] gaddr; input [SW-1:0] g; input [BEAT_W-1:0] bt;
        begin gaddr = {g, bt[BAI-1:0] & BMASK}; end endfunction

    // ---------------- registered searches ----------------
    reg           cs_hit_q;  reg [SW-1:0] cs_h_q;           // requested slot: found, its handle
    reg           cb_hit_q;  reg [SW-1:0] cb_h_q;           // first waiting block
    reg           fa_ok_q;   reg [KW-1:0] fa_k_q;           // first free entry of b's list
    reg           ft_ok_q;   reg [KW-1:0] ft_k_q;           // first free entry of bt's list
    reg           la_chg, la_chg_q;                         // b's list changes this cycle / changed last cycle
    reg  cs_hit; reg [KW-1:0] cs_k; reg cb_hit; reg [KW-1:0] cb_k; reg fa_ok; reg [KW-1:0] fa_k; reg ft_ok; reg [KW-1:0] ft_k;
    reg  ps_hit; reg [KW-1:0] ps_k; reg pc_hit; reg [KW-1:0] pc_k; reg fg_ok; reg [SW-1:0] fg;
    integer ki, gi;
    always @(*) begin
        cs_hit = 0; cs_k = 0; cb_hit = 0; cb_k = 0; fa_ok = 0; fa_k = 0; ft_ok = 0; ft_k = 0;
        ps_hit = 0; ps_k = 0; pc_hit = 0; pc_k = 0;
        for (ki = K - 1; ki >= 0; ki = ki - 1) begin
            if (la_v[ki])                             begin cb_hit = 1; cb_k = ki[KW-1:0]; end
            if (!la_v[ki])                            begin fa_ok = 1;  fa_k = ki[KW-1:0]; end
            if (!lt_v[ki])                            begin ft_ok = 1;  ft_k = ki[KW-1:0]; end
            if (la_v[ki] && !la_stg[ki] && !(os_hit && os_k == ki[KW-1:0])) begin pc_hit = 1; pc_k = ki[KW-1:0]; end
        end
        cs_hit = os_hit && la_v[os_k]; cs_k = os_k;                       // requested slot
        ps_hit = os_hit && la_v[os_k] && !la_stg[os_k]; ps_k = os_k;      // requested, to stage
        fg_ok = 0; fg = 0;
        for (gi = STG - 1; gi >= 0; gi = gi - 1) if (!g_used[gi]) begin fg_ok = 1; fg = gi[SW-1:0]; end
    end
    assign cam_slot_hit         = opened && cs_hit_q;
    assign cam_slot_idx         = {{(PTR_W-SW){1'b0}}, cs_h_q};
    assign cam_bkt_hit          = opened && cb_hit_q && (cam_bkt_target == ob);
    assign cam_bkt_idx          = {{(PTR_W-SW){1'b0}}, cb_h_q};
    wire [FW-1:0]       cb_f = la_cb[cb_k_q[1:0]];
    assign cam_bkt_slot_addr    = {{(SLOT_AW-SLOT_W-12){1'b0}}, cb_f[FW-1:PTR_W], 12'd0};
    // busy in exactly the cycle after a change to b's list: the registered candidate is stale then
    // (la_chg is set by the change itself; a registered copy would be one cycle late and let the
    // controller evict the same block twice)
    assign cam_bkt_inhibit_busy = la_chg;

    // ---------------- free pool indices ----------------
    reg  [PTR_W-1:0]    fstk [0:P-1];
    reg  [PTR_W:0]      fsp, fresh, used_n;
    // the next free pool index, computed one cycle ahead (an insert never reads the free stack in the
    // same cycle). It is stale only in the cycle right after the free stack changed (fchg); an insert
    // then is an error. In DOMA's flow the one insert of an access comes long after the last change.
    reg  [PTR_W-1:0]    new_idx;
    reg                 fchg;
    assign ins_full  = (fsp == 0 && fresh == P) || !(same ? fa_ok_q : ft_ok_q) || !fg_ok;
    assign ins_idx   = {{(PTR_W-SW){1'b0}}, fg};
    assign occupancy = used_n;
    wire [SW-1:0]       rh = remap_idx[SW-1:0], eh = evict_idx[SW-1:0], dh = drd_entry[SW-1:0], wh = dwr_entry[SW-1:0];

    // ---------------- AXI jobs ----------------
    localparam [3:0] J_INIT = 4'd0, J_IDLE = 4'd1, J_RD = 4'd2, J_WLA = 4'd5, J_WLT = 4'd6, J_WSTG = 4'd7;
    localparam [1:0] T_LA = 2'd0, T_LT = 2'd1, T_PRE = 2'd2;
    reg  [3:0]          job;
    reg  [BUCKET_W:0]   init_b;
    reg                 init_req;
    reg  [7:0]          rbeat, wbeat, wlen;
    reg  [4:0]          outst;
    reg                 aw_sent, w_on;
    reg  [SW-1:0]       wg;
    reg                 wg_go;
    reg  [KW:0]         n_cand;
    reg  [1:0]          tq_k [0:15];
    reg  [SW-1:0]       tq_g [0:15];
    reg  [3:0]          tq_rp, tq_wp;
    reg  [4:0]          tq_n;
    reg                 iss_la, iss_lt, la_in2;
    reg                 sel_go; reg [KW-1:0] sel_k; reg sel_req;            // registered prefetch selection
    reg  [1:0]          rdy_q;
    wire [1:0]          hk = tq_k[tq_rp];
    wire [SW-1:0]       hg = tq_g[tq_rp];
    assign m_arsize = 3'b101; assign m_arburst = 2'b01; assign m_rready = 1'b1;
    assign m_awsize = 3'b101; assign m_awburst = 2'b01; assign m_bready = 1'b1;
    assign m_wstrb  = {(AXI_DW/8){1'b1}};
    assign m_wlast  = (wbeat == wlen);
    assign wr_quiet = init_done && (outst == 0) && !c_pend && (job == J_IDLE || job == J_RD) && !w_on && !m_awvalid;
    wire   rdy_now  = opened && la_in && lt_in && pre_done && !c_pend;
    assign ready    = rdy_now && rdy_q[1];

    // staging: one write port (prefetch fill or a data write; never the same cycle), two registered reads
    wire              pre_beat = (job == J_RD) && m_rvalid && (hk == T_PRE);
    wire              s_we = pre_beat || dwr_en;
    wire [SW+BAI-1:0] s_wa = pre_beat ? gaddr(hg, rbeat) : gaddr(wh, dwr_beat);
    wire [AXI_DW-1:0] s_wd = pre_beat ? m_rdata : dwr_data;
    wire              w_hs = m_wvalid && m_wready;
    wire [7:0]        wb_next = w_hs ? wbeat + 1'b1 : wbeat;
    reg  [AXI_DW-1:0] stg_wb, lba_q, lbt_q;
    integer e;
    always @(posedge clk) begin
        if (s_we) stg[s_wa] <= s_wd;
        drd_data <= stg[gaddr(dh, drd_beat)];
        stg_wb   <= stg[gaddr(wg, wb_next)];
        for (e = 0; e < EPB; e = e + 1) begin                // list beats for the write-back, registered
            lba_q[64*e +: 64] <= e_pack(la_v[wb_next[LB_W-1:0]*EPB+e], la_wb[e][FW-1:PTR_W], la_wb[e][PTR_W-1:0]);
            lbt_q[64*e +: 64] <= e_pack(lt_v[wb_next[LB_W-1:0]*EPB+e], lt_wb[e][FW-1:PTR_W], lt_wb[e][PTR_W-1:0]);
        end
    end
    always @(*) m_wdata = (job == J_WSTG) ? stg_wb : (job == J_WLA) ? lba_q : (job == J_WLT) ? lbt_q : {AXI_DW{1'b0}};

    // registered searches (updated every cycle from the current lists)
    integer kk;
    always @(posedge clk) begin
        cs_hit_q <= cs_hit;  cs_h_q <= la_g[cs_k];
        cb_hit_q <= cb_hit;  cb_h_q <= la_g[cb_k];  cb_k_q <= cb_k;
        fa_ok_q  <= fa_ok;   fa_k_q <= fa_k;  ft_ok_q <= ft_ok;  ft_k_q <= ft_k;
        la_chg_q <= la_chg;
    end
    always @(posedge clk) if (evict_en && g_used[eh] && !g_lt[eh] && opened) fstk[fsp] <= g_idx[eh];
    always @(posedge clk) new_idx <= (fsp != 0) ? fstk[fsp - 1'b1] : fresh[PTR_W-1:0];

    // ---------------- list fields in LUT-RAM columns ----------------
    wire              ins_ok  = ins_en && !(ins_full || !opened || fchg);          // the insert succeeds
    wire              rm_ok   = remap_en && g_used[rh] && !g_lt[rh] && !same && ft_ok_q;
    wire              la_land = (job == J_RD) && m_rvalid && (hk == T_LA);
    wire              lt_land = (job == J_RD) && m_rvalid && (hk == T_LT);
    wire [FW-1:0]     ins_f   = {ins_slot_addr[SLOT_W+11:12], new_idx};
    wire [FW-1:0]     rm_f    = la_rm[g_k[rh][1:0]];
    wire [FW-1:0]     sel_f   = la_sel[sel_k[1:0]];
    wire [PTR_W-1:0]  sel_i   = sel_f[PTR_W-1:0];
    genvar gc;
    generate for (gc = 0; gc < EPB; gc = gc + 1) begin : lcol
        (* ram_style = "distributed" *) reg [FW-1:0] am [0:LBEATS-1];       // b's list, column gc
        (* ram_style = "distributed" *) reg [FW-1:0] tm [0:LBEATS-1];       // bt's list, column gc
        wire [FW-1:0] land_f = {m_rdata[64*gc+32 +: SLOT_W], m_rdata[64*gc +: PTR_W]};
        always @(posedge clk) begin                                         // one write port each
            if (la_land)                                         am[rbeat[LB_W-1:0]] <= land_f;
            else if (ins_ok && same && fa_k_q[1:0] == gc)        am[fa_k_q[KW-1:2]]  <= ins_f;
            if (lt_land)                                         tm[rbeat[LB_W-1:0]] <= land_f;
            else if (ins_ok && !same && ft_k_q[1:0] == gc)       tm[ft_k_q[KW-1:2]]  <= ins_f;
            else if (rm_ok && ft_k_q[1:0] == gc)                 tm[ft_k_q[KW-1:2]]  <= rm_f;
        end
        assign la_cb[gc]  = am[cb_k_q[KW-1:2]];
        assign la_sel[gc] = am[sel_k[KW-1:2]];
        assign la_rm[gc]  = am[g_k[rh][KW-1:2]];
        assign la_wb[gc]  = am[wb_next[LB_W-1:0]];
        assign lt_wb[gc]  = tm[wb_next[LB_W-1:0]];
    end endgenerate
    // read-only views of the slot fields, for the unit test's list-content check (unused in hardware)
    wire [SLOT_W-1:0] la_s [0:K-1];
    wire [SLOT_W-1:0] lt_s [0:K-1];
    genvar gk;
    generate for (gk = 0; gk < K; gk = gk + 1) begin : lview
        assign la_s[gk] = lcol[gk % EPB].am[gk / EPB][FW-1:PTR_W];
        assign lt_s[gk] = lcol[gk % EPB].tm[gk / EPB][FW-1:PTR_W];
    end endgenerate

    task wstart; input [63:0] a; input [7:0] len; begin
        m_awaddr <= a; m_awlen <= len; wlen <= len; wbeat <= 0; m_awvalid <= 1'b1; aw_sent <= 1'b0; w_on <= 1'b1; m_wvalid <= 1'b1;
    end endtask

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            init_done <= 1'b0; init_b <= 0; init_req <= 1'b0; job <= J_INIT; rbeat <= 0; wbeat <= 0; wlen <= 0; outst <= 0;
            aw_sent <= 1'b0; w_on <= 1'b0; m_arvalid <= 1'b0; m_awvalid <= 1'b0; m_wvalid <= 1'b0;
            m_araddr <= 0; m_arlen <= 0; m_awaddr <= 0; m_awlen <= 0;
            ob <= 0; obt <= 0; os <= 0; same <= 1'b0; opened <= 1'b0; la_in <= 1'b0; lt_in <= 1'b0; pre_done <= 1'b0; c_pend <= 1'b0;
            la_v <= 0; lt_v <= 0; la_stg <= 0; g_used <= 0; g_land <= 0; g_dirty <= 0; g_lt <= 0;
            wg <= 0; wg_go <= 1'b0; n_cand <= 0; tq_rp <= 0; tq_wp <= 0; tq_n <= 0; iss_la <= 1'b0; iss_lt <= 1'b0; la_in2 <= 1'b0;
            sel_go <= 1'b0; sel_k <= 0; sel_req <= 1'b0; rdy_q <= 0; la_chg <= 1'b0; os_hit <= 1'b0; os_k <= 0;
            fsp <= 0; fresh <= 0; used_n <= 0; drd_valid <= 1'b0; err <= 1'b0; fchg <= 1'b0;
        end else begin
            la_chg <= 1'b0;                                  // (registered into la_chg_q next edge)
            fchg   <= (ins_en && !ins_full && opened) || (evict_en && g_used[eh] && !g_lt[eh] && opened);
            rdy_q  <= {rdy_q[0], rdy_now};
            la_in2 <= la_in;
            outst  <= outst + ((m_awvalid && m_awready) ? 5'd1 : 5'd0) - (m_bvalid ? 5'd1 : 5'd0);
            // ---- data accesses: staging by handle ----
            drd_valid <= drd_en && g_used[dh] && g_land[dh];
            if (drd_en && !(g_used[dh] && g_land[dh])) err <= 1'b1;
            if (dwr_en) begin if (g_used[wh]) g_dirty[wh] <= 1'b1; else err <= 1'b1; end
            // ---- list operations (one per cycle) ----
            if (ins_en) begin
                if (ins_full || !opened || fchg) err <= 1'b1;    // fchg: new_idx not yet current
                else begin
                    if (fsp != 0) fsp <= fsp - 1'b1; else fresh <= fresh + 1'b1;
                    used_n <= used_n + 1'b1;
                    g_used[fg] <= 1'b1; g_land[fg] <= 1'b1; g_dirty[fg] <= 1'b0; g_idx[fg] <= new_idx; g_lt[fg] <= !same;
                    if (same) begin la_v[fa_k_q] <= 1'b1; la_g[fa_k_q] <= fg; la_stg[fa_k_q] <= 1'b1; g_k[fg] <= fa_k_q; la_chg <= 1'b1; end
                    else      begin lt_v[ft_k_q] <= 1'b1; g_k[fg] <= ft_k_q; end   // fields: LUT-RAM columns
                end
            end
            if (remap_en && ins_en) err <= 1'b1;             // never both in one cycle (one column write port)
            if (remap_en) begin                              // b -> bt (a block found in b's list)
                if (!g_used[rh] || g_lt[rh]) err <= 1'b1;
                else if (!same) begin
                    if (!ft_ok_q) err <= 1'b1;
                    else begin
                        la_v[g_k[rh]] <= 1'b0; la_chg <= 1'b1;
                        lt_v[ft_k_q] <= 1'b1;                    // fields copied by the LUT-RAM columns
                        g_lt[rh] <= 1'b1; g_k[rh] <= ft_k_q;
                    end
                end
            end
            if (evict_en) begin                              // leaves b's list and the pool; its staged copy stays
                if (!g_used[eh] || g_lt[eh] || !opened) err <= 1'b1;
                else begin
                    la_v[g_k[eh]] <= 1'b0; la_chg <= 1'b1; used_n <= used_n - 1'b1; fsp <= fsp + 1'b1;
                end
            end
            // ---- open an access ----
            if (open_en) begin
                if (!init_done || c_pend || job != J_IDLE) err <= 1'b1;
                ob <= open_b; obt <= open_bt; os <= open_slot[SLOT_W+11:12]; same <= (open_b == open_bt);
                opened <= 1'b1; la_in <= 1'b0; lt_in <= 1'b0; pre_done <= 1'b0; la_v <= 0; lt_v <= 0; la_stg <= 0;
                g_used <= 0; g_land <= 0; g_dirty <= 0; g_lt <= 0; n_cand <= 0; iss_la <= 1'b0; iss_lt <= 1'b0;
                sel_go <= 1'b0; sel_req <= 1'b0; la_chg <= 1'b1; os_hit <= 1'b0;
            end
            if (init_go) init_req <= 1'b1;
            if (commit && opened) c_pend <= 1'b1;            // (the boot format's re-encryption opens nothing)
            // ---- the AXI job engine ----
            if (m_awvalid && m_awready) begin m_awvalid <= 1'b0; aw_sent <= 1'b1; end
            if (w_hs) begin
                if (wbeat == wlen) begin m_wvalid <= 1'b0; w_on <= 1'b0; wbeat <= 0; end   // back to beat 0 between bursts
                else wbeat <= wbeat + 1'b1;
            end
            case (job)
                J_INIT: if (init_req && !w_on && !m_awvalid) begin          // boot: zero every list
                    if (init_b == B) begin if (outst == 0) begin init_done <= 1'b1; job <= J_IDLE; end end
                    else begin wstart(init_b * LIST_BYTES, LBEATS - 1); init_b <= init_b + 1'b1; end
                end
                J_IDLE: begin
                    if (c_pend && !w_on && !m_awvalid) begin wstart(ob * LIST_BYTES, LBEATS - 1); job <= J_WLA; end
                    else if (opened && !la_in && !iss_la && !open_en && outst == 0 && !m_arvalid) begin
                        job <= J_RD; rbeat <= 0;                // every earlier write is acknowledged
                    end
                end
                J_RD: begin                                      // pipelined reads
                    if (m_arvalid && m_arready) m_arvalid <= 1'b0;
                    begin : issue
                        reg go; reg [1:0] k; reg [SW-1:0] g; go = 0; k = T_LA; g = 0;
                        if (!m_arvalid || m_arready) begin
                            if (!iss_la) begin
                                go = 1; k = T_LA; iss_la <= 1'b1; m_araddr <= ob * LIST_BYTES; m_arlen <= LBEATS - 1;
                            end else if (!iss_lt && !same) begin
                                go = 1; k = T_LT; iss_lt <= 1'b1; m_araddr <= obt * LIST_BYTES; m_arlen <= LBEATS - 1;
                            end else if (sel_go) begin               // issue the selection registered last cycle
                                go = 1; k = T_PRE; g = fg; sel_go <= 1'b0;
                                la_stg[sel_k] <= 1'b1; la_g[sel_k] <= fg; g_used[fg] <= 1'b1; g_idx[fg] <= sel_i;
                                g_lt[fg] <= 1'b0; g_k[fg] <= sel_k; if (!sel_req) n_cand <= n_cand + 1'b1;
                                m_araddr <= POOL_BASE + sel_i * BLOCK_BYTES; m_arlen <= BEATS - 1;
                            end
                        end
                        if (go) begin m_arvalid <= 1'b1; tq_k[tq_wp] <= k; tq_g[tq_wp] <= g; tq_wp <= tq_wp + 1'b1; end
                        tq_n <= tq_n + (go ? 5'd1 : 5'd0) - ((m_rvalid && m_rlast) ? 5'd1 : 5'd0);
                        // select (registered) the next block to stage, from b's list once it is in
                        if (!go && !sel_go && la_in2 && fg_ok) begin
                            if (ps_hit)                     begin sel_go <= 1'b1; sel_k <= ps_k; sel_req <= 1'b1; end
                            else if (pc_hit && n_cand < Z)  begin sel_go <= 1'b1; sel_k <= pc_k; sel_req <= 1'b0; end
                            else if (la_in && (same || lt_in) && tq_n == 0 && !m_arvalid && !m_rvalid) begin
                                pre_done <= 1'b1; lt_in <= 1'b1; job <= J_IDLE;     // all staged and landed
                            end
                        end
                    end
                    if (m_rvalid) begin                              // land: route by the head tag
                        if (hk == T_LA || hk == T_LT) begin
                            for (e = 0; e < EPB; e = e + 1) begin
                                if (hk == T_LA) begin
                                    la_v[rbeat*EPB+e] <= m_rdata[64*e+63];
                                    if (m_rdata[64*e+63] && m_rdata[64*e+32 +: SLOT_W] == os) begin
                                        os_hit <= 1'b1; os_k <= rbeat[LB_W-1:0] * EPB + e;   // the requested slot
                                    end
                                end else
                                    lt_v[rbeat*EPB+e] <= m_rdata[64*e+63];
                            end
                            if (hk == T_LA) la_chg <= 1'b1;
                        end
                        rbeat <= rbeat + 1'b1;
                        if (m_rlast) begin
                            rbeat <= 0; tq_rp <= tq_rp + 1'b1;
                            if (hk == T_LA) la_in <= 1'b1;
                            if (hk == T_LT) lt_in <= 1'b1;
                            if (hk == T_PRE) g_land[hg] <= 1'b1;
                        end
                    end
                end
                J_WLA: if (!w_on && !m_awvalid) begin
                    if (!same) begin wstart(obt * LIST_BYTES, LBEATS - 1); job <= J_WLT; end
                    else job <= J_WSTG;
                end
                J_WLT: if (!w_on && !m_awvalid) job <= J_WSTG;
                J_WSTG: if (wg_go) begin
                    wg_go <= 1'b0; wstart(POOL_BASE + g_idx[wg] * BLOCK_BYTES, BEATS - 1);
                end else if (!w_on && !m_awvalid) begin : nd       // dirty staged blocks back to the pool
                    reg f; reg [SW-1:0] g; f = 0; g = 0;
                    for (gi = STG - 1; gi >= 0; gi = gi - 1) if (g_used[gi] && g_dirty[gi]) begin f = 1; g = gi[SW-1:0]; end
                    if (f) begin wg <= g; g_dirty[g] <= 1'b0; wg_go <= 1'b1; end   // its first beat is read next cycle
                    else begin c_pend <= 1'b0; opened <= 1'b0; job <= J_IDLE; end
                end
                default: job <= J_IDLE;
            endcase
        end
    end
endmodule
