// tinyoram_axi_adapter.v -- Tiny ORAM's DRAM interface to one AXI4 master (m_axi_gmem2).
//
// Plain 1:1 translation, so Tiny ORAM sees the memory it was designed for and nothing more:
//   * every Tiny ORAM command (one 64-byte burst, DRAMAddress in 64-bit words) becomes one
//     AXI burst of DDR_BITS/DW beats (2 at 256 bits) at base + DRAMAddress*8; no merging.
//     A 64-byte-aligned 2-beat burst never crosses a 4 KB boundary.
//   * single ID, so reads return in order.
//   * ordering Tiny ORAM assumes from a DDR3 MIG and AXI does not give: a read is not issued
//     while any earlier write is unacknowledged (no B yet), and a write is not issued while any
//     earlier read still has data to return. Commands are issued strictly in order.
//   * read data: Tiny ORAM has no ready on it, so beats are buffered here; an AR is issued
//     only when the buffer has room for all its beats (rready stays high), and the buffer
//     streams to Tiny ORAM at up to one beat per cycle.
//   * write data: Tiny ORAM's AES has only about two buckets of keystream buffering and no way to
//     stall it, so a long W-channel stall would lose keystream ("Lose Masks!"). Like a memory
//     controller's write FIFO, a buffer of 2^WBUF_LOG2 beats absorbs AXI write stalls; beats leave
//     it only after their AW has been issued.
// Status: quiet_w (every write beat Tiny ORAM sent is on the bus), error (a non-OKAY
// response or an address beyond the tree), and beat counters for the traffic report.
`timescale 1ns/1ps
module tinyoram_axi_adapter #(
    parameter integer DW        = 256,   // AXI data width = Tiny ORAM BEDWidth
    parameter integer DDR_BITS  = 512,   // Tiny ORAM DDRDWidth (one command)
    parameter integer AW_CORE   = 20,    // Tiny ORAM DDRAWidth
    parameter [63:0]  TREE_BYTES = 64'd0, // size of the tree region; 0 = no range check
    parameter integer RBUF_LOG2 = 9,     // read buffer depth (beats) = 2^RBUF_LOG2
    parameter integer WBUF_LOG2 = 9      // write buffer depth (beats) = 2^WBUF_LOG2
) (
    input  wire               clk,
    input  wire               rst,          // synchronous, active high
    input  wire [63:0]        base,         // byte address of the tree region (latched pages)
    // ---- Tiny ORAM side ----
    input  wire [AW_CORE-1:0] core_addr,    // in 64-bit words
    input  wire [2:0]         core_cmd,     // 0 write, 1 read
    input  wire               core_cmd_valid,
    output wire               core_cmd_ready,
    output reg  [DW-1:0]      core_rdata,
    output reg                core_rvalid,
    input  wire [DW-1:0]      core_wdata,
    input  wire               core_wvalid,
    output wire               core_wready,
    // ---- AXI4 master ----
    output wire [63:0]        araddr,  output wire [7:0] arlen, output wire [2:0] arsize, output wire [1:0] arburst,
    output wire               arvalid, input  wire       arready,
    input  wire [DW-1:0]      rdata,   input  wire [1:0] rresp, input wire rlast, input wire rvalid, output wire rready,
    output wire [63:0]        awaddr,  output wire [7:0] awlen, output wire [2:0] awsize, output wire [1:0] awburst,
    output wire               awvalid, input  wire       awready,
    output wire [DW-1:0]      wdata,   output wire [DW/8-1:0] wstrb, output wire wlast, output wire wvalid, input wire wready,
    input  wire [1:0]         bresp,   input  wire       bvalid, output wire bready,
    // ---- status ----
    output wire               quiet_w,      // no AW pending and every issued write beat sent
    output wire               idle,         // nothing queued, nothing outstanding (incl. B)
    output reg                error,        // sticky: SLVERR/DECERR or address outside the tree
    output reg  [63:0]        rd_beats,     // AXI read beats received (traffic counter)
    output reg  [63:0]        wr_beats      // AXI write beats sent
);
    localparam integer BPC   = DDR_BITS / DW;           // beats per command
    localparam integer CW    = $clog2(BPC) + 1;
    localparam integer DEPTH = 1 << RBUF_LOG2;
`ifndef SYNTHESIS
    initial if (DDR_BITS % DW != 0 || BPC < 1 || BPC > 256) begin
        $display("ERROR: tinyoram_axi_adapter needs DDR_BITS a multiple of DW"); $finish; end
`endif

    // ---------------- command queue (4 deep, registered ready) ----------------
    reg  [AW_CORE-1:0] cq_addr [0:3];
    reg                cq_rd   [0:3];
    reg  [1:0]         cq_wp, cq_rp;
    reg  [2:0]         cq_n;
    wire               cq_push = core_cmd_valid && core_cmd_ready;
    wire               cq_pop;
    assign core_cmd_ready = (cq_n < 3'd3);               // depends on a register only
    wire [AW_CORE-1:0] h_addr = cq_addr[cq_rp];
    wire               h_rd   = cq_rd[cq_rp];
    wire               h_val  = (cq_n != 3'd0);

    // ---------------- hazard bookkeeping ----------------
    reg  [15:0] b_out;          // AWs issued whose B has not arrived
    reg  [15:0] r_res;          // read beats requested (AR issued) and not yet received
    reg  [RBUF_LOG2:0] rb_n;    // beats held in the read buffer
    reg  [15:0] w_credit;       // write beats allowed by issued AWs and not yet sent

    wire rd_ok = (b_out == 16'd0) && ({{(16-RBUF_LOG2-1){1'b0}}, rb_n} + r_res + BPC <= DEPTH);
    wire wr_ok = (r_res == 16'd0) && (b_out < 16'hFFF0);

    reg         ar_v, aw_v;
    reg  [63:0] a_addr;
    assign arvalid = ar_v;  assign araddr = a_addr;
    assign awvalid = aw_v;  assign awaddr = a_addr;
    assign arlen = BPC - 1; assign awlen = BPC - 1;
    assign arsize = $clog2(DW / 8); assign awsize = $clog2(DW / 8);
    assign arburst = 2'b01; assign awburst = 2'b01;
    wire ar_fire = ar_v && arready;
    wire aw_fire = aw_v && awready;
    assign cq_pop = !ar_v && !aw_v && h_val && (h_rd ? rd_ok : wr_ok);   // head moves into the AR/AW register
    wire [63:0] byte_off = {{(64-AW_CORE-3){1'b0}}, h_addr, 3'b000};

    // ---------------- write data: buffer, then out after AW ----------------
    localparam integer WDEPTH = 1 << WBUF_LOG2;
    reg  [DW-1:0] wbuf [0:WDEPTH-1];
    reg  [WBUF_LOG2-1:0] wb_wp, wb_rp;
    reg  [WBUF_LOG2:0]   wb_n;          // beats in wbuf (not counting the output register)
    reg  [DW-1:0] wout;                 // output register (head beat)
    reg           wout_v;
    reg  [CW-1:0] wbeat;
    reg           wb_full;              // registered: core_wready depends on a register only
    wire   wb_push     = core_wvalid && core_wready;
    assign core_wready = !wb_full;
    assign wvalid      = wout_v && (w_credit != 16'd0);
    assign wdata       = wout;
    assign wstrb       = {(DW/8){1'b1}};
    assign wlast       = (wbeat == BPC - 1);
    wire   w_fire      = wvalid && wready;
    wire   wb_load     = (wb_n != 0) && (!wout_v || w_fire);     // move the next beat into the output register
    assign bready      = 1'b1;
    assign quiet_w     = !aw_v && (w_credit == 16'd0) && !(h_val && !h_rd) && (wb_n == 0) && !wout_v;
    assign idle        = (cq_n == 3'd0) && !ar_v && !aw_v && (b_out == 16'd0) && (r_res == 16'd0)
                         && (rb_n == 0) && (w_credit == 16'd0) && (wb_n == 0) && !wout_v;
    always @(posedge clk) begin
        if (wb_push) wbuf[wb_wp] <= core_wdata;
        if (wb_load) wout <= wbuf[wb_rp];
    end

    // ---------------- read buffer (one write port, one registered read) ----------------
    reg  [DW-1:0] rbuf [0:DEPTH-1];
    reg  [RBUF_LOG2-1:0] rb_wp, rb_rp;
    assign rready = 1'b1;                                // room was reserved by the AR
    wire   r_fire = rvalid;                              // rready is always high
    wire   rb_pop = (rb_n != 0);
    always @(posedge clk) begin
        if (r_fire) rbuf[rb_wp] <= rdata;
        if (rb_pop) core_rdata <= rbuf[rb_rp];
    end

    integer i;
    always @(posedge clk) begin
        if (rst) begin
            cq_wp <= 0; cq_rp <= 0; cq_n <= 0;
            b_out <= 0; r_res <= 0; rb_n <= 0; w_credit <= 0; wbeat <= 0;
            ar_v <= 1'b0; aw_v <= 1'b0; a_addr <= 64'd0;
            rb_wp <= 0; rb_rp <= 0; core_rvalid <= 1'b0;
            wb_wp <= 0; wb_rp <= 0; wb_n <= 0; wout_v <= 1'b0; wb_full <= 1'b0;
            error <= 1'b0; rd_beats <= 64'd0; wr_beats <= 64'd0;
        end else begin
            // queue
            if (cq_push) begin cq_addr[cq_wp] <= core_addr; cq_rd[cq_wp] <= (core_cmd == 3'd1); cq_wp <= cq_wp + 1'b1; end
            if (cq_pop)  cq_rp <= cq_rp + 1'b1;
            cq_n <= cq_n + (cq_push ? 3'd1 : 3'd0) - (cq_pop ? 3'd1 : 3'd0);
            // head -> address channel
            if (cq_pop) begin
                a_addr <= base + byte_off;
                if (h_rd) ar_v <= 1'b1; else aw_v <= 1'b1;
                if (TREE_BYTES != 0 && byte_off + DDR_BITS / 8 > TREE_BYTES) error <= 1'b1;
            end
            if (ar_fire) ar_v <= 1'b0;
            if (aw_fire) aw_v <= 1'b0;
            // outstanding counts
            b_out    <= b_out + (aw_fire ? 16'd1 : 16'd0) - ((bvalid && bready) ? 16'd1 : 16'd0);
            r_res    <= r_res + (cq_pop && h_rd ? BPC : 16'd0) - (r_fire ? 16'd1 : 16'd0);
            w_credit <= w_credit + (aw_fire ? BPC : 16'd0) - (w_fire ? 16'd1 : 16'd0);
            if (w_fire) wbeat <= (wbeat == BPC - 1) ? {CW{1'b0}} : wbeat + 1'b1;
            // write buffer
            if (wb_push) wb_wp <= wb_wp + 1'b1;
            if (wb_load) wb_rp <= wb_rp + 1'b1;
            wb_n <= wb_n + (wb_push ? 1'b1 : 1'b0) - (wb_load ? 1'b1 : 1'b0);
            if (wb_load) wout_v <= 1'b1; else if (w_fire) wout_v <= 1'b0;
            wb_full <= (wb_n + (wb_push ? 1 : 0) - (wb_load ? 1 : 0)) >= WDEPTH - 2;
            // read buffer
            if (r_fire) rb_wp <= rb_wp + 1'b1;
            if (rb_pop) rb_rp <= rb_rp + 1'b1;
            rb_n <= rb_n + (r_fire ? 1'b1 : 1'b0) - (rb_pop ? 1'b1 : 1'b0);
            core_rvalid <= rb_pop;
            // status
            if ((r_fire && rresp != 2'b00) || (bvalid && bresp != 2'b00)) error <= 1'b1;
            if (r_fire) rd_beats <= rd_beats + 64'd1;
            if (w_fire) wr_beats <= wr_beats + 64'd1;
        end
    end
endmodule
