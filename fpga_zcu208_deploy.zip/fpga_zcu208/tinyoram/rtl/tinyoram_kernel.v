// tinyoram_kernel.v -- Vitis RTL kernel wrapper for Tiny ORAM (Fletcher et al., FCCM 2015).
//
// Same calling convention, control registers, buffer layout, response and summary records as
// doma_kernel.v, so host_doma drives both:
//   tinyoram_kernel(cmd_input, resp_output, pages, size)
//     cmd_input   (m_axi_gmem0)  commands, read          resp_output (m_axi_gmem1)  responses, written
//     pages       (m_axi_gmem2)  Tiny ORAM's tree        size  number of commands in this run
// Control: 0x00 CTRL (ap_start, ap_done clear-on-read, ap_idle, ap_ready), 0x04 GIE, 0x08 IER,
//          0x0C ISR, 0x10 cmd_input, 0x1C resp_output, 0x28 pages, 0x34 size.
// cmd_input:   [0, size*32) headers (byte0 0x01 GET / 0x02 PUT, bytes 4-7 key);
//              PUT data at HC + i*4096, HC = roundup(size*32, 4 KB); the first ORAMB/8 bytes are the record.
// resp_output: [0, size*32) headers (0x10 ACK / 0x11 ERR, key, latency, status), record [size] =
//              summary (0x5A, total cycles, min/max latency, error flags, commands completed),
//              record [size+1] = traffic (0x5B, see below);
//              GET data at HR + i*4096, HR = roundup((size+2)*32, 4 KB) (as doma_kernel); ORAMB/8 bytes are written.
// Status flags: 0x2 unknown opcode, 0x4 key rejected (>= N), 0x8 ORAM failed (integrity
//               violation or AXI error), 0x10 timeout, 0x20 pages buffer changed.
//
// What differs from doma_kernel (and why):
//   * Tiny ORAM in place of DOMA, behind tinyoram_axi_adapter (1:1 AXI translation).
//   * First launch (size = 0, the init launch): latches the pages address for the kernel's lifetime
//     and reports the build's geometry in record [size+1] (blocks, tree size) WITHOUT touching
//     memory, so the host can check that its pages buffer holds the tree before anything is written.
//     The first launch with size > 0 (the start of the host's preload) then zero-fills the tree (an
//     all-zero bucket is Tiny ORAM's "never written" bucket; Tiny ORAM has no DRAM initialiser) and
//     releases Tiny ORAM from reset. If the very first launch has size > 0, it latches and fills.
//   * Keys >= N are rejected by the wrapper (Tiny ORAM itself only raises a sticky flag).
//   * Latency of a command, counted from issuing it to Tiny ORAM (plan step B1, 2026-10-12):
//       primary   (header bytes 8-11, summary min/max): (GET data received, or PUT data sent) and
//                 Tiny ORAM idle (its Idle status output) and every write acknowledged (B) --
//                 the same end point as DOMA's client_done;
//       secondary (header bytes 16-19): data ready;  (header bytes 20-23): last write-back beat sent.
//   * Record [size+1] (same format as DOMA's): byte0 0x5B, bytes 8-15 read beats and 16-23 write
//     beats on m_axi_gmem2 during this launch (the launch that zero-fills includes it). Tiny ORAM also
//     fills DOMA's reserved bytes: 24-27 the build's number of blocks N, 28-31 the tree size in 64-byte bursts.
//   * Tiny ORAM's crypto keys are its own hard-coded constants (as published).
// Tiny ORAM build configuration comes from the TINYORAM_* defines (patch 01): TINYORAM_ORAMB
// (block bits), TINYORAM_ORAML (levels - 1), TINYORAM_BEDWIDTH (must equal the AXI width, 256).
`timescale 1ns/1ps
`include "Const.vh"

module tinyoram_kernel #(
    parameter integer C_S_AXI_CONTROL_ADDR_WIDTH = 12,
    parameter integer C_M_AXI_ADDR_WIDTH         = 64,
    parameter integer C_M_AXI_DATA_WIDTH         = 256,
    parameter integer CMD_TIMEOUT                = 4000000   // cycles a command may take before the run aborts
) (
    input  wire                                    ap_clk,
    input  wire                                    ap_rst_n,
    input  wire [C_S_AXI_CONTROL_ADDR_WIDTH-1:0]   s_axi_control_awaddr,
    input  wire                                    s_axi_control_awvalid,
    output wire                                    s_axi_control_awready,
    input  wire [31:0]                             s_axi_control_wdata,
    input  wire [3:0]                              s_axi_control_wstrb,
    input  wire                                    s_axi_control_wvalid,
    output wire                                    s_axi_control_wready,
    output wire [1:0]                              s_axi_control_bresp,
    output reg                                     s_axi_control_bvalid,
    input  wire                                    s_axi_control_bready,
    input  wire [C_S_AXI_CONTROL_ADDR_WIDTH-1:0]   s_axi_control_araddr,
    input  wire                                    s_axi_control_arvalid,
    output wire                                    s_axi_control_arready,
    output reg  [31:0]                             s_axi_control_rdata,
    output wire [1:0]                              s_axi_control_rresp,
    output reg                                     s_axi_control_rvalid,
    input  wire                                    s_axi_control_rready,
    output wire                                    interrupt,
    // ---------------- m_axi_gmem0: commands (read) ----------------
    output reg  [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem0_araddr,
    output reg  [7:0]                              m_axi_gmem0_arlen,
    output wire [2:0]                              m_axi_gmem0_arsize,
    output wire [1:0]                              m_axi_gmem0_arburst,
    output reg                                     m_axi_gmem0_arvalid,
    input  wire                                    m_axi_gmem0_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem0_rdata,
    input  wire [1:0]                              m_axi_gmem0_rresp,
    input  wire                                    m_axi_gmem0_rlast,
    input  wire                                    m_axi_gmem0_rvalid,
    output wire                                    m_axi_gmem0_rready,
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem0_awaddr,
    output wire [7:0]                              m_axi_gmem0_awlen,
    output wire [2:0]                              m_axi_gmem0_awsize,
    output wire [1:0]                              m_axi_gmem0_awburst,
    output wire                                    m_axi_gmem0_awvalid,
    input  wire                                    m_axi_gmem0_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem0_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem0_wstrb,
    output wire                                    m_axi_gmem0_wlast,
    output wire                                    m_axi_gmem0_wvalid,
    input  wire                                    m_axi_gmem0_wready,
    input  wire [1:0]                              m_axi_gmem0_bresp,
    input  wire                                    m_axi_gmem0_bvalid,
    output wire                                    m_axi_gmem0_bready,
    // ---------------- m_axi_gmem1: responses (write) ----------------
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem1_araddr,
    output wire [7:0]                              m_axi_gmem1_arlen,
    output wire [2:0]                              m_axi_gmem1_arsize,
    output wire [1:0]                              m_axi_gmem1_arburst,
    output wire                                    m_axi_gmem1_arvalid,
    input  wire                                    m_axi_gmem1_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem1_rdata,
    input  wire [1:0]                              m_axi_gmem1_rresp,
    input  wire                                    m_axi_gmem1_rlast,
    input  wire                                    m_axi_gmem1_rvalid,
    output wire                                    m_axi_gmem1_rready,
    output reg  [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem1_awaddr,
    output reg  [7:0]                              m_axi_gmem1_awlen,
    output wire [2:0]                              m_axi_gmem1_awsize,
    output wire [1:0]                              m_axi_gmem1_awburst,
    output reg                                     m_axi_gmem1_awvalid,
    input  wire                                    m_axi_gmem1_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem1_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem1_wstrb,
    output wire                                    m_axi_gmem1_wlast,
    output reg                                     m_axi_gmem1_wvalid,
    input  wire                                    m_axi_gmem1_wready,
    input  wire [1:0]                              m_axi_gmem1_bresp,
    input  wire                                    m_axi_gmem1_bvalid,
    output wire                                    m_axi_gmem1_bready,
    // ---------------- m_axi_gmem2: Tiny ORAM's tree ----------------
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem2_araddr,
    output wire [7:0]                              m_axi_gmem2_arlen,
    output wire [2:0]                              m_axi_gmem2_arsize,
    output wire [1:0]                              m_axi_gmem2_arburst,
    output wire                                    m_axi_gmem2_arvalid,
    input  wire                                    m_axi_gmem2_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem2_rdata,
    input  wire [1:0]                              m_axi_gmem2_rresp,
    input  wire                                    m_axi_gmem2_rlast,
    input  wire                                    m_axi_gmem2_rvalid,
    output wire                                    m_axi_gmem2_rready,
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem2_awaddr,
    output wire [7:0]                              m_axi_gmem2_awlen,
    output wire [2:0]                              m_axi_gmem2_awsize,
    output wire [1:0]                              m_axi_gmem2_awburst,
    output wire                                    m_axi_gmem2_awvalid,
    input  wire                                    m_axi_gmem2_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem2_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem2_wstrb,
    output wire                                    m_axi_gmem2_wlast,
    output wire                                    m_axi_gmem2_wvalid,
    input  wire                                    m_axi_gmem2_wready,
    input  wire [1:0]                              m_axi_gmem2_bresp,
    input  wire                                    m_axi_gmem2_bvalid,
    output wire                                    m_axi_gmem2_bready
);
    // ---------------- Tiny ORAM constants (from its own headers) ----------------
    `include "PathORAM.vh"
    `include "UORAM.vh"
    `include "DMLocal.vh"
    `include "DDR3SDRAMLocal.vh"
    `include "BucketLocal.vh"
    `include "CommandsLocal.vh"
    `include "PLBLocal.vh"
    `include "JTAG.vh"

    localparam integer DW        = C_M_AXI_DATA_WIDTH;
    localparam [31:0]  NKEYS     = NumValidBlock;                       // N (blocks)
    localparam integer SLOT      = 4096;                                // bytes per command/response slot
    localparam integer REC_BEATS = ORAMB / DW;                          // AXI beats per record
    localparam integer CH_PER_BT = DW / FEDWidth;                       // Tiny ORAM data chunks per AXI beat
    localparam integer RBW       = (REC_BEATS > 1) ? $clog2(REC_BEATS) : 1;
    localparam integer CHW       = (CH_PER_BT > 1) ? $clog2(CH_PER_BT) : 1;
    localparam [63:0]  TREE_BYTES = 64'd64 * NumBuckets * BktSize_DRBursts;  // whole tree span
    localparam [63:0]  TREE_BURSTS = TREE_BYTES / 64;                     // reported in record [size+1]
    localparam integer FILL_BEATS = 128;                                // zero-fill burst: 4 KB
    localparam [2:0]   ASIZE  = $clog2(DW / 8);
    localparam [7:0]   T_GET = 8'h01, T_PUT = 8'h02, T_ACK = 8'h10, T_ERR = 8'h11, T_SUM = 8'h5A;
    wire rst = !ap_rst_n;
`ifndef SYNTHESIS
    initial begin
        if (DW != 256 || BEDWidth != DW || FEDWidth != 64 || ORAMB % DW != 0 || ORAMB > SLOT * 8) begin
            $display("ERROR: tinyoram_kernel needs a 256-bit AXI width = BEDWidth, FEDWidth 64 and ORAMB a multiple of 256 up to 32768 (got DW=%0d BED=%0d FED=%0d ORAMB=%0d)",
                     DW, BEDWidth, FEDWidth, ORAMB);
            $finish;
        end
        $display("tinyoram_kernel: ORAMB=%0d bits (%0d B) ORAML=%0d Z=%0d N=%0d EnableAES=%0d EnableIV=%0d tree=%0d bytes",
                 ORAMB, ORAMB/8, ORAML, ORAMZ, NKEYS, EnableAES, EnableIV, TREE_BYTES);
    end
`endif

    // =====================================================================
    // AXI4-Lite control registers (identical to doma_kernel)
    // =====================================================================
    reg        ap_start_r, ap_done_r, ap_ready_r, auto_restart_r, gie_r;
    reg  [1:0] ier_r, isr_r;
    reg [63:0] arg_cmd, arg_resp, arg_pages;
    reg [31:0] arg_size;
    wire       ap_idle;
    reg        done_pulse;

    wire wr_hs = s_axi_control_awvalid && s_axi_control_wvalid && !s_axi_control_bvalid;
    assign s_axi_control_awready = wr_hs;
    assign s_axi_control_wready  = wr_hs;
    assign s_axi_control_bresp   = 2'b00;
    assign s_axi_control_arready = !s_axi_control_rvalid;
    assign s_axi_control_rresp   = 2'b00;
    wire [7:0] wa = s_axi_control_awaddr[7:0];
    wire [7:0] ra = s_axi_control_araddr[7:0];
    function [31:0] wmask; input [31:0] oldv, newv; input [3:0] strb; integer b;
        begin wmask = oldv; for (b = 0; b < 4; b = b + 1) if (strb[b]) wmask[b*8 +: 8] = newv[b*8 +: 8]; end
    endfunction

    always @(posedge ap_clk) begin
        if (rst) begin
            ap_start_r <= 1'b0; ap_done_r <= 1'b0; ap_ready_r <= 1'b0; auto_restart_r <= 1'b0;
            gie_r <= 1'b0; ier_r <= 2'b00; isr_r <= 2'b00;
            arg_cmd <= 64'd0; arg_resp <= 64'd0; arg_pages <= 64'd0; arg_size <= 32'd0;
            s_axi_control_bvalid <= 1'b0; s_axi_control_rvalid <= 1'b0; s_axi_control_rdata <= 32'd0;
        end else begin
            if (wr_hs) begin
                s_axi_control_bvalid <= 1'b1;
                case (wa)
                    8'h00: begin
                        if (s_axi_control_wstrb[0] && s_axi_control_wdata[0]) ap_start_r <= 1'b1;
                        if (s_axi_control_wstrb[0]) auto_restart_r <= s_axi_control_wdata[7];
                    end
                    8'h04: if (s_axi_control_wstrb[0]) gie_r <= s_axi_control_wdata[0];
                    8'h08: if (s_axi_control_wstrb[0]) ier_r <= s_axi_control_wdata[1:0];
                    8'h0C: if (s_axi_control_wstrb[0]) isr_r <= isr_r ^ s_axi_control_wdata[1:0];
                    8'h10: arg_cmd[31:0]    <= wmask(arg_cmd[31:0],    s_axi_control_wdata, s_axi_control_wstrb);
                    8'h14: arg_cmd[63:32]   <= wmask(arg_cmd[63:32],   s_axi_control_wdata, s_axi_control_wstrb);
                    8'h1C: arg_resp[31:0]   <= wmask(arg_resp[31:0],   s_axi_control_wdata, s_axi_control_wstrb);
                    8'h20: arg_resp[63:32]  <= wmask(arg_resp[63:32],  s_axi_control_wdata, s_axi_control_wstrb);
                    8'h28: arg_pages[31:0]  <= wmask(arg_pages[31:0],  s_axi_control_wdata, s_axi_control_wstrb);
                    8'h2C: arg_pages[63:32] <= wmask(arg_pages[63:32], s_axi_control_wdata, s_axi_control_wstrb);
                    8'h34: arg_size         <= wmask(arg_size,         s_axi_control_wdata, s_axi_control_wstrb);
                    default: ;
                endcase
            end
            if (s_axi_control_bvalid && s_axi_control_bready) s_axi_control_bvalid <= 1'b0;
            if (s_axi_control_arvalid && !s_axi_control_rvalid) begin
                s_axi_control_rvalid <= 1'b1;
                case (ra)
                    8'h00: begin
                        s_axi_control_rdata <= {24'd0, auto_restart_r, 3'd0, ap_ready_r, ap_idle, ap_done_r, ap_start_r};
                        ap_done_r <= 1'b0; ap_ready_r <= 1'b0;
                    end
                    8'h04: s_axi_control_rdata <= {31'd0, gie_r};
                    8'h08: s_axi_control_rdata <= {30'd0, ier_r};
                    8'h0C: s_axi_control_rdata <= {30'd0, isr_r};
                    8'h10: s_axi_control_rdata <= arg_cmd[31:0];
                    8'h14: s_axi_control_rdata <= arg_cmd[63:32];
                    8'h1C: s_axi_control_rdata <= arg_resp[31:0];
                    8'h20: s_axi_control_rdata <= arg_resp[63:32];
                    8'h28: s_axi_control_rdata <= arg_pages[31:0];
                    8'h2C: s_axi_control_rdata <= arg_pages[63:32];
                    8'h34: s_axi_control_rdata <= arg_size;
                    default: s_axi_control_rdata <= 32'd0;
                endcase
            end
            if (s_axi_control_rvalid && s_axi_control_rready) s_axi_control_rvalid <= 1'b0;
            if (done_pulse) begin
                ap_done_r  <= 1'b1;
                ap_ready_r <= 1'b1;
                ap_start_r <= auto_restart_r;
                if (ier_r[0]) isr_r[0] <= 1'b1;
            end
        end
    end
    assign interrupt = gie_r && |(isr_r & ier_r);

    // =====================================================================
    // Tiny ORAM and its memory adapter
    // =====================================================================
    reg                     core_run;          // Tiny ORAM out of reset (after the zero-fill)
    wire                    core_rst = rst || !core_run;
    reg  [BECMDWidth-1:0]   t_cmd;
    reg  [ORAMU-1:0]        t_paddr;
    reg                     t_cmd_valid;
    wire                    t_cmd_ready;
    wire [FEDWidth-1:0]     t_din;
    wire                    t_din_valid, t_din_ready;
    wire [FEDWidth-1:0]     t_dout;
    wire                    t_dout_valid;
    wire                    t_idle;
    wire [DDRAWidth-1:0]    d_addr;
    wire [DDRCWidth-1:0]    d_cmd;
    wire                    d_cmd_valid, d_cmd_ready;
    wire [BEDWidth-1:0]     d_rdata, d_wdata;
    wire                    d_rvalid, d_wvalid, d_wready;
    wire [JTWidth_PMMAC-1:0] j_pmmac;

    TinyORAMCore u_tiny (
        .Clock(ap_clk), .Reset(core_rst),
        .Cmd(t_cmd), .PAddr(t_paddr), .WMask({DMWidth{1'b1}}), .CmdValid(t_cmd_valid), .CmdReady(t_cmd_ready),
        .DataIn(t_din), .DataInValid(t_din_valid), .DataInReady(t_din_ready),
        .DataOut(t_dout), .DataOutValid(t_dout_valid), .DataOutReady(1'b1),
        .DRAMAddress(d_addr), .DRAMCommand(d_cmd), .DRAMCommandValid(d_cmd_valid), .DRAMCommandReady(d_cmd_ready),
        .DRAMReadData(d_rdata), .DRAMReadDataValid(d_rvalid),
        .DRAMWriteData(d_wdata), .DRAMWriteDataValid(d_wvalid), .DRAMWriteDataReady(d_wready),
        .Mode_DummyGen(1'b0), .Idle(t_idle),
        .JTAG_UORAM(), .JTAG_PMMAC(j_pmmac), .JTAG_Frontend(),
        .JTAG_AES(), .JTAG_StashCore(), .JTAG_Stash(), .JTAG_StashTop(), .JTAG_BackendCore(), .JTAG_Backend());

    reg  [63:0] pages_base;                     // latched at the first ap_start
    wire [63:0] a_araddr, a_awaddr;
    wire [7:0]  a_arlen, a_awlen;
    wire [2:0]  a_arsize, a_awsize;
    wire [1:0]  a_arburst, a_awburst;
    wire        a_arvalid, a_awvalid, a_rready, a_wlast, a_wvalid, a_bready, a_quiet_w, a_idle, a_err;
    wire [DW-1:0]   a_wdata;
    wire [DW/8-1:0] a_wstrb;
    wire [63:0] a_rd_beats, a_wr_beats;
    tinyoram_axi_adapter #(.DW(DW), .DDR_BITS(DDRDWidth), .AW_CORE(DDRAWidth), .TREE_BYTES(TREE_BYTES)) u_adapt (
        .clk(ap_clk), .rst(core_rst), .base(pages_base),
        .core_addr(d_addr), .core_cmd(d_cmd), .core_cmd_valid(d_cmd_valid), .core_cmd_ready(d_cmd_ready),
        .core_rdata(d_rdata), .core_rvalid(d_rvalid),
        .core_wdata(d_wdata), .core_wvalid(d_wvalid), .core_wready(d_wready),
        .araddr(a_araddr), .arlen(a_arlen), .arsize(a_arsize), .arburst(a_arburst), .arvalid(a_arvalid),
        .arready(m_axi_gmem2_arready), .rdata(m_axi_gmem2_rdata), .rresp(m_axi_gmem2_rresp),
        .rlast(m_axi_gmem2_rlast), .rvalid(m_axi_gmem2_rvalid & core_run), .rready(a_rready),
        .awaddr(a_awaddr), .awlen(a_awlen), .awsize(a_awsize), .awburst(a_awburst), .awvalid(a_awvalid),
        .awready(m_axi_gmem2_awready), .wdata(a_wdata), .wstrb(a_wstrb), .wlast(a_wlast), .wvalid(a_wvalid),
        .wready(m_axi_gmem2_wready), .bresp(m_axi_gmem2_bresp), .bvalid(m_axi_gmem2_bvalid & core_run), .bready(a_bready),
        .quiet_w(a_quiet_w), .idle(a_idle), .error(a_err), .rd_beats(a_rd_beats), .wr_beats(a_wr_beats));

    // zero-fill master (first launch only); owns the gmem2 write channels until core_run
    reg         zf_awvalid, zf_wvalid;
    reg  [63:0] zf_awaddr;
    reg  [7:0]  zf_awlen, zf_wcnt;
    reg  [63:0] zf_off;                 // next byte offset to issue
    reg  [31:0] zf_bout;                // bursts whose B is outstanding
    assign m_axi_gmem2_araddr  = a_araddr;  assign m_axi_gmem2_arlen = a_arlen;  assign m_axi_gmem2_arsize = a_arsize;
    assign m_axi_gmem2_arburst = a_arburst; assign m_axi_gmem2_arvalid = a_arvalid & core_run;
    assign m_axi_gmem2_rready  = core_run ? a_rready : 1'b1;
    assign m_axi_gmem2_awaddr  = core_run ? a_awaddr : zf_awaddr;
    assign m_axi_gmem2_awlen   = core_run ? a_awlen  : zf_awlen;
    assign m_axi_gmem2_awsize  = ASIZE;     assign m_axi_gmem2_awburst = 2'b01;
    assign m_axi_gmem2_awvalid = core_run ? a_awvalid : zf_awvalid;
    assign m_axi_gmem2_wdata   = core_run ? a_wdata : {DW{1'b0}};
    assign m_axi_gmem2_wstrb   = core_run ? a_wstrb : {(DW/8){1'b1}};
    assign m_axi_gmem2_wlast   = core_run ? a_wlast : (zf_wcnt == zf_awlen);
    assign m_axi_gmem2_wvalid  = core_run ? a_wvalid : zf_wvalid;
    assign m_axi_gmem2_bready  = core_run ? a_bready : 1'b1;

    // =====================================================================
    // Command engine
    // =====================================================================
    localparam [4:0] K_IDLE = 5'd0,  K_FILL = 5'd1,  K_FILL_W = 5'd2, K_FILL_B = 5'd3, K_BOOT = 5'd4,
                     K_HDR_AR = 5'd5, K_HDR_R = 5'd6, K_REQ = 5'd7,   K_PDAT_AR = 5'd8, K_PDAT = 5'd9,
                     K_WAIT = 5'd10, K_GDAT_AW = 5'd11, K_GDAT_PRE = 5'd12, K_GDAT_W = 5'd13, K_GDAT_B = 5'd14,
                     K_RHDR_AW = 5'd15, K_RHDR_W = 5'd16, K_RHDR_B = 5'd17, K_NEXT = 5'd18,
                     K_SUM_AW = 5'd19, K_SUM_W = 5'd20, K_SUM_B = 5'd21, K_DONE = 5'd22,
                     K_BYT_AW = 5'd23, K_BYT_W = 5'd24, K_BYT_B = 5'd25;
    reg  [4:0]  kst;
    reg         booted;
    reg  [31:0] idx, nsize;
    reg  [63:0] cbase, rbase, hc_off, hr_off;
    reg  [7:0]  ctype;
    reg  [31:0] ckey;
    reg  [31:0] lat, lat_min, lat_max, wait_cnt;
    reg  [63:0] total;
    reg  [31:0] stat, errs, ndone;
    reg         cput;                       // current command is a PUT
    // PUT data: AXI beats from gmem0 -> 64-bit chunks into Tiny ORAM
    reg  [DW-1:0] pbeat;
    reg           pbeat_v;
    reg  [CHW-1:0] pch;
    reg  [RBW:0]  pbeats_in;                // record beats received
    reg  [15:0]   pchunks_out;              // chunks handed to Tiny ORAM
    // GET data: 64-bit chunks from Tiny ORAM -> AXI beats into rbuf
    reg  [DW-1:0] gasm;
    reg  [CHW-1:0] gch;
    reg  [RBW:0]  gbeats;                   // record beats assembled
    reg  [DW-1:0] rbuf [0:REC_BEATS-1];
    reg  [DW-1:0] wreg;
    reg  [RBW:0]  wcnt;
    reg  [1:0]    idle_run;                 // consecutive cycles: Tiny ORAM idle, every write acknowledged
    reg  [1:0]    wsent_run;                // consecutive cycles: Tiny ORAM idle, every write beat sent
    reg  [31:0]   lat_d, lat_w;             // secondary latencies: data ready, last write beat sent
    reg           got_d, got_w;
    // traffic on the data port (gmem2), including the first launch's zero-fill
    reg  [63:0]   g2_rd, g2_wr, g2_rd0, g2_wr0;
    wire          halted = j_pmmac[0] | a_err;
    wire [15:0]   rec_chunks = ORAMB / FEDWidth;

    assign ap_idle = (kst == K_IDLE);
    assign t_din       = pbeat[pch*FEDWidth +: FEDWidth];
    assign t_din_valid = (kst == K_PDAT) && pbeat_v;
    assign m_axi_gmem0_rready = (kst == K_HDR_R) || ((kst == K_PDAT) && !pbeat_v);
    assign m_axi_gmem0_arsize = ASIZE;  assign m_axi_gmem0_arburst = 2'b01;
    assign m_axi_gmem1_awsize = ASIZE;  assign m_axi_gmem1_awburst = 2'b01;
    assign m_axi_gmem1_bready = 1'b1;
    assign m_axi_gmem1_wstrb  = {(DW/8){1'b1}};
    assign m_axi_gmem1_wlast  = (kst == K_GDAT_W) ? (wcnt == REC_BEATS - 1) : 1'b1;
    // response header: bytes 8-11 latency to write-back acknowledged (the primary figure, as DOMA's),
    // 12-15 status, 16-19 latency to data ready (GET data received / PUT data sent),
    // 20-23 latency to the last write-back beat sent
    wire [DW-1:0] hdr_beat = {{(DW-192){1'b0}}, lat_w, lat_d, stat, lat, ckey, 24'd0, ((stat == 32'd0) ? T_ACK : T_ERR)};
    // record [size+1]: 0x5B, bytes 8-15 read beats and 16-23 write beats on gmem2 in this launch
    wire [255:0]  byt_beat = {TREE_BURSTS[31:0], NKEYS[31:0], g2_wr - g2_wr0, g2_rd - g2_rd0, 56'd0, 8'h5B};
    wire [255:0]  sum_beat = {ndone, errs, lat_max, (lat_min == 32'hFFFF_FFFF ? 32'd0 : lat_min), total, 56'd0, T_SUM};
    assign m_axi_gmem1_wdata = (kst == K_GDAT_W) ? wreg : (kst == K_SUM_W) ? sum_beat : (kst == K_BYT_W) ? byt_beat : hdr_beat;
    // unused channels
    assign m_axi_gmem0_awaddr = {C_M_AXI_ADDR_WIDTH{1'b0}}; assign m_axi_gmem0_awlen = 8'd0;
    assign m_axi_gmem0_awsize = ASIZE; assign m_axi_gmem0_awburst = 2'b01; assign m_axi_gmem0_awvalid = 1'b0;
    assign m_axi_gmem0_wdata = {DW{1'b0}}; assign m_axi_gmem0_wstrb = {(DW/8){1'b0}};
    assign m_axi_gmem0_wlast = 1'b0; assign m_axi_gmem0_wvalid = 1'b0; assign m_axi_gmem0_bready = 1'b1;
    assign m_axi_gmem1_araddr = {C_M_AXI_ADDR_WIDTH{1'b0}}; assign m_axi_gmem1_arlen = 8'd0;
    assign m_axi_gmem1_arsize = ASIZE; assign m_axi_gmem1_arburst = 2'b01; assign m_axi_gmem1_arvalid = 1'b0;
    assign m_axi_gmem1_rready = 1'b1;

    // GET data assembly and buffer (one write port, one registered read)
    wire g_take = t_dout_valid && (kst == K_WAIT) && !cput;
    always @(posedge ap_clk) begin
        if (g_take && gch == CH_PER_BT - 1 && gbeats < REC_BEATS)
            rbuf[gbeats[RBW-1:0]] <= {t_dout, gasm[DW-1:FEDWidth]};
        if (kst == K_GDAT_PRE || (kst == K_GDAT_W && m_axi_gmem1_wvalid && m_axi_gmem1_wready))
            wreg <= rbuf[(kst == K_GDAT_PRE) ? {RBW{1'b0}} : (wcnt[RBW-1:0] + 1'b1)];
    end

    always @(posedge ap_clk) begin
        if (rst) begin
            kst <= K_IDLE; booted <= 1'b0; core_run <= 1'b0; pages_base <= 64'd0;
            t_cmd <= 0; t_paddr <= 0; t_cmd_valid <= 1'b0;
            idx <= 0; nsize <= 0; cbase <= 0; rbase <= 0; hc_off <= 0; hr_off <= 0;
            ctype <= 8'd0; ckey <= 32'd0; lat <= 0; lat_min <= 32'hFFFF_FFFF; lat_max <= 0; wait_cnt <= 0;
            total <= 64'd0; stat <= 0; errs <= 0; ndone <= 0; cput <= 1'b0;
            pbeat <= 0; pbeat_v <= 1'b0; pch <= 0; pbeats_in <= 0; pchunks_out <= 0;
            gasm <= 0; gch <= 0; gbeats <= 0; wcnt <= 0; idle_run <= 2'd0; wsent_run <= 2'd0;
            lat_d <= 0; lat_w <= 0; got_d <= 1'b0; got_w <= 1'b0;
            g2_rd <= 64'd0; g2_wr <= 64'd0; g2_rd0 <= 64'd0; g2_wr0 <= 64'd0;
            zf_awvalid <= 1'b0; zf_wvalid <= 1'b0; zf_awaddr <= 64'd0; zf_awlen <= 8'd0; zf_wcnt <= 8'd0;
            zf_off <= 64'd0; zf_bout <= 32'd0;
            m_axi_gmem0_arvalid <= 1'b0; m_axi_gmem0_araddr <= 0; m_axi_gmem0_arlen <= 8'd0;
            m_axi_gmem1_awvalid <= 1'b0; m_axi_gmem1_awaddr <= 0; m_axi_gmem1_awlen <= 8'd0; m_axi_gmem1_wvalid <= 1'b0;
            done_pulse <= 1'b0;
        end else begin
            done_pulse <= 1'b0;
            if (kst != K_IDLE && kst != K_DONE) total <= total + 64'd1;
            if (m_axi_gmem2_rvalid && m_axi_gmem2_rready) g2_rd <= g2_rd + 64'd1;
            if (m_axi_gmem2_wvalid && m_axi_gmem2_wready) g2_wr <= g2_wr + 64'd1;
            // zero-fill write responses (counted in any state)
            if (!core_run && m_axi_gmem2_bvalid) zf_bout <= zf_bout - 32'd1 + ((zf_awvalid && m_axi_gmem2_awready) ? 32'd1 : 32'd0);
            else if (zf_awvalid && m_axi_gmem2_awready) zf_bout <= zf_bout + 32'd1;
            // GET data assembly (64-bit chunks, chunk 0 in the low bits)
            if (g_take) begin
                gasm <= {t_dout, gasm[DW-1:FEDWidth]};
                if (gch == CH_PER_BT - 1) begin gch <= 0; gbeats <= gbeats + 1'b1; end
                else gch <= gch + 1'b1;
            end
            case (kst)
                K_IDLE: if (ap_start_r && !done_pulse) begin
                    nsize  <= arg_size; cbase <= arg_cmd; rbase <= arg_resp;
                    hc_off <= ({32'd0, arg_size} * 64'd32 + 64'd4095) & ~64'd4095;
                    hr_off <= ({32'd0, arg_size} * 64'd32 + 64'd64 + 64'd4095) & ~64'd4095;   // after records [size], [size+1]
                    idx <= 0; total <= 64'd0; ndone <= 0; lat_min <= 32'hFFFF_FFFF; lat_max <= 0;
                    g2_rd0 <= g2_rd; g2_wr0 <= g2_wr;
                    // first launch: latch pages. Zero-fill and boot at the first launch with size > 0.
                    if (!booted) begin
                        pages_base <= arg_pages; errs <= 0; booted <= 1'b1; zf_off <= 64'd0;
                        kst <= (arg_size == 32'd0) ? K_SUM_AW : K_FILL;
                    end else begin
                        errs <= (arg_pages != pages_base) ? 32'h20 : 32'h0; zf_off <= 64'd0;
                        kst <= core_run ? K_BOOT : ((arg_size == 32'd0) ? K_SUM_AW : K_FILL);
                    end
                end
                // ---- first launch: zero the tree, then release Tiny ORAM from reset
                K_FILL: begin
                    if (!zf_awvalid) begin
                        if (zf_off >= TREE_BYTES) kst <= K_FILL_B;
                        else begin
                            zf_awaddr  <= pages_base + zf_off;
                            zf_awlen   <= ((TREE_BYTES - zf_off) >= FILL_BEATS * (DW / 8)) ? FILL_BEATS - 1
                                          : ((TREE_BYTES - zf_off) / (DW / 8)) - 1;
                            zf_awvalid <= 1'b1;
                        end
                    end else if (m_axi_gmem2_awready) begin
                        zf_awvalid <= 1'b0; zf_wvalid <= 1'b1; zf_wcnt <= 8'd0; kst <= K_FILL_W;
                    end
                end
                K_FILL_W: if (zf_wvalid && m_axi_gmem2_wready) begin
                    if (zf_wcnt == zf_awlen) begin
                        zf_wvalid <= 1'b0; zf_off <= zf_off + ({56'd0, zf_awlen} + 64'd1) * (DW / 8); kst <= K_FILL;
                    end else zf_wcnt <= zf_wcnt + 8'd1;
                end
                K_FILL_B: if (zf_bout == 32'd0) begin core_run <= 1'b1; kst <= K_BOOT; end
                K_BOOT: if (t_cmd_ready) kst <= (nsize == 0) ? K_SUM_AW : K_HDR_AR;   // Tiny ORAM's own init done
                // ---- fetch the command header
                K_HDR_AR: begin
                    m_axi_gmem0_araddr <= cbase + {idx, 5'd0}; m_axi_gmem0_arlen <= 8'd0; m_axi_gmem0_arvalid <= 1'b1;
                    if (m_axi_gmem0_arvalid && m_axi_gmem0_arready) begin m_axi_gmem0_arvalid <= 1'b0; kst <= K_HDR_R; end
                end
                K_HDR_R: if (m_axi_gmem0_rvalid) begin
                    ctype <= m_axi_gmem0_rdata[7:0]; ckey <= m_axi_gmem0_rdata[63:32]; wait_cnt <= 0; kst <= K_REQ;
                end
                // ---- issue the request to Tiny ORAM
                K_REQ: begin
                    stat <= 32'd0; lat <= 0; cput <= (ctype == T_PUT);
                    pbeat_v <= 1'b0; pch <= 0; pbeats_in <= 0; pchunks_out <= 0;
                    gch <= 0; gbeats <= 0; idle_run <= 2'd0; wsent_run <= 2'd0;
                    lat_d <= 0; lat_w <= 0; got_d <= 1'b0; got_w <= 1'b0;
                    if (ctype != T_GET && ctype != T_PUT) begin stat <= 32'h2; kst <= K_RHDR_AW; end
                    else if (ckey >= NKEYS) begin stat <= 32'h4; kst <= K_RHDR_AW; end
                    else if (halted) begin stat <= 32'h8; errs <= errs | 32'h8; t_cmd_valid <= 1'b0; kst <= K_RHDR_AW; end
                    else if (!t_cmd_valid) begin
                        t_cmd <= (ctype == T_PUT) ? BECMD_Update : BECMD_Read; t_paddr <= ckey; t_cmd_valid <= 1'b1;
                    end else if (t_cmd_ready) begin                       // handshake this cycle
                        t_cmd_valid <= 1'b0; lat <= 32'd1; wait_cnt <= 0;
                        kst <= (ctype == T_PUT) ? K_PDAT_AR : K_WAIT;
                    end else if (wait_cnt >= CMD_TIMEOUT) begin           // Tiny ORAM never became ready
                        t_cmd_valid <= 1'b0; stat <= 32'h10; errs <= errs | 32'h10; kst <= K_RHDR_AW;
                    end else wait_cnt <= wait_cnt + 1;
                end
                // ---- PUT data: read the record from the command buffer and stream it in
                K_PDAT_AR: begin
                    lat <= lat + 1;
                    m_axi_gmem0_araddr <= cbase + hc_off + {idx, 12'd0};
                    m_axi_gmem0_arlen <= REC_BEATS - 1; m_axi_gmem0_arvalid <= 1'b1;
                    if (m_axi_gmem0_arvalid && m_axi_gmem0_arready) begin m_axi_gmem0_arvalid <= 1'b0; kst <= K_PDAT; end
                end
                K_PDAT: begin
                    lat <= lat + 1;
                    if (!pbeat_v && m_axi_gmem0_rvalid) begin pbeat <= m_axi_gmem0_rdata; pbeat_v <= 1'b1; pch <= 0; pbeats_in <= pbeats_in + 1'b1; end
                    if (t_din_valid && t_din_ready) begin
                        pchunks_out <= pchunks_out + 16'd1;
                        if (pch == CH_PER_BT - 1) pbeat_v <= 1'b0; else pch <= pch + 1'b1;
                        if (pchunks_out + 16'd1 == rec_chunks) kst <= K_WAIT;
                    end
                end
                // ---- wait for completion: data done, Tiny ORAM idle, write-back sent
                K_WAIT: begin
                    lat <= lat + 1; wait_cnt <= wait_cnt + 1;
                    // data ready: GET record received, or (PUT) record sent, which is true on entry
                    if (!got_d && (cput || gbeats == REC_BEATS)) begin got_d <= 1'b1; lat_d <= lat; end
                    // last write-back beat sent: Tiny ORAM idle and every write beat on the bus (2 cycles)
                    wsent_run <= (t_idle && a_quiet_w && got_d) ? ((wsent_run == 2'd2) ? 2'd2 : wsent_run + 2'd1) : 2'd0;
                    if (!got_w && wsent_run == 2'd2) begin got_w <= 1'b1; lat_w <= lat; end
                    // done (primary): Tiny ORAM idle and every write acknowledged (B received), 2 cycles
                    idle_run <= (t_idle && a_idle && got_d) ? ((idle_run == 2'd2) ? 2'd2 : idle_run + 2'd1) : 2'd0;
                    if (idle_run == 2'd2) begin
                        if (!got_w) lat_w <= lat;   // acknowledged in the same cycles as sent
                        ndone <= ndone + 1;
                        if (lat < lat_min) lat_min <= lat;
                        if (lat > lat_max) lat_max <= lat;
                        kst <= cput ? K_RHDR_AW : K_GDAT_AW;
                    end else if (halted || wait_cnt >= CMD_TIMEOUT) begin
                        stat <= halted ? 32'h8 : 32'h10; errs <= errs | (halted ? 32'h8 : 32'h10);
                        kst <= K_RHDR_AW;
                    end
                end
                // ---- GET data, then the header
                K_GDAT_AW: begin
                    m_axi_gmem1_awaddr <= rbase + hr_off + {idx, 12'd0};
                    m_axi_gmem1_awlen <= REC_BEATS - 1; m_axi_gmem1_awvalid <= 1'b1;
                    if (m_axi_gmem1_awvalid && m_axi_gmem1_awready) begin m_axi_gmem1_awvalid <= 1'b0; kst <= K_GDAT_PRE; end
                end
                K_GDAT_PRE: begin wcnt <= 0; kst <= K_GDAT_W; end
                K_GDAT_W: begin
                    m_axi_gmem1_wvalid <= 1'b1;
                    if (m_axi_gmem1_wvalid && m_axi_gmem1_wready) begin
                        wcnt <= wcnt + 1'b1;
                        if (wcnt == REC_BEATS - 1) begin m_axi_gmem1_wvalid <= 1'b0; kst <= K_GDAT_B; end
                    end
                end
                K_GDAT_B: if (m_axi_gmem1_bvalid) kst <= K_RHDR_AW;
                K_RHDR_AW: begin
                    m_axi_gmem1_awaddr <= rbase + {idx, 5'd0}; m_axi_gmem1_awlen <= 8'd0; m_axi_gmem1_awvalid <= 1'b1;
                    if (m_axi_gmem1_awvalid && m_axi_gmem1_awready) begin m_axi_gmem1_awvalid <= 1'b0; kst <= K_RHDR_W; end
                end
                K_RHDR_W: begin
                    m_axi_gmem1_wvalid <= 1'b1;
                    if (m_axi_gmem1_wvalid && m_axi_gmem1_wready) begin m_axi_gmem1_wvalid <= 1'b0; kst <= K_RHDR_B; end
                end
                K_RHDR_B: if (m_axi_gmem1_bvalid) kst <= K_NEXT;
                K_NEXT: begin
                    idx <= idx + 1;
                    kst <= ((idx + 1 == nsize) || halted || stat[4]) ? K_SUM_AW : K_HDR_AR;
                end
                // ---- summary record [size]
                K_SUM_AW: begin
                    m_axi_gmem1_awaddr <= rbase + {nsize, 5'd0}; m_axi_gmem1_awlen <= 8'd0; m_axi_gmem1_awvalid <= 1'b1;
                    if (m_axi_gmem1_awvalid && m_axi_gmem1_awready) begin m_axi_gmem1_awvalid <= 1'b0; kst <= K_SUM_W; end
                end
                K_SUM_W: begin
                    m_axi_gmem1_wvalid <= 1'b1;
                    if (m_axi_gmem1_wvalid && m_axi_gmem1_wready) begin m_axi_gmem1_wvalid <= 1'b0; kst <= K_SUM_B; end
                end
                K_SUM_B: if (m_axi_gmem1_bvalid) kst <= K_BYT_AW;
                // ---- traffic record [size+1]
                K_BYT_AW: begin
                    m_axi_gmem1_awaddr <= rbase + {nsize + 32'd1, 5'd0}; m_axi_gmem1_awlen <= 8'd0; m_axi_gmem1_awvalid <= 1'b1;
                    if (m_axi_gmem1_awvalid && m_axi_gmem1_awready) begin m_axi_gmem1_awvalid <= 1'b0; kst <= K_BYT_W; end
                end
                K_BYT_W: begin
                    m_axi_gmem1_wvalid <= 1'b1;
                    if (m_axi_gmem1_wvalid && m_axi_gmem1_wready) begin m_axi_gmem1_wvalid <= 1'b0; kst <= K_BYT_B; end
                end
                K_BYT_B: if (m_axi_gmem1_bvalid) kst <= K_DONE;
                K_DONE: begin done_pulse <= 1'b1; kst <= K_IDLE; end
                default: kst <= K_IDLE;
            endcase
        end
    end
endmodule
