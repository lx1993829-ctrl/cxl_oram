#!/bin/bash
# run_study.sh -- the bare-core study harness (tb_core.sv drives TinyORAMCore directly; not the kernel
# regression). Uses the patched sources from ../fetch_tinyoram.sh (patches 01-06).
#   ./run_study.sh <name> <config.vh> [defines...]
# Examples:
#   ./run_study.sh base4k ../config/tinyoram_config_4k.vh -DNCMD=200 -DGAP=10 -DZERO_INIT
#   ./run_study.sh mask64 ../config/tinyoram_config_64.vh -DMASK_TEST -DNCMD=300 -DGAP=10 -DZERO_INIT
#   (for N = 16K or 64K: copy tinyoram_config_64.vh and set TINYORAM_ORAML to 12 or 14)
# tb_core.sv knobs: NCMD RD_LAT GAP SEED ZERO_INIT WR_LAG WD_NS TRACE MASK_TEST IDLE_CHECK
#                   FIXED_GAP SAME_KEY/SAME_KEY_PUT SHOW_CMDS SEQ_FILE (+seq=<file>) RST_CYC DUMP_STATE
set -e
here=$(cd "$(dirname "$0")" && pwd)
src=$here/../build/src
[ -f "$src/files.f" ] || bash "$here/../fetch_tinyoram.sh" 4k
name=$1; cfg=$(cd "$(dirname "$2")" && pwd)/$(basename "$2"); shift 2
out=$here/build_$name
rm -rf "$out" "$out.cfg"; mkdir -p "$out.cfg"; cp "$cfg" "$out.cfg/tinyoram_config.vh"
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style -Wno-WIDTH -Wno-MULTIDRIVEN -Wno-ZERODLY \
    --top-module tb_core -DSIMULATION "$@" -I"$out.cfg" -I"$src" \
    $(sed "s#^#$src/#" "$src/files.f") "$here/tb_core.sv" -j "$(nproc)" --Mdir "$out" > "$out.build.log" 2>&1 \
    || { grep %Error "$out.build.log" | head; exit 1; }
ulimit -s unlimited
"$out/Vtb_core" $RUNARGS | tee "$here/$name.log" | grep -E '^(CONFIG|INIT|PRELOAD|RUN|RESULT|MISMATCH|MASKED|TRACE)|ERROR|Error'
