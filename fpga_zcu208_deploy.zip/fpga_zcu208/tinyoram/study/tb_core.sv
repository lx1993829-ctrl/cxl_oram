// tb_core.sv -- standalone harness around TinyORAMCore (Step 1 study only, not the
// Step 4 regression). Drives the frontend (op, addr, data) interface with a
// preload of every block followed by random GET/PUT traffic, checks every GET
// against a reference copy, and models DRAM as an in-order burst memory with
// random command/write backpressure and random read gaps.
//
// Build-time knobs (defines): the *_OVR overrides in the patched PathORAM.vh,
// NCMD (random commands after preload), RD_LAT (DRAM read latency, cycles),
// GAP (percent of cycles a DRAM-side ready/valid is withheld), SEED, ZERO_INIT
// (never-written DRAM reads as zeros instead of garbage), WR_LAG (writes become
// visible WR_LAG cycles late, i.e. no AXI write-response ordering), WD_NS
// (watchdog), TRACE (per-phase timing of the first 6 random commands; adds idle
// time, so don't read RUN throughput from a TRACE build).
`include "Const.vh"
`timescale 1ns/1ps
module tb_core;
	`include "PathORAM.vh"
	`include "UORAM.vh"
	`include "DMLocal.vh"
	`include "DDR3SDRAMLocal.vh"
	`include "BucketLocal.vh"
	`include "CommandsLocal.vh"
	`include "PLBLocal.vh"
	`include "JTAG.vh"

`ifndef NCMD
	`define NCMD 200
`endif
`ifndef RD_LAT
	`define RD_LAT 40
`endif
`ifndef GAP
	`define GAP 0
`endif
`ifndef SEED
	`define SEED 1
`endif
	localparam integer CHUNKS = ORAMB / FEDWidth;      // frontend beats per block
	localparam integer BPB    = DDRDWidth / BEDWidth;  // backend beats per DRAM burst

	reg Clock = 0, Reset = 1;
	always #1.6667 Clock = ~Clock;                     // ~300 MHz, cosmetic only
	longint cyc = 0;
	always @(posedge Clock) cyc <= cyc + 1;

	// ---------------- frontend ----------------
	reg  [BECMDWidth-1:0] Cmd = 0;
	reg  [DMWidth-1:0]    WMaskR = {DMWidth{1'b1}};
	int                   masked_puts = 0;
	reg  [ORAMU-1:0]      PAddr = 0;
	reg                   CmdValid = 0;
	wire                  CmdReady;
	reg  [FEDWidth-1:0]   DataIn = 0;
	reg                   DataInValid = 0;
	wire                  DataInReady;
	wire [FEDWidth-1:0]   DataOut;
	wire                  DataOutValid;
	reg                   DataOutReady = 1;

	// ---------------- DRAM side ----------------
	wire [DDRAWidth-1:0]  DRAMAddress;
	wire [DDRCWidth-1:0]  DRAMCommand;
	wire                  DRAMCommandValid;
	reg                   DRAMCommandReady = 0;
	reg  [BEDWidth-1:0]   DRAMReadData = 0;
	reg                   DRAMReadDataValid = 0;
	wire [BEDWidth-1:0]   DRAMWriteData;
	wire                  DRAMWriteDataValid;
	reg                   DRAMWriteDataReady = 0;

	TinyORAMCore core(
		.Clock(Clock), .Reset(Reset),
		.Cmd(Cmd), .PAddr(PAddr), .WMask(WMaskR), .CmdValid(CmdValid), .CmdReady(CmdReady),
		.DataIn(DataIn), .DataInValid(DataInValid), .DataInReady(DataInReady),
		.DataOut(DataOut), .DataOutValid(DataOutValid), .DataOutReady(DataOutReady),
		.DRAMAddress(DRAMAddress), .DRAMCommand(DRAMCommand),
		.DRAMCommandValid(DRAMCommandValid), .DRAMCommandReady(DRAMCommandReady),
		.DRAMReadData(DRAMReadData), .DRAMReadDataValid(DRAMReadDataValid),
		.DRAMWriteData(DRAMWriteData), .DRAMWriteDataValid(DRAMWriteDataValid),
		.DRAMWriteDataReady(DRAMWriteDataReady),
		.Mode_DummyGen(1'b0),
		.JTAG_UORAM(), .JTAG_PMMAC(), .JTAG_Frontend(),
		.JTAG_AES(), .JTAG_StashCore(), .JTAG_Stash(), .JTAG_StashTop(), .JTAG_BackendCore(), .JTAG_Backend());

	// ---------------- DRAM model ----------------
	// Flat array indexed by burst (DRAMAddress / DDRBstLen), filled explicitly at time 0:
	// with --x-initial unique, Verilator randomises unwritten storage (an associative
	// array's missing keys included), so "never written" must be modelled by hand.
	localparam longint NBURSTS = 64'd1 << (DDRAWidth - 3);
	logic [DDRDWidth-1:0] mem [0:NBURSTS-1];
	initial for (longint i = 0; i < NBURSTS; i++)
`ifdef ZERO_INIT
		mem[i] = '0;
`else
		mem[i] = garbage();
`endif
	typedef struct { longint idx; bit rd; } cmd_t;
	cmd_t                 cq[$];                       // accepted commands, in order
	logic [BEDWidth-1:0]  wq[$];                       // write beats, in order
	logic [BEDWidth-1:0]  rq[$];                       // read beats ready to return
	longint               rts[$];                      // release cycle per read beat
	longint               t_rc_first = -1, t_rc_last = -1, t_rd_first = -1, t_rd_last = -1, t_wr_first = -1, t_wr_last = -1, t_do_first = -1, t_do_last = -1;
	task automatic trace_clear(); t_rc_first = -1; t_rd_first = -1; t_wr_first = -1; t_do_first = -1; t_rc_last = -1; t_rd_last = -1; t_wr_last = -1; t_do_last = -1; endtask
	longint               pw_idx[$], pw_t[$];
	logic [DDRDWidth-1:0] pw_dat[$];
	longint               rd_bursts = 0, wr_bursts = 0, max_rq = 0;
	int                   lat_ctr = 0;

	function automatic logic [DDRDWidth-1:0] garbage();
		logic [DDRDWidth-1:0] g;
		for (int i = 0; i < DDRDWidth/32; i++) g[i*32 +: 32] = $urandom;
		return g;
	endfunction

	always @(posedge Clock) begin
		if (Reset) begin
			DRAMCommandReady <= 0; DRAMWriteDataReady <= 0; DRAMReadDataValid <= 0;
		end else begin
			// accept commands / write beats
			if (DRAMCommandValid && DRAMCommandReady) begin
				cmd_t c; c.idx = longint'(DRAMAddress) / DDRBstLen; c.rd = (DRAMCommand == DDR3CMD_Read);
				if (DRAMAddress % DDRBstLen != 0) begin $display("TB ERROR: unaligned DRAM address %x", DRAMAddress); $finish; end
				cq.push_back(c);
			end
			if (DRAMWriteDataValid && DRAMWriteDataReady) begin wq.push_back(DRAMWriteData); if (t_wr_first < 0) t_wr_first = cyc; if (cyc > t_wr_last) t_wr_last = cyc; end
			if (DRAMCommandValid && DRAMCommandReady && DRAMCommand == DDR3CMD_Read) begin if (t_rc_first < 0) t_rc_first = cyc; if (cyc > t_rc_last) t_rc_last = cyc; end
			if (DRAMReadDataValid) begin if (t_rd_first < 0) t_rd_first = cyc; if (cyc > t_rd_last) t_rd_last = cyc; end
			if (DataOutValid && DataOutReady) begin if (t_do_first < 0) t_do_first = cyc; if (cyc > t_do_last) t_do_last = cyc; end
			DRAMCommandReady   <= ($urandom % 100) >= `GAP;
			DRAMWriteDataReady <= ($urandom % 100) >= `GAP;
			// execute commands in order (a write waits for its data)
			if (cq.size() != 0) begin
				if (cq[0].rd) begin
					logic [DDRDWidth-1:0] w;
					w = mem[cq[0].idx];
					for (int b = 0; b < BPB; b++) begin rq.push_back(w[b*BEDWidth +: BEDWidth]); rts.push_back(cyc + `RD_LAT); end
					rd_bursts++;
					void'(cq.pop_front());
				end else if (wq.size() >= BPB) begin
					logic [DDRDWidth-1:0] w;
					for (int b = 0; b < BPB; b++) w[b*BEDWidth +: BEDWidth] = wq.pop_front();
`ifdef WR_LAG
					pw_idx.push_back(cq[0].idx); pw_dat.push_back(w); pw_t.push_back(cyc + `WR_LAG);
`else
					mem[cq[0].idx] = w;
`endif
					wr_bursts++;
					void'(cq.pop_front());
				end
			end
`ifdef WR_LAG
			// writes become visible only WR_LAG cycles after their data arrived (AXI without B-ordering)
			while (pw_t.size() != 0 && pw_t[0] <= cyc) begin
				mem[pw_idx.pop_front()] = pw_dat.pop_front(); void'(pw_t.pop_front());
			end
`endif
			// return read beats (no ready on this interface: Tiny ORAM must sink them)
			DRAMReadDataValid <= 0;
			if (rq.size() != 0 && rts[0] <= cyc && ($urandom % 100) >= `GAP) begin
				DRAMReadData <= rq.pop_front(); void'(rts.pop_front());
				DRAMReadDataValid <= 1;
			end
			if (rq.size() > max_rq) max_rq = rq.size();
		end
	end

`ifdef DUMP_STATE
	int ntr = 0; logic [3:0] last_scs = 0, last_ccs = 0;
	always @(posedge Clock) if (!Reset && ntr < 0) begin
		if (core.back_end.bend_core.stash_top.stash.CS != last_scs || core.back_end.bend_core.stash_top.stash.core.CS != last_ccs
		    || core.back_end.bend_core.stash_top.stash.core.AddBlock || core.back_end.bend_core.stash_top.stash.BogusU) begin
			$display("TR cyc=%0d stash.CS=%0d core.CS=%0d AddBlock=%b BogusU=%b occ=%0d ScanLV=%b ScanPAddr=%x",
				cyc, core.back_end.bend_core.stash_top.stash.CS, core.back_end.bend_core.stash_top.stash.core.CS,
				core.back_end.bend_core.stash_top.stash.core.AddBlock, core.back_end.bend_core.stash_top.stash.BogusU,
				core.back_end.bend_core.stash_top.stash.StashOccupancy, core.back_end.bend_core.stash_top.stash.Scan_LeafValid,
				core.back_end.bend_core.stash_top.stash.Scan_PAddr);
			ntr++;
		end
		last_scs = core.back_end.bend_core.stash_top.stash.CS; last_ccs = core.back_end.bend_core.stash_top.stash.core.CS;
	end
`endif
`ifdef DUMP_STATE
	int nh = 0;
	always @(posedge Clock) if (!Reset && nh < 12 && core.back_end.bend_core.stash_top.in_convert.HeaderValid && core.back_end.bend_core.stash_top.in_convert.BucketTransition) begin
		$display("HDR cyc=%0d IV=%x valid=%b BucketValid=%b", cyc, core.back_end.bend_core.stash_top.in_convert.HeaderDown_EncryptionIV,
			core.back_end.bend_core.stash_top.in_convert.HeaderDown_ValidBits, core.back_end.bend_core.stash_top.in_convert.BucketValid);
		nh++;
	end
	int nc = 0;
	always @(posedge Clock) if (!Reset && nc < 8 && DRAMCommandValid && DRAMCommandReady) begin
		$display("DCMD cyc=%0d cmd=%0d addr=%x wq=%0d", cyc, DRAMCommand, DRAMAddress, wq.size()); nc++;
	end
	int nw = 0;
	always @(posedge Clock) if (!Reset && nw < 4 && DRAMWriteDataValid && DRAMWriteDataReady) begin
		$display("DWR cyc=%0d data=%x", cyc, DRAMWriteData[127:0]); nw++;
	end
	int nd = 0;
	always @(posedge Clock) if (!Reset && nd < 12 && DRAMReadDataValid) begin
		if (nd < 4) $display("RDDRAM cyc=%0d data=%x", cyc, DRAMReadData[127:0]);
		nd++;
	end
`endif
`ifdef WATCH_KEY
	// trace one key through the PosMap and the integrity verifier
	always @(posedge Clock) if (!Reset) begin
		if (core.front_end.uoram.PPP.PosMapWrite && !core.front_end.uoram.PPP.PosMapInit && core.front_end.uoram.PPP.PosMapAddr == `WATCH_KEY)
			$display("W%0d cyc=%0d PosMap write %x (read value %x, PosMapValid=%b)", `WATCH_KEY, cyc, core.front_end.uoram.PPP.PosMapIn,
				core.front_end.uoram.PPP.PosMapOut, core.front_end.uoram.PPP.PosMapValid);
		if (core.front_end.uoram.PPP.PosMapSelect && core.front_end.uoram.PPP.PosMapAddr == `WATCH_KEY)
			$display("W%0d cyc=%0d PosMap read (cmd %0d)", `WATCH_KEY, cyc, core.front_end.uoram.PPP.Cmd);
		if (core.BEnd_CmdValid && core.BEnd_CmdReady && core.BEnd_PAddr == `WATCH_KEY)
			$display("W%0d cyc=%0d BE cmd %0d cur leaf %x new leaf %x", `WATCH_KEY, cyc, core.BEnd_Cmd, core.CurrentLeaf, core.RemappedLeaf);
		if (core.front_end.MAC.iv.CSAESStart1 && core.front_end.MAC.iv.PAddr_Int == `WATCH_KEY)
			$display("W%0d cyc=%0d IV PRF start: counters cur %x new %x", `WATCH_KEY, cyc, core.front_end.MAC.iv.FECurrentCounter_Int, core.front_end.MAC.iv.FERemappedCounter_Int);
	end
`endif
	// ---------------- reference model + stimulus ----------------
	localparam integer NBLK = NumValidBlock;
	logic [FEDWidth-1:0] ref_mem [NBLK][CHUNKS];
	bit                  written [NBLK];
	int errors = 0, ngets = 0, nputs = 0;
	longint lat_min = 64'h7fffffffffffffff, lat_max = 0, lat_sum = 0;
	longint get_min = 64'h7fffffffffffffff, get_max = 0, put_min = 64'h7fffffffffffffff, put_max = 0;
	longint rd0, wr0;

	function automatic logic [FEDWidth-1:0] pattern(int key, int op, int ch);
		logic [FEDWidth-1:0] p;
		for (int i = 0; i < FEDWidth/32; i++) p[i*32 +: 32] = (key * 32'h9E3779B1) ^ (op * 32'h85EBCA77) ^ (ch * 32'hC2B2AE3D) ^ (i * 32'h27D4EB2F);
		return p;
	endfunction

	task automatic wait_ready_idle();
		while (!CmdReady) @(posedge Clock);
	endtask

	// One access. Returns cycles from command handshake to: GET -> last data beat
	// received; PUT -> last data beat accepted and CmdReady high again.
	task automatic access(input bit put, input int key, input int opno, output longint lat);
		longint t0;
		@(negedge Clock);
		while (!CmdReady) @(negedge Clock);
		WMaskR = {DMWidth{1'b1}};
`ifdef MASK_TEST
		// partial writes to blocks that already exist: a random byte range (odd sizes and
		// offsets), or an aligned 8-byte record slot as packing would use
		if (put && written[key] && ($urandom % 4) != 0) begin
			int off, len;
			if ($urandom % 2) begin off = ($urandom % (DMWidth / 8)) * 8; len = 8; end
			else begin off = $urandom % DMWidth; len = 1 + $urandom % (DMWidth - off); end
			WMaskR = '0;
			for (int b = off; b < off + len; b++) WMaskR[b] = 1'b1;
			masked_puts++;
		end
`endif
		Cmd = put ? BECMD_Update : BECMD_Read; PAddr = key; CmdValid = 1;
		@(posedge Clock); t0 = cyc;
		@(negedge Clock); CmdValid = 0;
		if (put) begin
			for (int ch = 0; ch < CHUNKS; ch++) begin
				DataIn = pattern(key, opno, ch); DataInValid = 1;
				@(posedge Clock); while (!DataInReady) @(posedge Clock);
				@(negedge Clock);
				for (int by = 0; by < FEDWidth / 8; by++)
					if (WMaskR[ch * (FEDWidth / 8) + by]) ref_mem[key][ch][by*8 +: 8] = DataIn[by*8 +: 8];
			end
			DataInValid = 0;
			written[key] = 1;
			@(posedge Clock); while (!CmdReady) @(posedge Clock);
			nputs++;
		end else begin
			int ch = 0;
			while (ch < CHUNKS) begin
				@(posedge Clock);
				if (DataOutValid && DataOutReady) begin
					if (written[key] && DataOut !== ref_mem[key][ch]) begin
						if (errors < 10) $display("MISMATCH key %0d chunk %0d: got %x exp %x", key, ch, DataOut, ref_mem[key][ch]);
						errors++;
					end
					ch++;
				end
			end
			ngets++;
		end
		lat = cyc - t0;
	endtask

	longint lat;
`ifdef SEQ_FILE
	logic [15:0] seq [0:4095];
	int nseq = 0;
	initial begin : rdseq
		int fd, op, k, n; string fn; if (!$value$plusargs("seq=%s", fn)) fn = `SEQ_FILE; fd = $fopen(fn, "r"); n = 0;
		while (!$feof(fd) && n < 4096) begin if ($fscanf(fd, "%h %h\n", op, k) == 2) begin seq[n] = {k[7:0], 7'd0, op[0]}; n++; end end
		$fclose(fd); $display("SEQ %0d commands", n); nseq = n;
	end
`endif
	longint t_pre0, t_pre1, t_run1;
	initial begin
		void'($urandom(`SEED));
		for (int k = 0; k < NBLK; k++) written[k] = 0;
		$display("CONFIG ORAMB=%0d ORAML=%0d ORAMZ=%0d ORAMC=%0d FEDWidth=%0d BEDWidth=%0d EnableAES=%0d EnableREW=%0d EnableIV=%0d PLB=%0d PRF=%0d Recursion=%0d N=%0d",
			ORAMB, ORAML, ORAMZ, ORAMC, FEDWidth, BEDWidth, EnableAES, EnableREW, EnableIV, EnablePLB, PRFPosMap, Recursion, NBLK);
		$display("CONFIG bucket=%0d bursts (%0d header) = %0d B; path=%0d buckets = %0d B; DDRAWidth=%0d",
			BktSize_DRBursts, BktHSize_DRBursts, BktSize_DRBursts*64, ORAML+1, (ORAML+1)*BktSize_DRBursts*64, DDRAWidth);
`ifndef RST_CYC
	`define RST_CYC 10
`endif
		repeat (`RST_CYC) @(posedge Clock);
		Reset = 0;
		// wait for the DRAM initializer etc.
		@(posedge Clock); while (!CmdReady) @(posedge Clock);
		$display("INIT done at cycle %0d, DRAM bursts written %0d read %0d", cyc, wr_bursts, rd_bursts);
		// preload: PUT every block once, in order
		t_pre0 = cyc; rd0 = rd_bursts; wr0 = wr_bursts;
`ifdef SEQ_FILE
		if (0)
`endif
		for (int k = 0; k < NBLK; k++) begin access(1, k, k, lat); if (k % 64 == 63) $display("PROGRESS preload %0d at cycle %0d", k + 1, cyc); end
		t_pre1 = cyc;
		$display("PRELOAD %0d PUTs in %0d cycles; bursts rd %0d wr %0d", NBLK, t_pre1 - t_pre0, rd_bursts - rd0, wr_bursts - wr0);
		// random traffic
		rd0 = rd_bursts; wr0 = wr_bursts; nputs = 0; ngets = 0;
`ifdef SEQ_FILE
		#1;
		for (int i = 0; i < nseq; i++) begin
`else
		for (int i = 0; i < `NCMD; i++) begin
`endif
			bit put = $urandom % 2; int key = $urandom % NBLK;
			longint tc;
`ifdef SEQ_FILE
			put = seq[i][0]; key = seq[i][15:8];
`endif
`ifdef SAME_KEY
			put = `SAME_KEY_PUT; key = NBLK - 1;
`endif
			trace_clear(); tc = cyc;
`ifdef SHOW_CMDS
			$display("C %0d %s %0d cyc=%0d", i, put ? "PUT" : "GET", key, cyc);
`endif
			access(put, key, NBLK + i, lat);
`ifdef TRACE
			if (i < 6) begin
				repeat (30000) @(posedge Clock);   // let the backend drain so the trace covers the whole access
				$display("TRACE %s key %0d (t0=cmd): rdcmd %0d..%0d rddata %0d..%0d wrdata %0d..%0d dataout %0d..%0d lat %0d",
					put ? "PUT" : "GET", key, t_rc_first - tc, t_rc_last - tc, t_rd_first - tc, t_rd_last - tc,
					t_wr_first - tc, t_wr_last - tc, t_do_first - tc, t_do_last - tc, lat);
			end
`endif
`ifdef FIXED_GAP
			repeat (`FIXED_GAP) @(posedge Clock);
`endif
`ifdef IDLE_CHECK
			begin : idle_chk
				longint t_idle, wr_at_idle, rc_at_idle; int run;
				run = 0;
				while (run < 2) begin @(posedge Clock); run = core.Idle ? run + 1 : 0; end
				t_idle = cyc; wr_at_idle = t_wr_last; rc_at_idle = t_rc_last;
				repeat (300) @(posedge Clock);
				if (t_wr_last != wr_at_idle || t_rc_last != rc_at_idle || wq.size() != 0) begin
					$display("IDLE ERROR cmd %0d: DRAM activity after Idle (wr %0d -> %0d, rdcmd %0d -> %0d)", i, wr_at_idle, t_wr_last, rc_at_idle, t_rc_last);
					errors++;
				end
				if (i < 8) $display("IDLE cmd %0d %s: user-visible lat %0d, idle at +%0d, last write beat at +%0d", i, put ? "PUT" : "GET", lat, t_idle - tc, wr_at_idle - tc);
			end
`endif
			if (put) begin if (lat < put_min) put_min = lat; if (lat > put_max) put_max = lat; end
			else     begin if (lat < get_min) get_min = lat; if (lat > get_max) get_max = lat; end
			lat_sum += lat;
		end
		t_run1 = cyc;
		$display("RUN %0d cmds (%0d GET, %0d PUT) in %0d cycles = %0.1f cyc/cmd", `NCMD, ngets, nputs, t_run1 - t_pre1, real'(t_run1 - t_pre1) / `NCMD);
		$display("RUN latency GET %0d..%0d PUT %0d..%0d", get_min, get_max, put_min, put_max);
		$display("RUN DRAM bursts rd %0d wr %0d -> %0.1f KB read + %0.1f KB written per cmd; max read backlog %0d beats",
			rd_bursts - rd0, wr_bursts - wr0, (rd_bursts - rd0) * 64.0 / 1024 / `NCMD, (wr_bursts - wr0) * 64.0 / 1024 / `NCMD, max_rq);
		$display("MASKED PUTS %0d", masked_puts);
		if (errors == 0) $display("RESULT PASS"); else $display("RESULT FAIL errors=%0d", errors);
		$finish;
	end

	initial begin
		`ifndef WD_NS
		`define WD_NS 64'd200_000_000
`endif
		#(`WD_NS);   // watchdog (ns)
		$display("RESULT FAIL watchdog at cycle %0d", cyc);
`ifdef DUMP_STATE
		$display("DUMP CmdReady=%b uoram: Preparing=%b Accessing=%b ExpProg=%b Fake=%b PPPCmdReady=%b | PPP: Init=%b Busy=%b PLBReady=%b",
			CmdReady, core.front_end.uoram.Preparing, core.front_end.uoram.Accessing, core.front_end.uoram.ExpectingProgramData,
			core.front_end.uoram.FakeAccess, core.front_end.uoram.PPPCmdReady, core.front_end.uoram.PPP.PosMapInit,
			core.front_end.uoram.PPP.PosMapBusy, core.front_end.uoram.PPP.PLBReady);
		$display("DUMP iv.CS=%0d becore.control.CS=%0d stash.CS=%0d stash.core.CS=%0d stashtop.CS=%0d BEnd_CmdValid=%b BEnd_CmdReady=%b",
			core.front_end.MAC.iv.CS, core.back_end.bend_core.control.CS, core.back_end.bend_core.stash_top.stash.CS,
			core.back_end.bend_core.stash_top.stash.core.CS, core.back_end.bend_core.stash_top.CS, core.BEnd_CmdValid, core.BEnd_CmdReady);
		$display("DUMP stash errors BNF=%b ISC1=%b ISC2=%b ISC3=%b ISC4=%b OVF=%b BOGUSU=%b OVFC=%b occupancy=%0d",
			core.back_end.bend_core.stash_top.stash.ERROR_BlockNotFound, core.back_end.bend_core.stash_top.stash.ERROR_ISC1,
			core.back_end.bend_core.stash_top.stash.ERROR_ISC2, core.back_end.bend_core.stash_top.stash.ERROR_ISC3,
			core.back_end.bend_core.stash_top.stash.ERROR_ISC4, core.back_end.bend_core.stash_top.stash.ERROR_StashOverflow,
			core.back_end.bend_core.stash_top.stash.ERROR_BOGUSU, core.back_end.bend_core.stash_top.stash.ERROR_StashOverflowConservative,
			core.back_end.bend_core.stash_top.stash.StashOccupancy);
`endif
		$finish;
	end
endmodule
