# v14d: the 4 KB on-package budgets at every record count up to 2M

**In short.**

- **Cause.** Your throughput reading does not hold. Your serialization reading does, but the serialization happens in the HBM switch, not in the stash's issue order.
  - The stash port is 256 bits (32 B per cycle: 9.6 GB/s at 300 MHz, 6.4 at 200), below one pseudo-channel's 14.4 GB/s. It never reads and writes at once.
  - The open already sends all its reads back to back, up to 24 in flight.
  - What serializes them is the single AXI ID. The HBM switch keeps same-ID reads in order across pseudo-channels, so a read to another channel waits until the earlier reads have returned.
  - Heads and metadata sit on the stash's first channel, while the 4 KB blocks spread over all of them. At 2M records the blocks span four channels instead of two, so a full-window open switches channel 11–15 times instead of 7–11.
- **Design A (this package's default).** Decisions wait only for the metadata. The open reads all metadata first, then the window's blocks in eviction order. `ready` no longer waits for the blocks; each copy waits only for its own block.
  - Deadline (1) goes back to its floor (299 cycles in simulation), whatever the stash's speed.
  - The blocks only have to keep ahead of the bucket write, which is deadline (2).
  - No new port, no link change, no host change.
- **Design B (`STASH_IDS=1`).** A, plus one AXI ID per pseudo-channel on the stash port, so reads to different channels never wait for each other. This attacks the cause. It needs `ARID/RID` on the gmem5 port; the host is unchanged.
- **A + RAMA (`CFG=doma_big2m_rama.cfg`).** A's RTL, with AMD's RAMA IP on the stash port: a link change only.
- **Stage B of the request (striped ports) is dropped**, as agreed: A alone fits the budgets at 2M.
- **Budgets unchanged:** 1228 / 2384 / 2818. Every request's visible times (read issue, write-back start, release, end) are cycle-identical to v14c at every block size; the timing hashes are in §4.

## 1. Root cause

### 1.1 What the port asks for, and what it is given

| | Value |
|---|---|
| Stash port width | 256 bits (`stash_hbm.v` `AXI_DW = 256`, `kernel.xml` `dataWidth="256"`) |
| Demand at 300 / 250 / 200 MHz | 9.6 / 8.0 / 6.4 GB/s, at most one beat per cycle |
| One pseudo-channel's peak | 14.4 GB/s |
| Reads and writes at once | never: the stash reads only after every write is acknowledged |

A per-channel cap of 14.4 GB/s therefore never binds. The regression's channel model confirms it: with the cap on every stash and bucket channel, 0 beats were held.

The 200 MHz pass does not come from a lower demand. The budgets are fixed in cycles, so at 200 MHz they are 1.5× longer in nanoseconds. Your 250 MHz test is the fingerprint: the write-back start scales with the clock, so the stash's time is fixed in nanoseconds.

### 1.2 The serialization

**The open's reads, today (v14c):**
- Level 1, back to back: head(b), head(bt), the requested block's meta and data, the free head's meta.
- Level 2, once head(b) has landed: for each window entry its meta and then its 4 KB data, three cycles per entry; then the chain head.
- At most 24 reads, all outstanding at once (tag queue of 32). The kernel's issue order is not the limit.

**What holds them up:** the HBM side.
- PG276: "transactions with the same ID are blocked on a channel level and execute in the order in which they are received", and each memory controller "processes commands independently".
- The kernel drives no AXI ID, so every stash read has ID 0.
- AMD's own Vitis HBM tutorial (BW explorations) measures random reads from one single-ID port:

| Transaction size | 1 channel | 2 channels | 4 channels | 4 channels, with RAMA |
|---|---|---|---|---|
| 512 B | 13.1 GB/s | 4.5 GB/s | 3.5 GB/s | 13.8 GB/s |
| 1 KB | 13.2 GB/s | 6.5 GB/s | 5.5 GB/s | 14.1 GB/s |

The card's effective stash rate in the late opens is about 5–6 GB/s at 1M records (two channels) and lower at 2M (four channels). The platform splits each 4 KB burst into 512-byte HBM transactions.

### 1.3 Why 2M records is slower than 1M (`sim/v14d_model/stash_traffic.py`)

The model replays the stash unit at card scale: the XRT layout, host_phases' preload and MIX streams, and fresh-first allocation, which uses every pool entry.

| | 1M records | 2M records |
|---|---|---|
| Stash buffer | 1,008 MiB: HBM[12:13] | 1,994 MiB: HBM[12:15] |
| Heads + metadata | 8.5 MiB, first channel | 16.9 MiB, first channel |
| Window data by channel, MIX (12 / 13 / 14 / 15) | 42 / 58 / – / – % | 19 / 24 / 29 / 29 % |
| Channel switches per open, windows of ≥ 7 entries (typical) | 7–11 | 11–15 |

- Every window entry is a metadata read on the first channel followed by a data read anywhere. More channels mean more switches per open, each one a wait for the reads still out.
- The count grows smoothly with the record count, because the share of blocks off the first channel does. That matches your measured 1.25M / 1.5M / 1.75M steps, with no jump at a channel boundary.
- It also explains why the second memory controller brings nothing: with one ID, reads to two controllers never overlap.

### 1.4 Why the preload is worse than MIX

The window sizes differ, at both record counts:

| Window entries read | 8 | 9 |
|---|---|---|
| Preload (1M / 2M) | 0.42 / 0.43 % | 0.30 / 0.32 % |
| MIX (1M / 2M) | 0.39 / 0.39 % | 0.14 / 0.14 % |

The preload has 2.2× as many full windows. After the random boot placement, each key is requested exactly once, in key order, so the boot's waiting blocks are met at their fullest. Eviction counts match your card's class split to within a few tenths of a percent.

### 1.5 How well the model fits

The single-ID blocking model reproduces every pattern:
- lateness driven by this access's own window;
- every class slower at 2M;
- a gradual growth with the record count;
- the preload worse than MIX.

With one latency parameter it does not fit the size of the shift (`deadline2.py` prints the fit). So the fix is chosen not to depend on the HBM switch at all.

## 2. Design A

### 2.1 What changes (`rtl/stash_hbm.v`, `rtl/flat_oram_gcm.v`)

- **Issue order.**
  - Level 1: the heads, the requested block's meta, the free head's meta, then the requested block's data.
  - Level 2: the meta of every window entry, then the chain head, then the window's data, slot by slot, which is eviction order.
  - With one in-order ID, all metadata now lands before any window data.
- **`ready`** waits for the metadata and the requested block only (`md_done`). Window data lands afterwards, and a `landed` vector reports each staging slot.
- **Eviction candidates** need only their slot address, which comes with their meta (`g_mland`).
- **The controller's copy engine** starts a copy only once its block has landed. The on-package write-back already streams behind the copies, so a late block holds the write, never a decision.
- **Staging is split into two memories** of the same total size: window slots, and slot 0 plus the insert slots. Window data landing after `ready` therefore never meets a controller write. Resources are unchanged: 16 slots of 4 KB, one write port and two read ports each.
- **Unchanged:** the commit write-back waits for every read to finish, then writes as before. The next open still waits for every write to be acknowledged.
- **Outstanding stash reads per open:** at most 24 before and after (5 at level 1, 9 window metas, the chain head, 9 window blocks). Design B splits them over 4 IDs, up to 32 per ID.

### 2.2 The cycle model of what changes

All times are in cycles. t_o is the open, t_a the arrival, RT a round trip, and B_k the time for block k's 128 beats.

| | v14c | v14d (A) |
|---|---|---|
| Stash ready | t_o + RT₁ + RT₂ + Σ B_k (every block) | t_o + RT₁ + RT₂ + (the requested block, if stashed) |
| Write-back start (deadline 1) | t_a + decisions, after max(t_a, ready) | the same, with the new ready: back to the floor |
| Block k lands | before ready | t_ready' + Σ_{j ≤ k} B_j (in eviction order) |
| Copy k done | queue order | c_k = max(land_k, c_{k-1}) + 128 |
| Position k written | w_k = w_{k-1} + 128 | w_k = max(w_{k-1}, c_k) + 128 |
| Release gate (deadline 2) | write-back start + 1,029 | write-back start + 1,029 + the write's hold |

In the simulation (`tb_doma_kernel`, 512 records, preload + 500 accesses, debug build):
- **Accesses whose open reads no window data** (381): every timestamp is cycle-identical to v14c (stash ready, write-back start, release gate, release).
- **Accesses with window data** (684):
  - stash ready up to 1,161 cycles earlier (mean 266);
  - write-back start within 3 cycles of v14c's (the eviction loop no longer pauses while a block lands);
  - release identical.

### 2.3 Deadline (1) at 2M: back to the floor

| Run | v14c: write-back start / release gate | A: write-back start / release gate |
|---|---|---|
| 4,096 records, preload + 4,000 accesses, no channel model | 381 / 1,410 | 299 / 1,328 |
| Same, stash over 1.99 channels (1M layout), one ID kept in order, 14.4 GB/s cap | 1,384 / 2,413: misses (1) 3×, (2) 1× | 299 / 1,328 |
| Same, 3.90 channels (2M layout) | 1,384 / 2,413: misses (1) 3×, (2) 1× | 299 / 1,328 |

At card scale (`design_e_check.py`), A's metadata is ready 630–1,210 cycles **before** the arrival, at 1M and 2M, even with a 600 ns latency per channel switch.

### 2.4 Deadline (2) at 2M, 8 copies, at the card's effective rate

**The rate.** v14c's slowest open at 2M was the preload's 1,745-cycle write-back start. That is a stash ready about 1,441 cycles after the arrival (decisions take about 304, the card's 1M value), so about 2,755 cycles from issue to the last block of a full window. That works out to about **0.44 beats per cycle (4.2 GB/s)** in the worst access.

**The test.** The `tb_ni +worst` directed cases run with every bucket on package and the stash slowed to that rate (56% read-data gaps, 120-cycle latency). They include 8 evictions into an empty bucket, where all 8 copies are needed from the first position on, and full 9-entry windows.

| Stash rate (beats per cycle) | A: write-back start | A: release gate | With 10% + 74 | v14c |
|---|---|---|---|---|
| 0.44 (the card's 2M worst) | 299 | **1,551** | 1,780 ≤ 2,384 | halts |
| 0.36 | 299 | 2,134 | 2,421 | – |
| 0.30 | – | halts on deadline (2) | – | – |

- A covers the card's worst observed rate with about 600 cycles to spare at the 10% margin. It breaks only if the worst access gets slower than about 0.37 beats per cycle.
- The test is pessimistic for A. A's own order removes about half the channel switches (no metadata between the blocks), so on the card its blocks come faster than v14c's did.
- Designs B and RAMA raise the rate itself.

### 2.5 The bucket port

The bottleneck does not move to the copies' writes. Each bucket write is 32 KB to one channel at one beat per cycle (9.6 GB/s, under 14.4), unchanged from v14c. In the channel-model runs the bucket port's channel cap held 0 beats. The copies feed the write from on-chip staging at one beat per cycle.

## 3. Design B and A + RAMA

### 3.1 B: one AXI ID per pseudo-channel (`STASH_IDS=1`: `ORAM_STASH_PC_IDS`)

- **The ID** is the read's channel within the stash buffer: address bits [30:29], 512 MiB channels. XRT concatenates a port's channels, and the 2 GB stash buffer is the only buffer on HBM[12:15], so it starts at HBM[12].
- **Correctness does not depend on the mapping.** Any read may carry any ID; only the speed does.
- **Per ID:** an in-order tag queue (32 entries), a registered head and a beat counter. Responses of different IDs may return in any order, even beat-interleaved.
- **Writes** use ID 0. The stash reads only after every write's B, as before.
- **Ports:** `doma_kernel` gains `m_axi_gmem5_arid/rid/awid/bid` (2 bits) under the define. `package_kernel.tcl` infers them into `m_axi_gmem5`. `kernel.xml` and the host programs are unchanged.
- **Without the define,** the logic is A's (one queue).
- **What only the card can tell** is whether the platform's memory subsystem, between the kernel and the HBM ports, passes distinct IDs through or compresses them to one thread.
  - The debug build's stash records show it directly: word 6, the longest read, and word 9, the cycles with reads out and no beat.
  - If the IDs are compressed, B behaves exactly like A.
- **Verified:**
  - The unit test runs with the model returning reads of different IDs in random order and interleaved every 16 beats: 6 runs, up to 100,000 accesses, 83,800 reads overtaking an older one, every check passed.
  - The kernel test at 4,096 records over 4 scaled channels, oldest-first and random/interleaved: every GET correct, no deadline missed, 299 / 1,328.

### 3.2 A + RAMA (`CFG=doma_big2m_rama.cfg`)

- **The link line:** `sp=doma_kernel_1.stash:HBM[12:15].12.RAMA`, the syntax of AMD's `hbm_rama_ip` example.
- **What RAMA does:** it substitutes IDs, lets the channels answer out of order, and restores request order before the kernel. AMD's numbers are in §1.2.
- **Visible cycles:** none change. Every access releases at its fixed time.
- **Internal timing:** RAMA adds latency to every stash read and write, on both paths. Its value is not published. The slack is ample: under A, the metadata is ready 600–1,200 cycles before an on-package arrival, and an off-package bucket arrives later still.
- **Utilization:** RAMA is in the platform's memory subsystem, not in `doma_kernel`, so the kernel utilization the paper reports is unchanged. If a RAMA build is the one measured, report its cost too. `vitis/rama_utilization.tcl` prints the RAMA cells' and the kernel's LUT / FF / BRAM / URAM / DSP from the routed checkpoint.
- **Unverified here:** RAMA's documented transaction limit is 512 B. Check the v++ link log for the RAMA instance and any burst-conversion warnings. If the link rejects it, design A stands alone.

### 3.3 Which should perform best

At the current budgets all three perform identically. After recalibrating, the worst release gate decides how far AR_REL_H can fall:
- **A:** about 1,780 at the 10% margin from the card-rate test.
- **B and A + RAMA:** toward 1,330 + 10% + 74 ≈ 1,535, if they lift the rate.

B carries no added latency and few resources, so it is the first choice if the platform honors IDs.

## 4. Visible times: cycle-identical at every size

`tb_doma_kernel`, production arrival build (λ = 7), three configurations per block size:
- (1) every bucket on package, preload + 200 + 4;
- (2) 20% on package, PCIe-like host latency, preload + 120 + 40;
- (3) 50% on package, 200 + 10.

Each compares every bucket-port timing hash (the AR/AW times, so read issue and write-back start), every off-package access-shape hash, every on-package release/end hash, and the device's total cycles, v14c1 against v14d.

| Block | Hash lines per tree | v14d vs v14c1 | Device cycles, run1 of each configuration | On-package release / end (cycles after the access start) |
|---|---|---|---|---|
| 4 KB | 30 | A identical; B identical; B with out-of-order, interleaved IDs identical | 828,288 / 578,613 / 913,329 | 3,738 / 3,869 |
| 2 KB | 30 | A identical; B identical | 452,288 / 341,138 / 524,954 | 2,050 / 2,117 |
| 1 KB | 30 | A identical | 308,888 / 226,693 / 351,953 | 1,429 / 1,464 |
| 512 B | 30 | A identical | 248,688 / 176,418 / 277,002 | 1,176 / 1,195 |
| 256 B | 30 | A identical | 224,088 / 154,628 / 245,076 | 1,077 / 1,088 |
| 128 B | 30 | A identical | 211,688 / 143,768 / 229,112 | 1,027 / 1,034 |
| 64 B | 30 | A identical | 205,488 / 138,243 / 221,031 | 1,002 / 1,007 |
| 32 B | 30 | A identical | 202,488 / 135,303 / 216,843 | 990 / 994 |

"Identical" means byte-identical result files: every hash, every device cycle count, every latency min/max, every
per-launch result line. The script and the per-size outputs are in `docs/v14d_hashes/`.

- **A + RAMA** has A's RTL, so its simulated times are A's. On the card, RAMA can change only when the stash's reads
  land. Every visible time is set by a fixed point:
  - read issue: CT_RD;
  - off-package write-back start and release: t_arr + AR_WB / AR_REL;
  - on-package release: t_arr + AR_REL_H.

  RAMA can therefore change a visible time only through an overrun, which halts. It is not on the bucket port at all.
- **Consequence:** with the budgets unchanged, only the on-package internals change (when the stash is ready, when
  blocks land, when copies start). Your existing measurements at every size stay valid for v14d.
- The regression's own hash lines match too. At 4 KB:
  - NI trace hashes 51c6213b1147687d / c537d46b5491598f;
  - arrival GET/PUT bucket-port hash bd809ba8947b70db;
  - strict e48f932135cb882b;
  - on-package release/end hash 7b6e46063502ed3d.

## 5. Which sizes to rebuild

The change is in `stash_hbm.v` and `flat_oram_gcm.v`, which every size compiles.

- **4 KB: rebuild.** This is where 2M failed.
- **2 KB: rebuild, and validate it at 2M.** It was calibrated at 1M only. It has the same exposure: a full window is 9 × 2 KB, against a bucket read of 16 KB, so its stash lead is about half the 4 KB one. Under v14c it is likely to miss at 2M.
- **64 B – 1 KB: rebuild when convenient.**
  - Their visible times are identical to v14c's (§4), so your existing measurements at those sizes stay valid as they are. A v14d bitstream would give the same cycles per request.
  - Rebuilding them makes the design one design across sizes, which the paper's description of the stash assumes.
  - Their v14c bitstreams already pass at 2M.
- **No size needs new budgets.** The default `calibrate_all_sizes.sh` sizes keep theirs. 4 KB's calibration run (below) only confirms them, and can lower them later if you choose.

## 6. Budgets and calibration at 2M

`rtl/oram_params.vh` is unchanged: AR_WB_H 1228, AR_REL_H 2384, AR_DONE_H 2818 (4 KB, λ = 7).

`vitis/calibrate_all_sizes.sh` changes:
- **4 KB at 2M:** size 128 is accepted. Its defaults are `NMAX_128=2097152`, `DOMA_N_128=2097151` (the largest multiple of 7 the build serves; the stash then spans all of HBM[12:15], its slowest layout), `PCTS_128="20 50"` (100% does not fit in HBM at 4 KB and 2M), and `CFG_128=doma_big2m.cfg`.
- **The run-step fix:** host_phases now runs from the calibrated build's own `vitis/` folder, so its lambda check reads that build's `rtl/oram_build_cfg.vh`, not the main tree's empty one. It also passes `DOMA_NMAX`.

```bash
cd vitis
STASH_IDS=0 bash calibrate_all_sizes.sh build 128    # 4 KB debug bitstream at NMAX 2,097,152 (add STASH_IDS=1 for B, CFG_128=doma_big2m_rama.cfg for RAMA)
bash calibrate_all_sizes.sh timing 128
ACC=2097152 bash calibrate_all_sizes.sh run 128      # 20% and 50% on package, preload + 2M MIX each, per-access records
bash calibrate_all_sizes.sh report 128               # card_budgets.py: worst write-back start, release gate, budgets at 10%
```

The debug records keep their format. Word 15 ("the open complete") now marks `ready`, which is the metadata. Word 5 (the last read beat) can come after it, because the window's data lands later.

## 7. Regression

`docs/v14d_regression_lambda7_4KB_partial.txt` (4 KB, λ = 7, design A): every group up to and including arrival passed, 0 FAIL (units, crypto, self-test and tamper, NI, stress and calibration, backpressure, secure build, derived worst case, combined adverse case, host-wait, kernel, boot, arrival). The onpkg group, including the new pseudo-channel checks, was still running at delivery. v14c1's own run on this machine: 66 PASS, 0 FAIL. Design B's unit and kernel checks were run outside the script (§3.1); `run_verilator.sh` now includes them (units, onpkg (i)).

New and changed checks:
- **units:** stash_hbm's tests run unchanged, and with slow read data (`+rgap`, `+rlat`), where decisions start before the data and block reads wait for their landing. Design B's unit tests run with out-of-order, interleaved IDs.
- **onpkg (i), new:**
  - The stash over HBM pseudo-channels at the 1M and 2M layouts, one ID kept in order across channels, every channel capped at 14.4 GB/s, every bucket on package: no overrun, every GET correct, release and end fixed. The same at 2M with 150-cycle stash reads.
  - The debug build's worst write-back start and release gate at 2M, against the budgets at 10% + 74.
- **Memory model** (`sim/axi_mem_model.v`, all off by default): pseudo-channels (`pc_bytes`), single-ID ordering across channels (`id_block`), a per-channel byte cap (`pc_cap_x100`), and independent IDs with out-of-order and interleaved return (`id_ooo`, `id_ilv`).
- **Testbench options:**
  - `tb_doma_kernel`: `+stash_pcs`, `+stash_pcb`, `+stash_idblk`, `+hbm_pccap`, `+hbmb_pc`, `+hbmb_idblk`, `+stash_ooo`, `+stash_ilv`, `+stash_log`.
  - `tb_ni`: `+stash_gap`, `+stash_pc`, `+stash_idblk`.

## 8. Build commands (4 KB, λ = 7, arrival)

```bash
cd vitis
# design A
CFG=doma_big2m.cfg NMAX=2097152 LAMBDA=7 SCHED=arrival TRACE=1 DEBUG=1 bash build.sh     # debug (calibration)
CFG=doma_big2m.cfg NMAX=2097152 LAMBDA=7 SCHED=arrival bash build.sh                     # production
CFG=doma_big2m.cfg NMAX=2097152 LAMBDA=7 SCHED=arrival TRACE=1 bash build.sh             # traced
# design B: the same three with STASH_IDS=1
# A + RAMA: the same three with CFG=doma_big2m_rama.cfg; then: vivado -mode batch -source rama_utilization.tcl
```

Build each variant in its own folder, as before. The host programs are unchanged for all three. Run with `DOMA_LAMBDA=7 DOMA_N=<n ≤ 2,097,151> DOMA_NMAX=2097152`, and 20% or 50% on package at 4 KB and 2M.

## Sources

- AMD PG276, AXI HBM Controller, *System-Level Considerations*: https://docs.amd.com/r/en-US/pg276-axi-hbm/System-Level-Considerations
- AMD RAMA IP: https://www.amd.com/en/products/adaptive-socs-and-fpgas/intellectual-property/rama.html
- AMD Vitis HBM tutorial, *BW explorations*: https://xilinx.github.io/Vitis-Tutorials/master/docs-jp/docs/Hardware_Acceleration/Feature_Tutorials/07-using-hbm/3_BW_Explorations.html
- AMD Vitis_Accel_Examples `hbm_rama_ip`: https://xilinx.github.io/Vitis_Accel_Examples/2022.1/html/hbm_rama_ip.html
