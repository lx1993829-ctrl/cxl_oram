#!/bin/bash
# build_hosts.sh -- compile the unmodified host programs (vitis/host_ycsb.cpp, vitis/host_doma.cpp) against the mock XRT
# and the Verilated doma_kernel (build_model.sh first). Outputs: host_ycsb_sim, host_doma_sim.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"; VDIR="${OUT:-$HERE/obj_dir}"
VR="$(verilator --getenv VERILATOR_ROOT)"
CXX="g++ -std=c++17 -O2 -ffp-contract=off -I$HERE -I$VDIR -I$VR/include -I$VR/include/vltstd"
$CXX -c "$HERE/xrt_mock.cpp" -o "$HERE/xrt_mock.o"
for h in ${HOSTS:-ycsb doma phases}; do   # HOSTS=fault: host_fault (v14d build B; build_model.sh FAULT=1)
    $CXX "$HERE/../../vitis/host_$h.cpp" "$HERE/xrt_mock.o" "$VDIR/libVdoma_kernel.a" "$VDIR/libverilated.a" -pthread -o "$HERE/host_${h}_sim"
done
ls -l "$HERE"/host_*_sim
