// doma_kernel.v -- Vitis RTL kernel wrapper for DOMA (single-client build).
//
// Calling convention (mirrors BOLT's chain_kernel so one XRT host program drives both):
//   doma_kernel(cmd_input, resp_output, pages, size, meta, brec, stash, nblk, pages_hbm, hbm_bkts, pool_n)
//     cmd_input   (m_axi_gmem0, HBM)   commands, read
//     resp_output (m_axi_gmem1, HBM)   responses, written
//     pages       (m_axi_gmem2, HOST)  DOMA's encrypted buckets in host memory
//     size        (scalar)             number of commands in this run
//     meta        (m_axi_gmem3, HBM)   DOMA's trusted metadata (position map), in on-package HBM
//     brec        (m_axi_gmem4, HBM)   bucket records (bucket metadata + per-position IV/tag), in HBM
//     stash       (m_axi_gmem5, HBM)   the stash: per-bucket lists + block pool, in HBM
//
// Control registers (s_axi_control, Vitis ap_ctrl_hs layout):
//   0x00 CTRL  bit0 ap_start  bit1 ap_done (clear on read)  bit2 ap_idle  bit3 ap_ready (clear on read)
//   0x04 GIE   0x08 IER  0x0C ISR (bit0 done, toggle on write)
//   0x10/0x14 cmd_input   0x1C/0x20 resp_output   0x28/0x2C pages   0x34 size   0x3C/0x40 meta   0x48/0x4C brec   0x54/0x58 stash   0x60 nblk (blocks; 0 = the build's maximum)   0x68/0x6C pages_hbm   0x74 hbm_bkts   0x7C pool_n (stash pool entries)
//
// Buffer layout (32-byte aligned; the host converts BOLT's packets before timing starts):
//   cmd_input   [0, size*32)                     headers: byte0 type (0x01 GET, 0x02 PUT), bytes 4-7 key
//               [HC, HC + size*BLOCK)            PUT data, entry i at HC + i*BLOCK, HC = roundup(size*32, 4 KB)
//   resp_output [0, (size+2)*32)                 headers: byte0 0x10 ACK / 0x11 ERR, bytes 4-7 key,
//                                                bytes 8-11 latency (cycles, request to completion),
//                                                bytes 12-15 status flags
//                                                record [size] = summary: byte0 0x5A, bytes 8-15 total cycles,
//                                                16-19 min latency, 20-23 max latency, 24-27 error flags,
//                                                28-31 commands completed
//                                                record [size+1] = traffic: byte0 0x5B, bytes 8-15 read beats and
//                                                bytes 16-23 write beats on gmem2 (the bucket port) during the launch
//               [HR, HR + size*BLOCK)            GET data, entry i at HR + i*BLOCK, HR = roundup((size+2)*32, 4 KB)
// Keys are dense slot numbers 0..N-1; a key outside the ORAM is rejected by DOMA (ERR).
// DOMA boots at the FIRST ap_start, and boots again at every launch with size 0 (an init launch: the DOMA
// core is reset first): the pages, meta, brec and stash addresses and nblk given then are latched until
// the next init launch (summary error 0x20 if a launch with commands names a different buffer).
// The AES key and IV seed are fixed prototype stand-ins, as key provisioning is out of scope.
`timescale 1ns/1ps
`include "oram_params.vh"

module doma_kernel #(
    parameter integer C_S_AXI_CONTROL_ADDR_WIDTH = 12,
    parameter integer C_M_AXI_ADDR_WIDTH         = 64,
    parameter integer C_M_AXI_DATA_WIDTH         = `AXI_DATA_W,
    parameter [127:0] AES_KEY     = 128'h000102030405060708090a0b0c0d0e0f,
    parameter [95:0]  AES_IV_SEED = 96'h0123456789abcdef01234567,
    parameter integer CMD_TIMEOUT = 2000000          // cycles a command may take before the run aborts
) (
    input  wire                                    ap_clk,
    input  wire                                    ap_rst_n,
    // ---------------- AXI4-Lite control ----------------
    input  wire [C_S_AXI_CONTROL_ADDR_WIDTH-1:0]   s_axi_control_awaddr,
    input  wire                                    s_axi_control_awvalid,
    output wire                                    s_axi_control_awready,
    input  wire [31:0]                             s_axi_control_wdata,
    input  wire [3:0]                              s_axi_control_wstrb,
    input  wire                                    s_axi_control_wvalid,
    output wire                                    s_axi_control_wready,
    output wire [1:0]                              s_axi_control_bresp,
    output reg                                     s_axi_control_bvalid,
    input  wire                                    s_axi_control_bready,
    input  wire [C_S_AXI_CONTROL_ADDR_WIDTH-1:0]   s_axi_control_araddr,
    input  wire                                    s_axi_control_arvalid,
    output wire                                    s_axi_control_arready,
    output reg  [31:0]                             s_axi_control_rdata,
    output wire [1:0]                              s_axi_control_rresp,
    output reg                                     s_axi_control_rvalid,
    input  wire                                    s_axi_control_rready,
    output wire                                    interrupt,
    // ---------------- m_axi_gmem0: commands (read) ----------------
    output reg  [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem0_araddr,
    output reg  [7:0]                              m_axi_gmem0_arlen,
    output wire [2:0]                              m_axi_gmem0_arsize,
    output wire [1:0]                              m_axi_gmem0_arburst,
    output reg                                     m_axi_gmem0_arvalid,
    input  wire                                    m_axi_gmem0_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem0_rdata,
    input  wire [1:0]                              m_axi_gmem0_rresp,
    input  wire                                    m_axi_gmem0_rlast,
    input  wire                                    m_axi_gmem0_rvalid,
    output wire                                    m_axi_gmem0_rready,
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem0_awaddr,
    output wire [7:0]                              m_axi_gmem0_awlen,
    output wire [2:0]                              m_axi_gmem0_awsize,
    output wire [1:0]                              m_axi_gmem0_awburst,
    output wire                                    m_axi_gmem0_awvalid,
    input  wire                                    m_axi_gmem0_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem0_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem0_wstrb,
    output wire                                    m_axi_gmem0_wlast,
    output wire                                    m_axi_gmem0_wvalid,
    input  wire                                    m_axi_gmem0_wready,
    input  wire [1:0]                              m_axi_gmem0_bresp,
    input  wire                                    m_axi_gmem0_bvalid,
    output wire                                    m_axi_gmem0_bready,
    // ---------------- m_axi_gmem1: responses (write) ----------------
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem1_araddr,
    output wire [7:0]                              m_axi_gmem1_arlen,
    output wire [2:0]                              m_axi_gmem1_arsize,
    output wire [1:0]                              m_axi_gmem1_arburst,
    output wire                                    m_axi_gmem1_arvalid,
    input  wire                                    m_axi_gmem1_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem1_rdata,
    input  wire [1:0]                              m_axi_gmem1_rresp,
    input  wire                                    m_axi_gmem1_rlast,
    input  wire                                    m_axi_gmem1_rvalid,
    output wire                                    m_axi_gmem1_rready,
    output reg  [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem1_awaddr,
    output reg  [7:0]                              m_axi_gmem1_awlen,
    output wire [2:0]                              m_axi_gmem1_awsize,
    output wire [1:0]                              m_axi_gmem1_awburst,
    output reg                                     m_axi_gmem1_awvalid,
    input  wire                                    m_axi_gmem1_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem1_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem1_wstrb,
    output wire                                    m_axi_gmem1_wlast,
    output reg                                     m_axi_gmem1_wvalid,
    input  wire                                    m_axi_gmem1_wready,
    input  wire [1:0]                              m_axi_gmem1_bresp,
    input  wire                                    m_axi_gmem1_bvalid,
    output wire                                    m_axi_gmem1_bready,
    // ---------------- m_axi_gmem2: DOMA buckets (host memory) ----------------
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem2_araddr,
    output wire [7:0]                              m_axi_gmem2_arlen,
    output wire [2:0]                              m_axi_gmem2_arsize,
    output wire [1:0]                              m_axi_gmem2_arburst,
    output wire                                    m_axi_gmem2_arvalid,
    input  wire                                    m_axi_gmem2_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem2_rdata,
    input  wire [1:0]                              m_axi_gmem2_rresp,
    input  wire                                    m_axi_gmem2_rlast,
    input  wire                                    m_axi_gmem2_rvalid,
    output wire                                    m_axi_gmem2_rready,
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem2_awaddr,
    output wire [7:0]                              m_axi_gmem2_awlen,
    output wire [2:0]                              m_axi_gmem2_awsize,
    output wire [1:0]                              m_axi_gmem2_awburst,
    output wire                                    m_axi_gmem2_awvalid,
    input  wire                                    m_axi_gmem2_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem2_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem2_wstrb,
    output wire                                    m_axi_gmem2_wlast,
    output wire                                    m_axi_gmem2_wvalid,
    input  wire                                    m_axi_gmem2_wready,
    input  wire [1:0]                              m_axi_gmem2_bresp,
    input  wire                                    m_axi_gmem2_bvalid,
    output wire                                    m_axi_gmem2_bready,
    // ---------------- m_axi_gmem6: DOMA buckets kept in HBM (fixed boundary: buckets 0 .. hbm_bkts-1) ----------------
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem6_araddr,
    output wire [7:0]                              m_axi_gmem6_arlen,
    output wire [2:0]                              m_axi_gmem6_arsize,
    output wire [1:0]                              m_axi_gmem6_arburst,
    output wire                                    m_axi_gmem6_arvalid,
    input  wire                                    m_axi_gmem6_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem6_rdata,
    input  wire [1:0]                              m_axi_gmem6_rresp,
    input  wire                                    m_axi_gmem6_rlast,
    input  wire                                    m_axi_gmem6_rvalid,
    output wire                                    m_axi_gmem6_rready,
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem6_awaddr,
    output wire [7:0]                              m_axi_gmem6_awlen,
    output wire [2:0]                              m_axi_gmem6_awsize,
    output wire [1:0]                              m_axi_gmem6_awburst,
    output wire                                    m_axi_gmem6_awvalid,
    input  wire                                    m_axi_gmem6_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem6_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem6_wstrb,
    output wire                                    m_axi_gmem6_wlast,
    output wire                                    m_axi_gmem6_wvalid,
    input  wire                                    m_axi_gmem6_wready,
    input  wire [1:0]                              m_axi_gmem6_bresp,
    input  wire                                    m_axi_gmem6_bvalid,
    output wire                                    m_axi_gmem6_bready,
    // gmem3: DOMA's metadata in HBM (position map)
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem3_araddr,
    output wire [7:0]                              m_axi_gmem3_arlen,
    output wire [2:0]                              m_axi_gmem3_arsize,
    output wire [1:0]                              m_axi_gmem3_arburst,
    output wire                                    m_axi_gmem3_arvalid,
    input  wire                                    m_axi_gmem3_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem3_rdata,
    input  wire [1:0]                              m_axi_gmem3_rresp,
    input  wire                                    m_axi_gmem3_rlast,
    input  wire                                    m_axi_gmem3_rvalid,
    output wire                                    m_axi_gmem3_rready,
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem3_awaddr,
    output wire [7:0]                              m_axi_gmem3_awlen,
    output wire [2:0]                              m_axi_gmem3_awsize,
    output wire [1:0]                              m_axi_gmem3_awburst,
    output wire                                    m_axi_gmem3_awvalid,
    input  wire                                    m_axi_gmem3_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem3_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem3_wstrb,
    output wire                                    m_axi_gmem3_wlast,
    output wire                                    m_axi_gmem3_wvalid,
    input  wire                                    m_axi_gmem3_wready,
    input  wire [1:0]                              m_axi_gmem3_bresp,
    input  wire                                    m_axi_gmem3_bvalid,
    output wire                                    m_axi_gmem3_bready,
    // gmem4: bucket records in HBM (bucket metadata + per-position IV/tag)
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem4_araddr,
    output wire [7:0]                              m_axi_gmem4_arlen,
    output wire [2:0]                              m_axi_gmem4_arsize,
    output wire [1:0]                              m_axi_gmem4_arburst,
    output wire                                    m_axi_gmem4_arvalid,
    input  wire                                    m_axi_gmem4_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem4_rdata,
    input  wire [1:0]                              m_axi_gmem4_rresp,
    input  wire                                    m_axi_gmem4_rlast,
    input  wire                                    m_axi_gmem4_rvalid,
    output wire                                    m_axi_gmem4_rready,
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem4_awaddr,
    output wire [7:0]                              m_axi_gmem4_awlen,
    output wire [2:0]                              m_axi_gmem4_awsize,
    output wire [1:0]                              m_axi_gmem4_awburst,
    output wire                                    m_axi_gmem4_awvalid,
    input  wire                                    m_axi_gmem4_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem4_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem4_wstrb,
    output wire                                    m_axi_gmem4_wlast,
    output wire                                    m_axi_gmem4_wvalid,
    input  wire                                    m_axi_gmem4_wready,
    input  wire [1:0]                              m_axi_gmem4_bresp,
    input  wire                                    m_axi_gmem4_bvalid,
    output wire                                    m_axi_gmem4_bready,
    // gmem5: the stash in HBM (per-bucket lists + block pool)
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem5_araddr,
    output wire [7:0]                              m_axi_gmem5_arlen,
    output wire [2:0]                              m_axi_gmem5_arsize,
    output wire [1:0]                              m_axi_gmem5_arburst,
    output wire                                    m_axi_gmem5_arvalid,
    input  wire                                    m_axi_gmem5_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem5_rdata,
    input  wire [1:0]                              m_axi_gmem5_rresp,
    input  wire                                    m_axi_gmem5_rlast,
    input  wire                                    m_axi_gmem5_rvalid,
    output wire                                    m_axi_gmem5_rready,
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem5_awaddr,
    output wire [7:0]                              m_axi_gmem5_awlen,
    output wire [2:0]                              m_axi_gmem5_awsize,
    output wire [1:0]                              m_axi_gmem5_awburst,
    output wire                                    m_axi_gmem5_awvalid,
    input  wire                                    m_axi_gmem5_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem5_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem5_wstrb,
    output wire                                    m_axi_gmem5_wlast,
    output wire                                    m_axi_gmem5_wvalid,
    input  wire                                    m_axi_gmem5_wready,
    input  wire [1:0]                              m_axi_gmem5_bresp,
    input  wire                                    m_axi_gmem5_bvalid,
    output wire                                    m_axi_gmem5_bready
);
    localparam integer DW     = C_M_AXI_DATA_WIDTH;
    localparam integer BEATS  = `BEATS_PER_BLOCK;
    localparam integer BLOCK  = BEATS * (DW / 8);            // bytes per block (4 KB)
    localparam integer BW     = $clog2(BEATS);
    localparam integer BWI    = (BW > 0) ? BW : 1;    // index width (a 1-beat block still needs one bit)
    localparam [2:0]   ASIZE  = $clog2(DW / 8);
    localparam [7:0]   T_GET = 8'h01, T_PUT = 8'h02, T_ACK = 8'h10, T_ERR = 8'h11, T_SUM = 8'h5A;
    wire rst = !ap_rst_n;

    // =====================================================================
    // AXI4-Lite control registers
    // =====================================================================
    reg        ap_start_r, ap_done_r, ap_ready_r, auto_restart_r, gie_r;
    reg  [1:0] ier_r, isr_r;
    reg [63:0] arg_cmd, arg_resp, arg_pages, arg_meta, arg_brec, arg_stash;
    reg [63:0] arg_pages_hbm;                                   // HBM bucket buffer (buckets 0 .. hbm_bkts-1)
    reg [31:0] arg_hbm_bkts;                                    // buckets in HBM (fixed boundary; 0 = none)
    reg [31:0] arg_pool_n;                                      // stash pool entries (0 or > n: n, cannot run out)
    reg [31:0] arg_nblk;                                        // run-time number of blocks (0: the build's maximum)
`ifdef DOMA_FAULT
    // ---- build B (DOMA_FAULT): fault-injection arguments, all 0 (disarmed) unless the host sets them. Offsets 0x084 ..
    //      0x0D4 (32-bit scalars, 8 bytes apart like hbm_bkts / pool_n); see docs/v14d_fault_build.md for the fields.
    reg [31:0] flt_ctl, flt_cmd, flt_p5, flt_p6, flt_p8, flt_p3, flt_p1k, flt_p1b, flt_p7x, flt_hs, flt_p6n;
`ifdef ORAM_PHASE_TRACE
    DOMA_FAULT_without_PHASE_TRACE u_no_trace ();              // build B is the production build plus hooks: no trace
`endif
`ifdef ORAM_ONPKG_DEBUG
    DOMA_FAULT_without_ONPKG_DEBUG u_no_debug ();
`endif
`ifdef ORAM_PLAIN
    DOMA_FAULT_without_PLAIN u_no_plain ();
`endif
`endif
    reg [31:0] arg_size;
    wire       ap_idle;
    reg        done_pulse;                                   // from the command engine

    wire wr_hs = s_axi_control_awvalid && s_axi_control_wvalid && !s_axi_control_bvalid;
    assign s_axi_control_awready = wr_hs;
    assign s_axi_control_wready  = wr_hs;
    assign s_axi_control_bresp   = 2'b00;
    assign s_axi_control_arready = !s_axi_control_rvalid;
    assign s_axi_control_rresp   = 2'b00;
    wire [7:0] wa = s_axi_control_awaddr[7:0];
    wire [7:0] ra = s_axi_control_araddr[7:0];
    function [31:0] wmask; input [31:0] oldv, newv; input [3:0] strb; integer b;
        begin wmask = oldv; for (b = 0; b < 4; b = b + 1) if (strb[b]) wmask[b*8 +: 8] = newv[b*8 +: 8]; end
    endfunction

    always @(posedge ap_clk) begin
        if (rst) begin
            ap_start_r <= 1'b0; ap_done_r <= 1'b0; ap_ready_r <= 1'b0; auto_restart_r <= 1'b0;
            gie_r <= 1'b0; ier_r <= 2'b00; isr_r <= 2'b00;
            arg_cmd <= 64'd0; arg_resp <= 64'd0; arg_pages <= 64'd0; arg_size <= 32'd0; arg_meta <= 64'd0; arg_brec <= 64'd0; arg_stash <= 64'd0; arg_nblk <= 32'd0; arg_pages_hbm <= 64'd0; arg_hbm_bkts <= 32'd0; arg_pool_n <= 32'd0;
            s_axi_control_bvalid <= 1'b0; s_axi_control_rvalid <= 1'b0; s_axi_control_rdata <= 32'd0;
        end else begin
            // writes
            if (wr_hs) begin
                s_axi_control_bvalid <= 1'b1;
                case (wa)
                    8'h00: begin
                        if (s_axi_control_wstrb[0] && s_axi_control_wdata[0]) ap_start_r <= 1'b1;
                        if (s_axi_control_wstrb[0]) auto_restart_r <= s_axi_control_wdata[7];
                    end
                    8'h04: if (s_axi_control_wstrb[0]) gie_r <= s_axi_control_wdata[0];
                    8'h08: if (s_axi_control_wstrb[0]) ier_r <= s_axi_control_wdata[1:0];
                    8'h0C: if (s_axi_control_wstrb[0]) isr_r <= isr_r ^ s_axi_control_wdata[1:0];
                    8'h10: arg_cmd[31:0]    <= wmask(arg_cmd[31:0],    s_axi_control_wdata, s_axi_control_wstrb);
                    8'h14: arg_cmd[63:32]   <= wmask(arg_cmd[63:32],   s_axi_control_wdata, s_axi_control_wstrb);
                    8'h1C: arg_resp[31:0]   <= wmask(arg_resp[31:0],   s_axi_control_wdata, s_axi_control_wstrb);
                    8'h20: arg_resp[63:32]  <= wmask(arg_resp[63:32],  s_axi_control_wdata, s_axi_control_wstrb);
                    8'h28: arg_pages[31:0]  <= wmask(arg_pages[31:0],  s_axi_control_wdata, s_axi_control_wstrb);
                    8'h2C: arg_pages[63:32] <= wmask(arg_pages[63:32], s_axi_control_wdata, s_axi_control_wstrb);
                    8'h34: arg_size         <= wmask(arg_size,         s_axi_control_wdata, s_axi_control_wstrb);
                    8'h3C: arg_meta[31:0]   <= wmask(arg_meta[31:0],   s_axi_control_wdata, s_axi_control_wstrb);
                    8'h40: arg_meta[63:32]  <= wmask(arg_meta[63:32],  s_axi_control_wdata, s_axi_control_wstrb);
                    8'h48: arg_brec[31:0]   <= wmask(arg_brec[31:0],   s_axi_control_wdata, s_axi_control_wstrb);
                    8'h4C: arg_brec[63:32]  <= wmask(arg_brec[63:32],  s_axi_control_wdata, s_axi_control_wstrb);
                    8'h54: arg_stash[31:0]  <= wmask(arg_stash[31:0],  s_axi_control_wdata, s_axi_control_wstrb);
                    8'h58: arg_stash[63:32] <= wmask(arg_stash[63:32], s_axi_control_wdata, s_axi_control_wstrb);
                    8'h60: arg_nblk         <= wmask(arg_nblk,         s_axi_control_wdata, s_axi_control_wstrb);
                    8'h68: arg_pages_hbm[31:0]  <= wmask(arg_pages_hbm[31:0],  s_axi_control_wdata, s_axi_control_wstrb);
                    8'h6C: arg_pages_hbm[63:32] <= wmask(arg_pages_hbm[63:32], s_axi_control_wdata, s_axi_control_wstrb);
                    8'h74: arg_hbm_bkts     <= wmask(arg_hbm_bkts,     s_axi_control_wdata, s_axi_control_wstrb);
                    8'h7C: arg_pool_n       <= wmask(arg_pool_n,       s_axi_control_wdata, s_axi_control_wstrb);
                    default: ;
                endcase
            end
            if (s_axi_control_bvalid && s_axi_control_bready) s_axi_control_bvalid <= 1'b0;
            // reads (ap_done and ap_ready clear on read of CTRL)
            if (s_axi_control_arvalid && !s_axi_control_rvalid) begin
                s_axi_control_rvalid <= 1'b1;
                case (ra)
                    8'h00: begin
                        s_axi_control_rdata <= {24'd0, auto_restart_r, 3'd0, ap_ready_r, ap_idle, ap_done_r, ap_start_r};
                        ap_done_r <= 1'b0; ap_ready_r <= 1'b0;
                    end
                    8'h04: s_axi_control_rdata <= {31'd0, gie_r};
                    8'h08: s_axi_control_rdata <= {30'd0, ier_r};
                    8'h0C: s_axi_control_rdata <= {30'd0, isr_r};
                    8'h10: s_axi_control_rdata <= arg_cmd[31:0];
                    8'h14: s_axi_control_rdata <= arg_cmd[63:32];
                    8'h1C: s_axi_control_rdata <= arg_resp[31:0];
                    8'h20: s_axi_control_rdata <= arg_resp[63:32];
                    8'h28: s_axi_control_rdata <= arg_pages[31:0];
                    8'h2C: s_axi_control_rdata <= arg_pages[63:32];
                    8'h34: s_axi_control_rdata <= arg_size;
                    8'h3C: s_axi_control_rdata <= arg_meta[31:0];
                    8'h40: s_axi_control_rdata <= arg_meta[63:32];
                    8'h48: s_axi_control_rdata <= arg_brec[31:0];
                    8'h4C: s_axi_control_rdata <= arg_brec[63:32];
                    8'h54: s_axi_control_rdata <= arg_stash[31:0];
                    8'h58: s_axi_control_rdata <= arg_stash[63:32];
                    8'h60: s_axi_control_rdata <= arg_nblk;
                    8'h68: s_axi_control_rdata <= arg_pages_hbm[31:0];
                    8'h6C: s_axi_control_rdata <= arg_pages_hbm[63:32];
                    8'h74: s_axi_control_rdata <= arg_hbm_bkts;
                    8'h7C: s_axi_control_rdata <= arg_pool_n;
`ifdef DOMA_FAULT
                    8'h84: s_axi_control_rdata <= flt_ctl;
                    8'h8C: s_axi_control_rdata <= flt_cmd;
                    8'h94: s_axi_control_rdata <= flt_p5;
                    8'h9C: s_axi_control_rdata <= flt_p6;
                    8'hA4: s_axi_control_rdata <= flt_p8;
                    8'hAC: s_axi_control_rdata <= flt_p3;
                    8'hB4: s_axi_control_rdata <= flt_p1k;
                    8'hBC: s_axi_control_rdata <= flt_p1b;
                    8'hC4: s_axi_control_rdata <= flt_p7x;
                    8'hCC: s_axi_control_rdata <= flt_hs;
                    8'hD4: s_axi_control_rdata <= flt_p6n;
`endif
                    default: s_axi_control_rdata <= 32'd0;
                endcase
            end
            if (s_axi_control_rvalid && s_axi_control_rready) s_axi_control_rvalid <= 1'b0;
            // completion
            if (done_pulse) begin
                ap_done_r  <= 1'b1;
                ap_ready_r <= 1'b1;
                ap_start_r <= auto_restart_r;
                if (ier_r[0]) isr_r[0] <= 1'b1;
            end
        end
    end
    assign interrupt = gie_r && |(isr_r & ier_r);

    // =====================================================================
    // DOMA (single-client build)
    // =====================================================================
    reg                         mgmt_req;
    wire                        mgmt_ack, mgmt_error;
    wire [31:0]                 mgmt_token_out;
    wire [31:0]                 c_token_lane;   // the kernel's client lane: its own lease token
    wire [63:0]                 halt_info;      // the controller's halt record, reported in a halted launch's summary
    reg                         key_load;
    wire                        key_ready, oram_ready, err_ct, err_tag, err_stash;
    reg                         c_req, c_op;
    reg  [`SLOT_ADDR_W-1:0]     c_addr;
    reg  [31:0]                 c_token;
    wire                        c_done, c_rvalid, c_viol, c_ready;
    wire [DW-1:0]               c_wdata;      // the data slot streamed into DOMA (assigned below the state list)
    wire [DW-1:0]               c_rdata;
    wire                        c_wvalid;
    // DOMA's own bucket master (32-bit addresses, relative to the bucket region)
    wire [`AXI_ADDR_W-1:0]      o_araddr, o_awaddr;

    wire [63:0] meta_araddr, meta_awaddr;                     // DOMA-relative metadata addresses
    wire [63:0] brec_araddr, brec_awaddr;                     // DOMA-relative bucket-record addresses
    wire [63:0] stash_araddr, stash_awaddr;                   // DOMA-relative stash addresses
    // run-time size: nblk from the first launch; 0 or above the build's maximum means the maximum
    reg  [31:0]          nblk_q;
    // timing: every size derived from the boot arguments is registered (constant during a run; K_BOOT waits for
    // them to settle), so no per-access path starts at nblk_q / hbm_q / pool_q
    wire [`SLOT_ID_W:0]  nblk_eff_c = (nblk_q == 32'd0 || nblk_q > `ORAM_N) ? `ORAM_N : nblk_q[`SLOT_ID_W:0];
    reg  [`SLOT_ID_W:0]  nblk_eff;
    // buckets in HBM: hbm_bkts from the boot, clamped to the bucket count ceil(n / lambda)
    reg  [31:0]           hbm_q;
    reg  [31:0]           pool_q;                       // stash pool entries from the boot
    wire [`SLOT_ID_W:0]   pool_eff_c = (pool_q == 32'd0 || pool_q > nblk_eff) ? nblk_eff : pool_q[`SLOT_ID_W:0];
    reg  [`SLOT_ID_W:0]   pool_eff;
    reg  [63:0]           pages_hbm_base;
    // nb_full = ceil(nblk_eff / lambda), bit-serial (lambda need not be a power of two; a one-cycle division
    // would be a long path): restarts whenever nblk_eff changes, done SLOT_ID_W + 3 cycles later; K_BOOT
    // starts its settle count only once it is done (kdv_idle)
    localparam integer KDV_W = $clog2(`ORAM_C + 1);
    reg  [`SLOT_ID_W+1:0] nb_full;
    reg  [`SLOT_ID_W+1:0] kdv_src, kdv_x, kdv_q;
    reg  [KDV_W:0]        kdv_r;
    reg  [5:0]            kdv_i;
    reg                   kdv_fin;
    wire                  kdv_idle = (kdv_i == 0) && !kdv_fin && (kdv_src == {1'b0, nblk_eff});
    always @(posedge ap_clk) begin
        if (!ap_rst_n) begin kdv_src <= 0; kdv_x <= 0; kdv_q <= 0; kdv_r <= 0; kdv_i <= 0; kdv_fin <= 1'b0; nb_full <= 0; end
        else begin
            kdv_fin <= 1'b0;
            if (kdv_src != {1'b0, nblk_eff}) begin
                kdv_src <= {1'b0, nblk_eff}; kdv_x <= {1'b0, nblk_eff} + `ORAM_C - 1; kdv_q <= 0; kdv_r <= 0; kdv_i <= `SLOT_ID_W + 2;
            end else if (kdv_i != 0) begin : kdiv_step
                reg [KDV_W:0] r2;
                r2 = {kdv_r[KDV_W-1:0], kdv_x[`SLOT_ID_W+1]};
                kdv_x <= kdv_x << 1;
                if (r2 >= `ORAM_C) begin kdv_r <= r2 - `ORAM_C; kdv_q <= {kdv_q[`SLOT_ID_W:0], 1'b1}; end
                else               begin kdv_r <= r2;           kdv_q <= {kdv_q[`SLOT_ID_W:0], 1'b0}; end
                kdv_i <= kdv_i - 1'b1;
                if (kdv_i == 1) kdv_fin <= 1'b1;
            end else if (kdv_fin) nb_full <= kdv_q;
        end
    end
    wire [`BUCKET_ID_W:0] hbm_eff_c = (hbm_q > nb_full) ? nb_full[`BUCKET_ID_W:0] : hbm_q[`BUCKET_ID_W:0];
    reg  [`BUCKET_ID_W:0] hbm_eff;
    reg  [`AXI_ADDR_W-1:0] hb_lim;                     // hbm_eff x BUCKET_BYTES (compact layout), registered
    always @(posedge ap_clk) begin
        nblk_eff <= nblk_eff_c; pool_eff <= pool_eff_c; hbm_eff <= hbm_eff_c;
        hb_lim   <= {{(`AXI_ADDR_W-`BUCKET_ID_W-1){1'b0}}, hbm_eff} * `BUCKET_BYTES;
    end
`ifdef ORAM_PHASE_TRACE
    wire [10:0] c_pent;                                      // DOMA's phase-entry pulses
`endif
`ifdef ORAM_ONPKG_DEBUG
    // v14b debug build (build.sh DEBUG=1, with TRACE=1): the core's per-access record (written as the second half of
    // each 128-byte trace record) and its on-package overrun records (written after the traffic record, [size+2] ..
    // [size+4]). Never in a measured or deployed bitstream.
`ifndef ORAM_PHASE_TRACE
    ORAM_ONPKG_DEBUG_needs_ORAM_PHASE_TRACE u_needs_trace ();   // a missing module stops the build (build.sh DEBUG=1 sets both)
`endif
    wire [255:0] c_acc_rec;
    wire [767:0] c_ov_rec;
    wire [255:0] c_st_rec;                                  // v14c: the access's stash open (third beat of the trace record)
`endif
`ifdef DOMA_FAULT
    wire [`BUCKET_ID_W-1:0] f_p1_ovr;                       // P1: the remap override for this access (0 = none)
    wire [31:0]             f_token;                        // P7: the token presented with the request
    wire [DW-1:0]           f_brec_rdata;                   // P3: the bucket-record read data into DOMA
    wire [15:0]             f_sub_wb, f_sub_rel;            // P5: this access's budget shortening
    wire [23:0]             f_occ;                          // the stash occupancy (pool entries in use)
    wire                    f_p6_blk;                       // P6: hold the pages port's R channel now
    wire                    f_p6b_blk;                      // P6: hold the pages port's B channel now
    wire                    f_dec_done, f_dec_ok;           // an off-package bucket's tag verdict (this cycle)
    wire [DW-1:0]           f_p8_mask;                      // P8: the bit flipped in the bucket read beat now
    reg                     f_wi;                           // which build-B record is being written (0: [size+2])
    reg                     f_rec2_ok;                      // record [size+3] fits (not when (size + 2) % 128 is 0 or 127)
`endif
`ifdef ORAM_PLAIN
    plain_oram_top  #(.UNIFORM_FILL(1)) u_doma (            // build option: the non-oblivious baseline (plain_oram_top.v)
`else
    secure_oram_top #(.UNIFORM_FILL(1)) u_doma (            // every command fills: GETs and PUTs start alike
`endif
        .clk(ap_clk), .rst_n(ap_rst_n && !doma_srst),            // also reset for a re-boot (init launch)
        .mgmt_req(mgmt_req), .mgmt_op(3'd0), .mgmt_lease_id(8'd0), .mgmt_client_id(1'b0),
        .mgmt_base_addr({`SLOT_ADDR_W{1'b0}}), .mgmt_size({{(`SLOT_ADDR_W-`SLOT_ID_W-13){1'b0}}, nblk_eff, 12'd0}), .mgmt_duration(32'hFFFF_FFFF), .mgmt_token_in(32'd0),
        .mgmt_ack(mgmt_ack), .mgmt_error(mgmt_error), .mgmt_token_out(mgmt_token_out), .client_token_out(c_token_lane), .dbg_halt_info(halt_info),
        .client_req(c_req), .client_op(c_op), .client_slot_addr(c_addr),
        .client_wdata(c_wdata), .client_wstrb(c_wstrb), .client_wdata_valid(c_wvalid),
`ifdef DOMA_FAULT
        .client_token(f_token), .client_lease_id(8'd0),
`else
        .client_token(c_token), .client_lease_id(8'd0),
`endif
        .client_done(c_done), .client_rdata(c_rdata), .client_rdata_valid(c_rvalid),
        .access_violation(c_viol), .client_lockout(),
        .key_load(key_load), .key_ready(key_ready), .err_ct_overrun(err_ct), .oram_ready(oram_ready),
        .cfg_tdm_slot_cycles(16'd0), .client_wbeat_req(), .client_ready(c_ready),
        .err_slot_overrun(), .dbg_slot_start(),
        .dbg_real_cnt(),
        .init_mode(1'b0), .init_pm_wr_addr({`SLOT_ADDR_W{1'b0}}), .init_pm_wr_bucket({`BUCKET_ID_W{1'b0}}),
        .init_pm_wr_status(2'd0), .init_pm_wr_en(1'b0), .init_bm_wr_bucket({`BUCKET_ID_W{1'b0}}),
        .init_bm_wr_slot_list({(`ORAM_Z*`SLOT_ID_W){1'b0}}), .init_bm_wr_fill({`FILL_CNT_W{1'b0}}), .init_bm_wr_en(1'b0),
        .aes_key(AES_KEY), .aes_iv_seed(AES_IV_SEED), .cfg_n(nblk_eff), .cfg_hbm_bkts(hbm_eff), .cfg_pool_n(pool_eff),
        .m_axi_arid(), .m_axi_araddr(o_araddr), .m_axi_arlen(b_arlen), .m_axi_arsize(b_arsize),
        .m_axi_arburst(b_arburst), .m_axi_arvalid(b_arvalid), .m_axi_arready(b_arready),
        .m_axi_rid({`AXI_ID_W{1'b0}}), .m_axi_rdata(b_rdata), .m_axi_rresp(b_rresp),
        .m_axi_rlast(b_rlast), .m_axi_rvalid(b_rvalid), .m_axi_rready(b_rready),
        .m_axi_awid(), .m_axi_awaddr(o_awaddr), .m_axi_awlen(b_awlen), .m_axi_awsize(b_awsize),
        .m_axi_awburst(b_awburst), .m_axi_awvalid(b_awvalid), .m_axi_awready(b_awready),
        .m_axi_wdata(b_wdata), .m_axi_wstrb(b_wstrb), .m_axi_wlast(b_wlast),
        .m_axi_wvalid(b_wvalid), .m_axi_wready(b_wready),
        .m_axi_bid({`AXI_ID_W{1'b0}}), .m_axi_bresp(b_bresp), .m_axi_bvalid(b_bvalid),
        .m_axi_bready(b_bready),
        .m_meta_araddr(meta_araddr), .m_meta_arlen(m_axi_gmem3_arlen), .m_meta_arsize(m_axi_gmem3_arsize),
        .m_meta_arburst(m_axi_gmem3_arburst), .m_meta_arvalid(m_axi_gmem3_arvalid), .m_meta_arready(m_axi_gmem3_arready),
        .m_meta_rdata(m_axi_gmem3_rdata), .m_meta_rlast(m_axi_gmem3_rlast), .m_meta_rvalid(m_axi_gmem3_rvalid),
        .m_meta_rready(m_axi_gmem3_rready), .m_meta_awaddr(meta_awaddr), .m_meta_awlen(m_axi_gmem3_awlen),
        .m_meta_awsize(m_axi_gmem3_awsize), .m_meta_awburst(m_axi_gmem3_awburst), .m_meta_awvalid(m_axi_gmem3_awvalid),
        .m_meta_awready(m_axi_gmem3_awready), .m_meta_wdata(m_axi_gmem3_wdata), .m_meta_wstrb(m_axi_gmem3_wstrb),
        .m_meta_wlast(m_axi_gmem3_wlast), .m_meta_wvalid(m_axi_gmem3_wvalid), .m_meta_wready(m_axi_gmem3_wready),
        .m_meta_bvalid(m_axi_gmem3_bvalid), .m_meta_bready(m_axi_gmem3_bready),
        .m_brec_araddr(brec_araddr), .m_brec_arlen(m_axi_gmem4_arlen), .m_brec_arsize(m_axi_gmem4_arsize),
        .m_brec_arburst(m_axi_gmem4_arburst), .m_brec_arvalid(m_axi_gmem4_arvalid), .m_brec_arready(m_axi_gmem4_arready),
`ifdef DOMA_FAULT
        .m_brec_rdata(f_brec_rdata), .m_brec_rlast(m_axi_gmem4_rlast), .m_brec_rvalid(m_axi_gmem4_rvalid),
`else
        .m_brec_rdata(m_axi_gmem4_rdata), .m_brec_rlast(m_axi_gmem4_rlast), .m_brec_rvalid(m_axi_gmem4_rvalid),
`endif
        .m_brec_rready(m_axi_gmem4_rready), .m_brec_awaddr(brec_awaddr), .m_brec_awlen(m_axi_gmem4_awlen),
        .m_brec_awsize(m_axi_gmem4_awsize), .m_brec_awburst(m_axi_gmem4_awburst), .m_brec_awvalid(m_axi_gmem4_awvalid),
        .m_brec_awready(m_axi_gmem4_awready), .m_brec_wdata(m_axi_gmem4_wdata), .m_brec_wstrb(m_axi_gmem4_wstrb),
        .m_brec_wlast(m_axi_gmem4_wlast), .m_brec_wvalid(m_axi_gmem4_wvalid), .m_brec_wready(m_axi_gmem4_wready),
        .m_brec_bvalid(m_axi_gmem4_bvalid), .m_brec_bready(m_axi_gmem4_bready),
        .m_stash_araddr(stash_araddr), .m_stash_arlen(m_axi_gmem5_arlen), .m_stash_arsize(m_axi_gmem5_arsize),
        .m_stash_arburst(m_axi_gmem5_arburst), .m_stash_arvalid(m_axi_gmem5_arvalid), .m_stash_arready(m_axi_gmem5_arready),
        .m_stash_rdata(m_axi_gmem5_rdata), .m_stash_rlast(m_axi_gmem5_rlast), .m_stash_rvalid(m_axi_gmem5_rvalid),
        .m_stash_rready(m_axi_gmem5_rready), .m_stash_awaddr(stash_awaddr), .m_stash_awlen(m_axi_gmem5_awlen),
        .m_stash_awsize(m_axi_gmem5_awsize), .m_stash_awburst(m_axi_gmem5_awburst), .m_stash_awvalid(m_axi_gmem5_awvalid),
        .m_stash_awready(m_axi_gmem5_awready), .m_stash_wdata(m_axi_gmem5_wdata), .m_stash_wstrb(m_axi_gmem5_wstrb),
        .m_stash_wlast(m_axi_gmem5_wlast), .m_stash_wvalid(m_axi_gmem5_wvalid), .m_stash_wready(m_axi_gmem5_wready),
        .m_stash_bvalid(m_axi_gmem5_bvalid), .m_stash_bready(m_axi_gmem5_bready),
        .dbg_oram_state(), .oram_busy(), .err_stash_overflow(err_stash), .err_bucket_overflow(),
        .err_tag_mismatch(err_tag), .oram_beat_cnt(), .dbg_gcm_tag_match(), .dbg_gcm_tag_valid(),
`ifdef ORAM_PHASE_TRACE
        .phase_ent(c_pent),
`endif
`ifdef ORAM_ONPKG_DEBUG
        .dbg_acc_rec(c_acc_rec), .dbg_ov_rec(c_ov_rec), .dbg_st_rec(c_st_rec),
`endif
`ifdef DOMA_FAULT
        .flt_sub_wb(f_sub_wb), .flt_sub_rel(f_sub_rel), .flt_stash_used(f_occ),
        .flt_dec_done(f_dec_done), .flt_dec_ok(f_dec_ok),
        .dbg_force_same_bucket(1'b0), .dbg_prng_override(f_p1_ovr), .perf_reset(1'b0)
`else
        .dbg_force_same_bucket(1'b0), .dbg_prng_override({`BUCKET_ID_W{1'b0}}), .perf_reset(1'b0)
`endif
    );
    // buckets live at pages + DOMA's own offset
    // DOMA boots (key load, bucket layout) only at the first ap_start, when the host has given
    // the pages address; that address is latched then and used for the life of the kernel.
    // ---- bucket port switch (fixed boundary) ----
    // Buckets 0 .. hbm_bkts-1 live in HBM (gmem6, at pages_hbm + bucket offset); the rest in host memory
    // (gmem2, at pages + (bucket - hbm_bkts) offset). Both buffers are compact. DOMA never has bucket
    // transactions to two buckets in flight at once (a read waits for every earlier write acknowledgement,
    // and an access ends only when its writes are acknowledged), so R and B follow a select recorded when
    // the address is issued; W follows its AW (the current one while AW is valid). Which memory an access
    // uses is visible, but the bucket is uniformly random and independent of the request.
    // Host-memory buckets are rebased by hb_lim rounded DOWN to 4 KB: subtracting a multiple of 4 KB keeps
    // every address's place within its 4 KB page, where axi_master split a straddling bucket's burst
    // (rebasing by H x bucket bytes would move the boundaries). The first host bucket sits up to 4 KB
    // into the pages buffer, which the host allocates 4 KB larger.
    wire [`AXI_ADDR_W-1:0] hb_lim4k = {hb_lim[`AXI_ADDR_W-1:12], 12'h000};
    wire ar_h = (o_araddr < hb_lim);
    wire aw_h = (o_awaddr < hb_lim);
    reg  rsel_h, wsel_h;
    always @(posedge ap_clk) begin
        if (!ap_rst_n) begin rsel_h <= 1'b0; wsel_h <= 1'b0; end
        else begin
            if (b_arvalid) rsel_h <= ar_h;
            if (b_awvalid) wsel_h <= aw_h;
        end
    end
    wire w_h = b_awvalid ? aw_h : wsel_h;
    assign m_axi_gmem2_araddr  = pages_base     + {{(C_M_AXI_ADDR_WIDTH-`AXI_ADDR_W){1'b0}}, o_araddr - hb_lim4k};
    assign m_axi_gmem2_awaddr  = pages_base     + {{(C_M_AXI_ADDR_WIDTH-`AXI_ADDR_W){1'b0}}, o_awaddr - hb_lim4k};
    assign m_axi_gmem6_araddr  = pages_hbm_base + {{(C_M_AXI_ADDR_WIDTH-`AXI_ADDR_W){1'b0}}, o_araddr};
    assign m_axi_gmem6_awaddr  = pages_hbm_base + {{(C_M_AXI_ADDR_WIDTH-`AXI_ADDR_W){1'b0}}, o_awaddr};
    assign m_axi_gmem2_arlen = b_arlen;  assign m_axi_gmem6_arlen = b_arlen;
    assign m_axi_gmem2_arsize = b_arsize; assign m_axi_gmem6_arsize = b_arsize;
    assign m_axi_gmem2_arburst = b_arburst; assign m_axi_gmem6_arburst = b_arburst;
    assign m_axi_gmem2_arvalid = b_arvalid && !ar_h; assign m_axi_gmem6_arvalid = b_arvalid && ar_h;
    assign b_arready = ar_h ? m_axi_gmem6_arready : m_axi_gmem2_arready;
`ifdef DOMA_FAULT
    assign b_rdata  = (rsel_h ? m_axi_gmem6_rdata  : m_axi_gmem2_rdata) ^ f_p8_mask;
`else
    assign b_rdata  = rsel_h ? m_axi_gmem6_rdata  : m_axi_gmem2_rdata;
`endif
    assign b_rresp  = rsel_h ? m_axi_gmem6_rresp  : m_axi_gmem2_rresp;
    assign b_rlast  = rsel_h ? m_axi_gmem6_rlast  : m_axi_gmem2_rlast;
`ifdef DOMA_FAULT
    assign b_rvalid = rsel_h ? m_axi_gmem6_rvalid : (m_axi_gmem2_rvalid && !f_p6_blk);
    assign m_axi_gmem2_rready = b_rready && !rsel_h && !f_p6_blk; assign m_axi_gmem6_rready = b_rready && rsel_h;
`else
    assign b_rvalid = rsel_h ? m_axi_gmem6_rvalid : m_axi_gmem2_rvalid;
    assign m_axi_gmem2_rready = b_rready && !rsel_h; assign m_axi_gmem6_rready = b_rready && rsel_h;
`endif
    assign m_axi_gmem2_awlen = b_awlen;  assign m_axi_gmem6_awlen = b_awlen;
    assign m_axi_gmem2_awsize = b_awsize; assign m_axi_gmem6_awsize = b_awsize;
    assign m_axi_gmem2_awburst = b_awburst; assign m_axi_gmem6_awburst = b_awburst;
    assign m_axi_gmem2_awvalid = b_awvalid && !aw_h; assign m_axi_gmem6_awvalid = b_awvalid && aw_h;
    assign b_awready = aw_h ? m_axi_gmem6_awready : m_axi_gmem2_awready;
    assign m_axi_gmem2_wdata = b_wdata; assign m_axi_gmem6_wdata = b_wdata;
    assign m_axi_gmem2_wstrb = b_wstrb; assign m_axi_gmem6_wstrb = b_wstrb;
    assign m_axi_gmem2_wlast = b_wlast; assign m_axi_gmem6_wlast = b_wlast;
    assign m_axi_gmem2_wvalid = b_wvalid && !w_h; assign m_axi_gmem6_wvalid = b_wvalid && w_h;
    assign b_wready = w_h ? m_axi_gmem6_wready : m_axi_gmem2_wready;
    assign b_bresp  = wsel_h ? m_axi_gmem6_bresp  : m_axi_gmem2_bresp;
`ifdef DOMA_FAULT
    assign b_bvalid = wsel_h ? m_axi_gmem6_bvalid : (m_axi_gmem2_bvalid && !f_p6b_blk);
    assign m_axi_gmem2_bready = b_bready && !wsel_h && !f_p6b_blk; assign m_axi_gmem6_bready = b_bready && wsel_h;
`else
    assign b_bvalid = wsel_h ? m_axi_gmem6_bvalid : m_axi_gmem2_bvalid;
    assign m_axi_gmem2_bready = b_bready && !wsel_h; assign m_axi_gmem6_bready = b_bready && wsel_h;
`endif
    // the position map lives at meta + DOMA's own offset (latched at the first launch, like pages)
    assign m_axi_gmem3_araddr = meta_base + meta_araddr;
    assign m_axi_gmem3_awaddr = meta_base + meta_awaddr;
    // bucket records at brec + DOMA's own offset (latched at the first launch)
    assign m_axi_gmem4_araddr = brec_base + brec_araddr;
    assign m_axi_gmem4_awaddr = brec_base + brec_awaddr;
    // the stash at stash + DOMA's own offset (latched at the first launch)
    assign m_axi_gmem5_araddr = stash_base + stash_araddr;
    assign m_axi_gmem5_awaddr = stash_base + stash_awaddr;

    // =====================================================================
    // Command engine
    // =====================================================================
    localparam [5:0] K_IDLE = 6'd0,  K_BOOT = 6'd1,  K_LEASE = 6'd2,  K_LEASE_W = 6'd3,
                     K_HDR_AR = 6'd4, K_HDR_R = 6'd5, K_REQ = 6'd6,    K_REQ_P = 6'd7,
                     K_DAT_AR = 6'd8, K_DAT_R = 6'd9, K_WAIT = 6'd10, K_REQ_V = 6'd31, K_DAT_P = 6'd29, K_DAT_S = 6'd30,
                     K_GDAT_AW = 6'd11, K_GDAT_PRE = 6'd12, K_GDAT_W = 6'd13, K_GDAT_B = 6'd14,
                     K_RHDR_AW = 6'd15, K_RHDR_W = 6'd16, K_RHDR_B = 6'd17,
                     K_NEXT = 6'd18, K_SUM_AW = 6'd19, K_SUM_W = 6'd20, K_SUM_B = 6'd21, K_DONE = 6'd22,
                     K_TRF_AW = 6'd23, K_TRF_W = 6'd24, K_TRF_B = 6'd25, K_RST = 6'd26;
`ifdef ORAM_PHASE_TRACE
    localparam [5:0] K_TR_AW = 6'd27, K_TR_W = 6'd28;     // the two free codes
`endif
`ifdef DOMA_FAULT
    localparam [5:0] K_FLT_AW = 6'd35, K_FLT_W = 6'd36, K_FLT_B = 6'd37;   // build B: the record [size+2]
`endif
`ifdef ORAM_ONPKG_DEBUG
    localparam [5:0] K_DBG_AW = 6'd32, K_DBG_W = 6'd33, K_DBG_B = 6'd34;   // the debug records [size+2] .. [size+4]
    reg  [1:0]   dbg_i;                                     // which debug record
    reg  [255:0] tr_beat2, tr_beat3;                        // the core's records of the command's access (and its stash open)
    reg  [1:0]   tr_wi;                                     // trace record beat: 0 phase timestamps, 1 the core's record,
                                                            // 2 the stash open (v14c), 3 zero
    localparam [1:0] DBG_REC = 2'b11;                      // summary byte 2: [0] debug records, [1] debug trace records
    localparam       DBG_T128 = 1'b1;                       //  [3] (v14c) the trace records are 128 bytes
`else
    localparam [1:0] DBG_REC = 2'b00;
    localparam       DBG_T128 = 1'b0;
`endif
`ifdef ORAM_ONPKG_INTERIM
    localparam       DBG_INTERIM = 1'b1;                    // summary byte 2 [2]: the interim on-package budgets (INTERIM=1)
`else
    localparam       DBG_INTERIM = 1'b0;
`endif
    localparam [7:0] DBG_FLAGS = {4'd0, DBG_T128, DBG_INTERIM, DBG_REC};
    reg  [5:0]  kst;
    // No boot touch pass (v11b): DOMA's boot layout places every block at an independent uniform bucket itself
    // (random direct placement, flat_oram_gcm.v S_LAYOUT), which is the state the security argument and the stash
    // bound assume, so the first host command follows the lease directly.
    reg  [3:0]  boot_cnt;
    reg         key_sent, lease_ok;
    reg         doma_srst;                                   // holds the DOMA core in reset (re-boot)
    reg  [4:0]  srst_cnt;
    reg  [2:0]  settle;                                  // K_BOOT: cycles for the registered sizes to settle
    reg  [31:0] idx, nsize;
    reg  [63:0] cbase, rbase, hc_off, hr_off;
    wire [7:0] b_arlen, b_awlen; wire [2:0] b_arsize, b_awsize; wire [1:0] b_arburst, b_awburst, b_rresp, b_bresp;
    wire b_arvalid, b_arready, b_rlast, b_rvalid, b_rready, b_awvalid, b_awready, b_wlast, b_wvalid, b_wready, b_bvalid, b_bready;
    wire [C_M_AXI_DATA_WIDTH-1:0] b_rdata, b_wdata; wire [C_M_AXI_DATA_WIDTH/8-1:0] b_wstrb;
    reg  [63:0] pages_base, meta_base, brec_base, stash_base; // latched at the first ap_start
    reg  [7:0]  ctype;
    reg  [31:0] ckey;
    reg  [31:0] coff, clen;        // PUT record range in the block: bytes 8-11 offset, 12-15 length (0 = whole block)
    reg  [BWI:0] pcnt;             // PUT data beat being streamed into DOMA
    reg  [31:0] lat, lat_min, lat_max, wait_cnt;
`ifdef ORAM_PHASE_TRACE
    // ---- per-command phase timestamps on the bucket port (cycles since the request, the same timebase as lat):
    //      first bucket read request (AR), last bucket read beat (R), first and last write-back beat (W). The
    //      response header carries them in bytes 16-31; the host derives lookup, bucket read, processing (decryption,
    //      stash, re-encryption) and bucket write. ph_on spans the command, from the request to DOMA to its c_done.
    reg         ph_on, ph_ar_seen;
    reg  [31:0] ph_ar, ph_rl, ph_wf, ph_wl;
    reg  [15:0] ph_rn, ph_wn;
    // ---- phase trace record (32 bytes per command, written after its header when the host sets bit 31 of size):
    //      16 timestamps of 16 bits (cycles since the request, saturating), slot k = bits 16k+15:16k:
    //       0 lookup entered, 1 read gate, 2 bucket read request (AR), 3 first bucket beat, 4 last bucket beat,
    //       5 crypto (decryption pass), 6 block operation, 7 eviction, 8 re-encryption, 9 write-back gate, 10 write-back,
    //      11 first write-back beat, 12 last write-back beat, 13 release gate, 14 result, 15 DOMA idle again.
    reg         tr_en, tr_on;
    reg  [31:0] tr_cnt;
    reg  [15:0] tr_got;
    reg  [255:0] tr_beat;
`endif
    reg  [63:0] total;
    reg  [31:0] stat, errs, ndone;
    reg  [BW:0] rcnt, wcnt;
    reg  [DW-1:0] rbuf [0:BEATS-1];                          // GET data, written back after completion
    reg  [DW-1:0] wreg;
    // command prefetch: while DOMA serves command idx (K_WAIT), read command idx+1's header (the command port is idle
    // then); responses are posted (their B is counted, all are awaited once, before the summary)
    reg           pf_ar, pf_wait, pf_valid;
    reg  [7:0]    pf_type;
    reg  [31:0]   pf_key, pf_off, pf_len;
    reg  [15:0]   wb_pend;                                  // response writes not yet acknowledged
    reg           viol_q;                                   // the core's key-range verdict, registered (timing)
    // A rejected command is not answered at once: it makes a dummy access in its place (dmy), so its bus traffic,
    // timing and response look like any command's. Rejected here (rej_code: unknown opcode, record range outside
    // the block, key outside the ORAM), the kernel issues a GET of slot 0 under its own lease; a lease violation
    // (viol_q) is served as a dummy by the core. Either way the command streams its data slot, waits for the
    // access, writes a zero data slot and returns its status; it is not counted as completed.
    reg           dmy;
    wire [31:0]   rej_code = (ctype != T_GET && ctype != T_PUT) ? 32'h2
                           : (ctype == T_PUT && clen != 32'd0 && (coff >= BLOCK || clen > BLOCK - coff)) ? 32'h40
                           : (ckey >= nblk_eff) ? 32'h4 : 32'd0;
    // uniform commands: command idx+1's data slot (a PUT's data, or a GET's unused slot) is prefetched into pdbuf
    // during command idx, and every command streams its slot into DOMA (GETs too, data ignored); every command
    // writes its response data slot (a PUT with all strobes off). GETs and PUTs therefore take the same time.
    reg  [DW-1:0] pdbuf [0:BEATS-1];
    reg  [DW-1:0] pd_q;
    reg           pd_ar, pd_wait, pd_valid, pd_have;
    reg  [BWI:0]  pd_cnt;
    // The slot buffer is a simple dual-port RAM: one write port (the prefetch), one registered read port whose
    // address the state chooses (0 in K_DAT_P, the next beat in K_DAT_S). No reset, so it maps to block RAM;
    // pd_q gets the same beat on the same cycle as before. Writes (command k+1's prefetch, in K_WAIT) never
    // overlap the reads (command k+1's own K_DAT_S, after it).
    wire          pd_we = pd_wait && m_axi_gmem0_rvalid;
    wire [BWI:0]  pd_ra = (kst == K_DAT_S) ? (pcnt + 1'b1) : {(BWI+1){1'b0}};
    always @(posedge ap_clk) begin
        if (pd_we) pdbuf[pd_cnt % BEATS] <= m_axi_gmem0_rdata;
        pd_q <= pdbuf[pd_ra % BEATS];
    end
    wire        halted = err_ct | err_tag | err_stash;
    // a halt's cause, reported with it: 0x8 halted, plus 0x100 timing overrun, 0x200 integrity, 0x400 stash overflow
    wire [31:0] HALT_BITS = {21'd0, err_stash, err_tag, err_ct, 8'h08};

    assign ap_idle = (kst == K_IDLE);
`ifndef SYNTHESIS
    initial if (DW != 256) begin $display("ERROR: doma_kernel expects 256-bit data (DOMA's AXI width)"); $finish; end
`endif
    assign c_wvalid = ((kst == K_DAT_R) && m_axi_gmem0_rvalid) || (kst == K_DAT_S);   // every access's data slot
    assign c_wdata  = (kst == K_DAT_S) ? pd_q : m_axi_gmem0_rdata;
    // byte strobes of the beat being streamed: the record's bytes, or every byte (whole-block PUT)
    wire [DW/8-1:0] c_wstrb;
    genvar gs;
    generate for (gs = 0; gs < DW/8; gs = gs + 1) begin : g_wstrb
        wire [31:0] bidx = pcnt * (DW/8) + gs;                    // byte index within the block
        assign c_wstrb[gs] = (clen == 32'd0) || (bidx >= coff && bidx < coff + clen);
    end endgenerate
    assign m_axi_gmem0_rready = (kst == K_HDR_R) || (kst == K_DAT_R) || pf_wait || pd_wait;
    assign m_axi_gmem0_arsize = ASIZE;  assign m_axi_gmem0_arburst = 2'b01;
    assign m_axi_gmem1_awsize = ASIZE;  assign m_axi_gmem1_awburst = 2'b01;
    assign m_axi_gmem1_bready = 1'b1;
    assign m_axi_gmem1_wstrb  = (kst == K_GDAT_W && ctype != T_GET) ? {(DW/8){1'b0}} : {(DW/8){1'b1}};   // PUT: slot untouched
`ifdef ORAM_ONPKG_DEBUG
    assign m_axi_gmem1_wlast  = (kst == K_GDAT_W) ? (wcnt == BEATS - 1) : (kst == K_TR_W) ? (tr_wi == 2'd3) : 1'b1;   // 128-byte trace records
`elsif DOMA_FAULT
    assign m_axi_gmem1_wlast  = (kst == K_GDAT_W) ? (wcnt == BEATS - 1) : (kst == K_FLT_W) ? (f_wi || !f_rec2_ok) : 1'b1;
`else
    assign m_axi_gmem1_wlast  = (kst == K_GDAT_W) ? (wcnt == BEATS - 1) : 1'b1;
`endif
    // response header / summary beat
`ifdef ORAM_PHASE_TRACE
    // header: byte 0 type | 4-7 block | 8-11 latency | 12-15 status | 16-19 bucket AR | 20-23 last R | 24-27 first W | 28-31 last W
    wire [255:0]  hdr_256  = {ph_wl, ph_wf, ph_rl, ph_ar, stat, lat, ckey, 24'd0, ((stat == 32'd0) ? T_ACK : T_ERR)};
    wire [DW-1:0] hdr_beat = hdr_256;
`else
    wire [DW-1:0] hdr_beat = {{(DW-128){1'b0}}, stat, lat, ckey, 24'd0, ((stat == 32'd0) ? T_ACK : T_ERR)};
`endif
`ifdef ORAM_PHASE_TRACE
    localparam integer PH_BKT_BEATS = `ORAM_Z * BEATS;          // one bucket each way per command
    always @(posedge ap_clk) begin
        if (!ap_rst_n) begin
            ph_on <= 1'b0; ph_ar_seen <= 1'b0; ph_ar <= 0; ph_rl <= 0; ph_wf <= 0; ph_wl <= 0; ph_rn <= 0; ph_wn <= 0;
        end else begin
            if (kst == K_REQ) begin                                     // a new command (or one rejected here): clear
                ph_ar_seen <= 1'b0; ph_ar <= 0; ph_rl <= 0; ph_wf <= 0; ph_wl <= 0; ph_rn <= 0; ph_wn <= 0;
            end
            if (kst == K_REQ_P) ph_on <= 1'b1;                          // c_req is high: DOMA has the command
            if (ph_on) begin
                if (b_arvalid && b_arready && !ph_ar_seen) begin ph_ar <= lat + 1; ph_ar_seen <= 1'b1; end
                if (b_rvalid && b_rready) begin ph_rl <= lat + 1; ph_rn <= ph_rn + 1'b1; end
                if (b_wvalid && b_wready) begin
                    if (ph_wn == 0) ph_wf <= lat + 1;
                    ph_wl <= lat + 1; ph_wn <= ph_wn + 1'b1;
                end
            end
            if (kst == K_WAIT && c_done) ph_on <= 1'b0;
        end
    end
`ifndef SYNTHESIS
    always @(posedge ap_clk)                                         // attribution check (simulation only)
        if (ap_rst_n && kst == K_WAIT && c_done &&
            (ph_rn + (b_rvalid && b_rready) != PH_BKT_BEATS || ph_wn + (b_wvalid && b_wready) != PH_BKT_BEATS))
            $display("PHASE ATTRIBUTION: command %0d saw %0d read and %0d write bucket beats (expected %0d each)",
                     ndone, ph_rn + (b_rvalid && b_rready), ph_wn + (b_wvalid && b_wready), PH_BKT_BEATS);
`endif
`ifdef ORAM_ONPKG_DEBUG
    // the core's record of this command's access, taken as the access ends (all ones: no access ended, e.g. a halt)
    always @(posedge ap_clk) begin
        if (!ap_rst_n || kst == K_REQ) begin tr_beat2 <= {256{1'b1}}; tr_beat3 <= {256{1'b1}}; end
        else if (kst == K_WAIT && c_done) begin tr_beat2 <= c_acc_rec; tr_beat3 <= c_st_rec; end
    end
`endif
    // trace record captures: tr_cnt equals lat while the command runs and keeps counting until the record is written
    always @(posedge ap_clk) begin
        if (!ap_rst_n) begin tr_on <= 1'b0; tr_cnt <= 0; tr_got <= 16'd0; tr_beat <= 256'd0; end
        else begin
            if (kst == K_REQ) begin tr_cnt <= 0; tr_got <= 16'd0; tr_beat <= 256'd0; end
            else if (kst == K_REQ_P || tr_on) tr_cnt <= tr_cnt + 1;
            if (kst == K_REQ_P) tr_on <= 1'b1;
            if (kst == K_TR_AW || kst == K_NEXT) tr_on <= 1'b0;          // record being written (or none requested)
            if (tr_on || kst == K_REQ_P) begin : trcap
                reg [15:0] t, ev; integer k;
                t  = (tr_cnt >= 32'd65535) ? 16'hFFFF : tr_cnt[15:0] + 16'd1;
                ev = {c_pent[10:8], (b_wvalid && b_wready), (b_wvalid && b_wready), c_pent[7:3], c_pent[2],
                      (b_rvalid && b_rready), (b_rvalid && b_rready), (b_arvalid && b_arready), c_pent[1:0]};
                for (k = 0; k < 16; k = k + 1)
                    if (ev[k] && (!tr_got[k] || k == 4 || k == 12)) begin   // slots 4 and 12: the last beat
                        tr_beat[16*k +: 16] <= t; tr_got[k] <= 1'b1;
                    end
            end
        end
    end
`endif
`ifdef DOMA_FAULT
    // =====================================================================
    // Build B (DOMA_FAULT): fault-injection hooks and stash statistics (docs/v14d_fault_build.md)
    // Every hook is armed per launch by flt_ctl (latched at the launch start) and fires at most once, during the
    // access of command flt_cmd (P1: the accesses to block flt_p1k, or every access). With flt_ctl = 0 every hook
    // net below is 0 and DOMA runs exactly as build A; only the extra record [size+2] is written at the end.
    //   flt_ctl  [0] P3 arm  [1] P5 arm  [2] P6 arm  [3] P8 arm  [4] P1 arm  [5] P7 arm
    //            [8] P8 on the HBM bucket port (0: the pages port)   [12] P1 every access   [13] P1 every access to flt_p1k
    //   flt_cmd  the command index (0 .. size-1) of P3, P5, P6, P7, P8
    //   flt_p5   [15:0] cycles off AR_WB_H, [31:16] cycles off AR_REL_H (P5)
    //   flt_p6   [15:0] the pages-port R beat of the access to hold (0: before the first); [16] hold the access's
    //            first pages-port B response instead (P6);  flt_p6n (0x0D4) the cycles to hold (32 bits)
    //   flt_p8   [7:0] bit (0..255) of the beat, [23:8] beat of the access's bucket read on the chosen port (P8)
    //   flt_p3   [7:0] bit (0..223) of the record's {tag, IV} beat: 0..95 the IV, 96..223 the tag (P3)
    //   flt_p1k  the block (key) to steer; flt_p1b the bucket to steer it to (1 .. buckets-1; 0 = no override) (P1)
    //   flt_p7x  the token XOR (0 means 1) (P7)
    //   flt_hs   the stash histogram: [4:0] bin width log2, [31:8] first bin's lower edge
    // =====================================================================
    always @(posedge ap_clk) begin
        if (rst) begin
            flt_ctl <= 0; flt_cmd <= 0; flt_p5 <= 0; flt_p6 <= 0; flt_p8 <= 0; flt_p3 <= 0; flt_p1k <= 0; flt_p1b <= 0;
            flt_p7x <= 0; flt_hs <= 0; flt_p6n <= 0;
        end else if (s_axi_control_awvalid && s_axi_control_wvalid && !s_axi_control_bvalid) begin
            case (s_axi_control_awaddr[7:0])
                8'h84: flt_ctl <= wmask(flt_ctl, s_axi_control_wdata, s_axi_control_wstrb);
                8'h8C: flt_cmd <= wmask(flt_cmd, s_axi_control_wdata, s_axi_control_wstrb);
                8'h94: flt_p5  <= wmask(flt_p5,  s_axi_control_wdata, s_axi_control_wstrb);
                8'h9C: flt_p6  <= wmask(flt_p6,  s_axi_control_wdata, s_axi_control_wstrb);
                8'hA4: flt_p8  <= wmask(flt_p8,  s_axi_control_wdata, s_axi_control_wstrb);
                8'hAC: flt_p3  <= wmask(flt_p3,  s_axi_control_wdata, s_axi_control_wstrb);
                8'hB4: flt_p1k <= wmask(flt_p1k, s_axi_control_wdata, s_axi_control_wstrb);
                8'hBC: flt_p1b <= wmask(flt_p1b, s_axi_control_wdata, s_axi_control_wstrb);
                8'hC4: flt_p7x <= wmask(flt_p7x, s_axi_control_wdata, s_axi_control_wstrb);
                8'hCC: flt_hs  <= wmask(flt_hs,  s_axi_control_wdata, s_axi_control_wstrb);
                8'hD4: flt_p6n <= wmask(flt_p6n, s_axi_control_wdata, s_axi_control_wstrb);
                default: ;
            endcase
        end
    end
    reg  [7:0]   f_arm;           // arm bits of this launch
    reg  [7:0]   f_fired;         // [0] P3 [1] P5 (on package) [2] P6 [3] P8 [4] P1 [5] P7; [6] P3's bucket was on package;
                                  // [7] P5's access was off package (nothing to shorten)
    reg  [15:0]  f_p1n;           // P1 overrides this launch
    reg          f_p1_used;       // P1 (one-shot) has steered its access
    reg          f_cur;           // a command's access is in flight (its request .. c_done)
    reg          f_t_hbm;         // the target access's bucket is on package
    reg          f4_bi, f4_hbm;   // P3: the record beat now arriving (0 metadata, 1 {tag, IV}); its bucket on package
    reg  [15:0]  f6_cnt;          // P6: pages-port R beats of the target access
    reg  [31:0]  f6_hold;         // P6: cycles the beat (or the B response) has been held
    reg  [15:0]  f8_cnt;          // P8: bucket beats of the target access on the chosen port
    reg  [23:0]  f_bmax, f_lmax;  // stash occupancy maximum since the boot / this launch
    reg  [151:0] f_hist;          // 8 bins x 19 bits: occupancy at each access end, this launch
    reg          f_rec_ok;        // record [size+2] fits before the response data (not when (size + 2) % 128 == 0)
    wire         f_tgt   = f_cur && (idx == flt_cmd);
    wire         f_p1_on = f_arm[4] && f_cur && (flt_ctl[12] || ckey == flt_p1k) && (flt_ctl[12] || flt_ctl[13] || !f_p1_used);
    assign f_p1_ovr  = f_p1_on ? flt_p1b[`BUCKET_ID_W-1:0] : {`BUCKET_ID_W{1'b0}};
    wire         f_p7_on = f_arm[5] && (idx == flt_cmd) && kst != K_IDLE;
    assign f_token   = f_p7_on ? (c_token ^ ((flt_p7x == 32'd0) ? 32'd1 : flt_p7x)) : c_token;
    assign f_sub_wb  = (f_arm[1] && f_tgt) ? flt_p5[15:0]  : 16'd0;
    assign f_sub_rel = (f_arm[1] && f_tgt) ? flt_p5[31:16] : 16'd0;
    wire         f_p3_now = f_arm[0] && f_tgt && !f_fired[0] && m_axi_gmem4_rvalid && f4_bi;
    assign f_brec_rdata = m_axi_gmem4_rdata ^ (f_p3_now ? ({{(DW-1){1'b0}}, 1'b1} << flt_p3[7:0]) : {DW{1'b0}});
    wire         f6_at   = f_arm[2] && !flt_p6[16] && f_tgt && !f_fired[2] && !rsel_h && (f6_cnt == flt_p6[15:0]);
    assign f_p6_blk  = f6_at && (f6_hold < flt_p6n);
    // B: the target access's first pages-port write response is held for flt_p6n cycles. In arrival mode an access
    // ends once its write data is handed off, so the hold runs on past its end (the next access's bucket read waits
    // for the acknowledgement): once started it continues on its own counter until done.
    reg          f6b_on;
    reg  [31:0]  f6b_hold;
    wire         f6b_start = f_arm[2] && flt_p6[16] && f_tgt && !f_fired[2] && !f6b_on && !wsel_h && m_axi_gmem2_bvalid;
    wire         f6b_at  = f6b_start || f6b_on;
    assign f_p6b_blk = f6b_start ? (flt_p6n != 32'd0) : (f6b_on && f6b_hold < flt_p6n);
    wire         f8_sel  = flt_ctl[8] ? rsel_h : !rsel_h;
    wire         f_p8_now = f_arm[3] && f_tgt && !f_fired[3] && f8_sel && b_rvalid && (f8_cnt == flt_p8[23:8]);
    assign f_p8_mask = f_p8_now ? ({{(DW-1){1'b0}}, 1'b1} << flt_p8[7:0]) : {DW{1'b0}};
    wire [23:0]  f_hbase = flt_hs[31:8];
    wire [23:0]  f_hrel  = (f_occ > f_hbase) ? (f_occ - f_hbase) >> flt_hs[4:0] : 24'd0;
    wire [2:0]   f_bin   = (f_hrel > 24'd7) ? 3'd7 : f_hrel[2:0];
    wire         f_launch = (kst == K_IDLE) && ap_start_r && !done_pulse;
    always @(posedge ap_clk) begin : flt_logic
        integer k;
        if (rst) begin
            f_arm <= 0; f_fired <= 0; f_p1n <= 0; f_p1_used <= 0; f_cur <= 0; f_t_hbm <= 0; f4_bi <= 0; f4_hbm <= 0;
            f6_cnt <= 0; f6_hold <= 0; f6b_on <= 1'b0; f6b_hold <= 0; f8_cnt <= 0; f_bmax <= 0; f_lmax <= 0; f_hist <= 0; f_rec_ok <= 1'b1; f_rec2_ok <= 1'b1;
        end else begin
            if (f_launch) begin
                f_arm <= flt_ctl[7:0]; f_fired <= 0; f_p1n <= 0; f_p1_used <= 1'b0; f_lmax <= 0; f_hist <= 0;
                f_rec_ok  <= ((arg_size + 32'd2) & 32'd127) != 32'd0;
                f_rec2_ok <= ((arg_size + 32'd2) & 32'd127) != 32'd0 && ((arg_size + 32'd2) & 32'd127) != 32'd127;
            end
            // the access in flight: from the cycle its request is up (K_REQ_P) to its c_done
            if (kst == K_REQ_P) begin f_cur <= 1'b1; f6_cnt <= 0; f6_hold <= 0; f8_cnt <= 0; end
            if ((kst == K_WAIT && c_done) || kst == K_NEXT || kst == K_IDLE) f_cur <= 1'b0;
            if (kst == K_REQ_P && f_p7_on) f_fired[5] <= 1'b1;
            if (kst == K_WAIT && c_done && f_p1_on) begin
                f_p1_used <= 1'b1; f_fired[4] <= 1'b1; if (f_p1n != 16'hFFFF) f_p1n <= f_p1n + 16'd1;
            end
            if (f_tgt && b_arvalid && b_arready) f_t_hbm <= ar_h;
            if (kst == K_WAIT && c_done && f_tgt && f_arm[1]) begin
                if (f_t_hbm) f_fired[1] <= 1'b1; else f_fired[7] <= 1'b1;
            end
            // P3: the record port (each record is 2 beats: metadata, then {tag, IV})
            if (m_axi_gmem4_arvalid && m_axi_gmem4_arready) begin
                f4_bi <= brec_araddr[5]; f4_hbm <= ((brec_araddr >> 6) < {{(64-`BUCKET_ID_W-1){1'b0}}, hbm_eff});
            end else if (m_axi_gmem4_rvalid && m_axi_gmem4_rready) f4_bi <= ~f4_bi;
            if (f_p3_now && m_axi_gmem4_rready) begin f_fired[0] <= 1'b1; f_fired[6] <= f4_hbm; end
            // P6: hold the chosen pages-port beat
            if (f_tgt && m_axi_gmem2_rvalid && m_axi_gmem2_rready) f6_cnt <= f6_cnt + 16'd1;
            if (f6_at && m_axi_gmem2_rvalid && f_p6_blk) f6_hold <= f6_hold + 32'd1;
            if (f6_at && !f_p6_blk && m_axi_gmem2_rvalid && m_axi_gmem2_rready) f_fired[2] <= 1'b1;
            if (f6b_start) begin f6b_hold <= 32'd1; f6b_on <= f_p6b_blk; if (!f_p6b_blk) f_fired[2] <= 1'b1; end
            else if (f6b_on) begin
                if (f_p6b_blk) f6b_hold <= f6b_hold + 32'd1; else begin f6b_on <= 1'b0; f_fired[2] <= 1'b1; end
            end
            // P8: flip one bit of the chosen bucket beat
            if (f_tgt && f8_sel && b_rvalid && b_rready) f8_cnt <= f8_cnt + 16'd1;
            if (f_p8_now && b_rready) f_fired[3] <= 1'b1;
            // stash statistics
            if (doma_srst) f_bmax <= 0; else if (f_occ > f_bmax) f_bmax <= f_occ;
            if (!f_launch && f_occ > f_lmax) f_lmax <= f_occ;
            if (kst == K_WAIT && c_done)
                for (k = 0; k < 8; k = k + 1)
                    if (f_bin == k && f_hist[19*k +: 19] != 19'h7FFFF) f_hist[19*k +: 19] <= f_hist[19*k +: 19] + 19'd1;
        end
    end
    // record [size+2]: byte 0 0x5F | 1 fired | 2-3 P1 overrides | 4-6 occupancy now | 7-9 maximum since the boot |
    //                  10-12 maximum this launch | 13-31 the histogram, 8 bins of 19 bits (bin 0 first)
    wire [255:0] f_rec = {f_hist, f_lmax, f_bmax, f_occ, f_p1n, f_fired, 8'h5F};
    // ---- observation (test plan Part B section 4): the halt, the halting access, activity after it, order ----
    // An access's bucket read is "verified" once its tag check passed (off package) or at once (on package: v14 keeps
    // those buckets as plaintext, with no tag). order_violation counts a result beat leaving DOMA, or a bucket AW
    // handshake, while the latest bucket read is not verified. Activity after the halt: bucket AW handshakes and W
    // beats on either port, DOMA result beats and response-data beats.
    reg          o_tok;           // the latest bucket read is verified
    reg          o_tbad;          // the latest bucket read failed its tag check
    reg          o_ahbm;          // the latest bucket read was on package
    reg          o_hs;            // halted (this launch, or already at its start)
    reg  [7:0]   o_fl;            // flags (record byte 1)
    reg  [5:0]   o_kst;           // the command engine state at the halt
    reg  [31:0]  o_hacc, o_hcyc, o_cyc, o_nrel;
    reg  [15:0]  o_awb, o_pawb, o_pwb, o_prv, o_ov;   // the access's bucket W beats; after the halt: AW, W, results; violations
    reg  [7:0]   o_aaw, o_arv, o_tfail;               // the access's bucket AWs, result beats; tag fails
    reg  [15:0]  h_awb; reg [7:0] h_aaw, h_arv;      // the halting access's counts at the halt
    reg  [23:0]  o_tok_n;                             // tag checks passed
    reg          o_rv1;                               // the access has released a result beat
    wire         o_aw  = b_awvalid && b_awready;
    wire         o_w   = b_wvalid && b_wready;
    wire         o_rd  = c_rvalid;                                              // DOMA's result beats (to the kernel)
    wire         o_rk  = (kst == K_GDAT_W && m_axi_gmem1_wvalid && m_axi_gmem1_wready);   // response data to the host
    reg  [7:0]   o_pkd;                               // response-data beats written after the halt
    always @(posedge ap_clk) begin : flt_obs
        if (rst) begin
            o_tok <= 1'b1; o_tbad <= 1'b0; o_ahbm <= 1'b0; o_hs <= 1'b0; o_fl <= 0; o_kst <= 0; o_hacc <= 0; o_hcyc <= 0;
            o_cyc <= 0; o_nrel <= 0; o_awb <= 0; o_pawb <= 0; o_pwb <= 0; o_prv <= 0; o_ov <= 0; o_aaw <= 0; o_arv <= 0;
            o_tfail <= 0; h_awb <= 0; h_aaw <= 0; h_arv <= 0; o_tok_n <= 0; o_rv1 <= 1'b0; o_pkd <= 0;
        end else begin
            o_cyc <= o_cyc + 32'd1;
            if (doma_srst) begin o_tok <= 1'b1; o_tbad <= 1'b0; end
            else if (b_arvalid && b_arready) begin o_tok <= ar_h; o_ahbm <= ar_h; o_tbad <= 1'b0; end
            else if (f_dec_done) begin o_tok <= f_dec_ok; o_tbad <= !f_dec_ok; end
            if (f_dec_done &&  f_dec_ok && o_tok_n != 24'hFFFFFF) o_tok_n <= o_tok_n + 24'd1;
            if (f_dec_done && !f_dec_ok && o_tfail != 8'hFF) o_tfail <= o_tfail + 8'd1;
            if (((c_rvalid && !o_rv1) || o_aw) && !o_tok && o_ov != 16'hFFFF) o_ov <= o_ov + 16'd1;
            if (kst == K_REQ_P) begin o_awb <= 0; o_aaw <= 0; o_arv <= 0; o_rv1 <= 1'b0; end
            else begin
                if (o_w && o_awb != 16'hFFFF) o_awb <= o_awb + 16'd1;
                if (o_aw && o_aaw != 8'hFF) o_aaw <= o_aaw + 8'd1;
                if (c_rvalid && o_arv != 8'hFF) o_arv <= o_arv + 8'd1;
                if (c_rvalid && !o_rv1) begin o_rv1 <= 1'b1; o_nrel <= o_nrel + 32'd1; end
            end
            if (f_launch) begin
                o_hs <= halted; o_fl <= {6'd0, halted, 1'b0}; o_kst <= 0; o_hacc <= 32'hFFFF_FFFF; o_hcyc <= 0; o_cyc <= 0;
                o_nrel <= 0; o_pawb <= 0; o_pwb <= 0; o_prv <= 0; o_ov <= 0; o_tok_n <= 0; o_tfail <= 0; o_pkd <= 0;
                h_awb <= 0; h_aaw <= 0; h_arv <= 0;
            end else if (doma_srst) o_hs <= 1'b0;              // a re-boot (init launch) clears the halt
            else if (halted && !o_hs) begin
                o_hs <= 1'b1; o_kst <= kst; o_hacc <= idx; o_hcyc <= o_cyc;
                o_fl[0] <= 1'b1; o_fl[3] <= f_cur; o_fl[4] <= o_ahbm; o_fl[5] <= o_tok; o_fl[6] <= o_tbad;
                h_awb <= o_awb; h_aaw <= o_aaw; h_arv <= o_arv;
            end else if (o_hs) begin
                if (o_aw && o_pawb != 16'hFFFF) o_pawb <= o_pawb + 16'd1;
                if (o_w  && o_pwb  != 16'hFFFF) o_pwb  <= o_pwb  + 16'd1;
                if (o_rd && o_prv  != 16'hFFFF) o_prv  <= o_prv  + 16'd1;
                if (o_rk && o_pkd  != 8'hFF)    o_pkd  <= o_pkd  + 8'd1;
                if (o_aw || o_w || o_rd || o_rk) o_fl[2] <= 1'b1;
            end
        end
    end
    // record [size+3]: byte 0 0x60 | 1 flags: [0] halted [1] already halted at the launch start [2] activity after the
    //   halt [3] the halt came during an access [4] that access's bucket read was on package [5] it had verified
    //   [6] it failed its tag check | 2 the command state at the halt | 3 response-data beats the kernel wrote to the
    //   host after the halt | 4-7 the command index at the halt (all 1s: none)
    //   | 8-11 cycles from the launch start to the halt | 12-13 the access's bucket W beats before the halt | 14 its
    //   bucket AWs | 15 its result beats (DOMA to the kernel) | 16-17 bucket AWs after the halt | 18-19 bucket W beats
    //   after the halt | 20-21 DOMA's result beats after the halt (to the kernel, never written out) | 22-23 order
    //   violations | 24-26 tag checks passed
    //   | 27 tag checks failed | 28-31 accesses that released a result this launch
    wire [255:0] f_obs = {o_nrel, o_tfail, o_tok_n, o_ov, o_prv, o_pwb, o_pawb, h_arv, h_aaw, h_awb, o_hcyc, o_hacc,
                          o_pkd, 2'b00, o_kst, o_fl, 8'h60};
`endif
    // summary: byte0 0x5A | byte1 lambda if not 6 (0 = 6) | bytes 4-7 block size in beats | 8-15 total | 16-19 min | 20-23 max | 24-27 errors | 28-31 completed
    // byte 1: lambda when it is not 6 (0 means 6, so a lambda = 6 build is unchanged); the host checks it against DOMA_LAMBDA
    localparam [7:0] LAM_REP = (`ORAM_C == 6) ? 8'd0 : `ORAM_C;
    // a halted launch reports the controller's halt record in place of the latency min/max (bucket, state, HBM flag;
    // memory-unit errors, access cycle: see flat_oram_gcm dbg_halt_info)
    wire [255:0]  sum_beat = {ndone, errs, (errs[3] ? halt_info[63:32] : lat_max),
                              (errs[3] ? halt_info[31:0] : (lat_min == 32'hFFFF_FFFF ? 32'd0 : lat_min)),
`ifdef DOMA_FAULT
                              total, BEATS[31:0], 8'd0, (DBG_FLAGS | {1'b0, f_rec2_ok, f_rec_ok, 1'b1, 4'b0000}), LAM_REP, T_SUM};   // [4] build B, [5] [6] records [size+2] [size+3] written
`else
                              total, BEATS[31:0], 8'd0, DBG_FLAGS, LAM_REP, T_SUM};
`endif
    // traffic record [size+1]: byte0 0x5B | bytes 8-15 read beats | 16-23 write beats on gmem2 (this launch)
    reg  [63:0]   trf_rd, trf_wr;
    wire [255:0]  trf_beat = {64'd0, trf_wr, trf_rd, 56'd0, 8'h5B};
`ifdef ORAM_ONPKG_DEBUG
    assign m_axi_gmem1_wdata = (kst == K_GDAT_W) ? wreg : (kst == K_SUM_W) ? sum_beat : (kst == K_TRF_W) ? trf_beat :
                               (kst == K_TR_W) ? ((tr_wi == 2'd0) ? tr_beat : (tr_wi == 2'd1) ? tr_beat2 : (tr_wi == 2'd2) ? tr_beat3 : 256'd0) :
                               (kst == K_DBG_W) ? c_ov_rec[256*dbg_i +: 256] : hdr_beat;
`elsif ORAM_PHASE_TRACE
    assign m_axi_gmem1_wdata = (kst == K_GDAT_W) ? wreg : (kst == K_SUM_W) ? sum_beat : (kst == K_TRF_W) ? trf_beat :
                               (kst == K_TR_W) ? tr_beat : hdr_beat;
`else
`ifdef DOMA_FAULT
    assign m_axi_gmem1_wdata = (kst == K_GDAT_W) ? wreg : (kst == K_SUM_W) ? sum_beat : (kst == K_TRF_W) ? trf_beat :
                               (kst == K_FLT_W) ? (f_wi ? f_obs : f_rec) : hdr_beat;
`else
    assign m_axi_gmem1_wdata = (kst == K_GDAT_W) ? wreg : (kst == K_SUM_W) ? sum_beat : (kst == K_TRF_W) ? trf_beat : hdr_beat;
`endif
`endif
    // unused channels
    assign m_axi_gmem0_awaddr = {C_M_AXI_ADDR_WIDTH{1'b0}}; assign m_axi_gmem0_awlen = 8'd0;
    assign m_axi_gmem0_awsize = ASIZE; assign m_axi_gmem0_awburst = 2'b01; assign m_axi_gmem0_awvalid = 1'b0;
    assign m_axi_gmem0_wdata = {DW{1'b0}}; assign m_axi_gmem0_wstrb = {(DW/8){1'b0}};
    assign m_axi_gmem0_wlast = 1'b0; assign m_axi_gmem0_wvalid = 1'b0; assign m_axi_gmem0_bready = 1'b1;
    assign m_axi_gmem1_araddr = {C_M_AXI_ADDR_WIDTH{1'b0}}; assign m_axi_gmem1_arlen = 8'd0;
    assign m_axi_gmem1_arsize = ASIZE; assign m_axi_gmem1_arburst = 2'b01; assign m_axi_gmem1_arvalid = 1'b0;
    assign m_axi_gmem1_rready = 1'b1;

    always @(posedge ap_clk) begin
        if (c_rvalid && rcnt < BEATS) rbuf[rcnt[BWI-1:0] & (BEATS - 1)] <= c_rdata;
        if (kst == K_GDAT_PRE || (kst == K_GDAT_W && m_axi_gmem1_wvalid && m_axi_gmem1_wready))
            wreg <= dmy ? {DW{1'b0}} : rbuf[(kst == K_GDAT_PRE) ? {BWI{1'b0}} : ((wcnt[BWI-1:0] + 1'b1) & (BEATS - 1))];   // a dummy writes zeros
    end

    always @(posedge ap_clk) begin
        if (rst) begin
            kst <= K_IDLE; boot_cnt <= 4'd0; key_sent <= 1'b0; doma_srst <= 1'b0; srst_cnt <= 5'd0; pages_base <= 64'd0; pages_hbm_base <= 64'd0; hbm_q <= 32'd0; pool_q <= 32'd0; meta_base <= 64'd0; brec_base <= 64'd0; stash_base <= 64'd0; nblk_q <= 32'd0; key_load <= 1'b0; lease_ok <= 1'b0;
            mgmt_req <= 1'b0; c_req <= 1'b0; c_op <= 1'b0; c_addr <= 0; c_token <= 32'd0; dmy <= 1'b0;
            idx <= 0; nsize <= 0; cbase <= 0; rbase <= 0; hc_off <= 0; hr_off <= 0; trf_rd <= 64'd0; trf_wr <= 64'd0;
            ctype <= 8'd0; ckey <= 32'd0; lat <= 0; lat_min <= 32'hFFFF_FFFF; lat_max <= 0; wait_cnt <= 0;
            total <= 64'd0; stat <= 0; errs <= 0; ndone <= 0; rcnt <= 0; wcnt <= 0;
            pf_ar <= 1'b0; pf_wait <= 1'b0; pf_valid <= 1'b0; wb_pend <= 16'd0;
            pd_ar <= 1'b0; pd_wait <= 1'b0; pd_valid <= 1'b0; pd_have <= 1'b0;
            m_axi_gmem0_arvalid <= 1'b0; m_axi_gmem0_araddr <= 0; m_axi_gmem0_arlen <= 8'd0;
            m_axi_gmem1_awvalid <= 1'b0; m_axi_gmem1_awaddr <= 0; m_axi_gmem1_awlen <= 8'd0; m_axi_gmem1_wvalid <= 1'b0;
            done_pulse <= 1'b0;
        end else begin
            done_pulse <= 1'b0; key_load <= 1'b0; mgmt_req <= 1'b0; c_req <= 1'b0;
            if (kst != K_IDLE && kst != K_DONE) total <= total + 64'd1;
            if (c_rvalid && rcnt < BEATS) rcnt <= rcnt + 1'b1;
            // prefetch: the address handshake (may complete after K_WAIT), then the header beat
            if (pf_ar && m_axi_gmem0_arvalid && m_axi_gmem0_arready) begin m_axi_gmem0_arvalid <= 1'b0; pf_ar <= 1'b0; pf_wait <= 1'b1; end
            if (pf_wait && m_axi_gmem0_rvalid) begin
                pf_type <= m_axi_gmem0_rdata[7:0]; pf_key <= m_axi_gmem0_rdata[63:32];
                pf_off <= m_axi_gmem0_rdata[95:64]; pf_len <= m_axi_gmem0_rdata[127:96];
                pf_wait <= 1'b0; pf_valid <= 1'b1;
            end
            // data-slot prefetch: the address handshake, then BEATS beats into pdbuf
            if (pd_ar && m_axi_gmem0_arvalid && m_axi_gmem0_arready) begin m_axi_gmem0_arvalid <= 1'b0; pd_ar <= 1'b0; pd_wait <= 1'b1; pd_cnt <= 0; end
            if (pd_wait && m_axi_gmem0_rvalid) begin
                pd_cnt <= pd_cnt + 1'b1;                       // the beat itself: the slot RAM above
                if (m_axi_gmem0_rlast) begin pd_wait <= 1'b0; pd_valid <= 1'b1; end
            end
            // posted responses: count each GET-data / header write, minus each B (the summary's own come later)
            wb_pend <= wb_pend
`ifdef ORAM_PHASE_TRACE
                     + (((kst == K_GDAT_AW || kst == K_RHDR_AW || kst == K_TR_AW) && m_axi_gmem1_awvalid && m_axi_gmem1_awready) ? 16'd1 : 16'd0)
`else
                     + (((kst == K_GDAT_AW || kst == K_RHDR_AW) && m_axi_gmem1_awvalid && m_axi_gmem1_awready) ? 16'd1 : 16'd0)
`endif
`ifdef ORAM_ONPKG_DEBUG
                     - ((m_axi_gmem1_bvalid && kst != K_SUM_B && kst != K_TRF_B && kst != K_DBG_B) ? 16'd1 : 16'd0);
`else
`ifdef DOMA_FAULT
                     - ((m_axi_gmem1_bvalid && kst != K_SUM_B && kst != K_TRF_B && kst != K_FLT_B) ? 16'd1 : 16'd0);
`else
                     - ((m_axi_gmem1_bvalid && kst != K_SUM_B && kst != K_TRF_B) ? 16'd1 : 16'd0);
`endif
`endif
            trf_rd <= trf_rd + ((m_axi_gmem2_rvalid && m_axi_gmem2_rready) ? 64'd1 : 64'd0);
            trf_wr <= trf_wr + ((m_axi_gmem2_wvalid && m_axi_gmem2_wready) ? 64'd1 : 64'd0);
            case (kst)
                K_IDLE: if (ap_start_r && !done_pulse) begin
`ifdef ORAM_PHASE_TRACE
                    nsize  <= {1'b0, arg_size[30:0]}; tr_en <= arg_size[31];   // bit 31: write a trace record per command
                    cbase <= arg_cmd; rbase <= arg_resp; trf_rd <= 64'd0; trf_wr <= 64'd0;
                    hc_off <= ({33'd0, arg_size[30:0]} * 64'd32 + 64'd4095) & ~64'd4095;
`ifdef ORAM_ONPKG_DEBUG
                    hr_off <= ({33'd0, arg_size[30:0]} * 64'd32 + 64'd160 + 64'd4095) & ~64'd4095;   // after [size] .. [size+4]
`else
                    hr_off <= ({33'd0, arg_size[30:0]} * 64'd32 + 64'd64 + 64'd4095) & ~64'd4095;
`endif
`else
                    nsize  <= arg_size; cbase <= arg_cmd; rbase <= arg_resp; trf_rd <= 64'd0; trf_wr <= 64'd0;
                    hc_off <= ({32'd0, arg_size} * 64'd32 + 64'd4095) & ~64'd4095;
                    hr_off <= ({32'd0, arg_size} * 64'd32 + 64'd64 + 64'd4095) & ~64'd4095;   // after records [size], [size+1]
`endif
                    idx <= 0; total <= 64'd0; ndone <= 0; lat_min <= 32'hFFFF_FFFF; lat_max <= 0; settle <= 3'd0;
                    pf_valid <= 1'b0; pd_valid <= 1'b0; pd_have <= 1'b0;   // never a header or slot from an earlier run
                    // first launch, or any init launch (size 0): (re)boot DOMA with these arguments. An init launch
                    // on a booted kernel resets the DOMA core first (K_RST), so every run starts from a fresh
                    // boot whatever ran before. A launch WITH commands naming a different buffer is flagged.
                    if (!key_sent || arg_size == 32'd0) begin pages_base <= arg_pages; meta_base <= arg_meta; brec_base <= arg_brec; stash_base <= arg_stash;
                                         nblk_q <= arg_nblk; pages_hbm_base <= arg_pages_hbm; hbm_q <= arg_hbm_bkts; pool_q <= arg_pool_n; errs <= (arg_nblk > `ORAM_N) ? 32'h80 : 32'h0; end   // 0x80: above the maximum
                    else errs <= (arg_pages != pages_base || arg_meta != meta_base || arg_brec != brec_base || arg_stash != stash_base || arg_nblk != nblk_q || arg_pages_hbm != pages_hbm_base || arg_hbm_bkts != hbm_q || arg_pool_n != pool_q) ? 32'h20 : 32'h0;
                    kst <= (key_sent && arg_size == 32'd0) ? K_RST : K_BOOT;
                end
                K_RST: begin                                      // re-boot: hold the DOMA core in reset 16 cycles
                    doma_srst <= 1'b1; srst_cnt <= srst_cnt + 1'b1;
                    if (srst_cnt == 5'd15) begin
                        doma_srst <= 1'b0; srst_cnt <= 5'd0; key_sent <= 1'b0; lease_ok <= 1'b0; kst <= K_BOOT;
                    end
                end
                K_BOOT:   if (!key_sent) begin                       // boot DOMA once the registered sizes settled
                              if (!kdv_idle) settle <= 3'd0;              // the bucket count is being computed
                              else if (settle != 3'd7) settle <= settle + 3'd1;
                              else begin key_load <= 1'b1; key_sent <= 1'b1; end
                          end
                          else if (halted) begin errs <= errs | HALT_BITS; kst <= K_SUM_AW; end   // halted at boot (e.g. the
                                                                                                  // pool cannot hold the placement's excess)
                          else if (key_ready && oram_ready)
                              kst <= !lease_ok ? K_LEASE : ((nsize == 0) ? K_SUM_AW : K_HDR_AR);
                K_LEASE:  begin mgmt_req <= 1'b1; kst <= K_LEASE_W; end
                K_LEASE_W: if (mgmt_ack) begin
                    c_token <= c_token_lane; lease_ok <= !mgmt_error;
                    if (mgmt_error) begin errs <= errs | 32'h1; kst <= K_SUM_AW; end
                    else kst <= (nsize == 0) ? K_SUM_AW : K_HDR_AR;
                end
                // ---- fetch the command header
                K_HDR_AR: begin
                    m_axi_gmem0_araddr <= cbase + {idx, 5'd0}; m_axi_gmem0_arlen <= 8'd0; m_axi_gmem0_arvalid <= 1'b1;
                    if (m_axi_gmem0_arvalid && m_axi_gmem0_arready) begin m_axi_gmem0_arvalid <= 1'b0; kst <= K_HDR_R; end
                end
                K_HDR_R: if (m_axi_gmem0_rvalid) begin
                    ctype <= m_axi_gmem0_rdata[7:0]; ckey <= m_axi_gmem0_rdata[63:32];
                    coff <= m_axi_gmem0_rdata[95:64]; clen <= m_axi_gmem0_rdata[127:96]; wait_cnt <= 0; kst <= K_REQ;
                end
                // ---- issue the request to DOMA
                K_REQ: begin
                    stat <= 32'd0; rcnt <= 0; lat <= 0; dmy <= 1'b0;
                    if (halted) begin stat <= 32'h8; errs <= errs | HALT_BITS; kst <= K_RHDR_AW; end
                    else if (c_ready) begin
                        c_req <= 1'b1; kst <= K_REQ_P;
                        if (rej_code != 32'd0) begin stat <= rej_code; dmy <= 1'b1; c_op <= 1'b0; c_addr <= 0; end   // dummy GET of slot 0
                        else begin c_op <= (ctype == T_PUT); c_addr <= ckey << 12; end
                    end else if (wait_cnt >= CMD_TIMEOUT) begin
                        stat <= 32'h10; errs <= errs | 32'h10; kst <= K_RHDR_AW;
                    end else wait_cnt <= wait_cnt + 1;
                end
                K_REQ_P: begin                                        // c_req is high this cycle: register the verdict
                    lat <= lat + 1; wait_cnt <= 0; viol_q <= c_viol; kst <= K_REQ_V;
                end
                K_REQ_V: begin                                        // timing: decide from the registered verdict
                    lat <= lat + 1;
                    if (viol_q) begin stat <= 32'h4; dmy <= 1'b1; kst <= pd_have ? K_DAT_P : K_DAT_AR; end   // lease violation: the core serves a dummy
                    else kst <= pd_have ? K_DAT_P : K_DAT_AR;          // every command streams its data slot
                end
                K_DAT_P: begin lat <= lat + 1; pcnt <= 0; kst <= K_DAT_S; end   // the RAM reads beat 0 now
                K_DAT_S: begin                                        // prefetched slot, one beat per cycle
                    lat <= lat + 1; pcnt <= pcnt + 1'b1;                          // the RAM reads beat pcnt + 1
                    if (pcnt == BEATS - 1) kst <= K_WAIT;
                end
                K_DAT_AR: begin
                    lat <= lat + 1;
                    m_axi_gmem0_araddr <= cbase + hc_off + {idx, {$clog2(BLOCK){1'b0}}};
                    m_axi_gmem0_arlen <= BEATS - 1; m_axi_gmem0_arvalid <= 1'b1; pcnt <= 0;
                    if (m_axi_gmem0_arvalid && m_axi_gmem0_arready) begin m_axi_gmem0_arvalid <= 1'b0; kst <= K_DAT_R; end
                end
                K_DAT_R: begin
                    lat <= lat + 1;
                    if (m_axi_gmem0_rvalid) pcnt <= pcnt + 1'b1;
                    if (m_axi_gmem0_rvalid && m_axi_gmem0_rlast) kst <= K_WAIT;
                end
                K_WAIT: begin
                    lat <= lat + 1; wait_cnt <= wait_cnt + 1;
                    if (!pf_valid && !pf_wait && !pf_ar && idx + 1 < nsize) begin   // prefetch the next header
                        m_axi_gmem0_araddr <= cbase + {idx + 1'b1, 5'd0}; m_axi_gmem0_arlen <= 8'd0;
                        m_axi_gmem0_arvalid <= 1'b1; pf_ar <= 1'b1;
                    end else if (pf_valid && !pd_valid && !pd_ar && !pd_wait) begin     // then its data slot
                        m_axi_gmem0_araddr <= cbase + hc_off + {idx + 1'b1, {$clog2(BLOCK){1'b0}}};
                        m_axi_gmem0_arlen <= BEATS - 1; m_axi_gmem0_arvalid <= 1'b1; pd_ar <= 1'b1;
                    end
                    if (c_done) begin
                        if (!dmy) begin                                // a rejected command's dummy is not counted
                            ndone <= ndone + 1;
                            if (lat + 1 < lat_min) lat_min <= lat + 1;
                            if (lat + 1 > lat_max) lat_max <= lat + 1;
                        end
                        kst <= K_GDAT_AW;                              // every command writes its data slot
                    end else if (halted || wait_cnt >= CMD_TIMEOUT) begin
                        stat <= halted ? 32'h8 : 32'h10; errs <= errs | (halted ? HALT_BITS : 32'h10);
                        kst <= K_RHDR_AW;
                    end
                end
                // ---- GET data, then the header
                K_GDAT_AW: begin
                    m_axi_gmem1_awaddr <= rbase + hr_off + {idx, {$clog2(BLOCK){1'b0}}};
                    m_axi_gmem1_awlen <= BEATS - 1; m_axi_gmem1_awvalid <= 1'b1;
                    if (m_axi_gmem1_awvalid && m_axi_gmem1_awready) begin m_axi_gmem1_awvalid <= 1'b0; kst <= K_GDAT_PRE; end
                end
                K_GDAT_PRE: begin wcnt <= 0; kst <= K_GDAT_W; end    // wreg <= rbuf[0]
                K_GDAT_W: begin
                    m_axi_gmem1_wvalid <= 1'b1;
                    if (m_axi_gmem1_wvalid && m_axi_gmem1_wready) begin
                        wcnt <= wcnt + 1'b1;
                        if (wcnt == BEATS - 1) begin m_axi_gmem1_wvalid <= 1'b0; kst <= K_RHDR_AW; end   // posted: no wait for B
                    end
                end
                K_GDAT_B: if (m_axi_gmem1_bvalid) kst <= K_RHDR_AW;
                K_RHDR_AW: begin
                    m_axi_gmem1_awaddr <= rbase + {idx, 5'd0}; m_axi_gmem1_awlen <= 8'd0; m_axi_gmem1_awvalid <= 1'b1;
                    if (m_axi_gmem1_awvalid && m_axi_gmem1_awready) begin m_axi_gmem1_awvalid <= 1'b0; kst <= K_RHDR_W; end
                end
                K_RHDR_W: begin
                    m_axi_gmem1_wvalid <= 1'b1;
`ifdef ORAM_PHASE_TRACE
                    if (m_axi_gmem1_wvalid && m_axi_gmem1_wready) begin m_axi_gmem1_wvalid <= 1'b0; kst <= tr_en ? K_TR_AW : K_NEXT; end
`else
                    if (m_axi_gmem1_wvalid && m_axi_gmem1_wready) begin m_axi_gmem1_wvalid <= 1'b0; kst <= K_NEXT; end   // posted
`endif
                end
                K_RHDR_B: if (m_axi_gmem1_bvalid) kst <= K_NEXT;
`ifdef ORAM_PHASE_TRACE
`ifdef ORAM_ONPKG_DEBUG
                K_TR_AW: begin                                        // debug: 128 bytes, the phase timestamps, the core's record, its stash open, zeros
                    m_axi_gmem1_awaddr <= rbase + hr_off + ({32'd0, nsize} << $clog2(BLOCK)) + {idx, 7'd0};
                    m_axi_gmem1_awlen <= 8'd3; m_axi_gmem1_awvalid <= 1'b1; tr_wi <= 2'd0;
                    if (m_axi_gmem1_awvalid && m_axi_gmem1_awready) begin m_axi_gmem1_awvalid <= 1'b0; kst <= K_TR_W; end
                end
                K_TR_W: begin
                    m_axi_gmem1_wvalid <= 1'b1;
                    if (m_axi_gmem1_wvalid && m_axi_gmem1_wready) begin
                        if (tr_wi == 2'd3) begin m_axi_gmem1_wvalid <= 1'b0; kst <= K_NEXT; end   // posted
                        tr_wi <= tr_wi + 2'd1;
                    end
                end
`else
                K_TR_AW: begin                                        // the trace record, after the response data
                    m_axi_gmem1_awaddr <= rbase + hr_off + ({32'd0, nsize} << $clog2(BLOCK)) + {idx, 5'd0};
                    m_axi_gmem1_awlen <= 8'd0; m_axi_gmem1_awvalid <= 1'b1;
                    if (m_axi_gmem1_awvalid && m_axi_gmem1_awready) begin m_axi_gmem1_awvalid <= 1'b0; kst <= K_TR_W; end
                end
                K_TR_W: begin
                    m_axi_gmem1_wvalid <= 1'b1;
                    if (m_axi_gmem1_wvalid && m_axi_gmem1_wready) begin m_axi_gmem1_wvalid <= 1'b0; kst <= K_NEXT; end   // posted
                end
`endif
`endif
                K_NEXT: if (!pf_ar && !pf_wait && !pd_ar && !pd_wait) begin   // a prefetch in flight lands first
                    idx <= idx + 1;
                    // a halted DOMA serves nothing more: end the run with the summary
                    if ((idx + 1 == nsize) || halted || stat[4]) kst <= K_SUM_AW;
                    else if (pf_valid) begin                           // the header is already here
                        ctype <= pf_type; ckey <= pf_key; coff <= pf_off; clen <= pf_len;
                        wait_cnt <= 0; pf_valid <= 1'b0; kst <= K_REQ;
                        pd_have <= pd_valid; pd_valid <= 1'b0;             // its data slot, if it arrived
                    end else begin pd_have <= 1'b0; pd_valid <= 1'b0; kst <= K_HDR_AR; end
                end
                // ---- summary record [size]
                K_SUM_AW: if (wb_pend == 16'd0 && !pf_ar && !pf_wait && !pd_ar && !pd_wait) begin   // every response acknowledged
                    m_axi_gmem1_awaddr <= rbase + {nsize, 5'd0}; m_axi_gmem1_awlen <= 8'd0; m_axi_gmem1_awvalid <= 1'b1;
                    if (m_axi_gmem1_awvalid && m_axi_gmem1_awready) begin m_axi_gmem1_awvalid <= 1'b0; kst <= K_SUM_W; end
                end
                K_SUM_W: begin
                    m_axi_gmem1_wvalid <= 1'b1;
                    if (m_axi_gmem1_wvalid && m_axi_gmem1_wready) begin m_axi_gmem1_wvalid <= 1'b0; kst <= K_SUM_B; end
                end
                K_SUM_B: if (m_axi_gmem1_bvalid) kst <= K_TRF_AW;
                // ---- traffic record [size+1] (its own single-beat write: a 2-beat burst from [size] could
                //      cross a 4 KB boundary when (size+1)*32 is a multiple of 4 KB)
                K_TRF_AW: begin
                    m_axi_gmem1_awaddr <= rbase + {nsize + 32'd1, 5'd0}; m_axi_gmem1_awlen <= 8'd0; m_axi_gmem1_awvalid <= 1'b1;
                    if (m_axi_gmem1_awvalid && m_axi_gmem1_awready) begin m_axi_gmem1_awvalid <= 1'b0; kst <= K_TRF_W; end
                end
                K_TRF_W: begin
                    m_axi_gmem1_wvalid <= 1'b1;
                    if (m_axi_gmem1_wvalid && m_axi_gmem1_wready) begin m_axi_gmem1_wvalid <= 1'b0; kst <= K_TRF_B; end
                end
`ifdef ORAM_ONPKG_DEBUG
                K_TRF_B: if (m_axi_gmem1_bvalid) begin dbg_i <= 2'd0; kst <= K_DBG_AW; end
                // ---- debug records [size+2] (counters), [size+3] (first on-package overrun), [size+4] (first deadline
                //      (2) miss), one single-beat write each
                K_DBG_AW: begin
                    m_axi_gmem1_awaddr <= rbase + {nsize + 32'd2 + {30'd0, dbg_i}, 5'd0}; m_axi_gmem1_awlen <= 8'd0; m_axi_gmem1_awvalid <= 1'b1;
                    if (m_axi_gmem1_awvalid && m_axi_gmem1_awready) begin m_axi_gmem1_awvalid <= 1'b0; kst <= K_DBG_W; end
                end
                K_DBG_W: begin
                    m_axi_gmem1_wvalid <= 1'b1;
                    if (m_axi_gmem1_wvalid && m_axi_gmem1_wready) begin m_axi_gmem1_wvalid <= 1'b0; kst <= K_DBG_B; end
                end
                K_DBG_B: if (m_axi_gmem1_bvalid) begin
                    if (dbg_i == 2'd2) kst <= K_DONE; else begin dbg_i <= dbg_i + 2'd1; kst <= K_DBG_AW; end
                end
`else
`ifdef DOMA_FAULT
                K_TRF_B: if (m_axi_gmem1_bvalid) kst <= f_rec_ok ? K_FLT_AW : K_DONE;
                // ---- build B: the fault/stash record [size+2] (when it fits before the response data)
                K_FLT_AW: begin
                    m_axi_gmem1_awaddr <= rbase + {nsize + 32'd2, 5'd0}; m_axi_gmem1_awlen <= f_rec2_ok ? 8'd1 : 8'd0;
                    m_axi_gmem1_awvalid <= 1'b1; f_wi <= 1'b0;
                    if (m_axi_gmem1_awvalid && m_axi_gmem1_awready) begin m_axi_gmem1_awvalid <= 1'b0; kst <= K_FLT_W; end
                end
                K_FLT_W: begin
                    m_axi_gmem1_wvalid <= 1'b1;
                    if (m_axi_gmem1_wvalid && m_axi_gmem1_wready) begin
                        if (f_wi || !f_rec2_ok) begin m_axi_gmem1_wvalid <= 1'b0; kst <= K_FLT_B; end
                        f_wi <= 1'b1;
                    end
                end
                K_FLT_B: if (m_axi_gmem1_bvalid) kst <= K_DONE;
`else
                K_TRF_B: if (m_axi_gmem1_bvalid) kst <= K_DONE;
`endif
`endif
                K_DONE: begin done_pulse <= 1'b1; kst <= K_IDLE; end
                default: kst <= K_IDLE;
            endcase
        end
    end
endmodule
