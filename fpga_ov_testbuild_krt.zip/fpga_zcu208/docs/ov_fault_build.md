# The overlap test build for the K design, K = 4 (OV_TRACE=1 OV_FAULT=1)

One test bitstream for the card tests that the production bitstream cannot run:

| Test | How | Pass |
|---|---|---|
| Exact schedule on the card | `host_leak_ov` with the hooks off (`DOMA_OVF=1`) | every rule `exact` |
| Planted-leak control | the same with `DOMA_OV_LEAK=1`: every PUT's read gate one cycle late | the schedule is `NOT exact` |
| Accesses in flight | the trace analysis counts them at each start | reported |
| P1 host-memory bucket tamper | `host_fault_ov` P1: bit flip, replay, swap, zero, truncate, unchanged rewrite (control), black-box | tag halt 0x208 at the bucket, no result from the failed access |
| P2 on-package bucket tamper | `host_fault_ov` P2, host DMA into HBM | expected NOT detected (on-package buckets are plaintext, as in v14) |
| P3 tag/IV corruption | `host_fault_ov` P3 | tag halt 0x208, the access wrote nothing |
| P8 in-flight beat corruption | `host_fault_ov` P8 (host port, and on package) | host port: tag halt; on package: expected NOT detected |
| PI the same with other commands in flight | `host_fault_ov` PI: the target is command 1..14 of a 16-command launch | as above; every result returned is correct |

It is the overlap production design plus OV_TRACE's header records and the hooks. **Never measure performance with
it and never deploy it.** With `OV_FAULT` unset the preprocessed RTL is byte-identical to production (checked for
doma_kernel.v, flat_oram_gcm.v and secure_oram_top.v).

## What the hooks are

All are armed per launch through `flt_ctl` (the v14d build B register map, 22 kernel arguments,
`vitis/kernel_fault.xml`) and are 0, disarmed, unless the host sets them. Disarmed, DOMA's logic is the production
logic; the kernel only writes two more records at the end of each launch.

| Bit of `flt_ctl` | Hook | Where |
|---|---|---|
| [4] | P1 steering: the access to block `flt_p1k` takes bucket `flt_p1b` as its new bucket ([13] every access to it, [12] every access) | flat_oram_gcm F stage, the new-bucket select |
| [0] | P3: flip bit `flt_p3` (0..95 IV, 96..223 tag) of the {tag, IV} used for the tag check of command `flt_cmd`'s access | where M takes them (S_CR_IVW), since with accesses in flight the record can be fetched twice |
| [3] | P8: flip bit `flt_p8[7:0]` of beat `flt_p8[23:8]` (0..1023) of command `flt_cmd`'s bucket read; [8] selects on package / host | the landed beat, before the scratch buffer |
| [6] | planted leak: every PUT's read gate one cycle late | the phase 3 read issuer |

The kernel finds the target's context: accesses are taken in command order, one per command (a rejected command's
dummy too), so the k-th access taken in a launch is command k.

Records after the summary (summary byte 2: [4] header records, [5] [6] these records written, [7] this build):
- `[n+2]` byte 0 0x5F, byte 1 hooks fired ([0] P3, [3] P8, [4] P1, [6] P3's record was on package), bytes 2-3 P1
  overrides. Bytes 4-31 are zero (v14d's stash statistics are not in this build).
- `[n+3]` byte 0 0x60, the observation record in v14d's layout. In this build "the halting access" is the one M was
  working on (for a tag failure, the failed one); its bucket writes and results are counted per context. An order
  violation is a write-back's bucket AW, or an access's first result beat, before that access's own read verified.

## Build

`make_test_build.sh` (in the zip) copies the K design (from its zip or a tree), applies `patches/ov_testbuild.patch`, adds
the new files and prints the build command. In short:

```bash
bash make_test_build.sh ~/fpga_zcu208_v14c_respfix_krt_full.zip ~/p3rx300krttest
cd ~/p3rx300krttest/fpga_zcu208/vitis
OVERLAP=4 P3=1 OV_PMIN=1600 OV_GA=1600 OV_XWB=300 OV_TRACE=1 OV_FAULT=1 SCHED=arrival BEATS=128 CFG=doma_big2m_rama.cfg NMAX=2097152 LAMBDA=7 TARGET=hw nohup bash build.sh > build.log 2>&1 &
```

`build.sh` refuses OV_FAULT without OVERLAP=4 P3=1 and OV_TRACE=1, and with OV_TEST_LEAK. It builds `host_fault_ov` and
`host_leak_ov` next to the bitstream. Check timing closure as usual: the hooks add logic, and none of it has been
through Vivado.

## Before the build (recommended): the mock run

On the build machine, from `sim/`, while nothing else needs the folder's `sim/`:

```bash
bash ov_test_mock.sh
```

It Verilates the test build, runs every fault test at a small scale, the exact check with the hooks off and the planted
leak, and ends `MOCK TEST BUILD OK`. This is the first time the hooks run at all.

## On the card (from vitis/, one record count at a time)

1. Hooks off: the exact schedule, the latency comparisons and the rate check. Run each record count on its own:

   ```bash
   DOMA_OVF=1 NS=14 bash leak_runs_ov.sh doma_hw.xclbin tb_n14
   ```

   and the same with `NS=35`, `NS=4096`, `NS=1048576` (new folder each). Pass: `NO LEAK FOUND`, `schedule exact`,
   `ANALYSIS CONTROL PASSED`, `RATE DOES NOT DEPEND ON THE COMMANDS`. The `.analysis` file also lists how many accesses
   were in flight when each one started.

2. The planted leak, the positive control:

   ```bash
   DOMA_OVF=1 DOMA_OV_LEAK=1 NS=4096 bash leak_runs_ov.sh doma_hw.xclbin tb_leak
   ```

   Pass: `tb_leak/n4096.analysis` shows `schedule NOT exact`. The script then reports `SOMETHING TO LOOK AT`, which here
   is the expected result.

3. The fault tests:

   ```bash
   DOMA_OV_K=4 flock -n ~/.u55c_card.lock ./host_fault_ov doma_hw.xclbin all > fault_16k.log 2>&1
   DOMA_OV_K=4 DOMA_N=35 flock -n ~/.u55c_card.lock ./host_fault_ov doma_hw.xclbin P0,P1,P3,P8,PI > fault_35.log 2>&1
   DOMA_OV_K=4 DOMA_N=1048576 flock -n ~/.u55c_card.lock ./host_fault_ov doma_hw.xclbin P0,P1,P3,P8,PI --scale 0.05 > fault_1m.log 2>&1
   ```

   Pass: each log ends `ALL TRIALS PASSED`. Rows marked `v14:none` (P2, P8 on package) are expected not to be
   detected: on-package buckets are plaintext. `DOMA_N=35` has 5 buckets, so other accesses often share the target's
   bucket; P2 needs two on-package buckets and is skipped there.

4. The high-stash test, one record count at a time, in a new folder each:

   ```bash
   DOMA_OVF=1 bash leak_highstash_ov.sh doma_hw.xclbin hs_n4096 4096
   DOMA_OVF=1 bash leak_highstash_ov.sh doma_hw.xclbin hs_n1m 1048576
   ```

   Phases alternate a sequential scan (the stash fills) and uniform requests (it drains), four times, each at least five
   times the bucket count long. Every request records the stash at its open: pool entries in use, whether its bucket has
   blocks waiting beyond its window, and the window entries (header bytes 1-3). `sim/card_highstash_ov.py` compares the
   latency of the fullest 10% of requests with the emptiest 10%, and of the buckets with the longest identifiable waiting
   list with empty ones, on and off package, and reports the peak stash. Pass: `NO STASH-LEVEL DEPENDENCE FOUND`. The design
   keeps no per-bucket count, so the waiting list is the window fill and whether a chain exists, not a full length.

5. The same-bucket conflict rate, one record count at a time (more bucket counts make a better figure; 7 records per bucket):

   ```bash
   for n in 14 35 140 700 4096 1048576; do DOMA_OVF=1 bash leak_conflict_ov.sh doma_hw.xclbin conflict $n; done
   python3 ../sim/card_conflict_ov.py plot conflict/fig_conflict conflict/n*.json
   ```

   One phase per workload (uniform, one key, re-request, turns of 2 to 5 keys, scan). For each request: did its bucket match
   one of the three before it (the prediction is 1 - (1 - 1/B)^3, about 3/B for large B), and did its read issue later because
   of that. `fig_conflict.csv` always; the PDF and PNG need matplotlib. If the card drops during the loop, rerun that record
   count: run them one at a time if it does.

`host_leak_ov` refuses this bitstream without `DOMA_OVF=1`: it then passes all 22 arguments, so registers left set by
`host_fault_ov` are cleared at every launch.

## K
This package is for K = 4 (`DOMA_OV_K=4`, or unset). `leak_runs_ov.sh` and `leak_highstash_ov.sh` refuse any other K: the exact
schedule rules have no term for a smaller cap (`check_p3.py --k K` in simulation has it). The hosts stop if the boot refuses K.
All card programs here take `~/.u55c_card.lock`, the lock `krt_run.sh` uses, so they cannot share the card with it.

## Limits

- The hooks have been linted and simulated end to end in the XRT mock (`sim/ov_test_mock.sh`: n = 140, every test at a small
  scale, 20 more in-flight trials per fault), and the production configuration is byte-identical after preprocessing.
  They have not been through Vivado or on the card.
- This bitstream is a different netlist from production. Its schedule results describe the same RTL; report its
  achieved clock.
- P4 to P7 and P9 of v14d's plan (stash full, deadline trims, delays, wrong token, stress) are not in this build.
- What happens after a halt is not judged. The tests check the halt, its cause and bucket, that the failed access wrote
  and released nothing, and that every result returned before it is correct. Each trial re-boots DOMA first.
