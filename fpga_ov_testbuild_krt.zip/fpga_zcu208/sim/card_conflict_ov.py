#!/usr/bin/env python3
"""card_conflict_ov.py -- how often a request meets, and waits for, another in-flight request on its bucket (docs/ov_fault_build.md).

  python3 card_conflict_ov.py count <records> <leak.csv> <out.json>     per workload, from one CSV of leak_conflict_ov.sh
  python3 card_conflict_ov.py plot <prefix> <a.json> [<b.json> ...]     <prefix>.csv, and .pdf/.png if matplotlib is present

Needs the test build's trace (OV_TRACE). For each request:
  conflict  its bucket equals that of one of the three requests before it (the design's public same-bucket mask em)
  waited    its bucket read issued later than it would have without that conflict: later than the other read-issue terms,
            s + CT_RD, the previous issue + 2 and the read two back completing
The prediction for a uniformly random bucket and K = 4 is 1 - (1 - 1/B)^3, about 3/B when B is large (3/B exceeds 1 at B = 2).
A tree ORAM conflicts on every request, since every path shares the root. The first three requests of a run are left out."""
import csv, json, os, sys
from array import array
import numpy as np
CTRD, MASK28, SAT = 600, (1 << 28), 0xFFFF

def wilson(k, n, z=1.96):
    if n == 0: return (0.0, 0.0)
    p = k / n; d = 1 + z * z / n; c = (p + z * z / (2 * n)) / d; h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0.0, c - h), min(1.0, c + h))

def count(n_rec, path, out):
    NUM = ("s", "ri", "a", "em", "hbm")
    col = {k: array("q") for k in NUM}; kinds = []
    with open(path) as f:
        for r in csv.DictReader(f):
            try: v = [int(r[k]) for k in NUM]
            except (TypeError, ValueError, KeyError): continue
            for k, x in zip(NUM, v): col[k].append(x)
            kinds.append(r["kind"])
    d = {k: np.frombuffer(v, dtype=np.int64) for k, v in col.items()}
    n = len(d["s"])
    if n < 4 or not np.any(d["s"] != 0): sys.exit("card_conflict_ov: no OV_TRACE records in " + path)
    kinds = np.array(kinds)
    s = np.concatenate(([int(d["s"][0])], int(d["s"][0]) + np.cumsum(np.diff(d["s"]) % MASK28))).astype(np.int64)
    ok = (d["ri"] != SAT) & (d["a"] != SAT)
    ri, a = s + d["ri"], s + d["a"]
    p1 = np.concatenate(([ri[0] - 2], ri[:-1])); a2 = np.concatenate((a[:2] - 10**9, a[:-2]))
    base = np.maximum(np.maximum(s + CTRD + 1, p1 + 2), a2 + 1)      # the read issue rule without the same-bucket term
    em = d["em"]; idx = np.arange(n) >= 3
    nc = idx & ok & (em == 0)
    mism = int(np.count_nonzero(ri[nc] != base[nc]))                 # no conflict: the rule must hold exactly (a check on the offsets)
    B = (n_rec + 6) // 7
    res = dict(records=n_rec, buckets=B, requests=int(n), no_conflict_rule_mismatches=mism, workloads={})
    for k in sorted(set(kinds.tolist())):
        m = idx & ok & (kinds == k); t = int(m.sum())
        c = m & (em != 0); w = c & (ri > base)
        res["workloads"][k] = dict(requests=t, conflict=int(c.sum()), waited=int(w.sum()),
                                   dist=[int(np.count_nonzero(m & (((em >> b) & 1) == 1))) for b in range(3)],
                                   conflict_share=c.sum() / max(1, t), waited_share=w.sum() / max(1, t),
                                   mean_wait=float((ri[w] - base[w]).mean()) if w.any() else 0.0,
                                   conflict_ci=wilson(int(c.sum()), t), waited_ci=wilson(int(w.sum()), t))
    json.dump(res, open(out, "w"), indent=1)
    pred = 1 - (1 - 1 / B) ** 3
    print(f"n = {n_rec}, {B} buckets, {n} requests; predicted conflict share {100 * pred:.4f}% (3/B = {300 / B:.4f}%); no-conflict rule mismatches {mism}")
    print(f"  {'workload':<9}{'requests':>10}{'conflict %':>12}{'waited %':>11}{'mean wait':>11}")
    for k, v in res["workloads"].items():
        print(f"  {k:<9}{v['requests']:>10}{100 * v['conflict_share']:>12.4f}{100 * v['waited_share']:>11.4f}{v['mean_wait']:>11.1f}")

def plot(prefix, files):
    R = [json.load(open(f)) for f in files]; R.sort(key=lambda r: r["buckets"])
    with open(prefix + ".csv", "w", newline="") as f:
        w = csv.writer(f); w.writerow(["records", "buckets", "workload", "requests", "conflict", "waited", "conflict_share", "waited_share", "predicted_share", "mean_wait_cycles"])
        for r in R:
            B = r["buckets"]
            for k, v in r["workloads"].items():
                w.writerow([r["records"], B, k, v["requests"], v["conflict"], v["waited"], v["conflict_share"], v["waited_share"], 1 - (1 - 1 / B) ** 3, v["mean_wait"]])
    print("wrote", prefix + ".csv")
    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib is not installed here: plot from the .csv elsewhere"); return
    ORDER = ["uni", "fixed", "rereq", "ab", "t3", "t4", "t5", "scan"]
    LABEL = {"uni": "uniform", "fixed": "one key", "rereq": "re-request", "ab": "2 keys in turn", "t3": "3 keys", "t4": "4 keys", "t5": "5 keys", "scan": "scan"}
    COL = dict(zip(ORDER, ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]))   # reference palette, fixed order
    MARK = dict(zip(ORDER, ["o", "s", "^", "D", "v", "P", "X", "*"]))
    INK2, GRID = "#52514e", "#e4e3df"
    plt.rcParams.update({"font.size": 8, "axes.edgecolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False, "pdf.fonttype": 42})
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.9), sharey=True)
    Bs = sorted({r["buckets"] for r in R}); bb = np.logspace(np.log10(min(Bs)) - 0.1, np.log10(max(Bs)) + 0.1, 200)
    for ax, field, ci, title in ((axes[0], "conflict_share", "conflict_ci", "(a) requests whose bucket was in flight"), (axes[1], "waited_share", "waited_ci", "(b) requests that waited")):
        ax.set_axisbelow(True); ax.grid(True, color=GRID, linewidth=0.6)
        ax.plot(bb, 1 - (1 - 1 / bb) ** 3, color=INK2, linewidth=1.2, label=r"prediction $1-(1-1/B)^3$", zorder=2)
        ax.plot(bb[bb > 3], 3 / bb[bb > 3], color=INK2, linewidth=1.0, linestyle=":", label=r"$3/B$", zorder=2)
        ax.axhline(1.0, color="#e34948", linewidth=1.0, linestyle="--", zorder=1)
        ax.text(bb[-1], 1.12, "tree ORAM: every request (root)", ha="right", va="bottom", fontsize=7, color=INK2)
        kinds = [k for k in ORDER if any(k in r["workloads"] for r in R)]
        for j, k in enumerate(kinds):
            xs, ys, lo, hi = [], [], [], []
            for r in R:
                v = r["workloads"].get(k)
                if v and v[field] > 0:
                    xs.append(r["buckets"] * 10 ** ((j - (len(kinds) - 1) / 2) * 0.018)); ys.append(v[field]); lo.append(max(0, v[field] - v[ci][0])); hi.append(max(0, v[ci][1] - v[field]))
            if xs: ax.errorbar(xs, ys, yerr=[lo, hi], fmt=MARK[k], color=COL[k], markersize=4.5, markeredgecolor="white", markeredgewidth=0.4, elinewidth=0.8, capsize=0, linestyle="none", label=LABEL[k], zorder=3)
        ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlabel("buckets $B$"); ax.set_title(title, loc="left", fontsize=8); ax.tick_params(length=0)
        ax.set_ylim(top=2.2)
    axes[0].set_ylabel("share of requests")
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=5, frameon=False, fontsize=6.5, bbox_to_anchor=(0.5, 1.02))
    fig.tight_layout(rect=(0, 0, 1, 0.86))
    for e in ("pdf", "png"): fig.savefig(f"{prefix}.{e}", dpi=300)
    print("wrote", prefix + ".pdf, .png")

if __name__ == "__main__":
    if len(sys.argv) == 5 and sys.argv[1] == "count": count(int(sys.argv[2]), sys.argv[3], sys.argv[4])
    elif len(sys.argv) >= 4 and sys.argv[1] == "plot": plot(sys.argv[2], sys.argv[3:])
    else: sys.exit(__doc__)
