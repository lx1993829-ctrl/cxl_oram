#!/usr/bin/env python3
"""card_highstash_ov.py leak.csv [--out summary.json] -- does latency depend on how full the stash is? (docs/ov_fault_build.md)

leak.csv comes from vitis/leak_highstash_ov.sh on the overlap test build (OV_TRACE records: per request, the stash at its open:
occ pool entries in use, chain the bucket has blocks waiting beyond its window, wc entries in its window). Phases alternate a
sequential scan (the stash fills) and uniform requests (it drains).

Comparisons, each by the request's own latency, separately for on- and off-package buckets:
  occupancy     the fullest 10% of requests against the emptiest 10%
  waiting list  the bucket's waiting list: longest we can identify (window full and more on its chain, or, if too few, the
                fullest window seen) against shortest (empty window, no chain)
Requests that share a bucket with one of the three before them are left out: that wait is public, and it would otherwise
be mixed into the comparison. A flag is |t| > 4.5 or a Holm rejection at 0.01 of the smaller of the t and KS p-values.
The waiting list is not a full length: the design keeps no per-bucket count, only the window and whether a chain exists.
Unlike the class comparisons these are not randomized (no coin decides a request's stash level), so slow drift can show up
as a difference. Halts are not judged."""
import argparse, csv, json, os, sys
from array import array
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import card_leak_analyze_ov as A

ap = argparse.ArgumentParser(); ap.add_argument("leak_csv"); ap.add_argument("--out", default="highstash.json")
ap.add_argument("--min-group", type=int, default=200, help="fewest requests in a group for a comparison")
a = ap.parse_args()
NUM = ("phase", "lat", "hbm", "em", "occ", "chain", "wc", "end")
col = {k: array("q") for k in NUM}; kinds = []; cut = 0
with open(a.leak_csv) as f:
    for r in csv.DictReader(f):
        try: v = [int(r[k]) for k in NUM]
        except (TypeError, ValueError, KeyError): cut += 1; continue
        for k, x in zip(NUM, v): col[k].append(x)
        kinds.append(r["kind"])
d = {k: np.frombuffer(v, dtype=np.int64) if len(v) else np.zeros(0, np.int64) for k, v in col.items()}
n = len(d["lat"])
if n == 0 or not np.any(d["end"] != 0): sys.exit("card_highstash_ov: no OV_TRACE records in this CSV (the test build, with DOMA_OVF=1)")
kinds = np.array(kinds)
if cut: print(f"note: {cut} incomplete row(s) skipped")
occ = d["occ"]; peak = int(occ.max())
print(f"{n} requests; stash occupancy: min {int(occ.min())}, median {int(np.median(occ))}, peak {peak} pool entries"
      + (" (saturated)" if peak >= 0x7FFFF else ""))
for k in ("scan", "uni"):
    m = kinds == k
    if m.any(): print(f"  {k:<5} requests {int(m.sum())}: occupancy median {int(np.median(occ[m]))}, peak {int(occ[m].max())}")
print(f"  buckets with blocks waiting beyond the window (chain): {100.0 * d['chain'].mean():.3f}% of requests; "
      f"window entries at open: " + ", ".join(f"{int(v)}: {int(c)}" for v, c in zip(*np.unique(d['wc'], return_counts=True))))
tests = []
use = d["em"] == 0                                      # no same-bucket access in the three before
for loc, name in ((1, "on"), (0, "off")):
    m = use & (d["hbm"] == loc)
    if m.sum() < 10 * a.min_group:
        print(f"note: too few {name}-package requests ({int(m.sum())})"); continue
    lo, hi = np.percentile(occ[m], 10), np.percentile(occ[m], 90)
    x0, x1 = d["lat"][m & (occ <= lo)], d["lat"][m & (occ >= hi)]
    if len(x0) >= a.min_group and len(x1) >= a.min_group and hi > lo:
        t = A.welch_ks(x0, x1)
        if t: tests.append((f"occupancy fullest 10% (>= {int(hi)}) vs emptiest 10% (<= {int(lo)})", name, t))
    else: print(f"note: occupancy groups not separable for {name} package (10th {int(lo)}, 90th {int(hi)})")
    long1 = m & (d["chain"] == 1); desc = "window full and a chain"
    if long1.sum() < a.min_group:
        top = int(d["wc"][m].max()); long1 = m & (d["wc"] == top); desc = f"fullest window seen ({top} entries)"
    short = m & (d["wc"] == 0) & (d["chain"] == 0)
    if long1.sum() >= a.min_group and short.sum() >= a.min_group:
        t = A.welch_ks(d["lat"][short], d["lat"][long1])
        if t: tests.append((f"waiting list: {desc} vs empty", name, t))
    else: print(f"note: too few requests for the waiting-list comparison, {name} package (long {int(long1.sum())}, empty {int(short.sum())})")
rej = A.holm([min(t["p_t"], t["p_ks"]) for *_, t in tests]) if tests else []
print(f"\n== comparisons (flag: |t| > 4.5, or Holm at 0.01 over {len(tests)})")
print(f"  {'comparison':<66}{'loc':<5}{'n0':>9}{'n1':>9}{'mean diff':>11}{'|t|':>8}{'KS':>8}{'detect':>9}  result")
flagged = 0; out = []
for (lab, loc, t), hr in zip(tests, rej):
    bad = bool(abs(t["t"]) > 4.5 or hr); flagged += int(bad)
    out.append(dict(test=lab, loc=loc, flagged=bad, **t))
    print(f"  {lab:<66}{loc:<5}{t['n0']:>9}{t['n1']:>9}{t['mean0'] - t['mean1']:>11.3f}{abs(t['t']):>8.2f}{t['ks']:>8.4f}{t['detect']:>9.2f}  {'FLAG' if bad else 'ok'}")
json.dump(dict(requests=n, peak_occupancy=peak, comparisons=out, flagged=flagged), open(a.out, "w"), indent=1)
ok = bool(tests) and flagged == 0 and not cut
print(f"\n== {'NO STASH-LEVEL DEPENDENCE FOUND' if ok else ('CHECK THE FLAGGED ROWS' if flagged else 'INCOMPLETE')}: {flagged} of {len(tests)} comparisons flagged; peak stash {peak} pool entries (details: {a.out})")
sys.exit(0 if ok else 1)
