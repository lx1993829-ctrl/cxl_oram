#!/bin/bash
# leak_highstash_ov.sh <bitstream.xclbin> <results folder> <records> -- the high-stash test on the overlap test build
# (docs/ov_fault_build.md). Run it from vitis/, one record count at a time, in a new folder each time:
#   DOMA_OVF=1 bash leak_highstash_ov.sh doma_hw.xclbin hs_n4096 4096
# Phases alternate a sequential scan (the stash fills) and uniform requests (it drains), REPS times, each phase LEN requests
# (default max(5 x buckets, 20000)). A clean run's CSV is deleted unless KEEP_CSV=1.
XC=$1; R=$2; N=$3; [ -n "$N" ] || { echo "usage: bash leak_highstash_ov.sh <xclbin> <results folder> <records>"; exit 2; }
exec 9> "$HOME/.u55c_card.lock"; flock -n 9 || { echo "another program is using the card ($HOME/.u55c_card.lock): wait for it to finish"; exit 2; }
[ "${DOMA_OV_K:-4}" = 4 ] || { echo "this test is for K = 4: DOMA_OV_K=$DOMA_OV_K is not supported"; exit 2; }
[ -e "$R/hs.csv" ] && { echo "$R/hs.csv is from an earlier run: use a new results folder"; exit 2; }
mkdir -p "$R"; source /opt/xilinx/xrt/setup.sh > /dev/null; export DOMA_LAMBDA=7
HBM=${HBM:-20}; REPS=${REPS:-4}; B=$(( (N + 6) / 7 )); L=$(( 5 * B )); [ "$L" -lt 20000 ] && L=20000; LEN=${LEN:-$L}
PH=""; for ((i = 0; i < REPS; i++)); do PH="$PH${PH:+,}scan:$LEN,uni:$LEN"; done
echo "== n = $N ($B buckets), $REPS x (scan, uniform), $LEN requests each"
DOMA_N=$N DOMA_HBM_PCT=$HBM DOMA_LEAK_SEED=${LEAK_SEED:-12345} DOMA_LEAK_CSV="$R/hs.csv" DOMA_PHASES=$PH ./host_leak_ov "$XC" "${LAUNCH:-65536}" > "$R/hs.log" 2>&1
tail -1 "$R/hs.log"
[ -s "$R/hs.csv" ] || { echo "== INCOMPLETE: the host wrote no results, see $R/hs.log"; exit 1; }
if python3 ../sim/card_highstash_ov.py "$R/hs.csv" --out "$R/hs.json" > "$R/hs.analysis" 2>&1; then rc=0; [ "${KEEP_CSV:-0}" = 1 ] || rm -f "$R/hs.csv"; else rc=1; fi
grep -E 'peak|chain|FLAG|^== ' "$R/hs.analysis" | cut -c1-200
exit $rc
