// host_leak_ov.cpp -- host_leak.cpp for the phase 3 overlap design (build.sh OVERLAP=4 P3=1; docs/LEAK_CARD_RUNBOOK_OV.md,
// sim/card_leak_analyze_ov.py). Compared with host_leak.cpp:
//   ab, t3, t4, t5   repeated requests: keys in turns of 2, 3, 4, 5 from a small set, usable as a class
//   rpair:A/B:N:L    the coin picks a class for each RUN of L commands, so that all four contexts can hold one class
//                    (with L = 1, as pair:, classes rarely fill the contexts). rpair:uni/ab:1000000:16
//   DOMA_N           small n (14, 35) makes same-bucket accesses frequent: the card's forced collisions
//   header records   an OV_TRACE=1 bitstream (summary byte 2 bit 4) reports each access's public events in header bytes
//                    16-31: s, on package, same-bucket mask, request, read issue, read completion, write-back, release, end
//   leak tests only  GET data is not compared and halts are not judged. If the design stops, the run ends as incomplete,
//                    because later headers would be stale. Only the headers are read back from the card.
//   CSV              phase,launch,cmd,run,class,kind,op,key,lat,s,rq,ri,a,wi,rel,end,hbm,em,status,occ,chain,wc (0 without OV_TRACE)
// The overlap build has no TRACE or DEBUG variant, so DOMA_PHASE_TRACE and DOMA_ONPKG_CSV are ignored here.
// ---- host_leak.cpp's description follows
// host_leak.cpp -- copy of host_phases.cpp for the card leakage tests (sim/card_leak_analyze.py). host_phases.cpp is
// unchanged; this file adds, on top of its phases:
//   DOMA_PHASES items, besides put:N, get:N, mix:N:
//     uni:N      mixed GET/PUT, uniform keys (= mix:N)        scan:N   mixed GET/PUT, keys in order from a random start
//     fixed:N    mixed GET/PUT on one fixed key               rereq:N  mixed GET/PUT, each on the previous command's key
//     pair:A/B:N each command is class A or class B by an independent coin (DOMA_LEAK_SEED, its own generator, not
//                DOMA's), A, B in uni, fixed, rereq, get, put, zero (PUT of an all-zero value), bad (a GET with a key outside
//                the ORAM: the kernel rejects it and serves a dummy access, which must look like any other), badput (the same as a PUT)
//   DOMA_LEAK_CSV=<file>: one row per command (phase, launch, cmd, class, op, key, latency, the header's AR / last R /
//     first W / last W times, status). launch and cmd match DOMA_ONPKG_CSV's rows (a debug bitstream), so the two join.
//   The fixed key is drawn once per run (never block 0, the dummy access's block); rereq after a rejected command
//   draws a uniform key. Example (debug bitstream, see docs/LEAK_CARD_RUNBOOK.md):
//     DOMA_LAMBDA=7 DOMA_N=1048576 DOMA_HBM_PCT=20 DOMA_PHASE_TRACE=1 DOMA_ONPKG_CSV=onpkg.csv DOMA_LEAK_CSV=leak.csv \
//     DOMA_PHASES=pair:uni/fixed:1000000,pair:get/put:1000000 ./host_leak doma.xclbin
// ---- host_phases.cpp's description follows
// host_phases.cpp -- host_doma.cpp's boot, preload, staging, launch and checks, with the query replaced by phases.
//   DOMA_PHASES="put:250000,get:250000" (default): each phase issues that many commands of one type (mix:N: each
//   command a GET or a PUT with probability 1/2), keys uniform
//   over the dataset (std::mt19937 seed 1, continued across phases), PUT values random. A phase is split into
//   launches of at most <commands per launch> (default 65536: the command and response buffers' capacity at 4 KB);
//   each launch is timed like host_doma's query (launch + wait, commands already on the card), and the phase time is
//   their sum. Every GET is checked against the latest value written (preload or an earlier PUT).
//   Refuses to run if LAMBDA / ZPOS below differ from ../rtl/oram_params.vh, when that file is present.
//   DOMA_MEMREPORT=1: print every buffer as allocated by XRT (role, memory, bank, size, address) and the totals;
//   DOMA_HOLD=<s> then keeps them allocated that long, for an independent check with xrt-smi.
//   DOMA_PHASE_TRACE=1 (a TRACE=1 bitstream): every command also writes a 32-byte record of 16 phase timestamps after
//   the launch's response data; each phase prints the mean of 12 phases that add up to E2E (see host_ycsb.cpp).
#include <sstream>
#include <fstream>
#include <regex>
#include <cctype>
// host_doma.cpp -- XRT host program for doma_kernel, built to match BOLT's benchmark host
// (BOLT-benchmark/BOLT/*/host.cpp) so the two are measured the same way:
//   * same workload generator: std::mt19937 seed 1, 50% PUT, keys uniform over the dataset,
//     VALUE_SIZE random bytes per PUT (DOMA stores them at the start of a 4 KB block)
//   * keys are dense: key index i is DOMA slot i (BOLT looks keys up through its hash map)
//   * commands are converted and copied to the card BEFORE timing starts, as BOLT does
//   * query time = one kernel launch processing all CMD_SIZE commands, plus wait()
//   * init time = boot run (key load, bucket layout, lease) + preloading every slot,
//     the analogue of BOLT's data preparation and loading
// Usage: ./host_doma <xclbin> [CMD_SIZE] [--kernel NAME]
//   NAME (or DOMA_KERNEL=NAME): doma_kernel (default) or tinyoram_kernel, the Tiny ORAM baseline.
//   Everything else -- generator, seeds, preload counted as initialization, the timed region of one
//   launch plus wait(), the DOMA_* variables -- is the same for both kernels. For tinyoram_kernel:
//     DOMA_N      records; must match the bitstream's tree (Tiny ORAM's depth is fixed per build:
//                 N = 4 * 2^L blocks, L >= 6 the smallest with 4 * 2^L >= blocks, as build_tinyoram.sh picks it);
//                 default: the bitstream's N
//     DOMA_BLOCK  Tiny ORAM's block size in bytes (64, 128, 256 or 4096), used to size the command, response
//                 and tree buffers before the first launch (default 4096, which also covers the smaller builds)
//     DOMA_PACK   as for DOMA: BLOCK / 8 records per block (offset and length in the command header,
//                 written through Tiny ORAM's byte write mask); DOMA_N records then need N/(BLOCK/8) blocks
//   Tiny ORAM launches with 4 arguments (cmd, resp, pages, size) and needs no metadata buffers.
#include <xrt/xrt_bo.h>
#include <xrt/xrt_device.h>
#include <xrt/xrt_kernel.h>
#include <algorithm>
#include <cmath>
#include <vector>
#include <chrono>
#include <thread>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <initializer_list>
#include <random>
#include <string>
#include <vector>
#include "doma_debug.h"                    // v14b: halt record and debug-build records

// must match the hardware build (rtl/oram_params.vh, single-client default)
// run-time size (DOMA_N=<records>): n blocks in NB = ceil(n / LAMBDA) buckets, passed to the kernel as nblk
// (the build's maximum is rtl/oram_params.vh ORAM_N; build.sh NMAX=...). Default: 256 blocks, as before.
static uint32_t LAMBDA     = 6;                // rtl/oram_params.vh ORAM_C; DOMA_LAMBDA=<lambda> for a LAMBDA=7 build (checked at init)
static const uint32_t ZPOS       = 8;                // rtl/oram_params.vh ORAM_Z

// Stash pool size: Claim 1 of the stash analysis (docs/stash_chain_design.md). The stash exceeds xR + xO with
// probability at most gamma = 2^-64 per access, for every access sequence (Chernoff bounds over negatively
// associated per-bucket terms; the best split of gamma between the two terms). Per-bucket counts are
// Binomial(n, 1/B) with B = n / lambda from the start: since v11b the boot places every block at an independent
// uniform bucket (the excess over Z waits in the stash, nothing else does), and every remap keeps it so.
static double ln_mgf_A(double t, double Bk, double n) {     // ln E[e^{tA}], P(A >= i) = (1 - 1/B)^i, A capped at n
    const double p = 1.0 / Bk, lr = std::log1p(-p) + t;
    if (std::fabs(lr) < 1e-15) return std::log(p * n + 1.0);
    if (lr > 0) { const double lrn = n * lr; if (lrn > 700) return INFINITY;
                  return std::log(p * std::expm1(lrn) / std::expm1(lr) + std::exp(lrn)); }
    const double rn = std::exp(n * lr);
    return std::log(p * (1 - rn) / (-std::expm1(lr)) + rn);
}
static double stash_xR(double Bk, double n, double lg) {   // lg = ln(1 / gamma_R)
    double best = INFINITY;
    for (int i = 1; i < 400; i++) { const double u = i * 0.005, v = ln_mgf_A(std::expm1(u) / Bk, Bk, n);
        if (!std::isfinite(v)) break; best = std::min(best, (Bk * v + lg) / u); }
    return best;
}
static double stash_xO(double Bk, double n, int Z, double lg) {   // per-bucket count Binomial(n, 1/B)
    double best = INFINITY; std::vector<double> lt(160); const double p = 1.0 / Bk, lp = std::log(p), lq = std::log1p(-p);
    for (int i = 1; i < 400; i++) { const double u = i * 0.01; double mx = -INFINITY, sum = 0;
        for (int k = 0; k < 160; k++) { lt[k] = std::lgamma(n + 1) - std::lgamma(k + 1.0) - std::lgamma(n - k + 1) + k * lp + (n - k) * lq
                                                + u * std::max(0, k - Z); mx = std::max(mx, lt[k]); }
        for (int k = 0; k < 160; k++) sum += std::exp(lt[k] - mx);
        best = std::min(best, (Bk * (mx + std::log(sum)) + lg) / u); }
    return best;
}
static double stash_bound(double n, double lam, int Z) {
    const double Bk = std::ceil(n / lam), G = 64 * std::log(2.0);   // n is a multiple of lambda (the host rounds it): B = n / lambda
    double best = INFINITY;
    for (double f : {0.1, 0.3, 0.5, 0.7, 0.9})
        best = std::min(best, stash_xR(Bk, n, G - std::log(f)) + stash_xO(Bk, n, int(Z), G - std::log(1 - f)));
    return best;
}
static uint32_t       NBLK       = 256;              // blocks (slots)
static uint32_t       NB         = 64;               // buckets
static const size_t   MAX_BLOCK  = 4096;             // largest block (4 KB); buffers are sized for it
static size_t         BLOCK      = 4096;             // bytes per slot: the kernel reports its own after boot
static const size_t   BUCKET_STRIDE = 32768;         // bucket spacing in DOMA's memory map
static const int      VALUE_SIZE = 8;                // BOLT's default value size (bytes)
static uint32_t       PACK       = 1;                // records per block: 1, or BLOCK / VALUE_SIZE with DOMA_PACK=1
static uint32_t       NKEYS      = 256;              // keys (records); slots x records per block by default
static const uint8_t  T_GET = 0x01, T_PUT = 0x02, T_ACK = 0x10, T_SUM = 0x5A;
static const uint8_t  T_ERR = 0x11;                  // a rejected command's header (status in bytes 12-15)

static size_t roundup4k(size_t x) { return (x + 4095) & ~size_t(4095); }

struct Cmd { uint8_t type; uint32_t key; uint8_t value[VALUE_SIZE]; };

// BOLT's generate_uniform_commands(), with the key index used directly as the key
static std::vector<Cmd> generate_uniform_commands(int size) {
    std::vector<Cmd> cmds;
    uint32_t seed = 1;
    std::mt19937 gen(seed);
    std::uniform_real_distribution<double> op_dis(0.0, 1.0);
    std::uniform_int_distribution<int> key_dis(0, NKEYS - 1);
    std::uniform_int_distribution<int> value_dis(0, 255);
    for (int i = 0; i < size; i++) {
        Cmd c{};
        double rw = op_dis(gen);
        c.key = key_dis(gen);
        if (rw < 0.5) { c.type = T_PUT; for (int j = 0; j < VALUE_SIZE; j++) c.value[j] = (uint8_t)value_dis(gen); }
        else c.type = T_GET;
        cmds.push_back(c);
    }
    return cmds;
}

struct Buffers {
    xrt::bo cmd, resp, pages, meta, brec, stash;   // meta: position map; brec: bucket records; stash (all in HBM)
    xrt::bo pages_hbm;                             // DOMA: buckets kept in HBM (DOMA_HBM_PCT, fixed boundary)
    size_t hc = 0, hr = 0;
};

// lay commands out as doma_kernel expects: 32-byte headers, then PUT data on 4 KB boundaries
static void stage(Buffers& b, const std::vector<Cmd>& cmds) {
    size_t n = cmds.size();
    b.hc = roundup4k(n * 32);
    b.hr = roundup4k((n + SUMREC) * 32);              // after records [n] (summary), [n+1] (traffic) (and [n+2..n+4], debug)
    auto p = b.cmd.map<uint8_t*>();
    std::memset(p, 0, b.hc + n * BLOCK);
    for (size_t i = 0; i < n; i++) {
        // key k is record k % PACK of block k / PACK; a packed PUT writes only its record
        // (offset and length in header bytes 8-15); unpacked commands use length 0 (whole block)
        uint32_t slot = cmds[i].key / PACK, off = (cmds[i].key % PACK) * VALUE_SIZE;
        uint32_t len  = (PACK > 1) ? uint32_t(VALUE_SIZE) : 0u;
        p[i * 32] = cmds[i].type;
        std::memcpy(p + i * 32 + 4, &slot, 4);
        std::memcpy(p + i * 32 + 8, &off, 4);
        std::memcpy(p + i * 32 + 12, &len, 4);
        if (cmds[i].type == T_PUT) std::memcpy(p + b.hc + i * BLOCK + off, cmds[i].value, VALUE_SIZE);
    }
    b.cmd.sync(XCL_BO_SYNC_BO_TO_DEVICE, b.hc + n * BLOCK, 0);
}

struct Summary { uint64_t total, rd_beats, wr_beats; uint32_t lam, beats, lat_min, lat_max, errors, done, dbg; bool ok, traffic;
                 uint32_t geo_n; size_t geo_tree; };   // tinyoram_kernel only: traffic-record bytes 24-27 blocks, 28-31 tree (64-byte bursts)

static Summary read_summary(Buffers& b, size_t n) {
    // at least through the summary record itself (b.hr is 0 before the first stage())
    b.resp.sync(XCL_BO_SYNC_BO_FROM_DEVICE, std::max(b.hr, (n + SUMREC) * size_t(32)), 0);   // headers and summary: GET data is not read
    auto r = b.resp.map<uint8_t*>() + n * 32;
    Summary s{};
    s.ok = (r[0] == T_SUM); s.lam = r[1] ? r[1] : 6;   // byte 1: lambda when not 6
    s.dbg = s.ok ? r[2] : 0;                           // byte 2: debug bitstream flags (doma_debug.h)
    std::memcpy(&s.beats, r + 4, 4);   // block size in beats (0 from bitstreams before this field)
    std::memcpy(&s.total, r + 8, 8);   std::memcpy(&s.lat_min, r + 16, 4); std::memcpy(&s.lat_max, r + 20, 4);
    std::memcpy(&s.errors, r + 24, 4); std::memcpy(&s.done, r + 28, 4);
    // record [n+1]: traffic on the bucket port during the launch (0x5B; absent from older bitstreams)
    s.traffic = (r[32] == 0x5B);
    if (s.traffic) { std::memcpy(&s.rd_beats, r + 40, 8); std::memcpy(&s.wr_beats, r + 48, 8);
                     uint32_t gt; std::memcpy(&s.geo_n, r + 56, 4); std::memcpy(&gt, r + 60, 4); s.geo_tree = size_t(gt) * 64; }
    return s;
}

// Tiny ORAM's tree span in bytes for a block of `block` bytes and depth L (ORAML), Z = 4, PMMAC on:
// the formulas of its include/BucketLocal.vh (buckets of 64-byte bursts, subtree layout per DDR3 row)
static size_t tinyoram_tree_bytes(size_t block, unsigned L) {
    const unsigned Z = 4, U = 32, E = 64, H = 128;
    unsigned hdr = E + 8 * ((Z + 7) / 8) + U * Z + L * Z + H * Z;                // header bits
    size_t bkt = (hdr + 511) / 512 + Z * ((block * 8 + 511) / 512);             // bucket, in 64-byte bursts
    size_t words = bkt * 8, x = 8192 / words + 1;
    unsigned lst = 0; while ((size_t(2) << lst) <= x) lst++;                      // log2 floor
    if (lst == 0) lst = 1;
    unsigned nst = (L + 1 + lst - 1) / lst;
    size_t tot = ((size_t(1) << (nst * lst)) - 1) / ((size_t(1) << lst) - 1);
    return 64 * ((size_t(1) << (L + 1)) + tot) * bkt;
}
static unsigned tinyoram_depth(size_t blocks) { unsigned L = 6; while ((size_t(4) << L) < blocks) L++; return L; }

int main(int argc, char** argv) {
    if (const char* l = std::getenv("DOMA_LAMBDA")) LAMBDA = uint32_t(std::stoul(l));   // the bitstream's lambda (build.sh LAMBDA)
    if (argc < 2) { std::printf("usage: %s <xclbin> [commands per launch, default 65536]   (phases: DOMA_PHASES=pair:uni/fixed:N,rpair:uni/ab:N:16,scan:N,...)\n", argv[0]); return 1; }
    int CMD_SIZE = 65536;                                                  // commands per launch (buffer capacity)
    {   // the constants above must match the RTL this program is used with
        std::ifstream pf("../rtl/oram_params.vh"); std::string line; int z = -1, c = -1; std::smatch m;
        while (std::getline(pf, line)) {
            if (std::regex_search(line, m, std::regex("`define ORAM_Z\\s+(\\d+)"))) z = std::stoi(m[1]);
            if (std::regex_search(line, m, std::regex("`define ORAM_C\\s+(\\d+)"))) c = std::stoi(m[1]);
        }
        std::ifstream bf("../rtl/oram_build_cfg.vh");   // a LAMBDA=7 build sets ORAM_C here, ahead of the default (as in the RTL)
        while (std::getline(bf, line))
            if (std::regex_search(line, m, std::regex("`define ORAM_C\\s+(\\d+)"))) c = std::stoi(m[1]);
        if (z >= 0 && c >= 0 && (uint32_t(z) != ZPOS || uint32_t(c) != LAMBDA)) {
            std::printf("host_leak_ov is built for Z = %u, lambda = %u, but ../rtl (oram_params.vh, oram_build_cfg.vh) has Z = %d, lambda = %d: refusing to run\n", ZPOS, LAMBDA, z, c);
            return 1;
        }
    }
    std::string kname = std::getenv("DOMA_KERNEL") ? std::getenv("DOMA_KERNEL") : "doma_kernel";
    for (int a = 2; a < argc; a++) {
        std::string o = argv[a];
        if (o == "--kernel" && a + 1 < argc) kname = argv[++a];
        else if (a == 2 && !o.empty() && o[0] != '-') CMD_SIZE = std::stoi(o);
        else { std::printf("unknown argument %s\n", o.c_str()); return 1; }
    }
    const bool TINY = (kname == "tinyoram_kernel");
    if (!TINY && kname != "doma_kernel") { std::printf("unknown kernel %s (doma_kernel or tinyoram_kernel)\n", kname.c_str()); return 1; }
    auto device = xrt::device(0);
    auto uuid   = device.load_xclbin(argv[1]);
    auto krnl   = xrt::kernel(device, uuid, kname);

    // size: DOMA_BLOCK (bytes, default 4 KB) sizes the buffers before boot; checked against the kernel after
    const size_t BLOCKA = std::getenv("DOMA_BLOCK") ? std::stoul(std::getenv("DOMA_BLOCK")) : MAX_BLOCK;
    if (BLOCKA < 32 || BLOCKA > MAX_BLOCK || (BLOCKA & (BLOCKA - 1))) { std::printf("DOMA_BLOCK must be a power of two, 32..4096\n"); return 1; }
    const uint32_t pack_a = std::getenv("DOMA_PACK") ? uint32_t(BLOCKA / VALUE_SIZE) : 1u;
    if (std::getenv("DOMA_N")) {
        NKEYS = uint32_t(std::stoul(std::getenv("DOMA_N")));
        NBLK  = (NKEYS + pack_a - 1) / pack_a;
    }
    // the stash analysis takes B = n / lambda exactly: round n up to a multiple of lambda (at most lambda - 1 extra
    // blocks, never requested). (Since v11b the boot places every block at an independent uniform bucket, so the
    // per-bucket counts are Binomial(n, 1/B) for any n; the rounding is kept, and costs at most lambda - 1 blocks.) The kernel clamps n to its build's maximum: DOMA_NMAX=<that maximum> makes a rounding past it an error.
    const uint32_t nblk_req = NBLK;
    if (!TINY) NBLK = ((NBLK + LAMBDA - 1) / LAMBDA) * LAMBDA;
    if (!TINY && NBLK != nblk_req) std::printf("n: %u blocks rounded up to %u, a multiple of lambda = %u (the extra blocks are never requested)\n", nblk_req, NBLK, LAMBDA);
    if (!TINY && std::getenv("DOMA_NMAX") && NBLK > std::stoul(std::getenv("DOMA_NMAX"))) {
        std::printf("n = %u exceeds the build's maximum %s: the kernel would clamp it to a size that is not a multiple of lambda\n", NBLK, std::getenv("DOMA_NMAX")); return 1; }
    NB = (NBLK + LAMBDA - 1) / LAMBDA;
    const size_t stride = size_t(ZPOS) * BLOCKA;                              // compact layout: exactly Z blocks per bucket
    // stash pool: Claim 1's bound at 2^-64 per access, rounded up, plus one; never more than n. DOMA_POOL=<entries> overrides it.
    const double pool_bnd = stash_bound(double(NBLK), double(LAMBDA), int(ZPOS));
    uint32_t POOL = uint32_t(std::min<double>(NBLK, std::ceil(pool_bnd) + 1));
    if (std::getenv("DOMA_POOL")) POOL = uint32_t(std::min<unsigned long>(NBLK, std::stoul(std::getenv("DOMA_POOL"))));
    // Tiny ORAM: its tree for the requested size (the bitstream reports the real one at init; checked below)
    const unsigned tiny_L = tinyoram_depth(NBLK);
    // DOMA_HBM_PCT: the percentage of buckets kept in HBM (fixed boundary: buckets 0 .. HBMK-1), the rest in pages
    const unsigned hbm_pct = std::getenv("DOMA_HBM_PCT") ? unsigned(std::stoul(std::getenv("DOMA_HBM_PCT"))) : 0u;
    if (hbm_pct > 100) { std::printf("DOMA_HBM_PCT must be 0..100\n"); return 1; }
    if (TINY && hbm_pct) { std::printf("DOMA_HBM_PCT is for doma_kernel only\n"); return 1; }
    const uint32_t HBMK = uint32_t((uint64_t(NB) * hbm_pct) / 100);
    const size_t pages_bytes = TINY ? roundup4k(tinyoram_tree_bytes(BLOCKA, tiny_L))
                                    : size_t(NB - HBMK) * stride + 4096;      // + up to 4 KB: the kernel rebases by a 4 KB multiple
    if (TINY) std::printf("size: %u blocks, Tiny ORAM tree for L=%u (N=%u), %zu-byte blocks: %zu bytes\n",
                          NBLK, tiny_L, 4u << tiny_L, BLOCKA, pages_bytes);
    if (!TINY) std::printf("stash pool: %u entries (Claim 1 bound %.1f at 2^-64 per access, rounded up, + 1)%s\n", POOL, pool_bnd,
                           std::getenv("DOMA_POOL") ? " [DOMA_POOL]" : "");
    if (TINY) {} else std::printf("size: %u blocks (nblk), %u buckets (%u in HBM = %u%%, %u in pages), buffers sized for %zu-byte blocks\n",
                     NBLK, NB, HBMK, hbm_pct, NB - HBMK, BLOCKA);
    const size_t max_cmds = std::max<size_t>(CMD_SIZE, std::min<size_t>(NBLK, 5000));
    Buffers b;
    b.cmd   = xrt::bo(device, roundup4k(max_cmds * 32) + max_cmds * BLOCKA, krnl.group_id(0));
    const bool PTRACE = false;                                             // the overlap build has no phase-trace records
    if (std::getenv("DOMA_PHASE_TRACE") || std::getenv("DOMA_ONPKG_CSV")) std::printf("DOMA_PHASE_TRACE and DOMA_ONPKG_CSV are ignored: the overlap build has no TRACE or DEBUG variant\n");
    bool ov_trace = false;                                                 // an OV_TRACE=1 bitstream: header bytes 16-31 (from the boot summary)
    b.resp  = xrt::bo(device, roundup4k((max_cmds + 5) * 32) + max_cmds * BLOCKA + (PTRACE ? max_cmds * 128 : 0), krnl.group_id(1));   // (debug bitstream: 5 records, 128-byte trace)
    b.pages = std::getenv("DOMA_PAGES_HBM") ? xrt::bo(device, pages_bytes, krnl.group_id(2)) : xrt::bo(device, pages_bytes, xrt::bo::flags::host_only, krnl.group_id(2));
    if (!TINY) {
    // DOMA's trusted metadata (position map, 4 bytes per slot) in on-package HBM; DOMA writes all of it at boot
    b.meta  = xrt::bo(device, std::max<size_t>(4096, ((size_t(NBLK) + 4) / 5) * 32), krnl.group_id(4));   // 48-bit entries, 5 per 32-byte beat
    // bucket records: 256 bytes per bucket (metadata + each position's IV/tag), written by DOMA at boot
    b.brec  = xrt::bo(device, std::max<size_t>(4096, size_t(NB) * 64), krnl.group_id(5));    // 64-byte records (per-bucket GCM)
    // the stash: 512-byte lists per bucket, then a pool with one block per slot
    // the stash: 32-byte heads per bucket, 16-byte links per pool entry, then the pool's blocks
    // heads: 64 bytes per bucket. A head holds Z + 2 entries; at Z = 10 it takes two 32-byte beats when the build's
    // pool index needs more than 20 bits (NMAX above 2^20), and the kernel then lays out its regions after NB * 64.
    b.stash = xrt::bo(device, roundup4k(size_t(NB) * 64) + roundup4k(size_t(POOL) * 16) + size_t(POOL) * BLOCKA, krnl.group_id(6));
    // buckets kept in HBM: buckets 0 .. HBMK-1 (DOMA formats them at boot, like pages)
    b.pages_hbm = xrt::bo(device, std::max<size_t>(4096, size_t(HBMK) * stride), krnl.group_id(8));
    if (std::getenv("DOMA_MEMREPORT")) {   // what XRT actually allocated (bo.size(), bo.address()), by role and memory
        const bool pages_host = !std::getenv("DOMA_PAGES_HBM");
        struct M { const char* role; const xrt::bo* bo; int arg; bool host; bool io; };
        const M m[] = {{"buckets in host memory", &b.pages, 2, pages_host, false}, {"buckets in HBM", &b.pages_hbm, 8, false, false},
                       {"position map", &b.meta, 4, false, false}, {"bucket records", &b.brec, 5, false, false},
                       {"stash (heads, entry metadata, data)", &b.stash, 6, false, false},
                       {"commands (I/O, not ORAM state)", &b.cmd, 0, false, true}, {"responses (I/O, not ORAM state)", &b.resp, 1, false, true}};
        size_t on = 0, host = 0, io = 0;
        std::printf("memory report (as allocated by XRT): N=%u records, %u buckets (%u in HBM), stash pool %u entries, %zu-byte blocks\n",
                    NBLK, NB, HBMK, POOL, size_t(BLOCKA));
        for (const auto& x : m) {
            const size_t sz = x.bo->size();
            std::printf("  %-36s %-5s bank group %2d  %14zu B = %10.2f MiB  at 0x%llx\n", x.role, x.host ? "host" : "HBM",
                        int(krnl.group_id(x.arg)), sz, sz / 1048576.0, (unsigned long long)x.bo->address());
            (x.io ? io : x.host ? host : on) += sz;
        }
        std::printf("  ORAM state: on-package (HBM) %.2f MiB, host memory %.2f MiB, total %.2f MiB; I/O buffers %.2f MiB (HBM)\n",
                    on / 1048576.0, host / 1048576.0, (on + host) / 1048576.0, io / 1048576.0);
        if (const char* hs = std::getenv("DOMA_HOLD")) {
            std::printf("  holding the buffers for %s s: run 'xrt-smi examine -d <bdf> -r memory' now\n", hs);
            std::fflush(stdout);
            std::this_thread::sleep_for(std::chrono::seconds(std::atoi(hs)));
        }
    }
    }
    // DOMA: 10 arguments; Tiny ORAM: cmd, resp, pages, size
    // trace records: every phase launch with DOMA_PHASE_TRACE=1; preload launches only with a debug bitstream (their
    // records feed the on-package calibration)
    // the overlap test build (build.sh OV_FAULT=1, summary byte 2 bit 7) takes 22 arguments: DOMA_OVF=1 passes them, every
    // hook disarmed, so registers left set by host_fault_ov are cleared at each launch. DOMA_OV_LEAK=1 (with DOMA_OVF=1)
    // switches on the planted leak (flt_ctl bit 6, every PUT's read gate one cycle late): the positive control of the
    // exact schedule check, which must then fail.
    const bool OVF = std::getenv("DOMA_OVF") && std::string(std::getenv("DOMA_OVF")) == "1";
    const uint32_t FCTL = (std::getenv("DOMA_OV_LEAK") && std::string(std::getenv("DOMA_OV_LEAK")) == "1") ? 0x40u : 0u;
    // DOMA_OV_K=2|3|4: the run-time in-flight cap of a phase 3 bitstream, bits [31:29] of the hbm_bkts argument, fixed from the
    // boot. Unset: the build's 4. The exact schedule check here is for K = 4 only.
    const uint32_t OVK = std::getenv("DOMA_OV_K") ? uint32_t(std::atoi(std::getenv("DOMA_OV_K"))) : 0u;
    if (OVK != 0 && OVK != 2 && OVK != 3 && OVK != 4) { std::printf("DOMA_OV_K must be 2, 3 or 4\n"); return 1; }
    const uint32_t HBMK_ARG = HBMK | (OVK << 29);
    if (OVK) std::printf("in-flight cap: K = %u (run-time, fixed for the run)\n", OVK);
    if (FCTL && !OVF) { std::printf("DOMA_OV_LEAK=1 needs DOMA_OVF=1 (the overlap test build)\n"); return 1; }
    if (FCTL) std::printf("PLANTED LEAK ON (DOMA_OV_LEAK=1): a positive control; these results are not a measurement of the design\n");
    auto launch = [&](uint32_t n, bool preload_launch = false) {
        const bool tr = PTRACE && n && (!preload_launch || TRACE64);
        const uint32_t z = 0;
        return TINY ? krnl(b.cmd, b.resp, b.pages, n)
             : OVF  ? krnl(b.cmd, b.resp, b.pages, n, b.meta, b.brec, b.stash, NBLK, b.pages_hbm, HBMK_ARG, POOL,
                           FCTL, z, z, z, z, z, z, z, z, z, z)
                    : krnl(b.cmd, b.resp, b.pages, n | (tr ? 0x80000000u : 0u), b.meta, b.brec, b.stash, NBLK, b.pages_hbm, HBMK_ARG, POOL);   // never flag an init launch (size 0)
    };

    // ---- init: boot run, then preload every key (BOLT's init includes loading its dataset)
    auto init_start = std::chrono::system_clock::now();
    auto r0 = launch(0u);                                                  // DOMA: key load, layout, lease; Tiny ORAM: latch
    r0.wait();
    {   // the kernel reports its block size; the data layout must match the bitstream
        Summary s0 = read_summary(b, 0);
        if (!TINY) std::printf("boot: %llu device cycles, errors 0x%x%s", (unsigned long long)s0.total, s0.errors, s0.errors ? "" : "\n");
        if (!TINY && s0.errors) std::printf(" (halted at boot:%s%s%s)\n",
            (s0.errors & 0x100) ? " timing overrun" : "", (s0.errors & 0x200) ? " integrity failure" : "", (s0.errors & 0x400) ? " stash overflow" : "");
        if (s0.errors & 0x8) print_halt_record("boot", s0.lat_min, s0.lat_max);   // in place of the latency fields
        if (!TINY && s0.ok) { const uint8_t sb[3] = {0, 0, uint8_t(s0.dbg)}; dbg_from_summary(sb); }
        if (!TINY && (s0.errors & 0x80)) { std::printf("boot refused an argument (error 0x80): records above the build's maximum, or DOMA_OV_K on a bitstream without run-time K\n"); return 1; }
        ov_trace = s0.ok && (s0.dbg & 0x10);
        if (!TINY && s0.ok && bool(s0.dbg & 0x80) != OVF) {
            std::printf(OVF ? "DOMA_OVF=1 but this is not the overlap test build (summary byte 2 bit 7 clear)\n"
                            : "this is the overlap test build (summary byte 2 bit 7): run it with DOMA_OVF=1, so every launch disarms its hooks\n");
            return 1;
        }
        std::printf("public-event records (OV_TRACE): %s\n", ov_trace ? "ON (a leak-test bitstream, not the deployed one)" : "off (latency only)");
        if (!TINY && s0.ok && s0.lam != LAMBDA) {   // before any other check: a lambda mismatch also mis-sizes the stash pool
            std::printf("the bitstream's lambda is %u but the host sized the ORAM for lambda = %u: set DOMA_LAMBDA=%u\n", s0.lam, LAMBDA, s0.lam);
            return 1; }
        if (s0.ok && s0.beats > 0 && s0.beats * 32 <= MAX_BLOCK) BLOCK = size_t(s0.beats) * 32;
        std::printf("block: %zu bytes per slot%s\n", BLOCK, (s0.beats == 0) ? " (bitstream does not report it; assuming 4 KB)" : "");
        if (VALUE_SIZE > BLOCK) { std::printf("VALUE_SIZE %d exceeds the block\n", VALUE_SIZE); return 1; }
        if (BLOCK != BLOCKA && (std::getenv("DOMA_BLOCK") || std::getenv("DOMA_N"))) {
            std::printf("the kernel's block is %zu bytes but DOMA_BLOCK sized the buffers for %zu: set DOMA_BLOCK=%zu\n", BLOCK, BLOCKA, BLOCK);
            return 1; }
    }
    if (TINY) {   // the bitstream's geometry; Tiny ORAM has touched no memory yet (it zero-fills at the next launch)
        Summary g = read_summary(b, 0);
        if (!g.ok || !g.traffic || g.geo_n == 0) { std::printf("tinyoram_kernel did not report its geometry\n"); return 1; }
        unsigned bl = 1; while ((4u << bl) < g.geo_n) bl++;
        std::printf("Tiny ORAM bitstream: N=%u blocks (L=%u), tree %zu bytes\n", g.geo_n, bl, g.geo_tree);
        if (std::getenv("DOMA_N") && g.geo_n != (4u << tiny_L)) {
            std::printf("DOMA_N=%u records (%u blocks of %u) need a Tiny ORAM build with L=%u (N=%u blocks); this bitstream has N=%u (L=%u)\n",
                        NKEYS, NBLK, pack_a, tiny_L, 4u << tiny_L, g.geo_n, bl);
            return 1; }
        if (!std::getenv("DOMA_N")) NBLK = g.geo_n;
        if (g.geo_tree > b.pages.size()) {
            std::printf("this bitstream's tree (%zu bytes) is larger than the pages buffer (%zu bytes): run with DOMA_BLOCK=%zu and DOMA_N for its N=%u blocks\n",
                        g.geo_tree, b.pages.size(), BLOCK, g.geo_n);
            return 1; }
    }
    if (std::getenv("DOMA_PACK")) PACK = uint32_t(BLOCK / VALUE_SIZE);    // records share a block
    if (!std::getenv("DOMA_N")) NKEYS = NBLK * PACK;
    std::printf("records: %u keys of %d bytes, %u per block\n", NKEYS, VALUE_SIZE, PACK);
    std::vector<Cmd> preload;
    std::mt19937 vgen(16);                                                // BOLT seeds its dataset with 16
    std::uniform_int_distribution<int> vdis(0, 255);
    for (uint32_t k = 0; k < NKEYS; k++) {
        Cmd c{}; c.type = T_PUT; c.key = k;
        for (int j = 0; j < VALUE_SIZE; j++) c.value[j] = (uint8_t)vdis(vgen);
        preload.push_back(c);
    }
    uint32_t pre_err = 0; bool halt_shown = false;
    Summary last_halt{}; std::string last_where;
    auto note_halt = [&](const Summary& p, const std::string& where) {   // the first halted launch's record, and the last's
        if (!(p.errors & 0x8) || TINY) return;
        if (!halt_shown) { print_halt_record(where.c_str(), p.lat_min, p.lat_max); halt_shown = true; }
        last_halt = p; last_where = where;
    };
    OnpkgStats all_st(true);                                               // every command's core record (debug bitstream)
    unsigned dbg_wbh = 0, dbg_relh = 0;                                    // the bitstream's on-package budgets (debug records)
    // the preload's commands are accesses like any other: their records count too (the card halted during the preload)
    for (size_t at = 0; at < preload.size(); at += max_cmds) {             // in batches that fit the buffers
        std::vector<Cmd> part(preload.begin() + at, preload.begin() + std::min(preload.size(), at + max_cmds));
        stage(b, part);
        auto r1 = launch((uint32_t)part.size(), true);
        r1.wait();
        Summary p = read_summary(b, part.size());
        pre_err |= p.errors;
        note_halt(p, "preload, launch at key " + std::to_string(at));
        const size_t n = part.size();
        if (PTRACE && TRACE64) {
            const size_t TR = TRACE_B;
            b.resp.sync(XCL_BO_SYNC_BO_FROM_DEVICE, n * TR, b.hr + n * BLOCK);
            auto resp = b.resp.map<uint8_t*>();
            all_st.launch++;
            for (size_t i = 0; i < n; i++) { const uint8_t* rr = resp + b.hr + n * BLOCK + i * TR;
                                             all_st.add(i, rr + 32, TR == 128 ? rr + 64 : nullptr); }
        }
        if (SUMREC == 5) {
            const uint8_t* rec = b.resp.map<uint8_t*>() + (n + 2) * 32;
            dbg_wbh = rd16(rec + 2); dbg_relh = rd16(rec + 4);
            if (at + max_cmds >= preload.size()) print_debug_records("after the preload", rec);
        }
    }
    if (PTRACE && TRACE64) all_st.print("preload", dbg_wbh, dbg_relh);
    if (pre_err) { std::printf("RUN INCOMPLETE: the design stopped during the preload\n"); return 1; }
    auto init_end = std::chrono::system_clock::now();
    std::printf("init: %.6f s (boot + preload of %u keys), preload errors=0x%x\n",
                std::chrono::duration<double>(init_end - init_start).count(), NKEYS, pre_err);

    // ---- phases (see the top of this file)
    std::string spec = std::getenv("DOMA_PHASES") ? std::getenv("DOMA_PHASES") : "pair:uni/fixed:100000,pair:get/put:100000";
    // leak tests: a phase is one kind of command, or a pair of kinds chosen per command by an independent coin
    enum Kind { K_PUT, K_GET, K_UNI, K_FIXED, K_REREQ, K_ZERO, K_BAD, K_SCAN, K_AB, K_T3, K_T4, K_T5, K_BADP, K_NONE };
    static const char* KNAME[] = {"put", "get", "uni", "fixed", "rereq", "zero", "bad", "scan", "ab", "t3", "t4", "t5", "badput"};
    auto kind_of = [](const std::string& s) -> Kind {
        return s == "put" ? K_PUT : s == "get" ? K_GET : (s == "uni" || s == "mix") ? K_UNI : s == "fixed" ? K_FIXED
             : s == "rereq" ? K_REREQ : s == "zero" ? K_ZERO : s == "bad" ? K_BAD : s == "badput" ? K_BADP : s == "scan" ? K_SCAN
             : s == "ab" ? K_AB : s == "t3" ? K_T3 : s == "t4" ? K_T4 : s == "t5" ? K_T5 : K_NONE; };
    struct Phase { Kind a, b; bool pair; size_t n; std::string name; size_t runlen; };
    std::vector<Phase> phases;
    {
        std::stringstream ss(spec); std::string item;
        while (std::getline(ss, item, ',')) {
            size_t runlen = 1;
            if (item.rfind("rpair:", 0) == 0) {                    // rpair:A/B:N:L -> a pair by runs of L commands
                auto cl = item.rfind(':');
                if (cl != std::string::npos) { runlen = std::strtoul(item.c_str() + cl + 1, nullptr, 10); item = "pair:" + item.substr(6, cl - 6); }
                if (runlen < 2) { std::printf("bad DOMA_PHASES rpair item (want rpair:KIND/KIND:N:L, L >= 2)\n"); return 1; }
            }
            auto c = item.rfind(':');
            std::string k = c == std::string::npos ? "" : item.substr(0, c);
            for (auto& ch : k) ch = char(std::tolower(ch));
            size_t n = c == std::string::npos ? 0 : std::strtoul(item.c_str() + c + 1, nullptr, 10);
            Phase p{K_NONE, K_NONE, false, n, runlen > 1 ? "r" + k + ":" + std::to_string(runlen) : k, runlen};
            if (k.rfind("pair:", 0) == 0) {
                auto s = k.find('/');
                if (s != std::string::npos) { p.a = kind_of(k.substr(5, s - 5)); p.b = kind_of(k.substr(s + 1)); p.pair = true; }
                if (p.a == K_SCAN || p.b == K_SCAN) p.a = K_NONE;   // stash pressure builds over many commands: scan is a phase
            } else p.a = p.b = kind_of(k);
            if (p.a == K_NONE || p.b == K_NONE || n == 0) {
                std::printf("bad DOMA_PHASES item '%s' (want KIND:N, pair:KIND/KIND:N or rpair:KIND/KIND:N:L, KIND in put get mix uni fixed rereq zero bad badput"
                            " ab t3 t4 t5 scan; scan only alone)\n", item.c_str()); return 1; }
            phases.push_back(p);
        }
    }
    std::mt19937 pgen(1);
    std::uniform_int_distribution<uint32_t> pkey(0, NKEYS - 1);
    std::uniform_int_distribution<int> pval(0, 255);
    std::bernoulli_distribution pmix(0.5);
    // the class coin: its own generator, independent of the keys, the values and DOMA's bucket generator
    std::mt19937_64 cgen(std::getenv("DOMA_LEAK_SEED") ? std::stoull(std::getenv("DOMA_LEAK_SEED")) : 12345ULL);
    std::bernoulli_distribution coin(0.5);
    uint32_t fixed_key; do fixed_key = pkey(pgen); while (fixed_key / PACK == 0);   // never block 0 (the dummy's block)
    uint32_t prev_key = pkey(pgen), scan_pos = pkey(pgen);
    // repeated requests: a small set of distinct keys, taken in turn; a new set at each run of the class (or every 256 uses)
    uint32_t cyc_keys[5] = {0, 0, 0, 0, 0}; size_t cyc_pos = 0; bool cyc_new = true;
    if (NKEYS < 7) { std::printf("DOMA_N must be at least 7 for the repeated-request classes\n"); return 1; }
    auto make = [&](Kind k) -> Cmd {
        Cmd c{};
        const bool cyc = (k == K_AB || k == K_T3 || k == K_T4 || k == K_T5);
        const bool mixed = (k == K_UNI || k == K_FIXED || k == K_REREQ || k == K_SCAN || cyc);
        const size_t cn = k == K_AB ? 2 : k == K_T3 ? 3 : k == K_T4 ? 4 : 5;
        if (cyc && (cyc_new || cyc_pos >= 256)) {
            for (size_t x = 0; x < 5; x++) { bool dup; do { cyc_keys[x] = pkey(pgen); dup = false; for (size_t y = 0; y < x; y++) dup = dup || cyc_keys[y] == cyc_keys[x]; } while (dup); }
            cyc_pos = 0; cyc_new = false;
        }
        c.type = (k == K_PUT || k == K_ZERO || k == K_BADP) ? T_PUT : mixed ? (pmix(pgen) ? T_PUT : T_GET) : T_GET;
        c.key = cyc ? cyc_keys[cyc_pos++ % cn] : (k == K_FIXED) ? fixed_key : (k == K_REREQ) ? prev_key : (k == K_SCAN) ? (scan_pos++ % NKEYS)
              : (k == K_BAD || k == K_BADP) ? NBLK * PACK + 5 : pkey(pgen);   // bad, badput: a block beyond the ORAM's n
        if (c.type == T_PUT && k != K_ZERO) for (int j = 0; j < VALUE_SIZE; j++) c.value[j] = uint8_t(pval(pgen));
        if (k != K_BAD && k != K_BADP) prev_key = c.key;
        return c;
    };
    FILE* lcsv = std::getenv("DOMA_LEAK_CSV") ? std::fopen(std::getenv("DOMA_LEAK_CSV"), "w") : nullptr;
    if (std::getenv("DOMA_LEAK_CSV") && !lcsv) { std::printf("cannot write %s\n", std::getenv("DOMA_LEAK_CSV")); return 1; }
    if (lcsv) std::fprintf(lcsv, "phase,launch,cmd,run,class,kind,op,key,lat,s,rq,ri,a,wi,rel,end,hbm,em,status,occ,chain,wc\n");
    unsigned long long leak_launch = 0;                                     // without a debug bitstream: own launch count
    const size_t chunk = size_t(CMD_SIZE);
    bool all_ok = true, stop_run = false;
    unsigned long long run_id = 0;                                          // the coin's unit: a command, or a run of L commands
    for (size_t pi = 0; pi < phases.size() && !stop_run; pi++) {
        const Phase& ph = phases[pi];
        double t = 0; uint64_t cyc = 0, rdb = 0, wrb = 0; uint32_t errs = 0; bool sok = true, traffic = true;
        int bad = 0; size_t launches = 0; std::vector<uint32_t> lv; lv.reserve(ph.n);
        uint64_t pn = 0, plook = 0, pread = 0, pproc = 0, pwrite = 0, ptail = 0; size_t pzero = 0, pbad = 0;
        uint64_t tn = 0, te2e = 0, tph[12] = {0}, tovl = 0; size_t tbad = 0;     // phase-trace records
        uint64_t wovl = 0; size_t wovl_n = 0;                                    // re-encryption past the write-back start
        // the budget check: how long after the bucket's last beat re-encryption ends (trace slot 10 - slot 4), and when
        // the write-back starts (slot 11 - slot 4, the fixed time AR_WB); a histogram for the tail, the maximum
        std::vector<uint64_t> eh(65536, 0); uint32_t emax = 0, wmin = 0xffffffffu, wmax = 0; size_t en = 0;
        OnpkgStats ph_st;                                                        // this phase's core records (debug bitstream)
        uint64_t ng = 0, np = 0, lg = 0, lp = 0;                                  // GET / PUT counts and latency sums
        uint64_t ccnt[2] = {0, 0}, clat[2] = {0, 0};                              // leak tests: per class
        uint64_t k_late = 0; uint32_t k_wo_max = 0;                               // traffic record: results landing during a response write, longest write
        uint64_t tr_sat = 0, tr_n = 0;                                            // OV_TRACE: records with a saturated or absent field
        size_t run_left = 0; uint8_t run_cls = 0;
        for (size_t at = 0; at < ph.n; at += chunk) {
            const size_t n = std::min(chunk, ph.n - at);
            std::vector<Cmd> cmds(n);
            std::vector<uint8_t> cls(n, 0);
            std::vector<Kind> kinds(n);
            std::vector<unsigned long long> runs(n);
            for (size_t i = 0; i < n; i++) {
                if (run_left == 0) { run_cls = uint8_t(ph.pair && coin(cgen)); run_left = ph.runlen; run_id++; cyc_new = true; }
                run_left--;
                cls[i] = run_cls; runs[i] = run_id;
                kinds[i] = cls[i] ? ph.b : ph.a;
                cmds[i] = make(kinds[i]);
            }
            stage(b, cmds);
            auto t0 = std::chrono::system_clock::now();
            auto run = launch((uint32_t)n);
            run.wait();
            auto t1 = std::chrono::system_clock::now();
            t += std::chrono::duration<double>(t1 - t0).count(); launches++;
            Summary s = read_summary(b, n);
            const size_t TR = TRACE_B;                                                      // trace record size
            if (PTRACE) b.resp.sync(XCL_BO_SYNC_BO_FROM_DEVICE, n * TR, b.hr + n * BLOCK);   // the launch's trace records
            note_halt(s, ph.name + " phase, launch " + std::to_string(launches));
            if (SUMREC == 5) { const uint8_t* rec = b.resp.map<uint8_t*>() + (n + 2) * 32; dbg_wbh = rd16(rec + 2); dbg_relh = rd16(rec + 4);
                               if (s.errors || at + chunk >= ph.n) print_debug_records((ph.name + " phase").c_str(), rec); }
            if (PTRACE && TRACE64) { all_st.launch++; ph_st.launch = all_st.launch; }
            const unsigned long long lid = (PTRACE && TRACE64) ? all_st.launch : ++leak_launch;   // DOMA_LEAK_CSV's launch
            const size_t nrej = size_t(std::count(kinds.begin(), kinds.end(), K_BAD) + std::count(kinds.begin(), kinds.end(), K_BADP));   // rejected: served, not counted as completed
            cyc += s.total; errs |= s.errors; sok = sok && s.ok && s.done == n - nrej; traffic = traffic && s.traffic;
            rdb += s.rd_beats; wrb += s.wr_beats;
            if (s.traffic) { k_late += s.geo_n; k_wo_max = std::max<uint32_t>(k_wo_max, uint32_t(s.geo_tree / 64)); }   // (bytes 24-31 of the record)
            auto resp = b.resp.map<uint8_t*>();
            for (size_t i = 0; i < n; i++) {
                const uint8_t* h = resp + i * 32;
                uint32_t slot; std::memcpy(&slot, h + 4, 4);
                {   // a halted or timed-out head: its header says so, later headers are stale. Results before it are good.
                    uint32_t st0; std::memcpy(&st0, h + 12, 4);
                    if (s.errors && h[0] == T_ERR && (st0 & 0x18)) {
                        std::printf("phase %zu: the design stopped at command %zu; later responses are not valid\n", pi + 1, at + i);
                        stop_run = true; break;
                    }
                }
                const uint32_t key = cmds[i].key;
                const bool rej = (kinds[i] == K_BAD || kinds[i] == K_BADP);                           // must come back rejected (0x11, status 0x4)
                uint32_t st; std::memcpy(&st, h + 12, 4);
                if (rej ? (h[0] != T_ERR || st != 0x4) : (h[0] != T_ACK || slot != key / PACK)) {
                    if (bad++ < 5) std::printf("%s phase, command %zu: bad header 0x%02x block %u status 0x%x%s\n", ph.name.c_str(), at + i,
                                               h[0], slot, st, rej ? " (expected a rejection)" : "");
                    continue;
                }
                uint32_t l; std::memcpy(&l, h + 8, 4); lv.push_back(l);
                if (cmds[i].type == T_PUT) { np++; lp += l; } else { ng++; lg += l; }
                ccnt[cls[i]]++; clat[cls[i]] += l;
                {   // OV_TRACE: the access's public events, header bytes 16-31 (absolute s; the others relative to it; 0xFFFF: saturated)
                    uint32_t w0 = 0; uint16_t f[6] = {0, 0, 0, 0, 0, 0};
                    if (ov_trace) { std::memcpy(&w0, h + 16, 4); std::memcpy(f, h + 20, 12); tr_n++;
                                    for (int x = 1; x < 6; x++) if (f[x] == 0xFFFF) { tr_sat++; break; } }
                    const uint32_t ts = w0 & 0x0FFFFFFFu, thbm = (w0 >> 28) & 1, tem = w0 >> 29;
                    // header bytes 1-3 (OV_TRACE): the stash at this access's open: [23:5] pool entries in use, [4] its bucket
                    // has blocks waiting beyond its window (a chain), [3:0] entries in its window
                    const uint32_t tinfo = ov_trace ? uint32_t(h[1]) | (uint32_t(h[2]) << 8) | (uint32_t(h[3]) << 16) : 0u;
                    if (lcsv) std::fprintf(lcsv, "%zu,%llu,%zu,%llu,%u,%s,%s,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,0x%x,%u,%u,%u\n", pi + 1, lid, i, runs[i], cls[i], KNAME[kinds[i]],
                                           cmds[i].type == T_PUT ? "PUT" : "GET", key, l, ts, unsigned(f[0]), unsigned(f[1]), unsigned(f[2]), unsigned(f[3]), unsigned(f[4]), unsigned(f[5]), thbm, tem, st, tinfo >> 5, (tinfo >> 4) & 1u, tinfo & 15u);
                    pzero++;
                }
                if (PTRACE) {   // 12 phases, as in host_ycsb.cpp (slot 9, the write-back gate state, is unused in arrival mode)
                    uint16_t v[16]; std::memcpy(v, resp + b.hr + n * BLOCK + i * TR, 32);
                    if (TRACE64) { const uint8_t* rr = resp + b.hr + n * BLOCK + i * TR, *s2 = (TR == 128) ? rr + 64 : nullptr;
                                   all_st.add(i, rr + 32, s2); ph_st.add(i, rr + 32, s2); }
                    // Two AES lanes: re-encryption runs at the write-back's rate (32 B per cycle), so the write-back, issued at its
                    // fixed time, may start before the last encrypted beat (slot 10 after slot 11). That is safe: the write
                    // never catches up (it would halt, axim_wdata_stall). Count the overlap, and end re-encryption at the
                    // write-back's start so the phases still add up to E2E.
                    const uint32_t enc_end = (v[11] != 0 && v[10] > v[11]) ? v[11] : v[10];
                    if (enc_end != v[10]) { wovl_n++; wovl += v[10] - v[11]; }
                    if (v[4] != 0 && v[10] >= v[4] && v[11] >= v[4]) {
                        const uint32_t e = v[10] - v[4], w = v[11] - v[4];
                        eh[std::min<uint32_t>(e, 65535)]++; en++; emax = std::max(emax, e); wmin = std::min(wmin, w); wmax = std::max(wmax, w);
                    }
                    const uint32_t ch[12] = {v[0], v[1], v[2], v[4], v[6], v[7], v[8], enc_end, v[11], v[12], v[14], l};
                    bool tok = v[3] != 0 && v[5] != 0;
                    for (int k = 0; k < 11 && tok; k++) tok = ch[k] != 0 && ch[k] <= ch[k + 1];
                    if (!tok) { if (tbad++ < 3) { std::printf("%s phase, command %zu: trace record out of order:", ph.name.c_str(), at + i);
                                                  for (int k = 0; k < 16; k++) std::printf(" %u", v[k]); std::printf(" | done %u\n", l); } }
                    else { tn++; te2e += l; tph[0] += ch[0]; for (int k = 1; k < 12; k++) tph[k] += ch[k] - ch[k - 1];
                           tovl += (v[5] < v[4]) ? v[4] - v[5] : 0; }
                }
            }
            if (stop_run) break;
        }
        const bool ok = !stop_run && bad == 0 && pbad == 0 && tbad == 0;      // every row valid; data and halts are not judged here
        (void)sok; (void)errs;
        std::printf("phase %zu: %zu %s in %zu launch%s, %.6f s = %.2f KQPS, %.2f us per command; device %.1f cycles per command, errors 0x%x\n",
                    pi + 1, ph.n, ph.name.c_str(), launches, launches == 1 ? "" : "es", t, ph.n / t / 1e3, 1e6 * t / ph.n,
                    double(cyc) / ph.n, errs);
        std::printf("phase %zu: %llu GET (mean latency %.1f cycles) and %llu PUT (mean latency %.1f cycles)\n", pi + 1,
                    (unsigned long long)ng, ng ? double(lg) / ng : 0.0, (unsigned long long)np, np ? double(lp) / np : 0.0);
        if (ph.pair)
            std::printf("phase %zu: class %s %llu commands (mean latency %.2f cycles), class %s %llu commands (mean latency %.2f cycles)\n",
                        pi + 1, KNAME[ph.a], (unsigned long long)ccnt[0], ccnt[0] ? double(clat[0]) / ccnt[0] : 0.0,
                        KNAME[ph.b], (unsigned long long)ccnt[1], ccnt[1] ? double(clat[1]) / ccnt[1] : 0.0);
        if (!lv.empty()) {
            std::sort(lv.begin(), lv.end());
            auto pct = [&](double q) { return lv[std::min(lv.size() - 1, size_t(q * (lv.size() - 1) + 0.5))]; };
            double mean = 0; for (uint32_t x : lv) mean += x; mean /= lv.size();
            std::printf("phase %zu: latency min %u, p50 %u, p90 %u, p99 %u, p99.9 %u, max %u, mean %.1f cycles (%zu commands)\n",
                        pi + 1, lv.front(), pct(0.5), pct(0.9), pct(0.99), pct(0.999), lv.back(), mean, lv.size());
        }
        if (pn) {
            auto m = [&](uint64_t x) { return double(x) / pn; };
            std::printf("phase %zu: phases, mean cycles: lookup %.1f, bucket read %.1f, processing %.1f, bucket write %.1f, after the write %.1f (%zu commands%s)\n",
                        pi + 1, m(plook), m(pread), m(pproc), m(pwrite), m(ptail), pn, pbad ? "" : ", all in order");
        }
        std::printf("phase %zu: results landing during a response write %llu, longest response write %u cycles\n", pi + 1, (unsigned long long)k_late, k_wo_max);
        if (tr_sat) std::printf("phase %zu: %llu of %llu records have a saturated or absent field\n", pi + 1, (unsigned long long)tr_sat, (unsigned long long)tr_n);
        if (pbad) std::printf("phase %zu: %zu commands with phase timestamps out of order\n", pi + 1, pbad);
        if (tn) {
            static const char* PH[12] = {"handoff", "lookup", "read gate", "bucket read", "decrypt/verify", "operation", "eviction",
                                         "re-encrypt", "write-back wait", "bucket write", "release gate", "result"};
            std::printf("phase %zu: trace, mean cycles (sum = E2E):", pi + 1);
            for (int k = 0; k < 12; k++) std::printf("%s %s %.1f", k ? "," : "", PH[k], double(tph[k]) / tn);
            std::printf(" = E2E %.1f; decryption overlaps the bucket read by %.1f (%zu records)\n", double(te2e) / tn, double(tovl) / tn, tn);
            if (wovl_n) std::printf("phase %zu: re-encryption ends after the write-back start in %zu records, by %.1f cycles on average (safe: the write never catches up)\n",
                                    pi + 1, wovl_n, double(wovl) / wovl_n);
            if (en) {
                auto pct = [&](double q) { uint64_t c = 0, k = uint64_t(std::ceil(q * en)); for (uint32_t x = 0; x < 65536; x++) { c += eh[x]; if (c >= k) return x; } return 65535u; };
                std::printf("phase %zu: re-encryption ends after the last beat by: p50 %u, p99 %u, p99.9 %u, p99.99 %u, max %u cycles; "
                            "the write-back starts after it at %u..%u cycles (%zu records)\n",
                            pi + 1, pct(0.5), pct(0.99), pct(0.999), pct(0.9999), emax, wmin, wmax, en);
            }
        } else if (PTRACE) std::printf("phase %zu: no trace records (is this a TRACE=1 bitstream?)\n", pi + 1);
        if (tbad) std::printf("phase %zu: %zu trace records out of order\n", pi + 1, tbad);
        if (PTRACE && TRACE64) ph_st.print((ph.name + " phase").c_str(), dbg_wbh, dbg_relh);
        if (traffic)
            std::printf("phase %zu: bucket port (pages, off-package) %.0f B read, %.0f B written per command\n",
                        pi + 1, 32.0 * rdb / ph.n, 32.0 * wrb / ph.n);
        std::printf("phase %zu: %s\n", pi + 1, ok ? "complete" : "INCOMPLETE");
        all_ok = all_ok && ok;
    }
    if (PTRACE && TRACE64) all_st.print("whole run (preload and every phase)", dbg_wbh, dbg_relh);
    if (halt_shown && last_where.size()) print_halt_record(("last halted launch: " + last_where).c_str(), last_halt.lat_min, last_halt.lat_max);
    if (lcsv) std::fclose(lcsv);
    std::printf("%s\n", all_ok ? "ALL PHASES COMPLETE" : "RUN INCOMPLETE");
    return all_ok ? 0 : 1;
}
