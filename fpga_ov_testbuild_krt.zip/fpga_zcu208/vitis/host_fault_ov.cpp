// host_fault_ov.cpp -- the fault-injection tests on the overlap test build (build.sh OV_TRACE=1 OV_FAULT=1;
// docs/ov_fault_build.md): v14d's host_fault.cpp (DOMA test plan Part B) reduced to the tamper tests, plus the overlap
// cases. Tests: P0 controls, P1 host-memory bucket tamper (targeted with P1 steering, and black-box), P2 HBM bucket
// tamper (host DMA), P3 tag/IV corruption, P8 in-flight beat corruption, PI the same faults with other commands in
// flight (the target in the middle of a 16-command launch). Every result is printed as terminal text: a line per test,
// then the results table (and, with --csv, one CSV line per trial on stdout, prefixed "CSV,").
//
// Usage: ./host_fault_ov <xclbin> [TESTS] [--scale F] [--seed S] [--csv] [--verbose]
//   TESTS    comma-separated: P0,P1,P2,P3,P8,PI or all (default: all)
//   --scale  multiplies every trial count (1 = the plan's counts; 0.01 for a quick pass)
//   --seed   the host's random seed (default 1)
// Environment: DOMA_N (records, default 16384), DOMA_LAMBDA (default 7), DOMA_HBM_PCT (default 20), DOMA_POOL (stash
//   pool, default Claim 1's bound + 1), DOMA_OV_K (the run-time in-flight cap, 2, 3 or 4; unset: the build's 4).
// The test build is the overlap production design plus OV_TRACE's header records and the hooks P1, P3, P8 and the planted
// leak, armed through 11 more scalar arguments (the v14d build B register map; this build uses flt_ctl, flt_cmd, flt_p8,
// flt_p3, flt_p1k, flt_p1b). With every hook disarmed DOMA's RTL is as in production. It writes records [n+2] (hooks) and
// [n+3] (observation) after the summary. Never measure with it or deploy it.
#include <xrt/xrt_bo.h>
#include <xrt/xrt_device.h>
#include <xrt/xrt_kernel.h>
#include <algorithm>
#include <atomic>
#include <cctype>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <map>
#include <random>
#include <set>
#include <string>
#include <thread>
#include <vector>
#include "doma_debug.h"

// ---------------- configuration (must match the bitstream) ----------------
static uint32_t LAMBDA = 7;                        // build.sh LAMBDA (checked against the summary)
static const uint32_t ZPOS = 8;                    // rtl/oram_params.vh ORAM_Z
static const size_t BLOCK = 4096, BEATS = 128;     // build B is built for 4 KB blocks (checked)
static const size_t STRIDE = ZPOS * BLOCK;         // one bucket, compact layout
static const uint32_t BKT_BEATS = ZPOS * BEATS;    // 1024 beats per bucket
static const uint32_t CMD_TIMEOUT = 2000000;       // rtl/doma_kernel.v: cycles a command may wait
static uint32_t NBLK = 16384, NB = 0, HBMK = 0, POOL_DEF = 0, POOL_MAX = 0;
static unsigned HBM_PCT = 20;
static uint32_t OV_K = 0;                          // DOMA_OV_K: the run-time in-flight cap (bits [31:29] of hbm_bkts; 0: the build's 4)
static const uint8_t T_GET = 1, T_PUT = 2, T_ACK = 0x10, T_ERR = 0x11, T_SUM = 0x5A, CANARY = 0xA5;

// flt_ctl bits (docs/v14d_fault_build.md)
enum : uint32_t { F_P3 = 1, F_P5 = 2, F_P6 = 4, F_P8 = 8, F_P1 = 16, F_P7 = 32, F_P8_HBM = 0x100, F_P1_ALL = 0x1000 };
struct FaultArgs { uint32_t ctl = 0, cmd = 0, p5 = 0, p6 = 0, p8 = 0, p3 = 0, p1k = 0, p1b = 0, p7x = 0, hs = 0, p6n = 0; };

static size_t roundup4k(size_t x) { return (x + 4095) & ~size_t(4095); }
static double SCALE = 1.0; static bool CSV = false, VERBOSE = false; static uint64_t SEED = 1;
static int cnt(double plan) { return std::max(1, int(std::lround(plan * SCALE))); }

// ---------------- stash bound (host_doma.cpp, Claim 1) ----------------
static double ln_mgf_A(double t, double Bk, double n) {
    const double p = 1.0 / Bk, lr = std::log1p(-p) + t;
    if (std::fabs(lr) < 1e-15) return std::log(p * n + 1.0);
    if (lr > 0) { const double lrn = n * lr; if (lrn > 700) return INFINITY;
                  return std::log(p * std::expm1(lrn) / std::expm1(lr) + std::exp(lrn)); }
    const double rn = std::exp(n * lr);
    return std::log(p * (1 - rn) / (-std::expm1(lr)) + rn);
}
static double stash_xR(double Bk, double n, double lg) {
    double best = INFINITY;
    for (int i = 1; i < 400; i++) { const double u = i * 0.005, v = ln_mgf_A(std::expm1(u) / Bk, Bk, n);
        if (!std::isfinite(v)) break; best = std::min(best, (Bk * v + lg) / u); }
    return best;
}
static double stash_xO(double Bk, double n, int Z, double lg) {
    double best = INFINITY; std::vector<double> lt(160); const double p = 1.0 / Bk, lp = std::log(p), lq = std::log1p(-p);
    for (int i = 1; i < 400; i++) { const double u = i * 0.01; double mx = -INFINITY, sum = 0;
        for (int k = 0; k < 160; k++) { lt[k] = std::lgamma(n + 1) - std::lgamma(k + 1.0) - std::lgamma(n - k + 1) + k * lp + (n - k) * lq
                                                + u * std::max(0, k - Z); mx = std::max(mx, lt[k]); }
        for (int k = 0; k < 160; k++) sum += std::exp(lt[k] - mx);
        best = std::min(best, (Bk * (mx + std::log(sum)) + lg) / u); }
    return best;
}
static double stash_bound(double n, double lam, int Z) {
    const double Bk = std::ceil(n / lam), G = 64 * std::log(2.0);
    double best = INFINITY;
    for (double f : {0.1, 0.3, 0.5, 0.7, 0.9})
        best = std::min(best, stash_xR(Bk, n, G - std::log(f)) + stash_xO(Bk, n, int(Z), G - std::log(1 - f)));
    return best;
}

// ---------------- the kernel, its buffers and one launch ----------------
struct Cmd { uint8_t type; uint32_t key, off = 0, len = 0; uint32_t exp_status = 0; };
struct Hdr { uint8_t type; uint32_t key, lat, status; bool answered; };
struct Summary { bool ok = false; uint32_t lam = 0, beats = 0, dbg = 0, lat_min = 0, lat_max = 0, errors = 0, done = 0;
                 uint64_t total = 0, rd = 0, wr = 0; };
struct StashRec { bool valid = false; uint8_t fired = 0; uint32_t p1n = 0, occ = 0, bmax = 0, lmax = 0, hist[8] = {0}; };
struct Obs { bool valid = false; uint8_t flags = 0, kst = 0; uint32_t hacc = 0, hcyc = 0, h_w = 0, h_aw = 0, h_rv = 0,
             p_aw = 0, p_w = 0, p_rv = 0, p_kd = 0, ov = 0, tok = 0, tfail = 0, nrel = 0; };
// h_rv / p_rv: DOMA's result beats to the kernel (inside the card; the kernel writes nothing out after a halt);
// p_kd: response-data beats the kernel wrote to the host after the halt (must be 0)
struct Launch { Summary s; StashRec st; Obs o; std::vector<Hdr> h; int mism = 0, unanswered = 0, canary_bad = 0;
                std::vector<int> wrong_keys; };

static xrt::device* g_dev; static xrt::kernel* g_k;
static xrt::bo b_cmd, b_resp, b_pages, b_meta, b_brec, b_stash, b_hbm;
static size_t MAXC = 0;
static int done_(int rc) { b_cmd = xrt::bo(); b_resp = xrt::bo(); b_pages = xrt::bo(); b_meta = xrt::bo(); b_brec = xrt::bo();
                           b_stash = xrt::bo(); b_hbm = xrt::bo(); return rc; }   // the buffers go before the device                                 // commands per launch (buffer capacity)
static uint32_t cur_pool = 0;
static std::vector<uint32_t> refv;                      // the reference model: each block's version (0: zeros since boot)
static uint32_t ver_next = 1;
static std::mt19937_64 rng;

static void pattern(uint32_t key, uint32_t ver, uint8_t* p) {   // a block's content for (key, version); version 0: zeros
    if (ver == 0) { std::memset(p, 0, BLOCK); return; }
    uint64_t x = (uint64_t(key) << 32 | ver) * 0x9E3779B97F4A7C15ull ^ 0xD1B54A32D192ED03ull;
    for (size_t i = 0; i < BLOCK; i += 8) { x ^= x << 13; x ^= x >> 7; x ^= x << 17; std::memcpy(p + i, &x, 8); }
}
static uint64_t bits(const uint8_t* r, unsigned lo, unsigned w) {   // a little-endian bit field of a 32-byte record
    uint64_t v = 0; for (unsigned i = 0; i < w; i++) { unsigned b = lo + i; v |= uint64_t((r[b / 8] >> (b % 8)) & 1) << i; } return v;
}
static bool fits(size_t n) { return ((n + 2) % 128) != 0 && ((n + 2) % 128) != 127; }   // records [n+2], [n+3] written

// one launch: n commands (n = 0: boot / re-boot), the fault registers, the canary, every check against the reference
static Launch launch(const std::vector<Cmd>& c, const FaultArgs& fa, uint32_t pool = 0) {
    const size_t n = c.size();
    if (n > MAXC) { std::printf("internal: %zu commands exceed the buffers (%zu)\n", n, MAXC); std::exit(2); }
    if (n && !fits(n)) { std::printf("internal: %zu commands leave no room for records [n+2], [n+3]\n", n); std::exit(2); }
    const size_t hc = roundup4k(n * 32), hr = roundup4k(n * 32 + 64);
    if (n) {
        auto p = b_cmd.map<uint8_t*>(); std::memset(p, 0, hc + n * BLOCK);
        for (size_t i = 0; i < n; i++) {
            p[i * 32] = c[i].type; std::memcpy(p + i * 32 + 4, &c[i].key, 4);
            std::memcpy(p + i * 32 + 8, &c[i].off, 4); std::memcpy(p + i * 32 + 12, &c[i].len, 4);
            if (c[i].type == T_PUT && c[i].exp_status == 0) pattern(c[i].key, ver_next + uint32_t(i), p + hc + i * BLOCK);
        }
        b_cmd.sync(XCL_BO_SYNC_BO_TO_DEVICE, hc + n * BLOCK, 0);
    }
    {   // the canary: every header, record and data slot of this launch
        auto r = b_resp.map<uint8_t*>(); const size_t span = std::max(hr + n * BLOCK, size_t(4096));
        std::memset(r, CANARY, span); b_resp.sync(XCL_BO_SYNC_BO_TO_DEVICE, span, 0);
    }
    if (pool) cur_pool = pool;
    auto run = (*g_k)(b_cmd, b_resp, b_pages, uint32_t(n), b_meta, b_brec, b_stash, NBLK, b_hbm, HBMK | (OV_K << 29), cur_pool,
                      fa.ctl, fa.cmd, fa.p5, fa.p6, fa.p8, fa.p3, fa.p1k, fa.p1b, fa.p7x, fa.hs, fa.p6n);
    run.wait();
    Launch L;
    const size_t span = std::max(hr + n * BLOCK, (n + 4) * size_t(32));
    b_resp.sync(XCL_BO_SYNC_BO_FROM_DEVICE, span, 0);
    auto r = b_resp.map<uint8_t*>();
    const uint8_t* s = r + n * 32;
    L.s.ok = (s[0] == T_SUM); L.s.lam = s[1] ? s[1] : 6; L.s.dbg = s[2]; L.s.beats = rd32(s + 4);
    std::memcpy(&L.s.total, s + 8, 8); L.s.lat_min = rd32(s + 16); L.s.lat_max = rd32(s + 20);
    L.s.errors = rd32(s + 24); L.s.done = rd32(s + 28);
    if (s[32] == 0x5B) { std::memcpy(&L.s.rd, s + 40, 8); std::memcpy(&L.s.wr, s + 48, 8); }
    const uint8_t* q = s + 64;                                  // [n+2]
    if ((L.s.dbg & 0x20) && q[0] == 0x5F) {
        L.st.valid = true; L.st.fired = q[1]; L.st.p1n = rd16(q + 2);
        L.st.occ = uint32_t(bits(q, 32, 24)); L.st.bmax = uint32_t(bits(q, 56, 24)); L.st.lmax = uint32_t(bits(q, 80, 24));
        for (int k = 0; k < 8; k++) L.st.hist[k] = uint32_t(bits(q, 104 + 19 * k, 19));
    }
    const uint8_t* o = s + 96;                                  // [n+3]
    if ((L.s.dbg & 0x40) && o[0] == 0x60) {
        L.o.valid = true; L.o.flags = o[1]; L.o.kst = o[2] & 63; L.o.p_kd = o[3]; L.o.hacc = rd32(o + 4); L.o.hcyc = rd32(o + 8);
        L.o.h_w = rd16(o + 12); L.o.h_aw = o[14]; L.o.h_rv = o[15]; L.o.p_aw = rd16(o + 16); L.o.p_w = rd16(o + 18);
        L.o.p_rv = rd16(o + 20); L.o.ov = rd16(o + 22); L.o.tok = uint32_t(bits(o, 192, 24)); L.o.tfail = o[27]; L.o.nrel = rd32(o + 28);
    }
    // every command: header, status, data against the reference (and the canary of unanswered / halted commands)
    std::vector<uint8_t> want(BLOCK);
    for (size_t i = 0; i < n; i++) {
        const uint8_t* h = r + i * 32; Hdr x{h[0], rd32(h + 4), rd32(h + 8), rd32(h + 12), true};
        const uint8_t* d = r + hr + i * BLOCK;
        bool can = true; for (size_t b = 0; b < BLOCK; b++) if (d[b] != CANARY) { can = false; break; }
        if (h[0] == CANARY && h[1] == CANARY) { x.answered = false; L.unanswered++; if (!can) L.canary_bad++; L.h.push_back(x); continue; }
        if (x.status == 0x8 || x.status == 0x10) { if (!can) L.canary_bad++; L.h.push_back(x); continue; }   // halted / timed out
        if (c[i].exp_status) { if (x.type != T_ERR || x.status != c[i].exp_status) L.mism++; L.h.push_back(x); continue; }
        if (x.type != T_ACK || x.key != c[i].key || x.status != 0) { L.mism++; L.h.push_back(x); continue; }
        if (c[i].type == T_PUT) refv[c[i].key] = ver_next + uint32_t(i);
        else { pattern(c[i].key, refv[c[i].key], want.data());
               if (std::memcmp(d, want.data(), BLOCK) != 0) { L.mism++; L.wrong_keys.push_back(int(c[i].key)); } }
        L.h.push_back(x);
    }
    ver_next += uint32_t(n) + 1;
    return L;
}
static FaultArgs NOF;
static uint32_t boot_occ = 0;
static bool boot(uint32_t pool = 0) {             // a fresh boot: new layout, every block zeros
    Launch L = launch({}, NOF, pool ? pool : POOL_DEF);
    std::fill(refv.begin(), refv.end(), 0u);
    if (!L.s.ok) { std::printf("boot: no summary record\n"); return false; }
    boot_occ = L.st.occ;
    if (L.s.errors) { if (VERBOSE) std::printf("boot (pool %u): errors 0x%x\n", cur_pool, L.s.errors); return false; }
    return true;
}
static uint64_t halt_rec(const Summary& s) { return (uint64_t(s.lat_max) << 32) | s.lat_min; }
static uint64_t halt_bucket(const Summary& s) { return halt_rec(s) >> 40; }
static unsigned halt_code(const Summary& s) { return unsigned(halt_rec(s) >> 32) & 3; }
static bool halt_hbm(const Summary& s) { return (halt_rec(s) >> 34) & 1; }

// buckets: on package 1 .. HBMK-1 (bucket 0 cannot be a steering target), off package max(HBMK, 1) .. NB-1
static uint32_t rnd(uint64_t n) { return uint32_t(rng() % n); }
static uint32_t pick_off() { const uint32_t lo = std::max<uint32_t>(HBMK, 1); return lo + rnd(NB - lo); }
static uint32_t pick_on() { return 1 + rnd(HBMK - 1); }
static uint8_t* hostb(uint32_t j) { return b_pages.map<uint8_t*>() + size_t(j - HBMK) * STRIDE; }   // host bucket j
static std::vector<uint8_t> snap(uint32_t j) { const uint8_t* p = hostb(j); return {p, p + STRIDE}; }
static void put_host(uint32_t j, const std::vector<uint8_t>& v) { std::memcpy(hostb(j), v.data(), STRIDE); b_pages.sync(XCL_BO_SYNC_BO_TO_DEVICE); }
static std::vector<uint8_t> get_hbm(uint32_t j) {
    b_hbm.sync(XCL_BO_SYNC_BO_FROM_DEVICE, STRIDE, size_t(j) * STRIDE);
    const uint8_t* p = b_hbm.map<uint8_t*>() + size_t(j) * STRIDE; return {p, p + STRIDE};
}
static void put_hbm(uint32_t j, const std::vector<uint8_t>& v) {
    std::memcpy(b_hbm.map<uint8_t*>() + size_t(j) * STRIDE, v.data(), STRIDE);
    b_hbm.sync(XCL_BO_SYNC_BO_TO_DEVICE, STRIDE, size_t(j) * STRIDE);
}
static uint32_t rkey() { return rnd(NBLK); }
static Cmd get_(uint32_t k) { return Cmd{T_GET, k}; }
static Cmd put_(uint32_t k) { return Cmd{T_PUT, k}; }
static std::vector<Cmd> uniform(size_t n) {
    std::vector<Cmd> v; for (size_t i = 0; i < n; i++) v.push_back((rng() & 1) ? put_(rkey()) : get_(rkey())); return v;
}
static size_t fitn(size_t n) { while (n > 1 && !fits(n)) n--; return n; }
// P1 steering: the next access to block k takes bucket j as its new bucket (a PUT, so k holds fresh data)
static bool steer(uint32_t k, uint32_t j) {
    FaultArgs fa; fa.ctl = F_P1; fa.p1k = k; fa.p1b = j;
    Launch L = launch({put_(k)}, fa);
    const bool ok = !L.s.errors && L.mism == 0 && L.st.valid && (L.st.fired & 0x10) && L.st.p1n == 1;
    if (!ok) std::printf("steer: block %u to bucket %u failed (errors 0x%x, mismatches %d, fired 0x%02x, overrides %u)\n",
                         k, j, L.s.errors, L.mism, L.st.fired, L.st.p1n);
    return ok;
}
static void settle(int ms = 10) { std::this_thread::sleep_for(std::chrono::milliseconds(ms)); }

// ---------------- results ----------------
struct Row { std::string fault, where, mech; int trials = 0, halted_ok = 0, halt_exp = 0, released = 0, writes_after = 0,
             partial = 0, pass = 0, fail = 0; std::string note; bool no_halt_expected = false;
             bool v14 = false; };   // v14: not detected by design (on-package plaintext): "pass" = behaved as designed
static std::vector<Row> rows;
static int trial_id = 0;
static void csv(const std::string& fault, const std::string& params, int acc, const Launch& L, bool canary, int bucket_same,
                int lat, bool pass) {
    if (!CSV) return;
    const bool h = L.s.errors & 0x8;
    std::printf("CSV,%d,B,%s,%s,%llu,%u,%u,%u,%d,%d,0x%x,%u,%d,%lld,%d,%d,%u,%u,%d,%d,%d,%d\n", trial_id, fault.c_str(), params.c_str(),
                (unsigned long long)SEED, NBLK, ZPOS, LAMBDA, acc, h ? 1 : 0, L.s.errors, h ? halt_code(L.s) : 0,
                L.o.valid && (L.o.flags & 1) ? int(L.o.hacc) : -1, h ? (long long)halt_bucket(L.s) : -1LL, canary ? 1 : 0,
                (L.o.flags >> 2) & 1, L.o.h_w, L.o.ov, bucket_same, L.mism, lat, pass ? 1 : 0);
}
static void csv_header() {
    if (CSV) std::printf("CSV,trial_id,build,fault_point,params,seed,N,Z,lambda,acc_index,halted,halt_cause,halt_phase,halt_acc,"
                         "halt_bucket,canary_intact,post_halt_activity,wbeats_faulting_acc,order_violation,bucket_unchanged,"
                         "refmodel_mismatches,latency,pass\n");
}
// criteria (a)-(d) for a halt expected at command `acc` of L with the summary errors `exp`
static bool clean_halt(const Launch& L, uint32_t exp, int acc, int64_t bucket, std::string* why) {
    std::string w; const bool tagfail = (exp & 0x200) != 0;   // an integrity halt: not even a result beat inside the card
    if (L.s.errors != exp) w += " errors 0x" + [&]{ char b[16]; std::snprintf(b, 16, "%x", L.s.errors); return std::string(b); }();
    if (!L.o.valid) w += " no observation record";
    else {
        if (!(L.o.flags & 1)) w += " no halt observed";
        if (acc >= 0 && L.o.hacc != uint32_t(acc)) w += " halt at command " + std::to_string(int(L.o.hacc));
        if (L.o.h_aw || L.o.h_w) w += " the halting access wrote its bucket";     // (what happens after the halt is not judged)
        if (tagfail && L.o.h_rv) w += " DOMA released result beats of the failed access";
        if (L.o.ov) w += " order violations " + std::to_string(L.o.ov);
    }
    if (bucket >= 0 && int64_t(halt_bucket(L.s)) != bucket) w += " halt bucket " + std::to_string(halt_bucket(L.s));
    if (L.canary_bad) w += " canary overwritten";
    if (L.mism) w += " " + std::to_string(L.mism) + " wrong results before the halt";
    if (why) *why = w;
    return w.empty();
}
static void tally(Row& r, const Launch& L, bool pass) {
    r.trials++; (pass ? r.pass : r.fail)++;
    if (L.o.valid) { r.released += (L.o.p_kd || L.canary_bad) ? 1 : 0; r.writes_after += (L.o.p_aw || L.o.p_w) ? 1 : 0;
                     if (L.o.h_w != 0 && L.o.h_w != BKT_BEATS) r.partial++; }
}
static void line(const Row& r) {
    std::printf("  -> %-34s trials %5d  pass %5d  fail %5d%s%s\n", r.fault.c_str(), r.trials, r.pass, r.fail,
                r.note.empty() ? "" : "  | ", r.note.c_str());
    std::fflush(stdout);
}
static bool need_boot = true;
static bool ensure_boot() { if (!need_boot) return true; need_boot = !boot(); return !need_boot; }

// ================= P0: controls =================
static void p0() {
    std::printf("\nP0 controls: uniform workload, every hook disarmed (and P1/P3/P8 armed with no effect)\n");
    Row r{"Controls (hooks disarmed)", "--", "Both"}; r.no_halt_expected = true;
    Row a{"Controls (hooks armed, null)", "--", "Debug"}; a.no_halt_expected = true;
    if (!ensure_boot()) { std::printf("P0: boot failed\n"); return; }
    const size_t B = fitn(std::min<size_t>(MAXC, std::getenv("DOMA_BATCH") ? std::stoul(std::getenv("DOMA_BATCH")) : 1000));
    long acc = 0, target = cnt(20000), mism = 0, ov = 0; uint32_t lmin = UINT32_MAX, lmax = 0;
    while (acc < target) {
        auto c = uniform(fitn(std::min<size_t>(B, size_t(target - acc) + 2)));
        Launch L = launch(c, NOF);
        const bool ok = !L.s.errors && !L.mism && L.o.valid && !(L.o.flags & 1) && !L.o.ov && L.s.done == c.size();
        tally(r, L, ok); acc += long(c.size()); mism += L.mism; ov += L.o.ov;
        lmin = std::min(lmin, L.s.lat_min); lmax = std::max(lmax, L.s.lat_max);
        csv("P0", "disarmed", -1, L, true, -1, -1, ok);
        if (L.s.errors) { need_boot = true; ensure_boot(); }
    }
    // armed with null effect: P3 on an unused record bit (224..255), P5 by 0 cycles, P6 for 0 cycles, P8 on a beat
    // past the bucket (never reached); each must leave every result correct and no halt
    for (int t = 0; t < cnt(200); t++) {
        auto c = uniform(fitn(16)); FaultArgs fa; const int m = t % 3; fa.cmd = rnd(c.size());
        if (m == 0) { fa.ctl = F_P3; fa.p3 = 224 + rnd(32); }                         // a bit the record does not use
        if (m == 1) { fa.ctl = F_P8; fa.p8 = (0xFFFFu << 8) | rnd(256); }             // a beat past the bucket
        if (m == 2) { uint32_t k; bool used; do { k = rkey(); used = false; for (auto& x : c) used = used || x.key == k; } while (used);
                      fa.ctl = F_P1; fa.p1k = k; fa.p1b = pick_off(); }               // a block the launch never asks for
        Launch L = launch(c, fa);
        const bool ok = !L.s.errors && !L.mism && L.o.valid && !(L.o.flags & 1) && !L.o.ov && !(m == 2 && (L.st.fired & 0x10));
        tally(a, L, ok); acc += long(c.size()); mism += L.mism;
        csv("P0", "armed-null-" + std::to_string(m), int(fa.cmd), L, true, -1, -1, ok);
        if (L.s.errors) { need_boot = true; ensure_boot(); }
    }
    char b[200]; std::snprintf(b, sizeof b, "%ld accesses, %ld wrong results, %ld order violations, latency %u..%u cycles",
                               acc, mism, ov, lmin, lmax);
    r.note = b; rows.push_back(r); line(r); rows.push_back(a); line(a);
}

// ================= P1: host-memory bucket tamper =================
// targeted: steer block k to off-package bucket j, tamper j in host memory, request k: the access must read j and halt
static void p1() {
    std::printf("\nP1 host-memory bucket tamper (targeted with P1 steering, plus black-box)\n");
    if (NB - std::max<uint32_t>(HBMK, 1) < 2) { std::printf("P1: needs at least two off-package buckets (DOMA_HBM_PCT)\n"); return; }
    struct V { const char* name; const char* label; int n; };
    const V vs[] = {{"flip", "Bit flip (random position, incl. first/last beat)", cnt(1000)}, {"replay", "Replay of older version", cnt(1000)},
                    {"swap", "Swap two buckets", cnt(1000)}, {"zero", "Zero bucket", cnt(200)}, {"truncate", "Truncate bucket", cnt(200)},
                    {"identical", "Identical rewrite (control)", cnt(200)}};
    for (const V& v : vs) {
        Row r{v.label, "Host-memory bucket", "Host"}; const bool ctl = std::string(v.name) == "identical"; r.no_halt_expected = ctl;
        int bsame = 0, flips_forced = 0;
        for (int t = 0; t < v.n; t++, trial_id++) {
            need_boot = need_boot || !ctl; if (!ensure_boot()) { r.fail++; r.trials++; continue; }
            const uint32_t k = rkey(), j = pick_off();
            if (!steer(k, j)) { r.fail++; r.trials++; need_boot = true; continue; }
            std::string params;
            if (std::string(v.name) == "replay") {                         // j's version now; then DOMA rewrites j
                auto old = snap(j);
                FaultArgs fa; fa.ctl = F_P1; fa.p1k = k; fa.p1b = j;       // reads j, re-steers k to j
                Launch L0 = launch({get_(k)}, fa);
                if (L0.s.errors || L0.mism || std::memcmp(old.data(), hostb(j), STRIDE) == 0) {
                    std::printf("P1 replay: bucket %u not rewritten by the access (errors 0x%x)\n", j, L0.s.errors);
                    r.fail++; r.trials++; need_boot = true; continue; }
                put_host(j, old); params = "bucket=" + std::to_string(j);
            } else if (std::string(v.name) == "flip") {
                size_t bit;
                if (t < int(2 * ZPOS) && flips_forced < int(2 * ZPOS)) {     // every position's first and last beat
                    const size_t pos = t / 2, beat = (t % 2) ? BEATS - 1 : 0; bit = ((pos * BEATS + beat) * 32) * 8 + rnd(256); flips_forced++;
                } else if (t % 10 == 0) bit = (STRIDE - 32) * 8 + rnd(256);  // the bucket's last beat, often
                else bit = rnd(STRIDE * 8);
                auto x = snap(j); x[bit / 8] ^= uint8_t(1u << (bit % 8)); put_host(j, x);
                params = "bucket=" + std::to_string(j) + " bit=" + std::to_string(bit);
            } else if (std::string(v.name) == "swap") {
                uint32_t m; do m = pick_off(); while (m == j);
                auto a = snap(j), b = snap(m); put_host(j, b); put_host(m, a);
                params = "bucket=" + std::to_string(j) + " with=" + std::to_string(m);
            } else if (std::string(v.name) == "zero") {
                put_host(j, std::vector<uint8_t>(STRIDE, 0)); params = "bucket=" + std::to_string(j);
            } else if (std::string(v.name) == "truncate") {
                const size_t keep = size_t(rnd(BKT_BEATS)) * 32; auto x = snap(j);
                bool nz = false; for (size_t i = keep; i < STRIDE; i++) nz |= (x[i] != 0);
                std::memset(x.data() + keep, 0, STRIDE - keep); if (!nz) x[STRIDE - 1] = 1;   // (never an identical rewrite)
                put_host(j, x); params = "bucket=" + std::to_string(j) + " keep=" + std::to_string(keep);
            } else {                                                         // identical rewrite
                put_host(j, snap(j)); params = "bucket=" + std::to_string(j);
            }
            const auto tampered = snap(j);
            Launch L = launch({get_(k)}, NOF);
            bool pass; std::string why;
            if (ctl) { pass = !L.s.errors && !L.mism && L.o.valid && !L.o.ov; if (!pass) why = " halted or wrong result"; }
            else {
                pass = clean_halt(L, 0x208, 0, j, &why);
                settle(); b_pages.sync(XCL_BO_SYNC_BO_FROM_DEVICE);
                const bool same = std::memcmp(tampered.data(), hostb(j), STRIDE) == 0; bsame += same;
                r.halt_exp += (L.s.errors == 0x208);
            }
            tally(r, L, pass); csv("P1-" + std::string(v.name), params, 0, L, L.canary_bad == 0, ctl ? -1 : 1, -1, pass);
            if (!pass && r.fail <= 3) std::printf("  P1 %s trial %d (%s): FAIL:%s\n", v.name, t, params.c_str(), why.c_str());
            need_boot = need_boot || (L.s.errors != 0);
        }
        if (!ctl) r.note = "halted 0x208 at bucket j: " + std::to_string(r.halt_exp) + "; bucket j still tampered: " + std::to_string(bsame);
        else r.note = "no halt, k's data correct";
        rows.push_back(r); line(r);
    }
    // black-box: tamper a random off-package bucket, run the uniform workload until DOMA halts (cap: 4 x B accesses)
    Row r{"Bit flip, black-box (untargeted)", "Host-memory bucket", "Host"};
    for (int t = 0; t < cnt(50); t++, trial_id++) {
        need_boot = true; if (!ensure_boot()) { r.fail++; r.trials++; continue; }
        const uint32_t j = pick_off(); auto x = snap(j); const size_t bit = rnd(STRIDE * 8); x[bit / 8] ^= uint8_t(1u << (bit % 8));
        put_host(j, x);
        long acc = 0; bool done = false, pass = false; Launch L; std::string why;
        while (!done && acc < 4L * NB + 64) {
            auto c = uniform(fitn(64)); L = launch(c, NOF); acc += long(c.size());
            if (L.s.errors) { done = true; pass = clean_halt(L, 0x208, -1, j, &why); }
        }
        if (!done) why = " no halt within the cap";
        settle(); b_pages.sync(XCL_BO_SYNC_BO_FROM_DEVICE);
        tally(r, L, pass); r.halt_exp += (L.s.errors == 0x208);
        csv("P1-blackbox", "bucket=" + std::to_string(j) + " bit=" + std::to_string(bit), int(L.o.hacc), L, L.canary_bad == 0, 1, -1, pass);
        if (!pass && r.fail <= 3) std::printf("  P1 black-box trial %d: FAIL:%s\n", t, why.c_str());
    }
    r.note = "halted 0x208 at bucket j: " + std::to_string(r.halt_exp); rows.push_back(r); line(r); need_boot = true;
}

// ================= P2: HBM-resident bucket tamper (host DMA into the on-package bucket buffer) =================
// v14 keeps on-package buckets as plaintext with no tag (A2 excludes this path): the expected v14 outcome is NOT
// DETECTED. The test places a block in an on-package bucket, finds it there (plaintext), corrupts one bit of it and reads it.
static void p2() {
    std::printf("\nP2 HBM-resident bucket tamper (host DMA; a test of the check, not an attack path: (A2))\n");
    Row r{"HBM bucket tamper (P2)", "On-package bucket", "Host DMA"}; r.no_halt_expected = true;
    if (HBMK < 2) { std::printf("P2: needs on-package buckets (DOMA_HBM_PCT)\n"); return; }
    int undetected = 0, detected = 0, unplaced = 0;
    for (int t = 0; t < cnt(200); t++, trial_id++) {
        need_boot = true; if (!ensure_boot()) { r.fail++; r.trials++; continue; }
        const uint32_t j = pick_on(); uint32_t k1 = rkey(), k2; do k2 = rkey(); while (k2 == k1);
        FaultArgs fa; fa.ctl = F_P1 | F_P1_ALL; fa.p1b = j;                  // both blocks to bucket j
        Launch A = launch({put_(k1), put_(k2)}, fa);
        Launch B = launch({get_(k1)}, NOF);                                  // reads j: its write-back takes k2 if there is room
        auto x = get_hbm(j); std::vector<uint8_t> want(BLOCK); pattern(k2, refv[k2], want.data());
        int pos = -1; for (uint32_t p = 0; p < ZPOS; p++) if (std::memcmp(x.data() + p * BLOCK, want.data(), BLOCK) == 0) pos = int(p);
        if (A.s.errors || B.s.errors || pos < 0) { unplaced++; t--; if (unplaced > 20 * cnt(200)) break; continue; }
        const size_t bit = size_t(pos) * BLOCK * 8 + rnd(BLOCK * 8); x[bit / 8] ^= uint8_t(1u << (bit % 8)); put_hbm(j, x);
        Launch L = launch({get_(k2)}, NOF);
        const bool halted = L.s.errors != 0, wrong = L.mism != 0;
        if (halted) detected++; else if (wrong) undetected++;
        tally(r, L, !halted && wrong);                                         // as v14 is designed: returned, undetected
        csv("P2", "bucket=" + std::to_string(j) + " pos=" + std::to_string(pos) + " bit=" + std::to_string(bit), 0, L, true, -1, -1, halted);
    }
    r.note = "v14: on-package buckets are plaintext without a tag -> expected NOT DETECTED; halted " + std::to_string(detected) +
             ", tampered data returned undetected " + std::to_string(undetected) + " (block placed by steering, found by its plaintext)";
    r.v14 = true; rows.push_back(r); line(r); need_boot = true;
}

// ================= P3: tag / IV corruption on the record read path (hook) =================
static void p3() {
    std::printf("\nP3 tag/IV corruption (hook on the bucket-record read; one bit of the {tag, IV} beat, applied once)\n");
    Row r{"Tag / IV corruption", "Bucket record (HBM)", "Debug"}; Row c{"Tag / IV hook, unused bit (control)", "Bucket record (HBM)", "Debug"};
    c.no_halt_expected = true;
    int tagb = 0, ivb = 0;
    for (int t = 0; t < cnt(500) + cnt(50); t++, trial_id++) {
        const bool ctl = t >= cnt(500);
        if (!ensure_boot()) { r.fail++; r.trials++; continue; }
        const uint32_t k = rkey(), j = pick_off();
        if (!steer(k, j)) { need_boot = true; continue; }
        FaultArgs fa; fa.ctl = F_P3; fa.cmd = 0; fa.p3 = ctl ? 224 + rnd(32) : rnd(224);
        (fa.p3 < 96 ? ivb : tagb) += ctl ? 0 : 1;
        const auto before = snap(j);
        Launch L = launch({get_(k)}, fa);
        std::string why; bool pass;
        if (ctl) { pass = !L.s.errors && !L.mism && (L.st.fired & 1); tally(c, L, pass); }
        else {
            pass = clean_halt(L, 0x208, 0, j, &why) && (L.st.fired & 1) && !(L.st.fired & 0x40) && L.o.h_w == 0 && L.o.h_aw == 0;
            settle(); b_pages.sync(XCL_BO_SYNC_BO_FROM_DEVICE);
            r.halt_exp += (L.s.errors == 0x208); tally(r, L, pass);
        }
        csv(ctl ? "P3-control" : "P3", "bucket=" + std::to_string(j) + " bit=" + std::to_string(fa.p3), 0, L, L.canary_bad == 0, 1, -1, pass);
        if (!pass && (r.fail + c.fail) <= 3) std::printf("  P3 trial %d bit %u: FAIL:%s\n", t, fa.p3, why.c_str());
        need_boot = (L.s.errors != 0);
    }
    r.note = "bits in the IV " + std::to_string(ivb) + ", in the tag " + std::to_string(tagb) + "; halted 0x208 at bucket j: " +
             std::to_string(r.halt_exp) + "; no write-back of the halting access";
    c.note = "bits 224..255 of the beat (unused): no halt, results correct";
    rows.push_back(r); line(r); rows.push_back(c); line(c);
}

// ================= P8: in-flight beat corruption (hook on the bucket read stream) =================
static void p8() {
    std::printf("\nP8 in-flight beat corruption: one bit of beat k (0 .. %u, incl. the first and last) of the access's bucket read\n", BKT_BEATS - 1);
    Row r{"In-flight beat corruption", "Bucket read stream", "Debug"};
    int firstb = 0, lastb = 0;
    for (int t = 0; t < cnt(500); t++, trial_id++) {
        if (!ensure_boot()) { r.fail++; r.trials++; continue; }
        const uint32_t k = rkey(), j = pick_off();
        if (!steer(k, j)) { need_boot = true; continue; }
        const uint32_t beat = (t % 4 == 0) ? 0 : (t % 4 == 1) ? BKT_BEATS - 1 : rnd(BKT_BEATS);
        firstb += beat == 0; lastb += beat == BKT_BEATS - 1;
        FaultArgs fa; fa.ctl = F_P8; fa.cmd = 0; fa.p8 = (beat << 8) | rnd(256);
        const auto before = snap(j);
        Launch L = launch({get_(k)}, fa);
        std::string why;
        bool pass = clean_halt(L, 0x208, 0, j, &why) && (L.st.fired & 8) && L.o.h_aw == 0 && L.o.h_w == 0;
        settle(); b_pages.sync(XCL_BO_SYNC_BO_FROM_DEVICE);
        r.halt_exp += (L.s.errors == 0x208); tally(r, L, pass);
        csv("P8", "bucket=" + std::to_string(j) + " beat=" + std::to_string(beat) + " bit=" + std::to_string(fa.p8 & 255), 0, L, L.canary_bad == 0, 1, -1, pass);
        if (!pass && r.fail <= 3) std::printf("  P8 trial %d beat %u: FAIL:%s\n", t, beat, why.c_str());
        need_boot = (L.s.errors != 0);
    }
    r.note = "first beat " + std::to_string(firstb) + ", last beat " + std::to_string(lastb) + " trials; halted 0x208: " + std::to_string(r.halt_exp) +
             "; no result, no bucket AW/W for the access, order violations 0";
    rows.push_back(r); line(r);
    // on the HBM bucket port (on package, plaintext): expected NOT DETECTED in v14
    if (HBMK >= 2) {
        Row h{"In-flight corruption, on package", "HBM bucket read stream", "Debug"}; h.no_halt_expected = true; int nh = 0;
        for (int t = 0; t < cnt(50); t++, trial_id++) {
            if (!ensure_boot()) continue;
            const uint32_t k = rkey(), j = pick_on(); if (!steer(k, j)) { need_boot = true; continue; }
            FaultArgs fa; fa.ctl = F_P8 | F_P8_HBM; fa.cmd = 0; fa.p8 = (rnd(BKT_BEATS) << 8) | rnd(256);
            Launch L = launch({get_(k)}, fa); nh += (L.s.errors == 0); tally(h, L, L.s.errors == 0);
            need_boot = true;                                                  // the corrupted block may be read later: re-boot
        }
        h.note = "v14: on-package buckets carry no tag -> expected NOT DETECTED; no halt in " + std::to_string(nh) + " trials"; h.v14 = true;
        rows.push_back(h); line(h);
    }
}

// ================= PI: the faults with other commands in flight (overlap) =================
// The target GET is command `at` (1 .. 14) of a 16-command uniform launch, so up to three earlier commands are at DOMA
// with it. P1: its block steered to an off-package bucket j, j tampered in host memory (one bit). P3 / P8: the hook on
// command `at`. Expected: a tag halt (0x208) at bucket j; for P3 and P8 at command `at` (P1: at `at` or at an earlier
// command whose access also read j); every result returned is correct; the halting command has no result and its data
// slot is untouched; the halting access wrote nothing and released nothing; no order violation. What happens after the halt is not judged. Reported, not
// failed: earlier commands in flight that lost their results to the halt.
static void pinf() {
    std::printf("\nPI faults with other commands in flight: the target is command 1..14 of a 16-command launch\n");
    if (NB - std::max<uint32_t>(HBMK, 1) < 1) { std::printf("PI: needs an off-package bucket (DOMA_HBM_PCT)\n"); return; }
    const char* names[3] = {"P1 bit flip, in flight", "P3 tag/IV, in flight", "P8 beat, in flight"};
    for (int v = 0; v < 3; v++) {
        Row r{names[v], v == 0 ? "Host-memory bucket" : v == 1 ? "Bucket record (HBM)" : "Bucket read stream", v == 0 ? "Host" : "Debug"};
        std::map<int, int> lost; int earlier_halt = 0;
        for (int t = 0; t < cnt(200); t++, trial_id++) {
            need_boot = true; if (!ensure_boot()) { r.fail++; r.trials++; continue; }
            const uint32_t k = rkey(), j = pick_off();
            if (!steer(k, j)) { r.fail++; r.trials++; need_boot = true; continue; }
            auto c = uniform(fitn(16)); const uint32_t at = 1 + rnd(c.size() - 2); c[at] = get_(k);
            for (size_t i = 0; i < c.size(); i++) if (i != at && c[i].key == k) c[i].key = (k + 1) % NBLK;   // k only at `at`
            FaultArgs fa; std::string params = "bucket=" + std::to_string(j) + " at=" + std::to_string(at);
            if (v == 0) { const size_t bit = rnd(STRIDE * 8); auto x = snap(j); x[bit / 8] ^= uint8_t(1u << (bit % 8)); put_host(j, x);
                          params += " bit=" + std::to_string(bit); }
            if (v == 1) { fa.ctl = F_P3; fa.cmd = at; fa.p3 = rnd(224); params += " p3=" + std::to_string(fa.p3); }
            if (v == 2) { const uint32_t beat = (t % 4 == 0) ? 0 : (t % 4 == 1) ? BKT_BEATS - 1 : rnd(BKT_BEATS);
                          fa.ctl = F_P8; fa.cmd = at; fa.p8 = (beat << 8) | rnd(256); params += " beat=" + std::to_string(beat); }
            Launch L = launch(c, fa);
            std::string why;
            bool pass = clean_halt(L, 0x208, -1, j, &why);
            const int hacc = (L.o.valid && L.o.hacc != 0xFFFFFFFFu) ? int(L.o.hacc) : -1;
            if (v != 0 && hacc != int(at)) { pass = false; why += " halt at command " + std::to_string(hacc); }
            if (v == 0 && (hacc < 0 || hacc > int(at))) { pass = false; why += " halt at command " + std::to_string(hacc); }
            if (v == 0 && hacc >= 0 && hacc < int(at)) earlier_halt++;
            if (v == 1 && !(L.st.fired & 1)) { pass = false; why += " P3 did not fire"; }
            if (v == 2 && !(L.st.fired & 8)) { pass = false; why += " P8 did not fire"; }
            // results: a prefix of the commands, then only "halted" or no answer
            int first = int(c.size());
            for (size_t i = 0; i < L.h.size(); i++) if (!L.h[i].answered || L.h[i].status == 0x8 || L.h[i].status == 0x10) { first = int(i); break; }
            if (hacc >= 0 && first > hacc) { pass = false; why += " the halting command has a result"; }
            if (hacc >= 0 && first <= hacc) lost[hacc - first]++;
            settle();                                                     // (a pause before the next trial's re-boot)
            r.halt_exp += (L.s.errors == 0x208); tally(r, L, pass);
            csv("PI-" + std::to_string(v), params, int(at), L, L.canary_bad == 0, 1, -1, pass);
            if (!pass && r.fail <= 3) std::printf("  %s trial %d (%s): FAIL:%s\n", names[v], t, params.c_str(), why.c_str());
            need_boot = true;
        }
        std::string ls; for (auto& kv : lost) ls += " " + std::to_string(kv.first) + ":" + std::to_string(kv.second);
        r.note = "halted 0x208 at bucket j: " + std::to_string(r.halt_exp) + "; earlier commands that lost their results (count:trials):" + ls +
                 (v == 0 ? "; halt at an earlier command that also read j: " + std::to_string(earlier_halt) : "");
        rows.push_back(r); line(r);
    }
}

// ================= the results table =================
static void table() {
    std::printf("\n==== Fault-injection results (DOMA test plan Part B, section 6; build B = build A + test hooks and counters) ====\n");
    std::printf("n = %u blocks, Z = %u, lambda = %u, %u buckets (%u on package = %u%%), pool %u, seed %llu, scale %.3g\n",
                NBLK, ZPOS, LAMBDA, NB, HBMK, HBM_PCT, POOL_DEF, (unsigned long long)SEED, SCALE);
    std::printf("%-42s %-22s %-12s %6s %8s %9s %9s %9s %6s %6s\n", "Fault", "Injected where", "Mechanism", "Trials", "Halted",
                "Released", "Writes", "Partial", "Pass", "Fail");
    std::printf("%-42s %-22s %-12s %6s %8s %9s %9s %9s %6s %6s\n", "", "", "", "", "(exp.)", "after", "after", "bucket", "", "");
    int tf = 0;
    for (auto& r : rows) {
        char h[16]; if (r.v14) std::snprintf(h, 16, "v14:none"); else if (r.no_halt_expected) std::snprintf(h, 16, "exp.none"); else std::snprintf(h, 16, "%d", r.halt_exp);
        std::printf("%-42.42s %-22.22s %-12.12s %6d %8s %9d %9d %9d %6d %6d\n", r.fault.c_str(), r.where.c_str(), r.mech.c_str(), r.trials, h,
                    r.released, r.writes_after, r.partial, r.pass, r.fail);
        tf += r.fail;
    }
    std::printf("\nnotes:\n");
    for (auto& r : rows) if (!r.note.empty()) std::printf("  %s: %s\n", r.fault.c_str(), r.note.c_str());
    std::printf("(Halted: trials that halted with the expected cause; exp.none: no halt expected; v14:none: not detected by v14's design,\n"
                " Pass then counts trials that behaved as designed. Released / Writes after: trials with a result or a bucket AW/W after\n"
                " the halt. Partial: trials whose halting access wrote part of a bucket.)\n");
    std::printf("\n%s\n", tf ? "SOME TRIALS FAILED (see the lines above and the notes)"
                             : "ALL TRIALS PASSED (rows marked v14:none show v14's expected non-detection on package, see the notes)");
}

int main(int argc, char** argv) {
    if (argc < 2) { std::printf("usage: %s <xclbin> [P0,P1,P2,P3,P8,PI|all] [--scale F] [--seed S] [--csv] [--verbose]\n", argv[0]); return 1; }
    std::set<std::string> tests;
    for (int a = 2; a < argc; a++) {
        std::string o = argv[a];
        if (o == "--scale" && a + 1 < argc) SCALE = std::stod(argv[++a]);
        else if (o == "--seed" && a + 1 < argc) SEED = std::stoull(argv[++a]);
        else if (o == "--csv") CSV = true;
        else if (o == "--verbose") VERBOSE = true;
        else if (o[0] != '-') { size_t p = 0; while (p <= o.size()) { size_t q = o.find(',', p); if (q == std::string::npos) q = o.size();
                                    std::string t = o.substr(p, q - p); for (auto& ch : t) ch = char(std::toupper(ch)); if (!t.empty()) tests.insert(t); p = q + 1; } }
        else { std::printf("unknown argument %s\n", o.c_str()); return 1; }
    }
    if (tests.empty()) tests.insert("ALL");
    if (tests.count("ALL")) for (const char* t : {"P0", "P1", "P2", "P3", "P8", "PI"}) tests.insert(t);
    for (auto& t : tests) if (t != "ALL" && t != "P0" && t != "P1" && t != "P2" && t != "P3" && t != "P8" && t != "PI") {
        std::printf("test %s is not in this build (P0, P1, P2, P3, P8, PI)\n", t.c_str()); return 1; }
    rng.seed(SEED);
    if (const char* l = std::getenv("DOMA_LAMBDA")) LAMBDA = uint32_t(std::stoul(l));
    if (const char* e = std::getenv("DOMA_N")) NBLK = uint32_t(std::stoul(e));
    if (const char* e = std::getenv("DOMA_HBM_PCT")) HBM_PCT = unsigned(std::stoul(e));
    if (HBM_PCT > 100) { std::printf("DOMA_HBM_PCT must be 0..100\n"); return 1; }
    if (const char* e = std::getenv("DOMA_OV_K")) OV_K = uint32_t(std::atoi(e));
    if (OV_K != 0 && OV_K != 2 && OV_K != 3 && OV_K != 4) { std::printf("DOMA_OV_K must be 2, 3 or 4\n"); return 1; }
    NBLK = ((NBLK + LAMBDA - 1) / LAMBDA) * LAMBDA; NB = NBLK / LAMBDA; HBMK = uint32_t((uint64_t(NB) * HBM_PCT) / 100);
    POOL_DEF = uint32_t(std::min<double>(NBLK, std::ceil(stash_bound(double(NBLK), double(LAMBDA), int(ZPOS))) + 1));
    if (const char* e = std::getenv("DOMA_POOL")) POOL_DEF = uint32_t(std::min<unsigned long>(NBLK, std::stoul(e)));
    POOL_MAX = std::min<uint32_t>(NBLK, std::max<uint32_t>(POOL_DEF + 4096, 2 * POOL_DEF));
    refv.assign(NBLK, 0);
    std::printf("host_fault_ov: n = %u blocks (lambda %u, %u buckets, %u on package = %u%%), pool %u, seed %llu, scale %.3g\n",
                NBLK, LAMBDA, NB, HBMK, HBM_PCT, POOL_DEF, (unsigned long long)SEED, SCALE);

    xrt::device device(0); g_dev = &device;
    auto uuid = device.load_xclbin(argv[1]);
    xrt::kernel krnl(device, uuid, "doma_kernel"); g_k = &krnl;
    MAXC = 1000;
    b_cmd   = xrt::bo(device, roundup4k(MAXC * 32) + MAXC * BLOCK, krnl.group_id(0));
    b_resp  = xrt::bo(device, roundup4k((MAXC + 4) * 32) + MAXC * BLOCK, krnl.group_id(1));
    b_pages = xrt::bo(device, size_t(NB - HBMK) * STRIDE + 4096, xrt::bo::flags::host_only, krnl.group_id(2));
    b_meta  = xrt::bo(device, std::max<size_t>(4096, ((size_t(NBLK) + 4) / 5) * 32), krnl.group_id(4));
    b_brec  = xrt::bo(device, std::max<size_t>(4096, size_t(NB) * 64), krnl.group_id(5));
    b_stash = xrt::bo(device, roundup4k(size_t(NB) * 64) + roundup4k(size_t(POOL_MAX) * 16) + size_t(POOL_MAX) * BLOCK, krnl.group_id(6));
    b_hbm   = xrt::bo(device, std::max<size_t>(4096, size_t(HBMK) * STRIDE), krnl.group_id(8));
    cur_pool = POOL_DEF;

    // the first boot: this must be the overlap test build, 4 KB blocks, this lambda
    Launch L0 = launch({}, NOF, POOL_DEF);
    if (!L0.s.ok) { std::printf("no summary record: not a doma_kernel bitstream?\n"); return done_(1); }
    if (!(L0.s.dbg & 0x80)) { std::printf("this bitstream is not the overlap test build (summary byte 2 bit 7 clear): build it with build.sh OV_TRACE=1 OV_FAULT=1\n"); return done_(1); }
    if (L0.s.lam != LAMBDA) { std::printf("the bitstream's lambda is %u: set DOMA_LAMBDA=%u\n", L0.s.lam, L0.s.lam); return done_(1); }
    if (L0.s.beats != BEATS) { std::printf("the bitstream's block is %u bytes: host_fault_ov is for 4 KB blocks\n", L0.s.beats * 32); return done_(1); }
    if (L0.s.errors & 0x80) { std::printf("boot refused an argument (error 0x80): DOMA_OV_K on a bitstream without run-time K?\n"); return done_(1); }
    if (L0.s.errors) { std::printf("boot halted: errors 0x%x\n", L0.s.errors); print_halt_record("boot", L0.s.lat_min, L0.s.lat_max); return done_(1); }
    need_boot = false;
    std::printf("boot: %llu cycles (records [n+2], [n+3] present)\n", (unsigned long long)L0.s.total);
    csv_header();

    const std::pair<const char*, void (*)()> all[] = {{"P0", p0}, {"P1", p1}, {"P2", p2}, {"P3", p3}, {"P8", p8}, {"PI", pinf}};
    auto t0 = std::chrono::steady_clock::now();
    for (auto& t : all) if (tests.count(t.first)) {
        auto a = std::chrono::steady_clock::now(); t.second();
        std::printf("  (%s: %.1f s)\n", t.first, std::chrono::duration<double>(std::chrono::steady_clock::now() - a).count());
    }
    if (!rows.empty()) table();
    std::printf("total %.1f s\n", std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count());
    int f = 0; for (auto& r : rows) f += r.fail;
    return done_(f ? 1 : 0);
}
