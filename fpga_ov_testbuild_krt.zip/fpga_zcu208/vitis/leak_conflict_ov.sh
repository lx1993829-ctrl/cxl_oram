#!/bin/bash
# leak_conflict_ov.sh <bitstream.xclbin> <results folder> <records> -- the same-bucket conflict rate on the overlap test build
# (docs/ov_fault_build.md). Run it from vitis/, one record count at a time (the folder may be shared by the record counts):
#   DOMA_OVF=1 bash leak_conflict_ov.sh doma_hw.xclbin conflict 4096
# One phase per workload (uniform, one key, re-request, turns of 2 to 5 keys, scan), CMDS requests each (default 200,000, and
# 1,000,000 from 100,000 records). Writes <folder>/n<records>.json and a table; the CSV is deleted unless KEEP_CSV=1.
XC=$1; R=$2; N=$3; [ -n "$N" ] || { echo "usage: bash leak_conflict_ov.sh <xclbin> <results folder> <records>"; exit 2; }
exec 9> "$HOME/.u55c_card.lock"; flock -n 9 || { echo "another program is using the card ($HOME/.u55c_card.lock): wait for it to finish"; exit 2; }
[ "${DOMA_OV_K:-4}" = 4 ] || { echo "this test is for K = 4: DOMA_OV_K=$DOMA_OV_K is not supported"; exit 2; }
[ -e "$R/n$N.json" ] && { echo "$R/n$N.json exists: use a new results folder"; exit 2; }
mkdir -p "$R"; source /opt/xilinx/xrt/setup.sh > /dev/null; export DOMA_LAMBDA=7
C=200000; [ "$N" -ge 100000 ] && C=1000000; C=${CMDS:-$C}
PH=""; for k in uni fixed rereq ab t3 t4 t5 scan; do PH="$PH${PH:+,}$k:$C"; done
echo "== n = $N, $C requests per workload"
DOMA_N=$N DOMA_HBM_PCT=${HBM:-20} DOMA_LEAK_SEED=${LEAK_SEED:-12345} DOMA_LEAK_CSV="$R/n$N.csv" DOMA_PHASES=$PH ./host_leak_ov "$XC" "${LAUNCH:-65536}" > "$R/n$N.log" 2>&1
tail -1 "$R/n$N.log"
[ -s "$R/n$N.csv" ] || { echo "== INCOMPLETE: the host wrote no results, see $R/n$N.log"; exit 1; }
grep -q 'ALL PHASES COMPLETE' "$R/n$N.log" || echo "== NOTE: the run stopped early (see $R/n$N.log); these counts cover the phases completed"
python3 ../sim/card_conflict_ov.py count "$N" "$R/n$N.csv" "$R/n$N.json" | tee "$R/n$N.table" || exit 1
[ "${KEEP_CSV:-0}" = 1 ] || rm -f "$R/n$N.csv"
