# Option A + RAMA at every block size (2026-11-07)

`build.sh FIXWB=1 RAMA=1 BEATS=<1..128> LAMBDA=7 SCHED=arrival CFG=doma_big2m_rama.cfg NMAX=2097152`: the serial
baseline (v14d1 + Option A) with the stash on AMD's RAMA IP, at 32 B .. 4 KB. Before this change `RAMA=1` was 4 KB only.

## Budgets

| Block | AR_WB_H | AR_REL_H | AR_DONE_H | Option A start (WBF) | Source |
|---|---|---|---|---|---|
| 32 B | 644 | 659 | 667 | 607 | card-proven λ = 7 values, unchanged |
| 64 B | 640 | 663 | 677 | 603 | same |
| 128 B | 632 | 672 | 693 | 595 | same |
| 256 B | 616 | 690 | 724 | 579 | same |
| 512 B | 584 | 725 | 787 | 547 | same |
| 1 KB | 567 | 843 | 958 | 530 | same |
| 2 KB | 663 | 1208 | 1429 | 626 | same |
| 4 KB | 440 | 1669 | 2103 | 440 | card calibration with RAMA (2026-11-06) |

Off-package budgets are unchanged at every size: re-encryption, not the stash, sets them.

**Why only 4 KB gets lower budgets.** RAMA removes one thing: the single AXI ID kept in order across the stash's HBM
pseudo-channels. At 4 KB and 2M records a stash window spreads over several channels, and that ordering stalled the
window reads by up to about 750 cycles; RAMA removed it on the card (release gate 2,079 to 1,329). Paired simulation
runs (sim/cal_rama_sizes.sh PROF=rama / PROF=desa, identical except that ordering) reproduce it: 2,031 to 1,320, a
saving of 711, slightly under the card's 750. The method takes the card-calibrated 4 KB budgets exactly.

Below 4 KB the deadlines are set by a different worst case: a full stash window of dependent reads at 200 cycles each
(the cycle model of sim/worst_case.py part 4; AR_WB_H = max(derived, measured) + 74). RAMA does not make a single read
faster, so it does not shorten that bound. These sizes were built with the stash in one pseudo-channel, where the
ordering stall never occurred, so there is no measured stall to remove. A simulated "saving" there (the paired runs at
32 B give 1,213 against 294) would subtract a stall the card never had, so it is not used. The card-proven values stay.

**Option A's fixed start below 4 KB.** Option A issues the on-package write-back at exactly t_arr + WBF, every access.
At WBF = AR_WB_H the write would end 2 to 7 cycles before the release at 32 B .. 128 B, every access at that edge. The
start therefore splits AR_WB_H's 74-cycle margin: WBF = AR_WB_H - 37, 37 cycles over the derived worst decisions and
39 to 65 cycles before the release (write 8 x beats + 5 cycles). The release and end times are the card-proven ones,
so each size's visible times and cycles per command are those of the current baseline at that size.
`build.sh WBF=<cycles>` still overrides it (for example, if a card run halts on deadline (1), raise it towards AR_WB_H).

## Security

Nothing new is request-dependent: every budget and WBF is a build constant per block size; on-package write-back,
release and end are fixed offsets from the arrival in every run (sim/check_rama.py); a missed deadline is a fail-stop
halt, never a wrong answer or a moved time. Builds without RAMA preprocess to exactly the previous text (verilator -E
-P: 240 cases, 8 sizes x lambda 6 and 7 x serial / Option A / overlap phase 3 / debug / interim, 3 files).

## Regression

`sim/run_rama_sizes.sh` (docs/rama_sizes_regression_2026-11-07.txt): per size, Option A + RAMA at 4,096 records under
the RAMA-like stash (every read 200 cycles: the basis of the card-proven budgets; the card measured at most 191) and card-like host / bucket tails: GET/PUT mixes at 0, 20, 50
and 100% on package and one key repeated 600 times; every response correct, scoreboard 0 wrong, no halt; fixed offsets
per class; and a 600-cycle stash trips the budgets into a fail-stop halt with no wrong answer.
