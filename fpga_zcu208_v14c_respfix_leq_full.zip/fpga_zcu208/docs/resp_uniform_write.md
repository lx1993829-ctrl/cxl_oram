# The response-write leak and its fix (2026-11-07)

## The leak (card, p3rx300)
Under sustained load an all-PUT stream ran 2,079.6 device cycles per command against 1,624.9 for all GETs (n = 4,096,
20% on package); at n = 2,097,152 all PUTs ran 2,344. The kernel wrote a PUT's 128-beat response data slot (HBM[7])
with every byte strobe off (`m_axi_gmem1_wstrb`, "PUT: slot untouched"), a GET's with all strobes on. On the card the
zero-strobe write took about 2,200 cycles, a GET's 137 (a partial write; the memory system's handling of it, likely a
read-modify-write, is not documented to us). The completion side writes responses in order, the command queue holds
four commands, and slow writes delayed the issue side: rq(j) came late, and phase 3's start s(j) = max(s(j-1) + PMIN,
t'(j-4) + L, rq(j), ...) moved with it. The operation of earlier commands reached the visible bucket-port schedule.
The checks missed it because they take rq(j) as public and the memory model never slowed partial writes.

The serial kernel (every build without OVERLAP) has the same strobe rule: after each command it writes the data slot,
then the header, and only then fetches the next command, so a PUT's slow write delays the next access by about the
same 2,000 cycles. Its earlier card leak test compared latency, which starts at the command's issue and so excludes it.

## The fix (rtl/doma_kernel.v, every build)
- Every response beat is written with all strobes (`m_axi_gmem1_wstrb` all ones).
- A PUT's (any non-GET's) data slot is written with zeros; a GET's with its block, a dummy's with zeros, as before.
So every command writes the same 128 + 1 full beats; a write's time no longer depends on the operation.
A rejected or lease-violating PUT's slot is now zeros too (it was untouched). No host reads a PUT's slot: host_doma,
host_phases and host_ycsb check data for GETs only.

`TB_RESP_STRB_OLD` (test only; build.sh never sets it) restores the old write for the negative control; with it the
kernel preprocesses to exactly the pre-fix text (12 configurations).

## Simulation
- `sim/axi_mem_model.v pstrb_hold`, `tb_doma_kernel +resp_pstrb=H`: after a write beat with any strobe off, wready is
  low H cycles. 16 makes a zero-strobe 128-beat write take about 2,200 cycles, as on the card.
- `tb_doma_kernel`: an admitted PUT's slot must read zeros; a rejected command's slot must read zeros.
- `sim/run_resp_uniform.sh`: serial baseline (Option A + RAMA) and phase 3 (1,600, allowance 300), 4 KB, under
  +resp_pstrb=16: the same keys and arrivals at 0/50/100% PUTs give identical visible hashes and device cycles per
  command, every GET correct; the old write (negative control) shows the difference.

## On the card
Rebuild every design from this tree (the RTL changed for all builds). Then the acceptance test as specified
(`host_leak_ov ... DOMA_PHASES=get,put,zero,mix,fixed,rereq,scan,get`, `card_rate_check.py`: every phase within 0.2% of
GET, no response write over twice GET's longest), for the overlap build and, with host_phases get/put phases, for the
serial baseline. Throughput numbers measured before the fix (baseline and overlap) should be remeasured: the baseline's
PUTs carried the slow write, so its rate improves; the overlap's mixed rate was within 0.5% of all-GET.
