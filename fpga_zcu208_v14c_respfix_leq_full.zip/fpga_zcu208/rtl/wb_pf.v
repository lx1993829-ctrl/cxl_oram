`timescale 1ns / 1ps
// wb_pf.v -- overlap step 2: the write-back's scratch reads, prefetched (docs/overlap_rtl_spec.md section 16).
// The step 2 scratch buffers return read data two cycles after the read (block-RAM output registers, for 300 MHz),
// one cycle more than axi_master's write path is built for. wb_pf sits between them: it reads the bucket's beats in
// order, at most four ahead of the master, into a four-beat buffer, and answers the master exactly as a one-cycle
// scratch would: data for the beat the master reads in cycle X, valid in X + 1, once that beat is in the buffer (a
// master read of a beat not yet there gets no valid; the master then reads it again, as after a full slot).
// A beat is fetched only once its position may be written (pos_lim: the positions encrypted, or whose eviction copies
// have landed), the rule the master's own hold applies, so the prefetch never reads a beat the master may not take.
// Its schedule is a fixed function of the write's start and of pos_lim: two cycles more than a one-cycle scratch at
// the write's start, none after it.
`include "oram_params.vh"
module wb_pf #(
    parameter AXI_DW  = `AXI_DATA_W,
    parameter SAW     = `SCR_AW,                 // scratch beat address: {position, beat}
    parameter BEAT_AW = $clog2(`BEATS_PER_BLOCK),
    parameter POS_W   = `POS_IN_BKT_W,
    parameter TOTAL   = `BEATS_PER_BKT
)(
    input  wire              clk,
    input  wire              rst_n,
    input  wire              start,          // a write is issued (one cycle): the master starts at beat 0
    input  wire              active,         // a write (or the boot format's write) is streaming
    input  wire [3:0]        pos_lim,        // positions 0 .. pos_lim-1 may be read (>= Z: all)
    // the master (axi_master's write path, built for a one-cycle scratch)
    input  wire [SAW-1:0]    m_beat,         // the beat the master reads this cycle
    input  wire              m_rd,           // the master reads it this cycle
    output reg               m_valid,        // its data, the next cycle
    output wire [AXI_DW-1:0] m_data,
    output wire              m_have,         // the beat the master would read now is held (or lands now): it may read
    // the scratch (two-cycle read)
    output reg               s_rd,           // read beat s_beat (registered)
    output reg  [SAW-1:0]    s_beat,
    input  wire [AXI_DW-1:0] s_data          // the data of the read two cycles after s_rd
);
    reg  [SAW:0]       pf;                   // next beat to fetch
    reg  [AXI_DW-1:0]  bd [0:3];             // the buffer, by beat mod 4
    reg  [SAW-1:0]     bb [0:3];             // which beat each entry holds
    reg  [3:0]         bv;                   // entry holds its beat
    reg  [2:0]         pv;                   // reads in flight: issued 1, 2 and 3 cycles ago (s_rd, then the scratch)
    reg  [SAW-1:0]     pb [0:2];
    reg  [1:0]         mi;                   // the master's entry, for m_data
    reg                mst;                  // the master has started this write (its beat counter is this write's)
    // fetch at most three beats ahead of the master; until it starts (its counter may still hold the previous
    // write's last beat for a few cycles), beats 0 .. 3
    wire [SAW:0]       lim  = mst ? {1'b0, m_beat} + 3 : 3;
    wire               p_ok = ({1'b0, pf[BEAT_AW +: POS_W]} < {1'b0, pos_lim}) || (pos_lim > `ORAM_Z - 1);
    wire               go   = active && !start && (pf < TOTAL) && (pf <= lim) && p_ok;
    // the data arriving now (read three cycles ago: the request register, then the scratch's two)
    wire               a_v  = pv[2];
    wire [SAW-1:0]     a_b  = pb[2];
    wire [1:0]         mb   = m_beat[1:0];
    wire               have = (bv[mb] && bb[mb] == m_beat) || (a_v && a_b == m_beat);
    assign m_data = bd[mi];
    assign m_have = have;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pf <= 0; bv <= 4'b0; pv <= 3'b0; s_rd <= 1'b0; s_beat <= 0; m_valid <= 1'b0; mi <= 2'd0; mst <= 1'b0;
            pb[0] <= 0; pb[1] <= 0; pb[2] <= 0;
        end else begin
            // fetch
            s_rd <= go; s_beat <= pf[SAW-1:0];
            if (start) begin pf <= 0; bv <= 4'b0; mst <= 1'b0; end
            else if (m_rd && m_beat == 0) mst <= 1'b1;
            else if (go) pf <= pf + 1'b1;
            pv <= start ? 3'b0 : {pv[1:0], go};
            pb[0] <= pf[SAW-1:0]; pb[1] <= pb[0]; pb[2] <= pb[1];
            // land (a start drops nothing in flight: none is, the previous write has ended)
            if (a_v && !start) begin bd[a_b[1:0]] <= s_data; bb[a_b[1:0]] <= a_b; bv[a_b[1:0]] <= 1'b1; end
            // answer the master as a one-cycle scratch would
            m_valid <= m_rd && have && !start;
            mi <= mb;
        end
    end
`ifndef SYNTHESIS
    always @(posedge clk) if (rst_n && active && mst && m_rd && !start && !have && pf > {1'b0, m_beat} + 3)
        $display("[%0t] WB_PF: the master's beat %0d is behind the prefetch window (pf %0d)", $time, m_beat, pf);
`endif
endmodule
