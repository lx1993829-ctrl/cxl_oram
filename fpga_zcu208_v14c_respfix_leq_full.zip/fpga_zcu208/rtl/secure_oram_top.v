`timescale 1ns / 1ps
`include "oram_params.vh"

module secure_oram_top #(
    parameter UNIFORM_FILL = 0,   // 1: GETs take the write-data fill too (data ignored), so GET and PUT start alike
    parameter N            = `ORAM_N,
    parameter Z            = `ORAM_Z,
    parameter B            = `ORAM_B,
    parameter STASH_DEPTH  = `ORAM_STASH_DEPTH,
    parameter AXI_DW       = `AXI_DATA_W,
    parameter AXI_AW       = `AXI_ADDR_W,
    parameter AXI_SW       = `AXI_STRB_W,
    parameter AXI_IDW      = `AXI_ID_W,
    parameter AXI_LENW     = `AXI_LEN_W,
    parameter NUM_CLIENTS    = `ORAM_NUM_CLIENTS,
    parameter TDM_CID_W      = (NUM_CLIENTS > 1) ? $clog2(NUM_CLIENTS) : 1,
    parameter NUM_REGIONS    = 16,
    parameter TOKEN_WIDTH    = 32,
    parameter LEASE_ID_WIDTH = 8,
    parameter SLOT_AW        = `SLOT_ADDR_W
)(
    input  wire                 clk,
    input  wire                 rst_n,

    // Management Interface
    input  wire                                   mgmt_req,
    input  wire [2:0]                             mgmt_op,
    input  wire [LEASE_ID_WIDTH-1:0]              mgmt_lease_id,
    input  wire [TDM_CID_W-1:0]                   mgmt_client_id,
    input  wire [SLOT_AW-1:0]                     mgmt_base_addr,   // slot addresses (slot << 12)
    input  wire [SLOT_AW-1:0]                     mgmt_size,
    input  wire [31:0]                            mgmt_duration,
    input  wire [TOKEN_WIDTH-1:0]                 mgmt_token_in,
    output wire                                   mgmt_ack,
    output wire                                   mgmt_error,
    output wire [TOKEN_WIDTH-1:0]                 mgmt_token_out,
    output wire [NUM_CLIENTS*TOKEN_WIDTH-1:0]     client_token_out,   // client c's token on lane c only
    output wire [63:0]                            dbg_halt_info,      // the controller's halt record (flat_oram_gcm)

    // Client Interface (flattened)
    input  wire [NUM_CLIENTS-1:0]                     client_req,
    input  wire [NUM_CLIENTS-1:0]                     client_op,
    input  wire [NUM_CLIENTS*SLOT_AW-1:0]             client_slot_addr,
    input  wire [NUM_CLIENTS*AXI_DW-1:0]              client_wdata,
    input  wire [NUM_CLIENTS*AXI_DW/8-1:0]            client_wstrb,   // byte strobes per write beat (all ones = whole block)
    input  wire [NUM_CLIENTS-1:0]                     client_wdata_valid,
    input  wire [NUM_CLIENTS*TOKEN_WIDTH-1:0]         client_token,
    input  wire [NUM_CLIENTS*LEASE_ID_WIDTH-1:0]      client_lease_id,
    output wire [NUM_CLIENTS-1:0]                     client_done,
    output wire [NUM_CLIENTS*AXI_DW-1:0]              client_rdata,
    output wire [NUM_CLIENTS-1:0]                     client_rdata_valid,
    output wire [NUM_CLIENTS-1:0]                     access_violation,
    output wire [NUM_CLIENTS-1:0]     client_lockout,   // always 0 (the F10 lock-out was removed in v11a)
    input  wire                       key_load,         // F1: latch aes_key/aes_iv_seed (once per boot)
    output wire                       key_ready,        // F1: a key is loaded; accesses are accepted
    output wire                       err_ct_overrun,   // Phase 2: sticky timing-gate overrun (fail-stop)
    output wire                       oram_ready,       // Phase 2: key loaded and DDR formatted
    // Phase 3: static time-division arbiter. Configuration latched ONCE, on the
    // first cycle after reset (boot-time); slots start when oram_ready rises.
    input  wire [15:0]                cfg_tdm_slot_cycles, // access window length (0 = `ORAM_TDM_SLOT)
    output wire [NUM_CLIENTS*`BEAT_CNT_W-1:0] client_wbeat_req, // write beat each client should present
    output wire [NUM_CLIENTS-1:0]     client_ready,        // client may issue a request
    output wire                       err_slot_overrun,    // sticky: controller busy at a slot start
    output wire                       dbg_slot_start,      // debug builds only (0 otherwise)
    output wire [31:0]                dbg_real_cnt,

    // BRAM Init Interface
    input  wire                                       init_mode,
    input  wire [SLOT_AW-1:0]                         init_pm_wr_addr,
    input  wire [`BUCKET_ID_W-1:0]                    init_pm_wr_bucket,
    input  wire [1:0]                                 init_pm_wr_status,
    input  wire                                       init_pm_wr_en,
    input  wire [`BUCKET_ID_W-1:0]                    init_bm_wr_bucket,
    input  wire [Z*`SLOT_ID_W-1:0]                    init_bm_wr_slot_list,
    input  wire [`FILL_CNT_W-1:0]                     init_bm_wr_fill,
    input  wire                                       init_bm_wr_en,

    // AES-GCM Configuration
    input  wire [127:0]                               aes_key,
    input  wire [95:0]                                aes_iv_seed,
    input  wire [`SLOT_ID_W:0]                        cfg_n,            // run-time blocks (0: the build's maximum)
    input  wire [`BUCKET_ID_W:0]                      cfg_hbm_bkts,     // buckets 0 .. cfg_hbm_bkts-1 in HBM
    input  wire [`SLOT_ID_W:0]                        cfg_pool_n,       // stash pool entries (0: N)
`ifdef ORAM_OV4_P3
    input  wire [1:0]                                 cfg_ov_k,         // run-time in-flight cap, K mod 4 (0 = 4)
    input  wire [15:0]                                cfg_ov_leq,       // run-time same-bucket gap in cycles (0 = the build default)
`endif

    // AXI Master -> DDR
    output wire [AXI_IDW-1:0]   m_axi_arid,
    output wire [AXI_AW-1:0]    m_axi_araddr,
    output wire [AXI_LENW-1:0]  m_axi_arlen,
    output wire [2:0]            m_axi_arsize,
    output wire [1:0]            m_axi_arburst,
    output wire                  m_axi_arvalid,
    input  wire                  m_axi_arready,
    input  wire [AXI_IDW-1:0]   m_axi_rid,
    input  wire [AXI_DW-1:0]    m_axi_rdata,
    input  wire [1:0]            m_axi_rresp,
    input  wire                  m_axi_rlast,
    input  wire                  m_axi_rvalid,
    output wire                  m_axi_rready,
    output wire [AXI_IDW-1:0]   m_axi_awid,
    output wire [AXI_AW-1:0]    m_axi_awaddr,
    output wire [AXI_LENW-1:0]  m_axi_awlen,
    output wire [2:0]            m_axi_awsize,
    output wire [1:0]            m_axi_awburst,
    output wire                  m_axi_awvalid,
    input  wire                  m_axi_awready,
    output wire [AXI_DW-1:0]    m_axi_wdata,
    output wire [AXI_SW-1:0]    m_axi_wstrb,
    output wire                  m_axi_wlast,
    output wire                  m_axi_wvalid,
    input  wire                  m_axi_wready,
    input  wire [AXI_IDW-1:0]   m_axi_bid,
    input  wire [1:0]            m_axi_bresp,
    input  wire                  m_axi_bvalid,
    output wire                  m_axi_bready,
    // position map in HBM: addresses relative to the metadata buffer (the kernel adds its base)
    output wire [63:0]           m_meta_araddr,
    output wire [7:0]            m_meta_arlen,
    output wire [2:0]            m_meta_arsize,
    output wire [1:0]            m_meta_arburst,
    output wire                  m_meta_arvalid,
    input  wire                  m_meta_arready,
    input  wire [AXI_DW-1:0]     m_meta_rdata,
    input  wire                  m_meta_rlast,
    input  wire                  m_meta_rvalid,
    output wire                  m_meta_rready,
    output wire [63:0]           m_meta_awaddr,
    output wire [7:0]            m_meta_awlen,
    output wire [2:0]            m_meta_awsize,
    output wire [1:0]            m_meta_awburst,
    output wire                  m_meta_awvalid,
    input  wire                  m_meta_awready,
    output wire [AXI_DW-1:0]     m_meta_wdata,
    output wire [AXI_DW/8-1:0]   m_meta_wstrb,
    output wire                  m_meta_wlast,
    output wire                  m_meta_wvalid,
    input  wire                  m_meta_wready,
    input  wire                  m_meta_bvalid,
    output wire                  m_meta_bready,
    // bucket records in HBM (metadata + IV/tag), addresses relative to their buffer
    output wire [63:0]                 m_brec_araddr,
    output wire [7:0]                  m_brec_arlen,
    output wire [2:0]                  m_brec_arsize,
    output wire [1:0]                  m_brec_arburst,
    output wire                        m_brec_arvalid,
    input  wire                        m_brec_arready,
    input  wire [AXI_DW-1:0]           m_brec_rdata,
    input  wire                        m_brec_rlast,
    input  wire                        m_brec_rvalid,
    output wire                        m_brec_rready,
    output wire [63:0]                 m_brec_awaddr,
    output wire [7:0]                  m_brec_awlen,
    output wire [2:0]                  m_brec_awsize,
    output wire [1:0]                  m_brec_awburst,
    output wire                        m_brec_awvalid,
    input  wire                        m_brec_awready,
    output wire [AXI_DW-1:0]           m_brec_wdata,
    output wire [AXI_DW/8-1:0]         m_brec_wstrb,
    output wire                        m_brec_wlast,
    output wire                        m_brec_wvalid,
    input  wire                        m_brec_wready,
    input  wire                        m_brec_bvalid,
    output wire                        m_brec_bready,
`ifdef ORAM_STASH_PC_IDS
    output wire [1:0]             m_stash_arid,      // v14d design B: the read's pseudo-channel (ID)
    input  wire [1:0]             m_stash_rid,
`endif
    output wire [63:0]                 m_stash_araddr,
    output wire [7:0]                  m_stash_arlen,
    output wire [2:0]                  m_stash_arsize,
    output wire [1:0]                  m_stash_arburst,
    output wire                        m_stash_arvalid,
    input  wire                        m_stash_arready,
    input  wire [AXI_DW-1:0]           m_stash_rdata,
    input  wire                        m_stash_rlast,
    input  wire                        m_stash_rvalid,
    output wire                        m_stash_rready,
    output wire [63:0]                 m_stash_awaddr,
    output wire [7:0]                  m_stash_awlen,
    output wire [2:0]                  m_stash_awsize,
    output wire [1:0]                  m_stash_awburst,
    output wire                        m_stash_awvalid,
    input  wire                        m_stash_awready,
    output wire [AXI_DW-1:0]           m_stash_wdata,
    output wire [AXI_DW/8-1:0]         m_stash_wstrb,
    output wire                        m_stash_wlast,
    output wire                        m_stash_wvalid,
    input  wire                        m_stash_wready,
    input  wire                        m_stash_bvalid,
    output wire                        m_stash_bready,
    output wire [4:0] dbg_oram_state,
    // Status
    output wire                  oram_busy,
    output wire                  err_stash_overflow,
    output wire                  err_bucket_overflow,
    output wire                  err_tag_mismatch,
    output wire [`BEAT_CNT_W-1:0]  oram_beat_cnt,
    output wire dbg_gcm_tag_match,
    output wire dbg_gcm_tag_valid,

    // Test controls
    input  wire dbg_force_same_bucket,
    input  wire [`BUCKET_ID_W-1:0] dbg_prng_override,
    input  wire perf_reset,

    // Performance counters - 4-way: rb=read/bucket, rs=read/stash, wb=write/bucket, ws=write/stash
    output wire [31:0] perf_rb_ddr_rd, perf_rb_decrypt, perf_rb_encrypt,
    output wire [31:0] perf_rb_compact, perf_rb_evict, perf_rb_ddr_wr,
    output wire [31:0] perf_rb_scan, perf_rb_stash,
    output wire [31:0] perf_rb_total, perf_rb_ops,
    output wire [31:0] perf_rs_ddr_rd, perf_rs_decrypt, perf_rs_encrypt,
    output wire [31:0] perf_rs_compact, perf_rs_evict, perf_rs_ddr_wr,
    output wire [31:0] perf_rs_scan, perf_rs_stash,
    output wire [31:0] perf_rs_total, perf_rs_ops,
    output wire [31:0] perf_wb_ddr_rd, perf_wb_decrypt, perf_wb_encrypt,
    output wire [31:0] perf_wb_compact, perf_wb_evict, perf_wb_ddr_wr,
    output wire [31:0] perf_wb_scan, perf_wb_stash,
    output wire [31:0] perf_wb_total, perf_wb_ops,
    output wire [31:0] perf_ws_ddr_rd, perf_ws_decrypt, perf_ws_encrypt,
    output wire [31:0] perf_ws_compact, perf_ws_evict, perf_ws_ddr_wr,
`ifdef ORAM_PHASE_TRACE
    output wire [10:0] phase_ent,           // build option: the core's phase-entry pulses
`endif
`ifdef ORAM_ONPKG_DEBUG
    output wire [255:0] dbg_acc_rec,        // v14b debug build: the core's per-access record and overrun records
    output wire [767:0] dbg_ov_rec,
    output wire [255:0] dbg_st_rec,         // v14c: the access's stash open
`endif
    output wire [31:0] perf_ws_scan, perf_ws_stash,
    output wire [31:0] perf_ws_total, perf_ws_ops
);

    // =========================================================================
    // Gate Keeper: lease token validation
    // =========================================================================
    // ---- F1: per-boot key provisioning --------------------------------------
    // The AES key and IV seed are latched ONCE per boot when key_load is pulsed,
    // and no access is accepted before that. They must be fresh per boot (from
    // the PS / a secure key store): the GCM engine derives every IV from the
    // seed, so a fixed key + fixed seed replays the same IV sequence each boot
    // (GCM nonce reuse). An all-zero key is refused.
    reg  [127:0] key_q;
    reg  [95:0]  seed_q;
    reg          key_ready_r;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            key_q <= 128'd0; seed_q <= 96'd0; key_ready_r <= 1'b0;
        end else if (key_load && !key_ready_r && aes_key != 128'd0) begin
            key_q <= aes_key; seed_q <= aes_iv_seed; key_ready_r <= 1'b1;
        end
    end
    assign key_ready = key_ready_r;
    // ---- F11: debug / performance ports only in debug builds -----------------
`ifdef ORAM_DEBUG_PORTS
    localparam DBG_EN = 1'b1;
`else
    localparam DBG_EN = 1'b0;   // secure build: counters/state read 0, overrides ignored
`endif
    wire                    dbg_force_sb_i = DBG_EN ? dbg_force_same_bucket : 1'b0;
    // the controller owns the (random) layout; external PM/BM init only in debug builds
    wire                    init_mode_i    = DBG_EN ? init_mode : 1'b0;
    wire [`BUCKET_ID_W-1:0] dbg_prng_ovr_i = DBG_EN ? dbg_prng_override : {`BUCKET_ID_W{1'b0}};
    wire [NUM_CLIENTS-1:0] val_valid_raw;
    // Hardware partition check, independent of the host-requested leases: client c may
    // only address slots inside the ORAM (below N) and in its own partition c. Without it,
    // a host that over-grants a lease could let one client reach another client's ORAM,
    // or alias slot numbers past N onto another client's slots.
    wire [NUM_CLIENTS-1:0] part_ok;
    genvar pg;
    generate
        for (pg = 0; pg < NUM_CLIENTS; pg = pg + 1) begin : g_part
            wire [SLOT_AW-1:0] pa = client_slot_addr[pg*SLOT_AW +: SLOT_AW];
                        if (`ORAM_PART_W > 0) begin : g_parts
                assign part_ok[pg] = ((pa >> (`SLOT_ID_W + 12)) == 0) &&
                                     ((pa >> (`SLOT_ID_W + 12 - `ORAM_PART_W)) == pg);
            end else begin : g_one
                assign part_ok[pg] = ((pa >> (`SLOT_ID_W + 12)) == 0);   // inside the ORAM
            end
        end
    endgenerate
    wire [NUM_CLIENTS-1:0] val_ok = val_valid_raw & part_ok;
`ifndef SYNTHESIS
    initial if (NUM_CLIENTS != (1 << `ORAM_PART_W)) begin
        $display("ERROR: NUM_CLIENTS (%0d) must equal the number of ORAM partitions (%0d)", NUM_CLIENTS, 1 << `ORAM_PART_W);
        $finish;
    end
`endif
    wire [NUM_CLIENTS-1:0] val_valid;

    lease_token_table #(
        .ADDR_WIDTH(SLOT_AW),                       // leases cover slot addresses (34 bits at 2^22 slots)
        .NUM_CLIENTS(NUM_CLIENTS),
        .NUM_REGIONS(NUM_REGIONS),
        .LEASE_ID_WIDTH(LEASE_ID_WIDTH),
        .TOKEN_WIDTH(TOKEN_WIDTH)
    ) u_lease_table (
        .clk(clk), .rst_n(rst_n),
        .mgmt_req(mgmt_req), .mgmt_op(mgmt_op),
        .mgmt_lease_id(mgmt_lease_id), .mgmt_client_id(mgmt_client_id),
        .mgmt_base_addr(mgmt_base_addr), .mgmt_size(mgmt_size),
        .mgmt_duration(mgmt_duration), .mgmt_token_in(mgmt_token_in),
        .mgmt_ack(mgmt_ack), .mgmt_error(mgmt_error),
        .mgmt_token_out(mgmt_token_out), .client_token_out(client_token_out),
        .client_addr(client_slot_addr),
        .client_token(client_token),
        .client_lease_id(client_lease_id),
        .val_valid(val_valid_raw),
        .active_leases()
    );

    // ---- No lock-out (v11a): the F10 lock-out after repeated violations is removed. Every rejected request is
    // served as a dummy (below), each time; client_lockout stays 0 (the port is kept for the instantiations).
    assign val_valid      = val_ok;
    assign client_lockout = {NUM_CLIENTS{1'b0}};
    wire [NUM_CLIENTS-1:0] gated_req = client_req & val_valid & {NUM_CLIENTS{key_ready_r}};
    assign access_violation = client_req & ~val_valid;

    // =========================================================================
    // Simple Priority Arbiter
    // =========================================================================

    wire       oram_client_done;
    wire [AXI_DW-1:0] oram_client_rdata;
    wire       oram_client_rdata_valid;
    wire       oram_client_stall;

    // Access windows (one client, on demand). Once oram_ready (key loaded, memory
    // formatted, layout done), a window starts when the client has a complete,
    // lease-validated request buffered (for a write, all of its data), and every
    // window lasts the fixed length, so a result returns a fixed time after its
    // request. Results are pushed without backpressure. Lease-failed requests are
    // dropped at intake.
        localparam integer TDM_BEATS = `BEATS_PER_BLOCK;
    localparam [1:0] C_IDLE = 2'd0, C_FILL = 2'd1, C_READY = 2'd2, C_BUSY = 2'd3;
    reg                    tdm_cfg_latched, tdm_run;
    reg  [15:0]            tdm_t;
    reg  [15:0]            slot_cnt;
    reg                    oram_req_r, grant_real;
    reg  [TDM_CID_W-1:0]   grant_id;
    reg                    err_slot_overrun_r;
    reg                    ar_fin;          // arrival-relative: the window's access has finished
    reg  [31:0]            real_cnt;
    reg  [1:0]             cst   [0:NUM_CLIENTS-1];
    reg                    cop   [0:NUM_CLIENTS-1];
    reg  [SLOT_AW-1:0]     caddr [0:NUM_CLIENTS-1];
    // A request that violates its client's lease is not dropped: it is served as a dummy access, a GET of
    // slot 0 below the lease check, with its write beats taken as the request's would be and its returned
    // data zeroed. Its window, timing and bucket traffic are those of any access, so a rejection is not
    // visible on the memory bus or in when the result returns. access_violation still flags it.
    reg  [NUM_CLIENTS-1:0] cdmy;
    reg  [`BEAT_CNT_W-1:0] cfill [0:NUM_CLIENTS-1];
    integer                tc, tj;
    wire [`BEAT_CNT_W-1:0] ctrl_beat_req;        // controller's write-beat request
`ifdef ORAM_OVERLAP2
    // ---- overlap step 1: two request buffers, one per access parity (one client) ----
    // The client fills buffer in_p (request, then its data slot); a full buffer is presented to the controller,
    // in order, and held until the controller takes it (oc_acc: the access's start). The controller reads a PUT's
    // data from the buffer of the access it is deciding (oc_wsel) and the result belongs to the access its tail
    // streams (oc_rsel). A buffer is free again when its access is done. Each buffer is today's template.
`ifdef ORAM_OVERLAP4
    // ---- overlap step 2: four request buffers (access number mod 4), in order ----
    wire                   oc_acc; wire [1:0] oc_wsel, oc_rsel;
    reg  [1:0]             ost  [0:3];
    reg                    oop  [0:3];
    reg                    odmy [0:3];
    reg  [SLOT_AW-1:0]     oaddr [0:3];
    reg  [`BEAT_CNT_W-1:0] ofill [0:3];
    reg  [1:0]             in_p, iss_p, dn_p;
    wire                   o_fill_we = (ost[in_p] == C_FILL) && client_wdata_valid[0];
    wire [AXI_DW-1:0]      obuf_rd [0:3];
    wire [AXI_DW/8-1:0]    osb_rd  [0:3];
    // a filling beat is written one cycle after it arrives (300 MHz: the kernel's beat comes straight from the
    // platform's read channel); the controller reads a buffer only once its request is taken, much later
    reg                    of_we_q; reg [1:0] of_p_q; reg [`BEAT_CNT_W-1:0] of_a_q;
    reg  [AXI_DW-1:0]      of_d_q;  reg [AXI_DW/8-1:0] of_s_q;
    always @(posedge clk) begin
        of_we_q <= o_fill_we && rst_n; of_p_q <= in_p; of_a_q <= ofill[in_p];
        of_d_q  <= client_wdata[AXI_DW-1:0]; of_s_q <= client_wstrb[AXI_DW/8-1:0];
    end
    genvar gob;
    generate for (gob = 0; gob < 4; gob = gob + 1) begin : g_obuf     // each one today's template
        reg [AXI_DW-1:0]   mem  [0:TDM_BEATS-1];
        reg [AXI_DW/8-1:0] smem [0:TDM_BEATS-1];
        always @(posedge clk) if (of_we_q && of_p_q == gob) begin
            mem[of_a_q & (TDM_BEATS - 1)] <= of_d_q; smem[of_a_q & (TDM_BEATS - 1)] <= of_s_q;
        end
        assign obuf_rd[gob] = mem[ctrl_beat_req & (TDM_BEATS - 1)];
        assign osb_rd[gob]  = smem[ctrl_beat_req & (TDM_BEATS - 1)];
    end endgenerate
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin : o_rst
            integer q;
            for (q = 0; q < 4; q = q + 1) begin ost[q] <= C_IDLE; oop[q] <= 1'b0; odmy[q] <= 1'b0; oaddr[q] <= {SLOT_AW{1'b0}}; ofill[q] <= 0; end
            in_p <= 2'd0; iss_p <= 2'd0; dn_p <= 2'd0;
        end else begin
            case (ost[in_p])                                        // intake into buffer in_p
                C_IDLE: if (client_req[0] && key_ready_r) begin
                    oop[in_p]   <= client_op[0] && val_valid[0];
                    oaddr[in_p] <= val_valid[0] ? client_slot_addr[SLOT_AW-1:0] : {SLOT_AW{1'b0}};
                    odmy[in_p]  <= !val_valid[0];
                    ofill[in_p] <= 0;
                    if (client_op[0] || UNIFORM_FILL) ost[in_p] <= C_FILL;
                    else begin ost[in_p] <= C_READY; in_p <= in_p + 2'd1; end
                end
                C_FILL: if (client_wdata_valid[0]) begin
                    ofill[in_p] <= ofill[in_p] + 1'b1;
                    if (ofill[in_p] == TDM_BEATS - 1) begin ost[in_p] <= C_READY; in_p <= in_p + 2'd1; end
                end
                default: ;
            endcase
            if (oc_acc) begin ost[iss_p] <= C_BUSY; iss_p <= iss_p + 2'd1; end
            if (oram_client_done) begin ost[dn_p] <= C_IDLE; dn_p <= dn_p + 2'd1; end
        end
    end
`else
    wire                   oc_acc, oc_wsel, oc_rsel;
    reg  [1:0]             ost  [0:1];
    reg                    oop  [0:1];
    reg                    odmy [0:1];
    reg  [SLOT_AW-1:0]     oaddr [0:1];
    reg  [`BEAT_CNT_W-1:0] ofill [0:1];
    reg                    in_p, iss_p, dn_p;
    reg  [AXI_DW-1:0]      obuf0 [0:TDM_BEATS-1];
    reg  [AXI_DW-1:0]      obuf1 [0:TDM_BEATS-1];
    reg  [AXI_DW/8-1:0]    osb0  [0:TDM_BEATS-1];
    reg  [AXI_DW/8-1:0]    osb1  [0:TDM_BEATS-1];
    wire                   o_fill_we = (ost[in_p] == C_FILL) && client_wdata_valid[0];
    always @(posedge clk) if (o_fill_we && !in_p) begin
        obuf0[ofill[0] & (TDM_BEATS - 1)] <= client_wdata[AXI_DW-1:0]; osb0[ofill[0] & (TDM_BEATS - 1)] <= client_wstrb[AXI_DW/8-1:0];
    end
    always @(posedge clk) if (o_fill_we && in_p) begin
        obuf1[ofill[1] & (TDM_BEATS - 1)] <= client_wdata[AXI_DW-1:0]; osb1[ofill[1] & (TDM_BEATS - 1)] <= client_wstrb[AXI_DW/8-1:0];
    end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            ost[0] <= C_IDLE; ost[1] <= C_IDLE; oop[0] <= 1'b0; oop[1] <= 1'b0; odmy[0] <= 1'b0; odmy[1] <= 1'b0;
            oaddr[0] <= {SLOT_AW{1'b0}}; oaddr[1] <= {SLOT_AW{1'b0}}; ofill[0] <= 0; ofill[1] <= 0;
            in_p <= 1'b0; iss_p <= 1'b0; dn_p <= 1'b0;
        end else begin
            case (ost[in_p])                                        // intake into buffer in_p
                C_IDLE: if (client_req[0] && key_ready_r) begin
                    oop[in_p]   <= client_op[0] && val_valid[0];
                    oaddr[in_p] <= val_valid[0] ? client_slot_addr[SLOT_AW-1:0] : {SLOT_AW{1'b0}};
                    odmy[in_p]  <= !val_valid[0];
                    ofill[in_p] <= 0;
                    if (client_op[0] || UNIFORM_FILL) ost[in_p] <= C_FILL;
                    else begin ost[in_p] <= C_READY; in_p <= ~in_p; end
                end
                C_FILL: if (client_wdata_valid[0]) begin
                    ofill[in_p] <= ofill[in_p] + 1'b1;
                    if (ofill[in_p] == TDM_BEATS - 1) begin ost[in_p] <= C_READY; in_p <= ~in_p; end
                end
                default: ;
            endcase
            if (oc_acc) begin ost[iss_p] <= C_BUSY; iss_p <= ~iss_p; end     // the controller took it
            if (oram_client_done) begin ost[dn_p] <= C_IDLE; dn_p <= ~dn_p; end   // its access is done
        end
    end
`endif
`endif
    wire [AXI_DW-1:0]      wbuf_rd [0:NUM_CLIENTS-1];
    wire [AXI_DW/8-1:0]    sbuf_rd [0:NUM_CLIENTS-1];
    genvar gw;
    generate
        for (gw = 0; gw < NUM_CLIENTS; gw = gw + 1) begin : gen_wbuf
            // per-client 4 KB write buffer, own write port (clients fill independently)
            reg [AXI_DW-1:0]   mem  [0:TDM_BEATS-1];
            reg [AXI_DW/8-1:0] smem [0:TDM_BEATS-1];   // the beat's byte strobes
            always @(posedge clk)
                if (cst[gw] == C_FILL && client_wdata_valid[gw]) begin
                    // beat within the block, masked (a fixed [6:0] slice overran narrow counters)
                    mem[cfill[gw] & (TDM_BEATS - 1)]  <= client_wdata[gw*AXI_DW +: AXI_DW];
                    smem[cfill[gw] & (TDM_BEATS - 1)] <= client_wstrb[gw*AXI_DW/8 +: AXI_DW/8];
                end
            assign wbuf_rd[gw] = mem[ctrl_beat_req & (TDM_BEATS - 1)];
            assign sbuf_rd[gw] = smem[ctrl_beat_req & (TDM_BEATS - 1)];
        end
    endgenerate
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tdm_cfg_latched <= 1'b0; tdm_run <= 1'b0;
            tdm_t <= 16'd0; slot_cnt <= 16'd0;
            oram_req_r <= 1'b0; grant_real <= 1'b0;
            grant_id <= {TDM_CID_W{1'b0}};
            err_slot_overrun_r <= 1'b0; real_cnt <= 32'd0; ar_fin <= 1'b0;
            for (tc = 0; tc < NUM_CLIENTS; tc = tc + 1) begin
                cst[tc] <= C_IDLE; cop[tc] <= 1'b0; cdmy[tc] <= 1'b0;
                caddr[tc] <= {SLOT_AW{1'b0}}; cfill[tc] <= {`BEAT_CNT_W{1'b0}};
            end
        end else begin
            oram_req_r <= 1'b0;
            if (!tdm_cfg_latched) begin                 // boot-time configuration, once
                tdm_cfg_latched <= 1'b1;
                tdm_t  <= (cfg_tdm_slot_cycles == 16'd0) ? `ORAM_TDM_SLOT : cfg_tdm_slot_cycles;
            end
            if (tdm_cfg_latched && oram_ready) tdm_run <= 1'b1;   // never stops once started
            for (tc = 0; tc < NUM_CLIENTS; tc = tc + 1) begin     // per-client intake
                case (cst[tc])
                    C_IDLE: if (client_req[tc] && key_ready_r) begin     // admitted, or a dummy (cdmy, see above)
                        cop[tc]   <= client_op[tc] && val_valid[tc];
                        caddr[tc] <= val_valid[tc] ? client_slot_addr[tc*SLOT_AW +: SLOT_AW] : {SLOT_AW{1'b0}};
                        cdmy[tc]  <= !val_valid[tc];
                        cfill[tc] <= {`BEAT_CNT_W{1'b0}};
                        cst[tc]   <= (client_op[tc] || UNIFORM_FILL) ? C_FILL : C_READY;
                    end
                    C_FILL: if (client_wdata_valid[tc]) begin
                        cfill[tc] <= cfill[tc] + 1'b1;
                        if (cfill[tc] == TDM_BEATS - 1) cst[tc] <= C_READY;
                    end
                    C_BUSY: if (oram_client_done && grant_real && grant_id == tc[TDM_CID_W-1:0])
                        cst[tc] <= C_IDLE;
                    default: ;
                endcase
            end
            // One client, on demand: a window starts only when the client's request is ready
            // (write data fully buffered), and lasts the fixed window length, so the result
            // returns at a fixed time after the request. Every access is the client's own:
            // there is no schedule and no dummy access.
`ifdef ORAM_SCHED_ARRIVAL
            // Arrival-relative scheduling: a window lasts until its access has finished (completion follows the
            // visible bucket arrival by fixed hidden work, then the fixed result delivery) and the controller is
            // idle again; the next access may start right after. No fixed length: a slow off-package read
            // stretches the window instead of tripping the overrun check (the counter saturates).
            if (oram_client_done && grant_real) ar_fin <= 1'b1;
            if (tdm_run && !(slot_cnt == 16'd0 && cst[0] != C_READY)) begin
                if (slot_cnt != 16'd0)
                    slot_cnt <= (ar_fin && !oram_client_stall) ? 16'd0 : ((slot_cnt == 16'hFFFF) ? slot_cnt : slot_cnt + 16'd1);
                else slot_cnt <= 16'd1;
                if (slot_cnt == 16'd0) begin
                    ar_fin <= 1'b0;
`else
            if (tdm_run && !(slot_cnt == 16'd0 && cst[0] != C_READY)) begin
                slot_cnt <= (slot_cnt == tdm_t - 16'd1) ? 16'd0 : slot_cnt + 16'd1;
                if (slot_cnt == 16'd0) begin
`endif
                    if (oram_client_stall) begin
                        err_slot_overrun_r <= 1'b1;      // previous access still running
                    end else begin
                        oram_req_r <= 1'b1;
                        grant_real <= 1'b1;
                        grant_id   <= {TDM_CID_W{1'b0}};
                        cst[0]     <= C_BUSY;
                        real_cnt   <= real_cnt + 32'd1;
                    end
                end
            end
        end
    end
`ifdef ORAM_OVERLAP2
    wire               oram_req   = tdm_run && (ost[iss_p] == C_READY);   // held until taken
    wire               oram_op    = oop[iss_p];
    wire [SLOT_AW-1:0] oram_addr  = oaddr[iss_p];
`ifdef ORAM_OVERLAP4
    wire [AXI_DW-1:0]  oram_wdata = obuf_rd[oc_wsel];
    wire [AXI_DW/8-1:0] oram_wstrb = osb_rd[oc_wsel];
    reg                oram_wdata_valid_q;              // the access's PUT flag, a register (its data is read much later)
    always @(posedge clk) oram_wdata_valid_q <= oop[oc_wsel];
`else
    wire [AXI_DW-1:0]  oram_wdata = oc_wsel ? obuf1[ctrl_beat_req & (TDM_BEATS - 1)] : obuf0[ctrl_beat_req & (TDM_BEATS - 1)];
    wire [AXI_DW/8-1:0] oram_wstrb = oc_wsel ? osb1[ctrl_beat_req & (TDM_BEATS - 1)] : osb0[ctrl_beat_req & (TDM_BEATS - 1)];
`endif
`ifdef ORAM_OVERLAP4
    wire               oram_wdata_valid = oram_wdata_valid_q;
`else
    wire               oram_wdata_valid = oop[oc_wsel];
`endif
`else
    wire               oram_req   = oram_req_r;
    wire               oram_op    = grant_real ? cop[grant_id] : 1'b1;
    wire [SLOT_AW-1:0] oram_addr  = caddr[grant_id];
    wire [AXI_DW-1:0]  oram_wdata = wbuf_rd[grant_id];
    wire [AXI_DW/8-1:0] oram_wstrb = sbuf_rd[grant_id];
    wire               oram_wdata_valid = grant_real && cop[grant_id];
`endif
    // write beat each client should present; oram_beat_cnt keeps the old single-
    // client meaning (the beat the filling client should present)
    reg  [`BEAT_CNT_W-1:0] fill_beat_any;
    always @(*) begin
        fill_beat_any = {`BEAT_CNT_W{1'b0}};
        for (tj = 0; tj < NUM_CLIENTS; tj = tj + 1)
            if (cst[tj] == C_FILL) fill_beat_any = cfill[tj];
    end
`ifdef ORAM_OVERLAP2
    assign oram_beat_cnt = ofill[in_p];
`else
    assign oram_beat_cnt = fill_beat_any;
`endif
    genvar wi;
    generate
        for (wi = 0; wi < NUM_CLIENTS; wi = wi + 1) begin : gen_tdm_out
`ifdef ORAM_OVERLAP2
            assign client_wbeat_req[wi*`BEAT_CNT_W +: `BEAT_CNT_W] = ofill[in_p];
            assign client_ready[wi] = (ost[in_p] == C_IDLE);
`else
            assign client_wbeat_req[wi*`BEAT_CNT_W +: `BEAT_CNT_W] = cfill[wi];
            assign client_ready[wi] = (cst[wi] == C_IDLE);
`endif
        end
    endgenerate
`ifdef ORAM_OVERLAP2
    assign err_slot_overrun = 1'b0;            // the window logic is unused: the controller's start rule spaces accesses
    generate if (NUM_CLIENTS != 1) begin : overlap_one_client
        ORAM_OVERLAP2_supports_one_client_only u_no_ov ();
    end endgenerate
`else
    assign err_slot_overrun = err_slot_overrun_r;
`endif
    assign dbg_slot_start   = DBG_EN ? oram_req_r : 1'b0;
    assign dbg_real_cnt     = DBG_EN ? real_cnt   : 32'd0;
    
    // =========================================================================
    // ORAM with AES-GCM
    // =========================================================================
    // F11: internal debug/perf nets, exported only when DBG_EN
    wire [31:0] perf_rb_compact_i;
    wire [31:0] perf_rb_ddr_rd_i;
    wire [31:0] perf_rb_ddr_wr_i;
    wire [31:0] perf_rb_decrypt_i;
    wire [31:0] perf_rb_encrypt_i;
    wire [31:0] perf_rb_evict_i;
    wire [31:0] perf_rb_ops_i;
    wire [31:0] perf_rb_scan_i;
    wire [31:0] perf_rb_stash_i;
    wire [31:0] perf_rb_total_i;
    wire [31:0] perf_rs_compact_i;
    wire [31:0] perf_rs_ddr_rd_i;
    wire [31:0] perf_rs_ddr_wr_i;
    wire [31:0] perf_rs_decrypt_i;
    wire [31:0] perf_rs_encrypt_i;
    wire [31:0] perf_rs_evict_i;
    wire [31:0] perf_rs_ops_i;
    wire [31:0] perf_rs_scan_i;
    wire [31:0] perf_rs_stash_i;
    wire [31:0] perf_rs_total_i;
    wire [31:0] perf_wb_compact_i;
    wire [31:0] perf_wb_ddr_rd_i;
    wire [31:0] perf_wb_ddr_wr_i;
    wire [31:0] perf_wb_decrypt_i;
    wire [31:0] perf_wb_encrypt_i;
    wire [31:0] perf_wb_evict_i;
    wire [31:0] perf_wb_ops_i;
    wire [31:0] perf_wb_scan_i;
    wire [31:0] perf_wb_stash_i;
    wire [31:0] perf_wb_total_i;
    wire [31:0] perf_ws_compact_i;
    wire [31:0] perf_ws_ddr_rd_i;
    wire [31:0] perf_ws_ddr_wr_i;
    wire [31:0] perf_ws_decrypt_i;
    wire [31:0] perf_ws_encrypt_i;
    wire [31:0] perf_ws_evict_i;
    wire [31:0] perf_ws_ops_i;
    wire [31:0] perf_ws_scan_i;
    wire [31:0] perf_ws_stash_i;
    wire [31:0] perf_ws_total_i;
    wire [4:0] dbg_oram_state_i;
    wire dbg_gcm_tag_match_i, dbg_gcm_tag_valid_i;
    wire fmt_done_w;
    assign oram_ready = key_ready_r && fmt_done_w;


    flat_oram_gcm #(
        .N(N), .Z(Z), .B(B), .STASH_DEPTH(STASH_DEPTH)
    ) u_oram (
        .clk(clk), .rst_n(rst_n),
        .client_req(oram_req), .client_op(oram_op),
        .client_slot_addr(oram_addr),
        .client_wdata(oram_wdata), .client_wstrb(oram_wstrb),
        .client_wdata_valid(oram_wdata_valid),
        .client_wdata_beat(), .client_wdata_beat_req(ctrl_beat_req),
        .client_rdata(oram_client_rdata),
        .client_rdata_valid(oram_client_rdata_valid),
        .client_rdata_beat(),
        .client_done(oram_client_done),
        .client_stall(oram_client_stall),
`ifdef ORAM_OVERLAP2
        .client_acc(oc_acc), .client_wsel(oc_wsel), .client_rsel(oc_rsel),
`endif
        .err_bucket_overflow(err_bucket_overflow),
        .err_stash_overflow(err_stash_overflow),
        .err_tag_mismatch(err_tag_mismatch), .err_ct_overrun(err_ct_overrun), .fmt_done(fmt_done_w),
        .init_mode(init_mode_i),
        .init_pm_wr_addr(init_pm_wr_addr),
        .init_pm_wr_bucket(init_pm_wr_bucket),
        .init_pm_wr_status(init_pm_wr_status),
        .init_pm_wr_en(init_pm_wr_en),
        .init_bm_wr_bucket(init_bm_wr_bucket),
        .init_bm_wr_slot_list(init_bm_wr_slot_list),
        .init_bm_wr_fill(init_bm_wr_fill),
        .init_bm_wr_en(init_bm_wr_en),
        .aes_key(key_q), .aes_iv_seed(seed_q),        // F1: latched per boot
        .cfg_n(cfg_n), .cfg_hbm_bkts(cfg_hbm_bkts), .cfg_pool_n(cfg_pool_n), .dbg_halt_info(dbg_halt_info),
`ifdef ORAM_OV4_P3
        .cfg_ov_k(cfg_ov_k), .cfg_ov_leq(cfg_ov_leq),
`endif
        .m_axi_arid(m_axi_arid), .m_axi_araddr(m_axi_araddr),
        .m_axi_arlen(m_axi_arlen), .m_axi_arsize(m_axi_arsize),
        .m_axi_arburst(m_axi_arburst), .m_axi_arvalid(m_axi_arvalid),
        .m_axi_arready(m_axi_arready),
        .m_axi_rid(m_axi_rid), .m_axi_rdata(m_axi_rdata),
        .m_axi_rresp(m_axi_rresp), .m_axi_rlast(m_axi_rlast),
        .m_axi_rvalid(m_axi_rvalid), .m_axi_rready(m_axi_rready),
        .m_axi_awid(m_axi_awid), .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awlen(m_axi_awlen), .m_axi_awsize(m_axi_awsize),
        .m_axi_awburst(m_axi_awburst), .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awready(m_axi_awready),
        .m_axi_wdata(m_axi_wdata), .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wlast(m_axi_wlast), .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready),
        .m_axi_bid(m_axi_bid), .m_axi_bresp(m_axi_bresp),
        .m_axi_bvalid(m_axi_bvalid), .m_axi_bready(m_axi_bready),
        .m_meta_araddr(m_meta_araddr), .m_meta_arlen(m_meta_arlen), .m_meta_arsize(m_meta_arsize),
        .m_meta_arburst(m_meta_arburst), .m_meta_arvalid(m_meta_arvalid), .m_meta_arready(m_meta_arready),
        .m_meta_rdata(m_meta_rdata), .m_meta_rlast(m_meta_rlast), .m_meta_rvalid(m_meta_rvalid), .m_meta_rready(m_meta_rready),
        .m_meta_awaddr(m_meta_awaddr), .m_meta_awlen(m_meta_awlen), .m_meta_awsize(m_meta_awsize),
        .m_meta_awburst(m_meta_awburst), .m_meta_awvalid(m_meta_awvalid), .m_meta_awready(m_meta_awready),
        .m_meta_wdata(m_meta_wdata), .m_meta_wstrb(m_meta_wstrb), .m_meta_wlast(m_meta_wlast),
        .m_meta_wvalid(m_meta_wvalid), .m_meta_wready(m_meta_wready), .m_meta_bvalid(m_meta_bvalid), .m_meta_bready(m_meta_bready),
        .m_brec_araddr(m_brec_araddr), .m_brec_arlen(m_brec_arlen), .m_brec_arsize(m_brec_arsize),
        .m_brec_arburst(m_brec_arburst), .m_brec_arvalid(m_brec_arvalid), .m_brec_arready(m_brec_arready),
        .m_brec_rdata(m_brec_rdata), .m_brec_rlast(m_brec_rlast), .m_brec_rvalid(m_brec_rvalid),
        .m_brec_rready(m_brec_rready), .m_brec_awaddr(m_brec_awaddr), .m_brec_awlen(m_brec_awlen),
        .m_brec_awsize(m_brec_awsize), .m_brec_awburst(m_brec_awburst), .m_brec_awvalid(m_brec_awvalid),
        .m_brec_awready(m_brec_awready), .m_brec_wdata(m_brec_wdata), .m_brec_wstrb(m_brec_wstrb),
        .m_brec_wlast(m_brec_wlast), .m_brec_wvalid(m_brec_wvalid), .m_brec_wready(m_brec_wready),
        .m_brec_bvalid(m_brec_bvalid), .m_brec_bready(m_brec_bready),
`ifdef ORAM_STASH_PC_IDS
        .m_stash_arid(m_stash_arid), .m_stash_rid(m_stash_rid),
`endif
        .m_stash_araddr(m_stash_araddr), .m_stash_arlen(m_stash_arlen), .m_stash_arsize(m_stash_arsize),
        .m_stash_arburst(m_stash_arburst), .m_stash_arvalid(m_stash_arvalid), .m_stash_arready(m_stash_arready),
        .m_stash_rdata(m_stash_rdata), .m_stash_rlast(m_stash_rlast), .m_stash_rvalid(m_stash_rvalid),
        .m_stash_rready(m_stash_rready), .m_stash_awaddr(m_stash_awaddr), .m_stash_awlen(m_stash_awlen),
        .m_stash_awsize(m_stash_awsize), .m_stash_awburst(m_stash_awburst), .m_stash_awvalid(m_stash_awvalid),
        .m_stash_awready(m_stash_awready), .m_stash_wdata(m_stash_wdata), .m_stash_wstrb(m_stash_wstrb),
        .m_stash_wlast(m_stash_wlast), .m_stash_wvalid(m_stash_wvalid), .m_stash_wready(m_stash_wready),
        .m_stash_bvalid(m_stash_bvalid), .m_stash_bready(m_stash_bready),
        .dbg_state(dbg_oram_state_i), .dbg_client_done(), .dbg_client_req(),
        .dbg_req_b(), .dbg_req_b_new(),
        .dbg_found_in_bucket(), .dbg_found_in_stash(),
        .dbg_same_bucket(), .dbg_err_stash_ovf(), .dbg_stash_occ(),
        .dbg_gcm_tag_match(dbg_gcm_tag_match_i),.dbg_gcm_tag_valid(dbg_gcm_tag_valid_i),
        .dbg_force_same_bucket(dbg_force_sb_i),
        .dbg_prng_override(dbg_prng_ovr_i),
        .perf_reset(perf_reset),
        .perf_rb_ddr_rd(perf_rb_ddr_rd_i), .perf_rb_decrypt(perf_rb_decrypt_i),
        .perf_rb_encrypt(perf_rb_encrypt_i), .perf_rb_compact(perf_rb_compact_i),
        .perf_rb_evict(perf_rb_evict_i), .perf_rb_ddr_wr(perf_rb_ddr_wr_i),
        .perf_rb_scan(perf_rb_scan_i), .perf_rb_stash(perf_rb_stash_i),
        .perf_rb_total(perf_rb_total_i), .perf_rb_ops(perf_rb_ops_i),
        .perf_rs_ddr_rd(perf_rs_ddr_rd_i), .perf_rs_decrypt(perf_rs_decrypt_i),
        .perf_rs_encrypt(perf_rs_encrypt_i), .perf_rs_compact(perf_rs_compact_i),
        .perf_rs_evict(perf_rs_evict_i), .perf_rs_ddr_wr(perf_rs_ddr_wr_i),
        .perf_rs_scan(perf_rs_scan_i), .perf_rs_stash(perf_rs_stash_i),
        .perf_rs_total(perf_rs_total_i), .perf_rs_ops(perf_rs_ops_i),
        .perf_wb_ddr_rd(perf_wb_ddr_rd_i), .perf_wb_decrypt(perf_wb_decrypt_i),
        .perf_wb_encrypt(perf_wb_encrypt_i), .perf_wb_compact(perf_wb_compact_i),
        .perf_wb_evict(perf_wb_evict_i), .perf_wb_ddr_wr(perf_wb_ddr_wr_i),
        .perf_wb_scan(perf_wb_scan_i), .perf_wb_stash(perf_wb_stash_i),
        .perf_wb_total(perf_wb_total_i), .perf_wb_ops(perf_wb_ops_i),
        .perf_ws_ddr_rd(perf_ws_ddr_rd_i), .perf_ws_decrypt(perf_ws_decrypt_i),
        .perf_ws_encrypt(perf_ws_encrypt_i), .perf_ws_compact(perf_ws_compact_i),
        .perf_ws_evict(perf_ws_evict_i), .perf_ws_ddr_wr(perf_ws_ddr_wr_i),
        .perf_ws_scan(perf_ws_scan_i), .perf_ws_stash(perf_ws_stash_i),
`ifdef ORAM_PHASE_TRACE
        .phase_ent(phase_ent),
`endif
`ifdef ORAM_ONPKG_DEBUG
        .dbg_acc_rec(dbg_acc_rec), .dbg_ov_rec(dbg_ov_rec), .dbg_st_rec(dbg_st_rec),
`endif
        .perf_ws_total(perf_ws_total_i), .perf_ws_ops(perf_ws_ops_i)
    );

    // =========================================================================
    // Route outputs to correct client
    // =========================================================================
    genvar ci;
    generate
        for (ci = 0; ci < NUM_CLIENTS; ci = ci + 1) begin : gen_out
`ifdef ORAM_OVERLAP2
            assign client_done[ci] = oram_client_done;
            assign client_rdata[ci*AXI_DW +: AXI_DW] = odmy[oc_rsel] ? {AXI_DW{1'b0}} : oram_client_rdata;   // a dummy returns zeros
            assign client_rdata_valid[ci] = oram_client_rdata_valid;
`else
            assign client_done[ci] = oram_client_done &&
                grant_real && (grant_id == ci[TDM_CID_W-1:0]);
            assign client_rdata[ci*AXI_DW +: AXI_DW] = cdmy[ci] ? {AXI_DW{1'b0}} : oram_client_rdata;   // a dummy returns zeros
            assign client_rdata_valid[ci] = oram_client_rdata_valid &&
                grant_real && (grant_id == ci[TDM_CID_W-1:0]);
`endif
        end
    endgenerate

    // Phase 3: "a client request is pending" (the controller is busy in nearly every slot)
    assign oram_busy = ~&client_ready;

    // F11: secure build exports nothing that reveals access paths or timing
    assign perf_rb_compact = DBG_EN ? perf_rb_compact_i : 32'd0;
    assign perf_rb_ddr_rd = DBG_EN ? perf_rb_ddr_rd_i : 32'd0;
    assign perf_rb_ddr_wr = DBG_EN ? perf_rb_ddr_wr_i : 32'd0;
    assign perf_rb_decrypt = DBG_EN ? perf_rb_decrypt_i : 32'd0;
    assign perf_rb_encrypt = DBG_EN ? perf_rb_encrypt_i : 32'd0;
    assign perf_rb_evict = DBG_EN ? perf_rb_evict_i : 32'd0;
    assign perf_rb_ops = DBG_EN ? perf_rb_ops_i : 32'd0;
    assign perf_rb_scan = DBG_EN ? perf_rb_scan_i : 32'd0;
    assign perf_rb_stash = DBG_EN ? perf_rb_stash_i : 32'd0;
    assign perf_rb_total = DBG_EN ? perf_rb_total_i : 32'd0;
    assign perf_rs_compact = DBG_EN ? perf_rs_compact_i : 32'd0;
    assign perf_rs_ddr_rd = DBG_EN ? perf_rs_ddr_rd_i : 32'd0;
    assign perf_rs_ddr_wr = DBG_EN ? perf_rs_ddr_wr_i : 32'd0;
    assign perf_rs_decrypt = DBG_EN ? perf_rs_decrypt_i : 32'd0;
    assign perf_rs_encrypt = DBG_EN ? perf_rs_encrypt_i : 32'd0;
    assign perf_rs_evict = DBG_EN ? perf_rs_evict_i : 32'd0;
    assign perf_rs_ops = DBG_EN ? perf_rs_ops_i : 32'd0;
    assign perf_rs_scan = DBG_EN ? perf_rs_scan_i : 32'd0;
    assign perf_rs_stash = DBG_EN ? perf_rs_stash_i : 32'd0;
    assign perf_rs_total = DBG_EN ? perf_rs_total_i : 32'd0;
    assign perf_wb_compact = DBG_EN ? perf_wb_compact_i : 32'd0;
    assign perf_wb_ddr_rd = DBG_EN ? perf_wb_ddr_rd_i : 32'd0;
    assign perf_wb_ddr_wr = DBG_EN ? perf_wb_ddr_wr_i : 32'd0;
    assign perf_wb_decrypt = DBG_EN ? perf_wb_decrypt_i : 32'd0;
    assign perf_wb_encrypt = DBG_EN ? perf_wb_encrypt_i : 32'd0;
    assign perf_wb_evict = DBG_EN ? perf_wb_evict_i : 32'd0;
    assign perf_wb_ops = DBG_EN ? perf_wb_ops_i : 32'd0;
    assign perf_wb_scan = DBG_EN ? perf_wb_scan_i : 32'd0;
    assign perf_wb_stash = DBG_EN ? perf_wb_stash_i : 32'd0;
    assign perf_wb_total = DBG_EN ? perf_wb_total_i : 32'd0;
    assign perf_ws_compact = DBG_EN ? perf_ws_compact_i : 32'd0;
    assign perf_ws_ddr_rd = DBG_EN ? perf_ws_ddr_rd_i : 32'd0;
    assign perf_ws_ddr_wr = DBG_EN ? perf_ws_ddr_wr_i : 32'd0;
    assign perf_ws_decrypt = DBG_EN ? perf_ws_decrypt_i : 32'd0;
    assign perf_ws_encrypt = DBG_EN ? perf_ws_encrypt_i : 32'd0;
    assign perf_ws_evict = DBG_EN ? perf_ws_evict_i : 32'd0;
    assign perf_ws_ops = DBG_EN ? perf_ws_ops_i : 32'd0;
    assign perf_ws_scan = DBG_EN ? perf_ws_scan_i : 32'd0;
    assign perf_ws_stash = DBG_EN ? perf_ws_stash_i : 32'd0;
    assign perf_ws_total = DBG_EN ? perf_ws_total_i : 32'd0;
    assign dbg_oram_state    = DBG_EN ? dbg_oram_state_i : 5'd0;
    assign dbg_gcm_tag_match = DBG_EN ? dbg_gcm_tag_match_i : 1'b0;
    assign dbg_gcm_tag_valid = DBG_EN ? dbg_gcm_tag_valid_i : 1'b0;
endmodule