#!/usr/bin/env python3
"""hbm_port.py BUILD_DIR [...] -- which HBM switch port each DOMA kernel memory port reaches in the built design.
Read-only: follows the interface nets of the link's block design (ulp.bd) from doma_kernel_1/m_axi_gmemN through any
cells in between (RAMA, register slices, interconnects) to the HBM subsystem's slave port, and also prints the raw
vivado.log connect lines as evidence. gmem3 meta, gmem4 brec, gmem5 stash, gmem6 buckets kept in HBM."""
import json, os, re, sys, glob
ARG = {"gmem0": "cmd_input", "gmem1": "resp_output", "gmem2": "pages (host)", "gmem3": "meta", "gmem4": "brec",
       "gmem5": "stash", "gmem6": "pages_hbm"}

def flatten(bd):
    nets, cells = [], {}
    def walk(node, pre):
        for name, c in (node.get("components") or {}).items():
            p = pre + name
            cells[p] = c.get("vlnv", "hier")
            walk(c, p + "/")
        for nname, n in (node.get("interface_nets") or {}).items():
            pins = n.get("interface_ports") or n.get("ports") or []
            nets.append((pre + nname, [pre + q for q in pins]))
    d = bd.get("design", bd)
    walk(d, "")
    return nets, cells

def trace(nets, cells, start):
    pin2nets = {}
    for i, (_, pins) in enumerate(nets):
        for q in pins: pin2nets.setdefault(q, []).append(i)
    hbm = re.compile(r"(hmss|hbm)[^/]*/S(AXI_)?\d+", re.I)
    paths, seen = [], set()
    stack = [(start, [start])]
    while stack:
        pin, path = stack.pop()
        if pin in seen: continue
        seen.add(pin)
        for i in pin2nets.get(pin, []):
            for q in nets[i][1]:
                if q == pin or q in seen: continue
                if hbm.search(q): paths.append(path + [q]); seen.add(q); continue
                cell = q.rsplit("/", 1)[0] if "/" in q else ""
                if cell.startswith("doma_kernel"): continue
                stack.append((q, path + [q]))                          # a hierarchy boundary: same signal
                if cell in cells and cells[cell] != "hier":           # a leaf cell in between: continue on its master side
                    for p2 in pin2nets:
                        if p2.startswith(cell + "/") and p2 != q and re.search(r"/M\d*_?AXI|/M_AXI|/m_axi", p2):
                            stack.append((p2, path + [q, p2]))
    return paths

for b in sys.argv[1:]:
    link = os.path.join(os.path.expanduser(b), "fpga_zcu208/vitis/_x/link")
    print(f"== {b}")
    bds = [f for f in glob.glob(link + "/vivado/vpl/prj/**/ulp.bd", recursive=True)]
    if not bds: print("   no ulp.bd under", link)
    for f in bds[:1]:
        nets, cells = flatten(json.load(open(f)))
        for g in sorted(ARG):
            starts = [q for _, pins in nets for q in pins if q.endswith("doma_kernel_1/m_axi_" + g)]
            if not starts: print(f"   {g} {ARG[g]:12s} no net found"); continue
            ps = trace(nets, cells, starts[0])
            ends = sorted({p[-1] for p in ps})
            print(f"   {g} {ARG[g]:12s} -> {', '.join(ends) if ends else 'no HBM port reached (host memory, or path not followed)'}")
            for p in ps[:1]:
                if len(p) > 2: print("        via", " -> ".join(p[1:-1]))
    log = link + "/vivado/vpl/vivado.log"
    if os.path.exists(log):
        raw = sorted({l.strip()[:220] for l in open(log, errors="replace")
                      if re.search(r"m_axi_gmem[3-6]", l) and re.search(r"S\d\d_AXI|SAXI_\d+|rama|hmss", l, re.I)})
        print(f"   vivado.log evidence ({len(raw)} lines):")
        for l in raw[:12]: print("     ", l)
    else: print("   no vivado.log (link files cleaned?)")
    xb = os.path.join(os.path.expanduser(b), "fpga_zcu208/vitis/doma_hw.xclbin")
    if os.path.exists(xb) and os.system("command -v xclbinutil > /dev/null") == 0:
        out = f"/tmp/hbm_port_{os.getpid()}.json"
        os.system(f"xclbinutil --input '{xb}' --dump-section SYSTEM_METADATA:RAW:{out} --force > /dev/null 2>&1")
        if os.path.exists(out):
            t = open(out, errors="replace").read(); os.remove(out)
            hits = sorted({t[max(0, m.start() - 160): m.end() + 160].replace("\n", " ")
                           for m in re.finditer(r"m_axi_gmem[56]", t)})
            ports = sorted(set(re.findall(r"S\d\d_AXI|SAXI_\d+", t)))
            print(f"   xclbin system metadata: HBM switch ports named anywhere: {' '.join(ports) or 'none'}")
            for h in hits[:6]: print("      ...", re.sub(r"\s+", " ", h), "...")
