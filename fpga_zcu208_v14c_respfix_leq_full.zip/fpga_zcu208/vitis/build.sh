#!/bin/bash
# build.sh -- doma_kernel.xo -> doma.xclbin -> host program  (UNTESTED here)
# Needs Vitis 2024.1 (the version BOLT used), XRT, and the U55C platform installed.
#   TARGET=hw      bash build.sh   # board bitstream (hours)
#   TARGET=hw_emu  bash build.sh   # hardware emulation, no card needed
#   BEATS=8 TARGET=hw bash build.sh   # 256-byte blocks (1, 2, 4, 8 beats = 32-256 B; default 4 KB)
set -euo pipefail
cd "$(dirname "$0")"
PLATFORM=${PLATFORM:-xilinx_u55c_gen3x16_xdma_3_202210_1}     # BOLT's xclbins use this platform
TARGET=${TARGET:-hw}
CFG=${CFG:-doma.cfg}                  # CFG=doma_emu.cfg if hw_emu cannot use host memory
BEATS=${BEATS:-}                      # block size in 32-byte beats: 1, 2, 4, 8 (32-256 B); empty = 4 KB
if [ -n "$BEATS" ]; then
    printf '// written by build.sh\n`ifndef ORAM_BLOCK_BEATS\n`define ORAM_BLOCK_BEATS %s\n`endif\n' "$BEATS" > ../rtl/oram_build_cfg.vh
    # NMAX: the build's maximum number of blocks (the host chooses n <= NMAX at run time); default 256
    [ -n "${NMAX:-}" ] && printf '`ifndef ORAM_N\n`define ORAM_N %s\n`endif\n' "$NMAX" >> ../rtl/oram_build_cfg.vh
else
    printf '// written by build.sh: default block size (4 KB)\n' > ../rtl/oram_build_cfg.vh
    [ -n "${NMAX:-}" ] && printf '`ifndef ORAM_N\n`define ORAM_N %s\n`endif\n' "$NMAX" >> ../rtl/oram_build_cfg.vh
fi
# SCHED=arrival: arrival-relative scheduling. Everything secret-dependent stays padded (the lookup, the requested
# block's path, evictions); a bucket's own read latency is not (see docs/README_FPGA.md for the condition).
if [ "${SCHED:-strict}" = "arrival" ]; then
    printf '`define ORAM_SCHED_ARRIVAL\n' >> ../rtl/oram_build_cfg.vh
fi
# TRACE=1: the phase-trace variant (docs/README_FPGA.md, "Phase trace"). Every response header carries the bucket-port
# timestamps, and with bit 31 of size set each command also writes a 32-byte record of 16 phase timestamps. Without it
# the RTL is exactly the untraced design; build it in its own folder so both bitstreams stay available.
if [ "${TRACE:-0}" = "1" ]; then
    printf '`define ORAM_PHASE_TRACE\n' >> ../rtl/oram_build_cfg.vh
fi
# DEBUG=1 (v14b, needs TRACE=1 and SCHED=arrival): the on-package debug variant (docs/v14b_card_calibration.md). An
# on-package timing overrun is recorded and counted, never halts; each 128-byte trace record (v14c) carries the core's access
# record; the summary is followed by the debug records. For calibrating AR_WB_H / AR_REL_H on the card only: never
# measure with it, never deploy it. Build it in its own folder.
if [ "${DEBUG:-0}" = "1" ]; then
    [ "${TRACE:-0}" = "1" ] && [ "${SCHED:-strict}" = "arrival" ] || { echo "DEBUG=1 needs TRACE=1 and SCHED=arrival"; exit 1; }
    printf '`define ORAM_ONPKG_DEBUG\n' >> ../rtl/oram_build_cfg.vh
fi
# STASH_IDS=1 (v14d design B): the stash port carries AXI IDs, one per pseudo-channel of the stash buffer (address bits
# [30:29]); reads of different channels then never wait for each other in the HBM switch. Same host programs, same
# .cfg (doma_big2m.cfg at 4 KB, 2M records). Without it: design A. RAMA instead: CFG=doma_big2m_rama.cfg, no STASH_IDS.
if [ "${STASH_IDS:-0}" = "1" ]; then
    printf '`define ORAM_STASH_PC_IDS\n' >> ../rtl/oram_build_cfg.vh
fi
# FIXWB=1 (Option A, docs/fixwb_option_a.md; arrival scheduling, no overlap): an on-package bucket's write-back starts
# at exactly t_arr + WBF cycles and streams hold-free; the decisions not done by then, or a beat held for an eviction
# copy, is an on-package deadline (1) miss (fail-stop at the release time; the debug build records it instead).
# WBF defaults to 440 at 4 KB, lambda 7 (the card's worst first write beat 305 + worst hold 28, + 10% + 74); other
# sizes need WBF=<cycles>. Works with TRACE=1 and DEBUG=1. Off-package accesses and every visible time are v14d1's.
case "${FIXWB:-0}" in
    0) ;;
    1)
        [ "${SCHED:-strict}" = "arrival" ] || { echo "FIXWB=1 needs SCHED=arrival"; exit 2; }
        [ "${OVERLAP:-0}" = "0" ] || { echo "FIXWB=1 is not supported with OVERLAP yet (Option A is for the serial design)"; exit 2; }
        if [ -z "${WBF:-}" ] && [ "${RAMA:-0}" != 1 ] && { [ "${LAMBDA:-6}" != 7 ] || { [ -n "${BEATS:-}" ] && [ "$BEATS" != 128 ]; }; }; then
            echo "FIXWB=1: the default WBF (440) is for 4 KB blocks and LAMBDA=7; give WBF=<cycles> for this size"; exit 2; fi
        printf '`define ORAM_ONPKG_FIXWB\n' >> ../rtl/oram_build_cfg.vh
        [ -n "${WBF:-}" ] && printf '`define ORAM_AR_WBF_H %s\n' "$WBF" >> ../rtl/oram_build_cfg.vh ;;
    *) echo "FIXWB=$FIXWB: use 1 (Option A) or leave it unset"; exit 2 ;;
esac
# OVERLAP (docs/overlap_rtl_spec.md; arrival scheduling only; no debug or trace build yet):
#   OVERLAP=2 (or 1): step 1, two accesses in flight. Writes `define ORAM_OVERLAP2, ORAM_OV_P (default 2900) and
#                     ORAM_OV_DEQ (default 2700).
#   OVERLAP=4:        step 2, up to four in flight, two bucket reads in flight, a second AES-GCM core. Writes
#                     `define ORAM_OVERLAP2 and `define ORAM_OVERLAP4 and the card parameters (docs/overlap_rtl_spec.md
#                     section 14): ORAM_OV_P 2150, ORAM_OV_CT_RD 600, ORAM_OV_DEQ 6000, ORAM_OV4_GA 1500.
#   P3=1 (with OVERLAP=4): step 2 phase 3 (section 17), OV_PMIN (default 1500) the least start spacing.
#                     OV_LEQ (default 6809) and OV_L (default 4034), cycles after an access's effective arrival: when a
#                     later read of the same bucket may issue (its write-back streamed, acknowledged and readable), and
#                     when its context is free for the access four later. Independent since 2026-11-05 (section 19):
#                     OV_LEQ 3809, the old default, read a stale host bucket on the card. OV_LEQ below 3809 or OV_L below
#                     4034 is refused.
#   OV_P / OV_DEQ override the start spacing and the same-bucket shift (cycles); for OVERLAP=4 also OV_CTRD (the read
#   gate after the start) and OV_GA (the least spacing of effective arrivals). Step 2's write-back and release
#   allowances (ORAM_OV4_XWB 700, ORAM_OV4_XWB_H 1200, ORAM_OV4_XREL_H 1400) keep their RTL defaults.
#   Unset or 0: no overlap (v14d1).
case "${OVERLAP:-0}" in
    0) ;;
    1|2|4)
        if [ "${SCHED:-strict}" != "arrival" ] || [ "${DEBUG:-0}" = "1" ] || [ "${TRACE:-0}" = "1" ]; then
            echo "OVERLAP=$OVERLAP needs SCHED=arrival and no DEBUG/TRACE (not yet supported)"; exit 2; fi
        if [ "$OVERLAP" = "4" ]; then
            printf '`define ORAM_OVERLAP2\n`define ORAM_OVERLAP4\n`define ORAM_OV_P %s\n`define ORAM_OV_CT_RD %s\n`define ORAM_OV_DEQ %s\n`define ORAM_OV4_GA %s\n' \
                "${OV_P:-2150}" "${OV_CTRD:-600}" "${OV_DEQ:-6000}" "${OV_GA:-1500}" >> ../rtl/oram_build_cfg.vh
            # P3=1: phase 3 (docs/overlap_rtl_spec.md section 17): starts and same-bucket reads relative to the
            # arrivals, every write-back at t' + AR_WB; OV_PMIN the least start spacing (OV_P and OV_DEQ unused)
            # OV_LEQ / OV_L (cycles after the effective arrival; 0 or unset: the RTL defaults AR_WB + 4324 = 6809 and
            # max(AR_REL_H, AR_REL) + 250 = 4034): when a same-bucket read may issue, and when the context is free
            if [ "${P3:-0}" = 1 ]; then
                if [ "${OV_LEQ:-0}" != 0 ] && [ "$OV_LEQ" -lt 3809 ]; then echo "OV_LEQ below the default 3809 is not supported"; exit 2; fi
                if [ "${OV_L:-0}" != 0 ] && [ "$OV_L" -lt 4034 ]; then echo "OV_L below the default 4034 is not supported"; exit 2; fi
                if [ "${OV_GA:-1500}" -lt 1500 ] || [ "${OV_PMIN:-1500}" -lt 1500 ]; then echo "OV_GA / OV_PMIN below 1500 is not supported"; exit 2; fi
                printf '`define ORAM_OV4_P3\n`define ORAM_OV_PMIN %s\n`define ORAM_OV4_LEQ %s\n`define ORAM_OV4_L %s\n' \
                    "${OV_PMIN:-1500}" "${OV_LEQ:-0}" "${OV_L:-0}" >> ../rtl/oram_build_cfg.vh
                # OV_XWB (2026-11-06, docs section 21): the overlap allowance on the write-back and release budgets
                # (default 700; the on-package release allowance follows at OV_XWB + 700). Measured in simulation at
                # 1,600 spacing with a RAMA-like stash: clean down to 0. Values below 200 are refused.
                if [ -n "${OV_XWB:-}" ]; then
                    [ "$OV_XWB" -ge 200 ] && [ "$OV_XWB" -le 700 ] || { echo "OV_XWB must be 200 .. 700"; exit 2; }
                    if [ "$OV_XWB" -lt 700 ] && { [ "${OV_GA:-1500}" -lt 1600 ] || [ "${OV_PMIN:-1500}" -lt 1600 ]; }; then
                        echo "OV_XWB below 700 was measured only at OV_GA and OV_PMIN of 1600 or more"; exit 2; fi
                    printf '`define ORAM_OV4_XWB %s\n`define ORAM_OV4_XREL_H %s\n' "$OV_XWB" "$(( OV_XWB + 700 ))" >> ../rtl/oram_build_cfg.vh
                fi
                # OV_K (2026-11-07): at most OV_K accesses in flight (2 or 3; 4, the default, is the design unchanged).
                # A start also waits until the access OV_K back is free: a public term (its arrival + OV_L).
                # Since 2026-11-08 every phase 3 build takes K at run time (DOMA_OV_K=2|3|4 on the host, sent at the
                # boot), so OV_K is needed only to fix K in the bitstream (then DOMA_OV_K is ignored).
                if [ -n "${OV_K:-}" ] && [ "$OV_K" != 4 ]; then
                    case "$OV_K" in 2|3) ;; *) echo "OV_K must be 2, 3 or 4"; exit 2;; esac
                    printf '`define ORAM_OV4_K %s\n' "$OV_K" >> ../rtl/oram_build_cfg.vh
                fi
            fi
        else
            printf '`define ORAM_OVERLAP2\n`define ORAM_OV_P %s\n`define ORAM_OV_DEQ %s\n' "${OV_P:-2900}" "${OV_DEQ:-2700}" >> ../rtl/oram_build_cfg.vh
        fi ;;
    *) echo "OVERLAP=$OVERLAP: use 2 (step 1, two in flight) or 4 (step 2, four in flight)"; exit 2 ;;
esac
# RAMA=1 (2026-11-06; LAMBDA=7, SCHED=arrival, CFG=doma_big2m_rama.cfg): the on-package budgets with the stash on RAMA
# (rtl/oram_params.vh ORAM_ONPKG_RAMA). 4 KB: calibrated on the card (AR_WB_H 440, AR_REL_H 1669, AR_DONE_H 2103). 32 B ..
# 2 KB (2026-11-07, docs/rama_sizes.md): their card-proven budgets, unchanged (the stash's worst case there is a window
# of dependent reads, which RAMA does not shorten); with FIXWB=1 the write-back start is AR_WB_H - 37 per size unless
# WBF= is given. Off-package budgets are unchanged (re-encryption, not the stash, sets them). Not for the overlap builds.
if [ "${RAMA:-0}" = "1" ]; then
    { [ "${LAMBDA:-6}" = 7 ] && [ "${SCHED:-strict}" = "arrival" ]; } \
        || { echo "RAMA=1 is for LAMBDA=7, SCHED=arrival"; exit 1; }
    case "${BEATS:-128}" in 1|2|4|8|16|32|64|128) ;; *) echo "RAMA=1: BEATS must be 1, 2, 4, 8, 16, 32, 64 or 128"; exit 1 ;; esac
    [ "${CFG:-}" = "doma_big2m_rama.cfg" ] || { echo "RAMA=1 needs CFG=doma_big2m_rama.cfg (the budgets assume the stash on RAMA)"; exit 1; }
    [ "${OVERLAP:-0}" = 0 ] || { echo "RAMA=1 is not for the overlap builds"; exit 1; }
    printf '`define ORAM_ONPKG_RAMA\n' >> ../rtl/oram_build_cfg.vh
fi
# INTERIM=1 (v14b, 4 KB blocks, LAMBDA=7, SCHED=arrival): the interim on-package budgets (rtl/oram_params.vh: AR_WB_H
# 1455, AR_REL_H 2538, covering stash reads of up to 500 cycles) in place of v14's (855, 1938), until the card
# calibration (docs/v14b_card_calibration.md) sets the defaults. Off-package budgets are unchanged.
if [ "${INTERIM:-0}" = "1" ]; then
    { [ "${LAMBDA:-6}" = "7" ] && [ "${SCHED:-strict}" = "arrival" ] && { [ -z "${BEATS:-}" ] || [ "${BEATS}" = 128 ]; }; } \
        || { echo "INTERIM=1 is for 4 KB blocks, LAMBDA=7, SCHED=arrival"; exit 1; }
    printf '`define ORAM_ONPKG_INTERIM\n' >> ../rtl/oram_build_cfg.vh
fi
# PLAIN=1: the non-oblivious baseline (rtl/plain_oram_top.v instead of DOMA's core; docs/README_FPGA.md, "Baseline").
# Run it with DOMA_HBM_PCT=75 DOMA_POOL=64 so the HBM page buffer holds exactly one slot per record.
if [ "${PLAIN:-0}" = "1" ]; then
    [ "${TRACE:-0}" = "1" ] && { echo "PLAIN=1 and TRACE=1 together are not supported"; exit 1; }
    printf '`define ORAM_PLAIN\n' >> ../rtl/oram_build_cfg.vh
fi
# LAMBDA: slots per bucket (default 6, in rtl/oram_params.vh); the host programs need DOMA_LAMBDA=<the same> to run it
[ -n "${LAMBDA:-}" ] && printf '`ifndef ORAM_C\n`define ORAM_C %s\n`endif\n' "$LAMBDA" >> ../rtl/oram_build_cfg.vh
echo "kernel clock: ${MHZ:-300} MHz, lambda: ${LAMBDA:-6}, block size: ${BEATS:-128} beats ($(( ${BEATS:-128} * 32 )) bytes), scheduling: ${SCHED:-strict}, phase trace: $([ "${TRACE:-0}" = 1 ] && echo on || echo off), on-package debug: $([ "${DEBUG:-0}" = 1 ] && echo "ON (calibration only)" || echo off), on-package budgets: $([ "${INTERIM:-0}" = 1 ] && echo "INTERIM (500-cycle stash reads)" || { [ "${RAMA:-0}" = 1 ] && echo "RAMA (per block size, rtl/oram_params.vh)"; } || echo default), core: $([ "${PLAIN:-0}" = 1 ] && echo "PLAIN baseline" || echo DOMA), stash IDs: $([ "${STASH_IDS:-0}" = 1 ] && echo "one per pseudo-channel (design B)" || echo "one (design A)"), on-package write-back: $([ "${FIXWB:-0}" = 1 ] && echo "Option A, fixed at t_arr + ${WBF:-$([ "${RAMA:-0}" = 1 ] && echo "the per-size WBF (RAMA, rtl/oram_params.vh)" || echo 440)}, hold-free" || echo "v14d1 (after the decisions)"), overlap: $(case "${OVERLAP:-0}" in 1|2) echo "step 1, 2 in flight, P ${OV_P:-2900}, D_EQ ${OV_DEQ:-2700}";; 4) if [ "${P3:-0}" = 1 ]; then echo "step 2 PHASE 3, $([ -n "${OV_K:-}" ] && [ "$OV_K" != 4 ] && echo "$OV_K in flight at most (fixed)" || echo "in-flight cap set at run time (DOMA_OV_K = 2, 3 or 4; default 4)"), 2 reads in flight, least start spacing ${OV_PMIN:-1500}, same-bucket read ${OV_LEQ:-default $(( 1785 + ${OV_XWB:-700} + 4324 ))} and context free ${OV_L:-default $(( ${OV_XWB:-700} + 3334 ))} after the arrival, overlap allowance ${OV_XWB:-700}, starts and same-bucket reads after the arrivals, every write-back at t' + AR_WB, read gate ${OV_CTRD:-600}, arrival spacing ${OV_GA:-1500}"; else echo "step 2, 4 in flight, 2 reads in flight, P ${OV_P:-2150}, read gate ${OV_CTRD:-600}, D_EQ ${OV_DEQ:-6000}, arrival spacing ${OV_GA:-1500}"; fi;; *) echo off;; esac), cfg: $CFG"
echo "== rtl/oram_build_cfg.vh:"; cat ../rtl/oram_build_cfg.vh
vivado -mode batch -nojournal -nolog -source package_kernel.tcl -tclargs ../rtl doma_kernel.xo
# hardware builds: after placement, write the placed checkpoint and congestion/utilization/timing reports
# (post_place.tcl), so even a stopped build leaves evidence in _x/link/vivado/vpl/prj/prj.runs/impl_1/
HOOK=""
if [ "$TARGET" = "hw" ]; then HOOK="--vivado.prop run.impl_1.STEPS.PLACE_DESIGN.TCL.POST=$(pwd)/post_place.tcl"; fi
# MHZ=<clock> (2026-11-07; default 300): the kernel clock, as build_tinyoram.sh's FREQ. Budgets are in cycles and memory
# latencies in nanoseconds, so a lower clock only adds slack; the timing check follows the requested clock.
KMHZ=${MHZ:-300}
case "$KMHZ" in 1[0-9][0-9]|2[0-9][0-9]|300) ;; *) echo "MHZ must be 100 .. 300"; exit 1 ;; esac
v++ -l -t $TARGET --platform $PLATFORM --kernel_frequency $KMHZ --config $CFG $HOOK \
    --save-temps -o doma_$TARGET.xclbin doma_kernel.xo
g++ -std=c++17 -O2 host_doma.cpp -I$XILINX_XRT/include -L$XILINX_XRT/lib -lxrt_coreutil -pthread -o host_doma
if [ "$TARGET" = hw ]; then WANT_MHZ=$KMHZ ./check_timing.sh || echo "*** TIMING NOT CLOSED: do not use doma_hw.xclbin for measurements ***"; fi
if [ "$TARGET" = hw ] && [ "${OVERLAP:-0}" != 0 ]; then ./check_overlap_build.sh $([ "$OVERLAP" = 4 ] && echo 4 || echo 2) || echo "*** NOT THE OVERLAP DESIGN: see above ***"; fi
if [ "$TARGET" = hw_emu ]; then emconfigutil --platform $PLATFORM; echo "run: XCL_EMULATION_MODE=hw_emu ./host_doma doma_hw_emu.xclbin"; fi
