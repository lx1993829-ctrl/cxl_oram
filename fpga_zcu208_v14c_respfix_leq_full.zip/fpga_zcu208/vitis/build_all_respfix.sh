#!/bin/bash
# build_all_respfix.sh -- build every design of fpga_zcu208_v14c_respfix_full.zip, at most 3 at once (most important
# first), and check each one on the card as soon as it finishes; card runs never overlap (one lock). Each design builds in
# its own copy of the package under ~/<name>. Results: ~/respfix_results.txt (summary) and ~/<name>/check.log.
#
#   bash build_all_respfix.sh            # from the unzipped package's vitis/ folder, or anywhere with ZIP=<path>
#   ONLY="p3rx300fix optarama_fix" bash build_all_respfix.sh      # just these designs
#   CHECK_ONLY=1 bash build_all_respfix.sh                         # no builds: check the designs already built
#
# Designs, in order: p3rx300fix (overlap, phase 3, 1,600 / 300), optarama_fix (baseline Option A + RAMA, 4 KB),
# optarama_tr (the same, traced), then the baseline at 32 B .. 2 KB (rama_b1 .. rama_b64).
# Checks per finished design (only if its timing closed):
#   rate     host_phases get / put / mix / get at n = 4,096, 20% on package, 500,000 commands each: the device cycles per
#            command of every phase within 0.2% of the first GET phase (the operation must not reach the schedule)
#   leak     overlap only, if ~/p3rx300/fpga_zcu208/vitis/host_leak_ov exists: the acceptance test and card_rate_check.py
#   kqps     host_doma at 1,000,000 records, 0 / 20 / 100% on package, 2,000,000 requests (RUN_N, RUN_REQ to change)
#   phases   traced build only: host_phases mix at 1,000,000 records, 20% on package, with the phase breakdown
set -u
JOBS=${JOBS:-3}; RUN_N=${RUN_N:-1000000}; RUN_REQ=${RUN_REQ:-2000000}; RATE_N=${RATE_N:-500000}
SELF=$(cd "$(dirname "$0")" && pwd)
ZIP=${ZIP:-$(ls "$SELF"/../../pkg.zip 2>/dev/null || ls "$SELF"/../../*.zip 2>/dev/null | head -1)}
LEAK_HOST=${LEAK_HOST:-$HOME/p3rx300/fpga_zcu208/vitis/host_leak_ov}
LEAK_PY=${LEAK_PY:-$HOME/p3rx300/fpga_zcu208/sim/card_rate_check.py}
RES=$HOME/respfix_results.txt; LOCK=$HOME/.u55c_card.lock
COMMON="SCHED=arrival CFG=doma_big2m_rama.cfg NMAX=2097152 LAMBDA=7 TARGET=hw"
declare -A ARGS=(
  [p3rx300fix]="OVERLAP=4 P3=1 OV_PMIN=1600 OV_GA=1600 OV_XWB=300 BEATS=128"
  [optarama_fix]="FIXWB=1 RAMA=1 BEATS=128"
  [optarama_tr]="FIXWB=1 RAMA=1 TRACE=1 BEATS=128"
  [rama_b1]="FIXWB=1 RAMA=1 BEATS=1"   [rama_b2]="FIXWB=1 RAMA=1 BEATS=2"   [rama_b4]="FIXWB=1 RAMA=1 BEATS=4"
  [rama_b8]="FIXWB=1 RAMA=1 BEATS=8"   [rama_b16]="FIXWB=1 RAMA=1 BEATS=16" [rama_b32]="FIXWB=1 RAMA=1 BEATS=32"
  [rama_b64]="FIXWB=1 RAMA=1 BEATS=64")
ORDER="p3rx300fix optarama_fix optarama_tr rama_b1 rama_b2 rama_b4 rama_b8 rama_b16 rama_b32 rama_b64"
[ -n "${ONLY:-}" ] && ORDER=$ONLY
say() { echo "$(date '+%m-%d %H:%M') $*" | tee -a "$RES"; }
[ -n "${XILINX_XRT:-}" ] || { echo "source /opt/xilinx/xrt/setup.sh (and the Vitis settings64.sh) first"; exit 1; }
command -v v++ > /dev/null || { echo "source /tools/Xilinx/Vitis/2024.1/settings64.sh first"; exit 1; }
[ "${CHECK_ONLY:-0}" = 1 ] || [ -f "$ZIP" ] || { echo "package zip not found (ZIP=<path to fpga_zcu208_v14c_respfix_full.zip>)"; exit 1; }
for n in $ORDER; do [ -n "${ARGS[$n]:-}" ] || { echo "unknown design $n"; exit 1; }; done

beats_of() { echo "${ARGS[$1]}" | grep -oE "BEATS=[0-9]+" | cut -d= -f2; }

check() {   # check <name>: the card checks of one finished design (serialized by the card lock)
    local n=$1 d=$HOME/$1/fpga_zcu208/vitis b blk L
    b=$(beats_of "$n"); blk=$((b * 32)); L=$HOME/$n/check.log
    cd "$d" || return
    if [ ! -f doma_hw.xclbin ]; then say "$n: BUILD FAILED (no doma_hw.xclbin; see ~/$n/build.log)"; return; fi
    bash check_timing.sh > ../../timing.txt 2>&1; local t=$?
    if [ $t != 0 ] || grep -q "TIMING NOT CLOSED" ../../build.log; then
        say "$n: built, TIMING NOT CLOSED ($(grep -E 'kernel clock in|WNS=' ../../timing.txt | head -2 | tr '\n' ' ')): not measured"; return; fi
    say "$n: built, timing closed ($(grep -oE 'kernel clock in doma_hw.xclbin: [0-9.]+ MHz' ../../timing.txt))"
    [ -x host_phases ] || g++ -std=c++17 -O2 host_phases.cpp -I"$XILINX_XRT/include" -L"$XILINX_XRT/lib" -lxrt_coreutil -pthread -o host_phases
    (
      flock 9
      say "$n: card checks started"
      E="DOMA_LAMBDA=7 DOMA_NMAX=2097152 DOMA_PACK=1 DOMA_BLOCK=$blk"
      case $n in p3rx300fix) bash check_overlap_build.sh 4 > ../../overlap_build.txt 2>&1 \
                     && say "$n: overlap design present in the placed netlist" || say "$n: check_overlap_build.sh FAILED (~/$n/overlap_build.txt)";; esac
      # rate: GET / PUT / mix / GET
      env $E DOMA_N=4096 DOMA_HBM_PCT=20 DOMA_PHASES=get:$RATE_N,put:$RATE_N,mix:$RATE_N,get:$RATE_N ./host_phases doma_hw.xclbin 65536 > ../../rate.log 2>&1
      local cyc; cyc=$(grep -oE "^phase [0-9]+: .*device [0-9.]+ cycles per command" ../../rate.log | sed -E 's/.*device ([0-9.]+) cycles.*/\1/' | tr '\n' ' ')
      if [ "$(echo $cyc | wc -w)" = 4 ] && ! grep -qiE "wrong data|bad header|errors 0x[1-9a-f]" ../../rate.log; then
          python3 -c "import sys; v=[float(x) for x in sys.argv[1:]]; d=max(abs(x-v[0])/v[0] for x in v); print(f'{d*100:.3f}'); sys.exit(0 if d <= 0.002 else 1)" $cyc > ../../rate_dev.txt \
            && say "$n: RATE PASS: device cycles per command get / put / mix / get = $cyc(largest difference $(cat ../../rate_dev.txt)%)" \
            || say "$n: RATE FAIL: get / put / mix / get = $cyc(difference $(cat ../../rate_dev.txt)%, over 0.2%): the operation reaches the schedule"
      else say "$n: RATE run failed or a GET was wrong (~/$n/rate.log)"; fi
      # leak: the acceptance test (overlap)
      if [ "$n" = p3rx300fix ] && [ -x "$LEAK_HOST" ] && [ -f "$LEAK_PY" ]; then
          env DOMA_LAMBDA=7 DOMA_N=4096 DOMA_HBM_PCT=20 DOMA_PHASES=get:500000,put:500000,zero:500000,mix:500000,fixed:500000,rereq:500000,scan:500000,get:500000 \
              "$LEAK_HOST" doma_hw.xclbin 65536 > ../../leak_rate.log 2>&1
          python3 "$LEAK_PY" ../../leak_rate.log > ../../leak_check.txt 2>&1
          say "$n: LEAK acceptance: $(grep -E 'RATE DOES|RATE DEPENDS|ALL PHASES|PHASES? (WRONG|FAILED)' ../../leak_check.txt | tr '\n' ' ') (~/$n/leak_check.txt)"
      elif [ "$n" = p3rx300fix ]; then say "$n: LEAK acceptance skipped ($LEAK_HOST or $LEAK_PY not found)"; fi
      # kqps: the usual runs
      if [ "$n" != optarama_tr ]; then
          for p in 0 20 100; do
              env $E DOMA_N=$RUN_N DOMA_HBM_PCT=$p ./host_doma doma_hw.xclbin $RUN_REQ > ../../kqps_$p.log 2>&1
              say "$n: $p% on package: $(grep -oE '[0-9.]+ KQPS' ../../kqps_$p.log | tail -1), $(grep -E 'ALL RESPONSES CORRECT|ERRORS FOUND' ../../kqps_$p.log | tail -1)$(grep -qE 'HALT|halt record' ../../kqps_$p.log && echo ', HALT (see the log)')"
          done
      else   # phases: the per-phase cycles of the traced build
          env $E DOMA_N=$RUN_N DOMA_HBM_PCT=20 DOMA_PHASE_TRACE=1 DOMA_PHASES=mix:200000 ./host_phases doma_hw.xclbin 65536 > ../../phases.log 2>&1
          say "$n: phases at 20% on package: $(grep -E '^phase 1: phases, mean cycles' ../../phases.log | sed 's/^phase 1: //')"
      fi
      say "$n: card checks done"
    ) 9> "$LOCK"
}

build() {   # build <name>: its own copy, then build.sh; marks ST/<name>.built when it ends
    local n=$1
    if [ "${CHECK_ONLY:-0}" != 1 ]; then
        rm -rf "$HOME/$n"; mkdir -p "$HOME/$n"
        if ! (cd "$HOME/$n" && unzip -q "$ZIP"); then say "$n: unzip failed"; touch "$ST/$n.built"; return; fi
        local badf; badf=$(cd "$HOME/$n/fpga_zcu208" && sha256sum -c MANIFEST.sha256 2>/dev/null | grep -vc ': OK$')
        if [ "$badf" != 0 ]; then say "$n: $badf package files fail their checksum: not built"; touch "$ST/$n.built"; return; fi
        say "$n: build started (${ARGS[$n]})"
        ( cd "$HOME/$n/fpga_zcu208/vitis" && env ${ARGS[$n]} $COMMON bash build.sh ) > "$HOME/$n/build.log" 2>&1
        say "$n: build ended"
    fi
    touch "$ST/$n.built"
}

# the scheduler: at most JOBS builds at once, in ORDER; each finished build's card checks start at once (they queue on
# the card lock); ends when every design is built and checked
ST=$HOME/.respfix_state; rm -rf "$ST"; mkdir -p "$ST"
say "== start: $ORDER ($JOBS builds at once; card checks one at a time)"
set -- $ORDER; pending=("$@"); started=()
while :; do
    nb=0; for n in "${started[@]}"; do [ -f "$ST/$n.built" ] || nb=$((nb + 1)); done
    while [ "$nb" -lt "$JOBS" ] && [ "${#pending[@]}" -gt 0 ]; do
        n=${pending[0]}; pending=("${pending[@]:1}"); started+=("$n"); nb=$((nb + 1))
        build "$n" &
        sleep 2
    done
    left=0
    for n in "${started[@]}"; do
        if [ -f "$ST/$n.built" ] && [ ! -f "$ST/$n.chk" ]; then
            touch "$ST/$n.chk"; ( check "$n" > "$HOME/$n/check.log" 2>&1; touch "$ST/$n.done" ) &
        fi
        [ -f "$ST/$n.done" ] || left=$((left + 1))
    done
    [ "${#pending[@]}" = 0 ] && [ "$left" = 0 ] && break
    sleep "${POLL:-30}"
done
wait
say "== done: summary in $RES"
