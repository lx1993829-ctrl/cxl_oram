#!/usr/bin/env python3
"""check_rama.py LOG.csv [LOG.csv ...] -- Option A with the RAMA budgets (tb_doma_kernel +phase_log): every visible time
of every access is a fixed offset from its arrival, per class (on / off package): the write-back issue, the release and
the end; and the release (on package) is AR_REL_H after the arrival. Exit 0 only if all hold."""
import csv, sys
offs = {}; n = 0; ok = True
for f in sys.argv[1:]:
    for r in csv.DictReader(open(f)):
        r = {k: int(v) for k, v in r.items()}; n += 1
        for k in ('wb_issue', 'release', 'end'):
            offs.setdefault((r['hbm'], k), set()).add(r[k] - r['t_arr'])
for (h, k), s in sorted(offs.items()):
    cls = 'on package ' if h else 'off package'
    good = len(s) == 1
    ok &= good
    print(f"{'PASS' if good else 'FAIL'}  {cls} {k:9s} - arrival: {sorted(s)[:6]}{' ...' if len(s) > 6 else ''}")
print(f"check_rama: {n} accesses; " + ("every visible time a fixed offset from the arrival, per class" if ok else "NOT FIXED"))
sys.exit(0 if ok else 1)
