#!/bin/bash
# run_rama_sizes.sh -- the Option A + RAMA regression at every block size (build.sh FIXWB=1 RAMA=1: ORAM_ONPKG_FIXWB +
# ORAM_ONPKG_RAMA, the per-size budgets and write-back start of rtl/oram_params.vh), lambda 7, 4,096 records, under the
# RAMA-like stash model and card-like host / HBM tails:
#   - every response correct, scoreboard 0 wrong, no halt (GET/PUT mixes, 0/20/50/100% on package, one key repeated);
#   - every visible time a fixed offset from the arrival per class (check_rama.py): write-back issue, release, end;
#   - enforcement: under a stash 3x slower than the model (reads 600 cycles) the budgets are missed and the design
#     stops by a fail-stop halt, never a wrong answer;
#   - cycles per command at 0/50/100% on package (4 KB's comparison with Option A: sim/run_rama_base.sh).
#   bash run_rama_sizes.sh [sizes in beats]        default "1 2 4 8 16 32 64 128"
set -u
cd "$(dirname "$0")"
RTL=$(cd "${RTL_DIR:-../rtl}" && pwd); SIZES=${*:-"1 2 4 8 16 32 64 128"}; J=${J:-$(nproc)}; CMDS=${CMDS:-1500}
O=build/ramasz; mkdir -p $O
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
pass=0; fail=0; ok() { echo "PASS  $*"; pass=$((pass+1)); }; bad() { echo "FAIL  $*"; fail=$((fail+1)); }
build() { local d=$1 b=$2; shift 2
    [ -x $O/$d/V ] && return 0
    verilator --binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-BLKANDNBLK -I$RTL \
      -DORAM_BLOCK_BEATS=$b -DORAM_C=7 -DORAM_N=4096 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL "$@" \
      --top-module tb_doma_kernel tb_doma_kernel.v oram_timing_monitor.v axi_mem_model.v $SRCS $RTL/doma_kernel.v \
      -Mdir $O/$d -o V > $O/build_$d.log 2>&1 || { bad "build $d ($O/build_$d.log)"; return 1; }; }
H="+hb=0 +host_lat=480 +host_wlat=98 +host_slow_pct=3 +host_slow_extra=1500 +hbmb_slow_pct=3 +hbmb_slow_extra=300 +preload +cmds2=4"
RS="+stash_gap=40 +stash_pcs=390 +stash_idblk=0 +stash_lat=200 +stash_slow_pct=0"
SL="+stash_gap=40 +stash_pcs=390 +stash_idblk=0 +stash_lat=600 +stash_slow_pct=0"
clean() { grep -q "ALL CHECKS PASSED" $1 && grep -q "eviction scoreboard: .* 0 wrong" $1 && ! grep -q "DOMA HALT" $1; }
cyc() { grep -E "^run1: size=" $1 | sed -E 's/.*device total=([0-9]+) +completed=([0-9]+).*/\1 \2/' | awk '{if ($2) printf "%.0f", $1/$2}'; }
for b in $SIZES; do
    echo "== $((b * 32)) B ($b beats)"
    build r$b $b -DORAM_ONPKG_FIXWB -DORAM_ONPKG_RAMA || continue
    : > $O/jobs_$b.txt
    for d in r$b; do cat >> $O/jobs_$b.txt <<EOT
$d p0 $H $RS +hbm_pct=20 +cmds=$CMDS +put_pct=0 +seed=11
$d p100 $H $RS +hbm_pct=20 +cmds=$CMDS +put_pct=100 +seed=11
$d h0 $H $RS +hbm_pct=0 +cmds=$CMDS +put_pct=50 +seed=23
$d h50 $H $RS +hbm_pct=50 +cmds=$CMDS +put_pct=50 +seed=23
$d h100 $H $RS +hbm_pct=100 +cmds=$CMDS +put_pct=50 +seed=37
EOT
    done
    echo "r$b sk $H $RS +hbm_pct=50 +cmds=600 +same_key=600 +put_pct=50 +seed=7" >> $O/jobs_$b.txt
    echo "r$b slow $H $SL +hbm_pct=100 +cmds=600 +put_pct=50 +seed=29" >> $O/jobs_$b.txt
    O=$O xargs -P $J -L 1 bash -c 'd=$0; t=$1; shift 1; timeout 14400 ./$O/$d/V "$@" +phase_log=$O/pl_${d}_$t.csv > $O/${d}_$t.log 2>&1' < $O/jobs_$b.txt
    n=0; for t in p0 p100 h0 h50 h100 sk; do clean $O/r${b}_$t.log && n=$((n+1)) || bad "$((b*32)) B $t: Option A + RAMA run failed ($O/r${b}_$t.log)"; done
    [ $n = 6 ] && ok "$((b*32)) B: Option A + RAMA, 6 runs (GET/PUT mixes, 0/20/50/100% on package, one key x600): all responses correct, scoreboard 0 wrong, no halt"
    if python3 check_rama.py $(for t in p0 p100 h0 h50 h100 sk; do echo $O/pl_r${b}_$t.csv; done) > $O/check_$b.out 2>&1; then
        ok "$((b*32)) B: fixed offsets: $(tail -1 $O/check_$b.out); on package $(grep -E 'on package +(wb_issue|release|end)' $O/check_$b.out | grep -oE '\[[0-9]+\]' | tr '\n' ' ')"
    else bad "$((b*32)) B: fixed offsets"; cat $O/check_$b.out; fi
    l=$O/r${b}_slow.log
    if sed -n '1,/DOMA HALT/p' $l | grep -qE "data mismatch|not zero" || ! grep -q "eviction scoreboard: .* 0 wrong" $l; then bad "$((b*32)) B: wrong data under a 600-cycle stash ($l)"
    elif grep -q "DOMA HALT" $l; then ok "$((b*32)) B: enforcement: a 600-cycle stash misses the budgets and stops by a fail-stop halt, no wrong answer"
    else bad "$((b*32)) B: a 600-cycle stash did not trip the budgets (no halt): the enforcement case is not exercised"; fi
    for t in h0 h50 h100; do echo "      $t: Option A + RAMA $(cyc $O/r${b}_$t.log) device cycles per command"; done
done
echo "== $pass passed, $fail failed"; [ $fail = 0 ]
