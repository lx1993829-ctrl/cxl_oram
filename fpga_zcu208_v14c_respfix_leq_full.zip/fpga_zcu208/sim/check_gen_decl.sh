#!/bin/bash
# check_gen_decl.sh -- Vivado-only hazard check: a name used inside a generate block but declared only further down in
# the module. Verilator and Yosys resolve it to the module's declaration; Vivado makes an undriven net local to the
# generate block (Synth 8-3848 "does not have driver"), so the design runs correctly in every simulation and wrongly on
# the card (overlap step 2, round 2: every eviction copy into the scratch dropped, GETs returned zeros).
# Every RTL file, preprocessed as Vivado sees it (SYNTHESIS) in each build configuration. Exit 0 only if none is found.
set -u
cd "$(dirname "$0")"; RTL=$(cd "${1:-../rtl}" && pwd); T=$(mktemp -d); bad=0
B="-DORAM_BLOCK_BEATS=128 -DORAM_C=7 -DORAM_N=2097152 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -DSYNTHESIS"
for cfg in "v14d1:" "fixwb:-DORAM_ONPKG_FIXWB" "trace:-DORAM_PHASE_TRACE" "debug:-DORAM_PHASE_TRACE -DORAM_ONPKG_DEBUG" \
           "designB:-DORAM_STASH_PC_IDS" "step1:-DORAM_OVERLAP2" "step2:-DORAM_OVERLAP2 -DORAM_OVERLAP4" "step2p3:-DORAM_OVERLAP2 -DORAM_OVERLAP4 -DORAM_OV4_P3"; do
    n=${cfg%%:*}; x=${cfg#*:}
    for f in $RTL/*.v; do
        verilator -E -P -I$RTL $B $x $f > $T/pp.v 2>/dev/null || continue
        # drop the tool's false hits: keywords and literal suffixes taken as names
        r=$(python3 check_gen_decl_one.py $T/pp.v | grep -vE "'(wire|reg|d0|h[0-9a-fA-F]+|b[01]+)' declared")
        [ -n "$r" ] && { echo "FAIL $n $(basename $f):"; echo "$r" | sed 's/^/    /'; bad=1; }
    done
done
rm -rf $T
[ $bad = 0 ] && echo "PASS no name used in a generate block before its declaration (8 configurations, every RTL file)"
exit $bad
