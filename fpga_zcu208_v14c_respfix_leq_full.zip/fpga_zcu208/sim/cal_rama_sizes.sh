#!/bin/bash
# cal_rama_sizes.sh -- simulation calibration of the Option A + RAMA on-package budgets per block size (docs section
# "RAMA at every size"). Per size: the debug + trace build (never halts, one record per access, the card's format),
# serial design, lambda 7, the stash with RAMA's behaviour (no single-ID ordering across pseudo-channels) at a
# conservative latency profile, on-package shares 100% and 20%, PUT/GET mixes; then sim/card_budgets.py prints the
# worst write-back start (ws), release gate (rg), write time, first W and hold per size.
#   bash cal_rama_sizes.sh [sizes in beats]        default "128 1 2 4 8 16 32 64" (128 first: the check against the card)
#   PROF=card|slow   card: stash reads 120 cycles (the regression's RAMA model); slow (default): 200 cycles, the card's
#                    worst measured HBM read, with 3% of reads 300 cycles slower
#   CMDS=2000 SEEDS="11 23"
set -u
cd "$(dirname "$0")"
RTL=$(cd "${RTL_DIR:-../rtl}" && pwd); SIZES=${*:-"128 1 2 4 8 16 32 64"}; PROF=${PROF:-slow}; CMDS=${CMDS:-2000}
SEEDS=${SEEDS:-"11 23"}; J=${J:-$(nproc)}
O=build/calrama_$PROF; B=build/calrama_bin; mkdir -p $O $B
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
case $PROF in
  card) ST="+stash_gap=40 +stash_pcs=390 +stash_idblk=0 +stash_lat=120 +stash_slow_pct=0" ;;
  slow) ST="+stash_gap=40 +stash_pcs=390 +stash_idblk=0 +stash_lat=200 +stash_slow_pct=3 +stash_slow_extra=300" ;;
  rama) ST="+stash_gap=40 +stash_pcs=390 +stash_idblk=0 +stash_lat=200 +stash_slow_pct=0" ;;   # RAMA: no ordering across channels
  desa) ST="+stash_gap=40 +stash_pcs=390 +stash_idblk=1 +stash_lat=200 +stash_slow_pct=0" ;;   # design A today: one ID in order
  *) echo "PROF card|slow|rama|desa"; exit 2 ;;
esac
H="+hb=0 +host_lat=480 +host_wlat=98 +host_slow_pct=3 +host_slow_extra=1500 +hbmb_slow_pct=3 +hbmb_slow_extra=300 +preload +cmds2=4 +phase_trace"
for b in $SIZES; do
  if [ ! -x $B/b$b/V ]; then
    verilator --binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-BLKANDNBLK -I$RTL \
      -DORAM_BLOCK_BEATS=$b -DORAM_C=7 -DORAM_N=4096 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -DORAM_PHASE_TRACE -DORAM_ONPKG_DEBUG \
      --top-module tb_doma_kernel tb_doma_kernel.v oram_timing_monitor.v axi_mem_model.v $SRCS $RTL/doma_kernel.v \
      -Mdir $B/b$b -o V > $B/build_b$b.log 2>&1 && echo "built b$b ($(date +%T))" || { echo "BUILD FAILED b$b ($B/build_b$b.log)"; exit 1; }
  fi
  : > $O/jobs_b$b.txt
  for s in $SEEDS; do for p in 100 20; do
    echo "b$b p${p}s$s $H $ST +hbm_pct=$p +cmds=$CMDS +put_pct=50 +seed=$s +dbg_csv=$O/b$b/rec_p${p}s$s.csv" >> $O/jobs_b$b.txt
  done; done
  mkdir -p $O/b$b
  B=$B O=$O xargs -P $J -L 1 bash -c 'b=$0; t=$1; shift 1; timeout 7200 ./$B/$b/V "$@" > $O/${b}_$t.log 2>&1' < $O/jobs_b$b.txt
  bad=0; for l in $O/b${b}_*.log; do grep -q "ALL CHECKS PASSED" $l && ! grep -q "DOMA HALT" $l || { echo "  run failed: $l"; bad=1; }; done
  python3 card_budgets.py --beats $b --pct 20 --abs 74 --mhz 300 --params $RTL/oram_params.vh $O/b$b/rec_*.csv > $O/budgets_b$b.txt 2>&1
  echo "b$b ($((b * 32)) B): runs $([ $bad = 0 ] && echo clean || echo FAILED); $(grep -E '^SUMMARY' $O/budgets_b$b.txt) ($(date +%T))"
done
