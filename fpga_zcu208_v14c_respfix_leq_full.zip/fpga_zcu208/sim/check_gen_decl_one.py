import re, sys
# identifiers used inside a generate block before their (module-level) declaration: Vivado makes them implicit nets
# local to the generate scope (Synth 8-3848 "does not have driver"); simulators resolve them to the later declaration
txt = open(sys.argv[1]).read()
txt = re.sub(r'//.*', '', txt); txt = re.sub(r'/\*.*?\*/', '', txt, flags=re.S); txt = re.sub(r'"[^"\n]*"', '""', txt)
L = txt.split('\n')
decl_re = re.compile(r'^\s*(?:output\s+|input\s+|inout\s+)?(wire|reg|integer|localparam|genvar|parameter)\b(.*)')
KW = {'begin','end','if','else','for','assign','always','wire','reg','integer','signed','genvar','localparam','parameter','input','output','inout','generate','endgenerate','case','endcase','function','endfunction','posedge','negedge','or','and','not','module','endmodule'}
decl = {}
for i, l in enumerate(L):
    md = decl_re.match(l)
    if md:
        body = re.sub(r'\[[^\]]*\]', ' ', md.group(2)); body = re.sub(r'=.*?(,|;)', r'\1', body)
        for idn in re.findall(r'\b([A-Za-z_]\w*)\b', body):
            if idn in KW: continue
            decl.setdefault(idn, i)
depth = 0; out = set()
for i, l in enumerate(L):
    if re.search(r'\bgenerate\b', l): depth += 1
    if depth > 0:
        for idn in re.findall(r'\b([A-Za-z_]\w*)\b', l):
            if idn in decl and decl[idn] > i: out.add((i + 1, decl[idn] + 1, idn, l.strip()[:120]))
    if re.search(r'\bendgenerate\b', l): depth -= 1
for o in sorted(out): print(f"line {o[0]}: '{o[2]}' declared at line {o[1]}: {o[3]}")
