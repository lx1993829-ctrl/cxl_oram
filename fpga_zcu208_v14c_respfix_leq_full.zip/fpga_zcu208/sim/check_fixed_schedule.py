#!/usr/bin/env python3
"""check_fixed_schedule.py [--p P] [--deq D] dump [dump ...]   (dumps from tb_doma_kernel +fix_dump=<file>)

The overlap builds' fixed-schedule check: nothing visible may depend on the keys, the data or the stash state.
Per run (one dump):
  1. Shape: every access's visible times relative to its start, with the public same-bucket shift taken out, are the
     same for every off-package access, and the same for every on-package access (one hash per class).
  2. Start rule: every start is s(j) = max(r(j) + K1, s(j-1) + P + (eq(j-1) ? D_EQ : 0) + K2), with r(j) the cycle its
     request was first presented, eq the public bucket-equality flag, and K1, K2 two constants of the design
     (learned from the run, then required of every access).
Across the runs given together (same memory latencies): the per-class shapes must be equal in every run, so a
stream of one repeated key, two alternating keys or random keys shows the same visible times.
Needs a testbench without random memory gaps (+hb=0), where the memories' latencies are fixed.
--ctx N (step 2, two bucket reads in flight): the class is also keyed by the earlier N accesses' public facts (on or off
package, same-bucket flag). Reads return in issue order on one port, so an access's arrival can depend on whether the
read before it was still arriving: a memory latency of a public bucket location. Every access with the same public key
must still show one shape, the same in every run.
Exit 0 only if every check passes."""
import sys, collections

args = sys.argv[1:]
P, DEQ, CTX = 1500, 3600, 0
while args and args[0].startswith('--'):
    k = args.pop(0)
    if k == '--p': P = int(args.pop(0))
    elif k == '--deq': DEQ = int(args.pop(0))
    elif k == '--ctx': CTX = int(args.pop(0))
ok = True
glob = collections.defaultdict(dict)       # class -> {shape: [runs]}
for fn in args:
    rows = []
    for l in open(fn):
        f = l.split()
        if len(f) >= 6:                     # (step 2 builds add six phase 3 fields after these: ignored here)
            rows.append((int(f[0]), int(f[1]), int(f[2]), int(f[3]), int(f[4]), f[5]))
    rows.sort()
    if not rows:
        print(f"FAIL {fn}: no accesses recorded"); ok = False; continue
    run_ok = True
    # 1. one shape per class
    cls = collections.defaultdict(collections.Counter)
    pub = {i: (hbm, eq) for i, s, r, eq, hbm, h in rows}
    def key(i, hbm, eq):
        if CTX == 0: return hbm
        return (hbm, eq) + sum((pub.get(i - k, (-1, -1)) for k in range(1, CTX + 1)), ())
    def kname(k):
        if CTX == 0: return 'on-package' if k else 'off-package'
        f = lambda c: {1: 'on', 0: 'off', -1: '-'}[c[0]] + ('=' if c[1] == 1 else '')
        return f(k[:2]) + ' after ' + ','.join(f(k[2 + 2 * j: 4 + 2 * j]) for j in range(CTX))
    for i, s, r, eq, hbm, h in rows: cls[key(i, hbm, eq)][h] += 1
    for hbm, c in sorted(cls.items()):
        name = kname(hbm)
        if len(c) != 1:
            ok = False; run_ok = False
            print(f"FAIL {fn}: {name}: {len(c)} different visible shapes over {sum(c.values())} accesses: " +
                  ', '.join(f"{h} x{n}" for h, n in c.most_common(4)))
        h = next(iter(c))
        glob[name].setdefault(h, []).append(fn)
    # 2. start rule (consecutive accesses only: a gap in the order means an access did not complete in the record)
    k1 = k2 = None; bad = []; n_chk = 0
    by = {i: (s, r, eq) for i, s, r, eq, hbm, h in rows}
    seq = sorted(by)
    for i in seq:
        s, r, eq = by[i]
        if i - 1 not in by:
            continue
        sp, rp, eqp = by[i - 1]
        need = sp + P + (DEQ if eqp else 0)
        # learn: a request presented before the previous start + need waited for the spacing; a later one did not
        if k2 is None and r + 50 < need: k2 = s - need
        if k1 is None and r > need + 50: k1 = s - r
    for i in seq:
        s, r, eq = by[i]
        if i - 1 not in by: continue
        sp, rp, eqp = by[i - 1]
        need = sp + P + (DEQ if eqp else 0)
        exp = max(r + (k1 if k1 is not None else -10**9), need + (k2 if k2 is not None else -10**9))
        n_chk += 1
        if s != exp: bad.append((i, s, exp, r - sp, eqp))
    if bad:
        ok = False; run_ok = False
        print(f"FAIL {fn}: start rule broken at {len(bad)} of {n_chk} accesses (K1={k1}, K2={k2}); first: " +
              '; '.join(f"access {i} started {s}, rule {e} (request {d} after the previous start, previous same-bucket {q})"
                        for i, s, e, d, q in bad[:3]))
    if run_ok:
        print(f"PASS {fn}: {len(rows)} accesses; " +
              (', '.join(f"{'on' if hbm else 'off'}-package one shape x{sum(c.values())}" for hbm, c in sorted(cls.items())) if CTX == 0
               else f"{len(cls)} public classes (with {CTX} earlier accesses), one shape each, {len(set(h for c in cls.values() for h in c))} shapes in all") +
              f"; start rule exact at {n_chk} starts (K1={k1}, K2={k2}, same-bucket shifts {sum(1 for x in rows if x[3])})")
for name, d in sorted(glob.items()):
    if len(d) > 1:
        ok = False
        print(f"FAIL across runs: {name} shape differs: " + '; '.join(f"{h}: {', '.join(v)}" for h, v in d.items()))
    elif len(args) > 1:
        print(f"PASS across runs: {name} shape identical in {len(next(iter(d.values())))} runs")
sys.exit(0 if ok else 1)
