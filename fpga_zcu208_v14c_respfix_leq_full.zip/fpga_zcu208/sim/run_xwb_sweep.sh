#!/bin/bash
# run_xwb_sweep.sh -- how far the phase 3 overlap allowance (ORAM_OV4_XWB, default 700; the on-package release
# allowance ORAM_OV4_XREL_H follows it at +700) can come down with the stash on RAMA. Phase 3 at the p3r1600 settings
# (start spacing 1,600, arrival spacing 1,600, LEQ and L at their defaults, which follow the budgets), card-like host
# reads (480 cycles, 15% gaps, 5% of bursts 3,400 slower), a RAMA-like stash (no same-ID blocking across channels),
# 4 KB, lambda 7. For each allowance: 0%, 20%, 50% and 100% on package, preload + 3 launches x 900 commands, every GET
# checked; a run that misses a budget fail-stops, and its halt names the deadline. Also the throughput.
# Usage: XS="700 500 400 300 200" bash run_xwb_sweep.sh [jobs]
set -u
cd "$(dirname "$0")"
RTL=$(cd "${RTL_DIR:-../rtl}" && pwd); J=${1:-$(nproc)}; XS=${XS:-"700 500 400 300 200"}
O=build/xwb; mkdir -p $O
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
for x in $XS; do
    [ -x $O/x$x/V ] && continue
    verilator --binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -I$RTL \
      -DORAM_BLOCK_BEATS=128 -DORAM_C=7 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -Wno-BLKANDNBLK \
      -DORAM_OVERLAP2 -DORAM_OVERLAP4 -DORAM_OV4_P3 -DORAM_OV_PMIN=1600 -DORAM_OV_CT_RD=600 -DORAM_OV4_GA=1600 \
      -DORAM_OV4_LEQ=0 -DORAM_OV4_L=0 -DORAM_OV4_XWB=$x -DORAM_OV4_XREL_H=$((x + 700)) \
      --top-module tb_doma_kernel tb_doma_kernel.v oram_timing_monitor.v axi_mem_model.v $SRCS $RTL/doma_kernel.v \
      -Mdir $O/x$x -o V > $O/build_x$x.log 2>&1 && echo "built XWB $x" || { echo "BUILD FAILED x$x"; exit 1; }
done
M="+hb=0 +host_lat=480 +host_wlat=98 +host_slow_pct=5 +host_slow_extra=3400 +host_gap=15 +hbmb_slow_pct=3 +hbmb_slow_extra=1200"
RS="+stash_gap=40 +stash_pcs=390 +stash_idblk=0 +stash_lat=120 +stash_slow_pct=0"
: > $O/jobs.txt
for x in $XS; do for h in 0 20 50 100; do
    echo "x$x h$h $M $RS +hbm_pct=$h +preload +seed=$((h + 3)) +cmds=900 +launches=3 +cmds2=4 +put_pct=50" >> $O/jobs.txt
done; done
echo "== $(wc -l < $O/jobs.txt) runs, $J at a time ($(date +%H:%M))"
O=$O xargs -P $J -L 1 bash -c 'b=$0; t=$1; shift 1; [ -f $O/${b}_$t.log ] && grep -q "Verilog \$finish\|ALL CHECKS PASSED\|DOMA HALT" $O/${b}_$t.log && exit 0; timeout 14400 ./$O/$b/V "$@" > $O/${b}_$t.log 2>&1; echo "  done $b $t $(date +%H:%M)"' < $O/jobs.txt
echo "== results (XWB: per placement: clean or the halt; device cycles per command of run1)"
for x in $XS; do
    line="XWB $x:"; allok=1
    for h in 0 20 50 100; do l=$O/x${x}_h$h.log
        if grep -q "ALL CHECKS PASSED" $l && ! grep -q "DOMA HALT" $l; then
            c=$(grep -E "^(run1|runL): size=" $l | sed -E 's/.*device total=([0-9]+) +completed=([0-9]+).*/\1 \2/' | awk '{d+=$1; n+=$2} END {if (n) printf "%.0f cyc/cmd", d/n}')
            line="$line  ${h}%: clean ${c}"
        else allok=0; line="$line  ${h}%: $(grep -m1 -oE 'DOMA HALT[^|]*' $l | cut -c1-90 || echo FAILED)"; fi
    done
    echo "$line"; [ $allok = 1 ] && echo "      -> XWB $x: every run clean"
done
