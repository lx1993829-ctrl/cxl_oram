#!/bin/bash
# run_rama_base.sh -- Option A with the RAMA on-package budgets (build.sh RAMA=1: ORAM_ONPKG_RAMA, AR_REL_H 1669,
# AR_DONE_H 2103) under a RAMA-like stash model (no same-ID blocking across channels: +stash_idblk=0), 4 KB, lambda 7,
# 4,096 records: every response correct, no halt, every visible time a fixed offset from the arrival per class
# (check_rama.py), off-package times as Option A's; and enforcement: under design A's card-like stash (same-ID
# blocking) the lower budgets are missed and Option A stops by a fail-stop halt, never a wrong answer.
set -u
cd "$(dirname "$0")"
RTL=$(cd "${RTL_DIR:-../rtl}" && pwd); J=${1:-$(nproc)}
O=build/rama; mkdir -p $O
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
pass=0; fail=0; ok() { echo "PASS  $*"; pass=$((pass+1)); }; bad() { echo "FAIL  $*"; fail=$((fail+1)); }
build() { local d=$1; shift
    verilator --binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -I$RTL \
      -DORAM_BLOCK_BEATS=128 -DORAM_C=7 -DORAM_N=4096 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -DORAM_ONPKG_FIXWB -Wno-BLKANDNBLK "$@" \
      --top-module tb_doma_kernel tb_doma_kernel.v oram_timing_monitor.v axi_mem_model.v $SRCS $RTL/doma_kernel.v \
      -Mdir $O/$d -o V > $O/build_$d.log 2>&1 && echo "built $d" || { echo "BUILD FAILED $d ($O/build_$d.log)"; exit 1; }; }
echo "== building"; build fix; build fixr -DORAM_ONPKG_RAMA
H="+hb=0 +host_lat=401 +host_wlat=98 +preload +cmds2=4"
RS="+stash_gap=40 +stash_pcs=390 +stash_idblk=0 +stash_lat=120 +stash_slow_pct=0"     # RAMA-like stash
CS="+stash_gap=40 +stash_pcs=390 +stash_idblk=1 +stash_lat=120 +stash_slow_pct=0"     # design A's card-like stash
: > $O/jobs.txt
for b in fix fixr; do cat >> $O/jobs.txt <<EOT
$b p0 $H $RS +hbm_pct=20 +cmds=1500 +put_pct=0 +seed=11
$b p100 $H $RS +hbm_pct=20 +cmds=1500 +put_pct=100 +seed=11
$b h0 $H $RS +hbm_pct=0 +cmds=1000 +seed=23
$b h50 $H $RS +hbm_pct=50 +cmds=1500 +seed=23
$b h100 +hb=0 +preload +cmds2=4 $RS +hbm_pct=100 +cmds=1500 +seed=37
$b sk $H $RS +hbm_pct=50 +cmds=600 +same_key=600 +put_pct=50 +seed=7
EOT
done
echo "fixr csA $H $CS +hbm_pct=50 +cmds=1500 +seed=23" >> $O/jobs.txt
echo "== running $(wc -l < $O/jobs.txt) runs, $J at a time"
O=$O xargs -P $J -L 1 bash -c 'b=$0; t=$1; shift 1; timeout 14400 ./$O/$b/V "$@" +phase_log=$O/pl_${b}_$t.csv > $O/${b}_$t.log 2>&1; echo "  done $b $t"' < $O/jobs.txt
echo "== checks"
clean() { grep -q "ALL CHECKS PASSED" $1 && grep -q "eviction scoreboard: .* 0 wrong" $1 && ! grep -q "DOMA HALT" $1; }
for t in p0 p100 h0 h50 h100 sk; do
    clean $O/fixr_$t.log && ok "$t: Option A + RAMA budgets: all responses correct, scoreboard 0 wrong, no halt" || bad "$t: run failed ($O/fixr_$t.log)"
    clean $O/fix_$t.log || bad "$t: Option A (default budgets) run failed ($O/fix_$t.log)"
done
python3 check_rama.py $(for t in p0 p100 h0 h50 h100 sk; do echo $O/pl_fixr_$t.csv; done) > $O/check_rama.out 2>&1 \
    && ok "fixed offsets: $(tail -1 $O/check_rama.out)" || { bad "fixed offsets"; cat $O/check_rama.out; }
grep -E "on package +release|on package +end" $O/check_rama.out | sed 's/^/      /'
python3 check_rama.py $(for t in p0 p100 h0 h50 h100 sk; do echo $O/pl_fix_$t.csv; done) | grep -E "on package +(release|end)" | sed 's/^/      Option A default budgets: /'
for t in h0 h50 h100; do a=$(grep -oE "device [0-9]+ cycles|cycles per command [0-9.]+|[0-9.]+ cycles per command" $O/fix_$t.log | head -1); b=$(grep -oE "device [0-9]+ cycles|cycles per command [0-9.]+|[0-9.]+ cycles per command" $O/fixr_$t.log | head -1); echo "      $t: Option A $a; with RAMA budgets $b"; done
l=$O/fixr_csA.log
if sed -n '1,/DOMA HALT/p' $l | grep -qE "data mismatch|not zero" || ! grep -q "eviction scoreboard: .* 0 wrong" $l; then bad "csA: wrong data under a slower stash ($l)"
elif grep -q "DOMA HALT" $l; then ok "enforcement: under design A's stash the RAMA budgets are missed and Option A stops by a fail-stop halt: $(grep -m1 'DOMA HALT' $l | cut -c1-110)"
else ok "csA: design A's stash also fits the RAMA budgets in this run (no halt, all correct)"; fi
echo "== $pass passed, $fail failed"; [ $fail = 0 ]
