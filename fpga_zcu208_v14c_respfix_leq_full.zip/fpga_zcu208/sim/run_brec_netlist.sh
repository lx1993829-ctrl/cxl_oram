#!/bin/bash
# run_brec_netlist.sh -- the bucket record unit (rtl/bucket_rec_hbm.v: one open record, a write FIFO, IV/tag reads) as
# its Yosys gate netlist, against tb_brec.v's reference model: every metadata and IV/tag read, the late-landing phase
# and the open-versus-IV/tag-write races (2026-11-06, docs section 20). Exit 0 only if all pass.
set -u
cd "$(dirname "$0")"
RTL=$(cd "${1:-../rtl}" && pwd); O=build/brecnet; mkdir -p $O
command -v yosys > /dev/null || { echo "NETLIST brec: SKIPPED (yosys not on PATH)"; exit 3; }
cat > $O/synth.ys <<YS
read_verilog -sv -DSYNTHESIS -DORAM_BLOCK_BEATS=128 -DORAM_C=7 -I $RTL $RTL/bucket_rec_hbm.v
hierarchy -top bucket_rec_hbm
proc; flatten; opt -full; memory -nomap; opt -full; techmap; opt -fast
abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX
opt_clean
rename bucket_rec_hbm bucket_rec_hbm_net
write_verilog -noattr $O/brec_netlist.v
YS
yosys -q -l $O/synth.log $O/synth.ys > /dev/null 2>&1 || { echo "NETLIST brec: synthesis failed ($O/synth.log)"; exit 2; }
verilator --binary --timing -j 0 -O1 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-UNOPTFLAT \
    -I$RTL -DORAM_BLOCK_BEATS=128 -DORAM_C=7 -DBREC_NET --top-module tb_brec tb_brec.v axi_mem_model.v $O/brec_netlist.v \
    -Mdir $O/obj -o V > $O/build.log 2>&1 || { echo "NETLIST brec: testbench build failed ($O/build.log)"; exit 2; }
./$O/obj/V > $O/run.log 2>&1
if grep -q "BUCKET_REC_HBM: ALL CHECKS PASSED" $O/run.log; then echo "NETLIST brec: PASS  $(grep -oE '[0-9]+ checks, [0-9]+ mismatches' $O/run.log)"; exit 0
else echo "NETLIST brec: FAIL ($O/run.log)"; grep FAIL $O/run.log | head -3; exit 1; fi
