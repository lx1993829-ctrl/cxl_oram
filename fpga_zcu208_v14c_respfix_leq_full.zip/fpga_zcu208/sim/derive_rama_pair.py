#!/usr/bin/env python3
"""derive_rama_pair.py RAMA_DIR DESA_DIR [beats ...] -- the Option A + RAMA on-package budgets per block size, from paired
simulation runs (sim/cal_rama_sizes.sh PROF=rama and PROF=desa: the same seeds, the same 200-cycle stash reads, the
card's worst measured HBM read; only the stash's ordering differs: RAMA's independent channels against today's single
in-order ID). The debug build's per-access records give, over on-package accesses, cycles after the arrival:
  ws (write-back start), wfh = max(ws, first W + hold) (what Option A's fixed start must cover), rg (release gate).
RAMA's gain is D_wb = max(0, wfh(desa) - wfh(rama)), D_rel = max(0, rg(desa) - rg(rama)). The budgets keep each size's
card-proven lambda 7 values and take off only that gain, never going below the RAMA run's own worst + 74:
  AR_WB_H(RAMA)  = max(AR_WB_H - D_wb,  wfh(rama) + 74)            = WBF, Option A's fixed write-back start
  AR_REL_H(RAMA) = max(AR_REL_H - D_rel, rg(rama) + 74, AR_WB_H(RAMA) + (AR_REL_H - AR_WB_H))   the write's allowance kept
  AR_DONE_H(RAMA)= AR_REL_H(RAMA) + (AR_DONE_H - AR_REL_H)          the acknowledgement allowance kept
4 KB keeps its card calibration (440 / 1669 / 2103); its paired runs are printed as the check of the method."""
import csv, glob, os, re, sys
ra, de = sys.argv[1], sys.argv[2]; sizes = [int(x) for x in sys.argv[3:]] or [1, 2, 4, 8, 16, 32, 64, 128]
par = open(os.environ.get('PARAMS', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'rtl', 'oram_params.vh'))).read()
def dflt(name, b):
    v = re.findall(r'`define\s+ORAM_%s_L7_B%d\s+(\d+)' % (name, b), par); return int(v[-1])   # the last: non-RAMA for 4 KB
def worst(d, b):
    n = 0; ws = rg = wfh = 0
    for f in sorted(glob.glob(f"{d}/b{b}/rec_*.csv")):
        for r in csv.DictReader(open(f)):
            fl = int(r['flags'])
            if not (fl & 1 and fl & 2): continue
            if 65535 in (int(r['ea']), int(r['dg']), int(r['wf']), int(r['wl'])): continue
            t = int(r['tarr']); rel = lambda k: (int(r[k]) - t) & 0xFFFF
            a, g, f1, l1 = rel('ea'), rel('dg'), rel('wf'), rel('wl'); h = max(0, l1 - f1 + 1 - 8 * b)
            n += 1; ws = max(ws, a); rg = max(rg, g); wfh = max(wfh, a, f1 + h)
    return n, ws, wfh, rg
print(f"{'size':>7} | {'RAMA: acc   ws  wfh   rg':>24} | {'today: acc   ws  wfh   rg':>25} | {'D_wb':>5} {'D_rel':>5} | defaults WB/REL/DONE | RAMA WB(=WBF)/REL/DONE  saved")
out = []
for b in sizes:
    r = worst(ra, b); d = worst(de, b)
    if r[0] == 0 or d[0] == 0: print(f"{b*32:>5} B: missing records (rama {r[0]}, today {d[0]})"); continue
    dw, dr, dd = dflt('AR_WB_H', b), dflt('AR_REL_H', b), dflt('AR_DONE_H', b)
    Dwb = max(0, d[2] - r[2]); Drel = max(0, d[3] - r[3])
    if b == 128: wb, rel, done = 440, 1669, 2103
    else:
        wb = max(dw - Dwb, r[2] + 74); rel = max(dr - Drel, r[3] + 74, wb + (dr - dw)); done = rel + (dd - dr)
        if wb > dw or rel > dr: print(f"  note {b*32} B: the RAMA run's worst + 74 is above the card-proven defaults; the defaults are kept")
        wb, rel, done = min(wb, dw), min(rel, dr), min(done, dd)                  # never above the card-proven values
    out.append((b, wb, rel, done))
    print(f"{b*32:>5} B | {r[0]:>8} {r[1]:>4} {r[2]:>4} {r[3]:>4} | {d[0]:>9} {d[1]:>4} {d[2]:>4} {d[3]:>4} | {Dwb:>5} {Drel:>5} | {dw:>6}/{dr}/{dd} | {wb:>8}/{rel}/{done}  {dd - done:>5}")
print("RESULT " + " ".join(f"B{b}:{wb}/{rel}/{done}" for b, wb, rel, done in out))
