// axi_mem_model.v -- AXI4 slave memory for the doma_kernel testbench (simulation only).
// INCR bursts, up to 16 reads outstanding (each served RLAT cycles after its address),
// optional random read-data gaps, write data accepted before its address (W FIFO).
`timescale 1ns/1ps
module axi_mem_model #(
    parameter integer WF_DEPTH = 1024,   // write beats buffered until they land (limit: depth - 24)
    parameter integer DW    = 256,
    parameter integer WORDS = 65536,             // memory size in DW-bit words
    parameter [63:0]  BASE  = 64'd0,             // byte address of word 0
    parameter integer RLAT  = 40                 // cycles from address to first read beat
) (
    input  wire              clk,
    input  wire              rst_n,              // the bus is ignored while reset is held, as a real interconnect does
    input  wire [63:0]       araddr,  input wire [7:0] arlen, input wire arvalid, output wire arready,
    output reg  [DW-1:0]     rdata,   output wire [1:0] rresp, output reg rlast, output reg rvalid, input wire rready,
    input  wire [1:0]        arid,    output reg  [1:0] rid,     // v14d: used only with id_ooo (otherwise rid = 0)
    input  wire [63:0]       awaddr,  input wire [7:0] awlen, input wire awvalid, output wire awready,
    input  wire [DW-1:0]     wdata,   input wire [DW/8-1:0] wstrb, input wire wlast, input wire wvalid, output wire wready,
    output wire [1:0]        bresp,   output reg bvalid, input wire bready
);
    reg [DW-1:0] mem [0:WORDS-1];
    integer      lat = RLAT;             // may be changed by the testbench
    integer      gap_pct = 0;            // percent of cycles with no read beat
    // HBM-like latency: slow_pct percent of reads take slow_extra more cycles (refresh, row
    // conflicts). The U55C's HBM measured ~98% near 55 cycles and the rest near 160.
    integer      slow_pct = 0, slow_extra = 0, lat_seed = 1;
    integer      wlat = 0;               // cycles before a write lands; reads meanwhile see the old data
    integer      rdy_gap = 0;            // percent of cycles on which arready/awready/wready are held low
    integer      w_hold = 0;             // v14: wready held low for this many cycles after every write address (slow writes)
    integer      w_hold_n = 0;
    // v14b, HBM-like behaviour (default off: the model as before). b_early: a write's B as soon as its data is in and its
    // address accepted (the card's HBM controllers acknowledge a write when they queue it), while it lands wlat cycles
    // later; rd_wait_wr: a read is served only once every write accepted before it has landed (the controller keeps a
    // read behind the writes queued ahead of it on the channel), its latency counted from then; w_lead >= 0: W beats are
    // refused while the beats received exceed the accepted addresses' beats by w_lead (0: no W before its AW).
    integer      b_early = 0, rd_wait_wr = 0, w_lead = -1;
    integer      land_tot = 0, eb_n = 0;     // write bursts landed since reset; bursts in the queue already acknowledged (b_early)
    reg [31:0]   aw_q = 0, land_q = 0;       // the same, registered: what the read side sees (no same-cycle race between the blocks)
    always @(posedge clk) begin aw_q <= aw_q + ((awvalid && awready) ? 1 : 0); land_q <= land_tot; end
    integer      perr = 0;               // AXI protocol violations seen (wlast framing, 4 KB crossing)
    // v14d, HBM pseudo-channels (default off: the model as before). pc_bytes > 0: byte offset / pc_bytes is the read's
    // pseudo-channel (XRT concatenates a port's channels, no interleaving). id_block: the port drives ONE AXI ID, and
    // the HBM switch keeps same-ID reads in order across channels (PG276: same-ID transactions are blocked on a channel
    // level; each memory controller returns its own commands independently), so a read to another channel than the
    // reads still outstanding starts its latency only once they have all returned; later reads queue behind it.
    // pc_cap_x100 > 0: a channel delivers at most pc_cap_x100 / 100 bytes per cycle (14.4 GB/s at 300 MHz: 4800).
    integer      pc_bytes = 0, id_block = 0, pc_cap_x100 = 0;
    integer      pc_credit [0:63];
    integer      blk_n = 0, cap_n = 0;   // reads that waited for a channel change; beats held by a channel cap
    integer      pci;
    initial for (pci = 0; pci < 64; pci = pci + 1) pc_credit[pci] = 0;
    function integer pc_of; input [63:0] a; begin pc_of = (pc_bytes > 0) ? ((a - BASE) / pc_bytes) % 64 : 0; end endfunction
    reg          ar_blk = 0, aw_blk = 0, w_blk = 0;
    // Deterministic pseudo-random draws (xorshift32): identical on every simulator version. Verilator's $random sequence
    // changed between releases, which changed the stimulus and with it the calibrated timing budgets.
    function [31:0] xs32; input [31:0] x; reg [31:0] y; begin
        y = (x == 32'd0) ? 32'h2545F491 : x; y = y ^ (y << 13); y = y ^ (y >> 17); xs32 = y ^ (y << 5);
    end endfunction
    reg [31:0] rng_rdy = 32'h2545F491 ^ BASE[31:0] ^ (RLAT * 32'h9E3779B1) ^ WORDS;   // per-instance streams
    reg [31:0] rng_gap = 32'h6C8E9CF5 ^ BASE[31:0] ^ (RLAT * 32'h85EBCA6B) ^ WORDS;
    always @(posedge clk) begin : rdy_draw
        reg [31:0] a, b, c;
        a = xs32(rng_rdy); b = xs32(a); c = xs32(b); rng_rdy <= c;
        ar_blk <= (rdy_gap > 0) && (a % 100 < rdy_gap);
        aw_blk <= (rdy_gap > 0) && (b % 100 < rdy_gap);
        w_blk  <= (rdy_gap > 0) && (c % 100 < rdy_gap);
    end
    function cross4k; input [63:0] a; input [7:0] len; begin cross4k = ((a & 64'hFFF) + (len + 1) * (DW / 8)) > 4096; end endfunction
    integer      errors = 0;
    integer      cyc = 0;
    always @(posedge clk) cyc <= cyc + 1;
    // word index of a byte address, or -1 outside this memory (checked on the full 64-bit address,
    // so an address far outside cannot alias onto a valid word after truncation)
    function integer widx; input [63:0] a; reg [63:0] off; begin
        off = a - BASE;
        if (a < BASE || off >= WORDS * (DW / 8)) widx = -1;
        else widx = off >> $clog2(DW/8);
    end endfunction

    // ---------------- reads ----------------
    reg [63:0] rq_addr [0:15]; reg [7:0] rq_len [0:15]; integer rq_t [0:15]; integer rq_lat [0:15]; integer rq_ws [0:15];
    reg        rq_dep [0:15];            // v14d id_block: this read changes channel while earlier reads are out
    integer    last_pc = -1;
    integer rq_wp = 0, rq_rp = 0, rq_n = 0, rbeat = 0; reg rbusy = 0;
    // v14d id_ooo: reads of different IDs are independent (each ID in order, its latency from its own address, the
    // pseudo-channel cap and rd_wait_wr as above); among the IDs whose next read is due, the oldest goes first, or a
    // random one (id_ooo = 2). id_ilv: a burst may be interrupted every 16 beats by another ID's (AXI read
    // interleaving, as the HBM's 16-beat bursts would allow). The single-ID engine below is untouched (id_ooo = 0).
    integer      id_ooo = 0, id_ilv = 0;
    reg  [63:0]  oq_addr [0:15]; reg [7:0] oq_len [0:15], oq_beat [0:15]; reg [1:0] oq_id [0:15];
    integer      oq_t [0:15], oq_seq [0:15], oq_ws [0:15]; reg oq_v [0:15];
    integer      oq_n = 0, oq_seqn = 0, oq_cur = -1, ooo_n = 0;   // ooo_n: bursts returned ahead of an older one
    reg [31:0]   rng_ooo = 32'h1B873593;
    assign arready = rst_n && ((id_ooo != 0) ? (oq_n < 16) : (rq_n < 16)) && !ar_blk;
    assign rresp = 2'b00;
    initial begin rvalid = 0; rlast = 0; rdata = 0; bvalid = 0; end
    initial rid = 2'd0;
    always @(posedge clk) begin : rd
        integer w, q, best, bs, nq; reg ok;
        if (!rst_n) begin rvalid <= 0; rlast <= 0; oq_n = 0; oq_cur = -1; for (q = 0; q < 16; q = q + 1) oq_v[q] = 0; end
        else if (id_ooo != 0) begin
            rng_gap = xs32(rng_gap); rng_ooo = xs32(rng_ooo);
            if (pc_cap_x100 != 0) for (pci = 0; pci < 64; pci = pci + 1)
                pc_credit[pci] = (pc_credit[pci] + pc_cap_x100 > 2 * DW / 8 * 100) ? 2 * DW / 8 * 100 : pc_credit[pci] + pc_cap_x100;
            if (arvalid && arready) begin
                if (cross4k(araddr, arlen)) begin perr = perr + 1; errors = errors + 1; end
                q = 0; while (oq_v[q]) q = q + 1;
                oq_v[q] = 1; oq_addr[q] = araddr; oq_len[q] = arlen; oq_beat[q] = 0; oq_id[q] = arid; oq_seq[q] = oq_seqn;
                oq_ws[q] = aw_q + ((awvalid && awready) ? 1 : 0);
                if (slow_pct > 0) lat_seed = xs32(lat_seed);
                oq_t[q] = cyc + lat + ((slow_pct > 0 && ($unsigned(lat_seed) % 100) < slow_pct) ? slow_extra : 0);
                oq_seqn = oq_seqn + 1; oq_n = oq_n + 1;
            end
            if (rvalid && rready) begin
                rvalid <= 0;
                if (rlast) begin oq_v[oq_cur] = 0; oq_n = oq_n - 1; oq_cur = -1; end
                else if (id_ilv != 0 && (oq_beat[oq_cur] % 16) == 0) oq_cur = -1;     // may switch ID here
            end
            if (!rvalid || rready) begin
                if (oq_cur < 0) begin                        // choose: the due next reads of each ID
                    best = -1; bs = 0; nq = 0;
                    for (q = 0; q < 16; q = q + 1) if (oq_v[q]) begin
                        ok = 1;
                        for (w = 0; w < 16; w = w + 1) if (oq_v[w] && oq_id[w] == oq_id[q] && oq_seq[w] < oq_seq[q]) ok = 0;   // its ID's next
                        if (ok && oq_beat[q] == 0 && cyc < oq_t[q]) ok = 0;
                        if (ok && oq_beat[q] == 0 && rd_wait_wr != 0 && land_q < oq_ws[q]) ok = 0;
                        if (ok) begin
                            nq = nq + 1;
                            if (best < 0 || (id_ooo == 1 && oq_seq[q] < bs) || (id_ooo == 2 && (rng_ooo % nq) == 0)) begin best = q; bs = oq_seq[q]; end
                        end
                    end
                    if (best >= 0) begin
                        ok = 0; for (q = 0; q < 16; q = q + 1) if (oq_v[q] && oq_seq[q] < oq_seq[best]) ok = 1;
                        if (ok && oq_beat[best] == 0) ooo_n = ooo_n + 1;          // overtook an older read
                        oq_cur = best;
                    end
                end
                if (oq_cur >= 0 && (gap_pct == 0 || rng_gap % 100 >= gap_pct)
                    && (pc_cap_x100 == 0 || pc_credit[pc_of(oq_addr[oq_cur])] >= DW / 8 * 100)) begin
                    if (pc_cap_x100 != 0) pc_credit[pc_of(oq_addr[oq_cur])] = pc_credit[pc_of(oq_addr[oq_cur])] - DW / 8 * 100;
                    w = (widx(oq_addr[oq_cur]) < 0) ? -1 : widx(oq_addr[oq_cur]) + oq_beat[oq_cur];
                    if (w < 0 || w >= WORDS) begin errors = errors + 1; rdata <= {DW{1'b0}}; end
                    else rdata <= mem[w];
                    rlast <= (oq_beat[oq_cur] == oq_len[oq_cur]); rid <= oq_id[oq_cur]; rvalid <= 1;
                    oq_beat[oq_cur] = oq_beat[oq_cur] + 1;
                end
            end
        end
        else begin
        rng_gap = xs32(rng_gap);
        if (pc_cap_x100 != 0) for (pci = 0; pci < 64; pci = pci + 1)
            pc_credit[pci] = (pc_credit[pci] + pc_cap_x100 > 2 * DW / 8 * 100) ? 2 * DW / 8 * 100 : pc_credit[pci] + pc_cap_x100;
        if (arvalid && arready) begin
            if (cross4k(araddr, arlen)) begin perr = perr + 1; errors = errors + 1;
                if (perr < 5) $display("AXI PROTOCOL: read burst at %h len %0d crosses a 4 KB boundary", araddr, arlen + 1); end
            rq_addr[rq_wp] = araddr; rq_len[rq_wp] = arlen; rq_t[rq_wp] = cyc; rq_ws[rq_wp] = aw_q + ((awvalid && awready) ? 1 : 0);
            if (slow_pct > 0) lat_seed = xs32(lat_seed);           // lat_seed: the stream's state (the testbench may seed it)
            rq_lat[rq_wp] = lat + ((slow_pct > 0 && ($unsigned(lat_seed) % 100) < slow_pct) ? slow_extra : 0);
            rq_dep[rq_wp] = (id_block != 0) && (pc_bytes > 0) && (rq_n > 0) && (pc_of(araddr) != last_pc);
            if (rq_dep[rq_wp]) blk_n = blk_n + 1;
            last_pc = pc_of(araddr);
            rq_wp = (rq_wp + 1) % 16; rq_n = rq_n + 1;
        end
        // rd_wait_wr: the head read waits for the writes accepted before it, and its latency starts once they landed
        if (rd_wait_wr != 0 && rq_n > 0 && rbeat == 0 && land_q < rq_ws[rq_rp]) rq_t[rq_rp] = cyc;
        if (rvalid && rready) begin
            rvalid <= 0;
            if (rlast) begin
                rbusy = 0; rq_rp = (rq_rp + 1) % 16; rq_n = rq_n - 1; rbeat = 0;
                // v14d id_block: the next read changed channel: it (and every read queued behind it, up to the next
                // change) is issued to the memory only now, when all earlier reads have returned
                if (rq_n > 0 && rq_dep[rq_rp]) begin : unblk
                    integer q, qi; reg stop; stop = 0;
                    for (q = 0; q < rq_n; q = q + 1) begin
                        qi = (rq_rp + q) % 16;
                        if (q > 0 && rq_dep[qi]) stop = 1;
                        if (!stop && rq_t[qi] < cyc + 1) rq_t[qi] = cyc + 1;
                    end
                    rq_dep[rq_rp] = 0;
                end
            end
            else rbeat = rbeat + 1;
        end
        if (pc_cap_x100 != 0 && (!rvalid || rready) && rq_n > 0 && cyc >= rq_t[rq_rp] + rq_lat[rq_rp]
            && pc_credit[pc_of(rq_addr[rq_rp])] < DW / 8 * 100) cap_n = cap_n + 1;
        if ((!rvalid || rready) && rq_n > 0 && !(rvalid && rready && rlast) && cyc >= rq_t[rq_rp] + rq_lat[rq_rp]
            && (rd_wait_wr == 0 || land_q >= rq_ws[rq_rp])
            && (gap_pct == 0 || rng_gap % 100 >= gap_pct)
            && (pc_cap_x100 == 0 || pc_credit[pc_of(rq_addr[rq_rp])] >= DW / 8 * 100)
            && !(rq_dep[rq_rp] && rbeat == 0)) begin
            if (pc_cap_x100 != 0) pc_credit[pc_of(rq_addr[rq_rp])] = pc_credit[pc_of(rq_addr[rq_rp])] - DW / 8 * 100;
            w = (widx(rq_addr[rq_rp]) < 0) ? -1 : widx(rq_addr[rq_rp]) + rbeat;
            if (w < 0 || w >= WORDS) begin errors = errors + 1; rdata <= {DW{1'b0}}; end
            else rdata <= mem[w];
            rlast  <= (rbeat == rq_len[rq_rp]);
            rvalid <= 1;
        end
        end
    end

    // ---------------- writes ----------------
    reg [DW-1:0] wf_d [0:WF_DEPTH-1]; reg [DW/8-1:0] wf_s [0:WF_DEPTH-1]; reg wf_l [0:WF_DEPTH-1]; integer wf_wp = 0, wf_rp = 0, wf_n = 0;
    reg [63:0] aw_addr [0:15]; reg [7:0] aw_len [0:15]; integer aw_t [0:15]; integer aw_end [0:15]; integer aw_done [0:15]; integer aw_cum = 0, w_rx = 0; integer aw_wp = 0, aw_rp = 0, aw_n = 0, b_pend = 0;
    assign wready  = rst_n && (wf_n < WF_DEPTH - 24) && !w_blk && (w_hold_n == 0) &&
                     (w_lead < 0 || w_rx < aw_cum + ((awvalid && awready) ? awlen + 1 : 0) + w_lead);
    // 2026-11-07: pstrb_hold = H: after a write beat with any strobe off, wready stays low H cycles (the card's response
    // memory took about 2,200 cycles for a 128-beat write with every strobe off, 137 with all on)
    integer      pstrb_hold = 0, pstrb_n = 0;
    always @(posedge clk) begin                                   // v14: +..._whold (deterministic write backpressure)
        if (awvalid && awready && w_hold > 0) w_hold_n <= w_hold;
        else if (wvalid && wready && pstrb_hold > 0 && wstrb != {(DW/8){1'b1}}) begin w_hold_n <= pstrb_hold; pstrb_n <= pstrb_n + 1; end
        else if (w_hold_n > 0) w_hold_n <= w_hold_n - 1;
    end
    assign awready = rst_n && (aw_n < 16) && !aw_blk;
    assign bresp   = 2'b00;
    always @(posedge clk) begin : wr
        integer k, w, by, q, qi;
        if (!rst_n) begin bvalid <= 0; aw_cum = 0; w_rx = 0; end
        else begin
        if (wvalid && wready) begin wf_d[wf_wp] = wdata; wf_s[wf_wp] = wstrb; wf_l[wf_wp] = wlast; wf_wp = (wf_wp + 1) % WF_DEPTH; wf_n = wf_n + 1; w_rx = w_rx + 1; end
        if (awvalid && awready) begin
            if (cross4k(awaddr, awlen)) begin perr = perr + 1; errors = errors + 1;
                if (perr < 5) $display("AXI PROTOCOL: write burst at %h len %0d crosses a 4 KB boundary", awaddr, awlen + 1); end
            aw_addr[aw_wp] = awaddr; aw_len[aw_wp] = awlen; aw_t[aw_wp] = cyc;
            aw_cum = aw_cum + awlen + 1; aw_end[aw_wp] = aw_cum; aw_done[aw_wp] = (w_rx >= aw_cum) ? cyc : -1;
            aw_wp = (aw_wp + 1) % 16; aw_n = aw_n + 1; end
        // a burst lands wlat cycles after its last data beat has arrived
        // each burst's data-complete time; a burst lands wlat cycles after its own (pipelined,
        // in order) -- not after the previous burst has landed
        for (q = 0; q < aw_n; q = q + 1) begin
            qi = (aw_rp + q) % 16;
            if (aw_done[qi] < 0 && w_rx >= aw_end[qi]) aw_done[qi] = cyc;
        end
        // b_early: each burst's B once its data is in (in order), before it lands
        if (b_early != 0) while (eb_n < aw_n && aw_done[(aw_rp + eb_n) % 16] >= 0) begin eb_n = eb_n + 1; b_pend = b_pend + 1; end
        if (aw_n > 0 && aw_done[aw_rp] >= 0 && wf_n >= aw_len[aw_rp] + 1 && cyc >= aw_done[aw_rp] + wlat) begin
            for (k = 0; k <= aw_len[aw_rp]; k = k + 1) begin
                w = (widx(aw_addr[aw_rp]) < 0) ? -1 : widx(aw_addr[aw_rp]) + k;
                if (wf_l[wf_rp] !== (k == aw_len[aw_rp])) begin perr = perr + 1; errors = errors + 1;
                    if (perr < 5) $display("AXI PROTOCOL: wlast=%0d on beat %0d of a %0d-beat write burst at %h", wf_l[wf_rp], k, aw_len[aw_rp] + 1, aw_addr[aw_rp]); end
                if (w < 0 || w >= WORDS) errors = errors + 1;
                else for (by = 0; by < DW/8; by = by + 1)
                    if (wf_s[wf_rp][by]) mem[w][by*8 +: 8] = wf_d[wf_rp][by*8 +: 8];
                wf_rp = (wf_rp + 1) % WF_DEPTH; wf_n = wf_n - 1;
            end
            aw_rp = (aw_rp + 1) % 16; aw_n = aw_n - 1; land_tot = land_tot + 1;
            if (eb_n > 0) eb_n = eb_n - 1; else b_pend = b_pend + 1;
        end
        if (bvalid && bready) begin bvalid <= 0; b_pend = b_pend - 1; end
        else if (b_pend > 0) bvalid <= 1;
        end
    end
endmodule
