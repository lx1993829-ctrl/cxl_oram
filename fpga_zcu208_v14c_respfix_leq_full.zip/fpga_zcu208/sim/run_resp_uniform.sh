#!/bin/bash
# run_resp_uniform.sh -- the response-write leak (2026-11-07, docs/resp_uniform_write.md). On the card a response data
# slot written with every strobe off (a PUT's, before the fix) took about 2,200 cycles against a GET's 137; through the
# command queue that backpressure moved later starts, so the access rate depended on the operation. The memory model
# reproduces it (+resp_pstrb=16: wready low 16 cycles after every beat with a strobe off).
# Four 4 KB, lambda 7 kernel testbenches: the serial baseline (Option A + RAMA) and phase 3 (1,600 spacing, allowance
# 300), each fixed and with the old response write (TB_RESP_STRB_OLD, test only). Each runs the same keys and arrivals
# with 0, 50 and 100% PUTs under the slow partial writes (no preload: the runs start from the same state):
#   - fixed: identical visible hashes (bucket-port timing, off-package shape, on-package release/end) and identical
#     device cycles per command across 0/50/100% PUTs; every GET correct; every PUT's slot written with zeros;
#   - old write: the hashes or the cycles differ (the negative control: the test sees the leak).
#   bash run_resp_uniform.sh [jobs]
set -u
cd "$(dirname "$0")"
RTL=$(cd "${RTL_DIR:-../rtl}" && pwd); J=${1:-$(nproc)}; CMDS=${CMDS:-300}
O=build/respu; mkdir -p $O
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
pass=0; fail=0; ok() { echo "PASS  $*"; pass=$((pass+1)); }; bad() { echo "FAIL  $*"; fail=$((fail+1)); }
build() { local d=$1; shift
    [ -x $O/$d/V ] && return 0
    verilator --binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-BLKANDNBLK -I$RTL \
      -DORAM_BLOCK_BEATS=128 -DORAM_C=7 -DORAM_N=4096 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL "$@" \
      --top-module tb_doma_kernel tb_doma_kernel.v oram_timing_monitor.v axi_mem_model.v $SRCS $RTL/doma_kernel.v \
      -Mdir $O/$d -o V > $O/build_$d.log 2>&1 && echo "built $d" || { bad "build $d ($O/build_$d.log)"; exit 1; }; }
SER="-DORAM_ONPKG_FIXWB -DORAM_ONPKG_RAMA"
P3="-DORAM_OVERLAP2 -DORAM_OVERLAP4 -DORAM_OV4_P3 -DORAM_OV_PMIN=1600 -DORAM_OV_CT_RD=600 -DORAM_OV4_GA=1600 -DORAM_OV4_LEQ=0 -DORAM_OV4_L=0 -DORAM_OV4_XWB=300 -DORAM_OV4_XREL_H=1000"
echo "== building (4 testbenches, one at a time)"
build ser $SER; build sero $SER -DTB_RESP_STRB_OLD; build p3 $P3; build p3o $P3 -DTB_RESP_STRB_OLD
H="+hb=0 +host_lat=480 +host_wlat=98 +host_slow_pct=3 +host_slow_extra=1500 +stash_gap=40 +stash_pcs=390 +stash_idblk=0 +stash_lat=200 +resp_pstrb=16"
: > $O/jobs.txt
for d in ser sero p3 p3o; do for p in 0 50 100; do
    echo "$d u$p $H +hbm_pct=20 +cmds=$CMDS +cmds2=4 +put_pct=$p +seed=41" >> $O/jobs.txt; done; done
echo "== running $(wc -l < $O/jobs.txt) runs, $J at a time"
O=$O xargs -P $J -L 1 bash -c 'd=$0; t=$1; shift 1; timeout 14400 ./$O/$d/V "$@" > $O/${d}_$t.log 2>&1; echo "  done $d $t"' < $O/jobs.txt
hashes() { grep -E "^run1: (bucket-port timing|folded off-package shape|on-package release/end) hash" $O/$1.log | sed -E 's/ over .*//'; }
cpc() { grep -E "^run1: size=" $O/$1.log | sed -E 's/.*size=([0-9]+) .*device total=([0-9]+).*/\2 \1/' | awk '{printf "%.1f", $1/$2}'; }
same() { [ -n "$(hashes $1)" ] && [ "$(hashes $1)" = "$(hashes $2)" ] && [ "$(cpc $1)" = "$(cpc $2)" ]; }
clean() { grep -q "ALL CHECKS PASSED" $O/$1.log && ! grep -q "DOMA HALT" $O/$1.log; }
echo "== checks"
for d in ser p3; do
    n=$( [ "$d" = ser ] && echo "serial baseline (Option A + RAMA)" || echo "phase 3 (1,600 spacing, allowance 300)")
    c=1; for p in 0 50 100; do clean ${d}_u$p || { bad "$n, $p% PUTs: run failed ($O/${d}_u$p.log)"; c=0; }; done
    [ $c = 1 ] && ok "$n: 0/50/100% PUTs under slow partial writes: every GET correct, every PUT's slot zeros, no halt"
    same ${d}_u0 ${d}_u50 && same ${d}_u0 ${d}_u100 \
        && ok "$n: 0/50/100% PUTs give identical visible hashes and device cycles per command ($(cpc ${d}_u0) / $(cpc ${d}_u50) / $(cpc ${d}_u100))" \
        || bad "$n: the operation reaches the schedule: cycles per command $(cpc ${d}_u0) / $(cpc ${d}_u50) / $(cpc ${d}_u100)"
    same ${d}o_u0 ${d}o_u100 \
        && bad "$n, old response write: 0% and 100% PUTs look the same (the test does not see the leak)" \
        || ok "$n, old response write (negative control): the leak is seen, cycles per command $(cpc ${d}o_u0) / $(cpc ${d}o_u50) / $(cpc ${d}o_u100) at 0/50/100% PUTs"
    same ${d}_u0 ${d}o_u0 && ok "$n: with no PUT the fixed and old builds are identical" || bad "$n: with no PUT the fixed build differs from the old one"
done
echo "== $pass passed, $fail failed"; [ $fail = 0 ]
