#!/usr/bin/env python3
"""budgets_l7.py -- DOMA's lambda = 7 arrival budgets for HBM buckets, from sim/measure_lambda.sh's measurement.

    python3 budgets_l7.py --show  PARAMS measure_lambda7.csv
    python3 budgets_l7.py --write PARAMS measure_lambda7.csv

The rule (README, "Lambda 7 budgets"): per size, AR_WB_H(7) = max(AR_WB_H(6), measured HBM worst + 74); AR_REL_H(7)
and AR_DONE_H(7) move by the same amount over their lambda = 6 values. They are the ORAM_AR_*_H_L7_B<beats> defines,
selected by ORAM_C == 7. Host buckets have no lambda = 7 budgets: the measured host worst must fit AR_WB (lambda 6),
or this script stops.
"""
import csv, re, sys

def read(params):
    raw = open(params, newline="").read()
    return raw, "\r\n" in raw, raw.replace("\r\n", "\n")

def get(s, name):
    m = re.search(r"^`define %s +(\d+)" % name, s, re.M)
    if not m: sys.exit(f"budgets_l7.py: {name} not found")
    return int(m.group(1))

def compute(s, rows):
    out = []
    for r in rows:
        b, host, hbm = int(r["beats"]), int(r["host_measured"]), int(r["hbm_measured"])
        if r["status"] != "ok": sys.exit(f"budgets_l7.py: the measurement at {b} beats did not pass: {r['status']}")
        wb6, rel6, done6, arwb = get(s, f"ORAM_AR_WB_H_B{b}"), get(s, f"ORAM_AR_REL_H_B{b}"), get(s, f"ORAM_AR_DONE_H_B{b}"), get(s, f"ORAM_AR_WB_B{b}")
        if host > arwb: sys.exit(f"budgets_l7.py: {b} beats: host worst {host} exceeds AR_WB {arwb} (lambda 7 would need host budgets)")
        wb7 = max(wb6, hbm + 74); d = wb7 - wb6
        out.append(dict(b=b, host=host, hbm=hbm, arwb=arwb, wb6=wb6, wb7=wb7, rel7=rel6 + d, done7=done6 + d, d=d))
    return out

def main(a):
    if len(a) != 3 or a[0] not in ("--show", "--write"): sys.exit(__doc__)
    params, rows = a[1], list(csv.DictReader(open(a[2])))
    raw, crlf, s = read(params)
    res = compute(s, rows)
    for x in res:
        print(f"{x['b']*32:>5} B ({x['b']:3d} beats): measured host {x['host']} (AR_WB {x['arwb']}), HBM {x['hbm']}; "
              f"AR_WB_H(7) = max({x['wb6']}, {x['hbm']} + 74) = {x['wb7']} (+{x['d']}), AR_REL_H(7) {x['rel7']}, AR_DONE_H(7) {x['done7']}")
    if a[0] == "--write":
        for x in res:
            for k, v in (("AR_WB_H_L7", x["wb7"]), ("AR_REL_H_L7", x["rel7"]), ("AR_DONE_H_L7", x["done7"])):
                pat = re.compile(r"^(`define ORAM_%s_B%d +)\d+" % (k, x["b"]), re.M)
                if len(pat.findall(s)) != 1: sys.exit(f"budgets_l7.py: ORAM_{k}_B{x['b']} not found exactly once")
                s = pat.sub(lambda m: m.group(1) + str(v), s)
        open(params, "w", newline="").write(s.replace("\n", "\r\n") if crlf else s)
        print(f"written {params}")

if __name__ == "__main__":
    main(sys.argv[1:])
