#!/bin/bash
# ov_test_mock.sh -- the overlap test build (OV_TRACE=1 OV_FAULT=1) end to end in the mock XRT, before the Vivado build
# (docs/ov_fault_build.md). Run it on the build machine, from sim/:   bash ov_test_mock.sh
# It Verilates a copy of ../rtl with the card build's defines (OVERLAP=4 P3=1, OV_PMIN, OV_GA, OV_XWB as for the card,
# OV_TRACE, OV_FAULT), builds host_fault_ov and host_leak_ov against it, and runs, at n = 140 (20 buckets):
#   1. host_fault_ov, every test at a small scale            -> must end ALL TRIALS PASSED
#   2. host_leak_ov, disarmed, then the exact schedule check -> must be exact
#   3. host_leak_ov with the planted leak, the same check    -> must NOT be exact (the positive control)
# Speed is about 100,000 cycles/s: the whole run takes some tens of minutes. Nothing here touches the card.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"; TOP="$(cd "$HERE/.." && pwd)"
W="${W:-$HERE/ovtest_mock}"; rm -rf "$W"; mkdir -p "$W/vitis"
cp -a "$TOP/rtl" "$W/rtl"
{ printf '`ifndef ORAM_BLOCK_BEATS\n`define ORAM_BLOCK_BEATS 128\n`endif\n'
  printf '`define ORAM_OVERLAP2\n`define ORAM_OVERLAP4\n`define ORAM_OV_P %s\n`define ORAM_OV_CT_RD %s\n`define ORAM_OV_DEQ %s\n`define ORAM_OV4_GA %s\n' \
         "${OV_P:-2150}" "${OV_CTRD:-600}" "${OV_DEQ:-6000}" "${OV_GA:-1600}"
  printf '`define ORAM_OV4_P3\n`define ORAM_OV_PMIN %s\n`define ORAM_OV4_LEQ %s\n`define ORAM_OV4_L %s\n' "${OV_PMIN:-1600}" "${OV_LEQ:-0}" "${OV_L:-0}"
  printf '`define ORAM_OV_TRACE\n`define ORAM_OV_FAULT\n'
  X="${OV_XWB:-300}"; printf '`define ORAM_OV4_XWB %s\n`define ORAM_OV4_XREL_H %s\n' "$X" "$(( X + 700 ))"
  printf '`ifndef ORAM_C\n`define ORAM_C 7\n`endif\n'; } > "$W/rtl/oram_build_cfg.vh"
echo "== the test build's configuration:"; cat "$W/rtl/oram_build_cfg.vh"
OUT="$W/obj" RTL="$W/rtl" LAMBDA=7 ORAM_N="${ORAM_N:-2097152}" bash "$HERE/xrt_mock/build_model.sh"
OUT="$W/obj" HOSTS="fault_ov leak_ov" bash "$HERE/xrt_mock/build_hosts.sh"
mv "$HERE/xrt_mock/host_fault_ov_sim" "$HERE/xrt_mock/host_leak_ov_sim" "$W/vitis/"
cd "$W/vitis"                                      # (the hosts check Z and lambda against ../rtl)
export MOCK_CFG=doma DOMA_LAMBDA=7 DOMA_N="${MOCK_N:-140}" DOMA_HBM_PCT=20
rc=0
echo "== 1. host_fault_ov, every test"
./host_fault_ov_sim x.xclbin all --scale "${MOCK_SCALE:-0.01}" > fault.log 2>&1 || true
tail -25 fault.log; grep -q 'ALL TRIALS PASSED' fault.log || rc=1
PH="pair:get/put:${MOCK_CMDS:-1200},pair:uni/rereq:${MOCK_CMDS:-1200},pair:uni/badput:${MOCK_CMDS:-1200}"
an() { python3 "$TOP/sim/card_leak_analyze_ov.py" "$1" --pmin "${OV_PMIN:-1600}" --ga "${OV_GA:-1600}" --xwb "${OV_XWB:-300}" \
           --l "${OV_L:-0}" --leq "${OV_LEQ:-0}" --out "${1%.csv}.json" > "${1%.csv}.analysis" 2>&1 || true; }
echo "== 2. host_leak_ov, hooks disarmed: the exact schedule check"
DOMA_OVF=1 DOMA_LEAK_CSV=clean.csv DOMA_PHASES="$PH" ./host_leak_ov_sim x.xclbin 200 > clean.log 2>&1 || true
an clean.csv; grep -E 'PASS|FAIL|in flight|==' clean.analysis | head -20
grep -q 'schedule exact' clean.analysis || rc=1
echo "== 3. host_leak_ov, the planted leak on: the check must fail"
DOMA_OVF=1 DOMA_OV_LEAK=1 DOMA_LEAK_CSV=leak.csv DOMA_PHASES="$PH" ./host_leak_ov_sim x.xclbin 200 > leak.log 2>&1 || true
an leak.csv; grep -E 'PASS|FAIL|==' leak.analysis | head -12
if grep -q 'schedule NOT exact' leak.analysis; then echo "== PLANTED LEAK CAUGHT"; else echo "== PLANTED LEAK NOT CAUGHT"; rc=1; fi
[ $rc = 0 ] && echo "== MOCK TEST BUILD OK" || echo "== MOCK TEST BUILD: SOMETHING FAILED (logs in $W/vitis)"
exit $rc
