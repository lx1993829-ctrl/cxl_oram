#!/bin/bash
# make_test_build.sh <fixed production tree> <new folder> -- set up the overlap test build (docs/ov_fault_build.md)
#   bash make_test_build.sh ~/p3rx300fix/fpga_zcu208 ~/p3rx300test
# Copies the production tree (sources only: no build products, bitstreams or result folders) to <new folder>/fpga_zcu208,
# applies patches/ov_testbuild.patch (OV_TRACE and OV_FAULT; production is unchanged when both are unset), adds the test
# programs and notes, and prints the build command. The production tree is only read.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)/fpga_zcu208"
SRC="${1:?usage: bash make_test_build.sh <fixed production tree, e.g. ~/p3rx300fix/fpga_zcu208> <new folder>}"
DST="${2:?usage: bash make_test_build.sh <fixed production tree> <new folder, e.g. ~/p3rx300test>}"
SRC="$(cd "$SRC" && pwd)"
[ -f "$SRC/rtl/doma_kernel.v" ] && [ -f "$SRC/vitis/build.sh" ] || { echo "$SRC is not an fpga_zcu208 tree"; exit 1; }
[ -e "$DST" ] && { echo "$DST exists: give a new folder"; exit 1; }
# the response-write fix must be in the source tree (every response beat written with all strobes on)
if grep -n "gmem1_wstrb" "$SRC/rtl/doma_kernel.v" | grep -q "1'b0"; then
    echo "$SRC/rtl/doma_kernel.v still writes response beats with strobes off: not the fixed tree"; exit 1; fi
grep -q 'ORAM_OV_FAULT' "$SRC/rtl/doma_kernel.v" && { echo "$SRC already has the test build's changes"; exit 1; }
mkdir -p "$DST/fpga_zcu208"
rsync -a --exclude '_x' --exclude '.Xil' --exclude '.ipcache' --exclude 'doma_ip' --exclude 'doma_pack' --exclude '*.xo' \
      --exclude '*.xclbin' --exclude '*.csv' --exclude 'leak_*/' --exclude 'tb_*/' --exclude '*.log' --exclude '*.out' \
      --exclude 'obj_dir' --exclude 'ovtest_mock' "$SRC/" "$DST/fpga_zcu208/"
cd "$DST/fpga_zcu208"
echo "== applying patches/ov_testbuild.patch"
patch -p1 --dry-run < "$HERE/patches/ov_testbuild.patch" > /dev/null || { echo "the patch does not apply to $SRC: nothing changed there; remove $DST"; exit 1; }
patch -p1 < "$HERE/patches/ov_testbuild.patch"
cp "$HERE"/vitis/host_fault_ov.cpp "$HERE"/vitis/host_leak_ov.cpp "$HERE"/vitis/leak_runs_ov.sh "$HERE"/vitis/kernel_fault.xml vitis/
cp "$HERE"/sim/card_leak_analyze_ov.py "$HERE"/sim/card_rate_check.py "$HERE"/sim/ov_test_mock.sh sim/
mkdir -p patches docs; cp "$HERE"/patches/ov_testbuild.patch patches/; cp "$HERE"/docs/ov_fault_build.md "$HERE"/docs/LEAK_CARD_RUNBOOK_OV.md docs/
echo "== the test build is in $DST/fpga_zcu208 (docs/ov_fault_build.md). Optional first: the mock run (no card):"
echo "   cd $DST/fpga_zcu208/sim && bash ov_test_mock.sh"
echo "== then the build:"
echo "   cd $DST/fpga_zcu208/vitis && OVERLAP=4 P3=1 OV_PMIN=1600 OV_GA=1600 OV_XWB=300 OV_TRACE=1 OV_FAULT=1 SCHED=arrival BEATS=128 CFG=doma_big2m_rama.cfg NMAX=2097152 LAMBDA=7 TARGET=hw nohup bash build.sh > build.log 2>&1 &"
