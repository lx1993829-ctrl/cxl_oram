#!/bin/bash
# run_overlap.sh: overlap step 1 (ORAM_OVERLAP2, two accesses in flight) regression, 4 KB blocks, lambda 7.
# Builds three kernel testbenches (v14d1 = base, overlap = ovf, overlap with the injected leak = ovl), runs the set below
# in parallel, and checks:
#   - every run: all responses correct, eviction scoreboard 0 wrong, no halt (ALL CHECKS PASSED), except as noted;
#   - paired streams (same keys and arrivals, different GET/PUT mix): identical visible hashes (bucket-port timing,
#     folded off-package shape, on-package release/end) for p0/p50/p100, same-key sk0/sk100, ABAB ab0/ab50;
#   - the injected leak (TB_OV_LEAK, a PUT's read one cycle late) changes the hashes between l0 and l100;
#   - on-package release/end hash equal to v14d1 (c1, 100% on package);
#   - fixed schedule (check_fixed_schedule.py, every overlap run): every access's visible times relative to its start,
#     with the public same-bucket shift taken out, are one fixed shape per class (off / on package), the same in every
#     run with the same memory latencies (random keys, one repeated key, ABAB, keys in turns of 3 and 4, card-like
#     stash); every start follows s(j) = max(request + K1, s(j-1) + P (+ D_EQ) + K2) exactly; the injected-leak build
#     must fail it;
#   - throughput against v14d1.
# Usage: bash run_overlap.sh [jobs]      (default jobs = nproc). Logs: build/ov/. About 20-40 min on 8 cores.
#        OV=4 bash run_overlap.sh [jobs]  step 2 (ORAM_OVERLAP4, four in flight): the same set and checks, except the
#        comparison with v14d1's per-access times (step 2 has larger write-back and release allowances). Logs: build/ov4/.
set -u
cd "$(dirname "$0")"
RTL=${RTL_DIR:-../rtl}; J=${1:-$(nproc)}
OV=${OV:-2}
if [ "$OV" = 4 ]; then O=build/ov4; XD="-DORAM_OVERLAP2 -DORAM_OVERLAP4"; else O=build/ov; XD="-DORAM_OVERLAP2"; fi
mkdir -p $O
SRCS=$(sed "s#^#$RTL/#" files_rtl.lst | tr '\n' ' ')
build() {   # build <dir> [defines]
    local d=$1; shift
    verilator --binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -I$RTL \
      -DORAM_BLOCK_BEATS=128 -DORAM_C=7 -DORAM_SECURE_BUILD -DORAM_SCHED_ARRIVAL -Wno-BLKANDNBLK "$@" \
      --top-module tb_doma_kernel tb_doma_kernel.v oram_timing_monitor.v axi_mem_model.v $SRCS $RTL/doma_kernel.v \
      -Mdir $O/$d -o V > $O/build_$d.log 2>&1 && echo "built $d" || { echo "BUILD FAILED $d ($O/build_$d.log)"; exit 1; }
}
echo "== building (3 testbenches)"
build base & build ovf $XD & build ovl $XD -DTB_OV_LEAK & wait
for d in base ovf ovl; do [ -x $O/$d/V ] || { echo "missing $O/$d/V"; exit 1; }; done
H="+hb=0 +host_lat=401 +host_wlat=98"
cat > $O/jobs.txt <<EOF
ovf p0 $H +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=0
ovf p50 $H +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=50
ovf p100 $H +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=100
base p50 $H +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=50
ovl l0 $H +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=0
ovl l100 $H +hbm_pct=20 +preload +cmds=300 +cmds2=4 +put_pct=100
ovf sk0 $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +same_key=120 +put_pct=0
ovf sk100 $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +same_key=120 +put_pct=100
ovf ab0 $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +abab_key=120 +put_pct=0
ovf ab50 $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +abab_key=120 +put_pct=50
ovf k3a $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +cyc_key=120 +cyc_n=3 +put_pct=0
ovf k3b $H +hbm_pct=20 +preload +cmds=120 +cmds2=4 +cyc_key=120 +cyc_n=3 +put_pct=100
ovf k4a $H +hbm_pct=50 +preload +cmds=120 +cmds2=4 +cyc_key=120 +cyc_n=4 +put_pct=30
ovf c0 $H +hbm_pct=0 +preload +cmds=200 +cmds2=4 +seed=5
base c0 $H +hbm_pct=0 +preload +cmds=200 +cmds2=4 +seed=5
ovf c1 +hb=0 +hbm_pct=100 +preload +seed=3 +cmds=200 +cmds2=4
base c1 +hb=0 +hbm_pct=100 +preload +seed=3 +cmds=200 +cmds2=4
ovf cs $H +hbm_pct=20 +preload +cmds=200 +cmds2=4 +stash_gap=40 +stash_pcs=390 +stash_idblk=1 +stash_lat=120 +stash_slow_pct=0
base cs $H +hbm_pct=20 +preload +cmds=200 +cmds2=4 +stash_gap=40 +stash_pcs=390 +stash_idblk=1 +stash_lat=120 +stash_slow_pct=0
ovf j2 +hb=0 +junk_mem +host_lat=263 +host_wlat=98 +hbm_pct=20 +preload
ovf c3 +hb=0 +hbm_pct=50 +cmds=200 +cmds2=10 +host_lat=263 +host_wlat=98 +seed=7
EOF
echo "== running $(wc -l < $O/jobs.txt) runs, $J at a time"
rm -f $O/fx_*.txt
O=$O xargs -P $J -L 1 bash -c 'b=$0; t=$1; shift 1; timeout 7200 ./$O/$b/V "$@" +fix_dump=$O/fx_${b}_$t.txt > $O/${b}_$t.log 2>&1; echo "  done $b $t"' < $O/jobs.txt
pass=0; fail=0
ok() { echo "PASS  $*"; pass=$((pass+1)); }
bad() { echo "FAIL  $*"; fail=$((fail+1)); }
hashes() { grep -E "^run1: (bucket-port timing|folded off-package shape|on-package release/end) hash" $O/$1.log | sed -E 's/ over .*//'; }
cpc() { grep -E "^run1: size=" $O/$1.log | sed -E 's/.*size=([0-9]+) .*device total=([0-9]+).*/\2 \1/' | awk '{printf "%.0f", $1/$2}'; }
echo "== checks"
while read -r b t rest; do
    l=$O/${b}_$t
    if [ "$b $t" = "ovl l100" ]; then continue; fi
    grep -q "ALL CHECKS PASSED" $l.log && grep -q "eviction scoreboard: .* 0 wrong" $l.log \
        && ok "$b $t: all responses correct, scoreboard 0 wrong" || bad "$b $t ($l.log)"
done < $O/jobs.txt
same() { local a=$1 b=$2; [ -n "$(hashes $a)" ] && [ "$(hashes $a)" = "$(hashes $b)" ]; }
same ovf_p0 ovf_p50 && same ovf_p0 ovf_p100 && ok "paired streams 0/50/100% PUTs: identical visible hashes" || bad "paired streams 0/50/100% PUTs differ"
same ovf_sk0 ovf_sk100 && ok "same key x120, 0/100% PUTs: identical visible hashes" || bad "same-key paired hashes differ"
same ovf_ab0 ovf_ab50 && ok "ABAB keys, 0/50% PUTs: identical visible hashes" || bad "ABAB paired hashes differ"
same ovf_k3a ovf_k3b && ok "keys in turns of 3, 0/100% PUTs: identical visible hashes" || bad "period-3 key paired hashes differ"
same ovl_l0 ovf_p0 && ok "injected-leak build without PUTs equals the overlap build" || bad "injected-leak build without PUTs differs"
[ "$(hashes ovl_l0 | grep timing)" != "$(hashes ovl_l100 | grep timing)" ] && [ "$(hashes ovl_l0 | grep release)" != "$(hashes ovl_l100 | grep release)" ] \
    && ok "injected leak (a PUT's read one cycle late) detected by the paired hashes" || bad "injected leak NOT detected"
# every access's visible times equal v14d1's once the public same-bucket shift (D_EQ) is taken out of exactly the
# accesses that had it: off-package shape and on-package release/end, at 0%, 100% and 20% (card-like stash)
corr() { grep -E "^run1: equality-corrected hashes" $O/$1.log | sed -E 's/ \(.*//'; }
neq()  { grep -E "^run1: equality-corrected hashes" $O/$1.log | sed -E 's/.*\(([0-9]+) same-bucket.*/\1/'; }
for t in c0 c1 cs; do
    [ "$OV" = 4 ] && break
    [ -n "$(corr ovf_$t)" ] && [ "$(corr ovf_$t)" = "$(corr base_$t)" ] \
        && ok "$t: every access's visible times equal v14d1's apart from the public same-bucket shift ($(neq ovf_$t) shifted accesses)" \
        || bad "$t: visible times differ from v14d1 beyond the same-bucket shift"
done
# fixed schedule: nothing visible depends on keys, data or stash state (only on arrivals, bucket equality, on package)
if [ "$OV" = 4 ]; then PD="--p 1500 --deq 3600"; else PD="--p 2900 --deq 2700"; fi
FX_ALL="p0 p50 p100 sk0 sk100 ab0 ab50 k3a k3b k4a c0 c1 cs j2 c3"
FX_SAME="p0 p50 p100 sk0 sk100 ab0 ab50 k3a k3b k4a c0 cs"     # same memory latencies (host 401 / 98)
fxbad=""; for t in $FX_ALL; do python3 check_fixed_schedule.py $PD $O/fx_ovf_$t.txt > $O/fx_ovf_$t.out 2>&1 || fxbad="$fxbad $t"; done
[ -z "$fxbad" ] && ok "fixed schedule in every run ($(echo $FX_ALL | wc -w) runs): one visible shape per class, start rule exact" \
                || bad "fixed schedule broken in:$fxbad (see $O/fx_ovf_<run>.out)"
python3 check_fixed_schedule.py $PD $(for t in $FX_SAME; do echo $O/fx_ovf_$t.txt; done) > $O/fx_across.out 2>&1 \
    && ok "fixed schedule across $(echo $FX_SAME | wc -w) runs (random keys, one key, ABAB, turns of 3 and 4, 0/20/50% on package, card-like stash): identical visible shapes" \
    || { bad "visible shapes differ between runs ($O/fx_across.out)"; grep FAIL $O/fx_across.out | head -3 | sed 's/^/      /'; }
python3 check_fixed_schedule.py $PD $O/fx_ovl_l100.txt > $O/fx_ovl_l100.out 2>&1 \
    && bad "injected leak NOT detected by the fixed-schedule check" || ok "injected leak detected by the fixed-schedule check"
echo "== throughput (cycles per command, run1)"
for t in c0 p50 cs c1; do echo "  $t: v14d1 $(cpc base_$t), overlap $(cpc ovf_$t)"; done
echo "== $pass passed, $fail failed"
[ $fail = 0 ]
