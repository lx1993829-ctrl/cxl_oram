# Overlap RTL spec, step 1: two accesses in flight (4 KB, design A)

Basis: v14d1 (`rtl/flat_oram_gcm.v`, `stash_hbm.v` 7c03d7ae), arrival-mode builds, λ = 7, Z = 8. Build switch
`ORAM_OVERLAP2`; without it the RTL is v14d1, bit for bit.

## 0. Why step 1 is two in flight, one GCM core, no forwarding

The measured model (`overlap_study.md` §1.2) puts the bound at P ≈ 2,850–2,900 cycles per access while the stash
runs at design A's 0.44 beats per cycle at 2M. At that spacing:

- **The previous access is finished with all shared secret state before the next one starts.** Access i's decisions,
  its position-map writes, its bucket-record write and its stash commit all end by about s(i) + 2,200, and
  s(i+1) ≥ s(i) + P. So access i+1 reads exactly the sequential state:
  - no key forwarding, no in-flight key table;
  - no bucket-image forwarding except for the same bucket (D1, below);
  - no second staging set: `stash_hbm.v` is untouched.

  A fixed check enforces it; if it ever fails, the design halts (C1, §4).
- **One GCM core is enough.** i's encryption ends near s(i) + 3,400. i+1's ciphertext starts landing at
  s(i+1) + 671 ≥ s(i) + 3,520.
- **What remains to build:**
  - two contexts;
  - a second scratch buffer and a second result buffer, copies of today's templates;
  - separate read and write engines on the bucket port;
  - a fixed start rule;
  - the same-bucket rule;
  - kernel changes.

Step 2 (4 in flight, two GCM cores, forwarding, a stash metadata port) is worth building only if the card's stash
rate under design B or RAMA reaches about 1 beat per cycle. It reuses everything here.

## 1. Stages and who owns what

Each access j has a fixed start s(j). It moves through three units:

| Unit | Work | States |
|---|---|---|
| **Front** F | Lookup (position map, bucket record), stash open request, read gate at s + CT_RD, bucket read into scratch[j mod 2] | Today's S_IDLE → S_POS_LOOKUP → S_RD_GATE, as a separate small FSM |
| **Main** M | Decryption (off package) or arrival wait (on package), scan, decisions, copies, position-map updates, evictions, commit, encryption | Today's S_CR_* (DA), S_DDR_READ, S_SCAN … S_EA_START, S_CR_* (EA) |
| **Tail** T | Wait for the write-back data hand-off, done gate at t_arr + AR_REL(_H), result stream from res[j mod 2], `client_done` | Today's S_DDR_WRITE, S_DONE_GATE, S_RES_STREAM, as a separate small FSM |

Timeline at P = 2,850, off package (offsets from s(i)):

```
access i     F 0-1,701 (read lands)   M 671-3,400 (decrypt, decide, encrypt)   T 3,400-4,960 (write hand-off, release, result)
access i+1                                         F 2,850-4,551               M 3,521-6,250 ...   T 6,250-7,810
```

**Hand-offs:**
- **F → M:** when M is free (it has handed its previous access to T) and the F context's read has been issued.
- **M → T:** at the end of encryption (off package), or at S_EA_START once the eviction copies are done (on package).

At most two accesses are in flight:
- F(i+1) overlaps M(i);
- M(i+1) overlaps T(i);
- T(i−1) has ended before F(i+1) starts. A check enforces this (C3).

**Per-access context:** two banks, indexed by the access's parity bit.
- Contents: request (slot, op, partition), req_b, b′, acc_hbm, same_bucket, the read state (landed beats, arr_seen,
  t_arr), its cycle counter ct_cnt, res_zero, wb_active, wb_done_seen, enc_pos_done and the per-access deadline maxima.
- **The decision registers stay single.** M handles one access at a time: fill, slot list, eviction queue, copy
  state and cr_*.

## 2. Shared resources

| Resource | Today | Step 1 | Why no request-dependent timing |
|---|---|---|---|
| **Bucket port** (gmem2 host, gmem6 HBM) | One `axi_master`, read or write at a time; a read is held until every earlier write is acknowledged | **Two `axi_master` instances, the module unchanged.** One only reads (AR/R); the other only writes (AW/W/B). The kernel's router already selects per channel. **The read hold changes:** a read is held only under the same-bucket rule (D1). | i's write and i+1's read are at fixed times to public addresses. Each one's latency may depend on the other's traffic, which is public (A6, §5). |
| **Scratch** | One `scratch_buf` | **Two instances**, today's template unchanged. F writes the arriving read into scratch[j mod 2]. M reads and writes scratch[mp]. T's write-back stream reads scratch[tp]. | Different memories: no shared port, no multi-writer memory. |
| **Result buffer** `res` | One, written by S_CP, read by S_RES_STREAM | **Two copies** of today's `res` template. M writes res[mp]; T reads res[tp]. | As above. |
| **GCM core** | M only | M only. Decryption of i+1 starts after M has handed i to T, so encryption of i has ended. | Unchanged. The IV LFSR advances in access order, as today. |
| **Stash** (`stash_hbm`) | Opened at the lookup; the open waits for the previous commit to be quiet | **Unchanged module.** F's open request fires only when M has handed the previous access to T (its copies are done) and the stash is write-quiet. | The open's start depends on the previous access's commit, which is internal. Its effect is bounded by the next access's fixed deadlines (fail-stop), as today. |
| **Position map, bucket records, IV/tag table** | One access | F(i+1) reads only after i's writes (C1). | Sequential. |
| **Debug maxima** (ct_max_*, ar_max_*) | One writer | Updated from M and T. One of them takes priority, and the other's update is held one cycle. | Debug only. |

**New memories:** scratch #2 and res #2, each a second instance of an existing single-write-port template. **No new
multi-writer memory.** Both go into the netlist group (`run_stash_netlist.sh`, plus a new `tb_scratch` unit test
against the Vivado and Yosys netlists).

## 3. The fixed schedule

**Start rule.** s(j) = max(the cycle request j is presented, s(j−1) + P).
- P is a build constant (`ORAM_OV_P`, one value per build, calibrated on the card).
- F starts j at s(j) only if F is free, which C3 guarantees.

**Fixed offsets, all as today:**

| Event | When |
|---|---|
| Lookup | s(j) |
| Read issue | s(j) + CT_RD |
| Off-package write-back | t_arr(j) + AR_WB |
| Release | t_arr(j) + AR_REL(_H) |
| Response | after the release |

**Same bucket (D1).** At the lookup, F compares b(j) with the bucket of every access whose write-back is not yet
acknowledged: at most i = j − 1. If they are equal, j's read issues at s(j) + CT_RD + D_EQ instead, and j's whole
schedule, including the next start, shifts by D_EQ. D_EQ is a constant: i's write-back is acknowledged by then, or
the design halts (C4).
- The equality of two bucket indices is public: the trace shows both addresses.
- The decryption of j uses the IV and tag i wrote, because it starts after i's encryption has ended.

**New checks.** Each check is fail-stop: the design halts at the access's release time, as v14b does.

| Check | Condition | Why |
|---|---|---|
| C1 | At s(j), M has passed i's S_EA_START (decisions, position-map and record writes issued), and those writes are acknowledged | j's lookup sees i's results |
| C2 | M is free for j by t_arr(j) − 1,030 + slack (decryption must not start late) | Covered by j's AR_WB check. Recorded separately for calibration. |
| C3 | T is free when M hands over j | T(j−1) is done |
| C4 | With b(j) = b(i): i's write-back is acknowledged by s(j) + CT_RD + D_EQ | Same-bucket read-after-write |
| Today's | CT_RD, AR_WB(_H), AR_REL(_H), AR_DONE(_H), each from its own access's s or t_arr | Recalibrated with the neighbour's traffic present |

## 4. Correctness

**Claim:** the overlapped design computes, for every access, exactly what v14d1 computes sequentially. By induction
on j:
- **Position map, bucket records, stash.** Written only by M, in access order. All of i's writes are issued before
  s(j) and acknowledged before j's reads issue (C1).
- **Stash open.** j's open fires after i's commit is quiet and i's copies are done, so `stash_hbm` sees the same
  sequence of operations as in v14d1.
- **Buckets.** j reads b(j) after every earlier write to b(j) is acknowledged:
  - for i − 1 and earlier, by the release and the start spacing;
  - for i, by C4.

  The ciphertext and the IV/tag pair are the sequential ones.
- **Scratch and result buffers** are private to their access by parity. C3 guarantees a buffer's previous owner has
  finished with it.
- **GCM and the IV LFSR** are used by M only, in access order.

**Test:** the overlapped design's responses, and its final bucket and stash images, equal v14d1's on the same
streams. The eviction scoreboard runs in every run.

## 5. Leakage, stage by stage

**Rule.** Every externally visible event of access j happens at a constant offset from s(j) or t_arr(j). The
visible events are host-port reads and writes (time, address, size), and the response. s(j) depends only on request
arrival times and the public bucket-equality class.

- **F.** The lookup and read gate are fixed offsets from s(j), as today. The read is no longer held for unrelated
  writes; it is held only on equality (public).
- **M.** Unchanged; internal, bounded by j's deadlines. Its start depends on i's encryption end (internal), as the
  open's start depended on the previous commit before.
- **T.** Unchanged: release and response at fixed offsets from t_arr(j).
- **Cross-access effects:**
  - **Bucket port.** j's read latency includes i's concurrent write traffic, which is public (fixed size and time,
    public address).
  - **Stash traffic.** j's stash open (secret volume) runs alongside i's on-package write-back. On package nothing
    is observable; only the deadlines matter, and they are fail-stop.
  - **Host-visible events of i** (write-back, release, response) are fixed offsets from t_arr(i) and never wait on j.
- **A6 (stated).** A memory's latency may depend on the public trace (now including the neighbour access's fixed
  traffic) and on request-independent noise.
  - The stash's secret-volume traffic stays on its own pseudo-channels (HBM[12:15]), as it already runs alongside
    the access's own bucket read today.
  - Assumed, as today, not to change the bucket port's latency enough to matter. The 2M calibration with the
    neighbour present measures it.
- **Halts.** A halt depends on memory timing and the stash (fail-stop), as today. The neighbour's stash volume is now
  one more input to the on-package deadlines, so the 10% margin is recalibrated with it present.

**The test that would catch a violation:** the injected-leak define `TB_OV_LEAK` makes F wait one extra cycle when
j's key equals i's key. The paired-stream hash check must fail with it, and pass without it.

## 6. Kernel

- **Commands.** The kernel holds up to two commands at the controller. It presents command j as soon as the
  controller's front is free (`client_ready_next`), not after `client_done` of j−1.
- **Data in both directions at once.** PUT data for j (`client_wdata_beat_req`, during M(j)'s copy) and the result
  stream of j−1 (`client_rdata`, during T) can be active together. The kernel serves them from separate paths.
  Responses are written in order, because T finishes in order.
- **Tokens.** The per-command token and debug record follow the command into its context.

## 7. Order of work and tests

1. **Two read/write engines** on the bucket port, plus the read-hold change (equality only). Regression: v14d1
   hashes unchanged with `ORAM_OVERLAP2` off; with it on and P = ∞ (no overlap), hashes identical to v14d1.
2. **Second scratch and result buffers**, parity selection, context banks. With P = ∞ still identical.
3. **F and T as separate FSMs**, the hand-offs, the start rule, C1–C4. Then P finite.
4. **Kernel** (two commands in the controller).
5. **Tests:**
   - **Paired streams:** different keys, data and op mix, same arrivals; hashes identical. Cases: repeated key
     (k times, ABAB), same bucket (`dbg_force_same_bucket`), stash-filling scan, 0 / 20 / 100% on package, the
     card-like stash.
   - **Injected leak:** fails as it should.
   - **Sequential equivalence:** against v14d1, with the scoreboard.
   - **XRT mock:** host_doma's 4,096-record sequence.
   - **Netlist group:** scratch #2 and res #2.
6. **Card:**
   - debug-bitstream calibration of P, D_EQ, C1–C4 and today's deadlines at 2M records, 20% and 50% on package;
   - all responses correct;
   - leakage Runs A and B;
   - throughput at P.

**Expected** (§1.2 model, card stash rate): about 2,850–2,900 cycles per request, 1.7× at 0–20% on package and
1.4× at 100%. With a faster stash, P falls toward the decision-end bound (≈ 2,250 off package; C1), about 2.2×,
without step 2.

## 8. Implementation (step 1, in progress)

All of the following sits behind `ORAM_OVERLAP2`. Without the define, the preprocessed `flat_oram_gcm.v`,
`secure_oram_top.v` and `doma_kernel.v` are textually identical to v14d1 (`verilator -E`, checked).

**Patch scripts:** `/home/claude/ovp/patch_{ctrl,top,kernel}.py`, applied to v14d1. They are kept so the changes can
be reviewed as one diff.

**Deviations from §1–§3, found while building:**
- **Two tails, one per access parity.** An off-package access's tail lasts from S_EA_START to its end (≈ 2,820
  cycles), longer than P − (the next access's decision time). With one tail, an off→on pair failed check C3 in the
  first simulation. Each tail has its own context: counter, t_arr, class, op, result-zero flag, bucket, deadline
  record, write pending and handed-off flags.
- **Write-backs leave in access order, one in flight, each acknowledged before the next is issued.** The kernel's
  bucket-port switch routes B responses by the latest AW. In the first simulation, an on-package write issued while
  an off-package write's B was still outstanding lost that B, which looked like a same-bucket hazard (C4 fired).
  - On package, the write issues as soon as the engine is free and quiet. Not observable.
  - Off package, it issues exactly at t_arr + AR_WB. If the engine is busy then, the design halts (fail-stop),
    never waits.
- **The write stream's hold** uses the progress of the access being written: M's progress while M is still on that
  access, otherwise "all positions done".
- **T takes the access at S_EA_START.** The off-package write gate (t_arr + AR_WB) then runs on T's context, while
  M finishes the encryption.

**Fail-stop checks implemented:**

| Check | Condition |
|---|---|
| C1 | M has passed the previous access's S_EA_START when F accepts |
| C3 | The tail of the same parity is idle at M's take and at S_EA_START. Results leave in order, one at a time. |
| C4 | A same-bucket write-back is acknowledged at the shifted read gate |
| Read engine | Free at accept and at the gate |
| Buffer reuse | Scratch and result buffers of the same parity are free |
| Write engine | Free and quiet at an off-package write's fixed time |

**Testbench additions:**
- **Overlap-aware eviction scoreboard.** A PUT counts at its access's S_EA_START. The slot list is taken as decided.
- **`folded off-package shape hash`.** Per-access events relative to the access start, folded in completion order.
  It is defined under overlap and computed identically in the serial build, so the two can be compared.
- **On-package release/end hash** under overlap.
- **Test options:** `+same_key=R` and `+abab_key=R`.
- **Injected leak, test only (`TB_OV_LEAK`):** a PUT's read gate is one cycle late.

**First result** (4 KB, λ 7, 20% on package, host read latency 401, preload of 512, then 200 + 4 commands, P = 2,900):
- **Correctness:** all responses correct; no halt; the eviction scoreboard checked 84,224 copied beats with 0 wrong.
- **Throughput:** 2,926 cycles per command, against 4,863 for v14d1 at 20% (1.66×). The excess over P comes from
  same-bucket shifts: with 512 records there are only 73 buckets, so equal consecutive buckets are common in this
  test.

**Comparison runs** (`/home/claude/ov/R`; v14d1 = `base`, overlap = `ovf`; 4 KB, λ 7, preload of 512, then about
200 commands; all runs pass every check with 0 wrong evicted beats):

| Run | v14d1 cycles/cmd | Overlap cycles/cmd | Gain |
|---|---|---|---|
| 0% on package, host read latency 401 | 5,138 | 2,926 | 1.76× |
| 20%, card-like stash (gap 40, 3.9 pseudo-channels, one ID, latency 120) | 4,924 | 2,962 | 1.66× |
| 100% on package | 4,141 | 2,908 | 1.42× |

**Paired streams** (same keys and arrivals; 0%, 50% and 100% PUTs; 20% on package; 300 commands): every visible hash
is identical across the three:
- bucket-port timing, over 3,968 requests;
- folded off-package shape;
- on-package release and end.

**Against v14d1:**
- **On-package release and end:** identical in every run (3,738 and 3,869 cycles after each access's start).
- **Folded off-package shape: every access identical to v14d1 except same-bucket ones.** The per-access event dump
  (`+shape_dump`, 0% on package, 64 accesses) shows exactly one differing access, number 59, whose bucket equalled
  the previous access's. Every one of its events is shifted by D_EQ = 2,700, as designed (D1: public bucket
  equality). There are 73 buckets in these tests, so equal consecutive buckets are common; at 2M records they are
  rare.

**Injected leak (`TB_OV_LEAK`, a PUT's read gate one cycle late) is caught:**

| Hash | 0% PUTs | 100% PUTs |
|---|---|---|
| Bucket-port timing | 741e8f33… (as without the leak) | **3c8d5054…** |
| Folded off-package shape | 13f150e6… | **296c0f8f…** |
| On-package release/end | a0e60f76…, release 3,738 | **013953e6…, release 3,739** |

**Repeated keys:** the same key 120 times in a row (`+same_key=120`) and ABAB (`+abab_key=120`), at 0%, 50% and 100%
PUTs. Every response is correct, the scoreboard reports 0 wrong, and the paired hashes are identical:
- same key: 52b9f3be… / 7be8689f… / bff2058f…;
- ABAB: 883a80f9… / 41d51c90… / bff2058f….

Throughput is 2,965 cycles per command: a repeated key goes to its fresh random bucket, so it never stalls.

## 9. Timing-leak review of step 1 (every wait that could reach a visible event)

**Visible events:**
- **Host bucket port:** each read and write (time, address, length), R and W beats.
- **The result:** its release and its end.
- **The start spacing:** the request rate.

On-package HBM traffic, the stash and the metadata are on package and not observable; their only effect is through
fail-stop deadlines.

**Two leaks found in the first version and fixed:**
1. **The start waited on F being free.** F is free once M takes the previous access, after M's previous encryption
   or copies, whose duration depends on the stash. Now s(j) = max(request presented, s(j−1) + P (+ D_EQ)) exactly. If
   F still holds the previous access then, the design halts (C3). With P = 2,900 this cannot happen inside the
   deadlines: M is free by s(j−1) + about 600 off package and about 840 on package.
2. **The same-bucket shift depended on whether the previous write had been acknowledged.** An on-package write's
   hand-off time depends on the eviction copies. The shift now depends on bucket equality with the previous access
   alone (public). At the shifted gate that write must be acknowledged, else the design halts (C4). The bucket of the
   access before that is never a reason to shift; its write must be acknowledged by the read, else halt.

**Every remaining wait, and why it is safe:**

| Wait | Depends on | Visible effect |
|---|---|---|
| Kernel presents a request | Its command fetch (HBM), a free request buffer (freed at a result's end, public), completion-queue room (freed after a response write, public) | Request arrival: public, as today |
| F accept | Request presented, s(j−1) + P (+ D_EQ) | None beyond those (no wait on internal state; C1/C3 halt instead) |
| F lookup | Position-map and record latency (HBM) | None: the read issues at s + CT_RD exactly (late lookup: halt) |
| Read gate | Fixed: CT_RD (+ D_EQ on public equality) | None |
| Read beats | Host memory latency and the other access's fixed write traffic (public), never back-pressured | As today (A6) |
| M take, stash open, decisions, encryption | Previous access's encryption or copies, stash commit (internal) | None: bounded by the fixed deadlines (fail-stop) |
| Off-package write | Fixed: t_arr + AR_WB. The write engine must be free and quiet then (halt otherwise); a beat held by unfinished encryption is a stall (halt) | None |
| On-package write | Engine free and quiet, copies landed | Not observable (HBM); bounded by AR_REL_H (halt at the release time) |
| Release | Fixed: t_arr + AR_REL(_H); write handed off by then (halt otherwise); results in order, one at a time (halt otherwise) | None |
| Kernel response write | After the result's end | Public |

**Halts.** Fail-stop conditions now include C1, C3, C4, the write engine and the result order. As for v14d1's
overruns, whether one fires can depend on internal timing. With calibrated budgets, none fires: the simulations
above have no halt, and the card's debug calibration must show margins for each.

**Checked in simulation:**
- **Paired streams** (GET/PUT mix 0/50/100%, same keys and arrivals): identical bucket-port timing, per-access
  off-package shape, and on-package release/end hashes.
- **Same key ×120 and ABAB:** identical paired hashes.
- **Injected one-cycle PUT-dependent delay:** caught by all three hashes.
- **Per-access event dump against v14d1:** identical except the public same-bucket shift.

**After both fixes: per access, overlap equals v14d1 exactly, apart from the public shift.** The testbench takes D_EQ
out of every time of exactly the accesses whose bucket equalled the previous access's (the "equality-corrected"
hashes). The result must equal v14d1's hashes bit for bit:
- **0% on package:** off-package shape including every R and W beat, 5b58a7fb… for both builds.
- **100% on package:** release/end, 7b6e4606… for both builds.

`run_overlap.sh` checks this at 0%, 100% and 20% with the card-like stash.

## 10. Step 2: four in flight (`ORAM_OVERLAP4`)

**Build switch.** An OVERLAP4 build defines both `ORAM_OVERLAP2` and `ORAM_OVERLAP4`. Every step-1 block sits
unchanged in the `else` branch of an `ifdef ORAM_OVERLAP4`. Checked with `verilator -E`: a step-1 build and a v14d1
build preprocess to exactly the text they had before. Patches: `/home/claude/ovp/patch_ov4.py` (controller) and
`patch_tk4.py` (top, kernel), applied after the step-1 patches.

**Structure:**

| Part | Step 2 |
|---|---|
| Contexts | 4, index = access number mod 4. Front records, scratch buffers, result buffers, tails and request buffers are each four copies of the existing single-write-port templates. The kernel holds up to four commands. |
| Main stage M | Decryption on core D (the stored IV), the decisions and the commit. It is free for the next access once the eviction copies are done (staging reuse: `stash_hbm.v` unchanged). |
| Encryption stage E | Core E, jobs in access order: an encryption off package, an IV advance on package. The boot format also runs on core E, so all IVs come from one generator in the serial order. |
| Read address (D2) | At accept, if one of the three previous accesses requested the same key and has not passed its decisions, the read goes to that access's new bucket (drawn at its start). A select, no wait. |
| Status, pool index, bucket record | As looked up, then corrected by every position-map and record write made after the lookup and before M takes the access. M's take reads no memory. |
| Same bucket (D1) | The bucket equals one of the three previous accesses' (public) → fixed shift D_EQ (default 3,600). Each of those writes must be acknowledged at the shifted gate (C4, else halt). The decryption of such an access starts only after its read has issued, after the earlier access's IV and tag were written. |
| Start rule | s(j) = max(request, s(j−1) + P (+ D_EQ)), P default 1,500. The context four back must be finished (taken, tail done, write acknowledged), else halt. |
| Budgets | The stages queue behind earlier accesses, so the arrival-relative write-back and release get fixed allowances: AR_WB +700, AR_WB_H +1,200, AR_REL_H +1,400 (`ORAM_OV4_X*`, to be calibrated). Per-access latency rises. Throughput is set by P. |

**First results** (4 KB, λ 7, host read latency 401, 20% on package, preload of 512, then 204 commands):
- **Correctness:** all responses correct; 84,224 copied beats checked, 0 wrong; no halt.
- **Throughput:** 1,631 cycles per command, against 4,863 for v14d1 (3.0×). Excluding the 6 same-bucket shifts:
  about 1,523 (3.2×).

**Regression:** `OV=4 bash sim/run_overlap.sh`. Same set and checks as step 1, plus keys repeating every 3 and every
4 commands. The comparison with v14d1's per-access times is skipped, because the budgets differ.

**Not yet:**
- debug and calibration records for four contexts;
- the netlist check of the new memories;
- the XRT-mock host sequence for step 2;
- card calibration of P, D_EQ and the allowances.

**Step-2 fixes found by the regression (all internal timing, no visible effect):**
1. **Eviction copies overlap the next access.** At 0% on package, M waited for an access's copies before taking the
   next one, which pushed a later encryption past its fixed write-back time (fail-stop halt). Now:
   - the copies belong to `c_own`, set when an access's decisions start, and run on while M takes the next access;
   - only the next stash open waits for them (the staging slots are reused);
   - E sees an access's pending copies only while it is still `c_own`.
2. **The stash open waits for the previous commit to register.** The stash's write-quiet flag lags a commit request
   by a cycle or two, so an open right after a commit was refused (stash error). The open now also requires no
   commit request this cycle and at least 3 cycles since the last one.
3. **Same-cycle corrections at the take.** A bucket-record write by the previous access, landing in the cycle M took
   the next access to the same bucket, was missed: the access took the old record, missed the block just evicted
   there, and one GET returned zeros. A record write, a position-map write, or the access's own record read landing in
   the take cycle is now passed straight to M.
4. **Testbench:** the scoreboard attributes each copy to its owner's slot list and request.

After these fixes, 0% and 20% on package (preload of 512, then 204 commands) both pass: all responses correct,
0 wrong evicted beats, no halt. That is 1,649 and 1,631 cycles per command: 3.1× and 3.0× v14d1, including the
same-bucket shifts.

**Step-2 status, 2026-11-04:**
- **`OV=4 run_overlap.sh`:** 26/26 on your laptop after the bucket-record fixes. The encryption stage's IV/tag write
  never shares a cycle with a record write. A same-bucket access fetches its record at its shifted gate. The
  decisions wait for the record.
- **Remaining before a card build** (scripts in the package):
  - `sim/run_overlap_more.sh`:
    - the scratch_buf netlist check;
    - host_doma's sequence in the XRT mock for steps 1 and 2;
    - 4,096-record kernel runs: 3 seeds × 0 / 20 / 50% on package, steps 1 and 2;
    - the too-slow-stash fail-stop check for step 2.
  - `bash sim/run_scratch_netlist.sh vivado` on the server.
  - `bash vitis/synth_ooc_overlap.sh 1` and `4` on the server: utilization and 300 MHz timing.
- **scratch_buf unit test (`tb_scratch.v`):**
  - random traffic on all five ports against a reference copy;
  - passes on the RTL and on the Yosys gate netlist;
  - the negative control (one bank's copy writes dropped) fails at once, with 2,072 mismatches.

## 11. Logic depth without Vivado (2026-11-04)

**Method.** `sim/ys_depth.sh` maps the controller, top and kernel (where all overlap logic lives) to UltraScale+
cells with Yosys (`synth_xilinx -family xcup`, no LUT RAM, so register-array read muxes count). The datapath blocks
(GCM, stash, scratch, AXI masters, HBM tables) are black boxes. `sim/ys_depth.py` then reports, for every register,
the deepest logic in front of it:

- a LUT counts 1;
- MUXF7, MUXF8 and MUXF9 count 0.3 each;
- a carry chain counts 1 to enter, then 0.15 per CARRY4.

It is a proxy, not a timing analysis. The measure that matters is the comparison with v14d1, whose paths closed at
300 MHz on the card.

**Before.** v14d1's deepest paths are its own:

| Path | Depth |
|---|---|
| `bkt_slot_list` | 13.9 |
| `bm_wr_slot_list` | 13.8 |
| `trf_beat` | 13.4 |
| M's done gate | 10–12 |

The overlap builds added new paths:

| Build | Path | Depth |
|---|---|---|
| Step 2 | the read gate and lookup (`f_ct[f_par]` 4:1 muxes, 32-bit compares) into `bm_rd_bucket`, `s_need`, `f_eqa`, `b_ctx` | 10.8–11.8 |
| Step 2 | the write-back issue (`t_ct` and `t_tarr` muxes, an add, a compare) into `axim_cmd_bucket` | 10.1 |
| Step 2 | `HALT_BITS` | 12.1 |
| Step 1 | the same write-back path | 10.1 |
| Step 1 | `HALT_BITS` | 12.0 |

**Changes.** Applied by `/home/claude/ovp/patch_timing.py`, after `patch_ov4.py`. All are cycle-exact.

- **T1, the tail's deadlines (steps 1 and 2).** `t_rel = t_ct − t_tarr` is kept as its own 33-bit counter:
  - it is set with `t_ct` at S_EA_START and counts with it;
  - each context compares it with constants (`t_wbok`, `t_gok`, `t_glate`, `ev_rtv`), and the write-back issue and
    T_GATE then select a single bit;
  - the 33 bits make the difference exact, so no compare can wrap.
- **T2, the serial tail (steps 1 and 2).** S_WB_GATE, S_DDR_WRITE, S_DONE_GATE and S_RES_STREAM are never entered in
  an overlap build, because T does that work. Their logic is removed there: each state now goes to S_HALT, which is
  equally unreachable.
- **F1, the front stage (step 2).** F holds one access at a time, so what it read through `f_par`-indexed 4:1 muxes now
  comes from plain copies:
  - the forwarding result, draw, partition and slot (written only at the accept);
  - the buckets of the three earlier accesses (a shift register, written at each lookup);
  - its own bucket and same-bucket flag;
  - its counter (`fl_ct` equals `f_ct[f_par]` while F is busy).

  Each copy is written in the same cycle, with the same value, as the array entry it mirrors. The read gate and the
  lookup's overrun check become flags registered with `fl_ct`: each takes the comparison of the counter's next value.
  The same-bucket mask is built per context from three equalities, with no variable bit index. The context indices
  are explicit 2-bit wires (`an`, `fp_m1..3`).

**After:**
- **Step 2:** every overlap path is 9.5 or less: the tail's result start at 9.5, `HALT_BITS` at 8.8. The only deeper
  paths are v14d1's own three.
- **Step 1:** every overlap path is 9.0 or less.

**Equivalence.**
- **v14d1:** its preprocessed source is unchanged (`verilator -E`).
- **Steps 1 and 2:** each was built from the old and the new RTL and run on the same cases. Every output line is
  identical: responses, every visible hash, the bucket-write digests, cycle counts, calibration maxima and halt records.
  - Step 2 cases: p50, c0, c1, k4a, ab50, cs and slow56.
  - Step 1 cases: p50, c0, c1, ab50, cs and slow78.
  - Halt cases, both steps: a too-slow stash (stash error), a too-slow bucket read (read-gate overrun) and an
    on-package deadline miss (write-back start and release hand-off).
- **`OV=4 run_overlap.sh` on the new RTL:** 26 passed, 0 failed. Throughput is unchanged:
  - 0% on package: 1,649 cycles per command;
  - p50: 1,600;
  - card-like stash: 1,720;
  - 100% on package: 1,630.

**Remaining risk.** The scratch and result buffers' read data passes one more 4:1 mux (step 2) or 2:1 mux (step 1)
after the block RAM than in v14d1. That is one LUT level on a path v14d1 closed.

## 12. Fixed-schedule check (`check_fixed_schedule.py`, in `run_overlap.sh`)

The paired streams vary only GET and PUT. This check also covers the keys, the data and the stash state. The
testbench (`+fix_dump=<file>`) writes one line per completed access:
- its start cycle;
- the cycle its request was first presented;
- the public same-bucket flag;
- whether it is on package;
- one hash of its visible times relative to its start, with the same-bucket shift taken out. Off package that is every
  bucket-port event, the release and the end; on package, the release and the end.

The check requires three things:

1. **One shape per class, in each run.** Every off-package access has the same hash, and every on-package access has
   the same hash.
2. **The start rule, exactly.** Every start is `s(j) = max(r(j) + K1, s(j−1) + P (+ D_EQ) + K2)`, where `r(j)` is the
   request time and `K1` and `K2` are the design's constants. Both are learned from the run, and every access must then
   follow them. Here `K1 = K2 = 1`.
3. **The same shapes across runs** that share the memory latencies: random keys, one repeated key, ABAB, keys repeating
   every 3 and every 4 commands, 0 / 20 / 50% on package, and the card-like stash.

The testbench memories have fixed latencies (`+hb=0`). Only the memories' latencies, the request arrivals and the
public bucket equality may move a visible time, so any dependence on keys, data or the stash shows up as a second
shape, or as a start off the rule.

**First results, step 2 (new RTL).** Every run had one shape per class, every start followed the rule (`K1 = K2 = 1`),
and the shapes were identical across seven runs:

| Run | Accesses | Off package | On package |
|---|---|---|---|
| p50 | 816 | 669 | 147 |
| sk100 | 636 | 519 | 117 |
| ab50 | 636 | 519 | 117 |
| k3a | 636 | 519 | 117 |
| k4a | 636 | 333 | 303 |
| c0 | 716 | 716 | 0 |
| cs | 716 | 577 | 139 |

The injected-leak build (a PUT's read one cycle late) fails, as it should:
- l100: two off-package shapes, 668 and 1 (the one GET in run 2);
- l0: two shapes in each class, because the preload is all PUTs.

**Regression with the fixed-schedule checks, on the new RTL (2026-11-04):**

| Step | Result | Fixed-schedule checks |
|---|---|---|
| Step 2 (`OV=4 run_overlap.sh`) | 29 passed, 0 failed | 3 |
| Step 1 (`run_overlap.sh`) | 32 passed, 0 failed | 3, plus the per-access comparison with v14d1 |

The three fixed-schedule checks are:
- every run, one visible shape per class, start rule exact (15 runs);
- identical shapes across the 12 runs with the same memory latencies;
- the injected-leak build fails.

## 13. Card build of step 2 (package `fpga_zcu208_overlap2_v14c_overlay.zip`)

**Package.** An overlay over v14c. It holds every v14d1 file (51 files; the overlap changed six of them: the three RTL
files, `vitis/build.sh`, `sim/run_verilator.sh` and `sim/tb_doma_kernel.v`) plus the overlap files, 67 files in all,
and a new `MANIFEST.sha256` covering the whole tree after unzipping over v14c (319 files). Check it with:

    cd fpga_zcu208 && sha256sum -c --quiet MANIFEST.sha256

The three RTL files carry both steps behind the switch. The overlap top (`secure_oram_top.v`) connects the
controller's `client_acc`, `client_wsel` and `client_rsel`, and the kernel (`doma_kernel.v`) holds up to four
commands. Without the switch, all three preprocess to exactly v14d1's text (`verilator -E -P`, compared on 768 files:
the 3 RTL files × 256 configurations, namely block sizes 32 B / 256 B / 4 KB / default × NMAX 2M or default ×
strict / arrival / trace / debug / stash IDs / interim / plain × SYNTHESIS and SECURE_BUILD on and off; 0 differ).
`vitis/package_kernel.tcl` packages every `rtl/*.v` and `*.vh`, so no file list changes. An `ORAM_OVERLAP4` without
`ORAM_OVERLAP2` stops at elaboration (a missing module).

**Build command** (in `vitis/`; Vitis 2024.1 environment as for v14d1):

    OVERLAP=4 SCHED=arrival BEATS=128 CFG=doma_big2m.cfg NMAX=2097152 LAMBDA=7 TARGET=hw bash build.sh

`build.sh` prints the `rtl/oram_build_cfg.vh` it wrote. For this command:

    `define ORAM_BLOCK_BEATS 128      (inside `ifndef)
    `define ORAM_N 2097152            (inside `ifndef)
    `define ORAM_SCHED_ARRIVAL
    `define ORAM_OVERLAP2
    `define ORAM_OVERLAP4
    `define ORAM_OV_P 1500
    `define ORAM_OV_DEQ 3600
    `define ORAM_C 7                  (inside `ifndef)

Other switch values:
- `OVERLAP=2` (or 1) writes `ORAM_OVERLAP2`, with P 2,900 and D_EQ 2,700;
- unset or 0 is v14d1;
- any other value stops the build;
- `OV_P` and `OV_DEQ` override P and D_EQ. Without them the defaults above hold, and they are the values every
  regression used;
- step 2's allowances keep their RTL defaults: `ORAM_OV4_XWB` 700, `ORAM_OV4_XWB_H` 1,200 and `ORAM_OV4_XREL_H` 1,400.

After a `TARGET=hw` build, `build.sh` runs two checks:
- `check_timing.sh`: whether the routed timing met 300 MHz;
- `check_overlap_build.sh 4`: whether the configuration has both defines, and whether the placed design
  (`post_place_util_hier.rpt`) contains the second GCM core `u_aes_gcm_e` and the four scratch buffers
  `g_scr[0..3]`. Either missing means v14d1 was built, or the overlap was trimmed.

**Host.** `host_doma`, `host_phases` and `host_ycsb` are unchanged, and are run exactly as for v14d1
(`DOMA_LAMBDA=7`, the same `DOMA_N` and pool). host_doma's own sequence on the step-2 RTL, through the XRT mock
(N max 2M, n = 4,096, 20% on package):
- boot errors 0;
- 5,000 commands (2,546 GET, 2,454 PUT), all responses correct;
- 7,617,091 device cycles: 1,523 per command, against about 4,900 for v14d1;
- per-command latency 5,434–9,572 cycles.
