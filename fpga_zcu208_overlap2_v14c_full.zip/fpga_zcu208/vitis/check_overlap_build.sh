#!/bin/bash
# check_overlap_build.sh <2|4> -- after an OVERLAP build (TARGET=hw): is the overlap design what was built?
#   1. rtl/oram_build_cfg.vh (written by build.sh) has the switch: OVERLAP=4 -> ORAM_OVERLAP2 and ORAM_OVERLAP4.
#   2. The placed design (post_place_util_hier.rpt, written after placement by post_place.tcl) has the overlap
#      instances: step 2 the second GCM core (u_aes_gcm_e) and four scratch buffers (g_scr[0..3]); step 1 the second
#      scratch buffer (u_scratch1). If they are missing, synthesis built (or trimmed back to) v14d1.
cd "$(dirname "$0")"
OV=${1:-4}; ok=1
C=../rtl/oram_build_cfg.vh
grep -q '^`define ORAM_OVERLAP2' $C || { echo "FAIL: $C has no ORAM_OVERLAP2"; ok=0; }
if [ "$OV" = 4 ]; then grep -q '^`define ORAM_OVERLAP4' $C || { echo "FAIL: $C has no ORAM_OVERLAP4"; ok=0; }
else grep -q '^`define ORAM_OVERLAP4' $C && { echo "FAIL: $C has ORAM_OVERLAP4 (step 2) in a step-1 check"; ok=0; }; fi
echo "build configuration ($C):"; sed 's/^/    /' $C
U=$(find ${XDIR:-_x} -name post_place_util_hier.rpt 2>/dev/null | head -1)
if [ -z "$U" ]; then echo "FAIL: no post_place_util_hier.rpt under ${XDIR:-_x}/ (did placement run?)"; ok=0
else
    echo "placed design: $U"
    if [ "$OV" = 4 ]; then
        n=$(grep -c "u_aes_gcm_e " "$U"); echo "    second GCM core (u_aes_gcm_e) rows: $n"; [ "$n" -gt 0 ] || { echo "FAIL: no u_aes_gcm_e in the placed design"; ok=0; }
        for k in 0 1 2 3; do n=$(grep -cE "g_scr\[$k\]" "$U"); echo "    scratch buffer g_scr[$k] rows: $n"; [ "$n" -gt 0 ] || { echo "FAIL: no g_scr[$k] in the placed design"; ok=0; }; done
    else
        n=$(grep -c "u_scratch1 " "$U"); echo "    second scratch buffer (u_scratch1) rows: $n"; [ "$n" -gt 0 ] || { echo "FAIL: no u_scratch1 in the placed design"; ok=0; }
    fi
    grep -E "u_aes_gcm_e |u_aes_gcm |g_scr\[[0-3]\]\.u_s |u_scratch1? " "$U" | sed 's/^/    /' | head -12
fi
[ $ok = 1 ] && echo "PASS: the overlap design (step $([ "$OV" = 4 ] && echo 2 || echo 1)) was built" || exit 1
