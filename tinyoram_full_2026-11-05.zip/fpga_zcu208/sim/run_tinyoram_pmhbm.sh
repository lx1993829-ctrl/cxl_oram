#!/bin/bash
# run_tinyoram_pmhbm.sh -- regression for the flat position map in HBM (TINYORAM_PM_HBM, patch 10; README §26).
#   bash run_tinyoram_pmhbm.sh               all stages (about 2 hours on 2 cores)
#   STAGES="1 2" ...                         some stages; logs in build_tinyoram/pmhbm/
# Needs Verilator 5 and iverilog.
#  1. Default builds unchanged: with patches 01-09 and with 01-10, every core file patch 10 touches preprocesses to the
#     same source when TINYORAM_PM_HBM is not defined: 7 sizes x 1:1/merged x native/flat PosMap/run-time depth x
#     with/without TOP_PLAINTEXT.
#  2. Lint (lint_tinyoram.sh, which adds tinyoram_pm_axi.v for these builds): 4 KB at L = 10 and 18, 64 B at L = 10
#     and 19, with and without the plaintext top.
#  3. The position map in HBM (h) against the same map on chip (f: patch 07's flat PosMap), 4 KB and 64 B, L = 10,
#     merged, plaintext top: the same commands give the same responses, the same tree bursts (every per-launch count
#     and traffic record) and, at a split top, byte-identical tree and top images; only the cycles differ. Each
#     access reads and writes one entry on gmem4 (the testbench counts both), and the map is zeroed (4 KB bursts)
#     at the first launch after an init, over stale contents.
#  4. h at 4 KB under the kernel's other paths: top_all, an odd top, re-boot (also with a split, a moved pages buffer),
#     write-error injection and release, preload, repeated keys, host latency and gaps, late write responses,
#     slow ready; and h without the plaintext top at 64 B.
#  5. Mutants, each must be caught: m1 the entry never written back (PosMapPLB), m2 the entry written in lane 0
#     whatever its address (tinyoram_pm_axi), m3 the map not zeroed (stale entries; tinyoram_pm_axi).
# Exit 0 = every check passed; last line "ALL n CHECKS PASSED".
set -u
cd "$(dirname "$0")"
TOR=$(cd ../tinyoram && pwd)
B=${PM_DIR:-build_tinyoram/pmhbm}; mkdir -p $B
[ -f $TOR/upstream/TinyORAMCore.v ] || bash $TOR/fetch_tinyoram.sh 4k > /dev/null || exit 2
VFLAGS="--binary --timing -j 0 -O2 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-STMTDLY -Wno-INITIALDLY -Wno-WIDTH -Wno-ZERODLY -Wno-BLKANDNBLK"
STAGES=${STAGES:-"1 2 3 4 5"}; L=10
FAILS=0; NCHK=0
pass() { echo "  PASS  $1"; NCHK=$((NCHK+1)); }
fail() { echo "  FAIL  $1"; FAILS=$((FAILS+1)); NCHK=$((NCHK+1)); }
has() { case " $STAGES " in *" $1 "*) return 0 ;; esac; return 1; }
fetch_geo() {   # fetch_geo <dir> <fetch args...>: a private fetch (the shared ../tinyoram/build is left alone)
    local d=$1; shift; rm -rf $d; mkdir -p $d
    cp $TOR/fetch_tinyoram.sh $d/ && cp -r $TOR/config $TOR/patches $d/ && ln -s $TOR/upstream $d/upstream
    bash $d/fetch_tinyoram.sh "$@" > $d/fetch.log 2>&1
}
mk() {   # mk <name> <host words> <fetch args...>   (MUT=<python edit> MUTF=<file>: a mutant; the file is a core source or rtl/<f>)
    local name=$1 W=$2; shift 2; local g=$B/$name
    [ -x $g/obj/Vtb ] && [ -z "${REBUILD:-}" ] && return 0
    fetch_geo $g "$@" || { echo "  FETCH FAILED: $name ($g/fetch.log)"; exit 2; }
    mkdir -p $g/rtl && cp $TOR/rtl/*.v $g/rtl/
    if [ -n "${MUT:-}" ]; then
        local mf=$g/build/src/$MUTF; case "$MUTF" in rtl/*) mf=$g/$MUTF ;; esac
        python3 -c "$MUT" $mf || { echo "  MUTANT NOT APPLIED: $name"; exit 2; }
    fi
    local pm=""; grep -q 'define TINYORAM_PM_HBM' $g/build/src/tinyoram_config.vh && pm=$g/rtl/tinyoram_pm_axi.v
    echo "  building $name ..."
    verilator $VFLAGS -I$g/build/src -DSIMULATION -DTB_HOST_WORDS=$W -DTB_TOP_WORDS=2097152 -DTB_NMAX=$((4 << L)) -DTB_CMD_WORDS=1048576 \
        --top-module tb_tinyoram_kernel ./tb_tinyoram_kernel.v ./axi_mem_model.v \
        $g/rtl/tinyoram_kernel.v $g/rtl/tinyoram_axi_adapter.v $pm $(sed "s#^#$g/build/src/#" $g/build/src/files.f | tr '\n' ' ') \
        -Mdir $g/obj -o Vtb > $g/build.log 2>&1 || { echo "  BUILD FAILED: $name ($g/build.log)"; exit 2; }
}
run() { local name=$1 tag=$2; shift 2; ( ulimit -s unlimited 2>/dev/null; ./$B/$name/obj/Vtb +hb=0 +limit=2000000000 "$@" > $B/$tag.log 2>&1 ); }
ok() { grep -q "TINYORAM KERNEL: ALL CHECKS PASSED" $B/$1.log && ! grep -qE "^FAIL|ERROR|Error:" $B/$1.log; }
# per-launch lines without the cycle counts (size, completed, errors, gets/puts, tree AR/AW; traffic records)
lines() { grep -E "^[a-z0-9]+: (size=|traffic record)" $B/$1.log | sed -E 's/host cycles=[0-9]+  device total=[0-9]+  //; s/latency min\/max=[0-9]+\/[0-9]+  //'; }
dev() { grep -E "^$2: size=" $B/$1.log | sed -E 's/.*device total=([0-9]+).*/\1/'; }
lmin() { grep -E "^$2: size=" $B/$1.log | sed -E 's/.*latency min\/max=([0-9]+)\/.*/\1/'; }
pmline() { grep -E "^$2: position map port" $B/$1.log | sed -E 's/^[a-z0-9]+: position map port: //'; }

if has 1; then
echo "== 1. patch 10 without TINYORAM_PM_HBM: the core preprocesses as before"
W=$(mktemp -d); trap 'rm -rf "$W"' EXIT
for t in p9 p10; do
    cp -rL $TOR/upstream $W/$t
    for p in $TOR/patches/0[1-9]_*.diff; do (cd $W/$t && patch -s -p1 < $p) || { echo "patch $p failed"; exit 2; }; done
done
(cd $W/p10 && patch -s -p1 < $TOR/patches/10_posmap_hbm.diff) || { echo "patch 10 failed"; exit 2; }
files=$(grep -E '^\+\+\+ b/.*\.v$' $TOR/patches/10_posmap_hbm.diff | sed -E 's#^\+\+\+ b/##; s#\t.*##')
norm() { python3 -c '
import re, sys
s = open(sys.argv[1]).read()
s = re.sub(r"/\*.*?\*/", " ", s, flags=re.S); s = re.sub(r"//[^\n]*", " ", s)
s = re.sub(r"\s+", " ", s); s = re.sub(r" ?([()\[\],;{}=:]) ?", r"\1", s); print(s.strip())' "$1"; }
bad=""; n=0; nc=0
for sz in 64 128 256 512 1k 2k 4k; do for mg in 0 1; do for md in none flat rt; do for tp in 0 1; do
    mkdir -p $W/cfg; cp $TOR/config/tinyoram_config_$sz.vh $W/cfg/tinyoram_config.vh; nc=$((nc+1))
    [ $mg = 1 ] && sed -i 's#^`endif#`define TINYORAM_MERGE 1\n`endif#' $W/cfg/tinyoram_config.vh
    [ $md = rt ] && sed -i 's#^`endif#`define TINYORAM_RTDEPTH 1\n`endif#' $W/cfg/tinyoram_config.vh
    [ $md = flat ] && sed -i 's#^`endif#`define TINYORAM_RECURSION 1\n`endif#' $W/cfg/tinyoram_config.vh
    [ $tp = 1 ] && sed -i 's#^`endif#`define TINYORAM_TOP_PLAINTEXT 1\n`endif#' $W/cfg/tinyoram_config.vh
    for f in $files; do
        n=$((n+1))
        for t in p9 p10; do iverilog -E -I$W/cfg -I$W/$t/include -o $W/$t.E $W/$t/$f 2>/dev/null || bad="$bad $f($t,E)"; norm $W/$t.E > $W/$t.N; done
        cmp -s $W/p9.N $W/p10.N || bad="$bad $f($sz,m$mg,$md,tp$tp)"
    done
done; done; done; done
[ -z "$bad" ] && pass "patch 10 without the define: $(echo $files | wc -w) core files x $nc configurations ($n comparisons), preprocessed sources identical" \
              || fail "patch 10 changes the default core:$bad"
fi

if has 2; then
echo "== 2. lint of the PM_HBM sources"
for v in "4k 10 merge hbmpm topplain" "4k 10 merge hbmpm" "4k 18 merge hbmpm topplain" "64 10 merge hbmpm topplain" "64 19 hbmpm"; do
    t=lint_$(echo $v | tr ' ' _); g=$B/$t
    if ! fetch_geo $g $v; then fail "$v: fetch ($g/fetch.log)"; continue; fi
    bash ./lint_tinyoram.sh $g/build/src $g/build/src/tinyoram_config.vh $B/$t > $B/$t.out 2>&1 \
        && pass "$v: lint, every module ($(tail -1 $g/fetch.log | sed -E 's/.*configuration //'))" \
        || { fail "$v: lint ($B/$t.out)"; sed 's/^/        /' $B/$t.out | head -8; }
done
fi

HW4=4194304   # 4 KB: room for two trees (re-boot to a moved buffer)
if has 3; then
echo "== 3. the position map in HBM (h) against the same map on chip (f), L = $L, merged, plaintext top"
for sz in 4k 64; do
    w=$HW4; [ $sz = 64 ] && w=1048576
    mk f_$sz $w $sz $L merge flatpm topplain & mk h_$sz $w $sz $L merge hbmpm topplain & wait
    pre=""; [ $sz = 64 ] && pre=+preload
    for split in nosplit split all; do
        tree=$(grep -m1 -oE "tree=[0-9]+ bytes" $B/h_${sz}_nosplit.log 2>/dev/null | grep -oE "[0-9]+")
        case $split in nosplit) sa="" ;; all) sa=+top_all ;; split) sa=+top=$(( ${tree:-0} / 7 / 4096 * 4096 )) ;; esac
        dm=""; [ $split = split ] && dm=+dumpmem
        run f_$sz f_${sz}_$split $sa $pre +cmds=200 +cmds2=40 ${dm:+$dm=$B/f_${sz}_$split} &
        run h_$sz h_${sz}_$split $sa $pre +cmds=200 +cmds2=40 ${dm:+$dm=$B/h_${sz}_$split} & wait
        lab="$sz B, $split${sa:+ ($sa)}"
        if ! ok f_${sz}_$split || ! ok h_${sz}_$split; then fail "$lab: not every response correct ($B/f_${sz}_$split.log, $B/h_${sz}_$split.log)"; continue; fi
        why=""
        cmp -s <(lines f_${sz}_$split) <(lines h_${sz}_$split) || why="per-launch counts or traffic differ"
        if [ -z "$why" ] && [ $split = split ]; then
            cmp -s $B/f_${sz}_split_host.hex $B/h_${sz}_split_host.hex || why="tree images differ"
            [ -z "$why" ] && { cmp -s $B/f_${sz}_split_top.hex $B/h_${sz}_split_top.hex || why="top images differ"; }
            rm -f $B/[fh]_${sz}_split_*.hex
        fi
        first=one; [ -n "$pre" ] && first=preload                        # the first launch with commands zeroes the map
        pr=$(pmline h_${sz}_$split run1); one=$(pmline h_${sz}_$split $first)
        [ -z "$why" ] && { [ "$pr" = "200 entry reads, 200 entry writes, 0 zeroing bursts" ] || why="run1 position map traffic: $pr"; }
        [ -z "$why" ] && { echo "$one" | grep -qE "^([0-9]+) entry reads, \1 entry writes, [1-9][0-9]* zeroing bursts" || why="first launch ($first): $one"; }
        fd=$(dev f_${sz}_$split run1); hd=$(dev h_${sz}_$split run1)
        [ -z "$why" ] && pass "$lab: both correct, the same bursts$([ $split = split ] && echo ' and tree/top bytes'); 1 entry read + 1 write per access; run1 $fd -> $hd device cycles (+$(( (hd - fd) / 200 )) per access), min latency $(lmin f_${sz}_$split run1) -> $(lmin h_${sz}_$split run1)" \
                      || fail "$lab: $why"
    done
done
fi

if has 4; then
echo "== 4. h under the kernel's other paths (4 KB, L = $L)"
mk h_4k $HW4 4k $L merge hbmpm topplain
tree=$(grep -m1 -oE "tree=[0-9]+ bytes" $B/h_4k_nosplit.log 2>/dev/null | grep -oE "[0-9]+"); tree=${tree:-56355456}
sp=+top=$(( tree / 7 / 4096 * 4096 ))
i=0
while read -r t args; do
    run h_4k o_$t $args &
    i=$((i+1)); [ $((i % 2)) = 0 ] && wait
done <<EOF
topall +top_all
oddtop +top=12345678 +seed=9
reboot +reboot
rebootsplit +reboot $sp +seed=4
rebootsame +reboot +reboot_same $sp
berr +berr=5 $sp
berrrel +berr_rel +host_wlat=200 $sp
berrlast +berr_last +host_wlat=200
preload +preload $sp
keys +keys=16 +seed=11 $sp
gaps +host_gap=40 +host_lat=200 +seed=3 $sp
wlat +host_wlat=300 $sp
slowack +host_rdy_gap=3 +seed=5 $sp
EOF
wait
for t in topall oddtop reboot rebootsplit rebootsame berr berrrel berrlast preload keys gaps wlat slowack; do
    if ok o_$t; then
        z=$(grep -cE "position map port: .* [1-9][0-9]* zeroing bursts" $B/o_$t.log)
        pass "$t: correct; position map zeroed at $z launch(es) ($(grep -E '^[a-z0-9]+: position map port' $B/o_$t.log | grep -v ': 0 entry reads' | wc -l) launches with traffic)"
    else fail "$t: $B/o_$t.log ($(grep -m1 -E '^FAIL|ERROR' $B/o_$t.log | cut -c1-100))"; fi
done
mk h64n 1048576 64 $L merge hbmpm
run h64n o_64n_e2e & run h64n o_64n_split +top=131072 +preload & wait
for t in o_64n_e2e o_64n_split; do ok $t && pass "64 B, no plaintext top, ${t#o_64n_}: correct" || fail "64 B, no plaintext top, ${t#o_64n_}: $B/$t.log"; done
fi

if has 5; then
echo "== 5. mutants (4 KB, L = $L, split top): each must be caught"
ED='import sys; p = sys.argv[1]; s = open(p).read(); o, n = %s; assert s.count(o) == 1; open(p, "w").write(s.replace(o, n))'
M1=$(printf "$ED" "'pm_st <= pm_upd ? PM_WCAP : PM_IDLE;', 'pm_st <= PM_IDLE;'")
M2=$(printf "$ED" "'<< (8 * req_addr[1:0]);', '<< 0;'")
M3=$(printf "$ED" "'if (zero_start) begin st <= S_Z; zoff <= 64\\'d0; zero_done <= 1\\'b0;', 'if (zero_start) begin zero_done <= 1\\'b1;'")
F1=PosMapPLB.v; F2=rtl/tinyoram_pm_axi.v; F3=rtl/tinyoram_pm_axi.v
for m in 1 2 3; do
    eval "mut=\$M$m; mf=\$F$m"
    MUT="$mut" MUTF=$mf mk m${m} $HW4 4k $L merge hbmpm topplain
    run m$m m${m}_run +top=8388608 +cmds=200 +cmds2=40
    ok m${m}_run && fail "mutant m$m not caught" || pass "mutant m$m caught: $(grep -m1 -E '^FAIL|ERROR' $B/m${m}_run.log | cut -c1-110)"
done
fi

[ $FAILS = 0 ] && { echo "ALL $NCHK CHECKS PASSED"; exit 0; }
echo "$FAILS OF $NCHK CHECKS FAILED"; exit 1
