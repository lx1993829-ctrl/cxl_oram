// tinyoram_kernel.v -- Vitis RTL kernel wrapper for Tiny ORAM (Fletcher et al., FCCM 2015).
//
// Same calling convention, control registers, buffer layout, response and summary records as
// doma_kernel.v, so host_doma drives both:
//   tinyoram_kernel(cmd_input, resp_output, pages, size, top, top_bytes)
//     cmd_input   (m_axi_gmem0)  commands, read          resp_output (m_axi_gmem1)  responses, written
//     pages       (m_axi_gmem2)  Tiny ORAM's tree        size  number of commands in this run
//     top         (m_axi_gmem3)  the tree top (on-package HBM): tree byte offsets below top_bytes live
//                                here instead of in pages (a tree-top cache of top_bytes bytes)
//     top_bytes   (scalar)       0 = the whole tree in pages; >= the tree size = the whole tree in top;
//                                otherwise rounded down to 4 KB
// Control: 0x00 CTRL (ap_start, ap_done clear-on-read, ap_idle, ap_ready), 0x04 GIE, 0x08 IER,
//          0x0C ISR, 0x10 cmd_input, 0x1C resp_output, 0x28 pages, 0x34 size, 0x3C top, 0x48 top_bytes.
// cmd_input:   [0, size*32) headers (byte0 0x01 GET / 0x02 PUT, bytes 4-7 key = block, bytes 8-11
//              record offset in the block, 12-15 record length, 0 = whole block);
//              PUT data at HC + i*BLOCK, HC = roundup(size*32, 4 KB), BLOCK = ORAMB/8 bytes (block-sized slots).
// resp_output: [0, size*32) headers (0x10 ACK / 0x11 ERR, key, latency, status), record [size] =
//              summary (0x5A, bytes 4-7 block size in 32-byte beats, total cycles, min/max latency,
//              error flags, commands completed), record [size+1] = traffic (0x5B, see below);
//              GET data at HR + i*BLOCK, HR = roundup((size+2)*32, 4 KB) (as doma_kernel).
// Packed records (offset/length != whole block): a PUT writes only the record's bytes (Tiny ORAM's own
//              byte write mask, WMask); a GET writes only the record's bytes into its response slot
//              (byte strobes; the rest of the slot is left untouched). A range outside the block is
//              rejected with status 0x40 before Tiny ORAM is accessed.
// Status flags: 0x2 unknown opcode, 0x4 key rejected (>= N), 0x8 ORAM failed (integrity
//               violation or AXI error), 0x10 timeout, 0x20 a command launch named a different pages
//               buffer than the last init launch (the latched one is kept), 0x40 record range outside the block,
//               0x80 top_bytes was rounded down (below the tree size and not a multiple of 4 KB).
//
// What differs from doma_kernel (and why):
//   * Tiny ORAM in place of DOMA, behind tinyoram_axi_adapter: 1:1 AXI translation (TINYORAM_MERGE 0,
//     the default) or contiguous commands merged into one burst (TINYORAM_MERGE 1); tree-top split.
//   * Every init launch (size = 0) re-boots, as doma_kernel's does: Tiny ORAM and the adapter are held
//     in reset, the pages address is latched again, and the build's geometry is reported in record
//     [size+1] (blocks, tree size) WITHOUT touching memory, so the host can check that its pages buffer
//     holds the tree before anything is written. The next launch with size > 0 (the start of the host's
//     preload) zero-fills the tree (an all-zero bucket is Tiny ORAM's "never written" bucket; Tiny ORAM
//     has no DRAM initialiser) and releases Tiny ORAM from reset, which re-initialises its on-chip state
//     (PosMap, PLB, stash). So each host process that starts with an init launch gets a fresh ORAM, even
//     when XRT keeps the xclbin loaded. If the very first launch has size > 0, it latches and fills.
//   * Keys >= N are rejected by the wrapper (Tiny ORAM itself only raises a sticky flag).
//   * Latency of a command, counted from issuing it to Tiny ORAM (2026-10-18, as doma_kernel's arrival
//     mode): primary (header bytes 8-11, summary min/max): data done (GET data received, or PUT data
//     sent) and Tiny ORAM idle and every write-back beat handed off on the bus; the command is then
//     released and the next one issued (the adapter still holds its reads until the writes are
//     acknowledged). Secondary: header bytes 16-19 data ready, 20-23 every write-back acknowledged (B).
//   * Record [size+1] (same format as DOMA's): byte0 0x5B, bytes 8-15 read beats and 16-23 write
//     beats on the tree ports (m_axi_gmem2 plus m_axi_gmem3) during this launch (the launch that zero-fills
//     includes it). Tiny ORAM also fills DOMA's reserved bytes: 1-7 the top port's (m_axi_gmem3) share of
//     those counts in 64-byte units (bits 8-35 read, 36-63 written; 4 KB units in TINYORAM_PM_HBM builds), 24-27 the build's number of blocks N,
//     28-31 the tree size in 64-byte bursts.
//   * Tiny ORAM's crypto keys are its own hard-coded constants (as published).
// Tiny ORAM build configuration comes from the TINYORAM_* defines (patch 01): TINYORAM_ORAMB
// (block bits), TINYORAM_ORAML (levels - 1), TINYORAM_BEDWIDTH (must equal the AXI width, 256).
// Run-time tree depth (TINYORAM_RTDEPTH, patch 08; README §18): the core is built for L_max = TINYORAM_ORAML and
//   runs as the native build of any depth L, 6 <= L <= L_max, chosen by an init launch with size = 0x8000_0000 | L
//   (size = 0: L = L_max). The summary's bytes 1-3 then report the active L, L_max and the smallest L (6); they are
//   0 in a native build. N, the tree, the zero-fill, the key check and the records follow the active L. A
//   requested L outside 6..L_max keeps L_max and sets status 0x100.
`timescale 1ns/1ps
`include "Const.vh"
`include "RTGeo.vh"

module tinyoram_kernel #(
    parameter integer C_S_AXI_CONTROL_ADDR_WIDTH = 12,
    parameter integer C_M_AXI_ADDR_WIDTH         = 64,
    parameter integer C_M_AXI_DATA_WIDTH         = 256,
    parameter integer CMD_TIMEOUT                = 4000000   // cycles a command may take before the run aborts
) (
    input  wire                                    ap_clk,
    input  wire                                    ap_rst_n,
    input  wire [C_S_AXI_CONTROL_ADDR_WIDTH-1:0]   s_axi_control_awaddr,
    input  wire                                    s_axi_control_awvalid,
    output wire                                    s_axi_control_awready,
    input  wire [31:0]                             s_axi_control_wdata,
    input  wire [3:0]                              s_axi_control_wstrb,
    input  wire                                    s_axi_control_wvalid,
    output wire                                    s_axi_control_wready,
    output wire [1:0]                              s_axi_control_bresp,
    output reg                                     s_axi_control_bvalid,
    input  wire                                    s_axi_control_bready,
    input  wire [C_S_AXI_CONTROL_ADDR_WIDTH-1:0]   s_axi_control_araddr,
    input  wire                                    s_axi_control_arvalid,
    output wire                                    s_axi_control_arready,
    output reg  [31:0]                             s_axi_control_rdata,
    output wire [1:0]                              s_axi_control_rresp,
    output reg                                     s_axi_control_rvalid,
    input  wire                                    s_axi_control_rready,
    output wire                                    interrupt,
    // ---------------- m_axi_gmem0: commands (read) ----------------
    output reg  [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem0_araddr,
    output reg  [7:0]                              m_axi_gmem0_arlen,
    output wire [2:0]                              m_axi_gmem0_arsize,
    output wire [1:0]                              m_axi_gmem0_arburst,
    output reg                                     m_axi_gmem0_arvalid,
    input  wire                                    m_axi_gmem0_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem0_rdata,
    input  wire [1:0]                              m_axi_gmem0_rresp,
    input  wire                                    m_axi_gmem0_rlast,
    input  wire                                    m_axi_gmem0_rvalid,
    output wire                                    m_axi_gmem0_rready,
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem0_awaddr,
    output wire [7:0]                              m_axi_gmem0_awlen,
    output wire [2:0]                              m_axi_gmem0_awsize,
    output wire [1:0]                              m_axi_gmem0_awburst,
    output wire                                    m_axi_gmem0_awvalid,
    input  wire                                    m_axi_gmem0_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem0_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem0_wstrb,
    output wire                                    m_axi_gmem0_wlast,
    output wire                                    m_axi_gmem0_wvalid,
    input  wire                                    m_axi_gmem0_wready,
    input  wire [1:0]                              m_axi_gmem0_bresp,
    input  wire                                    m_axi_gmem0_bvalid,
    output wire                                    m_axi_gmem0_bready,
    // ---------------- m_axi_gmem1: responses (write) ----------------
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem1_araddr,
    output wire [7:0]                              m_axi_gmem1_arlen,
    output wire [2:0]                              m_axi_gmem1_arsize,
    output wire [1:0]                              m_axi_gmem1_arburst,
    output wire                                    m_axi_gmem1_arvalid,
    input  wire                                    m_axi_gmem1_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem1_rdata,
    input  wire [1:0]                              m_axi_gmem1_rresp,
    input  wire                                    m_axi_gmem1_rlast,
    input  wire                                    m_axi_gmem1_rvalid,
    output wire                                    m_axi_gmem1_rready,
    output reg  [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem1_awaddr,
    output reg  [7:0]                              m_axi_gmem1_awlen,
    output wire [2:0]                              m_axi_gmem1_awsize,
    output wire [1:0]                              m_axi_gmem1_awburst,
    output reg                                     m_axi_gmem1_awvalid,
    input  wire                                    m_axi_gmem1_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem1_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem1_wstrb,
    output wire                                    m_axi_gmem1_wlast,
    output reg                                     m_axi_gmem1_wvalid,
    input  wire                                    m_axi_gmem1_wready,
    input  wire [1:0]                              m_axi_gmem1_bresp,
    input  wire                                    m_axi_gmem1_bvalid,
    output wire                                    m_axi_gmem1_bready,
    // ---------------- m_axi_gmem2: Tiny ORAM's tree ----------------
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem2_araddr,
    output wire [7:0]                              m_axi_gmem2_arlen,
    output wire [2:0]                              m_axi_gmem2_arsize,
    output wire [1:0]                              m_axi_gmem2_arburst,
    output wire                                    m_axi_gmem2_arvalid,
    input  wire                                    m_axi_gmem2_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem2_rdata,
    input  wire [1:0]                              m_axi_gmem2_rresp,
    input  wire                                    m_axi_gmem2_rlast,
    input  wire                                    m_axi_gmem2_rvalid,
    output wire                                    m_axi_gmem2_rready,
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem2_awaddr,
    output wire [7:0]                              m_axi_gmem2_awlen,
    output wire [2:0]                              m_axi_gmem2_awsize,
    output wire [1:0]                              m_axi_gmem2_awburst,
    output wire                                    m_axi_gmem2_awvalid,
    input  wire                                    m_axi_gmem2_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem2_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem2_wstrb,
    output wire                                    m_axi_gmem2_wlast,
    output wire                                    m_axi_gmem2_wvalid,
    input  wire                                    m_axi_gmem2_wready,
    input  wire [1:0]                              m_axi_gmem2_bresp,
    input  wire                                    m_axi_gmem2_bvalid,
    output wire                                    m_axi_gmem2_bready,
    // ---------------- m_axi_gmem3: the tree top (on-package) ----------------
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem3_araddr,
    output wire [7:0]                              m_axi_gmem3_arlen,
    output wire [2:0]                              m_axi_gmem3_arsize,
    output wire [1:0]                              m_axi_gmem3_arburst,
    output wire                                    m_axi_gmem3_arvalid,
    input  wire                                    m_axi_gmem3_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem3_rdata,
    input  wire [1:0]                              m_axi_gmem3_rresp,
    input  wire                                    m_axi_gmem3_rlast,
    input  wire                                    m_axi_gmem3_rvalid,
    output wire                                    m_axi_gmem3_rready,
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem3_awaddr,
    output wire [7:0]                              m_axi_gmem3_awlen,
    output wire [2:0]                              m_axi_gmem3_awsize,
    output wire [1:0]                              m_axi_gmem3_awburst,
    output wire                                    m_axi_gmem3_awvalid,
    input  wire                                    m_axi_gmem3_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem3_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem3_wstrb,
    output wire                                    m_axi_gmem3_wlast,
    output wire                                    m_axi_gmem3_wvalid,
    input  wire                                    m_axi_gmem3_wready,
    input  wire [1:0]                              m_axi_gmem3_bresp,
    input  wire                                    m_axi_gmem3_bvalid,
    output wire                                    m_axi_gmem3_bready
`ifdef TINYORAM_PM_HBM
    ,
    // ---------------- m_axi_gmem4: the flat position map (on-package HBM; TINYORAM_PM_HBM, patch 10) ----------------
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem4_araddr,
    output wire [7:0]                              m_axi_gmem4_arlen,
    output wire [2:0]                              m_axi_gmem4_arsize,
    output wire [1:0]                              m_axi_gmem4_arburst,
    output wire                                    m_axi_gmem4_arvalid,
    input  wire                                    m_axi_gmem4_arready,
    input  wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem4_rdata,
    input  wire [1:0]                              m_axi_gmem4_rresp,
    input  wire                                    m_axi_gmem4_rlast,
    input  wire                                    m_axi_gmem4_rvalid,
    output wire                                    m_axi_gmem4_rready,
    output wire [C_M_AXI_ADDR_WIDTH-1:0]           m_axi_gmem4_awaddr,
    output wire [7:0]                              m_axi_gmem4_awlen,
    output wire [2:0]                              m_axi_gmem4_awsize,
    output wire [1:0]                              m_axi_gmem4_awburst,
    output wire                                    m_axi_gmem4_awvalid,
    input  wire                                    m_axi_gmem4_awready,
    output wire [C_M_AXI_DATA_WIDTH-1:0]           m_axi_gmem4_wdata,
    output wire [C_M_AXI_DATA_WIDTH/8-1:0]         m_axi_gmem4_wstrb,
    output wire                                    m_axi_gmem4_wlast,
    output wire                                    m_axi_gmem4_wvalid,
    input  wire                                    m_axi_gmem4_wready,
    input  wire [1:0]                              m_axi_gmem4_bresp,
    input  wire                                    m_axi_gmem4_bvalid,
    output wire                                    m_axi_gmem4_bready
`endif
);
    // ---------------- Tiny ORAM constants (from its own headers) ----------------
    `include "PathORAM.vh"
    `include "UORAM.vh"
    `include "DMLocal.vh"
    `include "DDR3SDRAMLocal.vh"
    `include "BucketLocal.vh"
    `include "CommandsLocal.vh"
    `include "PLBLocal.vh"
    `include "JTAG.vh"

    localparam integer DW        = C_M_AXI_DATA_WIDTH;
    localparam [31:0]  NKEYS     = NumValidBlock;                       // N (blocks)
    localparam integer BLKB      = ORAMB / 8;                           // block bytes = command/response slot
    localparam integer BLG       = $clog2(BLKB);
    localparam integer MCH       = (BLKB < 128) ? BLKB : 128;           // WMask bytes built per cycle (partial PUT)
    localparam integer MSTEPS    = BLKB / MCH;
    localparam integer REC_BEATS = ORAMB / DW;                          // AXI beats per record
    localparam integer CH_PER_BT = DW / FEDWidth;                       // Tiny ORAM data chunks per AXI beat
    localparam integer RBW       = (REC_BEATS > 1) ? $clog2(REC_BEATS) : 1;
    localparam integer CHW       = (CH_PER_BT > 1) ? $clog2(CH_PER_BT) : 1;
    localparam [63:0]  TREE_BYTES = 64'd64 * NumBuckets * BktSize_DRBursts;  // whole tree span
    localparam [63:0]  TREE_BURSTS = TREE_BYTES / 64;                     // reported in record [size+1]
    localparam integer FILL_BEATS = 128;                                // zero-fill burst: 4 KB
    // the geometry the wrapper uses: the build's constants, or (TINYORAM_RTDEPTH) the active depth's
    wire [31:0]  nkeys_rt;                                              // N (blocks)
    wire [63:0]  tree_bursts_rt, tree_bytes_rt;                         // the tree in 64-byte bursts / bytes
`ifdef TINYORAM_RTDEPTH
    localparam integer RT_LMIN = 6;                                     // the smallest depth the wrapper accepts
    reg  [4:0]   act_L, req_L;                                          // the active depth; requested at init
    wire [`RTGW-1:0] rt_geo;
    TinyRTGeo u_geo (.Clock(ap_clk), .L(act_L), .Geo(rt_geo));
    assign nkeys_rt       = rt_geo[`RTG_NVB];
    assign tree_bursts_rt = {24'd0, rt_geo[`RTG_TBURSTS]};
    assign tree_bytes_rt  = {18'd0, rt_geo[`RTG_TBURSTS], 6'd0};
    wire   [7:0] RT_LMAX8 = ORAML;
`else
    assign nkeys_rt       = NKEYS;
    assign tree_bursts_rt = TREE_BURSTS;
    assign tree_bytes_rt  = TREE_BYTES;
`endif
`ifdef TINYORAM_MERGE
    localparam integer MERGE = `TINYORAM_MERGE;                         // adapter: merge contiguous commands
`else
    localparam integer MERGE = 0;                                       // adapter: 1:1, as published
`endif
    localparam [2:0]   ASIZE  = $clog2(DW / 8);
    localparam [7:0]   T_GET = 8'h01, T_PUT = 8'h02, T_ACK = 8'h10, T_ERR = 8'h11, T_SUM = 8'h5A;
    wire rst = !ap_rst_n;
`ifndef SYNTHESIS
    initial begin
        if (DW != 256 || BEDWidth != DW || FEDWidth != 64 || ORAMB % DW != 0 || ORAMB < 512 || ORAMB > 32768 ||
            (BLKB & (BLKB - 1)) != 0 || EnableIV != 1) begin
            $display("ERROR: tinyoram_kernel needs a 256-bit AXI width = BEDWidth, FEDWidth 64, ORAMB a power of two from 512 to 32768 (Tiny ORAM's backend waits for a whole 512-bit DRAM burst of block data: a smaller block never starts an eviction) and PMMAC on (WMask is applied by its integrity verifier) (got DW=%0d BED=%0d FED=%0d ORAMB=%0d)",
                     DW, BEDWidth, FEDWidth, ORAMB);
            $finish;
        end
        $display("tinyoram_kernel: ORAMB=%0d bits (%0d B) ORAML=%0d Z=%0d N=%0d EnableAES=%0d EnableIV=%0d tree=%0d bytes",
                 ORAMB, ORAMB/8, ORAML, ORAMZ, NKEYS, EnableAES, EnableIV, TREE_BYTES);
    end
`endif

    // =====================================================================
    // AXI4-Lite control registers (identical to doma_kernel)
    // =====================================================================
    reg        ap_start_r, ap_done_r, ap_ready_r, auto_restart_r, gie_r;
    reg  [1:0] ier_r, isr_r;
    reg [63:0] arg_cmd, arg_resp, arg_pages, arg_top;
    reg [31:0] arg_size, arg_top_bytes;
`ifdef TINYORAM_PM_HBM
    reg [63:0] arg_pm;                          // 0x50: the position map's buffer (arg 6, m_axi_gmem4)
`endif
    wire       ap_idle;
    reg        done_pulse;

    wire wr_hs = s_axi_control_awvalid && s_axi_control_wvalid && !s_axi_control_bvalid;
    assign s_axi_control_awready = wr_hs;
    assign s_axi_control_wready  = wr_hs;
    assign s_axi_control_bresp   = 2'b00;
    assign s_axi_control_arready = !s_axi_control_rvalid;
    assign s_axi_control_rresp   = 2'b00;
    wire [7:0] wa = s_axi_control_awaddr[7:0];
    wire [7:0] ra = s_axi_control_araddr[7:0];
    function [31:0] wmask; input [31:0] oldv, newv; input [3:0] strb; integer b;
        begin wmask = oldv; for (b = 0; b < 4; b = b + 1) if (strb[b]) wmask[b*8 +: 8] = newv[b*8 +: 8]; end
    endfunction

    always @(posedge ap_clk) begin
        if (rst) begin
            ap_start_r <= 1'b0; ap_done_r <= 1'b0; ap_ready_r <= 1'b0; auto_restart_r <= 1'b0;
            gie_r <= 1'b0; ier_r <= 2'b00; isr_r <= 2'b00;
            arg_cmd <= 64'd0; arg_resp <= 64'd0; arg_pages <= 64'd0; arg_size <= 32'd0; arg_top <= 64'd0; arg_top_bytes <= 32'd0;
`ifdef TINYORAM_PM_HBM
            arg_pm <= 64'd0;
`endif
            s_axi_control_bvalid <= 1'b0; s_axi_control_rvalid <= 1'b0; s_axi_control_rdata <= 32'd0;
        end else begin
            if (wr_hs) begin
                s_axi_control_bvalid <= 1'b1;
                case (wa)
                    8'h00: begin
                        if (s_axi_control_wstrb[0] && s_axi_control_wdata[0]) ap_start_r <= 1'b1;
                        if (s_axi_control_wstrb[0]) auto_restart_r <= s_axi_control_wdata[7];
                    end
                    8'h04: if (s_axi_control_wstrb[0]) gie_r <= s_axi_control_wdata[0];
                    8'h08: if (s_axi_control_wstrb[0]) ier_r <= s_axi_control_wdata[1:0];
                    8'h0C: if (s_axi_control_wstrb[0]) isr_r <= isr_r ^ s_axi_control_wdata[1:0];
                    8'h10: arg_cmd[31:0]    <= wmask(arg_cmd[31:0],    s_axi_control_wdata, s_axi_control_wstrb);
                    8'h14: arg_cmd[63:32]   <= wmask(arg_cmd[63:32],   s_axi_control_wdata, s_axi_control_wstrb);
                    8'h1C: arg_resp[31:0]   <= wmask(arg_resp[31:0],   s_axi_control_wdata, s_axi_control_wstrb);
                    8'h20: arg_resp[63:32]  <= wmask(arg_resp[63:32],  s_axi_control_wdata, s_axi_control_wstrb);
                    8'h28: arg_pages[31:0]  <= wmask(arg_pages[31:0],  s_axi_control_wdata, s_axi_control_wstrb);
                    8'h2C: arg_pages[63:32] <= wmask(arg_pages[63:32], s_axi_control_wdata, s_axi_control_wstrb);
                    8'h34: arg_size         <= wmask(arg_size,         s_axi_control_wdata, s_axi_control_wstrb);
                    8'h3C: arg_top[31:0]    <= wmask(arg_top[31:0],    s_axi_control_wdata, s_axi_control_wstrb);
                    8'h40: arg_top[63:32]   <= wmask(arg_top[63:32],   s_axi_control_wdata, s_axi_control_wstrb);
                    8'h48: arg_top_bytes    <= wmask(arg_top_bytes,    s_axi_control_wdata, s_axi_control_wstrb);
`ifdef TINYORAM_PM_HBM
                    8'h50: arg_pm[31:0]     <= wmask(arg_pm[31:0],     s_axi_control_wdata, s_axi_control_wstrb);
                    8'h54: arg_pm[63:32]    <= wmask(arg_pm[63:32],    s_axi_control_wdata, s_axi_control_wstrb);
`endif
                    default: ;
                endcase
            end
            if (s_axi_control_bvalid && s_axi_control_bready) s_axi_control_bvalid <= 1'b0;
            if (s_axi_control_arvalid && !s_axi_control_rvalid) begin
                s_axi_control_rvalid <= 1'b1;
                case (ra)
                    8'h00: begin
                        s_axi_control_rdata <= {24'd0, auto_restart_r, 3'd0, ap_ready_r, ap_idle, ap_done_r, ap_start_r};
                        ap_done_r <= 1'b0; ap_ready_r <= 1'b0;
                    end
                    8'h04: s_axi_control_rdata <= {31'd0, gie_r};
                    8'h08: s_axi_control_rdata <= {30'd0, ier_r};
                    8'h0C: s_axi_control_rdata <= {30'd0, isr_r};
                    8'h10: s_axi_control_rdata <= arg_cmd[31:0];
                    8'h14: s_axi_control_rdata <= arg_cmd[63:32];
                    8'h1C: s_axi_control_rdata <= arg_resp[31:0];
                    8'h20: s_axi_control_rdata <= arg_resp[63:32];
                    8'h28: s_axi_control_rdata <= arg_pages[31:0];
                    8'h2C: s_axi_control_rdata <= arg_pages[63:32];
                    8'h34: s_axi_control_rdata <= arg_size;
                    8'h3C: s_axi_control_rdata <= arg_top[31:0];
                    8'h40: s_axi_control_rdata <= arg_top[63:32];
                    8'h48: s_axi_control_rdata <= arg_top_bytes;
`ifdef TINYORAM_PM_HBM
                    8'h50: s_axi_control_rdata <= arg_pm[31:0];
                    8'h54: s_axi_control_rdata <= arg_pm[63:32];
`endif
                    default: s_axi_control_rdata <= 32'd0;
                endcase
            end
            if (s_axi_control_rvalid && s_axi_control_rready) s_axi_control_rvalid <= 1'b0;
            if (done_pulse) begin
                ap_done_r  <= 1'b1;
                ap_ready_r <= 1'b1;
                ap_start_r <= auto_restart_r;
                if (ier_r[0]) isr_r[0] <= 1'b1;
            end
        end
    end
    assign interrupt = gie_r && |(isr_r & ier_r);

    // =====================================================================
    // Tiny ORAM and its memory adapter
    // =====================================================================
    reg                     core_run;          // Tiny ORAM out of reset (after the zero-fill)
    wire                    core_rst = rst || !core_run;
    reg  [BECMDWidth-1:0]   t_cmd;
    reg  [ORAMU-1:0]        t_paddr;
    reg                     t_cmd_valid;
    reg  [DMWidth-1:0]      t_wmask;           // byte write mask, sampled with the command (all ones = whole block)
    wire                    t_cmd_ready;
    wire [FEDWidth-1:0]     t_din;
    wire                    t_din_valid, t_din_ready;
    wire [FEDWidth-1:0]     t_dout;
    wire                    t_dout_valid;
    wire                    t_idle;
    wire [DDRAWidth-1:0]    d_addr;
    wire [DDRCWidth-1:0]    d_cmd;
    wire                    d_cmd_valid, d_cmd_ready;
    wire [BEDWidth-1:0]     d_rdata, d_wdata;
    wire                    d_rvalid, d_wvalid, d_wready;
    wire [JTWidth_PMMAC-1:0] j_pmmac;

`ifdef TINYORAM_TOP_PLAINTEXT
    reg  [63:0] top_q;                          // tree offsets below this live in the top buffer (and in plaintext)
`endif
`ifdef TINYORAM_PM_HBM
    wire        pm_req_v, pm_req_r, pm_req_w, pm_resp_v, pm_wr_done, pm_zdone, pm_err;
    wire [31:0] pm_req_a;
    wire [63:0] pm_req_d, pm_resp_d;
    reg  [63:0] pm_base;                        // latched with pages at every init
    reg         pm_zstart, pm_zstarted;
`endif
    TinyORAMCore u_tiny (
        .Clock(ap_clk), .Reset(core_rst),
`ifdef TINYORAM_RTDEPTH
        .RTGeo(rt_geo),
`endif
`ifdef TINYORAM_TOP_PLAINTEXT
        .TopBytes(top_q),                       // patch 09: buckets below the split are stored in plaintext
`endif
        .Cmd(t_cmd), .PAddr(t_paddr), .WMask(t_wmask), .CmdValid(t_cmd_valid), .CmdReady(t_cmd_ready),
        .DataIn(t_din), .DataInValid(t_din_valid), .DataInReady(t_din_ready),
        .DataOut(t_dout), .DataOutValid(t_dout_valid), .DataOutReady(1'b1),
        .DRAMAddress(d_addr), .DRAMCommand(d_cmd), .DRAMCommandValid(d_cmd_valid), .DRAMCommandReady(d_cmd_ready),
        .DRAMReadData(d_rdata), .DRAMReadDataValid(d_rvalid),
        .DRAMWriteData(d_wdata), .DRAMWriteDataValid(d_wvalid), .DRAMWriteDataReady(d_wready),
        .Mode_DummyGen(1'b0), .Idle(t_idle),
`ifdef TINYORAM_PM_HBM
        .PMReqValid(pm_req_v), .PMReqReady(pm_req_r), .PMReqWrite(pm_req_w), .PMReqAddr(pm_req_a), .PMReqData(pm_req_d),
        .PMRespValid(pm_resp_v), .PMRespData(pm_resp_d), .PMWrDone(pm_wr_done),
`endif
        .JTAG_UORAM(), .JTAG_PMMAC(j_pmmac), .JTAG_Frontend(),
        .JTAG_AES(), .JTAG_StashCore(), .JTAG_Stash(), .JTAG_StashTop(), .JTAG_BackendCore(), .JTAG_Backend());

    reg  [63:0] pages_base;                     // latched by every init launch
    reg  [63:0] top_base;                       // the tree top's buffer (latched with pages)
`ifndef TINYORAM_TOP_PLAINTEXT
    reg  [63:0] top_q;                          // tree offsets below this live in the top buffer
`endif
`ifdef TINYORAM_PM_HBM
    // the pages buffer holds only the tree below the top (offsets top_q .. tree end): the host allocates tree - top
    // bytes, so a 1M-record tree (13.4 GiB at 4 KB) need not fit host memory whole; offset o >= top_q is at pages + o - top_q
`define TOR_PAGES_RB (pages_base - top_q)
`else
`define TOR_PAGES_RB pages_base
`endif
    wire [63:0] a_araddr, a_awaddr, a_t_araddr, a_t_awaddr;
    wire [7:0]  a_arlen, a_awlen, a_t_arlen, a_t_awlen;
    wire [2:0]  a_arsize, a_awsize, a_t_arsize, a_t_awsize;
    wire [1:0]  a_arburst, a_awburst, a_t_arburst, a_t_awburst;
    wire        a_arvalid, a_awvalid, a_rready, a_wlast, a_wvalid, a_bready, a_quiet_w, a_wdone, a_idle, a_err;
    wire        a_t_arvalid, a_t_awvalid, a_t_rready, a_t_wlast, a_t_wvalid, a_t_bready;
    wire [DW-1:0]   a_wdata, a_t_wdata;
    wire [DW/8-1:0] a_wstrb, a_t_wstrb;
    wire [63:0] a_rd_beats, a_wr_beats;
    tinyoram_axi_adapter #(.DW(DW), .DDR_BITS(DDRDWidth), .AW_CORE(DDRAWidth), .TREE_BYTES(TREE_BYTES), .MERGE(MERGE)) u_adapt (
        .clk(ap_clk), .rst(core_rst), .base(`TOR_PAGES_RB), .base_t(top_base), .top_bytes(top_q), .tree_lim(tree_bytes_rt),
        .core_addr(d_addr), .core_cmd(d_cmd), .core_cmd_valid(d_cmd_valid), .core_cmd_ready(d_cmd_ready),
        .core_rdata(d_rdata), .core_rvalid(d_rvalid),
        .core_wdata(d_wdata), .core_wvalid(d_wvalid), .core_wready(d_wready),
        .araddr(a_araddr), .arlen(a_arlen), .arsize(a_arsize), .arburst(a_arburst), .arvalid(a_arvalid),
        .arready(m_axi_gmem2_arready), .rdata(m_axi_gmem2_rdata), .rresp(m_axi_gmem2_rresp),
        .rlast(m_axi_gmem2_rlast), .rvalid(m_axi_gmem2_rvalid & core_run), .rready(a_rready),
        .awaddr(a_awaddr), .awlen(a_awlen), .awsize(a_awsize), .awburst(a_awburst), .awvalid(a_awvalid),
        .awready(m_axi_gmem2_awready), .wdata(a_wdata), .wstrb(a_wstrb), .wlast(a_wlast), .wvalid(a_wvalid),
        .wready(m_axi_gmem2_wready), .bresp(m_axi_gmem2_bresp), .bvalid(m_axi_gmem2_bvalid & core_run), .bready(a_bready),
        .t_araddr(a_t_araddr), .t_arlen(a_t_arlen), .t_arsize(a_t_arsize), .t_arburst(a_t_arburst), .t_arvalid(a_t_arvalid),
        .t_arready(m_axi_gmem3_arready), .t_rdata(m_axi_gmem3_rdata), .t_rresp(m_axi_gmem3_rresp),
        .t_rlast(m_axi_gmem3_rlast), .t_rvalid(m_axi_gmem3_rvalid & core_run), .t_rready(a_t_rready),
        .t_awaddr(a_t_awaddr), .t_awlen(a_t_awlen), .t_awsize(a_t_awsize), .t_awburst(a_t_awburst), .t_awvalid(a_t_awvalid),
        .t_awready(m_axi_gmem3_awready), .t_wdata(a_t_wdata), .t_wstrb(a_t_wstrb), .t_wlast(a_t_wlast), .t_wvalid(a_t_wvalid),
        .t_wready(m_axi_gmem3_wready), .t_bresp(m_axi_gmem3_bresp), .t_bvalid(m_axi_gmem3_bvalid & core_run), .t_bready(a_t_bready),
        .quiet_w(a_quiet_w), .wdone(a_wdone), .idle(a_idle), .error(a_err), .rd_beats(a_rd_beats), .wr_beats(a_wr_beats));

    // zero-fill master (first command launch after an init); owns both tree ports' write channels until core_run
    reg         zf_awvalid, zf_wvalid;
    reg         zf_t;                   // the current fill burst goes to the top buffer (gmem3)
    reg  [63:0] zf_awaddr;
    reg  [7:0]  zf_awlen, zf_wcnt;
    reg  [63:0] zf_off;                 // next byte offset to issue
    reg  [31:0] zf_bout;                // bursts whose B is outstanding
    assign m_axi_gmem2_araddr  = a_araddr;  assign m_axi_gmem2_arlen = a_arlen;  assign m_axi_gmem2_arsize = a_arsize;
    assign m_axi_gmem2_arburst = a_arburst; assign m_axi_gmem2_arvalid = a_arvalid & core_run;
    assign m_axi_gmem2_rready  = core_run ? a_rready : 1'b1;
    assign m_axi_gmem2_awaddr  = core_run ? a_awaddr : zf_awaddr;
    assign m_axi_gmem2_awlen   = core_run ? a_awlen  : zf_awlen;
    assign m_axi_gmem2_awsize  = ASIZE;     assign m_axi_gmem2_awburst = 2'b01;
    assign m_axi_gmem2_awvalid = core_run ? a_awvalid : (zf_awvalid && !zf_t);
    assign m_axi_gmem2_wdata   = core_run ? a_wdata : {DW{1'b0}};
    assign m_axi_gmem2_wstrb   = core_run ? a_wstrb : {(DW/8){1'b1}};
    assign m_axi_gmem2_wlast   = core_run ? a_wlast : (zf_wcnt == zf_awlen);
    assign m_axi_gmem2_wvalid  = core_run ? a_wvalid : (zf_wvalid && !zf_t);
    assign m_axi_gmem2_bready  = core_run ? a_bready : 1'b1;
    assign m_axi_gmem3_araddr  = a_t_araddr;  assign m_axi_gmem3_arlen = a_t_arlen;  assign m_axi_gmem3_arsize = a_t_arsize;
    assign m_axi_gmem3_arburst = a_t_arburst; assign m_axi_gmem3_arvalid = a_t_arvalid & core_run;
    assign m_axi_gmem3_rready  = core_run ? a_t_rready : 1'b1;
    assign m_axi_gmem3_awaddr  = core_run ? a_t_awaddr : zf_awaddr;
    assign m_axi_gmem3_awlen   = core_run ? a_t_awlen  : zf_awlen;
    assign m_axi_gmem3_awsize  = ASIZE;     assign m_axi_gmem3_awburst = 2'b01;
    assign m_axi_gmem3_awvalid = core_run ? a_t_awvalid : (zf_awvalid && zf_t);
    assign m_axi_gmem3_wdata   = core_run ? a_t_wdata : {DW{1'b0}};
    assign m_axi_gmem3_wstrb   = core_run ? a_t_wstrb : {(DW/8){1'b1}};
    assign m_axi_gmem3_wlast   = core_run ? a_t_wlast : (zf_wcnt == zf_awlen);
    assign m_axi_gmem3_wvalid  = core_run ? a_t_wvalid : (zf_wvalid && zf_t);
    assign m_axi_gmem3_bready  = core_run ? a_t_bready : 1'b1;
`ifdef TINYORAM_PM_HBM
    // the flat position map on m_axi_gmem4: the core's entry requests, and its zeroing before the core leaves reset
    tinyoram_pm_axi #(.DW(DW)) u_pm (
        .clk(ap_clk), .rst(rst), .base(pm_base), .nbytes({29'd0, nkeys_rt, 3'b000}), .zero_start(pm_zstart),
        .zero_done(pm_zdone), .err(pm_err),
        .req_valid(pm_req_v & core_run), .req_ready(pm_req_r), .req_write(pm_req_w), .req_addr(pm_req_a), .req_data(pm_req_d),
        .resp_valid(pm_resp_v), .resp_data(pm_resp_d), .wr_done(pm_wr_done),
        .araddr(m_axi_gmem4_araddr), .arlen(m_axi_gmem4_arlen), .arsize(m_axi_gmem4_arsize), .arburst(m_axi_gmem4_arburst),
        .arvalid(m_axi_gmem4_arvalid), .arready(m_axi_gmem4_arready), .rdata(m_axi_gmem4_rdata), .rresp(m_axi_gmem4_rresp),
        .rlast(m_axi_gmem4_rlast), .rvalid(m_axi_gmem4_rvalid), .rready(m_axi_gmem4_rready),
        .awaddr(m_axi_gmem4_awaddr), .awlen(m_axi_gmem4_awlen), .awsize(m_axi_gmem4_awsize), .awburst(m_axi_gmem4_awburst),
        .awvalid(m_axi_gmem4_awvalid), .awready(m_axi_gmem4_awready), .wdata(m_axi_gmem4_wdata), .wstrb(m_axi_gmem4_wstrb),
        .wlast(m_axi_gmem4_wlast), .wvalid(m_axi_gmem4_wvalid), .wready(m_axi_gmem4_wready),
        .bresp(m_axi_gmem4_bresp), .bvalid(m_axi_gmem4_bvalid), .bready(m_axi_gmem4_bready));
`endif
`ifdef TINYORAM_RTDEPTH
    wire [31:0] arg_n = arg_size[31] ? 32'd0 : arg_size;               // a depth-selecting init launch has no commands
`else
    wire [31:0] arg_n = arg_size;
`endif
    wire zf_aw_ok = zf_t ? m_axi_gmem3_awready : m_axi_gmem2_awready;
    wire zf_w_ok  = zf_t ? m_axi_gmem3_wready  : m_axi_gmem2_wready;
    // the tree-top split: top_bytes at or above the tree size = the whole tree in the top buffer;
    // below it, rounded down to 4 KB (flag 0x80 if that changed it)
`ifdef TINYORAM_PM_HBM
    // TINYORAM_PM_HBM builds take top_bytes in 4 KB units (tops above 4 GB: a 1M-block tree at 4 KB is 13 GB)
    wire [63:0] arg_top_b   = {20'd0, arg_top_bytes, 12'd0};
    wire [63:0] arg_top_eff = (arg_top_b >= tree_bytes_rt) ? tree_bytes_rt : arg_top_b;
    wire        arg_top_adj = 1'b0;
`else
    wire [63:0] arg_top_eff = ({32'd0, arg_top_bytes} >= tree_bytes_rt) ? tree_bytes_rt : ({32'd0, arg_top_bytes} & ~64'd4095);
    wire        arg_top_adj = ({32'd0, arg_top_bytes} < tree_bytes_rt) && (arg_top_bytes[11:0] != 12'd0);
`endif

    // =====================================================================
    // Command engine
    // =====================================================================
    // Per command: K_HDR (header from the fetcher) -> K_CHK -> [K_MASK] -> K_REQ -> [K_PDAT] -> K_WAIT
    // -> (released) [K_GDAT_*] -> K_HQ -> K_NEXT. As doma_kernel now does:
    //   * the fetcher prefetches command k+1's header (and, for a PUT, its data) while command k is in
    //     K_WAIT; every run start clears it;
    //   * response writes are posted: their B responses are counted (wb_pend) and waited for once, before
    //     the summary;
    //   * a command is released when its write-back data has been handed off (Tiny ORAM idle and every
    //     write beat on the bus): that is the primary latency (header bytes 8-11, summary min/max). Its
    //     header waits in a one-entry queue until the adapter has every write acknowledged, so header
    //     bytes 20-23 can carry the latency to write-back acknowledged; the adapter holds the next path's
    //     reads until then anyway.
    localparam [4:0] K_IDLE = 5'd0,  K_FILL = 5'd1,  K_FILL_W = 5'd2, K_FILL_B = 5'd3, K_BOOT = 5'd4,
                     K_HDR = 5'd5,   K_REQ = 5'd7,   K_PDAT = 5'd9,
                     K_WAIT = 5'd10, K_GDAT_AW = 5'd11, K_GDAT_PRE = 5'd12, K_GDAT_W = 5'd13,
                     K_HQ = 5'd15,   K_NEXT = 5'd18, K_DRAIN = 5'd17,
                     K_SUM_AW = 5'd19, K_SUM_W = 5'd20, K_SUM_B = 5'd21, K_DONE = 5'd22,
                     K_BYT_AW = 5'd23, K_BYT_W = 5'd24, K_BYT_B = 5'd25, K_CHK = 5'd26, K_MASK = 5'd27,
                     K_RST = 5'd28;
    localparam integer RST_HOLD = 16;           // cycles the init launch holds Tiny ORAM in reset before reporting
    reg  [4:0]  kst;
    reg         booted;
    reg  [4:0]  rst_cnt;
    reg  [31:0] idx, nsize;
    reg  [63:0] cbase, rbase, hc_off, hr_off;
    reg  [7:0]  ctype;
    reg  [31:0] ckey;
    reg  [31:0] coff, clen;                 // record range in the block: header bytes 8-11 offset, 12-15 length (0 = whole block)
    reg  [15:0] cend;                       // coff + clen (valid after the range check: <= BLKB)
    reg  [15:0] gb0, gb1;                   // GET: first and last response beat of the record
    reg  [15:0] mcnt;                       // WMask chunk being built
    reg  [31:0] pbm;                        // byte enables of the PUT beat held in pbeat
    reg  [31:0] gstrb;                      // byte strobes of the GET beat held in wreg
    reg  [15:0] gbi;                        // GET: index of the beat held in wreg
    reg  [31:0] fmask, lmask;               // record bytes in its first beat (>= offset) and last beat (<= last byte)
    reg  [31:0] lat, lat_min, lat_max, wait_cnt;
    reg  [63:0] total;
    reg  [31:0] stat, errs, ndone;
    reg         cput;                       // current command is a PUT
    // PUT data: beats from pbuf -> 64-bit chunks into Tiny ORAM
    reg  [DW-1:0] pbeat;
    reg           pbeat_v;
    reg  [CHW-1:0] pch;
    reg  [RBW:0]  pd_rd;                    // next pbuf beat to stream
    reg  [15:0]   pchunks_out;              // chunks handed to Tiny ORAM
    // GET data: 64-bit chunks from Tiny ORAM -> AXI beats into rbuf
    reg  [DW-1:0] gasm;
    reg  [CHW-1:0] gch;
    reg  [RBW:0]  gbeats;                   // record beats assembled
    reg  [DW-1:0] rbuf [0:REC_BEATS-1];
    reg  [DW-1:0] wreg;
    reg  [RBW:0]  wcnt;
    reg  [1:0]    wsent_run;                // consecutive cycles: Tiny ORAM idle, every write beat sent
    reg  [31:0]   lat_d;                    // secondary latency: data ready
    reg           released;                 // the current command was released (write-back handed off)
    reg  [31:0]   lat_rel;                  // its latency at release (the primary figure)
    reg           ack_seen;                 // ... and its writes were acknowledged since (lat_ack: when)
    reg  [31:0]   lat_ack;
    reg  [31:0]   errs_q;                   // errors found after release, while the header waited
    reg  [31:0]   nlate;                    // released commands whose header then got such an error
    reg           got_d;
    // traffic on the data port (gmem2), including the first launch's zero-fill
    reg  [63:0]   g2_rd, g2_wr, g2_rd0, g2_wr0;
    reg  [63:0]   g3_rd, g3_wr, g3_rd0, g3_wr0;   // the top port (gmem3) alone, so the host can tell on- from off-package
    reg           zf_err;                   // a zero-fill write came back with an error (the tree is not clean)
`ifdef TINYORAM_PM_HBM
    wire          halted = j_pmmac[0] | a_err | zf_err | pm_err;
`else
    wire          halted = j_pmmac[0] | a_err | zf_err;
`endif
    wire [15:0]   rec_chunks = ORAMB / FEDWidth;

    // ---- fetcher: header of command f_idx, then (PUT) its data into pbuf, on m_axi_gmem0 ----
    localparam [2:0] F_IDLE = 3'd0, F_HAR = 3'd1, F_HR = 3'd2, F_DAR = 3'd3, F_DR = 3'd4, F_DONE = 3'd5;
    reg  [2:0]    fst;
    reg  [31:0]   f_idx;
    reg  [127:0]  f_hdr;
    reg  [RBW:0]  f_cnt;                    // PUT data beats received into pbuf
    reg  [DW-1:0] pbuf [0:REC_BEATS-1];     // PUT data of the fetched command (LUT RAM: combinational read)
    reg           f_go;                     // engine request: fetch command f_go_idx (held until the fetcher takes it)
    reg  [31:0]   f_go_idx;
    wire          f_hdr_ok = (fst == F_DAR || fst == F_DR || fst == F_DONE) && (f_idx == idx);
    wire          f_busy   = (fst == F_HAR || fst == F_HR || fst == F_DAR || fst == F_DR);
    // ---- header queue (one entry) and its writer on m_axi_gmem1 ----
    reg           hq_v, hq_ackw;            // a header is queued / it waits for the write acknowledgements
    reg  [31:0]   hq_idx, hq_key, hq_stat, hq_lat, hq_latd, hq_lata;
    localparam [1:0] H_IDLE = 2'd0, H_AW = 2'd1, H_W = 2'd2;
    reg  [1:0]    hst;
    reg  [31:0]   wb_pend;                  // posted response writes (AW issued) whose B has not arrived
    wire          eng_gm1 = (kst == K_GDAT_AW || kst == K_GDAT_PRE || kst == K_GDAT_W ||
                             kst == K_SUM_AW || kst == K_SUM_W || kst == K_SUM_B ||
                             kst == K_BYT_AW || kst == K_BYT_W || kst == K_BYT_B);

    assign ap_idle = (kst == K_IDLE);
    // bytes of 32-byte beat `bi` of the block that lie in the record (all of them for a whole-block
    // command): from the record's first/last beat and the two edge masks, all registered in K_CHK
    function [31:0] beat_bytes; input [15:0] bi;
        begin
            if (clen == 32'd0) beat_bytes = 32'hFFFF_FFFF;
            else if (bi < gb0 || bi > gb1) beat_bytes = 32'd0;
            else beat_bytes = ((bi == gb0) ? fmask : 32'hFFFF_FFFF) & ((bi == gb1) ? lmask : 32'hFFFF_FFFF);
        end
    endfunction
    // WMask chunk mcnt (MCH bytes)
    wire [MCH-1:0] mchunk;
    genvar gm;
    generate for (gm = 0; gm < MCH; gm = gm + 1) begin : g_mask
        wire [15:0] bx = mcnt * MCH + gm;
        assign mchunk[gm] = (bx >= coff[15:0]) && (bx < cend);
    end endgenerate
    // PUT data into Tiny ORAM: bytes outside the record are zero, so a record written into a never-written
    // block (which Tiny ORAM stores as a whole-block Append, without the mask) leaves zeros around it
    wire [7:0] pch_be = pbm[pch*8 +: 8];
    wire [FEDWidth-1:0] pch_mask;
    genvar gz;
    generate for (gz = 0; gz < FEDWidth / 8; gz = gz + 1) begin : g_dz
        assign pch_mask[gz*8 +: 8] = {8{pch_be[gz]}};
    end endgenerate
    assign t_din       = pbeat[pch*FEDWidth +: FEDWidth] & pch_mask;
    assign t_din_valid = (kst == K_PDAT) && pbeat_v;
    assign m_axi_gmem0_rready = (fst == F_HR) || (fst == F_DR);
    assign m_axi_gmem0_arsize = ASIZE;  assign m_axi_gmem0_arburst = 2'b01;
    assign m_axi_gmem1_awsize = ASIZE;  assign m_axi_gmem1_awburst = 2'b01;
    assign m_axi_gmem1_bready = 1'b1;
    assign m_axi_gmem1_wstrb  = (kst == K_GDAT_W) ? gstrb : {(DW/8){1'b1}};
    assign m_axi_gmem1_wlast  = (kst == K_GDAT_W) ? (wcnt == gb1 - gb0) : 1'b1;
    // response header: bytes 8-11 latency to the last write-back beat handed off (the primary figure, the
    // same end point as doma_kernel's arrival mode), 12-15 status, 16-19 latency to data ready (GET data
    // received / PUT data sent), 20-23 latency to every write-back acknowledged (B received)
    wire [DW-1:0] hdr_beat = {{(DW-192){1'b0}}, hq_lata, hq_latd, hq_stat, hq_lat, hq_key, 24'd0, ((hq_stat == 32'd0) ? T_ACK : T_ERR)};
    // record [size+1]: 0x5B, bytes 8-15 read beats and 16-23 write beats on both tree ports in this launch
    // bytes 1-7: the top port's share, in 64-byte units (28 bits each: up to 17 GB per direction and launch),
    // bits 8-35 read, 36-63 written; the rest of both counts went to the pages port
`ifdef TINYORAM_PM_HBM
    // position-map-in-HBM builds (patch 10): in 4 KB units (up to 1 TiB per direction and launch; a 1M-command launch
    // at 4 KB moves hundreds of GB through a large top), rounded down
    wire [63:0]   g3_rd_u = (g3_rd - g3_rd0) >> 7, g3_wr_u = (g3_wr - g3_wr0) >> 7;
`else
    wire [63:0]   g3_rd_u = (g3_rd - g3_rd0) >> 1, g3_wr_u = (g3_wr - g3_wr0) >> 1;
`endif
    wire [255:0]  byt_beat = {tree_bursts_rt[31:0], nkeys_rt[31:0], g2_wr - g2_wr0, g2_rd - g2_rd0, g3_wr_u[27:0], g3_rd_u[27:0], 8'h5B};
    // summary: byte0 0x5A | bytes 4-7 block size in beats (as doma_kernel) | 8-15 total | 16-19 min | 20-23 max | 24-27 errors | 28-31 completed
`ifdef TINYORAM_TOP_PLAINTEXT
    // byte 1 bit 7: the tree top is stored in plaintext (TOP_PLAINTEXT, patch 09); bit 6: the position map is in HBM
    // (TINYORAM_PM_HBM, patch 10; top_bytes in 4 KB units); bits 4-0 as below
`ifdef TINYORAM_RTDEPTH
    wire [23:0]   sum_geo  = {8'd6, RT_LMAX8, 3'b100, act_L};
`elsif TINYORAM_PM_HBM
    wire [23:0]   sum_geo  = 24'h00_00C0;
`else
    wire [23:0]   sum_geo  = 24'h00_0080;
`endif
`elsif TINYORAM_PM_HBM
    wire [23:0]   sum_geo  = 24'h00_0040;
`else
`ifdef TINYORAM_RTDEPTH
    wire [23:0]   sum_geo  = {8'd6, RT_LMAX8, 3'd0, act_L};                // bytes 1-3: active L, L_max, smallest L
`else
    wire [23:0]   sum_geo  = 24'd0;
`endif
`endif
    wire [255:0]  sum_beat = {ndone - nlate, errs | errs_q, lat_max, (lat_min == 32'hFFFF_FFFF ? 32'd0 : lat_min), total, REC_BEATS[31:0], sum_geo, T_SUM};
    assign m_axi_gmem1_wdata = (kst == K_GDAT_W) ? wreg : (kst == K_SUM_W) ? sum_beat : (kst == K_BYT_W) ? byt_beat : hdr_beat;
    // unused channels
    assign m_axi_gmem0_awaddr = {C_M_AXI_ADDR_WIDTH{1'b0}}; assign m_axi_gmem0_awlen = 8'd0;
    assign m_axi_gmem0_awsize = ASIZE; assign m_axi_gmem0_awburst = 2'b01; assign m_axi_gmem0_awvalid = 1'b0;
    assign m_axi_gmem0_wdata = {DW{1'b0}}; assign m_axi_gmem0_wstrb = {(DW/8){1'b0}};
    assign m_axi_gmem0_wlast = 1'b0; assign m_axi_gmem0_wvalid = 1'b0; assign m_axi_gmem0_bready = 1'b1;
    assign m_axi_gmem1_araddr = {C_M_AXI_ADDR_WIDTH{1'b0}}; assign m_axi_gmem1_arlen = 8'd0;
    assign m_axi_gmem1_arsize = ASIZE; assign m_axi_gmem1_arburst = 2'b01; assign m_axi_gmem1_arvalid = 1'b0;
    assign m_axi_gmem1_rready = 1'b1;

    // GET data assembly and buffer (one write port, one registered read)
    wire [15:0] gnext = (kst == K_GDAT_PRE) ? gb0 : gbi + 16'd1;   // next beat of the record to write back
    wire g_take = t_dout_valid && (kst == K_WAIT) && !cput;
    always @(posedge ap_clk) begin
        if (g_take && gch == CH_PER_BT - 1 && gbeats < REC_BEATS)
            rbuf[gbeats[RBW-1:0]] <= {t_dout, gasm[DW-1:FEDWidth]};
        if (kst == K_GDAT_PRE || (kst == K_GDAT_W && m_axi_gmem1_wvalid && m_axi_gmem1_wready)) begin
            wreg  <= rbuf[gnext[RBW-1:0]];
            gstrb <= beat_bytes(gnext);
            gbi   <= gnext;
        end
        if (fst == F_DR && m_axi_gmem0_rvalid) pbuf[f_cnt[RBW-1:0]] <= m_axi_gmem0_rdata;
    end

    wire [15:0] lastb = coff[15:0] + clen[15:0] - 16'd1;          // the record's last byte (valid ranges)
    wire        bad_range = (clen != 32'd0) && (coff >= BLKB || clen > BLKB - coff);   // record outside the block
    wire        a_wacked = a_quiet_w && a_wdone;                  // every tree write sent and acknowledged
    integer fm;
    always @(posedge ap_clk) begin
        if (rst) begin
            kst <= K_IDLE; booted <= 1'b0; core_run <= 1'b0; pages_base <= 64'd0; top_base <= 64'd0; top_q <= 64'd0; zf_t <= 1'b0;
            t_cmd <= 0; t_paddr <= 0; t_cmd_valid <= 1'b0; t_wmask <= {DMWidth{1'b1}};
            coff <= 32'd0; clen <= 32'd0; cend <= 16'd0; gb0 <= 16'd0; gb1 <= 16'd0; mcnt <= 16'd0; pbm <= 32'hFFFF_FFFF;
            fmask <= 32'hFFFF_FFFF; lmask <= 32'hFFFF_FFFF;
            idx <= 0; nsize <= 0; cbase <= 0; rbase <= 0; hc_off <= 0; hr_off <= 0;
            ctype <= 8'd0; ckey <= 32'd0; lat <= 0; lat_min <= 32'hFFFF_FFFF; lat_max <= 0; wait_cnt <= 0;
            total <= 64'd0; stat <= 0; errs <= 0; ndone <= 0; cput <= 1'b0;
            pbeat <= 0; pbeat_v <= 1'b0; pch <= 0; pd_rd <= 0; pchunks_out <= 0;
            gasm <= 0; gch <= 0; gbeats <= 0; wcnt <= 0; wsent_run <= 2'd0;
            lat_d <= 0; got_d <= 1'b0;
            g2_rd <= 64'd0; g2_wr <= 64'd0; g2_rd0 <= 64'd0; g2_wr0 <= 64'd0;
            g3_rd <= 64'd0; g3_wr <= 64'd0; g3_rd0 <= 64'd0; g3_wr0 <= 64'd0;
            zf_awvalid <= 1'b0; zf_wvalid <= 1'b0; zf_awaddr <= 64'd0; zf_awlen <= 8'd0; zf_wcnt <= 8'd0;
            zf_off <= 64'd0; zf_bout <= 32'd0; rst_cnt <= 5'd0; zf_err <= 1'b0;
`ifdef TINYORAM_PM_HBM
            pm_base <= 64'd0; pm_zstart <= 1'b0; pm_zstarted <= 1'b0;
`endif
`ifdef TINYORAM_RTDEPTH
            act_L <= ORAML[4:0]; req_L <= ORAML[4:0];
`endif
            fst <= F_IDLE; f_idx <= 32'd0; f_hdr <= 128'd0; f_cnt <= 0; f_go <= 1'b0; f_go_idx <= 32'd0;
            released <= 1'b0; lat_rel <= 0; ack_seen <= 1'b0; lat_ack <= 0; errs_q <= 32'd0; nlate <= 32'd0;
            hq_v <= 1'b0; hq_ackw <= 1'b0; hq_idx <= 0; hq_key <= 0; hq_stat <= 0; hq_lat <= 0; hq_latd <= 0; hq_lata <= 0;
            hst <= H_IDLE; wb_pend <= 32'd0;
            m_axi_gmem0_arvalid <= 1'b0; m_axi_gmem0_araddr <= 0; m_axi_gmem0_arlen <= 8'd0;
            m_axi_gmem1_awvalid <= 1'b0; m_axi_gmem1_awaddr <= 0; m_axi_gmem1_awlen <= 8'd0; m_axi_gmem1_wvalid <= 1'b0;
            done_pulse <= 1'b0;
        end else begin
            done_pulse <= 1'b0;
            if (kst != K_IDLE && kst != K_DONE) total <= total + 64'd1;
            g2_rd <= g2_rd + ((m_axi_gmem2_rvalid && m_axi_gmem2_rready) ? 64'd1 : 64'd0)     // both tree ports
                           + ((m_axi_gmem3_rvalid && m_axi_gmem3_rready) ? 64'd1 : 64'd0);
            g2_wr <= g2_wr + ((m_axi_gmem2_wvalid && m_axi_gmem2_wready) ? 64'd1 : 64'd0)
                           + ((m_axi_gmem3_wvalid && m_axi_gmem3_wready) ? 64'd1 : 64'd0);
            if (m_axi_gmem3_rvalid && m_axi_gmem3_rready) g3_rd <= g3_rd + 64'd1;
            if (m_axi_gmem3_wvalid && m_axi_gmem3_wready) g3_wr <= g3_wr + 64'd1;
            // zero-fill write responses (only during the fill, and never below zero: a stray response left
            // from an aborted run is ignored)
            zf_bout <= zf_bout + ((zf_awvalid && zf_aw_ok) ? 32'd1 : 32'd0)
                               - ((!core_run && (m_axi_gmem2_bvalid || m_axi_gmem3_bvalid) && zf_bout != 32'd0 &&
                                   (kst == K_FILL || kst == K_FILL_W || kst == K_FILL_B)) ? 32'd1 : 32'd0)
                               - ((!core_run && m_axi_gmem2_bvalid && m_axi_gmem3_bvalid && zf_bout > 32'd1 &&
                                   (kst == K_FILL || kst == K_FILL_W || kst == K_FILL_B)) ? 32'd1 : 32'd0);
            if (!core_run && ((m_axi_gmem2_bvalid && m_axi_gmem2_bresp != 2'b00) || (m_axi_gmem3_bvalid && m_axi_gmem3_bresp != 2'b00)) &&
                (kst == K_FILL || kst == K_FILL_W || kst == K_FILL_B)) zf_err <= 1'b1;
            // posted response writes: +1 per AW issued (GET data, headers), -1 per B (the summary and
            // traffic records, written once the count is back to zero, wait for their own B)
            wb_pend <= wb_pend + ((m_axi_gmem1_awvalid && m_axi_gmem1_awready && kst != K_SUM_AW && kst != K_BYT_AW) ? 32'd1 : 32'd0)
                               - ((m_axi_gmem1_bvalid && kst != K_SUM_B && kst != K_BYT_B) ? 32'd1 : 32'd0);
            // GET data assembly (64-bit chunks, chunk 0 in the low bits)
            if (g_take) begin
                gasm <= {t_dout, gasm[DW-1:FEDWidth]};
                if (gch == CH_PER_BT - 1) begin gch <= 0; gbeats <= gbeats + 1'b1; end
                else gch <= gch + 1'b1;
            end

            // ---------------- fetcher ----------------
            case (fst)
                F_IDLE, F_DONE: if (f_go) begin                       // a request stays pending until taken here
                    f_go <= 1'b0; f_idx <= f_go_idx; f_cnt <= 0; fst <= F_HAR;
                    m_axi_gmem0_araddr <= cbase + {f_go_idx, 5'd0}; m_axi_gmem0_arlen <= 8'd0; m_axi_gmem0_arvalid <= 1'b1;
                end
                F_HAR: if (m_axi_gmem0_arready) begin m_axi_gmem0_arvalid <= 1'b0; fst <= F_HR; end
                F_HR: if (m_axi_gmem0_rvalid) begin
                    f_hdr <= m_axi_gmem0_rdata[127:0];
                    if (m_axi_gmem0_rdata[7:0] == T_PUT) begin
                        m_axi_gmem0_araddr <= cbase + hc_off + ({32'd0, f_idx} << BLG);
                        m_axi_gmem0_arlen <= REC_BEATS - 1; m_axi_gmem0_arvalid <= 1'b1; fst <= F_DAR;
                    end else fst <= F_DONE;
                end
                F_DAR: if (m_axi_gmem0_arready) begin m_axi_gmem0_arvalid <= 1'b0; fst <= F_DR; end
                F_DR: if (m_axi_gmem0_rvalid) begin
                    f_cnt <= f_cnt + 1'b1;
                    if (m_axi_gmem0_rlast) fst <= F_DONE;
                end
                default: fst <= F_IDLE;
            endcase

            // ---------------- header queue and writer ----------------
            // a released command whose header is not queued yet: note when its writes are acknowledged
            if (released && !ack_seen && a_wacked) begin ack_seen <= 1'b1; lat_ack <= lat; end
            // the queued header waits for the acknowledgements; an AXI error or no acknowledgement in time
            // is charged to that command (header status and summary)
            if (hq_v && hq_ackw) begin
                // an error first: the failing B may be the last one, and then both show in the same cycle
                if (halted) begin hq_ackw <= 1'b0; hq_stat <= hq_stat | 32'h8; errs_q <= errs_q | 32'h8; nlate <= nlate + 1; end
                else if (a_wacked) hq_ackw <= 1'b0;
                else if (hq_lata - hq_lat >= CMD_TIMEOUT) begin hq_ackw <= 1'b0; hq_stat <= hq_stat | 32'h10; errs_q <= errs_q | 32'h10; nlate <= nlate + 1; end
                else hq_lata <= hq_lata + 32'd1;
            end
            case (hst)
                H_IDLE: if (hq_v && !hq_ackw && !eng_gm1 && kst != K_GDAT_AW) begin
                    m_axi_gmem1_awaddr <= rbase + {hq_idx, 5'd0}; m_axi_gmem1_awlen <= 8'd0; m_axi_gmem1_awvalid <= 1'b1; hst <= H_AW;
                end
                H_AW: if (m_axi_gmem1_awready) begin m_axi_gmem1_awvalid <= 1'b0; m_axi_gmem1_wvalid <= 1'b1; hst <= H_W; end
                H_W:  if (m_axi_gmem1_wready) begin m_axi_gmem1_wvalid <= 1'b0; hq_v <= 1'b0; hst <= H_IDLE; end
                default: hst <= H_IDLE;
            endcase

            case (kst)
                K_IDLE: if (ap_start_r && !done_pulse) begin
                    nsize  <= arg_n; cbase <= arg_cmd; rbase <= arg_resp;
                    hc_off <= ({32'd0, arg_n} * 64'd32 + 64'd4095) & ~64'd4095;
                    hr_off <= ({32'd0, arg_n} * 64'd32 + 64'd64 + 64'd4095) & ~64'd4095;   // after records [size], [size+1]
                    idx <= 0; total <= 64'd0; ndone <= 0; lat_min <= 32'hFFFF_FFFF; lat_max <= 0;
                    g2_rd0 <= g2_rd; g2_wr0 <= g2_wr; g3_rd0 <= g3_rd; g3_wr0 <= g3_wr;
                    zf_off <= 64'd0; zf_bout <= 32'd0;
`ifdef TINYORAM_PM_HBM
                    pm_zstarted <= 1'b0; pm_zstart <= 1'b0;
`endif
                    fst <= F_IDLE; f_idx <= 32'hFFFF_FFFF; f_go <= 1'b0;      // every run starts with no prefetch
                    errs_q <= 32'd0; nlate <= 32'd0; wait_cnt <= 0;
`ifdef TINYORAM_RTDEPTH
                    if (arg_size == 32'd0 || arg_size[31]) begin
                        req_L <= arg_size[31] ? arg_size[4:0] : ORAML[4:0];   // applied in K_RST, with the core in reset
`else
                    if (arg_size == 32'd0) begin
`endif
                        // init launch: re-boot. Tiny ORAM and the adapter go (back) into reset, the pages
                        // address is latched again, and the next launch with commands zero-fills the tree
                        pages_base <= arg_pages; top_base <= arg_top; top_q <= arg_top_eff; booted <= 1'b1; zf_err <= 1'b0;
`ifdef TINYORAM_PM_HBM
                        pm_base <= arg_pm;
`endif
                        errs <= arg_top_adj ? 32'h80 : 32'h0;                  // top_bytes adjusted
                        rst_cnt <= 5'd0; kst <= K_RST;
                    end else if (!booted) begin                       // commands without an init launch first
                        pages_base <= arg_pages; top_base <= arg_top; top_q <= arg_top_eff; booted <= 1'b1; kst <= K_FILL;
`ifdef TINYORAM_PM_HBM
                        pm_base <= arg_pm;
`endif
                        errs <= arg_top_adj ? 32'h80 : 32'h0;
                    end else begin
`ifdef TINYORAM_PM_HBM
                        errs <= (arg_pages != pages_base || arg_top != top_base || arg_top_eff != top_q || arg_pm != pm_base) ? 32'h20 : 32'h0;
`else
                        errs <= (arg_pages != pages_base || arg_top != top_base || arg_top_eff != top_q) ? 32'h20 : 32'h0;   // the latched buffers are kept
`endif
                        kst <= core_run ? K_BOOT : K_FILL;
                    end
                end
                K_RST: begin
                    if (core_run) begin
                        // first let any traffic left from an aborted run finish (bounded), then reset
                        if (a_idle || wait_cnt >= CMD_TIMEOUT) begin core_run <= 1'b0; if (!a_idle) errs <= errs | 32'h10; end
                        else wait_cnt <= wait_cnt + 1;
                    end else begin                                    // hold the reset, then report the geometry
                        rst_cnt <= rst_cnt + 5'd1;
                        if (rst_cnt == RST_HOLD - 1) kst <= K_SUM_AW;
`ifdef TINYORAM_RTDEPTH
                        // the requested depth, while the core is in reset; its geometry settles a cycle later,
                        // then the tree-top split is taken again against the new tree size
                        if (rst_cnt == 5'd0) begin
                            if (req_L >= RT_LMIN && req_L <= ORAML) act_L <= req_L;
                            else begin act_L <= ORAML[4:0]; errs <= errs | 32'h100; end
                        end
                        if (rst_cnt == 5'd3) begin
                            top_q <= arg_top_eff;
                            errs <= (errs & ~32'h80) | (arg_top_adj ? 32'h80 : 32'h0);
                        end
`endif
                    end
                end
                // ---- first launch with commands after an init: zero the tree, then release Tiny ORAM from reset
                K_FILL: begin
`ifdef TINYORAM_PM_HBM
                    pm_zstart <= !pm_zstarted; pm_zstarted <= 1'b1;   // zero the position map alongside the tree
`endif
                    if (!zf_awvalid) begin
                        if (zf_off >= tree_bytes_rt) kst <= K_FILL_B;
                        else begin
                            zf_t       <= (zf_off < top_q);                         // the top part goes to gmem3
                            zf_awaddr  <= (zf_off < top_q) ? top_base + zf_off : `TOR_PAGES_RB + zf_off;
                            zf_awlen   <= ((tree_bytes_rt - zf_off) >= FILL_BEATS * (DW / 8)) ? FILL_BEATS - 1
                                          : ((tree_bytes_rt - zf_off) / (DW / 8)) - 1;
                            zf_awvalid <= 1'b1;
                        end
                    end else if (zf_aw_ok) begin
                        zf_awvalid <= 1'b0; zf_wvalid <= 1'b1; zf_wcnt <= 8'd0; kst <= K_FILL_W;
                    end
                end
                K_FILL_W: if (zf_wvalid && zf_w_ok) begin
                    if (zf_wcnt == zf_awlen) begin
                        zf_wvalid <= 1'b0; zf_off <= zf_off + ({56'd0, zf_awlen} + 64'd1) * (DW / 8); kst <= K_FILL;
                    end else zf_wcnt <= zf_wcnt + 8'd1;
                end
`ifdef TINYORAM_PM_HBM
                K_FILL_B: begin pm_zstart <= 1'b0; if (zf_bout == 32'd0 && pm_zdone && !pm_zstart) begin core_run <= 1'b1; kst <= K_BOOT; end end
`else
                K_FILL_B: if (zf_bout == 32'd0) begin core_run <= 1'b1; kst <= K_BOOT; end
`endif
                K_BOOT: if (t_cmd_ready) begin                        // Tiny ORAM's own init done
                    if (nsize == 0) kst <= K_SUM_AW;
                    else begin f_go <= 1'b1; f_go_idx <= 32'd0; kst <= K_HDR; end
                end else if (wait_cnt >= CMD_TIMEOUT) begin errs <= errs | 32'h10; kst <= K_SUM_AW; end   // never ready
                else wait_cnt <= wait_cnt + 1;
                // ---- the command header, from the fetcher (prefetched while the previous command ran)
                K_HDR: if (f_hdr_ok) begin
                    ctype <= f_hdr[7:0]; ckey <= f_hdr[63:32]; coff <= f_hdr[95:64]; clen <= f_hdr[127:96];
                    wait_cnt <= 0; kst <= K_CHK;
                    t_wmask <= {DMWidth{1'b1}};                                  // whole block unless K_MASK rebuilds it
                end
                // ---- check the command, then (partial PUT) build Tiny ORAM's byte write mask
                K_CHK: begin
                    stat <= 32'd0; lat <= 0; cput <= (ctype == T_PUT); released <= 1'b0; ack_seen <= 1'b0;
                    pbeat_v <= 1'b0; pch <= 0; pd_rd <= 0; pchunks_out <= 0;
                    gch <= 0; gbeats <= 0; wsent_run <= 2'd0;
                    lat_d <= 0; got_d <= 1'b0;
                    cend <= coff[15:0] + clen[15:0];
                    for (fm = 0; fm < 32; fm = fm + 1) begin
                        fmask[fm] <= (fm >= coff[4:0]);
                        lmask[fm] <= (fm <= lastb[4:0]);
                    end
                    gb0 <= (clen == 32'd0) ? 16'd0 : {5'd0, coff[15:5]};
                    gb1 <= (clen == 32'd0) ? REC_BEATS[15:0] - 16'd1 : (lastb >> 5);                       // beat of the last byte
                    // the order of doma_kernel's checks: opcode, PUT range, halted, key; then (Tiny ORAM only,
                    // since doma_kernel's GETs return the whole block) the GET range
                    if (ctype != T_GET && ctype != T_PUT) begin stat <= 32'h2; kst <= K_HQ; end
                    else if (ctype == T_PUT && bad_range) begin stat <= 32'h40; kst <= K_HQ; end
                    else if (halted) begin stat <= 32'h8; errs <= errs | 32'h8; kst <= K_HQ; end
                    else if (ckey >= nkeys_rt) begin stat <= 32'h4; kst <= K_HQ; end
                    else if (bad_range) begin stat <= 32'h40; kst <= K_HQ; end
                    else if (ctype == T_PUT && clen != 32'd0) begin mcnt <= 16'd0; kst <= K_MASK; end
                    else kst <= K_REQ;
                end
                K_MASK: begin
                    t_wmask[mcnt * MCH +: MCH] <= mchunk;
                    mcnt <= mcnt + 16'd1;
                    if (mcnt == MSTEPS - 1) kst <= K_REQ;
                end
                // ---- issue the request to Tiny ORAM
                K_REQ: begin
                    if (halted) begin stat <= 32'h8; errs <= errs | 32'h8; t_cmd_valid <= 1'b0; kst <= K_HQ; end
                    else if (!t_cmd_valid) begin
                        t_cmd <= (ctype == T_PUT) ? BECMD_Update : BECMD_Read; t_paddr <= ckey; t_cmd_valid <= 1'b1;
                    end else if (t_cmd_ready) begin                       // handshake this cycle
                        t_cmd_valid <= 1'b0; lat <= 32'd1; wait_cnt <= 0;
                        kst <= (ctype == T_PUT) ? K_PDAT : K_WAIT;
                    end else if (wait_cnt >= CMD_TIMEOUT) begin           // Tiny ORAM never became ready
                        t_cmd_valid <= 1'b0; stat <= 32'h10; errs <= errs | 32'h10; kst <= K_HQ;
                    end else wait_cnt <= wait_cnt + 1;
                end
                // ---- PUT data: stream the record from pbuf (filled by the fetcher) into Tiny ORAM
                K_PDAT: begin
                    lat <= lat + 1;
                    if (!pbeat_v && pd_rd < f_cnt) begin
                        pbeat <= pbuf[pd_rd[RBW-1:0]]; pbeat_v <= 1'b1; pch <= 0; pd_rd <= pd_rd + 1'b1;
                        pbm <= beat_bytes({{(15-RBW){1'b0}}, pd_rd});
                    end
                    if (t_din_valid && t_din_ready) begin
                        pchunks_out <= pchunks_out + 16'd1;
                        if (pch == CH_PER_BT - 1) pbeat_v <= 1'b0; else pch <= pch + 1'b1;
                        if (pchunks_out + 16'd1 == rec_chunks) kst <= K_WAIT;
                    end
                end
                // ---- wait for the write-back to be handed off; meanwhile prefetch the next command
                K_WAIT: begin
                    lat <= lat + 1; wait_cnt <= wait_cnt + 1;
                    if (wait_cnt == 0 && idx + 1 < nsize) begin f_go <= 1'b1; f_go_idx <= idx + 1; end
                    // data ready: GET record received, or (PUT) record sent, which is true on entry
                    if (!got_d && (cput || gbeats == REC_BEATS)) begin got_d <= 1'b1; lat_d <= lat; end
                    // released: Tiny ORAM idle and every write beat on the bus, for 2 cycles
                    wsent_run <= (t_idle && a_quiet_w && got_d) ? ((wsent_run == 2'd2) ? 2'd2 : wsent_run + 2'd1) : 2'd0;
                    // a halted ORAM first: its write-back may have failed even though it was handed off
                    if (halted) begin stat <= 32'h8; errs <= errs | 32'h8; kst <= K_HQ; end
                    else if (wsent_run == 2'd2) begin
                        released <= 1'b1; lat_rel <= lat; ack_seen <= a_wacked; lat_ack <= lat;
                        ndone <= ndone + 1;
                        if (lat < lat_min) lat_min <= lat;
                        if (lat > lat_max) lat_max <= lat;
                        kst <= cput ? K_HQ : K_GDAT_AW;
                    end else if (wait_cnt >= CMD_TIMEOUT) begin
                        stat <= 32'h10; errs <= errs | 32'h10;
                        kst <= K_HQ;
                    end
                end
                // ---- GET data (posted), then the header
                K_GDAT_AW: begin
                    lat <= lat + 1;                                   // keeps counting for the acknowledged figure
                    if (hst == H_IDLE) begin
                        m_axi_gmem1_awaddr <= rbase + hr_off + ({32'd0, idx} << BLG) + {43'd0, gb0, 5'd0};
                        m_axi_gmem1_awlen <= gb1[7:0] - gb0[7:0]; m_axi_gmem1_awvalid <= 1'b1;
                        if (m_axi_gmem1_awvalid && m_axi_gmem1_awready) begin m_axi_gmem1_awvalid <= 1'b0; kst <= K_GDAT_PRE; end
                    end
                end
                K_GDAT_PRE: begin wcnt <= 0; lat <= lat + 1; kst <= K_GDAT_W; end
                K_GDAT_W: begin
                    lat <= lat + 1;
                    m_axi_gmem1_wvalid <= 1'b1;
                    if (m_axi_gmem1_wvalid && m_axi_gmem1_wready) begin
                        wcnt <= wcnt + 1'b1;
                        if (wcnt == gb1 - gb0) begin m_axi_gmem1_wvalid <= 1'b0; kst <= K_HQ; end
                    end
                end
                // ---- queue the header; it is written once the tree writes are acknowledged (a rejected
                // command touched no memory, but waits behind the previous command's header)
                K_HQ: if (!hq_v) begin
                    hq_v <= 1'b1; hq_idx <= idx; hq_key <= ckey; hq_stat <= (released && halted) ? (stat | 32'h8) : stat;
                    if (released && halted) begin errs_q <= errs_q | 32'h8; nlate <= nlate + 1; end
                    hq_lat <= released ? lat_rel : lat; hq_latd <= lat_d;
                    hq_lata <= (released && ack_seen) ? lat_ack : lat;   // acknowledged already, or counting on from now
                    hq_ackw <= released && !halted && !ack_seen && !a_wacked;
                    kst <= K_NEXT;
                end else if (released) lat <= lat + 1;
                K_NEXT: begin
                    idx <= idx + 1;
                    if ((idx + 1 == nsize) || halted || stat[4]) begin wait_cnt <= 0; kst <= K_DRAIN; end
                    else begin
                        if (!(f_idx == idx + 1 && fst != F_IDLE)) begin f_go <= 1'b1; f_go_idx <= idx + 1; end   // not prefetched
                        kst <= K_HDR;
                    end
                end
                // ---- end of run: the last header written, every posted write acknowledged, no fetch in flight
                // (and Tiny ORAM idle with nothing left in the adapter, bounded: after a fault, Tiny ORAM still
                // finishes the access it was in, and the traffic record must include it)
                K_DRAIN: if (!hq_v && hst == H_IDLE && wb_pend == 32'd0 && !f_busy && !f_go) begin
                    if ((t_idle && a_idle) || wait_cnt >= CMD_TIMEOUT) kst <= K_SUM_AW;
                    else wait_cnt <= wait_cnt + 1;
                end
                // ---- summary record [size]
                K_SUM_AW: begin
                    m_axi_gmem1_awaddr <= rbase + {nsize, 5'd0}; m_axi_gmem1_awlen <= 8'd0; m_axi_gmem1_awvalid <= 1'b1;
                    if (m_axi_gmem1_awvalid && m_axi_gmem1_awready) begin m_axi_gmem1_awvalid <= 1'b0; kst <= K_SUM_W; end
                end
                K_SUM_W: begin
                    m_axi_gmem1_wvalid <= 1'b1;
                    if (m_axi_gmem1_wvalid && m_axi_gmem1_wready) begin m_axi_gmem1_wvalid <= 1'b0; kst <= K_SUM_B; end
                end
                K_SUM_B: if (m_axi_gmem1_bvalid) kst <= K_BYT_AW;
                // ---- traffic record [size+1]
                K_BYT_AW: begin
                    m_axi_gmem1_awaddr <= rbase + {nsize + 32'd1, 5'd0}; m_axi_gmem1_awlen <= 8'd0; m_axi_gmem1_awvalid <= 1'b1;
                    if (m_axi_gmem1_awvalid && m_axi_gmem1_awready) begin m_axi_gmem1_awvalid <= 1'b0; kst <= K_BYT_W; end
                end
                K_BYT_W: begin
                    m_axi_gmem1_wvalid <= 1'b1;
                    if (m_axi_gmem1_wvalid && m_axi_gmem1_wready) begin m_axi_gmem1_wvalid <= 1'b0; kst <= K_BYT_B; end
                end
                K_BYT_B: if (m_axi_gmem1_bvalid) kst <= K_DONE;
                K_DONE: begin done_pulse <= 1'b1; kst <= K_IDLE; end
                default: kst <= K_IDLE;
            endcase
        end
    end
endmodule
