#!/bin/bash
# build_tinyoram.sh -- tinyoram_kernel.xo -> tinyoram_<size>_<target>.xclbin -> host program  (UNTESTED here)
# Needs Vitis/Vivado 2024.1, XRT and the U55C platform (source both setup scripts first).
#   SIZE=4k TARGET=hw_emu bash build_tinyoram.sh   # hardware emulation, no card needed
#   SIZE=4k TARGET=hw     bash build_tinyoram.sh   # board bitstream (hours); run synth_ooc_tinyoram.tcl first
#   SIZE = 64 | 128 | 256 | 4k   (block size; 64 also serves 8-32 B records)
#   N    = records (default 256). Tiny ORAM's tree depth is fixed per build: L (>= 6) is the smallest
#          with 4 * 2^L >= blocks. Run the host with the same DOMA_N.
#   MERGE = 1: the adapter merges contiguous Tiny ORAM commands into one AXI burst (one bucket or more,
#          never across 4 KB); 0 (default) = the 1:1 adapter, one 64-byte burst per command. Tag _merge.
#   FLATPM = 1: no PosMap recursion; the whole position map on chip (N x 64-bit counters, 1 MB at
#          131,072 blocks), the same trust assumption as DOMA's on-package position map. Tag _flatpm.
#   RTDEPTH = 1: run-time tree depth (patch 08): built for L_max = the L of N, and run at any L from 6 to L_max,
#          chosen by the host from DOMA_N at its init (the core then behaves as the native build of that L;
#          sim/run_tinyoram_rteq.sh checks this cycle by cycle). One build serves every N up to N's. Tag _rt.
#   TOPPLAIN = 1: plaintext tree top (patch 09, README §25): buckets below the run's top_bytes split (the on-package
#          tree top) are stored in plaintext, every other bucket exactly as by default. Tag _tp.
#   HBMPM = 1: the flat position map in HBM (patch 10, README §26): no PosMap recursion, one 8-byte entry per block on
#          a fifth master (posmap, argument 6), read and written once per access; top_bytes counts 4 KB units and the
#          pages buffer holds only the tree below the top. Needs CFG=tinyoram_host_pm.cfg (set by default with
#          HBMPM=1); not with FLATPM or RTDEPTH. Tag _hbmpm.
#   PACK = 1: BLOCK/8 8-byte records per block (host DOMA_PACK=1), so blocks = N / (BLOCK/8);
#          e.g. SIZE=64 PACK=1 N=1000000 -> 125,000 blocks, L=15. Unpacked, N=1000000 -> L=18.
#   CFG  = tinyoram_hw.cfg (tree in HBM[8], default) | tinyoram_host.cfg (tree in HOST[0]; needs host
#          memory enabled on the card; the tag gets _host)
#   FREQ = kernel clock in MHz (default 300). If 300 does not close, rebuild with a lower FREQ and
#          report results in both cycles and time; check_timing.sh then checks against FREQ.
# Each size and N is its own xclbin, built in its own v++ temp directory (_x_<tag>).
set -euo pipefail
cd "$(dirname "$0")"
PLATFORM=${PLATFORM:-xilinx_u55c_gen3x16_xdma_3_202210_1}
TARGET=${TARGET:-hw}
SIZE=${SIZE:-4k}
CFG=${CFG:-tinyoram_hw.cfg}
FREQ=${FREQ:-300}
N=${N:-256}
PACK=${PACK:-0}
MERGE=${MERGE:-0}
FLATPM=${FLATPM:-0}
RTDEPTH=${RTDEPTH:-0}
TOPPLAIN=${TOPPLAIN:-0}
HBMPM=${HBMPM:-0}
if [ "$HBMPM" = 1 ]; then
    [ "$FLATPM" = 1 ] || [ "$RTDEPTH" = 1 ] && { echo "HBMPM=1 does not combine with FLATPM=1 or RTDEPTH=1"; exit 2; }
    [ "$CFG" = tinyoram_hw.cfg ] && CFG=tinyoram_host_pm.cfg       # the default config has no posmap port
    [ "$CFG" = tinyoram_host_pm.cfg ] || { echo "HBMPM=1 needs CFG=tinyoram_host_pm.cfg (it connects the posmap port)"; exit 2; }
fi
[ "$CFG" = tinyoram_host_pm.cfg ] && [ "$HBMPM" != 1 ] && { echo "CFG=tinyoram_host_pm.cfg is for HBMPM=1 builds"; exit 2; }
BB=$SIZE; case "$SIZE" in 1k) BB=1024 ;; 2k) BB=2048 ;; 4k) BB=4096 ;; esac
BLOCKS=$N; [ "$PACK" = 1 ] && BLOCKS=$(( (N + BB / 8 - 1) / (BB / 8) ))
L=6; while [ $((4 << L)) -lt $BLOCKS ]; do L=$((L + 1)); done
TAG=tinyoram_${SIZE}; [ "$N" = 256 ] && [ "$PACK" = 0 ] || TAG=${TAG}_n${N}; [ "$PACK" = 1 ] && TAG=${TAG}_p8
[ "$FREQ" = 300 ] || TAG=${TAG}_${FREQ}mhz
[ "$CFG" = tinyoram_host.cfg ] && TAG=${TAG}_host || true   # tree in host memory: its own xclbin name
[ "$CFG" = tinyoram_host_pm.cfg ] && TAG=${TAG}_host || true
[ "$MERGE" = 1 ] && TAG=${TAG}_merge || true
[ "$FLATPM" = 1 ] && TAG=${TAG}_flatpm || true
[ "$RTDEPTH" = 1 ] && TAG=${TAG}_rt || true
[ "$TOPPLAIN" = 1 ] && TAG=${TAG}_tp || true
[ "$HBMPM" = 1 ] && TAG=${TAG}_hbmpm || true
echo "Tiny ORAM build: $SIZE-byte blocks, $N records, $BLOCKS blocks -> L=$L (N=$((4 << L)) blocks), ${FREQ} MHz, tag $TAG"
bash ../tinyoram/fetch_tinyoram.sh $SIZE $L $([ "$MERGE" = 1 ] && echo merge) $([ "$FLATPM" = 1 ] && echo flatpm) $([ "$RTDEPTH" = 1 ] && echo rtdepth) $([ "$TOPPLAIN" = 1 ] && echo topplain) $([ "$HBMPM" = 1 ] && echo hbmpm)
# a one-minute Vivado elaboration of exactly these sources first (ELAB=0 skips it): a source error stops here,
# not hours into the build
if [ "${ELAB:-1}" = 1 ]; then
    vivado -mode batch -nojournal -nolog -source elab_tinyoram.tcl > elab_$TAG.log 2>&1 || true
    if grep -q "^ELAB PASS" elab_$TAG.log && ! grep -q "^ERROR:" elab_$TAG.log; then grep "^ELAB PASS" elab_$TAG.log
    else echo "*** ELABORATION FAILED ($(pwd)/elab_$TAG.log):"; grep -E "^ERROR:|^ELAB FAIL" elab_$TAG.log | head -10; exit 1; fi
fi
rm -rf tinyoram_ip tinyoram_pack     # the packager's work directories are shared by every Tiny ORAM configuration
# the .xo declares 300 MHz whatever FREQ is (the platform's kernel clock metadata); --kernel_frequency below sets FREQ
vivado -mode batch -nojournal -nolog -source package_tinyoram.tcl -tclargs ../tinyoram/rtl ../tinyoram/build/src $TAG.xo
# hardware builds: the same post-placement hook as build.sh (post_place.tcl: placed checkpoint, congestion,
# utilization per module, post-placement timing in _x_$TAG/link/vivado/vpl/prj/prj.runs/impl_1/)
HOOK=""
if [ "$TARGET" = "hw" ]; then HOOK="--vivado.prop run.impl_1.STEPS.PLACE_DESIGN.TCL.POST=$(pwd)/post_place.tcl"; fi
v++ -l -t $TARGET --platform $PLATFORM --kernel_frequency $FREQ --config $CFG $HOOK \
    --save-temps --temp_dir _x_$TAG -o ${TAG}_$TARGET.xclbin $TAG.xo
g++ -std=c++17 -O2 host_doma.cpp -I$XILINX_XRT/include -L$XILINX_XRT/lib -lxrt_coreutil -pthread -o host_doma
ENV="DOMA_KERNEL=tinyoram_kernel DOMA_BLOCK=$BB DOMA_N=$N"   # host settings for this bitstream
# (DOMA_TINY_TOP=<bytes> puts the top of the tree in the on-package top buffer; default 0)
[ "$PACK" = 1 ] && ENV="$ENV DOMA_PACK=1"
case "$CFG" in tinyoram_host*.cfg) ;; *) ENV="$ENV DOMA_PAGES_HBM=1" ;; esac   # tree buffer in HBM (tinyoram_hw.cfg)
if [ "$TARGET" = hw ]; then
    WANT_MHZ=$FREQ XCLBIN=${TAG}_hw.xclbin XDIR=_x_$TAG ./check_timing.sh || echo "*** TIMING NOT CLOSED: do not use ${TAG}_hw.xclbin for measurements ***"
    echo "run: $ENV ./host_doma ${TAG}_hw.xclbin 5000"
    [ "$RTDEPTH" = 1 ] && echo "     (run-time depth: any DOMA_N up to $N; the host selects L from it at init)"
fi
if [ "$TARGET" = hw_emu ]; then
    emconfigutil --platform $PLATFORM
    echo "run: XCL_EMULATION_MODE=hw_emu $ENV ./host_doma ${TAG}_hw_emu.xclbin 20"
fi
